# OCM M0 Persistence / Replay Format V1

M0 persistence exists to make runtime identity restart-safe; it is not a new epistemic theory.

## Event log

`EventStore` writes canonical JSON objects to an append-only JSONL log. Each event carries a schema identifier, monotonically increasing sequence number, predecessor event hash, event kind, payload, and its own SHA-256 hash. The supported M0 state transitions are `ADMIT_OBJECT`, `REVOKE_EVIDENCE`, and `REINSTATE_EVIDENCE`.

Replay is fail-closed. Sequence gaps, predecessor mismatches, unknown event kinds, malformed payloads, duplicate/invalid identities, or hash mismatches raise `PersistenceCannotCheck`, whose terminal is `CANNOT_CHECK`.

## Snapshot

A snapshot stores the runtime/schema versions, object identities and payloads, warrant/evidence IDs, dependency links, revoked evidence IDs, the last applied event sequence/hash, a hash of canonical runtime state, and a hash of the snapshot envelope. Snapshots are written atomically with `fsync`. Replay verifies the envelope and state hashes before accepting the snapshot, then replays later log entries.

## Required hostile lifecycle

The test suite requires this exact cross-process-equivalent lifecycle:

1. start from empty custody;
2. admit a learned object with named warrant evidence;
3. persist, reconstruct a fresh `EventStore`, and recover exactly;
4. revoke the warrant, persist, reconstruct, and require the object to remain present but not live;
5. reinstate the warrant, persist, reconstruct, and recover exact liveness;
6. mutate the log or snapshot and require `CANNOT_CHECK`.

No in-memory-only result satisfies M0.
