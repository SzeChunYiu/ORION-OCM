# ORION-V2 → ORION-OCM M0 Migration Provenance

## Frozen source identity

- Source repository: `SzeChunYiu/ORION-V2`
- Frozen source commit: `42b1b0d1ab5920a69036e1c782c6b84c92c3b4d3`
- Frozen OCM-owned tree: `research/orion-machine/**`
- Frozen OCM tree SHA: `9f04028706dfc70dad4606491c84eed72bba753c`
- Source PR ancestry recorded by M0: #290, #295, #298, #301, #302, #303.

The target repository must resolve `HEAD:research/orion-machine` to the same Git tree SHA. Historical preservation-class files are never rewritten in place. The generated migration manifest binds each selected migrated file to Git blob identity and SHA-256 content identity.

## Custody classes

`research/orion-machine/**` and the migrated OCM/KSO unit tests are preservation-class historical OCM evidence. A small frozen dependency slice is separately classified `PARENT_OWNED`; it exists only because inherited runners require exact Machine Epistemics primitives or protected receipts from ORION-V2. Parent-owned material does not become an OCM-originated claim.

Materialized parent-owned runtime custody is limited to:

- the frozen ME-X1 registered model/oracle/generator/arms/parent modules used by M1/M2 replay;
- the frozen ORION-V2 epistemic compatibility primitives required by those modules and by the inherited Jump binding;
- the protected ME-X3 Lean receipt consumed by M6a;
- a byte-equivalent extraction of the frozen `orion_v2.jump` module at `src/ocm/kso/jump.py`.

The exact blob identities are checked by `scripts/check_parent_dependencies.py`. The compatibility package under `src/orion_v2` is transitional M0 custody for historical replay; active OCM code must live under `src/ocm`.

## Authority preservation

M0 changes repository custody and runtime packaging only. It does not change scientific terminals. Guards require, among other inherited boundaries:

- M2 full solve: `PARENT_SUFFICIENT` where recorded;
- M0 general novelty: `NOT_ESTABLISHED`;
- M5: controlled codec chat only;
- M6a: `M6A_FORMAL_MATH_VERIFIER_CHANNEL_INTEGRATED_PARENT_SUFFICIENT`;
- negative/non-significant results remain negative/non-significant;
- `CANNOT_CHECK` is preserved and used for missing authority/evidence/dependencies rather than being upgraded to success.

`tests/test_authority_guard.py` plants authority-upgrade mutations and requires the guard to reject them.

## Dependency dispositions

Every Python reference entry point under `research/orion-machine/reference` is statically inventoried. Missing dependencies receive one of the explicit M0 dispositions: materialize an exact minimal dependency, equivalence-check an active extraction, mark a historical-only path, or return a named `CANNOT_CHECK`. There is no fail-open `ImportError` suppression and no permitted undeclared ORION-V2 checkout dependency.

The generated audit is `docs/DEPENDENCY_AUDIT_V1.json`.

## Active package boundary

New runtime code is under `src/ocm`. Historical scripts stay frozen under `research/`. The canonical Jump primitive is accepted into `src/ocm` only because it is byte-equivalent to the frozen parent source and is covered by an equivalence test. M0 does not refactor scientific algorithms into new semantics.

## Replay and persistence

The M0 runtime persistence format is append-only, versioned, hash-chained JSONL with a content-bound snapshot. Replay validates sequence, predecessor hash, event hash, snapshot state hash, and snapshot hash before reconstructing state. Evidence revocation and reinstatement survive process restart. Tampering terminates `CANNOT_CHECK`; it never fabricates or repairs authority.

## Programme gating

Issue #1 makes M0 predecessor to all later milestones. The programme inventory therefore marks M0 active and later milestones not started. Parked Method/Wisdom/Self-ORION work is preserved but not activated by migration. No M1+ implementation change is part of this branch.
