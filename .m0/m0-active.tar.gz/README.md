# ORION Cognitive Machine (OCM)

**Canonical repository for the ORION Cognitive Machine / Knowledge Space Object programme.**

OCM is a research programme toward a minimal self-extending cognitive machine. The active implementation gate is **M0: canonical repository and reproducibility**. No M1-or-later capability work is authorized until M0 closes.

## M0 clean-clone commands

From a fresh clone with Python 3.11+:

```bash
python -m pip install -e '.[test]'
python -m pytest tests
python -m ocm.demo --controlled
python -m ocm.status
```

The controlled demo is deliberately finite and fail-closed. It replays the inherited KSO mathematical sanity check, exact procedure learning/revocation, governed Jump calibration, controlled Language L0 generation, recursive-KSO revocation isolation, and the historical formal proof receipt. Every stage reports its inherited terminal and limitation.

## Scientific authority

Migration is custody, not capability expansion. In particular:

- the M2 full-solve comparison remains `PARENT_SUFFICIENT` where recorded;
- `CANNOT_CHECK` remains an admissible and required fail-closed state;
- negative and non-significant results remain negative/non-significant;
- M5 is controlled codec chat only;
- M6a is proof-kernel receipt integration, not frontier-math success;
- recursive/language/wisdom/method objects remain candidate organizations;
- general novelty/superiority remains `NOT_ESTABLISHED`.

The canonical M0 success terminal is `M0_CANONICAL_REPO_GREEN`. `python -m ocm.status` emits it only when the frozen historical tree, manifest, dependency audit, authority guards, persistence/restart checks, controlled demo, and content-bound test receipt all validate. Otherwise it exits with `CANNOT_CHECK`.

## Provenance boundary

The complete OCM-owned historical tree is preserved byte-for-byte from `SzeChunYiu/ORION-V2` at commit `42b1b0d1ab5920a69036e1c782c6b84c92c3b4d3`. A minimal frozen **parent-owned** compatibility slice is materialized only where inherited controlled runners require it. Those files do not become OCM-originated scientific claims.

See `docs/provenance/ORION_V2_MIGRATION.md`, `docs/provenance/MIGRATED_FILE_MANIFEST_V1.json`, `docs/DEPENDENCY_AUDIT_V1.json`, and `docs/PROGRAMME_ARTIFACT_INVENTORY_V1.json`.

## Programme management

Issue #1 is the programme spine. Issue #2 / M0 blocks every later milestone. Method-space expansion, Science KSO, broad wisdom/principle development, frontier-math claims, and self-architecture evolution remain parked until their declared programme gates are earned.
