from ocm.dependency_audit import main

if __name__ == "__main__":
    raise SystemExit(main())
