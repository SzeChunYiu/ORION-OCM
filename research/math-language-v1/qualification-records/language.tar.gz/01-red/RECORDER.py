"""Create-only local pytest evidence, no corpus or native proof dispatch."""
import hashlib, json, os, pathlib, resource, shutil, signal, subprocess, sys, time
base = pathlib.Path("/home/billy/orion-director-work/20260907")
source = base / "ocm-unary-language/research/math-language-v1"
python = base / "proof-runtime-engineering-env/bin/python"
root = base / "unary-language-qualification-v1" / sys.argv[1]
root.mkdir(parents=True, exist_ok=False)
def raw(p):
    b=p.read_bytes();return {"sha256":hashlib.sha256(b).hexdigest(),"bytes":len(b)}
def inventory():
    return {p.name:raw(p) for p in sorted(source.glob("*.py"))}
def write(name, value):
    with (root/name).open("x") as f:json.dump(value,f,indent=2,sort_keys=True);f.write("\n")
before=inventory()
(root/"source").mkdir()
for n in before: shutil.copyfile(source/n,root/"source"/n)
shutil.copyfile(__file__,root/"RECORDER.py")
write("SOURCE-BEFORE.json", before)
argv=[str(python),"-m","pytest","-q",".","--basetemp="+str(root/"cases"),"--junitxml="+str(root/"tests.xml")]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTEST_DISABLE_PLUGIN_AUTOLOAD="1")
write("REQUEST.json",{"argv":argv,"cwd":str(source),"environment_overrides":{"PYTHONDONTWRITEBYTECODE":"1","PYTEST_DISABLE_PLUGIN_AUTOLOAD":"1"},"python":dict(raw(python.resolve()),path=str(python),resolved=str(python.resolve()))})
start=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
p=None;failure=None
with (root/"stdout.log").open("xb") as out,(root/"stderr.log").open("xb") as err:
    try:
        p=subprocess.Popen(argv,cwd=source,env=env,stdout=out,stderr=err,start_new_session=True)
        p.wait(timeout=120)
    except BaseException as exc:
        failure=type(exc).__name__+": "+str(exc)
        if p is not None:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            p.wait()
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
after=inventory();write("SOURCE-AFTER.json",after)
write("PROCESS.json",{"argv":argv,"returncode":None if p is None else p.returncode,"pid":None if p is None else p.pid,"reaped":p is not None and p.returncode is not None,"error":failure,"outer_wall_s":time.monotonic()-start,"waited_child_user_s":usage.ru_utime-cpu.ru_utime,"waited_child_system_s":usage.ru_stime-cpu.ru_stime,"source_unchanged":before==after,"stdout":raw(root/"stdout.log"),"stderr":raw(root/"stderr.log"),"scope":"Authored package pytest only; no scientific evaluation or closed-host/no-neural qualification."})
print(json.dumps({"root":str(root),"returncode":None if p is None else p.returncode,"source_unchanged":before==after,"failure":failure}))
sys.exit(0 if failure is None and before==after else 2)
