# Concrete readiness and remaining inputs

- Ready for independent source review: boundary.py (two-node open cuts), alias_screen.py (P1 proof-ready screen), release_training.py (ordinal/dependency release) and run_opportunity.py (teaching-packet audit).
- Exact donors remain unchanged under donor/. The older typed extractor enumerates proper complete ancestor closures, not all two-node cuts. The boundary adapter is a separate source successor.
- Eleven authored structural/alias controls passed in PID 1913567. Four synthetic ordinal/dependency controls passed in PID 1926412. These are distinct pure processes, with no corpus/native/bridge calls. The first normal-proof control failure and repaired source remain in preflight-01 and REPAIR-01.json.
- The repetition control exercises the body-boundary helper over a declared synthetic DAG; it is not a complete saved-reference native trace qualification. The alpha control compares normalized boundaries across separately renamed synthetic catalogues, not cross-catalogue body identity.
- run_opportunity.py has source/AST inspection only; its whole packet/driver path has not been executed. A saved status in an arbitrary packet cannot replace the independently qualified external trace receipt bound by the root request.
- Missing before release: independent source review and a complete prior-protected-allocation exclusion attestation. No actual new training label list or opportunity count has been read.
- Missing before the opportunity audit: actual release receipt, new native trace export/source qualification, complete P1 contract/authority binding and the exact training-packet hash. The current six-anchor trace entry is not reusable as-is for 128 new labels.
- Missing before a scientific transfer study: usable training opportunity, sealed family split, development selection and held-out ordinary-consumption qualification. No minimum viable count is assumed.

The release and audit entry points are executable once their exact request/gate inputs exist. Current prospective specifications intentionally carry no invented input hashes. Root may authorize a metadata release after source/exclusion review; it does not thereby authorize native export or learner execution.
