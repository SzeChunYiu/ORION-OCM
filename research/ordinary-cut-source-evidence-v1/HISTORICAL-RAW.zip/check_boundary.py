"""Authored structural controls only; no corpus/native/learner execution."""
import copy,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/"donor")]
import boundary as C
import alias_screen as A
import structural_fixture as F
import typed_context as TC
checks=[]
def check(name,fn):
    fn();checks.append(name)
def fixture():
    tr,cs,inner=F.fixture();return tr,cs,inner
def edges():
    tr,cs,_=fixture();out=C.enumerate_two(tr,cs,{})
    assert len(out["rows"])==2
    assert all(x["status"]=="CUT_PROPOSAL" for x in out["rows"])
    assert all(x["logical_dag_nodes"]==2 for x in out["rows"])
    # The outer open cut is absent from the donor's proper ancestor closure language.
    assert any(x["head"]==tr["root"] for x in out["rows"])
def expected_inner():
    tr,cs,inner=fixture();rows=C.enumerate_two(tr,cs,{})["rows"]
    row=next(x for x in rows if tr["nodes"][x["head"]]["label"]=="pair")
    rename={old["label"]:new["label"] for old,new in zip(tr["source"]["essential"],row["proposal"]["hypotheses"])}
    assert row["proposal"]["proof"]==[rename.get(x,x) for x in inner]
def whole_excluded():
    tr,cs,inner=fixture();tr=F.trace_from_proof(tr["source"],cs,inner)
    cs={k:v for k,v in cs.items() if k in inner}
    rows=C.enumerate_two(tr,cs,{})["rows"]
    assert len(rows)==1 and rows[0]["status"]=="EXCLUDED_WHOLE_TRAINING_PROOF"
def repetition():
    tr,cs,_=fixture();head=next(n["id"] for n in tr["nodes"] if n.get("label")=="pair")
    child=next(n["id"] for n in tr["nodes"] if n.get("label")=="compose")
    # Private body-boundary witness over a declared DAG. Not a native/full-trace receipt.
    tr["nodes"][head]["inputs"][-2:]=[child,child]
    cs["pair"]["essential"]=[{"label":"pair.0","statement":tr["nodes"][child]["output"]},
                             {"label":"pair.1","statement":tr["nodes"][child]["output"]}]
    row=C.make_cut(tr,cs,head,child,{})
    assert row["logical_dag_nodes"]==2 and row["logical_tree_applications"]==3
    assert row["proposal"]["proof"].count("compose")==2
    assert len(row["boundary_nodes"])==2
def alpha():
    tr,cs,_=fixture();first=C.enumerate_two(tr,cs,{})
    t2,c2,_=F.fixture(names=("alpha","beta","gamma"),float_labels=("fa","fb","fc"))
    # Formal assertion metavariable names are part of the unchanged rule catalogue,
    # so this control compares boundary formulas, not a cross-catalogue body ID.
    second=C.enumerate_two(t2,c2,{})
    assert [(x["body"]["premises"],x["body"]["query"]) for x in first["rows"]]==[(x["body"]["premises"],x["body"]["query"]) for x in second["rows"]]
def source_refuses():
    tr,cs,_=fixture();tr["nodes"][0]["output"]=["wff","wrong"]
    try:C.enumerate_two(tr,cs,{})
    except ValueError:return
    raise AssertionError("tampered source accepted")
def rule(label="r",ports=()):
    return {"label":label,"kind":"$p","floating":[{"label":"fx","statement":["wff","x"]},{"label":"fy","statement":["wff","y"]}],
            "essential":[{"label":"h"+str(i),"statement":p} for i,p in enumerate(ports)],"dv":[],
            "statement":["|-","(","x","->","y",")"]}
def body(q,ps=()):return {"parameters":TC.parameters("wff"),"query":q,"premises":list(ps)}
Q=["|-","(","V0","->","V1",")"]
def direct_return_and_unknown():
    alien=rule();alien["floating"][0]["statement"][0]="alien"
    x=A.screen(body(Q,[Q]),[alien],{})
    assert x["status"]=="ALIAS_FOUND_PROOF_READY" and not x["coverage_complete"]
    assert x["aliases"]==[{"kind":"hypothesis_return","premise_indices":[0],"proof":["cut-h0"]}]
def reused_unused_ports():
    r=rule(ports=[["|-","(","x","->","y",")"]]*2)
    x=A.screen(body(Q,[["|-","V2"],Q]),[r],{})
    w=[x for x in x["aliases"] if x["kind"]=="one_logical_assertion"][0]
    assert w["premise_indices"]==[1,1] and w["proof"][-3:]==["cut-h1","cut-h1","r"]
def composite_repeated():
    wi={"label":"wi","kind":"$a","floating":[{"label":"fph","statement":["wff","ph"]},{"label":"fps","statement":["wff","ps"]}],"essential":[],"dv":[],"statement":["wff","(","ph","->","ps",")"]}
    term=["(","V0","->","V1",")"];q=["|-","("]+term+["->"]+term+[")"]
    x=A.screen(body(q),[rule(),wi],{})
    assert x["status"]=="ALIAS_FOUND_PROOF_READY" and x["coverage_complete"]
    assert x["aliases"][0]["proof"]==["cut-f0","cut-f1","wi","cut-f0","cut-f1","wi","r"]
def unknown_not_negative():
    x=A.screen(body(["|-","UNKNOWN"]),[],{})
    assert x["status"]=="UNKNOWN" and not x["coverage_complete"]
def empty_complete_domain():
    x=A.screen(body(Q),[],{})
    assert x["status"]=="SCREENED_NEGATIVE_IN_DOMAIN" and x["coverage_complete"]
start=time.perf_counter()
for name,fn in [("all essential edges/open boundary",edges),("independent inner normal proof",expected_inner),
("whole training theorem excluded",whole_excluded),("DAG versus repeated tree applications",repetition),
("typed alpha boundary",alpha),("source tamper refusal",source_refuses),
("positive survives unrelated UNKNOWN",direct_return_and_unknown),("repeated/unused ordinary hypotheses",reused_unused_ports),
("composite repeated syntax proof",composite_repeated),("unsupported ground UNKNOWN",unknown_not_negative),
("empty complete registered domain",empty_complete_domain)]:check(name,fn)
print(json.dumps({"terminal":"PURE_CONTROLS_PASS","checks":checks,"native_calls":0,"corpus_reads":0,"wall_s":time.perf_counter()-start},sort_keys=True))
