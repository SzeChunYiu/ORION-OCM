# Prospective ordinary cut opportunity audit

**Source preparation only. No new corpus body has been opened, no training release or native run is authorized.** This is a small native-input apparatus, not a new generic discovery miner or a novelty study.

## Population and release

The bound public set.mm file is selected in POPULATION-PROPOSAL.json. Reserve source $p ordinals 4,096–4,223 as one prospective training-only tranche; all first 4,095 theorems remain P0. All later proof bodies remain sealed. Do not replace excluded or unusable rows or require a useful count. The eight already exposed anchor/authored examples are apparatus controls only.

The Boolean census contract says its detailed results were internal and no train/dev/hidden allocation was made. That is distinct from a protected allocation. A root-custodian attestation must nevertheless reconcile every previous protected allocation for this corpus before release; the census alone cannot establish empty exclusions.

release_training.py uses the existing lexer/index and compressed-proof reference decoder. It stops at the exact 4,223rd proof terminator, closes only active lexical scopes, records all 128 positions and propagates protected theorem dependencies in source order. A protected P0 theorem causes refusal. No usable-row replacement occurs.

CUSTODIAN-PREFIX.mm may include excluded proofs and is restricted to the custodian/native trace qualifier. It is never a learner input. Released teaching packets omit excluded traces. Hashing the full corpus for custody does not authorize interpretation of later bodies.

## Native teaching qualification is a separate missing seam

The old trace entry permits six hardcoded public anchors. It cannot supply newly selected training DAGs without a separately reviewed source adapter. A fresh export must bind the released prefix, exact selected labels, all native authority identities and proof/DV contexts, and retain failed/unusable cases. Old accepted flags are not new authority.

The audit consumes a hash-bound, independently qualified teaching packet; it does not invoke the native checker. P1 retains every P0 assertion plus every released whole training theorem, even when that theorem's trace is outside the cut adapter's scope. New axiom or prefix changes require a separately versioned authority contract; they cannot inherit the old 96-assertion receipt.

## Exactly two distinct logical DAG applications

boundary.py preserves the old complete-ancestor extractor unchanged. For every logical node, it examines each ordered essential-input port after resolving saved references. When the parent is logical, those two distinct nodes form the selected cut. Other logical producers become boundary hypotheses; syntax nodes and floating proofs remain.

Repeated use of one declared essential hypothesis retains that proof identity. Different semantic frontier producers retain their identities. Every ordered application port and repeated proof use remains in the emitted proof. Two selected DAG nodes may expand to three logical proof-tree applications; both counters and normal label counts are recorded.

A whole demonstrated proof is excluded as a discovery candidate. Existing three-homogeneous-parameter/no-DV/no-extra-float, 256-source-node and 4,096-proof-label conditions remain. Boundaries outside the supported context are UNKNOWN_INTERFACE, not absent opportunities. No claim of complete general Metamath cuts follows.

## Ordinary P1 screen

alias_screen.py reuses the existing typed matcher and ground parsers. It includes direct hypothesis return and one existing logical assertion. Composite/repeated substitutions, repeated supplied-proof use, unused hypotheses and actual port order are allowed within the registered ground grammar. It constructs and structurally replays required syntax proofs.

ALIAS_FOUND_PROOF_READY records explicit substitution, ordered hypothesis witnesses and normal proof tokens. This is not fresh native acceptance. SCREENED_NEGATIVE_IN_DOMAIN requires complete registered coverage. Unsupported rows or exhausted work remain UNKNOWN. An already found positive witness remains available when unrelated comparisons are unknown.

run_opportunity.py records all root/cut dispositions and progressive root outputs. Proposed limits are two million matcher token states total and a 60-second soft in-process deadline, with any unfinished comparison marked UNKNOWN. These are containment limits, not optimized scientific settings or a hard OS deadline. A separate process observer must retain actual exit, resources and failures.

## Deliberately deferred branches

Three-node cuts require their own source, population and gate after the two-node result. They are not automatically run. Neither the ground CD Tools DAG factorizer nor its compression score is equivalent to these open cuts: ordered proof holes, typed parameters, syntax proofs and native DV authority require a separately qualified map. Existing TreeRePair/Horn and SGCD donor mechanisms remain the next larger-miner candidates; no GPL module or neural component is imported here.

A later usefulness experiment needs a separately sealed family allocation and the same acquired theorem in the strongest conventional host. This training-only audit cannot establish suitable held-out families, causal serving utility, repayment, language meaning or novelty.
