# Start here: ordinary cut opportunity apparatus

**Prepared, not corpus-executed.** The two-node boundary adapter and ordinary P1 screen have authored pure controls. A deterministic next-128-theorem training release is proposed before inspecting its bodies.

1. [Population boundary](POPULATION-PROPOSAL.json) and [protocol](PROTOCOL.md).
2. [Concrete readiness and missing inputs](READINESS.md).
3. [Donor provenance](DONORS.json), [read scope](READ-SCOPE.json), and [retained repair](REPAIR-01.json).
4. Source: boundary.py, alias_screen.py, release_training.py and run_opportunity.py.

No new corpus proof, candidate outcome, native verification, acquisition or search was run. All previous source, failure and published evidence remains unchanged. The eight exposed examples are apparatus references; they do not constitute an adequate new discovery population.
