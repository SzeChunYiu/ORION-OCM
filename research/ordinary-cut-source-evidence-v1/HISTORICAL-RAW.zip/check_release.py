"""Synthetic chronology/exclusion checks; no public corpus is read."""
import json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import release_training as R
def source():
    rows=["$c wff |- $.","$v ph $.","wph $f wff ph $.","ax $a |- ph $."]
    for i in range(1,4224):
        parent="ax" if i<=4096 else "t"+str(i-1)
        rows.append("t"+str(i)+" $p |- ph $= wph "+parent+" $.")
    return ("\n".join(rows)+"\n").encode()+b"UNRELEASED_INVALID_TAIL_\xff"
start=time.perf_counter();raw=source()
closed,result=R.release(raw,{"protected_labels":["t4097"]})
assert len(result["roots"])==128 and result["ordinals"]==list(range(4096,4224))
assert b"UNRELEASED" not in closed
assert result["roots"][0]["source_disposition"]=="RELEASED"
assert result["roots"][1]["source_disposition"]=="EXCLUDED_PRIOR_PROTECTED"
assert all(x["source_disposition"]=="EXCLUDED_DEPENDS_PRIOR_PROTECTED" for x in result["roots"][2:])
assert result["roots"][-1]["ordinal"]==4223  # no replacement or search for usable rows
try:R.release(raw,{"protected_labels":["t42"]})
except ValueError as exc:assert str(exc)=="protected theorem conflicts with unchanged P0"
else:raise AssertionError("P0 was weakened")
try:R.release(b"$c wff |- $.",{"protected_labels":[]})
except ValueError as exc:assert str(exc)=="fixed source range unavailable"
else:raise AssertionError("missing range accepted")
print(json.dumps({"terminal":"PURE_RELEASE_CONTROLS_PASS","checks":["exact ordinal range and unread tail","transitive exclusions without replacement","unchanged P0 conflict refusal","incomplete source range refusal"],"corpus_reads":0,"native_calls":0,"wall_s":time.perf_counter()-start},sort_keys=True))
