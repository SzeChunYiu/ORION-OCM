# Scoped v2 readiness

The v2 source is prepared for review. No actual corpus release, native prefix replay,
trace export, opportunity census or learned-lemma admission has run.

- Registry scope: root's exact 27-record universe and lineage, empty known protected
  native labels within that scope, no universal or held-out independence claim.
- Fixed range: all 4,095 original theorems in P0; exactly the next 128 source positions;
  exclusions and unusable rows retained without replacement.
- P1: explicit full-prefix axiom authority plus all P0 and released whole theorems.
  Trace extraction usability cannot remove an otherwise native-qualified theorem.
- Native input: coordinated v2 packet/P1/authority schemas with trace-export-v1.
  Actual corpus/export authority remains a separate missing input and gate.

Pure qualification retains 9 scope checks and 4 synthetic chronology checks in
qualification-01. The successor driver is exercised by 11 synthetic P1/packet checks
and 2 adversarial read-binding checks in qualification-02. Both synthetic packet
generations are preserved; their fabricated authority receipts are labelled doubles
and establish no native validity. All five actual child processes exited cleanly.

An inherited two-read JSON decoder defect was reproduced with an adversarial read
double and fixed: hash and decode the same byte string. Its exact preimage and
qualification-01 sources remain in source-before-read-binding-repair.

The unchanged boundary/alias mechanisms retain their original source/11-control
authority from candidate01; those experiments were not rerun. Current tests qualify
only the changed scope, custody and full-P1 boundary. All native/actual-release gates
remain closed. Root still needs to review/bind the concrete request and its observer.
