"""Synthetic scope/refusal controls plus readback of the real metadata-only declaration."""
import copy,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import registry_scope as R
scope=json.loads((ROOT/"REGISTRY-SCOPE.json").read_bytes())
corpus={"path":"/home/billy/orion-director-work/20260908/metamath-curriculum-feasibility-v1/set.mm",
        "bytes":51126635,"sha256":R.CORPUS}
checks=[];start=time.perf_counter()
def reject(name,change):
    changed=copy.deepcopy(scope);change(changed)
    try:R.validate(changed,corpus)
    except (ValueError,KeyError,TypeError):checks.append(name)
    else:raise AssertionError(name)
assert R.read_declared(scope,corpus)["source_metadata"]["records"];checks.append("real 27-record scoped declaration accepted without corpus read")
reject("old universal sentinel refused",lambda s:s.update(coverage="ALL_PREVIOUS_PROTECTED_ALLOCATIONS_FOR_THIS_CORPUS"))
reject("different corpus commit refused",lambda s:s.update(corpus_commit="0"*40))
reject("different registry universe refused",lambda s:s["universe"]["lineage"].update(sha256="0"*64))
reject("universal independence claim refused",lambda s:s.update(heldout_independence=True))
reject("replacement refused",lambda s:s.update(replacement=True))
reject("duplicate protected label refused",lambda s:s.update(protected_labels=["x","x"]))
reject("different ordinal range refused",lambda s:s.update(training_p_ordinals=[4096,4224]))
reject("extra schema field refused",lambda s:s.update(accepted=True))
print(json.dumps({"terminal":"PURE_SCOPE_CONTROLS_PASS","checks":checks,"native_calls":0,"corpus_reads":0,
                  "registry_metadata_read":True,"wall_s":time.perf_counter()-start},sort_keys=True))
