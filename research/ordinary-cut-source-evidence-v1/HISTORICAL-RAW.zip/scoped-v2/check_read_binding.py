"""Adversarial read double; no corpus, native or learner calls."""
import hashlib,importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_opportunity as fixed
spec=importlib.util.spec_from_file_location("old_driver",ROOT/"source-before-read-binding-repair/run_opportunity.py")
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
raw=b'{"value":"bound"}'
pin={"path":"double","bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
class Double:
    def __init__(self,*args):pass
    def read_bytes(self):return raw
    def read_text(self):return '{"value":"unbound"}'
old.Path=Double;fixed.Path=Double
assert old.read_bound(pin)=={"value":"unbound"}  # reproduces inherited wrong-byte interpretation
assert fixed.read_bound(pin)=={"value":"bound"}
print(json.dumps({"terminal":"PURE_READ_BINDING_CONTROLS_PASS","checks":["old two-read defect reproduced","fixed decoder consumes hash-bound bytes"],
                  "native_calls":0,"corpus_reads":0}))
