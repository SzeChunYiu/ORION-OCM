# Ordinary cut opportunity — scoped v2

This reviewed-first-version successor prepares a bounded training release and a
complete ordinary baseline. No corpus or native run is authorized by these files.

Read [PROTOCOL.md](PROTOCOL.md), [READINESS.md](READINESS.md), and
[REGISTRY-SCOPE.json](REGISTRY-SCOPE.json). The [release request](RELEASE-REQUEST.json)
is prepared for a separate root gate. The future native-qualified packet/P1 boundary
is implemented in teaching_packet.py and run_opportunity.py.

All first-version sources, the allocation audit and previous receipts remain
unchanged. Trace-unusable released theorems remain in P1; new prefix axioms require
fresh explicit authority. The scoped registry declaration grants no universal,
held-out or novelty claim.
