"""Authored structural controls; no corpus, native verifier, donor or bridge imports."""
import copy,types,unittest
import bound_io as B
import packet_export as K
import population as P
import trace_transport as U

FIELDS=("label","kind","statement","floating","essential","dv")
def contract(row):
    return {k:row[k] for k in FIELDS if k in row and (row["kind"] in {"$a","$p"} or k in FIELDS[:3])}
S=types.SimpleNamespace(contract=contract)
def example():
    hyp={"label":"h","kind":"$f","statement":["AUTHORED_TYPE","x"],"span":[1,2]}
    source={"label":"t","kind":"$p","statement":["AUTHORED_RESULT","x"],"span":[9,10],"raw":{},
        "proof_raw":{},"floating":[{"label":"h","statement":hyp["statement"]}],"essential":[],"dv":[],"active_dv":[]}
    trace={"source":source,"nodes":[{"label":"h"}],"terminal":"AUTHORED_NOT_NATIVE"}
    return trace,{"h":hyp,"t":source}

class TransportControls(unittest.TestCase):
    def test_exact_hypothesis_span_is_retained(self):
        trace,rows=example();out,contracts,reason=U.prepare(trace,rows,S)
        self.assertIs(out,trace);self.assertIsNone(reason)
        self.assertEqual(contracts["h"],rows["h"])
        self.assertIsNot(contracts["h"]["span"],rows["h"]["span"])
    def test_ordinary_projection_plus_span(self):
        trace,rows=example();a={**rows["t"],"label":"a","kind":"$a","span":[3,4]}
        rows["a"]=a;trace["nodes"].append({"label":"a"})
        _,contracts,_=U.prepare(trace,rows,S)
        self.assertEqual(contracts["a"],{**contract(a),"span":[3,4]})
        self.assertEqual(set(contracts["a"]),set(FIELDS)|{"span"})
    def test_unsupported_interface_has_explicit_disposition(self):
        for cause in ("extra_hypothesis","source_dv","used_dv","too_many_nodes","no_trace"):
            trace,rows=example()
            if cause=="extra_hypothesis":trace["source"]["floating"]=[]
            elif cause=="source_dv":trace["source"]["active_dv"]=[["x","y"]]
            elif cause=="used_dv":
                rows["a"]={**rows["t"],"label":"a","kind":"$a","span":[3,4],"dv":[["x","y"]]}
                trace["nodes"].append({"label":"a"})
            elif cause=="too_many_nodes":trace["nodes"]*=257
            else:trace=None
            with self.subTest(cause=cause):
                out,contracts,reason=U.prepare(trace,rows,S)
                self.assertIsNone(out);self.assertEqual(contracts,{});self.assertTrue(reason)
    def test_source_order_drift_is_binding_failure(self):
        trace,rows=example();rows["h"]["span"]=[9,10]
        with self.assertRaises(ValueError):U.prepare(trace,rows,S)
    def test_whole_p1_survives_unusable_and_excluded_is_empty(self):
        trace,rows=example();trace["source"]["floating"]=[]
        excluded={**rows["t"],"label":"excluded"};rows["excluded"]=excluded
        roots=[{"ordinal":4096,"label":"t","source_disposition":"RELEASED"},
               {"ordinal":4097,"label":"excluded","source_disposition":"EXCLUDED_PRIOR_PROTECTED"}]
        req={k:{"AUTHORED":k} for k in ("release","prefix","registry_scope","authority_contract",
             "P0_contracts","corpus","python","verifier","sources")}
        observed=types.SimpleNamespace(traces={"t":trace},unusable={})
        verified=types.SimpleNamespace(verified=[],scope_bindings={"t":{}})
        # No base theorem input in this tiny structural fixture; not a native qualification.
        authority,inventory,packet,retained=K.assemble(req,{"roots":roots},rows,[],[],verified,observed,None,S,P,B,U)
        self.assertEqual([r["label"] for r in inventory["contracts"]],["t"])
        released,protected=packet["roots"]
        self.assertEqual(released["trace_disposition"],"TRACE_UNUSABLE")
        self.assertEqual(released["whole_contract"],B.identity(B.canonical(contract(rows["t"]))))
        self.assertIsNone(released["trace"]);self.assertEqual(released["contracts"],{})
        self.assertIsNone(protected["whole_contract"]);self.assertEqual(protected["contracts"],{})
        self.assertIn("t",retained);self.assertEqual(authority["trace_bindings"],{})
    def test_ready_hash_covers_contract_span(self):
        trace,rows=example();out,contracts,_=U.prepare(trace,rows,S)
        before=B.identity(B.canonical(contracts));contracts["h"]["span"][0]=0
        self.assertNotEqual(before,B.identity(B.canonical(contracts)))

if __name__=="__main__":unittest.main()
