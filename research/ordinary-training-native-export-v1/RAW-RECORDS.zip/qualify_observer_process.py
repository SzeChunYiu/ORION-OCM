"""Three authorized authored OS-process controls; no actual export or native inputs."""
from pathlib import Path
import hashlib,json,os,sys,time,types
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/"observe_ordinary_export_v1.py"
PYTHON=Path("/home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11")
PIN={"bytes":7363,"sha256":"17cd28c890cabfd3f80e32fcd60d4991e7b5142cbb53c19bfb4e5970a9281fee"}
def ident(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def write(path,obj):
    raw=(json.dumps(obj,sort_keys=True,indent=2)+"\\n").replace("\\\\n","\\n").encode()
    # Use a real newline explicitly to keep synthetic JSON unambiguous.
    raw=json.dumps(obj,sort_keys=True,indent=2).encode()+bytes([10])
    with path.open("xb") as f:f.write(raw)
    return {"path":str(path),**ident(raw)}
def run_case(name,raw):
    folder=ROOT/"observer-pure-controls-01"/name;folder.mkdir(parents=True)
    module=types.ModuleType("reviewed_observer_"+name);module.__file__=str(SOURCE)
    exec(compile(raw,str(SOURCE),"exec"),module.__dict__)
    module.ROOT=folder;module.REQUEST=folder/"REQUEST.json";module.GATE=folder/"GATE.json"
    module.OUTPUT=folder/"output";module.OBSERVATION=folder/"observation"
    child_source=("from pathlib import Path\nimport json,sys,time\n"
        +("time.sleep(20)\n" if name=="raised_wait" else "")
        +"p=Path(sys.argv[2]);p.mkdir()\n"
        +"for n in "+repr(sorted(module.EXPECTED_OUTPUTS))+":\n"
        +" (p/n).write_text(json.dumps({'AUTHORED_PROCESS_CONTROL':True})+'\\n')\n")
    (folder/"trace_export.py").write_text(child_source)
    placeholder=write(folder/"AUTHORED-INPUT.json",{"AUTHORED_ONLY":True,"native":False})
    request={"python":{"path":str(PYTHON),**ident(PYTHON.read_bytes())},
        "sources":{"trace_export.py":ident(child_source.encode())},"gate_path":str(module.GATE)}
    for key in ("verifier","release","registry_scope","authority_contract","observer_contract","P0_contracts","prefix"):
        request[key]=placeholder
    req_pin=write(module.REQUEST,request)
    argv=[str(PYTHON),"-I","-S","-B",str(folder/"trace_export.py"),str(module.REQUEST),str(module.OUTPUT)]
    write(module.GATE,{"authorization":"ROOT_TRAINING_NATIVE_EXPORT_GATE",
        "request":{k:req_pin[k] for k in ("bytes","sha256")},"max_runs":1,"outer_wall_s":180,
        "observer":PIN,"observer_contract":placeholder,"output":str(module.OUTPUT),
        "observation":str(module.OBSERVATION),"argv":argv,"review_bindings":{}})
    real_wait=os.wait4;real_clock=time.perf_counter;cached={};events=[]
    facade=types.SimpleNamespace(**vars(os))
    if name=="raised_wait":
        def wait(pid,options):
            if options==os.WNOHANG and not events:
                events.append("injected_wait_OSError");raise OSError("AUTHORED_WAIT_FAILURE")
            return real_wait(pid,options)
        facade.wait4=wait
    elif name=="timeout_exit_race":
        def wait(pid,options):
            if options==os.WNOHANG:
                events.append("authored_WNOHANG_not_exited");return (0,0,None)
            if pid in cached:
                events.append("return_actual_reap_after_injected_exit_race");return cached.pop(pid)
            return real_wait(pid,options)
        def killpg(pid,sig):
            cached[pid]=real_wait(pid,0)
            events.append("actual_child_reaped_then_injected_ProcessLookupError")
            raise ProcessLookupError("AUTHORED_EXIT_RACE")
        count=[0]
        def clock():
            count[0]+=1
            return real_clock()+(181 if count[0]>=3 else 0)
        facade.wait4=wait;facade.killpg=killpg
        module.time=types.SimpleNamespace(perf_counter=clock,sleep=time.sleep)
    module.os=facade
    before=ident(SOURCE.read_bytes());started=real_clock()
    code=module.run()
    result_path=module.OBSERVATION/"PROCESS.json";result=json.loads(result_path.read_bytes())
    after=ident(SOURCE.read_bytes())
    checks={"source_equal":before==after==PIN,"reaped":result["reaped"],
        "all_inputs_equal":all(result["inputs_unchanged"].values()),"argv":result["argv"]==argv,
        "one_child_pid":type(result["pid"]) is int}
    if name=="clean_exit":
        checks.update(completed=code==0 and result["exit_code"]==0,
            population=result["output_population_ok"],no_errors=not result["read_errors"])
    elif name=="raised_wait":
        checks.update(failed=code==1,child_killed=result["exit_code"]==-9,
            retained_error="AUTHORED_WAIT_FAILURE" in result["read_errors"].get("process",""))
    else:
        checks.update(failed=code==1,timeout=result["timeout"],child_exit_zero=result["exit_code"]==0,
            handled_exit_race="actual_child_reaped_then_injected_ProcessLookupError" in events)
    return {"name":name,"pid":result["pid"],"checks":checks,"passed":all(checks.values()),
        "injections":events,"real_control_wall_s":real_clock()-started,"observer_source_pre":before,
        "observer_source_post":after,"receipt":{"path":str(result_path),**ident(result_path.read_bytes())},
        "cwd":str(folder),"actual_native_or_export_code":False,
        "scope":"AUTHORED_CHILD_ONLY; synthetic timeout clock values are not production cost measurements"}
def main():
    raw=SOURCE.read_bytes();assert ident(raw)==PIN
    assert sys.executable==str(PYTHON) and sys.flags.isolated and sys.flags.no_site and not sys.flags.optimize
    cases=[run_case(name,raw) for name in ("clean_exit","raised_wait","timeout_exit_race")]
    files={str(p.relative_to(ROOT)):ident(p.read_bytes()) for p in sorted((ROOT/"observer-pure-controls-01").rglob("*")) if p.is_file()}
    receipt={"schema":"ordinary.observer-authored-process-controls.v1","pid":os.getpid(),"cwd":os.getcwd(),
        "entry":str(Path(__file__).resolve()),"python":{"path":str(PYTHON),**ident(PYTHON.read_bytes())},
        "observer_source":{"path":str(SOURCE),**PIN},"cases":cases,"passed":all(c["passed"] for c in cases),
        "files":files,"real_native_calls":0,"learner_calls":0,"actual_export_gate_created":False,
        "scope":"Exactly three isolated authored child fixtures; no real release/prefix/request/gate/output read or run"}
    write(ROOT/"OBSERVER-PROCESS-CONTROLS-01.json",receipt)
    print(json.dumps({"passed":receipt["passed"],"cases":[{"name":c["name"],"pid":c["pid"],"passed":c["passed"]} for c in cases]}))
    return 0 if receipt["passed"] else 1
if __name__=="__main__":raise SystemExit(main())
