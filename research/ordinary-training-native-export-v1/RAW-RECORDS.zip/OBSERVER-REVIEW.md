# Observer review

The corrected observer source is accepted for the separately gated run described
in [OBSERVER-CONTRACT-01.json](OBSERVER-CONTRACT-01.json).
Source identity: 7363 bytes, SHA256
17cd28c890cabfd3f80e32fcd60d4991e7b5142cbb53c19bfb4e5970a9281fee.

[Successor review](OBSERVER-SOURCE-REVIEW-02.json) closes three findings retained in
[the historical review](OBSERVER-SOURCE-REVIEW-01.json): exceptional child cleanup,
conflicting custody pins and incomplete output-entry accounting.
The original observer source and reviewed successor bytes are both retained.

Exactly three authorized authored process controls passed: clean exit, injected
wait failure, and simulated timeout/exit race. All three children were reaped.
[Control receipt](OBSERVER-PROCESS-CONTROLS-01.json) records source custody,
child PIDs, errors and each fixture artifact. These used isolated fixture paths
and ordinary authored Python children. They executed no real exporter or verifier.

A real run will launch one OS child. Its two full-prefix native passes and at most
128 fallback proof checks remain internal to that child. Child/outer measured
costs have explicit exclusions and are not lifetime cost.

The source decision does not create a gate or admit native artifacts. Root must
bind the current source, contract and actual request in a fresh gate and launch
the observer without optimization. Any unreaped or failed result remains failure.
