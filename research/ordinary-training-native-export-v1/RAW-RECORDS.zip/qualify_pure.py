"""Run only authored source-contract controls; never imports native/donor/learner."""
import hashlib,importlib,json,os,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def identity(path):
    raw=path.read_bytes();return {"path":str(path),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def main():
    sys.path.insert(0,str(ROOT))
    names=("request_contract","bound_io","packet_export","population","trace_transport",
           "check_request_binding","check_trace_transport")
    before={name:identity(ROOT/(name+".py")) for name in names}
    modules=[importlib.import_module(name) for name in names]
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules[-2:])
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    after={name:identity(Path(sys.modules[name].__file__).resolve()) for name in names}
    forbidden=[n for n in sys.modules if any(x in n for x in ("mmverify","trace_adapter","trace_source","typed_constructor","learner"))]
    receipt={"schema":"ordinary.authored-pure-controls.v1","pid":os.getpid(),"ppid":os.getppid(),
        "cwd":os.getcwd(),"argv":sys.argv,"entry_file":str(Path(__file__).resolve()),
        "python_executable":sys.executable,"isolated":sys.flags.isolated,"no_site":sys.flags.no_site,
        "tests_run":result.testsRun,"errors":len(result.errors),"failures":len(result.failures),
        "pre":before,"post_imported":after,"source_equal":before==after,
        "forbidden_imports":forbidden,"corpus_read":False,"native_calls":0,"learner_calls":0,
        "scope":"AUTHORED_METADATA_AND_PACKET_STRUCTURES_ONLY"}
    with (ROOT/"PURE-QUALIFICATION-01.json").open("x") as f:json.dump(receipt,f,sort_keys=True,indent=2);f.write("\n")
    return 0 if result.wasSuccessful() and before==after and not forbidden else 1
if __name__=="__main__":raise SystemExit(main())
