"""Root binds the one approved exporter request; does not execute it."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('/home/billy/orion-director-work/20260908')
ROOT = BASE / 'ordinary-training-trace-export-v1'


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def descriptor(path):
    return {'path': str(path), **pin(path)}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


request = json.loads((ROOT / 'REQUEST-PROSPECTIVE-01.json').read_bytes())
request_path = ROOT / 'REQUEST-EXECUTION-01.json'
gate_path = ROOT / 'ROOT-EXPORT-GATE-01.json'
observer = BASE / 'observe_ordinary_export_v1.py'
contract_path = ROOT / 'OBSERVER-CONTRACT-01.json'
observer_review_path = ROOT / 'OBSERVER-SOURCE-REVIEW-02.json'
review = json.loads(observer_review_path.read_bytes())
controls = json.loads((ROOT / 'OBSERVER-PROCESS-CONTROLS-01.json').read_bytes())
assert pin(observer_review_path)['sha256'] == '7b5976416108ae683e0dabf2cf0f63367134e1fa8ee94b3332217c4471333fa9'
assert pin(contract_path)['sha256'] == 'c1b89da1311b4158eb571c0f7ba10a352ed5ad531fad19468dd202b179bf90d1'
assert review['remaining_blockers'] == []
assert review['status'] == 'SOURCE_ACCEPTED_WITH_FOCUSED_AUTHORED_PROCESS_CONTROLS'
observer_manifest = json.loads((ROOT / 'OBSERVER-REVIEW-HASHES-01.json').read_bytes())
for name, expected in observer_manifest['files'].items():
    assert pin(ROOT / name) == expected, name
assert pin(observer)['sha256'] == '17cd28c890cabfd3f80e32fcd60d4991e7b5142cbb53c19bfb4e5970a9281fee'
assert pin(ROOT / 'ROOT-SOURCE-ACCEPTANCE-01.json')['sha256'] == 'c753786cb65e9ba6f8967936eee1dab809869fea79bb464d7933567dfc2ee633'
assert controls['passed'] is True
request['observer_contract'] = descriptor(contract_path)
request['gate_path'] = str(gate_path)
assert all(value is not None for value in request.values())
for name, expected in request['sources'].items():
    assert pin(ROOT / name) == expected, name
for key in ('python', 'verifier', 'release', 'prefix', 'registry_scope', 'authority_contract', 'observer_contract', 'P0_contracts'):
    row = request[key]
    assert pin(Path(row['path'])) == {k: row[k] for k in ('bytes', 'sha256')}, key
write(request_path, request)
gate = {
    'schema': 'ordinary.root-native-export-gate.v1',
    'authorization': 'ROOT_TRAINING_NATIVE_EXPORT_GATE',
    'issued_utc': datetime.now(timezone.utc).isoformat(),
    'max_runs': 1, 'outer_wall_s': 180,
    'request': pin(request_path), 'observer': pin(observer),
    'observer_contract': request['observer_contract'],
    'output': str(ROOT / 'native-export-01'), 'observation': str(ROOT / 'native-export-observer-01'),
    'argv': [request['python']['path'], '-I', '-S', '-B', str(ROOT / 'trace_export.py'), str(request_path), str(ROOT / 'native-export-01')],
    'review_bindings': {str(ROOT / name): pin(ROOT / name) for name in (
        'ROOT-SOURCE-ACCEPTANCE-01.json', 'OBSERVER-SOURCE-REVIEW-01.json',
        'OBSERVER-SOURCE-REVIEW-02.json', 'OBSERVER-PROCESS-CONTROLS-01.json',
        'HASHES-02.json', 'SOURCE-REVIEW-REQUEST.json')},
    'scope': 'Once-only fresh verification of the fixed4223-theorem prefix followed by separate trace observation of128 released training roots. New100-assertion authority. Up to128 fallback proof checks. No opportunity census, learner, evaluation, rerun of an old experiment or automatic retry. Artifacts are candidates pending root qualification.',
    'root_review_record': descriptor(observer_review_path),
}
write(gate_path, gate)
print(json.dumps({'request': descriptor(request_path), 'gate': descriptor(gate_path)}))
