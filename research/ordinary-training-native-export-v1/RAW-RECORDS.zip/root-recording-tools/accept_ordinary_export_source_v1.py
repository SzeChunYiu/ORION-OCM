"""Record root's source review; no adapter imports or proof execution."""
import hashlib
import json
from pathlib import Path

BASE = Path('/home/billy/orion-director-work/20260908/ordinary-training-trace-export-v1')


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


manifest_path = BASE / 'HASHES-02.json'
assert pin(manifest_path)['sha256'] == '59eb30b7011e6aa72b2e48cafd260c8b8c30c37fa6d6a17f987235aae13734f9'
manifest = json.loads(manifest_path.read_bytes())
for name, expected in manifest['files'].items():
    assert pin(BASE / name) == expected, name
source = json.loads((BASE / 'SOURCE-REVIEW-REQUEST.json').read_bytes())
pure = json.loads((BASE / 'PURE-QUALIFICATION-01.json').read_bytes())
entry = json.loads((BASE / 'ENTRY-QUALIFICATION-01.json').read_bytes())
assert pure['tests_run'] == 14 and pure['errors'] == pure['failures'] == 0
assert pure['source_equal'] and pure['forbidden_imports'] == []
assert entry['passed'] and all(entry['checks'].values())
assert entry['source_before'] == entry['source_after'] == source['production_sources']
for name, expected in source['production_sources'].items():
    assert pin(BASE / name) == expected
result = {
    'schema': 'ordinary.root-export-source-review.v1',
    'terminal': 'BOUNDED_SOURCE_ACCEPTED_PENDING_OBSERVER_AND_EXECUTION_GATE',
    'manifest': pin(manifest_path), 'verified_manifest_entries': len(manifest['files']),
    'reviewed_production_sources': source['production_sources'],
    'pure_qualification': pin(BASE / 'PURE-QUALIFICATION-01.json'),
    'entry_qualification': pin(BASE / 'ENTRY-QUALIFICATION-01.json'),
    'root_review_findings': [
        'Read all nine production files. Native/source assertions, proof sequence and active contexts are checked against unchanged mmverify; a fresh verification pass precedes separate trace observation.',
        'Full P1 includes all prefix axioms, first4095 ordinary theorems and every released whole training theorem. Unusable trace transport does not remove ordinary parent knowledge.',
        'Trace and used-contract canonical identities include mandatory hypotheses and exact source spans; no ordinary proof body is inserted through used-contract projection.',
        'Fresh100-assertion authority is bound prospectively; old96-assertion proof receipts are not inherited. P0 remains a historical4191-contract artifact, distinct from the enlarged fair comparison base.',
        'Native_calls counts theorem verify invocations in one child, including the second observation pass and any fallback; it does not count OS processes.',
        'A trace observation failure may yield partial/unusable trace dispositions after successful prefix verification; this is explicitly retained, not a proof or learning failure inference.',
    ],
    'scope': 'Existing authored14 controls and actual missing-pin refusal reviewed without rerun. No current native success, useful acquired method, opportunity count, heldout performance or lifetime economy established.',
    'pending': ['Independent observer-source decision and exact contract', 'Concrete bound request and once-only gate', 'Fresh native outcome and independent artifact binding checks'],
    'review_script': pin(Path(__file__).resolve()),
}
target = BASE / 'ROOT-SOURCE-ACCEPTANCE-01.json'
with target.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'path': str(target), **pin(target)}))
