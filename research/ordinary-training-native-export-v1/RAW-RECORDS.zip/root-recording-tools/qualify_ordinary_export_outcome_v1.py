"""Root metadata qualification of completed native output; no proof replay."""
import collections
import hashlib
import json
from pathlib import Path

BASE = Path('/home/billy/orion-director-work/20260908/ordinary-training-trace-export-v1')
OUTPUT = BASE / 'native-export-01'


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def pin(path):
    return identity(path.read_bytes())


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def read(name):
    return json.loads((OUTPUT / name).read_bytes())


outer_path = BASE / 'native-export-observer-01/PROCESS.json'
outer = json.loads(outer_path.read_bytes())
assert outer['terminal'] == 'NATIVE_EXPORT_PROCESS_COMPLETED'
assert outer['pid'] == 2048380 and outer['reaped'] and outer['exit_code'] == 0
assert all(outer['inputs_unchanged'].values()) and outer['read_errors'] == {}
assert outer['output_population_ok'] and not outer['timeout']
for name, expected in outer['outputs'].items():
    assert pin(OUTPUT / name) == expected, name
result = read('RESULT.json')
request_raw = (BASE / 'REQUEST-EXECUTION-01.json').read_bytes()
request = json.loads(request_raw)
assert result['request'] == identity(request_raw)
assert read('REQUEST.json') == request
assert result['sources_before'] == result['sources_after'] == request['sources']
assert result['native_calls'] == 8446 and result['verified_count'] == 4223
assert result['native_error'] is None and result['trace_error'] is None
assert result['learner_calls'] == result['opportunity_calls'] == 0
release = json.loads(Path(request['release']['path']).read_bytes())
authority = read('NATIVE-AUTHORITY.json')
packet = read('TEACHING-PACKET-CANDIDATE.json')
inventory = read('P1-INVENTORY.json')
p0 = read('P0-CONTRACTS.json')
assert pin(OUTPUT / 'P0-CONTRACTS.json') == {k: request['P0_contracts'][k] for k in ('bytes', 'sha256')}
assert authority['verified_labels'] == [x['label'] for x in p0 if x['kind'] == '$p'] + [x['label'] for x in release['roots']]
assert len(authority['verified_labels']) == len(set(authority['verified_labels'])) == 4223
assert authority['terminal'] == 'FRESH_PREFIX_NATIVE_VERIFIED' and not authority['old_native_receipt_inherited']
assert len(inventory['contracts']) == 4323 and len(inventory['released_labels']) == 128
p1 = {x['label']: x for x in inventory['contracts']}
assert len(p1) == 4323 and all(p1[x['label']] == x for x in p0)
assert [{'label': x['contract']['label'], 'raw': x['raw']} for x in authority['axioms']] == release['axiom_identities']
assert len(authority['axioms']) == 100
assert authority['additional_axiom_labels'] == ['csymdif', 'df-symdif', 'c0', 'df-nul']
assert [x['ordinal'] for x in packet['roots']] == list(range(4096, 4224))
assert [x['label'] for x in packet['roots']] == [x['label'] for x in release['roots']]
for row in packet['roots']:
    label = row['label']
    assert row['source_disposition'] == 'RELEASED'
    assert row['whole_contract'] == identity(canonical(p1[label]))
    assert authority['selected_scope_bindings'][label]['contract'] == row['whole_contract']
    assert authority['trace_dispositions'][label]['status'] == row['trace_disposition']
    if row['trace_disposition'] == 'TRACE_READY':
        bindings = authority['trace_bindings'][label]
        assert bindings == {key: identity(canonical(row[key])) for key in ('trace', 'contracts')}
        assert row['trace']['terminal'] == 'NATIVE_VERIFIED'
    else:
        assert row['trace_disposition'] == 'TRACE_UNUSABLE'
        assert row['trace'] is None and row['contracts'] == {}
counts = dict(collections.Counter(x['trace_disposition'] for x in packet['roots']))
assert counts == {'TRACE_READY': 71, 'TRACE_UNUSABLE': 57}
review_root = BASE / 'native-export-independent-review-01'
assert pin(review_root / 'REVIEW.json')['sha256'] == '0d2a6fd43a92246ab0b6d745ac3ba9ab39cd6513f464a8c7621bfb29b748df38'
review = json.loads((review_root / 'REVIEW.json').read_bytes())
assert review['blockers'] == []
assert review['verdict'] == 'QUALIFIED_RETAINED_NATIVE_EXPORT_FOR_ITS_REGISTERED_SCOPE'
review_manifest = json.loads((review_root / 'FILES.json').read_bytes())
for name, expected in review_manifest['files'].items():
    assert pin(review_root / name) == expected, name
review_files = {p.relative_to(review_root).as_posix(): pin(p) for p in review_root.rglob('*') if p.is_file()}
assert review_files, 'independent outcome review required'
qualification = {
    'schema': 'ordinary.root-native-export-outcome.v1',
    'terminal': 'FRESH_NATIVE_TRAINING_EXPORT_QUALIFIED',
    'outer_process': pin(outer_path), 'outputs': outer['outputs'],
    'request': identity(request_raw), 'gate': pin(BASE / 'ROOT-EXPORT-GATE-01.json'),
    'independent_review': review_files, 'verified_theorems': 4223,
    'internal_proof_checks': 8446, 'direct_child_processes': 1,
    'P0_contracts': 4191, 'P1_contracts': 4323, 'released_training_theorems': 128,
    'axiom_declarations': 100, 'trace_dispositions': counts,
    'claim_scope': 'Formal proof validity under the bound assertion inventory and input readiness for the bounded trace interface. No cut opportunity, acquired method, search benefit, language transfer, novelty or lifetime economy established.',
    'gate_status': 'CONSUMED_ONCE_NO_RETRY', 'qualification_script': pin(Path(__file__).resolve()),
    'next': 'Separately bind and execute the previously specified training-only opportunity audit using the frozen consumer-v3; retain UNKNOWN and complete P1. Do not replay native export.',
}
target = BASE / 'ROOT-OUTCOME-QUALIFICATION-01.json'
with target.open('x') as stream:
    json.dump(qualification, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'path': str(target), **pin(target)}))
