"""Package completed native-export evidence without replaying its computation."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

BASE = Path('/home/billy/orion-director-work/20260908')
SOURCE = BASE / 'ordinary-training-trace-export-v1'
WORKTREE = BASE / 'native-typed-lifecycle-publication-v1/worktree'
TARGET = WORKTREE / 'research/ordinary-training-native-export-v1'


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


assert not TARGET.exists()
TARGET.mkdir()
files = sorted(p for p in SOURCE.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
records = {}
with zipfile.ZipFile(TARGET / 'RAW-RECORDS.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        name = path.relative_to(SOURCE).as_posix()
        raw = path.read_bytes()
        records[name] = pin(raw)
        archive.writestr(name, raw)
with zipfile.ZipFile(TARGET / 'RAW-RECORDS.zip') as archive:
    assert sorted(archive.namelist()) == sorted(records)
    for name, expected in records.items():
        assert pin(archive.read(name)) == expected
        assert pin((SOURCE / name).read_bytes()) == expected
write(TARGET / 'RAW-MANIFEST.json', {'schema': 'ordinary.export-publication-raw.v1',
    'source_root': str(SOURCE), 'files': records, 'archive': pin((TARGET / 'RAW-RECORDS.zip').read_bytes()),
    'scope': 'Exact retained source, controls, failed preimages, requests, gates and actual native-export evidence. No computation was replayed for publication.'})
direct = [
    'trace_export.py', 'bound_io.py', 'request_contract.py', 'population.py',
    'native_export.py', 'packet_export.py', 'trace_transport.py',
    'donor/trace_source.py', 'donor/trace_adapter.py',
    'SOURCE-CONTRACT.md', 'ARTIFACT-CONTRACT.md', 'READ-SCOPE.md',
    'SOURCE-REVIEW-REQUEST.json', 'ROOT-SOURCE-ACCEPTANCE-01.json',
    'PURE-QUALIFICATION-01.json', 'ENTRY-QUALIFICATION-01.json',
    'REQUEST-EXECUTION-01.json', 'ROOT-EXPORT-GATE-01.json',
    'NATIVE-AUTHORITY-CONTRACT-01.json', 'OBSERVER-CONTRACT-01.json',
    'OBSERVER-SOURCE-REVIEW-02.json', 'OBSERVER-PROCESS-CONTROLS-01.json',
    'REVIEWED-OBSERVER-SOURCE-02.py', 'native-export-observer-01/PROCESS.json',
    'native-export-01/RESULT.json', 'ROOT-OUTCOME-QUALIFICATION-01.json',
]
review_root = SOURCE / 'native-export-independent-review-01'
assert review_root.is_dir()
direct += [p.relative_to(SOURCE).as_posix() for p in review_root.rglob('*') if p.is_file()]
for name in direct:
    path = TARGET / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE / name, path)
    assert pin(path.read_bytes()) == records[name]
(TARGET / 'CORE.md').write_text('''# Verified native training export

Fresh proof checking completed for all **4,223** theorems in the fixed Metamath
prefix. The new 128 training theorems are retained in full in the ordinary parent.
The bounded trace interface accepts 71 proof traces and marks 57 unusable.
This establishes training input readiness; useful acquired methods remain untested.

- [Outcome and limits](RESULT.md).
- [Root qualification](ROOT-OUTCOME-QUALIFICATION-01.json).
- [Actual child result](native-export-01/RESULT.json) and
  [outer process record](native-export-observer-01/PROCESS.json).
- [Artifact contracts](ARTIFACT-CONTRACT.md) and [source contract](SOURCE-CONTRACT.md).
- [Exact raw archive](RAW-RECORDS.zip), [member identities](RAW-MANIFEST.json).

Raw records include historical source-only notes and failed observer preimages.
Those records retain their original dates/scope; this entry describes the completed
successor. Absolute paths are historical execution bindings, not portable install
instructions. Publication copies exact bytes and does not rerun the study.

The unchanged native verifier supplies formal validity within the explicitly bound
100-assertion prefix. It is not OCM learning or a claim of empirical truth.
The [source release and repaired consumer](../ordinary-cut-source-evidence-v1/CURRENT.md)
remain separate stages. No paper, novelty, speedup or lifetime-benefit claim follows.
''')
(TARGET / 'RESULT.md').write_text('''# Training readiness result

The once-only run completed in one isolated Python child (PID 2048380), with
4,223 fresh proof checks followed by 4,223 checks during trace observation.
Both passes completed without native or observer errors. The 8,446 internal proof
checks are not 8,446 operating-system processes. No learner or opportunity audit ran.

| Recorded quantity | Result |
| --- | ---: |
| Original P0 contracts | 4,191 |
| Original P0 theorems | 4,095 |
| New training theorems, ordinals 4096–4223 | 128 |
| Current prefix assertion declarations | 100 |
| Complete ordinary P1 contracts | 4,323 |
| Traces within current transport interface | 71 |
| Traces outside current transport interface | 57 |

All 128 training theorems remain in P1. Of the 57 unusable traces, 53 exceed the
source/active distinct-variable restriction, three use assertions with distinct-
variable requirements, and one uses a hypothesis outside the mandatory interface.
These are interface restrictions; all their proofs passed native verification.
They cannot support an absence-of-learning-opportunity conclusion.

Four new `$a` declarations are `csymdif`, `df-symdif`, `c0`, and `df-nul`:
syntax/definitions for symmetric difference and the empty set. They are explicitly
bound in the new authority; counting them does not infer four independent axioms.
The old raw prefix bytes remain identical. Old native receipts are not inherited.

The child used 2.896596 seconds elapsed, 2.821098 seconds user CPU, 0.072028 seconds
system CPU and 135,744 KiB peak RSS. Observer entry through post-run hashes took
2.946906 seconds. This excludes preparation, review, observer startup, final receipt
serialization and later qualification. It is neither total lifetime cost nor a
matched speed comparison.

The corpus and 27-record allocation registry were fixed before release. Clearance
is scoped to that declared registry; no universal unseen-session clearance or
fresh held-out evaluation claim is made. This population is training/development.

The next experiment is the already specified bounded proper-cut/ordinary-parent
opportunity audit. Preserve UNKNOWN outside supported typing/DV/resource bounds.
Only a later separately qualified acquisition, fresh-task use and matched-cost
comparison can establish useful learned structure. Extending DV support should
respond to this measured obstruction without changing the recorded population.
''')
manifest_lines = []
for path in sorted(TARGET.rglob('*')):
    if path.is_file():
        manifest_lines.append(pin(path.read_bytes())['sha256'] + '  ' + path.relative_to(TARGET).as_posix())
(TARGET / 'SHA256SUMS').write_text('\n'.join(manifest_lines) + '\n')
print(json.dumps({'target': str(TARGET), 'raw_files': len(records),
    'archive': pin((TARGET / 'RAW-RECORDS.zip').read_bytes()),
    'public_files': len(manifest_lines) + 1, 'manifest': pin((TARGET / 'SHA256SUMS').read_bytes())}))
