# Released metadata binding — prospective request

This addendum follows the source freeze in [CORE](CORE.md). The original template
and all first-freeze receipts remain unchanged.

[REQUEST-PROSPECTIVE-01.json](REQUEST-PROSPECTIVE-01.json) binds the consumed
custody release and its exact closed-prefix identity, the historical complete P0,
the unchanged exporter source, and a newly authored prospective authority contract.
The fresh observer-contract descriptor and export-gate path remain explicitly null.
This request has not launched and cannot pass the entry validator yet.

The release metadata contains all 128 RELEASED roots, ordinals 4096–4223,
ssind through pssdif. It binds 100 axiom declarations. Relative to the original
96-axiom P0, the additional labels are csymdif, df-symdif, c0 and df-nul.
Their exact raw identities appear in [the binding receipt](RELEASE-BINDING-01.json);
all 100 ordered identities are bound in
[NATIVE-AUTHORITY-CONTRACT-01.json](NATIVE-AUTHORITY-CONTRACT-01.json).

Only release metadata and the historical ordinary P0 contracts were read for this
addendum. The prefix body and the new axiom formulas were not read. Label names
do not establish their logical status or independence. A future fresh native
authority must bind their exact formal contracts and all 4223 verified theorems.
No old native receipt qualifies the expanded prefix.

The consumed release gate is not reused. Root source review and a separate new
export gate are required before actual prefix/native access. This remains source
and request preparation, with no native export, cut extraction or learner run.
