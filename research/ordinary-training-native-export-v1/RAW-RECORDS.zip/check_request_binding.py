"""Authored metadata-only controls. Never imports native, trace or learner modules."""
import copy
import unittest
import request_contract as C

def binding(path="/authored/control", digest="a"*64):
    return {"path":path,"bytes":1,"sha256":digest}

def request():
    return {"schema":C.REQUEST_SCHEMA,"ordinals":list(C.ORDINALS),
        "corpus":dict(C.CORPUS),"python":dict(C.PYTHON),"verifier":dict(C.VERIFIER),
        "prefix":binding(),"release":binding(),"registry_scope":binding(),
        "authority_contract":binding(),"observer_contract":binding(),"P0_contracts":binding(),
        "gate_path":"/authored/gate",
        "sources":{n:dict(C.DONORS[n]) if n in C.DONORS else {"bytes":1,"sha256":"a"*64} for n in C.SOURCE_NAMES}}

class RequestControls(unittest.TestCase):
    def test_authored_complete_request(self):
        self.assertEqual(C.validate_request(request()),None)

    def test_missing_actual_release_remains_closed(self):
        for key in ("prefix","release","authority_contract","observer_contract","P0_contracts","gate_path"):
            row=request();row[key]=None
            with self.subTest(key=key),self.assertRaises(ValueError):C.validate_request(row)

    def test_population_no_replacements_and_no_runtime_substitution(self):
        for key in ("ordinals","python","verifier","sources"):
            row=request()
            if key=="ordinals":row[key]=row[key][1:]+[4224]
            elif key=="sources":row[key].pop("donor/trace_adapter.py")
            else:row[key]["sha256"]="b"*64
            with self.subTest(key=key),self.assertRaises(ValueError):C.validate_request(row)

    def test_canonical_whole_contract_digest_is_stable(self):
        a={"label":"authored","kind":"$p","statement":["AUTHORED_ONLY"],"floating":[],"essential":[],"dv":[]}
        b={k:a[k] for k in reversed(a)}
        self.assertEqual(C.identity(C.canonical(a)),C.identity(C.canonical(b)))

    def test_metadata_population_and_excluded_stub_rule(self):
        roots=[{"ordinal":i,"label":"authored_"+str(i),"source_disposition":"RELEASED"} for i in C.ORDINALS]
        rel={"schema":C.RELEASE_SCHEMA,"ordinals":list(C.ORDINALS),"roots":roots,
             "corpus":dict(C.CORPUS),"registry_scope":binding(),"closed_source":{"bytes":1,"sha256":"a"*64}}
        C.validate_release(rel,request())
        for alter in ("duplicate","missing","unknown_disposition"):
            bad=copy.deepcopy(rel)
            if alter=="duplicate":bad["roots"][-1]["label"]=bad["roots"][0]["label"]
            elif alter=="missing":bad["roots"].pop()
            else:bad["roots"][0]["source_disposition"]="PICKED_WINNER"
            with self.subTest(alter=alter),self.assertRaises(ValueError):C.validate_release(bad,request())

    def test_donor_drift_and_float_ordinal_refuse(self):
        row=request();row["sources"]["donor/trace_source.py"]["sha256"]="b"*64
        with self.assertRaises(ValueError):C.validate_request(row)
        row=request();row["ordinals"][0]=4096.0
        with self.assertRaises(ValueError):C.validate_request(row)

    def test_new_authority_must_match_exact_axiom_contract(self):
        req=request();rel={"axiom_identities":[{"label":"AUTHORED_AXIOM","raw":{"bytes":1,"sha256":"a"*64}}]}
        plan={k:req[k] for k in ("release","prefix","registry_scope","corpus","python","verifier")}
        plan.update(schema="ordinary.native-export-authority-contract.v2",authority_id="AUTHORED_ONLY",
                    status="PROSPECTIVE_NEW_AUTHORITY_CONTRACT",axiom_identities=rel["axiom_identities"],
                    proof_ordinal_count=4223,base_policy="ALL_PREFIX_AXIOMS")
        self.assertIsNone(C.validate_authority(plan,req,rel))
        bad=copy.deepcopy(plan);bad["axiom_identities"]=[]
        with self.assertRaises(ValueError):C.validate_authority(bad,req,rel)

    def test_old_native_flags_cannot_replace_new_contract(self):
        with self.assertRaises(ValueError):
            C.validate_authority({"terminal":"NATIVE_VERIFIED","accepted":True},request(),{})

if __name__=="__main__":unittest.main()
