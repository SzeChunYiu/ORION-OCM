"""Exact isolated launch with missing pins; no native/corpus path is authorized."""
import hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def ident(path):
    raw=path.read_bytes();return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def main():
    request_path=ROOT/"SYNTHETIC-MISSING-PINS.json";req=json.loads(request_path.read_bytes())
    out=ROOT/"synthetic-entry-refusal-01"
    before={n:ident(ROOT/n) for n in req["sources"]}
    command=[req["python"]["path"],"-I","-S","-B",str(ROOT/"trace_export.py"),str(request_path),str(out)]
    runtime_before=ident(Path(command[0]))
    child=subprocess.run(command,cwd=ROOT,capture_output=True,check=False,timeout=30)
    (ROOT/"ENTRY-QUALIFICATION-01.stdout.txt").write_bytes(child.stdout)
    (ROOT/"ENTRY-QUALIFICATION-01.stderr.txt").write_bytes(child.stderr)
    result_path=out/"RESULT.json";result=json.loads(result_path.read_bytes())
    after={n:ident(ROOT/n) for n in req["sources"]}
    checks={"refused_exit":child.returncode==1,"refused_terminal":result["terminal"]=="EXPORT_REFUSED_OR_FAILED",
        "missing_pin_error":result["error"]=={"type":"ValueError","message":"missing or malformed binding"},
        "no_gate_read":result["gate_read"] is False,"no_prefix_read":result["prefix_read"] is False,
        "no_native_module":result["native_module_loaded"] is False,"zero_native_calls":result["native_calls"]==0,
        "zero_learner_calls":result["learner_calls"]==0,"source_unchanged":before==after==result["sources_before"]==result["sources_after"],
        "runtime_unchanged":runtime_before==ident(Path(command[0]))=={k:req["python"][k] for k in ("bytes","sha256")},
        "actual_cwd":result["cwd"]==str(ROOT),"actual_entry":result["entry_file"]==str(ROOT/"trace_export.py"),
        "bound_sibling_imports":result["imported_helpers"]=={"bound_io":str(ROOT/"bound_io.py"),"request_contract":str(ROOT/"request_contract.py")}}
    receipt={"schema":"ordinary.isolated-entry-refusal-qualification.v1","parent_pid":os.getpid(),
        "parent_cwd":os.getcwd(),"command":command,"child_pid":result["pid"],"child_cwd":result["cwd"],
        "child_entry":result["entry_file"],"child_imported_helpers":result["imported_helpers"],
        "exit_code":child.returncode,"request":{"path":str(request_path),**ident(request_path)},
        "result":{"path":str(result_path),**ident(result_path)},"source_before":before,"source_after":after,
        "checks":checks,"passed":all(checks.values()),"scope":"ACTUAL_ENTRY_MISSING_PIN_REFUSAL_ONLY"}
    with (ROOT/"ENTRY-QUALIFICATION-01.json").open("x") as f:json.dump(receipt,f,sort_keys=True,indent=2);f.write("\n")
    print(json.dumps({"passed":receipt["passed"],"child_pid":receipt["child_pid"],"checks":checks}))
    return 0 if receipt["passed"] else 1
if __name__=="__main__":raise SystemExit(main())
