# Ordinary training trace export — source capsule

Prepared successor for the fixed 4096–4223 theorem-ordinal population.
This is an isolated, pure-qualified source adapter. Its fresh native path has
not run and its outputs have not been admitted to any learner.

- [Source/request contract](SOURCE-CONTRACT.md): exact inputs, launch and custody.
- [Artifact contract](ARTIFACT-CONTRACT.md): full P1, trace dispositions and authority.
- [Read scope and qualification](READ-SCOPE.md): what was inspected and executed.
- [Request template](REQUEST.template.json): six explicit missing inputs.
- [Source review request](SOURCE-REVIEW-REQUEST.json): frozen review bindings.
- [Hash manifest](HASHES.json): source, controls and retained receipts.

The existing source index, trace observer and mmverify remain unchanged.
A future run verifies every theorem in the exact bound 4223-theorem prefix,
then separately observes released roots. No old native receipt qualifies it.
All prefix axioms require the newly bound authority contract.

Every released whole theorem remains in P1 even when its trace cannot enter the
bounded cut interface. Excluded rows retain only ordinal/label/disposition
metadata in the teaching packet. Unusable traces stay in custodian artifacts.

Fourteen authored pure controls passed. The actual pinned Python isolated entry
refused a synthetic missing-pin request before gate, prefix or native access.
Those controls establish input/transport behavior, not correctness of a corpus
export or opportunity result.

Root must supply exact release, prefix, original P0, new authority contract,
observer contract and gate bindings. The registry descriptor is the lead's
declared 27-record universe; it does not establish clearance across all sessions.
The changing release/consumer lane and this capsule remain separate.
No frozen experiment, native verifier, bridge or learner was executed here.
