from pathlib import Path
import json,sys,time
p=Path(sys.argv[2]);p.mkdir()
for n in ['CUSTODIAN-PROGRESS.jsonl', 'CUSTODIAN-UNUSABLE-TRACES.json', 'NATIVE-AUTHORITY.json', 'P0-CONTRACTS.json', 'P1-INVENTORY.json', 'REQUEST.json', 'RESULT.json', 'TEACHING-PACKET-CANDIDATE.json']:
 (p/n).write_text(json.dumps({'AUTHORED_PROCESS_CONTROL':True})+'\n')
