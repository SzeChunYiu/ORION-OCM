# Separate screening-only successor remains unopened

The prototype is not wired into the frozen screen. Root's next proposed study
keeps all 76 retained proposals in original order, the full 4,323-contract P1,
the existing two-million matcher-state and 60-second soft bounds, and prior costs.
There is no repeated extraction, native verification/export or replacement root.

The successor screen must explicitly catch SyntaxUnknown and mark coverage
incomplete. Only certified nonmembership may cross typed_alias.match as ValueError.
Do not wrap unsupported grammar or resource exceptions back into ValueError.
Grammar construction failure needs a run-level UNKNOWN/refusal record.

One compiled grammar should serve the full fixed screening invocation; count its
complete cold construction and copied contract storage. The prototype records cold
compile wall, parse/emission wall, input tokens, calls and emitted proof labels.
Lark internal chart-state work is not instrumented. Do not report it as zero or
claim sparse execution. Future outer process wall/CPU/RSS and import costs must
remain visible alongside matcher work.

The prototype's checkpoint permits pre/post parse and proof-emission resource
refusal. A running Lark call is not cooperatively interrupted within the parser;
the existing outer containment remains necessary. No new resource setting was
selected from a screening result.

The syntax vector remains bounded at 512 tokens and emitted proofs at 4,096 labels.
Grammar depth comes from finite parsing rather than the old handwritten Boolean
recursion limit; this is an explicit syntax-domain successor, not inherited
qualification of the old parser. Parameter context, native source-node boundary,
two-node cut family and population remain unchanged.

The actual library has been inspected as contract metadata only. None of its
retained proposal expressions has been parsed by the prototype. Actual grammar
compilation/interoperability and any re-screen require separate source review,
exact input/source bindings and root authorization. A parsed syntax witness still
needs exact native qualification before any new native acceptance claim.
