# Other retained interfaces: queued separately

These counts come from the original RESULT, without rerunning or repairing them.

| Stage | Recorded reason | Count |
| --- | --- | ---: |
| Root construction | three mandatory floats | 43 |
| Root construction | floating type/identity | 3 |
| Root construction | stack arity | 7 |
| Root construction | homogeneous parameters | 1 |
| Cut boundary | boundary lacks exactly three mandatory parameters | 2 |
| Exported transport | TRACE_UNUSABLE | 57 |

The 54 root-construction refusals and two cut-boundary refusals are separate
from the 76 early syntax-screen refusals. The 57 unusable traces retain their
whole theorems in P1. Their finer exporter reasons are outside this read scope.

These are inventories, not diagnoses of each distinct mechanism. Root will
sequence any deeper investigation; none is bundled into the syntax prototype.
