# Ordinary screening syntax revival

The original audit remains unresolved: all 76 cut proposals stopped at the
ground-syntax guard, before ordinary matching. This source tranche diagnoses
that interface and supplies a pure syntax prototype. It does not re-screen any
retained proposal or establish a useful learned method.

Read [diagnosis](DIAGNOSIS.md), [mechanism and donor choice](DESIGN.md),
and [qualification](QUALIFICATION.json). Seventeen authored controls passed.
[Remaining boundaries](NEXT.md) describe the separate screening-only successor.
[Other failures](OTHER-FAILURES.md) are recorded without bundled fixes.

The original result and parser/screen sources remain exact copies under original.
The [source freeze](SOURCE-FREEZE.json) binds this candidate. No frozen consumer,
observer, request, gate, population, cut family or original result was changed.
