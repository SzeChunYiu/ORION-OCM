# One failure stage: typed ground syntax

The retained run recorded 17 enumerated roots, 54 root-interface refusals and
57 unusable traces. Its 76 cut proposals all received UNKNOWN at ground_guard:
28 reported wff operator and 48 reported wff type. Two further cuts failed their
boundary-parameter condition. [Exact counts](DIAGNOSIS.json)

The chain is explicit: alias_screen.screen calls typed_alias.ground_guard;
typed_grammar routes all three-class contexts to legacy_class_terms.syntax.
That older parser recognizes only class intersection/union, subset and conjunction.
The retained proposal expressions include additional syntax constructors.
The guard returns before the ordinary-catalogue loop or match function.

The matcher token counter is absent from the retained work dictionary. Zero
matcher entry follows from those 76 early-return results and the source control
flow, rather than from a saved zero-valued counter. No alias absence follows.

This is an operational syntax-coverage restriction. The registered finite cut
population and ordinary P1 remain unchanged. The prototype does not claim to
resolve any of the original 76 results: none was parsed or re-screened.

The syntax-frame source audit found 44 axioms and two syntax theorems, all with
linear mandatory variables and no essential/DV context.
[SYNTAX-SOURCE-INVENTORY.json](SYNTAX-SOURCE-INVENTORY.json) preserves that read.
It is a contract-shape observation, not parser or native execution.
