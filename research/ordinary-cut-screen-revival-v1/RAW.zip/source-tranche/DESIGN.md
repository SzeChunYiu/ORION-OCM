# Contract-derived syntax and reusable parents

Existing body syntax witnesses are useful local evidence, but cannot establish
complete ordinary applicability. A logical output need not have a corresponding
syntax-constructor node, and ordinary matching considers legal composite images
absent from the body. Witness reuse can later avoid repeated work; it is not the
primary completeness argument.

The primary repair derives grammar productions from the admitted ordinary syntax
contracts. Metamath explicitly distinguishes syntax types from logical types,
requires linear syntax-axiom variables without essential/DV context, and handles
type conversions. [Official syntax contract](https://us.metamath.org/mpeuni/mm-j-commands.html)

Metamath-knife already implements this native grammar approach. Its parser uses
native lookahead/type-conversion declarations, so its Rust implementation is not
a direct Python arbitrary-CFG dependency.
[Exact source](https://github.com/metamath/metamath-knife/blob/76fc9f7f39f46f4c43499a0c2bd1402eb8b1cf9a/metamath-rs/src/grammar.rs)

Lark provides the existing Earley recognizer and ambiguity handling.
The adapter uses its basic lexer over unique encoded Metamath tokens, preserving
token boundaries. No observed operator is special-cased.
[Parser documentation](https://lark-parser.readthedocs.io/en/stable/parsers.html)

Lark 1.3.1 is pinned by wheel and all 46 runtime members. Its MIT notice is retained
in donor/lark-runtime/lark-1.3.1.dist-info/licenses/LICENSE. No optional dependencies
are installed. The parser algorithm is reused unchanged.

The compiler accepts declared syntax types, requires every mandatory floating
variable exactly once, and records unsupported frames. Exact productive-type
closure removes rules with no finite ground inhabitants in the current parameter
context. Composite and repeated substitutions for different formal variables
remain legal. Missing/repeated formal syntax variables, essential hypotheses or
DV conditions make coverage incomplete.

Parsing selects one witness; it does not claim unique derivation or minimum proof
cost. Children are emitted in the original mandatory floating order, even when
that differs from expression order. Structural replay checks the exact requested
type and token vector against the same copied contract frames. Nullary syntax
constructors are supported without clearing preceding stack entries.

SYNTAX_PROVED is constructive syntax evidence. Certified nonmembership requires
a complete supported grammar. Unsupported contracts, construction failure,
conversion/replay errors, bounds or resource refusal remain UNKNOWN. SyntaxUnknown
inherits RuntimeError, so the existing matcher's ValueError catch cannot turn it
into a silent negative type result.

The existing typed context is copied unchanged. The replay loop adapts the prior
screen's substitution/type-stack checks; the nullary case is the necessary change.
Existing proof-compression/derived-theorem parents remain the scientific baseline.
No new miner, proof algorithm or novelty claim is introduced.
