"""Isolated exact old helpers; only names changed. No study import."""

def g2_rows_equal(a_rows, b_rows):
    return all(
        a["task"] == b["task"]
        and a["enumeration_attempts"] == b["enumeration_attempts"]
        and a["unique_candidates_checked"] == b["unique_candidates_checked"]
        and tuple(a["program"]) == tuple(b["program"])
        and tuple(a["token_word"]) == tuple(b["token_word"])
        for a, b in zip(a_rows, b_rows)
    )

def g3_rows_equal(a_rows, b_rows):
    return all(
        a["task"] == b["task"]
        and a["enumeration_attempts"] == b["enumeration_attempts"]
        and a["unique_candidates_checked"] == b["unique_candidates_checked"]
        and tuple(a["token_word"]) == tuple(b["token_word"])
        and tuple(a["program"]) == tuple(b["program"])
        and tuple(a["macros_used"]) == tuple(b["macros_used"])
        for a, b in zip(a_rows, b_rows)
    )
