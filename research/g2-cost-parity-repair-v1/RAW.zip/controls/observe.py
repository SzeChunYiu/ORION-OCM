"""Observe one bounded authored helper-control process; never launch a study."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PYTHON = Path("/home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11")
helper = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
if not helper.is_relative_to(ROOT) or not out.is_relative_to(ROOT):
    raise SystemExit("Outside owned repair directory")
out.mkdir()

def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

paths = [helper, HERE / "test_parity.py", Path(__file__).resolve(), PYTHON]
pre = {str(p): identity(p) for p in paths}
argv = [str(PYTHON), "-I", "-S", "-B", str(HERE / "test_parity.py"),
        str(helper), str(out / "CONTROLS.json")]
(out / "START.json").write_text(json.dumps({"argv": argv, "cwd": "/tmp",
    "observer_pid": os.getpid(), "before": pre}, indent=2, sort_keys=True) + "\n")
start = time.perf_counter()
with (out / "stdout.txt").open("xb") as stdout, (out / "stderr.txt").open("xb") as stderr:
    process = subprocess.Popen(argv, cwd="/tmp", stdout=stdout, stderr=stderr)
    pid, status, usage = os.wait4(process.pid, 0)
    process.returncode = os.waitstatus_to_exitcode(status)
wall = time.perf_counter() - start
post = {str(p): identity(p) for p in paths}
record = {"schema": "g2.cost-parity.control-process.v1", "argv": argv, "cwd": "/tmp",
    "observer_pid": os.getpid(), "child_pid": pid, "exit_code": process.returncode,
    "reaped": True, "wall_s": wall, "user_cpu_s": usage.ru_utime,
    "system_cpu_s": usage.ru_stime, "peak_rss_kib": usage.ru_maxrss,
    "before": pre, "after": post, "sources_unchanged": pre == post,
    "outputs": {n: identity(out / n) for n in ("CONTROLS.json", "stdout.txt", "stderr.txt")},
    "scope": "One new authored helper-control set only; no study requalification."}
(out / "PROCESS.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
print(json.dumps({"child_pid": pid, "exit_code": process.returncode, "sources_unchanged": pre == post}))
