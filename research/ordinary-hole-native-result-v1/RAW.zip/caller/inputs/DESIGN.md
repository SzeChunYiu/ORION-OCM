# Native caller: one published argument-hole control

**Source-only candidate. No native, corpus, matcher, constructor, parser or test
execution occurred in this inventory.** Use the accepted two-module adapter
unchanged. The missing component binds an issued request to a native result.

## Concrete allowed control

The published [projection](references/4-PROJECTION.json) contains the admitted
ordinary witness `typed-admitted-0`, canonical body
`3a3edbba45f4bd28ccf7a357a28e1087df380bd2fe151d8d87dc27284fd093a2`.
Its ordered premises are `ph -> ps`, `ps -> ch`; conclusion `ph -> (ps /\ ch)`.
The body is `syl` then `jca`. It is a `jccir` alias with **no eligible learned
method**. Use it only as an alias-witness refactoring control. Its historical
admission flag cannot supply current native authority.

Its exact proof and local hypotheses are in the 234-byte published
[admission suffix](references/6-suffix.mm). The old 4095-theorem prefix plus
one newline plus this suffix has the published identity 1,757,440 bytes,
SHA256 `f25b4351b4b94e152006919a7062f0b0f1a990aabce6d862feee56aa5a0e2cd9`.
This extended prefix has 4096 proved labels and the same 96 axioms.
The future caller must check its bytes and freshly replay its proofs.
The [historical metadata excerpt](references/9-admission-metadata-excerpt.json)
is provenance, not acceptance for a future invocation.

Take route 0 from the published [authored fixtures](references/1-FIXTURES.json).
Define `X = ( ph /\ ps )`, simultaneously instantiate its old `ph` by `X`,
and keep old `ps` and `ch`. Replace each old `wph` proof occurrence with
`wph wps wa`. Replace each first-essential occurrence with
`wph wps simpr`, which proves `|- ( X -> ps )`. Keep the second essential
as one freshly issued hole `|- ( ps -> ch )`. The issued target is
`|- ( X -> ch )`. This is a prospective authored instance, not an old result.

The inner `syl`-then-`jca` occurrence substitutes `V0` by `( ph /\ ps )`,
`V1` by `ps`, and `V2` by `ch`. Its first floating argument is a composite
syntax subtree; its first essential argument is a complete `simpr` derivation.
Parameter images share `ps`. The remaining route uses outer `simpr` and `syl`.
Only the exact five [published contracts](references/2-ASSERTIONS.json) are
needed to author this instance. No fresh theorem catalogue read is needed.
Select the outer `syl`'s first essential port, path `[3]` in its ordered
floating-plus-essential input list. Validate that path against the fresh trace;
refuse a mismatch rather than choose another occurrence.

## Minimal integration: two fresh native calls

1. Bind old prefix, suffix, extended-prefix bytes, wrapper, index, trace adapter,
   verifier, Python, adapter modules and request. Use fresh source/replacement
   labels and separate local hole labels. Keep three wff parameters
   `ph/ps/ch` with `wph/wps/wch`, empty required/active DV, no extra floats,
   the accepted 256-node trace and 4096-label output boundaries.
2. Call unchanged `life_native.verify` on the extended prefix and exact authored
   source claim. This fresh replay checks the witness already in the prefix and
   the source claim together. Require exact selected label, proof population/order,
   trust digest, claims digest, database and source identities. The returned trace
   and exact USED-contract map become the target input.
3. Derive the six-field lemma contract from the current indexed prefix; compare it
   with the published witness sequent. Bind body, recipe contracts, current trace
   and used contracts, parameter context, prefix and fresh native result.
   Call unchanged `hole_match.match` then `replacement.emit_one` on path `[3]`,
   with the exact renaming of the source's single essential hole.
4. Compare emitted target and ordered hypotheses with a separately issued
   replacement request. Check its normal proof in a second `life_native.verify`
   call against the **same extended prefix**. The source target is not added to
   that prefix. Both source and replacement target labels must be absent from the
   replacement proof. Require one `typed-admitted-0` occurrence and bind complete
   emitted proof bytes. Native rejection and inability to check remain distinct.

Two calls suffice: the first replays the witness prefix while qualifying the
source trace; the second independently checks the replacement. Do not put witness
admission and a proof using it in one claims batch: the wrapper refuses references
to any selected claim label. Retain all calls, intermediate records, refusals and
prefix replay costs. This authored starting route is deliberately nonminimal;
no acquisition, later-use, compression advantage or lifetime benefit follows.

## Missing caller boundary and exact limits

`hole_match.validate` checks caller-supplied digests, not native acceptance.
Derive those descriptors from the exact current result and consumed files; bind
the issued query, ordered essentials, type/DV context and proof with before/after
custody. Never treat a saved flag or the adapter's proposal status as acceptance.

Full prefix identity stays separate from target contracts. The lemma-label
collision guard applies to USED pattern/target contracts, not the full library.
Preserve every actually used `$f/$e/$a/$p` entry and span. The proposed original
route does not use `typed-admitted-0`. If its fresh trace does contain that label,
refuse this control; never delete a used entry to bypass the guard.

Reuse `life_native`'s trace transport. `trace_context.validate` documents the
complete used-label set, scoped `$f/$e` membership, source/proof identities and
native-index spans, but its training-authority envelope differs from the wrapper
result schema. Add only an explicit envelope adapter or equivalent caller checks;
do not counterfeit training-export authority or pass full P1 as used contracts.

Minimum new controls: the composite/derived-essential positive above; source or
used-contract pin tamper refused before matching; wrong issued target/hole refused
at its binding/native stage; original-target shortcut refusal. Native negatives
must identify the exact issued pending label after the complete expected prefix.

[INTERFACES.json](INTERFACES.json) binds exact source paths and function ranges.
[SOURCE-READS.json](SOURCE-READS.json) binds the published commit and read/excerpt
scope. No full prefix is copied here. Accepted adapter/history remain untouched.
Concrete caller source, reviewed request and separate execution authorization
remain to be prepared; this source-only design authorizes no experiment.
