# Authored native argument-hole caller

**Source and six authored boundary controls are ready for independent review.
No actual native prefix check has run.** This is one noneligible ordinary
alias-witness control; it supplies no search, acquisition, later-use or benefit claim.

The caller reuses the accepted two-module adapter and unchanged native wrapper,
source index, trace transport and verifier. It checks a source proof, replaces
one fixed occurrence, then checks the exact replacement against the same prefix.
The ordinary witness is typed-admitted-0; it stays outside eligible learned IDs.

- [Fixed source/replacement definition](inputs/DEFINITION.json) specifies the
  30-label source, 21-label replacement, path [3], three wff parameters and no DV.
- [Source request](inputs/NATIVE-SOURCE-REQUEST.json) and
  [replacement request](inputs/NATIVE-REPLACEMENT-REQUEST.json) are exact previews
  of the wrapper envelopes derived by the pinned caller. They are not receipts.
- [Run request](RUN-REQUEST.json) binds sources, input bytes, Python, cwd and
  create-only output. The root gate does not yet exist.
- [Source freeze](SOURCE-FREEZE.json), [origins](SOURCE-ORIGINS.json) and
  [qualified design](inputs/DESIGN.md) make the reuse and interface scope explicit.
- [Qualification](QUALIFICATION.json) links the actual focused-control process
  and complete synthetic input/result records.

The new glue is small: caller_bindings.py checks the current result, issued
claim, complete used-label set, indexed spans and scoped hypotheses;
caller_flow.py uses those bindings around match/emission and two native calls;
run_native.py supplies the create-only root-gated entry and source/input custody.
Full prefix identity and complete USED contracts remain separate. A used lemma
label causes refusal; it is never deleted to pass the adapter's collision guard.

The first native call would freshly replay the old 4095-proof prefix plus the
published alias witness, then the new source claim. The second would use that
same 4096-proof prefix, without adding the source target. Both target labels are
forbidden in the replacement proof. Every call checks the same 96-axiom authority.
The old prefix/suffix identities are provenance until the new checks execute.

The six controls passed once on pinned Python 3.11.14/Linux, PID 2546040:
exact composite/essential arguments and hand-specified proof order; request,
source and used-contract tamper; exact target/hole binding; target shortcuts
and used-lemma collision; negative pending-label/full-prefix attribution; and
missing-gate refusal. The native-call guard stayed at zero.
Their synthetic prefix contains deliberately unverified dummy theorem bodies.
Its NATIVE_VERIFIED-shaped records exercise transport only; no native authority
is claimed for any synthetic record. No old suite was replayed.

[Process receipt](qualification-01/PROCESS.json): 0.081663438 s child wall,
0.073747 s user CPU, 0.003881 s system CPU, 56,396 KiB process highwater RSS.
The 0.377644732 s qualifier window includes source/runtime pinning and readback;
the child is nested in it. Interpreter imports and final qualifier serialization
are outside that window. All 2,027 pre/post pins and 142 actual module paths
reconciled. The receipt retains all six tests and their synthetic observations.

Concrete invocation after an independently reviewed separate root gate:

    cd /tmp
    /home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11 -I -S -B /home/billy/orion-director-work/20260908/ordinary-hole-native-caller-v1/run_native.py /home/billy/orion-director-work/20260908/ordinary-hole-native-caller-v1/RUN-REQUEST.json

Root should observe this once using its existing bounded process/log mechanism,
retain its outer costs and every caller/native artifact, and never retry
automatically. The process main/flow/native windows nest and must not be summed.
The controls qualify the new authored binding boundary, not the future native
result, the actual prefix replay, or the complete production entry's success path.
