# Native argument-hole outcome

[Accepted retained outcome](OUTCOME-REVIEW-01.json): one authored invocation
completed both native checks against the same 4096-proof prefix and 96 axioms.

The fixed occurrence preserves a composite floating proof and derived essential
argument. Its exact supplied proof changes from 30 to 21 labels; the independently
issued replacement passed native verification. Eligible learned methods remain
empty: this is an ordinary alias control, not discovery or demonstrated benefit.

[Counts and cost scopes](OUTCOME-COUNTS-01.json) ·
[Exact bindings](OUTCOME-BINDINGS-01.json) ·
[Accepted source review](IMPLEMENTATION-REVIEW-01.json).

Outer GNU time: 2.46 s wall and 113292 KiB peak RSS. Main, flow and native wrapper
windows are nested. This review read retained records only; nothing was replayed.
