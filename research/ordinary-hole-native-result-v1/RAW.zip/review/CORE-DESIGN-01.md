# Native caller review

The [design review](DESIGN-REVIEW-01.json) accepts the two-call authored boundary.
Implementation and actual execution remain pending.

Both native calls must use the same exact extended prefix. Current result
custody, complete ordered replay and the exact used-contract map qualify the
source trace; a separately issued replacement claim qualifies emitted output.
The ordinary witness remains a jccir alias with no eligible learned method.

This review used source and published authored material only. No target imports,
tests, native calls or unexposed population reads occurred.
[Exact reviewed identities](DESIGN-BINDINGS-01.json).
