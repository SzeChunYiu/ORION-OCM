"""Two externally authorized final-binary profile calls; not the full control matrix."""
from pathlib import Path
from hashlib import sha256
from types import ModuleType
import json,sys,time
SNAP=Path("/home/billy/orion-director-work/20260907/proof-environment-final-runtime-1cf7eca5-20260907T033758")
ROOT=Path(__file__).resolve().parent
REG=Path("/home/billy/orion-director-work/20260907/proof-environment-registration-20260907-v1/case-list.json")
REG_HASH="08c9d831b6ee38ae88624c7393a703991d996352df71b8950e61e9d520c3e0e8"
DESC_HASH="ec84f5c83e4fa667c6b9b458a12b60359a5d17abdd34be4586189f3c117ebdb2"
def record(path):
    h=sha256();size=0
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1048576),b""):h.update(block);size+=len(block)
    return {"path":str(path),"sha256":h.hexdigest(),"bytes":size}
def verify(binding):
    path=Path(binding["path"])
    assert path.resolve(strict=True)==path and record(path)==binding,binding["path"]
    return path
def bound(path,digest):
    raw=path.read_bytes();assert sha256(raw).hexdigest()==digest,path
    return json.loads(raw)
if not sys.flags.isolated or not sys.flags.no_site:raise SystemExit("Use Python -I -S")
if len(sys.argv)!=2 or sys.argv[1] not in ("prepare","check"):raise SystemExit("prepare|check required")
operation=sys.argv[1];started=time.monotonic()
descriptor=bound(SNAP/"PROVISIONAL-MOUNTS.json",DESC_HASH)
seal=bound(SNAP/"STATIC-SEAL.json","b6b182e004d7299e4289e4a6fd778ed51f0f1a9b21e955a94a8258163b162454")
for value in seal["files"].values():verify(value)
for name in ("env_inputs","env_runtime","env_dispatch","env_prepare","env_check"):
    path=SNAP/"driver/proof-environment-v1"/(name+".py");raw=path.read_bytes()
    module=ModuleType(name);module.__file__=str(path);sys.modules[name]=module
    exec(compile(raw,str(path),"exec",dont_inherit=True),module.__dict__)
    module.__ocm_source_sha256__=sha256(raw).hexdigest()
I=sys.modules["env_inputs"];D=sys.modules["env_dispatch"];R=sys.modules["env_runtime"];R.verify_imports()
cases=bound(REG,REG_HASH)["cases"];selected=[case for case in cases if case["id"]=="mutualRecursor"]
assert len(selected)==1;case=selected[0];assert len(case["checks"])==1
freeze=I.bound_json(verify(case["prepare_freeze"]),case["prepare_freeze"]["sha256"])
assert freeze["operation"]=="prepare" and set(freeze["inputs"])==D.OPERATIONS["prepare"]
for value in freeze["inputs"].values():verify(value)
check=case["checks"][0];verify(check["candidate_packet"]);assert check["candidate_root"]==9
run=ROOT/operation;run.mkdir();inputs=run/"inputs";inputs.mkdir();work=run/"work";work.mkdir()
if operation=="prepare":records=freeze["inputs"]
else:
    prepared_path=ROOT/"prepare/profile-result.json";prepared=json.loads(prepared_path.read_bytes())
    assert prepared["terminal"]=="PROFILE_OPERATION_SUPPORTED" and prepared["native"]["terminal"]=="PREPARED"
    assert prepared["descriptor_sha256"]==DESC_HASH and prepared["registration_sha256"]==REG_HASH
    for value in prepared["prepared_outputs"].values():verify(value)
    records={"permitted_packet":prepared["prepared_outputs"]["permitted.ndjson"],
             "target_packet":prepared["prepared_outputs"]["target.ndjson"],
             "registration":prepared["prepared_outputs"]["registration.json"],
             "primitive_packet":prepared["inputs"]["primitive_packet"],"candidate_packet":check["candidate_packet"]}
request={"schema":"ocm.proof-environment.request.v1","operation":operation};copied={};mounts=[]
for role,binding in sorted(records.items()):
    suffix=".json" if role in ("policy","registration") else ".ndjson"
    copied[role]=I.snapshot(binding,inputs/(role+suffix));request[role]="/inputs/"+role+suffix
    mounts.append((copied[role]["path"],request[role]))
if operation=="check":request["candidate_root"]=check["candidate_root"]
request_path=run/"request.json";I.write_json(request_path,request)
runtime_mounts=[(descriptor["executable"]["path"],"/bridge/ocm_environment"),*((x["file"]["path"],x["guest"]) for x in descriptor["libraries"])]
mounts=runtime_mounts+[(str(request_path),"/request/request.json")]+mounts
plan={"operation":operation,"scope":"Exact-final-binary runtime profile; exposed authored mutualRecursor only", "registration":record(REG),"descriptor":record(SNAP/"PROVISIONAL-MOUNTS.json"),"script":record(Path(__file__).resolve()),"python":record(Path(sys.executable).resolve()),"strace":record(Path("/usr/bin/strace")),"request":record(request_path),"inputs":copied,"mounts":[{"source":s,"guest":g} for s,g in mounts],"native_calls":1}
I.write_json(run/"plan.json",plan)
process=R.ISOLATION.run_isolated(["/bridge/ocm_environment","/request/request.json","/work/native"],read_only=mounts,executable_sha256=descriptor["executable"]["sha256"],work_dir=str(work),env={"HOME":"/tmp","LANG":"C.UTF-8","LC_ALL":"C.UTF-8","TMPDIR":"/tmp"},timeout_s=30,max_output_bytes=1048576,bwrap_path=descriptor["bwrap"]["path"],bwrap_sha256=descriptor["bwrap"]["sha256"])
I.write_json(run/"process.json",process)
result={"operation":operation,"terminal":"CANNOT_CHECK","descriptor_sha256":DESC_HASH,"registration_sha256":REG_HASH,"inputs":copied,"native":None,"prepared_outputs":{},"scope":"One runtime profile operation, not final47-control commissioning"}
try:
    for value in seal["files"].values():verify(value)
    for value in copied.values():verify(value)
    for value in records.values():verify(value)
    verify(plan["registration"]);verify(plan["request"]);R.verify_imports()
    if operation=="check":
        for value in prepared["prepared_outputs"].values():verify(value)
    native=D.native_result(process,work/"native",operation)
    expected=case["prepare_expected"] if operation=="prepare" else check["expected"]
    assert native["terminal"]==expected["terminal"] and native["stage"]==expected["stage"],native
    assert expected["reason_contains"] in native["reason"]
    result.update(terminal="PROFILE_OPERATION_SUPPORTED",native=native,prepared_outputs={p.name:record(p) for p in (work/"native").iterdir() if p.is_file()})
except Exception as exc:result["error"]=type(exc).__name__+": "+str(exc)
result["wall_through_validation_s"]=time.monotonic()-started
I.write_json(run/"profile-result.json",result)
print(json.dumps({"operation":operation,"terminal":result["terminal"],"native":result["native"],"process_terminal":process["terminal"],"returncode":process["returncode"],"cleanup":process["cleanup"],"stderr":process["stderr"]}))
raise SystemExit(0 if result["terminal"]=="PROFILE_OPERATION_SUPPORTED" else 2)
