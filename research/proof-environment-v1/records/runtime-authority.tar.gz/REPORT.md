# Qualified native runtime package

The fixed serving runtime is ready for the registered 47-control commissioning. This receipt qualifies packaging and two runtime-profile operations; it does not record that commissioning as complete.

- Runtime: `../proof-environment-qualified-runtime-20260907-v1/runtime.json`
- Runtime SHA256: `c9acc789908a216809a509facfc06c5aaf02206197fbc2f9f1531d3ae1c6d4e8`
- Canonical host Python: `/home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11`, invoked with `-I -S`.
- Final generic ELF SHA256: `1cf7eca5b692a2783fb95b7256b9836f2c0ab080b33463e86eba0cacfed19fe4`, 121,492,112 bytes.
- Current root driver verified the published runtime without another native execution.
- Package is read-only: 50 files, 125,285,768 retained bytes. `PACKAGE-SEAL.json` binds every file.

## Audit authority

`PROFILE-AUDIT.json` states the exact scope and limitations. `LINK-IMPORT-ELF-AUDIT.json` binds the three external audit assertions to the binary, six libraries, bubblewrap and build/source record. The packager preserves this authority; it does not derive closure from filenames or hashes alone.

Static snapshot: `../proof-environment-final-runtime-1cf7eca5-20260907T033758/`. Its `STATIC-SEAL.json` SHA256 is `b6b182e004d7299e4289e4a6fd778ed51f0f1a9b21e955a94a8258163b162454`. Its pending-profile descriptor remains unchanged, superseded by this qualified package.

The actual checker link response has 18 local objects and 17 transitive local imports, no local fixture object, no plugin and no dynamic import library. Source hashes match the retained successful build and reviewed native handoff `39d6ad412bb78e59abb252a3045a564be42655f2789119a9b19ed5643fafec51`. Generic Lean/Std/Init/Lake implementation remains trusted linked code; absence of fixture caches alone is not evidence that a binary is fixture-free.

All seven ELF objects have no RPATH/RUNPATH. Recursive DT_NEEDED closure and GNU version requirements resolve in the registered six library files. Guest library paths are:

- `/lib64/ld-linux-x86-64.so.2`
- `/lib/x86_64-linux-gnu/libc.so.6`
- `/lib/x86_64-linux-gnu/libpthread.so.0`
- `/lib/x86_64-linux-gnu/libdl.so.2`
- `/lib/x86_64-linux-gnu/librt.so.1`
- `/lib/x86_64-linux-gnu/libm.so.6`

Checker: `/bridge/ocm_environment`. These seven ELF files total 124,940,456 bytes. Bubblewrap is a separately pinned host launcher. Custody source/build records are never guest mounts; no worktree, full toolchain, fixture .olean cache or full export directory is mounted.

## Observed profile

Exactly two authorized operations ran for exposed `mutualRecursor` in case-list SHA256 `08c9d831b6ee38ae88624c7393a703991d996352df71b8950e61e9d520c3e0e8`:

| Operation | Native terminal | Observed work | Script wall through validation |
|---|---|---|---:|
| prepare | PREPARED | 27 replayed declarations; 100 dependency edges; 414 source declarations | 0.953741033 s |
| check | KERNEL_PASS | 27 replayed declarations; 27 candidate constants touched; no axioms reported | 0.606238627 s |

Both isolated envelopes completed with return code 0, empty stderr, no truncation, and reaped/absent process groups. Check consumes newly prepared outputs. These are runtime-profile observations, not a generated proof, learned structure, hidden-region result, or final matrix score.

Raw evidence: `../proof-environment-final-profile-20260907-v1/`, inventoried by `PROFILE-SEAL.json`: 41 files, 3,998,517 bytes. This includes exact mount/invocation plans, input copies, process envelopes, native outputs, host logs and twelve strace files. Native main/workers were distinguished from host Python and bubblewrap; namespace-local PIDs were not treated as host trace IDs.

Tracing selected file/process syscalls. Successful native reads used fixed code/request/input/work paths plus permitted `/proc/sys/vm/overcommit_memory`, `/proc/version_signature`, `/proc/stat`, and `/dev/urandom`. Loader cache/preload/hwcaps probes and selected /sys probes failed. No successful unregistered code, source, fixture, or cache load was observed. This does not assert absence of OS information, all-syscall confinement, arbitrary-input behavior, or a neural-free development host.

Check outer strace returned 0 with wall 0.635382519 s. Prepare outer tracer exit/timing were not separately retained; its traced Python exits 0 and complete native/cleanup evidence is retained. This limitation did not trigger a rerun.

## Costs and history

Sequential profile scripts total 1.559979660 s through validation. Inner isolation measurements (0.643115808 s and 0.300036853 s) overlap those script times and must not be added. CPU/RSS were not measured. Human audit, package wall, and complete lifetime cost are not inferred.

Static snapshot retains 134,449,709 bytes. Prior work is preserved: 27 selected toolchain files (422,409,600 bytes) and existing release archive (570,405,234 bytes) were rehashed, not downloaded again. The archive and prior 18,129-entry release inventory remain historical inputs, not a new complete toolchain build qualification. Development probes and native author controls retain separate provenance.

`PACKAGE-REQUEST.json` SHA256 `61c4aa558cef8f152d702a015e12ab797fb5df24a7d4ddc603721f2ea755348a` drove the reviewed create-only packager. `package.stdout` binds the runtime/receipt; `package.stderr` is empty. Copied packager and current driver sources were checked again. No native source/binary modification, build, or extra native call occurred during packaging.

Next: root binds this runtime to the registered matrix and performs fresh 47-control commissioning. Scientific reconstruction, actual corpus semantic adequacy, FLT stages, transfer, acquisition and novelty remain separate gates.
