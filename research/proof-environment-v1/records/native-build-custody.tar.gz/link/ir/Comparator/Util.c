// Lean compiler output
// Module: Comparator.Util
// Imports: public import Init public meta import Init public import Lean.Environment
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_ConstantInfo_name(lean_object*);
lean_object* l_Lean_Expr_getUsedConstants(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
lean_object* l_Lean_ConstantInfo_value_x3f(lean_object*, uint8_t);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
lean_object* l_List_forM___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__5(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__0(lean_object* v_f_1_, lean_object* v_x_2_, lean_object* v___y_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_apply_1(v_f_1_, v___y_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__2(lean_object* v_rhs_5_, lean_object* v___x_6_, lean_object* v_toApplicative_7_, lean_object* v_inst_8_, lean_object* v___f_9_, lean_object* v_____r_10_){
_start:
{
lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; uint8_t v___x_14_; 
v___x_11_ = l_Lean_Expr_getUsedConstants(v_rhs_5_);
v___x_12_ = lean_array_get_size(v___x_11_);
v___x_13_ = lean_box(0);
v___x_14_ = lean_nat_dec_lt(v___x_6_, v___x_12_);
if (v___x_14_ == 0)
{
lean_object* v_toPure_15_; lean_object* v___x_16_; 
lean_dec_ref(v___x_11_);
lean_dec(v___f_9_);
lean_dec_ref(v_inst_8_);
v_toPure_15_ = lean_ctor_get(v_toApplicative_7_, 1);
lean_inc(v_toPure_15_);
lean_dec_ref(v_toApplicative_7_);
v___x_16_ = lean_apply_2(v_toPure_15_, lean_box(0), v___x_13_);
return v___x_16_;
}
else
{
uint8_t v___x_17_; 
v___x_17_ = lean_nat_dec_le(v___x_12_, v___x_12_);
if (v___x_17_ == 0)
{
if (v___x_14_ == 0)
{
lean_object* v_toPure_18_; lean_object* v___x_19_; 
lean_dec_ref(v___x_11_);
lean_dec(v___f_9_);
lean_dec_ref(v_inst_8_);
v_toPure_18_ = lean_ctor_get(v_toApplicative_7_, 1);
lean_inc(v_toPure_18_);
lean_dec_ref(v_toApplicative_7_);
v___x_19_ = lean_apply_2(v_toPure_18_, lean_box(0), v___x_13_);
return v___x_19_;
}
else
{
size_t v___x_20_; size_t v___x_21_; lean_object* v___x_22_; 
lean_dec_ref(v_toApplicative_7_);
v___x_20_ = ((size_t)0ULL);
v___x_21_ = lean_usize_of_nat(v___x_12_);
v___x_22_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v_inst_8_, v___f_9_, v___x_11_, v___x_20_, v___x_21_, v___x_13_);
return v___x_22_;
}
}
else
{
size_t v___x_23_; size_t v___x_24_; lean_object* v___x_25_; 
lean_dec_ref(v_toApplicative_7_);
v___x_23_ = ((size_t)0ULL);
v___x_24_ = lean_usize_of_nat(v___x_12_);
v___x_25_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v_inst_8_, v___f_9_, v___x_11_, v___x_23_, v___x_24_, v___x_13_);
return v___x_25_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__2___boxed(lean_object* v_rhs_26_, lean_object* v___x_27_, lean_object* v_toApplicative_28_, lean_object* v_inst_29_, lean_object* v___f_30_, lean_object* v_____r_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__2(v_rhs_26_, v___x_27_, v_toApplicative_28_, v_inst_29_, v___f_30_, v_____r_31_);
lean_dec(v___x_27_);
return v_res_32_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__1(lean_object* v___x_33_, lean_object* v_toApplicative_34_, lean_object* v_inst_35_, lean_object* v___f_36_, lean_object* v_f_37_, lean_object* v_toBind_38_, lean_object* v_rule_39_){
_start:
{
lean_object* v_ctor_40_; lean_object* v_rhs_41_; lean_object* v___f_42_; lean_object* v___x_43_; lean_object* v___x_44_; 
v_ctor_40_ = lean_ctor_get(v_rule_39_, 0);
lean_inc(v_ctor_40_);
v_rhs_41_ = lean_ctor_get(v_rule_39_, 2);
lean_inc_ref(v_rhs_41_);
lean_dec_ref(v_rule_39_);
v___f_42_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__2___boxed), 6, 5);
lean_closure_set(v___f_42_, 0, v_rhs_41_);
lean_closure_set(v___f_42_, 1, v___x_33_);
lean_closure_set(v___f_42_, 2, v_toApplicative_34_);
lean_closure_set(v___f_42_, 3, v_inst_35_);
lean_closure_set(v___f_42_, 4, v___f_36_);
v___x_43_ = lean_apply_1(v_f_37_, v_ctor_40_);
v___x_44_ = lean_apply_4(v_toBind_38_, lean_box(0), lean_box(0), v___x_43_, v___f_42_);
return v___x_44_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__3(lean_object* v_inst_45_, lean_object* v_all_46_, lean_object* v_f_47_, lean_object* v_____r_48_){
_start:
{
lean_object* v___x_49_; 
v___x_49_ = l_List_forM___redArg(v_inst_45_, v_all_46_, v_f_47_);
return v___x_49_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__4(lean_object* v_info_50_, lean_object* v_inst_51_, lean_object* v_f_52_, lean_object* v_toBind_53_, lean_object* v___f_54_, lean_object* v_toPure_55_, lean_object* v_____r_56_){
_start:
{
switch(lean_obj_tag(v_info_50_))
{
case 5:
{
lean_object* v_val_57_; lean_object* v_all_58_; lean_object* v_ctors_59_; lean_object* v___f_60_; lean_object* v___x_61_; lean_object* v___x_62_; 
lean_dec(v_toPure_55_);
lean_dec(v___f_54_);
v_val_57_ = lean_ctor_get(v_info_50_, 0);
lean_inc_ref(v_val_57_);
lean_dec_ref_known(v_info_50_, 1);
v_all_58_ = lean_ctor_get(v_val_57_, 3);
lean_inc(v_all_58_);
v_ctors_59_ = lean_ctor_get(v_val_57_, 4);
lean_inc(v_ctors_59_);
lean_dec_ref(v_val_57_);
lean_inc(v_f_52_);
lean_inc_ref(v_inst_51_);
v___f_60_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__3), 4, 3);
lean_closure_set(v___f_60_, 0, v_inst_51_);
lean_closure_set(v___f_60_, 1, v_all_58_);
lean_closure_set(v___f_60_, 2, v_f_52_);
v___x_61_ = l_List_forM___redArg(v_inst_51_, v_ctors_59_, v_f_52_);
v___x_62_ = lean_apply_4(v_toBind_53_, lean_box(0), lean_box(0), v___x_61_, v___f_60_);
return v___x_62_;
}
case 6:
{
lean_object* v_val_63_; lean_object* v_induct_64_; lean_object* v___x_65_; 
lean_dec(v_toPure_55_);
lean_dec(v___f_54_);
lean_dec(v_toBind_53_);
lean_dec_ref(v_inst_51_);
v_val_63_ = lean_ctor_get(v_info_50_, 0);
lean_inc_ref(v_val_63_);
lean_dec_ref_known(v_info_50_, 1);
v_induct_64_ = lean_ctor_get(v_val_63_, 1);
lean_inc(v_induct_64_);
lean_dec_ref(v_val_63_);
v___x_65_ = lean_apply_1(v_f_52_, v_induct_64_);
return v___x_65_;
}
case 7:
{
lean_object* v_val_66_; lean_object* v_rules_67_; lean_object* v___x_68_; 
lean_dec(v_toPure_55_);
lean_dec(v_toBind_53_);
lean_dec(v_f_52_);
v_val_66_ = lean_ctor_get(v_info_50_, 0);
lean_inc_ref(v_val_66_);
lean_dec_ref_known(v_info_50_, 1);
v_rules_67_ = lean_ctor_get(v_val_66_, 6);
lean_inc(v_rules_67_);
lean_dec_ref(v_val_66_);
v___x_68_ = l_List_forM___redArg(v_inst_51_, v_rules_67_, v___f_54_);
return v___x_68_;
}
default: 
{
lean_object* v___x_69_; lean_object* v___x_70_; 
lean_dec(v___f_54_);
lean_dec(v_toBind_53_);
lean_dec(v_f_52_);
lean_dec_ref(v_inst_51_);
lean_dec_ref(v_info_50_);
v___x_69_ = lean_box(0);
v___x_70_ = lean_apply_2(v_toPure_55_, lean_box(0), v___x_69_);
return v___x_70_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__5(lean_object* v___f_71_, lean_object* v_____r_72_){
_start:
{
lean_object* v___x_73_; 
v___x_73_ = lean_apply_1(v___f_71_, v_____r_72_);
return v___x_73_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__6(lean_object* v_info_74_, lean_object* v___x_75_, lean_object* v_toPure_76_, lean_object* v_toBind_77_, lean_object* v___f_78_, lean_object* v_inst_79_, lean_object* v___f_80_, lean_object* v___f_81_, lean_object* v_____r_82_){
_start:
{
uint8_t v___x_83_; lean_object* v___x_84_; 
v___x_83_ = 1;
v___x_84_ = l_Lean_ConstantInfo_value_x3f(v_info_74_, v___x_83_);
if (lean_obj_tag(v___x_84_) == 1)
{
lean_object* v_val_85_; lean_object* v___x_86_; lean_object* v___x_87_; lean_object* v___x_88_; uint8_t v___x_89_; 
lean_dec(v___f_81_);
v_val_85_ = lean_ctor_get(v___x_84_, 0);
lean_inc(v_val_85_);
lean_dec_ref_known(v___x_84_, 1);
v___x_86_ = l_Lean_Expr_getUsedConstants(v_val_85_);
v___x_87_ = lean_array_get_size(v___x_86_);
v___x_88_ = lean_box(0);
v___x_89_ = lean_nat_dec_lt(v___x_75_, v___x_87_);
if (v___x_89_ == 0)
{
lean_object* v___x_90_; lean_object* v___x_91_; 
lean_dec_ref(v___x_86_);
lean_dec(v___f_80_);
lean_dec_ref(v_inst_79_);
v___x_90_ = lean_apply_2(v_toPure_76_, lean_box(0), v___x_88_);
v___x_91_ = lean_apply_4(v_toBind_77_, lean_box(0), lean_box(0), v___x_90_, v___f_78_);
return v___x_91_;
}
else
{
uint8_t v___x_92_; 
v___x_92_ = lean_nat_dec_le(v___x_87_, v___x_87_);
if (v___x_92_ == 0)
{
if (v___x_89_ == 0)
{
lean_object* v___x_93_; lean_object* v___x_94_; 
lean_dec_ref(v___x_86_);
lean_dec(v___f_80_);
lean_dec_ref(v_inst_79_);
v___x_93_ = lean_apply_2(v_toPure_76_, lean_box(0), v___x_88_);
v___x_94_ = lean_apply_4(v_toBind_77_, lean_box(0), lean_box(0), v___x_93_, v___f_78_);
return v___x_94_;
}
else
{
size_t v___x_95_; size_t v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; 
lean_dec(v_toPure_76_);
v___x_95_ = ((size_t)0ULL);
v___x_96_ = lean_usize_of_nat(v___x_87_);
v___x_97_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v_inst_79_, v___f_80_, v___x_86_, v___x_95_, v___x_96_, v___x_88_);
v___x_98_ = lean_apply_4(v_toBind_77_, lean_box(0), lean_box(0), v___x_97_, v___f_78_);
return v___x_98_;
}
}
else
{
size_t v___x_99_; size_t v___x_100_; lean_object* v___x_101_; lean_object* v___x_102_; 
lean_dec(v_toPure_76_);
v___x_99_ = ((size_t)0ULL);
v___x_100_ = lean_usize_of_nat(v___x_87_);
v___x_101_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v_inst_79_, v___f_80_, v___x_86_, v___x_99_, v___x_100_, v___x_88_);
v___x_102_ = lean_apply_4(v_toBind_77_, lean_box(0), lean_box(0), v___x_101_, v___f_78_);
return v___x_102_;
}
}
}
else
{
lean_object* v___x_103_; lean_object* v___x_104_; 
lean_dec(v___x_84_);
lean_dec(v___f_80_);
lean_dec_ref(v_inst_79_);
lean_dec(v___f_78_);
lean_dec(v_toBind_77_);
lean_dec(v_toPure_76_);
v___x_103_ = lean_box(0);
v___x_104_ = lean_apply_1(v___f_81_, v___x_103_);
return v___x_104_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__6___boxed(lean_object* v_info_105_, lean_object* v___x_106_, lean_object* v_toPure_107_, lean_object* v_toBind_108_, lean_object* v___f_109_, lean_object* v_inst_110_, lean_object* v___f_111_, lean_object* v___f_112_, lean_object* v_____r_113_){
_start:
{
lean_object* v_res_114_; 
v_res_114_ = lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__6(v_info_105_, v___x_106_, v_toPure_107_, v_toBind_108_, v___f_109_, v_inst_110_, v___f_111_, v___f_112_, v_____r_113_);
lean_dec(v___x_106_);
return v_res_114_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__7(lean_object* v_info_115_, lean_object* v_f_116_, lean_object* v_toBind_117_, lean_object* v___f_118_, lean_object* v_____r_119_){
_start:
{
lean_object* v___x_120_; lean_object* v___x_121_; lean_object* v___x_122_; 
v___x_120_ = l_Lean_ConstantInfo_name(v_info_115_);
v___x_121_ = lean_apply_1(v_f_116_, v___x_120_);
v___x_122_ = lean_apply_4(v_toBind_117_, lean_box(0), lean_box(0), v___x_121_, v___f_118_);
return v___x_122_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__7___boxed(lean_object* v_info_123_, lean_object* v_f_124_, lean_object* v_toBind_125_, lean_object* v___f_126_, lean_object* v_____r_127_){
_start:
{
lean_object* v_res_128_; 
v_res_128_ = lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__7(v_info_123_, v_f_124_, v_toBind_125_, v___f_126_, v_____r_127_);
lean_dec_ref(v_info_123_);
return v_res_128_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___redArg(lean_object* v_inst_129_, lean_object* v_info_130_, lean_object* v_f_131_){
_start:
{
lean_object* v_toApplicative_132_; lean_object* v_toBind_133_; lean_object* v___f_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___f_138_; lean_object* v___y_140_; lean_object* v___x_147_; lean_object* v___x_148_; uint8_t v___x_149_; 
v_toApplicative_132_ = lean_ctor_get(v_inst_129_, 0);
v_toBind_133_ = lean_ctor_get(v_inst_129_, 1);
lean_inc_n(v_toBind_133_, 2);
lean_inc_n(v_f_131_, 2);
v___f_134_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__0), 3, 1);
lean_closure_set(v___f_134_, 0, v_f_131_);
v___x_135_ = l_Lean_ConstantInfo_type(v_info_130_);
v___x_136_ = l_Lean_Expr_getUsedConstants(v___x_135_);
v___x_137_ = lean_unsigned_to_nat(0u);
lean_inc_ref(v___f_134_);
lean_inc_ref(v_inst_129_);
lean_inc_ref(v_toApplicative_132_);
v___f_138_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__1), 7, 6);
lean_closure_set(v___f_138_, 0, v___x_137_);
lean_closure_set(v___f_138_, 1, v_toApplicative_132_);
lean_closure_set(v___f_138_, 2, v_inst_129_);
lean_closure_set(v___f_138_, 3, v___f_134_);
lean_closure_set(v___f_138_, 4, v_f_131_);
lean_closure_set(v___f_138_, 5, v_toBind_133_);
v___x_147_ = lean_array_get_size(v___x_136_);
v___x_148_ = lean_box(0);
v___x_149_ = lean_nat_dec_lt(v___x_137_, v___x_147_);
if (v___x_149_ == 0)
{
lean_object* v_toPure_150_; lean_object* v___x_151_; 
lean_dec_ref(v___x_136_);
v_toPure_150_ = lean_ctor_get(v_toApplicative_132_, 1);
lean_inc(v_toPure_150_);
v___x_151_ = lean_apply_2(v_toPure_150_, lean_box(0), v___x_148_);
v___y_140_ = v___x_151_;
goto v___jp_139_;
}
else
{
uint8_t v___x_152_; 
v___x_152_ = lean_nat_dec_le(v___x_147_, v___x_147_);
if (v___x_152_ == 0)
{
if (v___x_149_ == 0)
{
lean_object* v_toPure_153_; lean_object* v___x_154_; 
lean_dec_ref(v___x_136_);
v_toPure_153_ = lean_ctor_get(v_toApplicative_132_, 1);
lean_inc(v_toPure_153_);
v___x_154_ = lean_apply_2(v_toPure_153_, lean_box(0), v___x_148_);
v___y_140_ = v___x_154_;
goto v___jp_139_;
}
else
{
size_t v___x_155_; size_t v___x_156_; lean_object* v___x_157_; 
v___x_155_ = ((size_t)0ULL);
v___x_156_ = lean_usize_of_nat(v___x_147_);
lean_inc_ref(v___f_134_);
lean_inc_ref(v_inst_129_);
v___x_157_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v_inst_129_, v___f_134_, v___x_136_, v___x_155_, v___x_156_, v___x_148_);
v___y_140_ = v___x_157_;
goto v___jp_139_;
}
}
else
{
size_t v___x_158_; size_t v___x_159_; lean_object* v___x_160_; 
v___x_158_ = ((size_t)0ULL);
v___x_159_ = lean_usize_of_nat(v___x_147_);
lean_inc_ref(v___f_134_);
lean_inc_ref(v_inst_129_);
v___x_160_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v_inst_129_, v___f_134_, v___x_136_, v___x_158_, v___x_159_, v___x_148_);
v___y_140_ = v___x_160_;
goto v___jp_139_;
}
}
v___jp_139_:
{
lean_object* v_toPure_141_; lean_object* v___f_142_; lean_object* v___f_143_; lean_object* v___f_144_; lean_object* v___f_145_; lean_object* v___x_146_; 
v_toPure_141_ = lean_ctor_get(v_toApplicative_132_, 1);
lean_inc_n(v_toPure_141_, 2);
lean_inc_n(v_toBind_133_, 3);
lean_inc(v_f_131_);
lean_inc_ref(v_inst_129_);
lean_inc_ref_n(v_info_130_, 2);
v___f_142_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__4), 7, 6);
lean_closure_set(v___f_142_, 0, v_info_130_);
lean_closure_set(v___f_142_, 1, v_inst_129_);
lean_closure_set(v___f_142_, 2, v_f_131_);
lean_closure_set(v___f_142_, 3, v_toBind_133_);
lean_closure_set(v___f_142_, 4, v___f_138_);
lean_closure_set(v___f_142_, 5, v_toPure_141_);
lean_inc_ref(v___f_142_);
v___f_143_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__5), 2, 1);
lean_closure_set(v___f_143_, 0, v___f_142_);
v___f_144_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__6___boxed), 9, 8);
lean_closure_set(v___f_144_, 0, v_info_130_);
lean_closure_set(v___f_144_, 1, v___x_137_);
lean_closure_set(v___f_144_, 2, v_toPure_141_);
lean_closure_set(v___f_144_, 3, v_toBind_133_);
lean_closure_set(v___f_144_, 4, v___f_143_);
lean_closure_set(v___f_144_, 5, v_inst_129_);
lean_closure_set(v___f_144_, 6, v___f_134_);
lean_closure_set(v___f_144_, 7, v___f_142_);
v___f_145_ = lean_alloc_closure((void*)(lp_proofEnvironment_Comparator_runForUsedConsts___redArg___lam__7___boxed), 5, 4);
lean_closure_set(v___f_145_, 0, v_info_130_);
lean_closure_set(v___f_145_, 1, v_f_131_);
lean_closure_set(v___f_145_, 2, v_toBind_133_);
lean_closure_set(v___f_145_, 3, v___f_144_);
v___x_146_ = lean_apply_4(v_toBind_133_, lean_box(0), lean_box(0), v___y_140_, v___f_145_);
return v___x_146_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts(lean_object* v_m_161_, lean_object* v_inst_162_, lean_object* v_info_163_, lean_object* v_f_164_){
_start:
{
lean_object* v___x_165_; 
v___x_165_ = lp_proofEnvironment_Comparator_runForUsedConsts___redArg(v_inst_162_, v_info_163_, v_f_164_);
return v___x_165_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Lean_Environment(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_Comparator_Util(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Environment(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
