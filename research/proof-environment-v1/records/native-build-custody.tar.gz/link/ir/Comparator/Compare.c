// Lean compiler output
// Module: Comparator.Compare
// Imports: public import Init public meta import Init public import Comparator.Axioms public import Export.Parse
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t l_Lean_instBEqConstantVal_beq(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t l_List_beq___at___00Lean_Environment_AddConstAsyncResult_commitConst_spec__0(lean_object*, lean_object*);
uint8_t l_Lean_instBEqAxiomVal_beq(lean_object*, lean_object*);
uint8_t l_Lean_instBEqDefinitionVal_beq(lean_object*, lean_object*);
uint8_t l_Lean_instBEqTheoremVal_beq(lean_object*, lean_object*);
uint8_t l_Lean_instBEqOpaqueVal_beq(lean_object*, lean_object*);
lean_object* l_Lean_QuotKind_ctorIdx(uint8_t);
uint8_t l_Lean_instBEqConstructorVal_beq(lean_object*, lean_object*);
uint8_t l_Lean_instBEqRecursorVal_beq(lean_object*, lean_object*);
lean_object* l_Lean_Expr_getUsedConstants(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_mk_array(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(lean_object*, lean_object*);
uint8_t l_Lean_instBEqDefinitionSafety_beq(uint8_t, uint8_t);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_finalizeImport_spec__5___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_pop(lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
lean_object* l_Lean_ConstantInfo_name(lean_object*);
lean_object* l_Lean_ConstantInfo_value_x3f(lean_object*, uint8_t);
size_t lean_array_size(lean_object*);
lean_object* l_Array_append___redArg(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator___closed__0_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator___closed__0_value;
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator___closed__0_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator___closed__0_value;
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator___closed__0_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator___closed__0_value;
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator___closed__0_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addWorklist___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addWorklist(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addWorklist___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___lam__0___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + sizeof(size_t)*1, .m_other = 0, .m_tag = 0}, .m_objs = {(lean_object*)(size_t)(0ULL)}};
LEAN_EXPORT const lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed__const__1 = (const lean_object*)&lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed__const__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_Compare_addRelevantConsts___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_Compare_addWorklist___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Comparator_Compare_addRelevantConsts___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_addRelevantConsts___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addRelevantConsts(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addRelevantConsts___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Comparator_Compare_loop___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 52, .m_capacity = 52, .m_length = 51, .m_data = "Const does not match between challenge and target '"};
static const lean_object* lp_proofEnvironment_Comparator_Compare_loop___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_loop___closed__0_value;
static const lean_string_object lp_proofEnvironment_Comparator_Compare_loop___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "'"};
static const lean_object* lp_proofEnvironment_Comparator_Compare_loop___closed__1 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_loop___closed__1_value;
static const lean_string_object lp_proofEnvironment_Comparator_Compare_loop___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "Const not found in solution '"};
static const lean_object* lp_proofEnvironment_Comparator_Compare_loop___closed__2 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_loop___closed__2_value;
static const lean_string_object lp_proofEnvironment_Comparator_Compare_loop___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "Const not found in challenge '"};
static const lean_object* lp_proofEnvironment_Comparator_Compare_loop___closed__3 = (const lean_object*)&lp_proofEnvironment_Comparator_Compare_loop___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_loop(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_loop___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_definitionHoleMatches(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_definitionHoleMatches___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 52, .m_capacity = 52, .m_length = 51, .m_data = "Challenge and solution constant kind don't match: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 57, .m_capacity = 57, .m_length = 56, .m_data = "Challenge and solution theorem statement do not match: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "Const not found in solution: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "Const not found in challenge: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 41, .m_capacity = 41, .m_length = 40, .m_data = "Solution constant is not a definition: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 42, .m_capacity = 42, .m_length = 41, .m_data = "Challenge constant is not a definition: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_Comparator_compareAt___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Comparator_compareAt___closed__0;
static lean_once_cell_t lp_proofEnvironment_Comparator_compareAt___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Comparator_compareAt___closed__1;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_compareAt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_compareAt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq(uint8_t v_x_1_, uint8_t v_y_2_){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; uint8_t v___x_5_; 
v___x_3_ = l_Lean_QuotKind_ctorIdx(v_x_1_);
v___x_4_ = l_Lean_QuotKind_ctorIdx(v_y_2_);
v___x_5_ = lean_nat_dec_eq(v___x_3_, v___x_4_);
lean_dec(v___x_4_);
lean_dec(v___x_3_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq___boxed(lean_object* v_x_6_, lean_object* v_y_7_){
_start:
{
uint8_t v_x_17__boxed_8_; uint8_t v_y_18__boxed_9_; uint8_t v_res_10_; lean_object* v_r_11_; 
v_x_17__boxed_8_ = lean_unbox(v_x_6_);
v_y_18__boxed_9_ = lean_unbox(v_y_7_);
v_res_10_ = lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq(v_x_17__boxed_8_, v_y_18__boxed_9_);
v_r_11_ = lean_box(v_res_10_);
return v_r_11_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq(lean_object* v_x_14_, lean_object* v_x_15_){
_start:
{
lean_object* v_toConstantVal_16_; uint8_t v_kind_17_; lean_object* v_toConstantVal_18_; uint8_t v_kind_19_; uint8_t v___x_20_; 
v_toConstantVal_16_ = lean_ctor_get(v_x_14_, 0);
v_kind_17_ = lean_ctor_get_uint8(v_x_14_, sizeof(void*)*1);
v_toConstantVal_18_ = lean_ctor_get(v_x_15_, 0);
v_kind_19_ = lean_ctor_get_uint8(v_x_15_, sizeof(void*)*1);
v___x_20_ = l_Lean_instBEqConstantVal_beq(v_toConstantVal_16_, v_toConstantVal_18_);
if (v___x_20_ == 0)
{
return v___x_20_;
}
else
{
uint8_t v___x_21_; 
v___x_21_ = lp_proofEnvironment_Comparator_Compare_instBEqQuotKind__comparator_beq(v_kind_17_, v_kind_19_);
return v___x_21_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq___boxed(lean_object* v_x_22_, lean_object* v_x_23_){
_start:
{
uint8_t v_res_24_; lean_object* v_r_25_; 
v_res_24_ = lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq(v_x_22_, v_x_23_);
lean_dec_ref(v_x_23_);
lean_dec_ref(v_x_22_);
v_r_25_ = lean_box(v_res_24_);
return v_r_25_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq(lean_object* v_x_28_, lean_object* v_x_29_){
_start:
{
lean_object* v_toConstantVal_30_; lean_object* v_numParams_31_; lean_object* v_numIndices_32_; lean_object* v_all_33_; lean_object* v_ctors_34_; lean_object* v_numNested_35_; uint8_t v_isRec_36_; uint8_t v_isUnsafe_37_; uint8_t v_isReflexive_38_; lean_object* v_toConstantVal_39_; lean_object* v_numParams_40_; lean_object* v_numIndices_41_; lean_object* v_all_42_; lean_object* v_ctors_43_; lean_object* v_numNested_44_; uint8_t v_isRec_45_; uint8_t v_isUnsafe_46_; uint8_t v_isReflexive_47_; uint8_t v___y_49_; uint8_t v___y_51_; uint8_t v___x_52_; 
v_toConstantVal_30_ = lean_ctor_get(v_x_28_, 0);
v_numParams_31_ = lean_ctor_get(v_x_28_, 1);
v_numIndices_32_ = lean_ctor_get(v_x_28_, 2);
v_all_33_ = lean_ctor_get(v_x_28_, 3);
v_ctors_34_ = lean_ctor_get(v_x_28_, 4);
v_numNested_35_ = lean_ctor_get(v_x_28_, 5);
v_isRec_36_ = lean_ctor_get_uint8(v_x_28_, sizeof(void*)*6);
v_isUnsafe_37_ = lean_ctor_get_uint8(v_x_28_, sizeof(void*)*6 + 1);
v_isReflexive_38_ = lean_ctor_get_uint8(v_x_28_, sizeof(void*)*6 + 2);
v_toConstantVal_39_ = lean_ctor_get(v_x_29_, 0);
v_numParams_40_ = lean_ctor_get(v_x_29_, 1);
v_numIndices_41_ = lean_ctor_get(v_x_29_, 2);
v_all_42_ = lean_ctor_get(v_x_29_, 3);
v_ctors_43_ = lean_ctor_get(v_x_29_, 4);
v_numNested_44_ = lean_ctor_get(v_x_29_, 5);
v_isRec_45_ = lean_ctor_get_uint8(v_x_29_, sizeof(void*)*6);
v_isUnsafe_46_ = lean_ctor_get_uint8(v_x_29_, sizeof(void*)*6 + 1);
v_isReflexive_47_ = lean_ctor_get_uint8(v_x_29_, sizeof(void*)*6 + 2);
v___x_52_ = l_Lean_instBEqConstantVal_beq(v_toConstantVal_30_, v_toConstantVal_39_);
if (v___x_52_ == 0)
{
return v___x_52_;
}
else
{
uint8_t v___x_53_; 
v___x_53_ = lean_nat_dec_eq(v_numParams_31_, v_numParams_40_);
if (v___x_53_ == 0)
{
return v___x_53_;
}
else
{
uint8_t v___x_54_; 
v___x_54_ = lean_nat_dec_eq(v_numIndices_32_, v_numIndices_41_);
if (v___x_54_ == 0)
{
return v___x_54_;
}
else
{
uint8_t v___x_55_; 
v___x_55_ = l_List_beq___at___00Lean_Environment_AddConstAsyncResult_commitConst_spec__0(v_all_33_, v_all_42_);
if (v___x_55_ == 0)
{
return v___x_55_;
}
else
{
uint8_t v___x_56_; 
v___x_56_ = l_List_beq___at___00Lean_Environment_AddConstAsyncResult_commitConst_spec__0(v_ctors_34_, v_ctors_43_);
if (v___x_56_ == 0)
{
return v___x_56_;
}
else
{
uint8_t v___x_57_; 
v___x_57_ = lean_nat_dec_eq(v_numNested_35_, v_numNested_44_);
if (v___x_57_ == 0)
{
return v___x_57_;
}
else
{
if (v_isRec_36_ == 0)
{
if (v_isRec_45_ == 0)
{
v___y_51_ = v___x_57_;
goto v___jp_50_;
}
else
{
return v_isRec_36_;
}
}
else
{
v___y_51_ = v_isRec_45_;
goto v___jp_50_;
}
}
}
}
}
}
}
v___jp_48_:
{
if (v_isReflexive_38_ == 0)
{
if (v_isReflexive_47_ == 0)
{
return v___y_49_;
}
else
{
return v_isReflexive_38_;
}
}
else
{
return v_isReflexive_47_;
}
}
v___jp_50_:
{
if (v___y_51_ == 0)
{
return v___y_51_;
}
else
{
if (v_isUnsafe_37_ == 0)
{
if (v_isUnsafe_46_ == 0)
{
v___y_49_ = v___y_51_;
goto v___jp_48_;
}
else
{
return v_isUnsafe_37_;
}
}
else
{
if (v_isUnsafe_46_ == 0)
{
return v_isUnsafe_46_;
}
else
{
v___y_49_ = v_isUnsafe_46_;
goto v___jp_48_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq___boxed(lean_object* v_x_58_, lean_object* v_x_59_){
_start:
{
uint8_t v_res_60_; lean_object* v_r_61_; 
v_res_60_ = lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq(v_x_58_, v_x_59_);
lean_dec_ref(v_x_59_);
lean_dec_ref(v_x_58_);
v_r_61_ = lean_box(v_res_60_);
return v_r_61_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(lean_object* v_x_64_, lean_object* v_x_65_){
_start:
{
switch(lean_obj_tag(v_x_64_))
{
case 0:
{
if (lean_obj_tag(v_x_65_) == 0)
{
lean_object* v_val_66_; lean_object* v_val_67_; uint8_t v___x_68_; 
v_val_66_ = lean_ctor_get(v_x_64_, 0);
v_val_67_ = lean_ctor_get(v_x_65_, 0);
v___x_68_ = l_Lean_instBEqAxiomVal_beq(v_val_66_, v_val_67_);
return v___x_68_;
}
else
{
uint8_t v___x_69_; 
v___x_69_ = 0;
return v___x_69_;
}
}
case 1:
{
if (lean_obj_tag(v_x_65_) == 1)
{
lean_object* v_val_70_; lean_object* v_val_71_; uint8_t v___x_72_; 
v_val_70_ = lean_ctor_get(v_x_64_, 0);
v_val_71_ = lean_ctor_get(v_x_65_, 0);
v___x_72_ = l_Lean_instBEqDefinitionVal_beq(v_val_70_, v_val_71_);
return v___x_72_;
}
else
{
uint8_t v___x_73_; 
v___x_73_ = 0;
return v___x_73_;
}
}
case 2:
{
if (lean_obj_tag(v_x_65_) == 2)
{
lean_object* v_val_74_; lean_object* v_val_75_; uint8_t v___x_76_; 
v_val_74_ = lean_ctor_get(v_x_64_, 0);
v_val_75_ = lean_ctor_get(v_x_65_, 0);
v___x_76_ = l_Lean_instBEqTheoremVal_beq(v_val_74_, v_val_75_);
return v___x_76_;
}
else
{
uint8_t v___x_77_; 
v___x_77_ = 0;
return v___x_77_;
}
}
case 3:
{
if (lean_obj_tag(v_x_65_) == 3)
{
lean_object* v_val_78_; lean_object* v_val_79_; uint8_t v___x_80_; 
v_val_78_ = lean_ctor_get(v_x_64_, 0);
v_val_79_ = lean_ctor_get(v_x_65_, 0);
v___x_80_ = l_Lean_instBEqOpaqueVal_beq(v_val_78_, v_val_79_);
return v___x_80_;
}
else
{
uint8_t v___x_81_; 
v___x_81_ = 0;
return v___x_81_;
}
}
case 4:
{
if (lean_obj_tag(v_x_65_) == 4)
{
lean_object* v_val_82_; lean_object* v_val_83_; uint8_t v___x_84_; 
v_val_82_ = lean_ctor_get(v_x_64_, 0);
v_val_83_ = lean_ctor_get(v_x_65_, 0);
v___x_84_ = lp_proofEnvironment_Comparator_Compare_instBEqQuotVal__comparator_beq(v_val_82_, v_val_83_);
return v___x_84_;
}
else
{
uint8_t v___x_85_; 
v___x_85_ = 0;
return v___x_85_;
}
}
case 5:
{
if (lean_obj_tag(v_x_65_) == 5)
{
lean_object* v_val_86_; lean_object* v_val_87_; uint8_t v___x_88_; 
v_val_86_ = lean_ctor_get(v_x_64_, 0);
v_val_87_ = lean_ctor_get(v_x_65_, 0);
v___x_88_ = lp_proofEnvironment_Comparator_Compare_instBEqInductiveVal__comparator_beq(v_val_86_, v_val_87_);
return v___x_88_;
}
else
{
uint8_t v___x_89_; 
v___x_89_ = 0;
return v___x_89_;
}
}
case 6:
{
if (lean_obj_tag(v_x_65_) == 6)
{
lean_object* v_val_90_; lean_object* v_val_91_; uint8_t v___x_92_; 
v_val_90_ = lean_ctor_get(v_x_64_, 0);
v_val_91_ = lean_ctor_get(v_x_65_, 0);
v___x_92_ = l_Lean_instBEqConstructorVal_beq(v_val_90_, v_val_91_);
return v___x_92_;
}
else
{
uint8_t v___x_93_; 
v___x_93_ = 0;
return v___x_93_;
}
}
default: 
{
if (lean_obj_tag(v_x_65_) == 7)
{
lean_object* v_val_94_; lean_object* v_val_95_; uint8_t v___x_96_; 
v_val_94_ = lean_ctor_get(v_x_64_, 0);
v_val_95_ = lean_ctor_get(v_x_65_, 0);
v___x_96_ = l_Lean_instBEqRecursorVal_beq(v_val_94_, v_val_95_);
return v___x_96_;
}
else
{
uint8_t v___x_97_; 
v___x_97_ = 0;
return v___x_97_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq___boxed(lean_object* v_x_98_, lean_object* v_x_99_){
_start:
{
uint8_t v_res_100_; lean_object* v_r_101_; 
v_res_100_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_x_98_, v_x_99_);
lean_dec_ref(v_x_99_);
lean_dec_ref(v_x_98_);
v_r_101_ = lean_box(v_res_100_);
return v_r_101_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addWorklist___redArg(lean_object* v_n_104_, lean_object* v_a_105_){
_start:
{
lean_object* v_worklist_106_; lean_object* v_checked_107_; uint8_t v___x_108_; 
v_worklist_106_ = lean_ctor_get(v_a_105_, 0);
v_checked_107_ = lean_ctor_get(v_a_105_, 1);
v___x_108_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_checked_107_, v_n_104_);
if (v___x_108_ == 0)
{
lean_object* v___x_110_; uint8_t v_isShared_111_; uint8_t v_isSharedCheck_119_; 
lean_inc_ref(v_checked_107_);
lean_inc_ref(v_worklist_106_);
v_isSharedCheck_119_ = !lean_is_exclusive(v_a_105_);
if (v_isSharedCheck_119_ == 0)
{
lean_object* v_unused_120_; lean_object* v_unused_121_; 
v_unused_120_ = lean_ctor_get(v_a_105_, 1);
lean_dec(v_unused_120_);
v_unused_121_ = lean_ctor_get(v_a_105_, 0);
lean_dec(v_unused_121_);
v___x_110_ = v_a_105_;
v_isShared_111_ = v_isSharedCheck_119_;
goto v_resetjp_109_;
}
else
{
lean_dec(v_a_105_);
v___x_110_ = lean_box(0);
v_isShared_111_ = v_isSharedCheck_119_;
goto v_resetjp_109_;
}
v_resetjp_109_:
{
lean_object* v___x_112_; lean_object* v___x_113_; lean_object* v___x_115_; 
v___x_112_ = lean_box(0);
v___x_113_ = lean_array_push(v_worklist_106_, v_n_104_);
if (v_isShared_111_ == 0)
{
lean_ctor_set(v___x_110_, 0, v___x_113_);
v___x_115_ = v___x_110_;
goto v_reusejp_114_;
}
else
{
lean_object* v_reuseFailAlloc_118_; 
v_reuseFailAlloc_118_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_118_, 0, v___x_113_);
lean_ctor_set(v_reuseFailAlloc_118_, 1, v_checked_107_);
v___x_115_ = v_reuseFailAlloc_118_;
goto v_reusejp_114_;
}
v_reusejp_114_:
{
lean_object* v___x_116_; lean_object* v___x_117_; 
v___x_116_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_116_, 0, v___x_112_);
lean_ctor_set(v___x_116_, 1, v___x_115_);
v___x_117_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_117_, 0, v___x_116_);
return v___x_117_;
}
}
}
else
{
lean_object* v___x_122_; lean_object* v___x_123_; lean_object* v___x_124_; 
lean_dec(v_n_104_);
v___x_122_ = lean_box(0);
v___x_123_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_123_, 0, v___x_122_);
lean_ctor_set(v___x_123_, 1, v_a_105_);
v___x_124_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_124_, 0, v___x_123_);
return v___x_124_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addWorklist(lean_object* v_n_125_, lean_object* v_a_126_, lean_object* v_a_127_){
_start:
{
lean_object* v___x_128_; 
v___x_128_ = lp_proofEnvironment_Comparator_Compare_addWorklist___redArg(v_n_125_, v_a_127_);
return v___x_128_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addWorklist___boxed(lean_object* v_n_129_, lean_object* v_a_130_, lean_object* v_a_131_){
_start:
{
lean_object* v_res_132_; 
v_res_132_ = lp_proofEnvironment_Comparator_Compare_addWorklist(v_n_129_, v_a_130_, v_a_131_);
lean_dec_ref(v_a_130_);
return v_res_132_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___lam__0(lean_object* v___x_133_, lean_object* v___y_134_, lean_object* v___y_135_){
_start:
{
lean_object* v___x_136_; lean_object* v___x_137_; 
v___x_136_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_136_, 0, v___x_133_);
lean_ctor_set(v___x_136_, 1, v___y_135_);
v___x_137_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_137_, 0, v___x_136_);
return v___x_137_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___lam__0___boxed(lean_object* v___x_138_, lean_object* v___y_139_, lean_object* v___y_140_){
_start:
{
lean_object* v_res_141_; 
v_res_141_ = lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___lam__0(v___x_138_, v___y_139_, v___y_140_);
lean_dec_ref(v___y_139_);
return v_res_141_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(lean_object* v_f_142_, lean_object* v_as_143_, size_t v_i_144_, size_t v_stop_145_, lean_object* v_b_146_, lean_object* v___y_147_, lean_object* v___y_148_){
_start:
{
uint8_t v___x_149_; 
v___x_149_ = lean_usize_dec_eq(v_i_144_, v_stop_145_);
if (v___x_149_ == 0)
{
lean_object* v___x_150_; lean_object* v___x_151_; 
v___x_150_ = lean_array_uget_borrowed(v_as_143_, v_i_144_);
lean_inc_ref(v_f_142_);
lean_inc_ref(v___y_147_);
lean_inc(v___x_150_);
v___x_151_ = lean_apply_3(v_f_142_, v___x_150_, v___y_147_, v___y_148_);
if (lean_obj_tag(v___x_151_) == 0)
{
lean_dec_ref(v_f_142_);
return v___x_151_;
}
else
{
lean_object* v_a_152_; lean_object* v_fst_153_; lean_object* v_snd_154_; size_t v___x_155_; size_t v___x_156_; 
v_a_152_ = lean_ctor_get(v___x_151_, 0);
lean_inc(v_a_152_);
lean_dec_ref_known(v___x_151_, 1);
v_fst_153_ = lean_ctor_get(v_a_152_, 0);
lean_inc(v_fst_153_);
v_snd_154_ = lean_ctor_get(v_a_152_, 1);
lean_inc(v_snd_154_);
lean_dec(v_a_152_);
v___x_155_ = ((size_t)1ULL);
v___x_156_ = lean_usize_add(v_i_144_, v___x_155_);
v_i_144_ = v___x_156_;
v_b_146_ = v_fst_153_;
v___y_148_ = v_snd_154_;
goto _start;
}
}
else
{
lean_object* v___x_158_; lean_object* v___x_159_; 
lean_dec_ref(v_f_142_);
v___x_158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_158_, 0, v_b_146_);
lean_ctor_set(v___x_158_, 1, v___y_148_);
v___x_159_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_159_, 0, v___x_158_);
return v___x_159_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0___boxed(lean_object* v_f_160_, lean_object* v_as_161_, lean_object* v_i_162_, lean_object* v_stop_163_, lean_object* v_b_164_, lean_object* v___y_165_, lean_object* v___y_166_){
_start:
{
size_t v_i_boxed_167_; size_t v_stop_boxed_168_; lean_object* v_res_169_; 
v_i_boxed_167_ = lean_unbox_usize(v_i_162_);
lean_dec(v_i_162_);
v_stop_boxed_168_ = lean_unbox_usize(v_stop_163_);
lean_dec(v_stop_163_);
v_res_169_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(v_f_160_, v_as_161_, v_i_boxed_167_, v_stop_boxed_168_, v_b_164_, v___y_165_, v___y_166_);
lean_dec_ref(v___y_165_);
lean_dec_ref(v_as_161_);
return v_res_169_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__2(lean_object* v_f_170_, lean_object* v_as_171_, lean_object* v___y_172_, lean_object* v___y_173_){
_start:
{
if (lean_obj_tag(v_as_171_) == 0)
{
lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; 
lean_dec_ref(v_f_170_);
v___x_174_ = lean_box(0);
v___x_175_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_175_, 0, v___x_174_);
lean_ctor_set(v___x_175_, 1, v___y_173_);
v___x_176_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_176_, 0, v___x_175_);
return v___x_176_;
}
else
{
lean_object* v_head_177_; lean_object* v_tail_178_; lean_object* v___y_180_; lean_object* v_ctor_184_; lean_object* v_rhs_185_; lean_object* v___x_186_; 
v_head_177_ = lean_ctor_get(v_as_171_, 0);
lean_inc(v_head_177_);
v_tail_178_ = lean_ctor_get(v_as_171_, 1);
lean_inc(v_tail_178_);
lean_dec_ref_known(v_as_171_, 2);
v_ctor_184_ = lean_ctor_get(v_head_177_, 0);
lean_inc(v_ctor_184_);
v_rhs_185_ = lean_ctor_get(v_head_177_, 2);
lean_inc_ref(v_rhs_185_);
lean_dec(v_head_177_);
lean_inc_ref(v_f_170_);
lean_inc_ref(v___y_172_);
v___x_186_ = lean_apply_3(v_f_170_, v_ctor_184_, v___y_172_, v___y_173_);
if (lean_obj_tag(v___x_186_) == 0)
{
lean_dec_ref(v_rhs_185_);
lean_dec(v_tail_178_);
lean_dec_ref(v_f_170_);
return v___x_186_;
}
else
{
lean_object* v_a_187_; lean_object* v_snd_188_; lean_object* v___x_189_; lean_object* v___x_190_; lean_object* v___x_191_; uint8_t v___x_192_; 
v_a_187_ = lean_ctor_get(v___x_186_, 0);
lean_inc(v_a_187_);
lean_dec_ref_known(v___x_186_, 1);
v_snd_188_ = lean_ctor_get(v_a_187_, 1);
lean_inc(v_snd_188_);
lean_dec(v_a_187_);
v___x_189_ = lean_unsigned_to_nat(0u);
v___x_190_ = l_Lean_Expr_getUsedConstants(v_rhs_185_);
v___x_191_ = lean_array_get_size(v___x_190_);
v___x_192_ = lean_nat_dec_lt(v___x_189_, v___x_191_);
if (v___x_192_ == 0)
{
lean_dec_ref(v___x_190_);
v_as_171_ = v_tail_178_;
v___y_173_ = v_snd_188_;
goto _start;
}
else
{
lean_object* v___x_194_; uint8_t v___x_195_; 
v___x_194_ = lean_box(0);
v___x_195_ = lean_nat_dec_le(v___x_191_, v___x_191_);
if (v___x_195_ == 0)
{
if (v___x_192_ == 0)
{
lean_dec_ref(v___x_190_);
v_as_171_ = v_tail_178_;
v___y_173_ = v_snd_188_;
goto _start;
}
else
{
size_t v___x_197_; size_t v___x_198_; lean_object* v___x_199_; 
v___x_197_ = ((size_t)0ULL);
v___x_198_ = lean_usize_of_nat(v___x_191_);
lean_inc_ref(v_f_170_);
v___x_199_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(v_f_170_, v___x_190_, v___x_197_, v___x_198_, v___x_194_, v___y_172_, v_snd_188_);
lean_dec_ref(v___x_190_);
v___y_180_ = v___x_199_;
goto v___jp_179_;
}
}
else
{
size_t v___x_200_; size_t v___x_201_; lean_object* v___x_202_; 
v___x_200_ = ((size_t)0ULL);
v___x_201_ = lean_usize_of_nat(v___x_191_);
lean_inc_ref(v_f_170_);
v___x_202_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(v_f_170_, v___x_190_, v___x_200_, v___x_201_, v___x_194_, v___y_172_, v_snd_188_);
lean_dec_ref(v___x_190_);
v___y_180_ = v___x_202_;
goto v___jp_179_;
}
}
}
v___jp_179_:
{
if (lean_obj_tag(v___y_180_) == 0)
{
lean_dec(v_tail_178_);
lean_dec_ref(v_f_170_);
return v___y_180_;
}
else
{
lean_object* v_a_181_; lean_object* v_snd_182_; 
v_a_181_ = lean_ctor_get(v___y_180_, 0);
lean_inc(v_a_181_);
lean_dec_ref_known(v___y_180_, 1);
v_snd_182_ = lean_ctor_get(v_a_181_, 1);
lean_inc(v_snd_182_);
lean_dec(v_a_181_);
v_as_171_ = v_tail_178_;
v___y_173_ = v_snd_182_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__2___boxed(lean_object* v_f_203_, lean_object* v_as_204_, lean_object* v___y_205_, lean_object* v___y_206_){
_start:
{
lean_object* v_res_207_; 
v_res_207_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__2(v_f_203_, v_as_204_, v___y_205_, v___y_206_);
lean_dec_ref(v___y_205_);
return v_res_207_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1(lean_object* v_f_208_, lean_object* v_as_209_, lean_object* v___y_210_, lean_object* v___y_211_){
_start:
{
if (lean_obj_tag(v_as_209_) == 0)
{
lean_object* v___x_212_; lean_object* v___x_213_; lean_object* v___x_214_; 
lean_dec_ref(v_f_208_);
v___x_212_ = lean_box(0);
v___x_213_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_213_, 0, v___x_212_);
lean_ctor_set(v___x_213_, 1, v___y_211_);
v___x_214_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_214_, 0, v___x_213_);
return v___x_214_;
}
else
{
lean_object* v_head_215_; lean_object* v_tail_216_; lean_object* v___x_217_; 
v_head_215_ = lean_ctor_get(v_as_209_, 0);
lean_inc(v_head_215_);
v_tail_216_ = lean_ctor_get(v_as_209_, 1);
lean_inc(v_tail_216_);
lean_dec_ref_known(v_as_209_, 2);
lean_inc_ref(v_f_208_);
lean_inc_ref(v___y_210_);
v___x_217_ = lean_apply_3(v_f_208_, v_head_215_, v___y_210_, v___y_211_);
if (lean_obj_tag(v___x_217_) == 0)
{
lean_dec(v_tail_216_);
lean_dec_ref(v_f_208_);
return v___x_217_;
}
else
{
lean_object* v_a_218_; lean_object* v_snd_219_; 
v_a_218_ = lean_ctor_get(v___x_217_, 0);
lean_inc(v_a_218_);
lean_dec_ref_known(v___x_217_, 1);
v_snd_219_ = lean_ctor_get(v_a_218_, 1);
lean_inc(v_snd_219_);
lean_dec(v_a_218_);
v_as_209_ = v_tail_216_;
v___y_211_ = v_snd_219_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1___boxed(lean_object* v_f_221_, lean_object* v_as_222_, lean_object* v___y_223_, lean_object* v___y_224_){
_start:
{
lean_object* v_res_225_; 
v_res_225_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1(v_f_221_, v_as_222_, v___y_223_, v___y_224_);
lean_dec_ref(v___y_223_);
return v_res_225_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0(lean_object* v_info_230_, lean_object* v_f_231_, lean_object* v___y_232_, lean_object* v___y_233_){
_start:
{
lean_object* v___y_235_; lean_object* v___y_236_; lean_object* v___x_253_; lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___y_257_; lean_object* v___x_283_; lean_object* v___x_284_; uint8_t v___x_285_; 
v___x_253_ = l_Lean_ConstantInfo_type(v_info_230_);
v___x_254_ = l_Lean_Expr_getUsedConstants(v___x_253_);
v___x_255_ = lean_unsigned_to_nat(0u);
v___x_283_ = lean_array_get_size(v___x_254_);
v___x_284_ = lean_box(0);
v___x_285_ = lean_nat_dec_lt(v___x_255_, v___x_283_);
if (v___x_285_ == 0)
{
lean_object* v___f_286_; 
lean_dec_ref(v___x_254_);
v___f_286_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___closed__0));
v___y_257_ = v___f_286_;
goto v___jp_256_;
}
else
{
uint8_t v___x_287_; 
v___x_287_ = lean_nat_dec_le(v___x_283_, v___x_283_);
if (v___x_287_ == 0)
{
if (v___x_285_ == 0)
{
lean_object* v___f_288_; 
lean_dec_ref(v___x_254_);
v___f_288_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___closed__0));
v___y_257_ = v___f_288_;
goto v___jp_256_;
}
else
{
size_t v___x_289_; lean_object* v___x_290_; lean_object* v___x_291_; lean_object* v___x_292_; 
v___x_289_ = lean_usize_of_nat(v___x_283_);
v___x_290_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed__const__1));
v___x_291_ = lean_box_usize(v___x_289_);
lean_inc_ref(v_f_231_);
v___x_292_ = lean_alloc_closure((void*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0___boxed), 7, 5);
lean_closure_set(v___x_292_, 0, v_f_231_);
lean_closure_set(v___x_292_, 1, v___x_254_);
lean_closure_set(v___x_292_, 2, v___x_290_);
lean_closure_set(v___x_292_, 3, v___x_291_);
lean_closure_set(v___x_292_, 4, v___x_284_);
v___y_257_ = v___x_292_;
goto v___jp_256_;
}
}
else
{
size_t v___x_293_; lean_object* v___x_294_; lean_object* v___x_295_; lean_object* v___x_296_; 
v___x_293_ = lean_usize_of_nat(v___x_283_);
v___x_294_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed__const__1));
v___x_295_ = lean_box_usize(v___x_293_);
lean_inc_ref(v_f_231_);
v___x_296_ = lean_alloc_closure((void*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0___boxed), 7, 5);
lean_closure_set(v___x_296_, 0, v_f_231_);
lean_closure_set(v___x_296_, 1, v___x_254_);
lean_closure_set(v___x_296_, 2, v___x_294_);
lean_closure_set(v___x_296_, 3, v___x_295_);
lean_closure_set(v___x_296_, 4, v___x_284_);
v___y_257_ = v___x_296_;
goto v___jp_256_;
}
}
v___jp_234_:
{
switch(lean_obj_tag(v_info_230_))
{
case 5:
{
lean_object* v_val_237_; lean_object* v_all_238_; lean_object* v_ctors_239_; lean_object* v___x_240_; 
v_val_237_ = lean_ctor_get(v_info_230_, 0);
lean_inc_ref(v_val_237_);
lean_dec_ref_known(v_info_230_, 1);
v_all_238_ = lean_ctor_get(v_val_237_, 3);
lean_inc(v_all_238_);
v_ctors_239_ = lean_ctor_get(v_val_237_, 4);
lean_inc(v_ctors_239_);
lean_dec_ref(v_val_237_);
lean_inc_ref(v_f_231_);
v___x_240_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1(v_f_231_, v_ctors_239_, v___y_235_, v___y_236_);
if (lean_obj_tag(v___x_240_) == 0)
{
lean_dec(v_all_238_);
lean_dec_ref(v_f_231_);
return v___x_240_;
}
else
{
lean_object* v_a_241_; lean_object* v_snd_242_; lean_object* v___x_243_; 
v_a_241_ = lean_ctor_get(v___x_240_, 0);
lean_inc(v_a_241_);
lean_dec_ref_known(v___x_240_, 1);
v_snd_242_ = lean_ctor_get(v_a_241_, 1);
lean_inc(v_snd_242_);
lean_dec(v_a_241_);
v___x_243_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__1(v_f_231_, v_all_238_, v___y_235_, v_snd_242_);
return v___x_243_;
}
}
case 6:
{
lean_object* v_val_244_; lean_object* v_induct_245_; lean_object* v___x_246_; 
v_val_244_ = lean_ctor_get(v_info_230_, 0);
lean_inc_ref(v_val_244_);
lean_dec_ref_known(v_info_230_, 1);
v_induct_245_ = lean_ctor_get(v_val_244_, 1);
lean_inc(v_induct_245_);
lean_dec_ref(v_val_244_);
lean_inc_ref(v___y_235_);
v___x_246_ = lean_apply_3(v_f_231_, v_induct_245_, v___y_235_, v___y_236_);
return v___x_246_;
}
case 7:
{
lean_object* v_val_247_; lean_object* v_rules_248_; lean_object* v___x_249_; 
v_val_247_ = lean_ctor_get(v_info_230_, 0);
lean_inc_ref(v_val_247_);
lean_dec_ref_known(v_info_230_, 1);
v_rules_248_ = lean_ctor_get(v_val_247_, 6);
lean_inc(v_rules_248_);
lean_dec_ref(v_val_247_);
v___x_249_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__2(v_f_231_, v_rules_248_, v___y_235_, v___y_236_);
return v___x_249_;
}
default: 
{
lean_object* v___x_250_; lean_object* v___x_251_; lean_object* v___x_252_; 
lean_dec_ref(v_f_231_);
lean_dec_ref(v_info_230_);
v___x_250_ = lean_box(0);
v___x_251_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_251_, 0, v___x_250_);
lean_ctor_set(v___x_251_, 1, v___y_236_);
v___x_252_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_252_, 0, v___x_251_);
return v___x_252_;
}
}
}
v___jp_256_:
{
lean_object* v___x_258_; 
lean_inc_ref(v___y_232_);
v___x_258_ = lean_apply_2(v___y_257_, v___y_232_, v___y_233_);
if (lean_obj_tag(v___x_258_) == 0)
{
lean_dec_ref(v_f_231_);
lean_dec_ref(v_info_230_);
return v___x_258_;
}
else
{
lean_object* v_a_259_; lean_object* v_snd_260_; lean_object* v___x_261_; lean_object* v___x_262_; 
v_a_259_ = lean_ctor_get(v___x_258_, 0);
lean_inc(v_a_259_);
lean_dec_ref_known(v___x_258_, 1);
v_snd_260_ = lean_ctor_get(v_a_259_, 1);
lean_inc(v_snd_260_);
lean_dec(v_a_259_);
v___x_261_ = l_Lean_ConstantInfo_name(v_info_230_);
lean_inc_ref(v_f_231_);
lean_inc_ref(v___y_232_);
v___x_262_ = lean_apply_3(v_f_231_, v___x_261_, v___y_232_, v_snd_260_);
if (lean_obj_tag(v___x_262_) == 0)
{
lean_dec_ref(v_f_231_);
lean_dec_ref(v_info_230_);
return v___x_262_;
}
else
{
lean_object* v_a_263_; lean_object* v_snd_264_; uint8_t v___x_265_; lean_object* v___x_266_; 
v_a_263_ = lean_ctor_get(v___x_262_, 0);
lean_inc(v_a_263_);
lean_dec_ref_known(v___x_262_, 1);
v_snd_264_ = lean_ctor_get(v_a_263_, 1);
lean_inc(v_snd_264_);
lean_dec(v_a_263_);
v___x_265_ = 1;
lean_inc_ref(v_info_230_);
v___x_266_ = l_Lean_ConstantInfo_value_x3f(v_info_230_, v___x_265_);
if (lean_obj_tag(v___x_266_) == 1)
{
lean_object* v_val_267_; lean_object* v___x_268_; lean_object* v___x_269_; uint8_t v___x_270_; 
v_val_267_ = lean_ctor_get(v___x_266_, 0);
lean_inc(v_val_267_);
lean_dec_ref_known(v___x_266_, 1);
v___x_268_ = l_Lean_Expr_getUsedConstants(v_val_267_);
v___x_269_ = lean_array_get_size(v___x_268_);
v___x_270_ = lean_nat_dec_lt(v___x_255_, v___x_269_);
if (v___x_270_ == 0)
{
lean_dec_ref(v___x_268_);
v___y_235_ = v___y_232_;
v___y_236_ = v_snd_264_;
goto v___jp_234_;
}
else
{
lean_object* v___x_271_; uint8_t v___x_272_; 
v___x_271_ = lean_box(0);
v___x_272_ = lean_nat_dec_le(v___x_269_, v___x_269_);
if (v___x_272_ == 0)
{
if (v___x_270_ == 0)
{
lean_dec_ref(v___x_268_);
v___y_235_ = v___y_232_;
v___y_236_ = v_snd_264_;
goto v___jp_234_;
}
else
{
size_t v___x_273_; size_t v___x_274_; lean_object* v___x_275_; 
v___x_273_ = ((size_t)0ULL);
v___x_274_ = lean_usize_of_nat(v___x_269_);
lean_inc_ref(v_f_231_);
v___x_275_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(v_f_231_, v___x_268_, v___x_273_, v___x_274_, v___x_271_, v___y_232_, v_snd_264_);
lean_dec_ref(v___x_268_);
if (lean_obj_tag(v___x_275_) == 0)
{
lean_dec_ref(v_f_231_);
lean_dec_ref(v_info_230_);
return v___x_275_;
}
else
{
lean_object* v_a_276_; lean_object* v_snd_277_; 
v_a_276_ = lean_ctor_get(v___x_275_, 0);
lean_inc(v_a_276_);
lean_dec_ref_known(v___x_275_, 1);
v_snd_277_ = lean_ctor_get(v_a_276_, 1);
lean_inc(v_snd_277_);
lean_dec(v_a_276_);
v___y_235_ = v___y_232_;
v___y_236_ = v_snd_277_;
goto v___jp_234_;
}
}
}
else
{
size_t v___x_278_; size_t v___x_279_; lean_object* v___x_280_; 
v___x_278_ = ((size_t)0ULL);
v___x_279_ = lean_usize_of_nat(v___x_269_);
lean_inc_ref(v_f_231_);
v___x_280_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0_spec__0(v_f_231_, v___x_268_, v___x_278_, v___x_279_, v___x_271_, v___y_232_, v_snd_264_);
lean_dec_ref(v___x_268_);
if (lean_obj_tag(v___x_280_) == 0)
{
lean_dec_ref(v_f_231_);
lean_dec_ref(v_info_230_);
return v___x_280_;
}
else
{
lean_object* v_a_281_; lean_object* v_snd_282_; 
v_a_281_ = lean_ctor_get(v___x_280_, 0);
lean_inc(v_a_281_);
lean_dec_ref_known(v___x_280_, 1);
v_snd_282_ = lean_ctor_get(v_a_281_, 1);
lean_inc(v_snd_282_);
lean_dec(v_a_281_);
v___y_235_ = v___y_232_;
v___y_236_ = v_snd_282_;
goto v___jp_234_;
}
}
}
}
else
{
lean_dec(v___x_266_);
v___y_235_ = v___y_232_;
v___y_236_ = v_snd_264_;
goto v___jp_234_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0___boxed(lean_object* v_info_297_, lean_object* v_f_298_, lean_object* v___y_299_, lean_object* v___y_300_){
_start:
{
lean_object* v_res_301_; 
v_res_301_ = lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0(v_info_297_, v_f_298_, v___y_299_, v___y_300_);
lean_dec_ref(v___y_299_);
return v_res_301_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addRelevantConsts(lean_object* v_info_303_, lean_object* v_a_304_, lean_object* v_a_305_){
_start:
{
lean_object* v___x_306_; lean_object* v___x_307_; 
v___x_306_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_addRelevantConsts___closed__0));
v___x_307_ = lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Compare_addRelevantConsts_spec__0(v_info_303_, v___x_306_, v_a_304_, v_a_305_);
return v___x_307_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_addRelevantConsts___boxed(lean_object* v_info_308_, lean_object* v_a_309_, lean_object* v_a_310_){
_start:
{
lean_object* v_res_311_; 
v_res_311_ = lp_proofEnvironment_Comparator_Compare_addRelevantConsts(v_info_308_, v_a_309_, v_a_310_);
lean_dec_ref(v_a_309_);
return v_res_311_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg(lean_object* v_as_312_, size_t v_i_313_, size_t v_stop_314_, lean_object* v_b_315_, lean_object* v___y_316_){
_start:
{
uint8_t v___x_317_; 
v___x_317_ = lean_usize_dec_eq(v_i_313_, v_stop_314_);
if (v___x_317_ == 0)
{
lean_object* v___x_318_; lean_object* v___x_319_; 
v___x_318_ = lean_array_uget_borrowed(v_as_312_, v_i_313_);
lean_inc(v___x_318_);
v___x_319_ = lp_proofEnvironment_Comparator_Compare_addWorklist___redArg(v___x_318_, v___y_316_);
if (lean_obj_tag(v___x_319_) == 0)
{
return v___x_319_;
}
else
{
lean_object* v_a_320_; lean_object* v_fst_321_; lean_object* v_snd_322_; size_t v___x_323_; size_t v___x_324_; 
v_a_320_ = lean_ctor_get(v___x_319_, 0);
lean_inc(v_a_320_);
lean_dec_ref_known(v___x_319_, 1);
v_fst_321_ = lean_ctor_get(v_a_320_, 0);
lean_inc(v_fst_321_);
v_snd_322_ = lean_ctor_get(v_a_320_, 1);
lean_inc(v_snd_322_);
lean_dec(v_a_320_);
v___x_323_ = ((size_t)1ULL);
v___x_324_ = lean_usize_add(v_i_313_, v___x_323_);
v_i_313_ = v___x_324_;
v_b_315_ = v_fst_321_;
v___y_316_ = v_snd_322_;
goto _start;
}
}
else
{
lean_object* v___x_326_; lean_object* v___x_327_; 
v___x_326_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_326_, 0, v_b_315_);
lean_ctor_set(v___x_326_, 1, v___y_316_);
v___x_327_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_327_, 0, v___x_326_);
return v___x_327_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg___boxed(lean_object* v_as_328_, lean_object* v_i_329_, lean_object* v_stop_330_, lean_object* v_b_331_, lean_object* v___y_332_){
_start:
{
size_t v_i_boxed_333_; size_t v_stop_boxed_334_; lean_object* v_res_335_; 
v_i_boxed_333_ = lean_unbox_usize(v_i_329_);
lean_dec(v_i_329_);
v_stop_boxed_334_ = lean_unbox_usize(v_stop_330_);
lean_dec(v_stop_330_);
v_res_335_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg(v_as_328_, v_i_boxed_333_, v_stop_boxed_334_, v_b_331_, v___y_332_);
lean_dec_ref(v_as_328_);
return v_res_335_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_loop(lean_object* v_a_340_, lean_object* v_a_341_){
_start:
{
lean_object* v_worklist_342_; lean_object* v_checked_343_; lean_object* v___x_344_; lean_object* v___x_345_; uint8_t v___x_346_; 
v_worklist_342_ = lean_ctor_get(v_a_341_, 0);
v_checked_343_ = lean_ctor_get(v_a_341_, 1);
v___x_344_ = lean_array_get_size(v_worklist_342_);
v___x_345_ = lean_unsigned_to_nat(0u);
v___x_346_ = lean_nat_dec_eq(v___x_344_, v___x_345_);
if (v___x_346_ == 0)
{
lean_object* v___x_348_; uint8_t v_isShared_349_; uint8_t v_isSharedCheck_440_; 
lean_inc_ref(v_checked_343_);
lean_inc_ref(v_worklist_342_);
v_isSharedCheck_440_ = !lean_is_exclusive(v_a_341_);
if (v_isSharedCheck_440_ == 0)
{
lean_object* v_unused_441_; lean_object* v_unused_442_; 
v_unused_441_ = lean_ctor_get(v_a_341_, 1);
lean_dec(v_unused_441_);
v_unused_442_ = lean_ctor_get(v_a_341_, 0);
lean_dec(v_unused_442_);
v___x_348_ = v_a_341_;
v_isShared_349_ = v_isSharedCheck_440_;
goto v_resetjp_347_;
}
else
{
lean_dec(v_a_341_);
v___x_348_ = lean_box(0);
v_isShared_349_ = v_isSharedCheck_440_;
goto v_resetjp_347_;
}
v_resetjp_347_:
{
lean_object* v___x_350_; lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v___x_353_; lean_object* v___y_355_; lean_object* v_worklist_356_; lean_object* v_checked_357_; lean_object* v___y_365_; lean_object* v___y_366_; lean_object* v___y_370_; lean_object* v___x_373_; lean_object* v___x_374_; uint8_t v___x_375_; 
v___x_350_ = lean_box(0);
v___x_351_ = lean_unsigned_to_nat(1u);
v___x_352_ = lean_nat_sub(v___x_344_, v___x_351_);
v___x_353_ = lean_array_get(v___x_350_, v_worklist_342_, v___x_352_);
lean_dec(v___x_352_);
v___x_373_ = lean_array_pop(v_worklist_342_);
lean_inc_ref(v_checked_343_);
lean_inc_ref(v___x_373_);
v___x_374_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_374_, 0, v___x_373_);
lean_ctor_set(v___x_374_, 1, v_checked_343_);
v___x_375_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_checked_343_, v___x_353_);
if (v___x_375_ == 0)
{
lean_object* v_challenge_376_; lean_object* v_solution_377_; lean_object* v_definitionTargets_378_; lean_object* v_theoremTargets_379_; lean_object* v_constMap_380_; lean_object* v___x_381_; 
v_challenge_376_ = lean_ctor_get(v_a_340_, 0);
v_solution_377_ = lean_ctor_get(v_a_340_, 1);
v_definitionTargets_378_ = lean_ctor_get(v_a_340_, 2);
v_theoremTargets_379_ = lean_ctor_get(v_a_340_, 3);
v_constMap_380_ = lean_ctor_get(v_challenge_376_, 0);
v___x_381_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_380_, v___x_353_);
if (lean_obj_tag(v___x_381_) == 1)
{
lean_object* v_val_382_; lean_object* v___x_384_; uint8_t v_isShared_385_; uint8_t v_isSharedCheck_431_; 
v_val_382_ = lean_ctor_get(v___x_381_, 0);
v_isSharedCheck_431_ = !lean_is_exclusive(v___x_381_);
if (v_isSharedCheck_431_ == 0)
{
v___x_384_ = v___x_381_;
v_isShared_385_ = v_isSharedCheck_431_;
goto v_resetjp_383_;
}
else
{
lean_inc(v_val_382_);
lean_dec(v___x_381_);
v___x_384_ = lean_box(0);
v_isShared_385_ = v_isSharedCheck_431_;
goto v_resetjp_383_;
}
v_resetjp_383_:
{
lean_object* v_constMap_386_; lean_object* v___x_387_; 
v_constMap_386_ = lean_ctor_get(v_solution_377_, 0);
v___x_387_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_386_, v___x_353_);
if (lean_obj_tag(v___x_387_) == 1)
{
lean_object* v_val_388_; lean_object* v___x_390_; uint8_t v_isShared_391_; uint8_t v_isSharedCheck_421_; 
lean_del_object(v___x_384_);
v_val_388_ = lean_ctor_get(v___x_387_, 0);
v_isSharedCheck_421_ = !lean_is_exclusive(v___x_387_);
if (v_isSharedCheck_421_ == 0)
{
v___x_390_ = v___x_387_;
v_isShared_391_ = v_isSharedCheck_421_;
goto v_resetjp_389_;
}
else
{
lean_inc(v_val_388_);
lean_dec(v___x_387_);
v___x_390_ = lean_box(0);
v_isShared_391_ = v_isSharedCheck_421_;
goto v_resetjp_389_;
}
v_resetjp_389_:
{
lean_object* v___x_405_; uint8_t v___x_406_; 
v___x_405_ = l_Lean_ConstantInfo_name(v_val_388_);
v___x_406_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_definitionTargets_378_, v___x_405_);
if (v___x_406_ == 0)
{
uint8_t v___x_407_; 
v___x_407_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_theoremTargets_379_, v___x_405_);
lean_dec(v___x_405_);
if (v___x_407_ == 0)
{
uint8_t v___x_408_; 
lean_dec_ref(v___x_373_);
lean_dec_ref(v_checked_343_);
v___x_408_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_val_382_, v_val_388_);
lean_dec(v_val_382_);
if (v___x_408_ == 0)
{
uint8_t v___x_409_; lean_object* v___x_410_; lean_object* v___x_411_; lean_object* v___x_412_; lean_object* v___x_413_; lean_object* v___x_414_; lean_object* v___x_416_; 
lean_dec(v_val_388_);
lean_dec_ref_known(v___x_374_, 2);
lean_del_object(v___x_348_);
v___x_409_ = 1;
v___x_410_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__0));
v___x_411_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_353_, v___x_409_);
v___x_412_ = lean_string_append(v___x_410_, v___x_411_);
lean_dec_ref(v___x_411_);
v___x_413_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_414_ = lean_string_append(v___x_412_, v___x_413_);
if (v_isShared_391_ == 0)
{
lean_ctor_set_tag(v___x_390_, 0);
lean_ctor_set(v___x_390_, 0, v___x_414_);
v___x_416_ = v___x_390_;
goto v_reusejp_415_;
}
else
{
lean_object* v_reuseFailAlloc_417_; 
v_reuseFailAlloc_417_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_417_, 0, v___x_414_);
v___x_416_ = v_reuseFailAlloc_417_;
goto v_reusejp_415_;
}
v_reusejp_415_:
{
return v___x_416_;
}
}
else
{
lean_object* v___x_418_; 
lean_del_object(v___x_390_);
v___x_418_ = lp_proofEnvironment_Comparator_Compare_addRelevantConsts(v_val_388_, v_a_340_, v___x_374_);
if (lean_obj_tag(v___x_418_) == 0)
{
lean_dec(v___x_353_);
lean_del_object(v___x_348_);
return v___x_418_;
}
else
{
lean_object* v_a_419_; lean_object* v_snd_420_; 
v_a_419_ = lean_ctor_get(v___x_418_, 0);
lean_inc(v_a_419_);
lean_dec_ref_known(v___x_418_, 1);
v_snd_420_ = lean_ctor_get(v_a_419_, 1);
lean_inc(v_snd_420_);
lean_dec(v_a_419_);
v___y_365_ = v_a_340_;
v___y_366_ = v_snd_420_;
goto v___jp_364_;
}
}
}
else
{
lean_del_object(v___x_390_);
lean_dec(v_val_382_);
goto v___jp_392_;
}
}
else
{
lean_dec(v___x_405_);
lean_del_object(v___x_390_);
lean_dec(v_val_382_);
goto v___jp_392_;
}
v___jp_392_:
{
lean_object* v___x_393_; lean_object* v___x_394_; lean_object* v___x_395_; uint8_t v___x_396_; 
v___x_393_ = l_Lean_ConstantInfo_type(v_val_388_);
lean_dec(v_val_388_);
v___x_394_ = l_Lean_Expr_getUsedConstants(v___x_393_);
v___x_395_ = lean_array_get_size(v___x_394_);
v___x_396_ = lean_nat_dec_lt(v___x_345_, v___x_395_);
if (v___x_396_ == 0)
{
lean_dec_ref(v___x_394_);
lean_dec_ref_known(v___x_374_, 2);
v___y_355_ = v_a_340_;
v_worklist_356_ = v___x_373_;
v_checked_357_ = v_checked_343_;
goto v___jp_354_;
}
else
{
lean_object* v___x_397_; uint8_t v___x_398_; 
v___x_397_ = lean_box(0);
v___x_398_ = lean_nat_dec_le(v___x_395_, v___x_395_);
if (v___x_398_ == 0)
{
if (v___x_396_ == 0)
{
lean_dec_ref(v___x_394_);
lean_dec_ref_known(v___x_374_, 2);
v___y_355_ = v_a_340_;
v_worklist_356_ = v___x_373_;
v_checked_357_ = v_checked_343_;
goto v___jp_354_;
}
else
{
size_t v___x_399_; size_t v___x_400_; lean_object* v___x_401_; 
lean_dec_ref(v___x_373_);
lean_dec_ref(v_checked_343_);
v___x_399_ = ((size_t)0ULL);
v___x_400_ = lean_usize_of_nat(v___x_395_);
v___x_401_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg(v___x_394_, v___x_399_, v___x_400_, v___x_397_, v___x_374_);
lean_dec_ref(v___x_394_);
v___y_370_ = v___x_401_;
goto v___jp_369_;
}
}
else
{
size_t v___x_402_; size_t v___x_403_; lean_object* v___x_404_; 
lean_dec_ref(v___x_373_);
lean_dec_ref(v_checked_343_);
v___x_402_ = ((size_t)0ULL);
v___x_403_ = lean_usize_of_nat(v___x_395_);
v___x_404_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg(v___x_394_, v___x_402_, v___x_403_, v___x_397_, v___x_374_);
lean_dec_ref(v___x_394_);
v___y_370_ = v___x_404_;
goto v___jp_369_;
}
}
}
}
}
else
{
lean_object* v___x_422_; uint8_t v___x_423_; lean_object* v___x_424_; lean_object* v___x_425_; lean_object* v___x_426_; lean_object* v___x_427_; lean_object* v___x_429_; 
lean_dec(v___x_387_);
lean_dec(v_val_382_);
lean_dec_ref_known(v___x_374_, 2);
lean_dec_ref(v___x_373_);
lean_del_object(v___x_348_);
lean_dec_ref(v_checked_343_);
v___x_422_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__2));
v___x_423_ = 1;
v___x_424_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_353_, v___x_423_);
v___x_425_ = lean_string_append(v___x_422_, v___x_424_);
lean_dec_ref(v___x_424_);
v___x_426_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_427_ = lean_string_append(v___x_425_, v___x_426_);
if (v_isShared_385_ == 0)
{
lean_ctor_set_tag(v___x_384_, 0);
lean_ctor_set(v___x_384_, 0, v___x_427_);
v___x_429_ = v___x_384_;
goto v_reusejp_428_;
}
else
{
lean_object* v_reuseFailAlloc_430_; 
v_reuseFailAlloc_430_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_430_, 0, v___x_427_);
v___x_429_ = v_reuseFailAlloc_430_;
goto v_reusejp_428_;
}
v_reusejp_428_:
{
return v___x_429_;
}
}
}
}
else
{
lean_object* v___x_432_; uint8_t v___x_433_; lean_object* v___x_434_; lean_object* v___x_435_; lean_object* v___x_436_; lean_object* v___x_437_; lean_object* v___x_438_; 
lean_dec(v___x_381_);
lean_dec_ref_known(v___x_374_, 2);
lean_dec_ref(v___x_373_);
lean_del_object(v___x_348_);
lean_dec_ref(v_checked_343_);
v___x_432_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__3));
v___x_433_ = 1;
v___x_434_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_353_, v___x_433_);
v___x_435_ = lean_string_append(v___x_432_, v___x_434_);
lean_dec_ref(v___x_434_);
v___x_436_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_437_ = lean_string_append(v___x_435_, v___x_436_);
v___x_438_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_438_, 0, v___x_437_);
return v___x_438_;
}
}
else
{
lean_dec_ref(v___x_373_);
lean_dec(v___x_353_);
lean_del_object(v___x_348_);
lean_dec_ref(v_checked_343_);
v_a_341_ = v___x_374_;
goto _start;
}
v___jp_354_:
{
lean_object* v___x_358_; lean_object* v___x_359_; lean_object* v___x_361_; 
v___x_358_ = lean_box(0);
v___x_359_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_finalizeImport_spec__5___redArg(v_checked_357_, v___x_353_, v___x_358_);
if (v_isShared_349_ == 0)
{
lean_ctor_set(v___x_348_, 1, v___x_359_);
lean_ctor_set(v___x_348_, 0, v_worklist_356_);
v___x_361_ = v___x_348_;
goto v_reusejp_360_;
}
else
{
lean_object* v_reuseFailAlloc_363_; 
v_reuseFailAlloc_363_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_363_, 0, v_worklist_356_);
lean_ctor_set(v_reuseFailAlloc_363_, 1, v___x_359_);
v___x_361_ = v_reuseFailAlloc_363_;
goto v_reusejp_360_;
}
v_reusejp_360_:
{
v_a_340_ = v___y_355_;
v_a_341_ = v___x_361_;
goto _start;
}
}
v___jp_364_:
{
lean_object* v_worklist_367_; lean_object* v_checked_368_; 
v_worklist_367_ = lean_ctor_get(v___y_366_, 0);
lean_inc_ref(v_worklist_367_);
v_checked_368_ = lean_ctor_get(v___y_366_, 1);
lean_inc_ref(v_checked_368_);
lean_dec_ref(v___y_366_);
v___y_355_ = v___y_365_;
v_worklist_356_ = v_worklist_367_;
v_checked_357_ = v_checked_368_;
goto v___jp_354_;
}
v___jp_369_:
{
if (lean_obj_tag(v___y_370_) == 0)
{
lean_dec(v___x_353_);
lean_del_object(v___x_348_);
return v___y_370_;
}
else
{
lean_object* v_a_371_; lean_object* v_snd_372_; 
v_a_371_ = lean_ctor_get(v___y_370_, 0);
lean_inc(v_a_371_);
lean_dec_ref_known(v___y_370_, 1);
v_snd_372_ = lean_ctor_get(v_a_371_, 1);
lean_inc(v_snd_372_);
lean_dec(v_a_371_);
v___y_365_ = v_a_340_;
v___y_366_ = v_snd_372_;
goto v___jp_364_;
}
}
}
}
else
{
lean_object* v___x_443_; lean_object* v___x_444_; lean_object* v___x_445_; 
v___x_443_ = lean_box(0);
v___x_444_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_444_, 0, v___x_443_);
lean_ctor_set(v___x_444_, 1, v_a_341_);
v___x_445_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_445_, 0, v___x_444_);
return v___x_445_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Compare_loop___boxed(lean_object* v_a_446_, lean_object* v_a_447_){
_start:
{
lean_object* v_res_448_; 
v_res_448_ = lp_proofEnvironment_Comparator_Compare_loop(v_a_446_, v_a_447_);
lean_dec_ref(v_a_446_);
return v_res_448_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0(lean_object* v_as_449_, size_t v_i_450_, size_t v_stop_451_, lean_object* v_b_452_, lean_object* v___y_453_, lean_object* v___y_454_){
_start:
{
lean_object* v___x_455_; 
v___x_455_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___redArg(v_as_449_, v_i_450_, v_stop_451_, v_b_452_, v___y_454_);
return v___x_455_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0___boxed(lean_object* v_as_456_, lean_object* v_i_457_, lean_object* v_stop_458_, lean_object* v_b_459_, lean_object* v___y_460_, lean_object* v___y_461_){
_start:
{
size_t v_i_boxed_462_; size_t v_stop_boxed_463_; lean_object* v_res_464_; 
v_i_boxed_462_ = lean_unbox_usize(v_i_457_);
lean_dec(v_i_457_);
v_stop_boxed_463_ = lean_unbox_usize(v_stop_458_);
lean_dec(v_stop_458_);
v_res_464_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_Compare_loop_spec__0(v_as_456_, v_i_boxed_462_, v_stop_boxed_463_, v_b_459_, v___y_460_, v___y_461_);
lean_dec_ref(v___y_460_);
lean_dec_ref(v_as_456_);
return v_res_464_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Comparator_definitionHoleMatches(lean_object* v_challengeHole_465_, lean_object* v_solutionHole_466_){
_start:
{
lean_object* v_toConstantVal_467_; uint8_t v_safety_468_; lean_object* v_toConstantVal_469_; uint8_t v_safety_470_; uint8_t v___x_471_; 
v_toConstantVal_467_ = lean_ctor_get(v_challengeHole_465_, 0);
v_safety_468_ = lean_ctor_get_uint8(v_challengeHole_465_, sizeof(void*)*4);
v_toConstantVal_469_ = lean_ctor_get(v_solutionHole_466_, 0);
v_safety_470_ = lean_ctor_get_uint8(v_solutionHole_466_, sizeof(void*)*4);
v___x_471_ = l_Lean_instBEqConstantVal_beq(v_toConstantVal_467_, v_toConstantVal_469_);
if (v___x_471_ == 0)
{
return v___x_471_;
}
else
{
uint8_t v___x_472_; 
v___x_472_ = l_Lean_instBEqDefinitionSafety_beq(v_safety_468_, v_safety_470_);
return v___x_472_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_definitionHoleMatches___boxed(lean_object* v_challengeHole_473_, lean_object* v_solutionHole_474_){
_start:
{
uint8_t v_res_475_; lean_object* v_r_476_; 
v_res_475_ = lp_proofEnvironment_Comparator_definitionHoleMatches(v_challengeHole_473_, v_solutionHole_474_);
lean_dec_ref(v_solutionHole_474_);
lean_dec_ref(v_challengeHole_473_);
v_r_476_ = lean_box(v_res_475_);
return v_r_476_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0(lean_object* v_challenge_481_, lean_object* v_solution_482_, lean_object* v_as_483_, size_t v_sz_484_, size_t v_i_485_, lean_object* v_b_486_){
_start:
{
uint8_t v___x_487_; 
v___x_487_ = lean_usize_dec_lt(v_i_485_, v_sz_484_);
if (v___x_487_ == 0)
{
lean_object* v___x_488_; 
v___x_488_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_488_, 0, v_b_486_);
return v___x_488_;
}
else
{
lean_object* v_constMap_489_; lean_object* v_a_490_; lean_object* v_fst_499_; lean_object* v_snd_500_; lean_object* v___x_514_; 
v_constMap_489_ = lean_ctor_get(v_challenge_481_, 0);
v_a_490_ = lean_array_uget_borrowed(v_as_483_, v_i_485_);
v___x_514_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_489_, v_a_490_);
if (lean_obj_tag(v___x_514_) == 1)
{
lean_object* v_val_515_; lean_object* v___x_517_; uint8_t v_isShared_518_; uint8_t v_isSharedCheck_539_; 
v_val_515_ = lean_ctor_get(v___x_514_, 0);
v_isSharedCheck_539_ = !lean_is_exclusive(v___x_514_);
if (v_isSharedCheck_539_ == 0)
{
v___x_517_ = v___x_514_;
v_isShared_518_ = v_isSharedCheck_539_;
goto v_resetjp_516_;
}
else
{
lean_inc(v_val_515_);
lean_dec(v___x_514_);
v___x_517_ = lean_box(0);
v_isShared_518_ = v_isSharedCheck_539_;
goto v_resetjp_516_;
}
v_resetjp_516_:
{
lean_object* v_constMap_519_; lean_object* v___x_520_; 
v_constMap_519_ = lean_ctor_get(v_solution_482_, 0);
v___x_520_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_519_, v_a_490_);
if (lean_obj_tag(v___x_520_) == 1)
{
lean_del_object(v___x_517_);
switch(lean_obj_tag(v_val_515_))
{
case 2:
{
lean_object* v_val_521_; 
v_val_521_ = lean_ctor_get(v___x_520_, 0);
lean_inc(v_val_521_);
lean_dec_ref_known(v___x_520_, 1);
if (lean_obj_tag(v_val_521_) == 2)
{
lean_object* v_val_522_; lean_object* v_val_523_; lean_object* v_toConstantVal_524_; lean_object* v_toConstantVal_525_; 
v_val_522_ = lean_ctor_get(v_val_515_, 0);
lean_inc_ref(v_val_522_);
lean_dec_ref_known(v_val_515_, 1);
v_val_523_ = lean_ctor_get(v_val_521_, 0);
lean_inc_ref(v_val_523_);
lean_dec_ref_known(v_val_521_, 1);
v_toConstantVal_524_ = lean_ctor_get(v_val_522_, 0);
lean_inc_ref(v_toConstantVal_524_);
lean_dec_ref(v_val_522_);
v_toConstantVal_525_ = lean_ctor_get(v_val_523_, 0);
lean_inc_ref(v_toConstantVal_525_);
lean_dec_ref(v_val_523_);
v_fst_499_ = v_toConstantVal_524_;
v_snd_500_ = v_toConstantVal_525_;
goto v___jp_498_;
}
else
{
lean_dec(v_val_521_);
lean_dec_ref_known(v_val_515_, 1);
lean_dec_ref(v_b_486_);
goto v___jp_491_;
}
}
case 0:
{
lean_object* v_val_526_; 
v_val_526_ = lean_ctor_get(v___x_520_, 0);
lean_inc(v_val_526_);
lean_dec_ref_known(v___x_520_, 1);
if (lean_obj_tag(v_val_526_) == 0)
{
lean_object* v_val_527_; lean_object* v_val_528_; lean_object* v_toConstantVal_529_; lean_object* v_toConstantVal_530_; 
v_val_527_ = lean_ctor_get(v_val_515_, 0);
lean_inc_ref(v_val_527_);
lean_dec_ref_known(v_val_515_, 1);
v_val_528_ = lean_ctor_get(v_val_526_, 0);
lean_inc_ref(v_val_528_);
lean_dec_ref_known(v_val_526_, 1);
v_toConstantVal_529_ = lean_ctor_get(v_val_527_, 0);
lean_inc_ref(v_toConstantVal_529_);
lean_dec_ref(v_val_527_);
v_toConstantVal_530_ = lean_ctor_get(v_val_528_, 0);
lean_inc_ref(v_toConstantVal_530_);
lean_dec_ref(v_val_528_);
v_fst_499_ = v_toConstantVal_529_;
v_snd_500_ = v_toConstantVal_530_;
goto v___jp_498_;
}
else
{
lean_dec(v_val_526_);
lean_dec_ref_known(v_val_515_, 1);
lean_dec_ref(v_b_486_);
goto v___jp_491_;
}
}
default: 
{
lean_dec_ref_known(v___x_520_, 1);
lean_dec(v_val_515_);
lean_dec_ref(v_b_486_);
goto v___jp_491_;
}
}
}
else
{
lean_object* v___x_531_; lean_object* v___x_532_; lean_object* v___x_533_; lean_object* v___x_534_; lean_object* v___x_535_; lean_object* v___x_537_; 
lean_dec(v___x_520_);
lean_dec(v_val_515_);
lean_dec_ref(v_b_486_);
v___x_531_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__2));
lean_inc(v_a_490_);
v___x_532_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_490_, v___x_487_);
v___x_533_ = lean_string_append(v___x_531_, v___x_532_);
lean_dec_ref(v___x_532_);
v___x_534_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_535_ = lean_string_append(v___x_533_, v___x_534_);
if (v_isShared_518_ == 0)
{
lean_ctor_set_tag(v___x_517_, 0);
lean_ctor_set(v___x_517_, 0, v___x_535_);
v___x_537_ = v___x_517_;
goto v_reusejp_536_;
}
else
{
lean_object* v_reuseFailAlloc_538_; 
v_reuseFailAlloc_538_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_538_, 0, v___x_535_);
v___x_537_ = v_reuseFailAlloc_538_;
goto v_reusejp_536_;
}
v_reusejp_536_:
{
return v___x_537_;
}
}
}
}
else
{
lean_object* v___x_540_; lean_object* v___x_541_; lean_object* v___x_542_; lean_object* v___x_543_; lean_object* v___x_544_; lean_object* v___x_545_; 
lean_dec(v___x_514_);
lean_dec_ref(v_b_486_);
v___x_540_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__3));
lean_inc(v_a_490_);
v___x_541_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_490_, v___x_487_);
v___x_542_ = lean_string_append(v___x_540_, v___x_541_);
lean_dec_ref(v___x_541_);
v___x_543_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_544_ = lean_string_append(v___x_542_, v___x_543_);
v___x_545_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_545_, 0, v___x_544_);
return v___x_545_;
}
v___jp_491_:
{
lean_object* v___x_492_; lean_object* v___x_493_; lean_object* v___x_494_; lean_object* v___x_495_; lean_object* v___x_496_; lean_object* v___x_497_; 
v___x_492_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__0));
lean_inc(v_a_490_);
v___x_493_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_490_, v___x_487_);
v___x_494_ = lean_string_append(v___x_492_, v___x_493_);
lean_dec_ref(v___x_493_);
v___x_495_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_496_ = lean_string_append(v___x_494_, v___x_495_);
v___x_497_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_497_, 0, v___x_496_);
return v___x_497_;
}
v___jp_498_:
{
uint8_t v___x_501_; 
v___x_501_ = l_Lean_instBEqConstantVal_beq(v_fst_499_, v_snd_500_);
lean_dec_ref(v_snd_500_);
if (v___x_501_ == 0)
{
lean_object* v___x_502_; lean_object* v___x_503_; lean_object* v___x_504_; lean_object* v___x_505_; lean_object* v___x_506_; lean_object* v___x_507_; 
lean_dec_ref(v_fst_499_);
lean_dec_ref(v_b_486_);
v___x_502_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__1));
lean_inc(v_a_490_);
v___x_503_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_490_, v___x_487_);
v___x_504_ = lean_string_append(v___x_502_, v___x_503_);
lean_dec_ref(v___x_503_);
v___x_505_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_506_ = lean_string_append(v___x_504_, v___x_505_);
v___x_507_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_507_, 0, v___x_506_);
return v___x_507_;
}
else
{
lean_object* v_type_508_; lean_object* v___x_509_; lean_object* v___x_510_; size_t v___x_511_; size_t v___x_512_; 
v_type_508_ = lean_ctor_get(v_fst_499_, 2);
lean_inc_ref(v_type_508_);
lean_dec_ref(v_fst_499_);
v___x_509_ = l_Lean_Expr_getUsedConstants(v_type_508_);
v___x_510_ = l_Array_append___redArg(v_b_486_, v___x_509_);
lean_dec_ref(v___x_509_);
v___x_511_ = ((size_t)1ULL);
v___x_512_ = lean_usize_add(v_i_485_, v___x_511_);
v_i_485_ = v___x_512_;
v_b_486_ = v___x_510_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___boxed(lean_object* v_challenge_546_, lean_object* v_solution_547_, lean_object* v_as_548_, lean_object* v_sz_549_, lean_object* v_i_550_, lean_object* v_b_551_){
_start:
{
size_t v_sz_boxed_552_; size_t v_i_boxed_553_; lean_object* v_res_554_; 
v_sz_boxed_552_ = lean_unbox_usize(v_sz_549_);
lean_dec(v_sz_549_);
v_i_boxed_553_ = lean_unbox_usize(v_i_550_);
lean_dec(v_i_550_);
v_res_554_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0(v_challenge_546_, v_solution_547_, v_as_548_, v_sz_boxed_552_, v_i_boxed_553_, v_b_551_);
lean_dec_ref(v_as_548_);
lean_dec_ref(v_solution_547_);
lean_dec_ref(v_challenge_546_);
return v_res_554_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1(lean_object* v_challenge_557_, lean_object* v_solution_558_, lean_object* v_as_559_, size_t v_sz_560_, size_t v_i_561_, lean_object* v_b_562_){
_start:
{
uint8_t v___x_563_; 
v___x_563_ = lean_usize_dec_lt(v_i_561_, v_sz_560_);
if (v___x_563_ == 0)
{
lean_object* v___x_564_; 
v___x_564_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_564_, 0, v_b_562_);
return v___x_564_;
}
else
{
lean_object* v_constMap_565_; lean_object* v_a_566_; lean_object* v___x_567_; 
v_constMap_565_ = lean_ctor_get(v_challenge_557_, 0);
v_a_566_ = lean_array_uget_borrowed(v_as_559_, v_i_561_);
v___x_567_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_565_, v_a_566_);
if (lean_obj_tag(v___x_567_) == 1)
{
lean_object* v_val_568_; lean_object* v___x_570_; uint8_t v_isShared_571_; uint8_t v_isSharedCheck_630_; 
v_val_568_ = lean_ctor_get(v___x_567_, 0);
v_isSharedCheck_630_ = !lean_is_exclusive(v___x_567_);
if (v_isSharedCheck_630_ == 0)
{
v___x_570_ = v___x_567_;
v_isShared_571_ = v_isSharedCheck_630_;
goto v_resetjp_569_;
}
else
{
lean_inc(v_val_568_);
lean_dec(v___x_567_);
v___x_570_ = lean_box(0);
v_isShared_571_ = v_isSharedCheck_630_;
goto v_resetjp_569_;
}
v_resetjp_569_:
{
lean_object* v_constMap_572_; lean_object* v___x_573_; 
v_constMap_572_ = lean_ctor_get(v_solution_558_, 0);
v___x_573_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_572_, v_a_566_);
if (lean_obj_tag(v___x_573_) == 1)
{
lean_del_object(v___x_570_);
if (lean_obj_tag(v_val_568_) == 1)
{
lean_object* v_val_574_; 
v_val_574_ = lean_ctor_get(v___x_573_, 0);
lean_inc(v_val_574_);
lean_dec_ref_known(v___x_573_, 1);
if (lean_obj_tag(v_val_574_) == 1)
{
lean_object* v_val_575_; lean_object* v_val_576_; lean_object* v___x_578_; uint8_t v_isShared_579_; uint8_t v_isSharedCheck_595_; 
v_val_575_ = lean_ctor_get(v_val_568_, 0);
lean_inc_ref(v_val_575_);
lean_dec_ref_known(v_val_568_, 1);
v_val_576_ = lean_ctor_get(v_val_574_, 0);
v_isSharedCheck_595_ = !lean_is_exclusive(v_val_574_);
if (v_isSharedCheck_595_ == 0)
{
v___x_578_ = v_val_574_;
v_isShared_579_ = v_isSharedCheck_595_;
goto v_resetjp_577_;
}
else
{
lean_inc(v_val_576_);
lean_dec(v_val_574_);
v___x_578_ = lean_box(0);
v_isShared_579_ = v_isSharedCheck_595_;
goto v_resetjp_577_;
}
v_resetjp_577_:
{
uint8_t v___x_580_; 
v___x_580_ = lp_proofEnvironment_Comparator_definitionHoleMatches(v_val_575_, v_val_576_);
lean_dec_ref(v_val_575_);
if (v___x_580_ == 0)
{
lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; lean_object* v___x_584_; lean_object* v___x_585_; lean_object* v___x_587_; 
lean_dec_ref(v_val_576_);
lean_dec_ref(v_b_562_);
v___x_581_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__0));
lean_inc(v_a_566_);
v___x_582_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_566_, v___x_563_);
v___x_583_ = lean_string_append(v___x_581_, v___x_582_);
lean_dec_ref(v___x_582_);
v___x_584_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_585_ = lean_string_append(v___x_583_, v___x_584_);
if (v_isShared_579_ == 0)
{
lean_ctor_set_tag(v___x_578_, 0);
lean_ctor_set(v___x_578_, 0, v___x_585_);
v___x_587_ = v___x_578_;
goto v_reusejp_586_;
}
else
{
lean_object* v_reuseFailAlloc_588_; 
v_reuseFailAlloc_588_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_588_, 0, v___x_585_);
v___x_587_ = v_reuseFailAlloc_588_;
goto v_reusejp_586_;
}
v_reusejp_586_:
{
return v___x_587_;
}
}
else
{
lean_object* v_toConstantVal_589_; lean_object* v_name_590_; lean_object* v___x_591_; size_t v___x_592_; size_t v___x_593_; 
lean_del_object(v___x_578_);
v_toConstantVal_589_ = lean_ctor_get(v_val_576_, 0);
lean_inc_ref(v_toConstantVal_589_);
lean_dec_ref(v_val_576_);
v_name_590_ = lean_ctor_get(v_toConstantVal_589_, 0);
lean_inc(v_name_590_);
lean_dec_ref(v_toConstantVal_589_);
v___x_591_ = lean_array_push(v_b_562_, v_name_590_);
v___x_592_ = ((size_t)1ULL);
v___x_593_ = lean_usize_add(v_i_561_, v___x_592_);
v_i_561_ = v___x_593_;
v_b_562_ = v___x_591_;
goto _start;
}
}
}
else
{
lean_object* v___x_597_; uint8_t v_isShared_598_; uint8_t v_isSharedCheck_607_; 
lean_dec(v_val_574_);
lean_dec_ref(v_b_562_);
v_isSharedCheck_607_ = !lean_is_exclusive(v_val_568_);
if (v_isSharedCheck_607_ == 0)
{
lean_object* v_unused_608_; 
v_unused_608_ = lean_ctor_get(v_val_568_, 0);
lean_dec(v_unused_608_);
v___x_597_ = v_val_568_;
v_isShared_598_ = v_isSharedCheck_607_;
goto v_resetjp_596_;
}
else
{
lean_dec(v_val_568_);
v___x_597_ = lean_box(0);
v_isShared_598_ = v_isSharedCheck_607_;
goto v_resetjp_596_;
}
v_resetjp_596_:
{
lean_object* v___x_599_; lean_object* v___x_600_; lean_object* v___x_601_; lean_object* v___x_602_; lean_object* v___x_603_; lean_object* v___x_605_; 
v___x_599_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__0));
lean_inc(v_a_566_);
v___x_600_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_566_, v___x_563_);
v___x_601_ = lean_string_append(v___x_599_, v___x_600_);
lean_dec_ref(v___x_600_);
v___x_602_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_603_ = lean_string_append(v___x_601_, v___x_602_);
if (v_isShared_598_ == 0)
{
lean_ctor_set_tag(v___x_597_, 0);
lean_ctor_set(v___x_597_, 0, v___x_603_);
v___x_605_ = v___x_597_;
goto v_reusejp_604_;
}
else
{
lean_object* v_reuseFailAlloc_606_; 
v_reuseFailAlloc_606_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_606_, 0, v___x_603_);
v___x_605_ = v_reuseFailAlloc_606_;
goto v_reusejp_604_;
}
v_reusejp_604_:
{
return v___x_605_;
}
}
}
}
else
{
lean_object* v___x_610_; uint8_t v_isShared_611_; uint8_t v_isSharedCheck_620_; 
lean_dec(v_val_568_);
lean_dec_ref(v_b_562_);
v_isSharedCheck_620_ = !lean_is_exclusive(v___x_573_);
if (v_isSharedCheck_620_ == 0)
{
lean_object* v_unused_621_; 
v_unused_621_ = lean_ctor_get(v___x_573_, 0);
lean_dec(v_unused_621_);
v___x_610_ = v___x_573_;
v_isShared_611_ = v_isSharedCheck_620_;
goto v_resetjp_609_;
}
else
{
lean_dec(v___x_573_);
v___x_610_ = lean_box(0);
v_isShared_611_ = v_isSharedCheck_620_;
goto v_resetjp_609_;
}
v_resetjp_609_:
{
lean_object* v___x_612_; lean_object* v___x_613_; lean_object* v___x_614_; lean_object* v___x_615_; lean_object* v___x_616_; lean_object* v___x_618_; 
v___x_612_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___closed__1));
lean_inc(v_a_566_);
v___x_613_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_566_, v___x_563_);
v___x_614_ = lean_string_append(v___x_612_, v___x_613_);
lean_dec_ref(v___x_613_);
v___x_615_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_616_ = lean_string_append(v___x_614_, v___x_615_);
if (v_isShared_611_ == 0)
{
lean_ctor_set_tag(v___x_610_, 0);
lean_ctor_set(v___x_610_, 0, v___x_616_);
v___x_618_ = v___x_610_;
goto v_reusejp_617_;
}
else
{
lean_object* v_reuseFailAlloc_619_; 
v_reuseFailAlloc_619_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_619_, 0, v___x_616_);
v___x_618_ = v_reuseFailAlloc_619_;
goto v_reusejp_617_;
}
v_reusejp_617_:
{
return v___x_618_;
}
}
}
}
else
{
lean_object* v___x_622_; lean_object* v___x_623_; lean_object* v___x_624_; lean_object* v___x_625_; lean_object* v___x_626_; lean_object* v___x_628_; 
lean_dec(v___x_573_);
lean_dec(v_val_568_);
lean_dec_ref(v_b_562_);
v___x_622_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__2));
lean_inc(v_a_566_);
v___x_623_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_566_, v___x_563_);
v___x_624_ = lean_string_append(v___x_622_, v___x_623_);
lean_dec_ref(v___x_623_);
v___x_625_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_626_ = lean_string_append(v___x_624_, v___x_625_);
if (v_isShared_571_ == 0)
{
lean_ctor_set_tag(v___x_570_, 0);
lean_ctor_set(v___x_570_, 0, v___x_626_);
v___x_628_ = v___x_570_;
goto v_reusejp_627_;
}
else
{
lean_object* v_reuseFailAlloc_629_; 
v_reuseFailAlloc_629_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_629_, 0, v___x_626_);
v___x_628_ = v_reuseFailAlloc_629_;
goto v_reusejp_627_;
}
v_reusejp_627_:
{
return v___x_628_;
}
}
}
}
else
{
lean_object* v___x_631_; lean_object* v___x_632_; lean_object* v___x_633_; lean_object* v___x_634_; lean_object* v___x_635_; lean_object* v___x_636_; 
lean_dec(v___x_567_);
lean_dec_ref(v_b_562_);
v___x_631_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0___closed__3));
lean_inc(v_a_566_);
v___x_632_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_566_, v___x_563_);
v___x_633_ = lean_string_append(v___x_631_, v___x_632_);
lean_dec_ref(v___x_632_);
v___x_634_ = ((lean_object*)(lp_proofEnvironment_Comparator_Compare_loop___closed__1));
v___x_635_ = lean_string_append(v___x_633_, v___x_634_);
v___x_636_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_636_, 0, v___x_635_);
return v___x_636_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1___boxed(lean_object* v_challenge_637_, lean_object* v_solution_638_, lean_object* v_as_639_, lean_object* v_sz_640_, lean_object* v_i_641_, lean_object* v_b_642_){
_start:
{
size_t v_sz_boxed_643_; size_t v_i_boxed_644_; lean_object* v_res_645_; 
v_sz_boxed_643_ = lean_unbox_usize(v_sz_640_);
lean_dec(v_sz_640_);
v_i_boxed_644_ = lean_unbox_usize(v_i_641_);
lean_dec(v_i_641_);
v_res_645_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1(v_challenge_637_, v_solution_638_, v_as_639_, v_sz_boxed_643_, v_i_boxed_644_, v_b_642_);
lean_dec_ref(v_as_639_);
lean_dec_ref(v_solution_638_);
lean_dec_ref(v_challenge_637_);
return v_res_645_;
}
}
static lean_object* _init_lp_proofEnvironment_Comparator_compareAt___closed__0(void){
_start:
{
lean_object* v___x_646_; lean_object* v___x_647_; lean_object* v___x_648_; 
v___x_646_ = lean_box(0);
v___x_647_ = lean_unsigned_to_nat(16u);
v___x_648_ = lean_mk_array(v___x_647_, v___x_646_);
return v___x_648_;
}
}
static lean_object* _init_lp_proofEnvironment_Comparator_compareAt___closed__1(void){
_start:
{
lean_object* v___x_649_; lean_object* v___x_650_; lean_object* v___x_651_; 
v___x_649_ = lean_obj_once(&lp_proofEnvironment_Comparator_compareAt___closed__0, &lp_proofEnvironment_Comparator_compareAt___closed__0_once, _init_lp_proofEnvironment_Comparator_compareAt___closed__0);
v___x_650_ = lean_unsigned_to_nat(0u);
v___x_651_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_651_, 0, v___x_650_);
lean_ctor_set(v___x_651_, 1, v___x_649_);
return v___x_651_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_compareAt(lean_object* v_challenge_652_, lean_object* v_solution_653_, lean_object* v_theoremTargets_654_, lean_object* v_definitionTargets_655_, lean_object* v_primitive_656_){
_start:
{
size_t v_sz_657_; size_t v___x_658_; lean_object* v___x_659_; 
v_sz_657_ = lean_array_size(v_theoremTargets_654_);
v___x_658_ = ((size_t)0ULL);
v___x_659_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__0(v_challenge_652_, v_solution_653_, v_theoremTargets_654_, v_sz_657_, v___x_658_, v_primitive_656_);
if (lean_obj_tag(v___x_659_) == 0)
{
lean_object* v_a_660_; lean_object* v___x_662_; uint8_t v_isShared_663_; uint8_t v_isSharedCheck_667_; 
lean_dec_ref(v_solution_653_);
lean_dec_ref(v_challenge_652_);
v_a_660_ = lean_ctor_get(v___x_659_, 0);
v_isSharedCheck_667_ = !lean_is_exclusive(v___x_659_);
if (v_isSharedCheck_667_ == 0)
{
v___x_662_ = v___x_659_;
v_isShared_663_ = v_isSharedCheck_667_;
goto v_resetjp_661_;
}
else
{
lean_inc(v_a_660_);
lean_dec(v___x_659_);
v___x_662_ = lean_box(0);
v_isShared_663_ = v_isSharedCheck_667_;
goto v_resetjp_661_;
}
v_resetjp_661_:
{
lean_object* v___x_665_; 
if (v_isShared_663_ == 0)
{
v___x_665_ = v___x_662_;
goto v_reusejp_664_;
}
else
{
lean_object* v_reuseFailAlloc_666_; 
v_reuseFailAlloc_666_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_666_, 0, v_a_660_);
v___x_665_ = v_reuseFailAlloc_666_;
goto v_reusejp_664_;
}
v_reusejp_664_:
{
return v___x_665_;
}
}
}
else
{
lean_object* v_a_668_; size_t v_sz_669_; lean_object* v___x_670_; 
v_a_668_ = lean_ctor_get(v___x_659_, 0);
lean_inc(v_a_668_);
lean_dec_ref_known(v___x_659_, 1);
v_sz_669_ = lean_array_size(v_definitionTargets_655_);
v___x_670_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_compareAt_spec__1(v_challenge_652_, v_solution_653_, v_definitionTargets_655_, v_sz_669_, v___x_658_, v_a_668_);
if (lean_obj_tag(v___x_670_) == 0)
{
lean_object* v_a_671_; lean_object* v___x_673_; uint8_t v_isShared_674_; uint8_t v_isSharedCheck_678_; 
lean_dec_ref(v_solution_653_);
lean_dec_ref(v_challenge_652_);
v_a_671_ = lean_ctor_get(v___x_670_, 0);
v_isSharedCheck_678_ = !lean_is_exclusive(v___x_670_);
if (v_isSharedCheck_678_ == 0)
{
v___x_673_ = v___x_670_;
v_isShared_674_ = v_isSharedCheck_678_;
goto v_resetjp_672_;
}
else
{
lean_inc(v_a_671_);
lean_dec(v___x_670_);
v___x_673_ = lean_box(0);
v_isShared_674_ = v_isSharedCheck_678_;
goto v_resetjp_672_;
}
v_resetjp_672_:
{
lean_object* v___x_676_; 
if (v_isShared_674_ == 0)
{
v___x_676_ = v___x_673_;
goto v_reusejp_675_;
}
else
{
lean_object* v_reuseFailAlloc_677_; 
v_reuseFailAlloc_677_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_677_, 0, v_a_671_);
v___x_676_ = v_reuseFailAlloc_677_;
goto v_reusejp_675_;
}
v_reusejp_675_:
{
return v___x_676_;
}
}
}
else
{
lean_object* v_a_679_; lean_object* v___x_680_; lean_object* v___x_681_; lean_object* v___x_682_; lean_object* v___x_683_; lean_object* v___x_684_; lean_object* v___x_685_; 
v_a_679_ = lean_ctor_get(v___x_670_, 0);
lean_inc(v_a_679_);
lean_dec_ref_known(v___x_670_, 1);
v___x_680_ = lean_obj_once(&lp_proofEnvironment_Comparator_compareAt___closed__1, &lp_proofEnvironment_Comparator_compareAt___closed__1_once, _init_lp_proofEnvironment_Comparator_compareAt___closed__1);
v___x_681_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_680_, v_definitionTargets_655_);
v___x_682_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_680_, v_theoremTargets_654_);
v___x_683_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_683_, 0, v_challenge_652_);
lean_ctor_set(v___x_683_, 1, v_solution_653_);
lean_ctor_set(v___x_683_, 2, v___x_681_);
lean_ctor_set(v___x_683_, 3, v___x_682_);
v___x_684_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_684_, 0, v_a_679_);
lean_ctor_set(v___x_684_, 1, v___x_680_);
v___x_685_ = lp_proofEnvironment_Comparator_Compare_loop(v___x_683_, v___x_684_);
lean_dec_ref_known(v___x_683_, 4);
if (lean_obj_tag(v___x_685_) == 0)
{
lean_object* v_a_686_; lean_object* v___x_688_; uint8_t v_isShared_689_; uint8_t v_isSharedCheck_693_; 
v_a_686_ = lean_ctor_get(v___x_685_, 0);
v_isSharedCheck_693_ = !lean_is_exclusive(v___x_685_);
if (v_isSharedCheck_693_ == 0)
{
v___x_688_ = v___x_685_;
v_isShared_689_ = v_isSharedCheck_693_;
goto v_resetjp_687_;
}
else
{
lean_inc(v_a_686_);
lean_dec(v___x_685_);
v___x_688_ = lean_box(0);
v_isShared_689_ = v_isSharedCheck_693_;
goto v_resetjp_687_;
}
v_resetjp_687_:
{
lean_object* v___x_691_; 
if (v_isShared_689_ == 0)
{
v___x_691_ = v___x_688_;
goto v_reusejp_690_;
}
else
{
lean_object* v_reuseFailAlloc_692_; 
v_reuseFailAlloc_692_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_692_, 0, v_a_686_);
v___x_691_ = v_reuseFailAlloc_692_;
goto v_reusejp_690_;
}
v_reusejp_690_:
{
return v___x_691_;
}
}
}
else
{
lean_object* v_a_694_; lean_object* v___x_696_; uint8_t v_isShared_697_; uint8_t v_isSharedCheck_702_; 
v_a_694_ = lean_ctor_get(v___x_685_, 0);
v_isSharedCheck_702_ = !lean_is_exclusive(v___x_685_);
if (v_isSharedCheck_702_ == 0)
{
v___x_696_ = v___x_685_;
v_isShared_697_ = v_isSharedCheck_702_;
goto v_resetjp_695_;
}
else
{
lean_inc(v_a_694_);
lean_dec(v___x_685_);
v___x_696_ = lean_box(0);
v_isShared_697_ = v_isSharedCheck_702_;
goto v_resetjp_695_;
}
v_resetjp_695_:
{
lean_object* v_fst_698_; lean_object* v___x_700_; 
v_fst_698_ = lean_ctor_get(v_a_694_, 0);
lean_inc(v_fst_698_);
lean_dec(v_a_694_);
if (v_isShared_697_ == 0)
{
lean_ctor_set(v___x_696_, 0, v_fst_698_);
v___x_700_ = v___x_696_;
goto v_reusejp_699_;
}
else
{
lean_object* v_reuseFailAlloc_701_; 
v_reuseFailAlloc_701_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_701_, 0, v_fst_698_);
v___x_700_ = v_reuseFailAlloc_701_;
goto v_reusejp_699_;
}
v_reusejp_699_:
{
return v___x_700_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_compareAt___boxed(lean_object* v_challenge_703_, lean_object* v_solution_704_, lean_object* v_theoremTargets_705_, lean_object* v_definitionTargets_706_, lean_object* v_primitive_707_){
_start:
{
lean_object* v_res_708_; 
v_res_708_ = lp_proofEnvironment_Comparator_compareAt(v_challenge_703_, v_solution_704_, v_theoremTargets_705_, v_definitionTargets_706_, v_primitive_707_);
lean_dec_ref(v_definitionTargets_706_);
lean_dec_ref(v_theoremTargets_705_);
return v_res_708_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_Comparator_Axioms(uint8_t builtin);
lean_object* initialize_proofEnvironment_Export_Parse(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_Comparator_Compare(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Comparator_Axioms(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Export_Parse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
