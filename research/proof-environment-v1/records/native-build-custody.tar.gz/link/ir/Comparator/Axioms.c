// Lean compiler output
// Module: Comparator.Axioms
// Imports: public import Init public meta import Init public import Comparator.Util public import Export.Parse
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Expr_getUsedConstants(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
lean_object* l_Lean_ConstantInfo_name(lean_object*);
lean_object* l_Lean_ConstantInfo_value_x3f(lean_object*, uint8_t);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
size_t lean_array_size(lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_finalizeImport_spec__5___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_pop(lean_object*);
static const lean_string_object lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "Illegal axiom detected: '"};
static const lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__0_value;
static const lean_string_object lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "'"};
static const lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1 = (const lean_object*)&lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1_value;
static const lean_string_object lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "Constant not found in solution '"};
static const lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__2 = (const lean_object*)&lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___lam__0___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + sizeof(size_t)*1, .m_other = 0, .m_tag = 0}, .m_objs = {(lean_object*)(size_t)(0ULL)}};
LEAN_EXPORT const lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed__const__1 = (const lean_object*)&lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed__const__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Comparator_Axioms_loop___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_Comparator_Axioms_loop_validateConst___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Comparator_Axioms_loop___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_Axioms_loop___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2_spec__2(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 38, .m_capacity = 38, .m_length = 37, .m_data = "Solution constant is not a theorem: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "Const not found in solution: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 41, .m_capacity = 41, .m_length = 40, .m_data = "Solution constant is not a definition: '"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_proofEnvironment_Comparator_checkAxioms___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_Comparator_checkAxioms___closed__0 = (const lean_object*)&lp_proofEnvironment_Comparator_checkAxioms___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_Comparator_checkAxioms___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Comparator_checkAxioms___closed__1;
static lean_once_cell_t lp_proofEnvironment_Comparator_checkAxioms___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Comparator_checkAxioms___closed__2;
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_checkAxioms(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_checkAxioms___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst(lean_object* v_n_4_, lean_object* v_a_5_, lean_object* v_a_6_){
_start:
{
lean_object* v___y_8_; lean_object* v_solution_28_; lean_object* v_legalAxioms_29_; lean_object* v_constMap_30_; lean_object* v___x_31_; 
v_solution_28_ = lean_ctor_get(v_a_5_, 0);
v_legalAxioms_29_ = lean_ctor_get(v_a_5_, 1);
v_constMap_30_ = lean_ctor_get(v_solution_28_, 0);
v___x_31_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_30_, v_n_4_);
if (lean_obj_tag(v___x_31_) == 1)
{
lean_object* v_val_32_; 
v_val_32_ = lean_ctor_get(v___x_31_, 0);
lean_inc(v_val_32_);
lean_dec_ref_known(v___x_31_, 1);
if (lean_obj_tag(v_val_32_) == 0)
{
lean_object* v_val_33_; lean_object* v___x_35_; uint8_t v_isShared_36_; uint8_t v_isSharedCheck_49_; 
v_val_33_ = lean_ctor_get(v_val_32_, 0);
v_isSharedCheck_49_ = !lean_is_exclusive(v_val_32_);
if (v_isSharedCheck_49_ == 0)
{
v___x_35_ = v_val_32_;
v_isShared_36_ = v_isSharedCheck_49_;
goto v_resetjp_34_;
}
else
{
lean_inc(v_val_33_);
lean_dec(v_val_32_);
v___x_35_ = lean_box(0);
v_isShared_36_ = v_isSharedCheck_49_;
goto v_resetjp_34_;
}
v_resetjp_34_:
{
lean_object* v_toConstantVal_37_; lean_object* v_name_38_; uint8_t v___x_39_; 
v_toConstantVal_37_ = lean_ctor_get(v_val_33_, 0);
lean_inc_ref(v_toConstantVal_37_);
lean_dec_ref(v_val_33_);
v_name_38_ = lean_ctor_get(v_toConstantVal_37_, 0);
lean_inc(v_name_38_);
lean_dec_ref(v_toConstantVal_37_);
v___x_39_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_legalAxioms_29_, v_name_38_);
lean_dec(v_name_38_);
if (v___x_39_ == 0)
{
uint8_t v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_47_; 
lean_dec_ref(v_a_6_);
v___x_40_ = 1;
v___x_41_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__0));
v___x_42_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_n_4_, v___x_40_);
v___x_43_ = lean_string_append(v___x_41_, v___x_42_);
lean_dec_ref(v___x_42_);
v___x_44_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_45_ = lean_string_append(v___x_43_, v___x_44_);
if (v_isShared_36_ == 0)
{
lean_ctor_set(v___x_35_, 0, v___x_45_);
v___x_47_ = v___x_35_;
goto v_reusejp_46_;
}
else
{
lean_object* v_reuseFailAlloc_48_; 
v_reuseFailAlloc_48_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_48_, 0, v___x_45_);
v___x_47_ = v_reuseFailAlloc_48_;
goto v_reusejp_46_;
}
v_reusejp_46_:
{
return v___x_47_;
}
}
else
{
lean_del_object(v___x_35_);
v___y_8_ = v_a_6_;
goto v___jp_7_;
}
}
}
else
{
lean_dec(v_val_32_);
v___y_8_ = v_a_6_;
goto v___jp_7_;
}
}
else
{
lean_object* v___x_50_; uint8_t v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; 
lean_dec(v___x_31_);
lean_dec_ref(v_a_6_);
v___x_50_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__2));
v___x_51_ = 1;
v___x_52_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_n_4_, v___x_51_);
v___x_53_ = lean_string_append(v___x_50_, v___x_52_);
lean_dec_ref(v___x_52_);
v___x_54_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_55_ = lean_string_append(v___x_53_, v___x_54_);
v___x_56_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_56_, 0, v___x_55_);
return v___x_56_;
}
v___jp_7_:
{
lean_object* v_worklist_9_; lean_object* v_checked_10_; uint8_t v___x_11_; 
v_worklist_9_ = lean_ctor_get(v___y_8_, 0);
v_checked_10_ = lean_ctor_get(v___y_8_, 1);
v___x_11_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_checked_10_, v_n_4_);
if (v___x_11_ == 0)
{
lean_object* v___x_13_; uint8_t v_isShared_14_; uint8_t v_isSharedCheck_22_; 
lean_inc_ref(v_checked_10_);
lean_inc_ref(v_worklist_9_);
v_isSharedCheck_22_ = !lean_is_exclusive(v___y_8_);
if (v_isSharedCheck_22_ == 0)
{
lean_object* v_unused_23_; lean_object* v_unused_24_; 
v_unused_23_ = lean_ctor_get(v___y_8_, 1);
lean_dec(v_unused_23_);
v_unused_24_ = lean_ctor_get(v___y_8_, 0);
lean_dec(v_unused_24_);
v___x_13_ = v___y_8_;
v_isShared_14_ = v_isSharedCheck_22_;
goto v_resetjp_12_;
}
else
{
lean_dec(v___y_8_);
v___x_13_ = lean_box(0);
v_isShared_14_ = v_isSharedCheck_22_;
goto v_resetjp_12_;
}
v_resetjp_12_:
{
lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_18_; 
v___x_15_ = lean_box(0);
v___x_16_ = lean_array_push(v_worklist_9_, v_n_4_);
if (v_isShared_14_ == 0)
{
lean_ctor_set(v___x_13_, 0, v___x_16_);
v___x_18_ = v___x_13_;
goto v_reusejp_17_;
}
else
{
lean_object* v_reuseFailAlloc_21_; 
v_reuseFailAlloc_21_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_21_, 0, v___x_16_);
lean_ctor_set(v_reuseFailAlloc_21_, 1, v_checked_10_);
v___x_18_ = v_reuseFailAlloc_21_;
goto v_reusejp_17_;
}
v_reusejp_17_:
{
lean_object* v___x_19_; lean_object* v___x_20_; 
v___x_19_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_19_, 0, v___x_15_);
lean_ctor_set(v___x_19_, 1, v___x_18_);
v___x_20_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_20_, 0, v___x_19_);
return v___x_20_;
}
}
}
else
{
lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; 
lean_dec(v_n_4_);
v___x_25_ = lean_box(0);
v___x_26_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_26_, 0, v___x_25_);
lean_ctor_set(v___x_26_, 1, v___y_8_);
v___x_27_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_27_, 0, v___x_26_);
return v___x_27_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop_validateConst___boxed(lean_object* v_n_57_, lean_object* v_a_58_, lean_object* v_a_59_){
_start:
{
lean_object* v_res_60_; 
v_res_60_ = lp_proofEnvironment_Comparator_Axioms_loop_validateConst(v_n_57_, v_a_58_, v_a_59_);
lean_dec_ref(v_a_58_);
return v_res_60_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1(lean_object* v_f_61_, lean_object* v_as_62_, lean_object* v___y_63_, lean_object* v___y_64_){
_start:
{
if (lean_obj_tag(v_as_62_) == 0)
{
lean_object* v___x_65_; lean_object* v___x_66_; lean_object* v___x_67_; 
lean_dec_ref(v_f_61_);
v___x_65_ = lean_box(0);
v___x_66_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_66_, 0, v___x_65_);
lean_ctor_set(v___x_66_, 1, v___y_64_);
v___x_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_67_, 0, v___x_66_);
return v___x_67_;
}
else
{
lean_object* v_head_68_; lean_object* v_tail_69_; lean_object* v___x_70_; 
v_head_68_ = lean_ctor_get(v_as_62_, 0);
lean_inc(v_head_68_);
v_tail_69_ = lean_ctor_get(v_as_62_, 1);
lean_inc(v_tail_69_);
lean_dec_ref_known(v_as_62_, 2);
lean_inc_ref(v_f_61_);
lean_inc_ref(v___y_63_);
v___x_70_ = lean_apply_3(v_f_61_, v_head_68_, v___y_63_, v___y_64_);
if (lean_obj_tag(v___x_70_) == 0)
{
lean_dec(v_tail_69_);
lean_dec_ref(v_f_61_);
return v___x_70_;
}
else
{
lean_object* v_a_71_; lean_object* v_snd_72_; 
v_a_71_ = lean_ctor_get(v___x_70_, 0);
lean_inc(v_a_71_);
lean_dec_ref_known(v___x_70_, 1);
v_snd_72_ = lean_ctor_get(v_a_71_, 1);
lean_inc(v_snd_72_);
lean_dec(v_a_71_);
v_as_62_ = v_tail_69_;
v___y_64_ = v_snd_72_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1___boxed(lean_object* v_f_74_, lean_object* v_as_75_, lean_object* v___y_76_, lean_object* v___y_77_){
_start:
{
lean_object* v_res_78_; 
v_res_78_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1(v_f_74_, v_as_75_, v___y_76_, v___y_77_);
lean_dec_ref(v___y_76_);
return v_res_78_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___lam__0(lean_object* v___x_79_, lean_object* v___y_80_, lean_object* v___y_81_){
_start:
{
lean_object* v___x_82_; lean_object* v___x_83_; 
v___x_82_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_82_, 0, v___x_79_);
lean_ctor_set(v___x_82_, 1, v___y_81_);
v___x_83_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_83_, 0, v___x_82_);
return v___x_83_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___lam__0___boxed(lean_object* v___x_84_, lean_object* v___y_85_, lean_object* v___y_86_){
_start:
{
lean_object* v_res_87_; 
v_res_87_ = lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___lam__0(v___x_84_, v___y_85_, v___y_86_);
lean_dec_ref(v___y_85_);
return v_res_87_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(lean_object* v_f_88_, lean_object* v_as_89_, size_t v_i_90_, size_t v_stop_91_, lean_object* v_b_92_, lean_object* v___y_93_, lean_object* v___y_94_){
_start:
{
uint8_t v___x_95_; 
v___x_95_ = lean_usize_dec_eq(v_i_90_, v_stop_91_);
if (v___x_95_ == 0)
{
lean_object* v___x_96_; lean_object* v___x_97_; 
v___x_96_ = lean_array_uget_borrowed(v_as_89_, v_i_90_);
lean_inc_ref(v_f_88_);
lean_inc_ref(v___y_93_);
lean_inc(v___x_96_);
v___x_97_ = lean_apply_3(v_f_88_, v___x_96_, v___y_93_, v___y_94_);
if (lean_obj_tag(v___x_97_) == 0)
{
lean_dec_ref(v_f_88_);
return v___x_97_;
}
else
{
lean_object* v_a_98_; lean_object* v_fst_99_; lean_object* v_snd_100_; size_t v___x_101_; size_t v___x_102_; 
v_a_98_ = lean_ctor_get(v___x_97_, 0);
lean_inc(v_a_98_);
lean_dec_ref_known(v___x_97_, 1);
v_fst_99_ = lean_ctor_get(v_a_98_, 0);
lean_inc(v_fst_99_);
v_snd_100_ = lean_ctor_get(v_a_98_, 1);
lean_inc(v_snd_100_);
lean_dec(v_a_98_);
v___x_101_ = ((size_t)1ULL);
v___x_102_ = lean_usize_add(v_i_90_, v___x_101_);
v_i_90_ = v___x_102_;
v_b_92_ = v_fst_99_;
v___y_94_ = v_snd_100_;
goto _start;
}
}
else
{
lean_object* v___x_104_; lean_object* v___x_105_; 
lean_dec_ref(v_f_88_);
v___x_104_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_104_, 0, v_b_92_);
lean_ctor_set(v___x_104_, 1, v___y_94_);
v___x_105_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_105_, 0, v___x_104_);
return v___x_105_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0___boxed(lean_object* v_f_106_, lean_object* v_as_107_, lean_object* v_i_108_, lean_object* v_stop_109_, lean_object* v_b_110_, lean_object* v___y_111_, lean_object* v___y_112_){
_start:
{
size_t v_i_boxed_113_; size_t v_stop_boxed_114_; lean_object* v_res_115_; 
v_i_boxed_113_ = lean_unbox_usize(v_i_108_);
lean_dec(v_i_108_);
v_stop_boxed_114_ = lean_unbox_usize(v_stop_109_);
lean_dec(v_stop_109_);
v_res_115_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(v_f_106_, v_as_107_, v_i_boxed_113_, v_stop_boxed_114_, v_b_110_, v___y_111_, v___y_112_);
lean_dec_ref(v___y_111_);
lean_dec_ref(v_as_107_);
return v_res_115_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__2(lean_object* v_f_116_, lean_object* v_as_117_, lean_object* v___y_118_, lean_object* v___y_119_){
_start:
{
if (lean_obj_tag(v_as_117_) == 0)
{
lean_object* v___x_120_; lean_object* v___x_121_; lean_object* v___x_122_; 
lean_dec_ref(v_f_116_);
v___x_120_ = lean_box(0);
v___x_121_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_121_, 0, v___x_120_);
lean_ctor_set(v___x_121_, 1, v___y_119_);
v___x_122_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_122_, 0, v___x_121_);
return v___x_122_;
}
else
{
lean_object* v_head_123_; lean_object* v_tail_124_; lean_object* v___y_126_; lean_object* v_ctor_130_; lean_object* v_rhs_131_; lean_object* v___x_132_; 
v_head_123_ = lean_ctor_get(v_as_117_, 0);
lean_inc(v_head_123_);
v_tail_124_ = lean_ctor_get(v_as_117_, 1);
lean_inc(v_tail_124_);
lean_dec_ref_known(v_as_117_, 2);
v_ctor_130_ = lean_ctor_get(v_head_123_, 0);
lean_inc(v_ctor_130_);
v_rhs_131_ = lean_ctor_get(v_head_123_, 2);
lean_inc_ref(v_rhs_131_);
lean_dec(v_head_123_);
lean_inc_ref(v_f_116_);
lean_inc_ref(v___y_118_);
v___x_132_ = lean_apply_3(v_f_116_, v_ctor_130_, v___y_118_, v___y_119_);
if (lean_obj_tag(v___x_132_) == 0)
{
lean_dec_ref(v_rhs_131_);
lean_dec(v_tail_124_);
lean_dec_ref(v_f_116_);
return v___x_132_;
}
else
{
lean_object* v_a_133_; lean_object* v_snd_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; uint8_t v___x_138_; 
v_a_133_ = lean_ctor_get(v___x_132_, 0);
lean_inc(v_a_133_);
lean_dec_ref_known(v___x_132_, 1);
v_snd_134_ = lean_ctor_get(v_a_133_, 1);
lean_inc(v_snd_134_);
lean_dec(v_a_133_);
v___x_135_ = lean_unsigned_to_nat(0u);
v___x_136_ = l_Lean_Expr_getUsedConstants(v_rhs_131_);
v___x_137_ = lean_array_get_size(v___x_136_);
v___x_138_ = lean_nat_dec_lt(v___x_135_, v___x_137_);
if (v___x_138_ == 0)
{
lean_dec_ref(v___x_136_);
v_as_117_ = v_tail_124_;
v___y_119_ = v_snd_134_;
goto _start;
}
else
{
lean_object* v___x_140_; uint8_t v___x_141_; 
v___x_140_ = lean_box(0);
v___x_141_ = lean_nat_dec_le(v___x_137_, v___x_137_);
if (v___x_141_ == 0)
{
if (v___x_138_ == 0)
{
lean_dec_ref(v___x_136_);
v_as_117_ = v_tail_124_;
v___y_119_ = v_snd_134_;
goto _start;
}
else
{
size_t v___x_143_; size_t v___x_144_; lean_object* v___x_145_; 
v___x_143_ = ((size_t)0ULL);
v___x_144_ = lean_usize_of_nat(v___x_137_);
lean_inc_ref(v_f_116_);
v___x_145_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(v_f_116_, v___x_136_, v___x_143_, v___x_144_, v___x_140_, v___y_118_, v_snd_134_);
lean_dec_ref(v___x_136_);
v___y_126_ = v___x_145_;
goto v___jp_125_;
}
}
else
{
size_t v___x_146_; size_t v___x_147_; lean_object* v___x_148_; 
v___x_146_ = ((size_t)0ULL);
v___x_147_ = lean_usize_of_nat(v___x_137_);
lean_inc_ref(v_f_116_);
v___x_148_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(v_f_116_, v___x_136_, v___x_146_, v___x_147_, v___x_140_, v___y_118_, v_snd_134_);
lean_dec_ref(v___x_136_);
v___y_126_ = v___x_148_;
goto v___jp_125_;
}
}
}
v___jp_125_:
{
if (lean_obj_tag(v___y_126_) == 0)
{
lean_dec(v_tail_124_);
lean_dec_ref(v_f_116_);
return v___y_126_;
}
else
{
lean_object* v_a_127_; lean_object* v_snd_128_; 
v_a_127_ = lean_ctor_get(v___y_126_, 0);
lean_inc(v_a_127_);
lean_dec_ref_known(v___y_126_, 1);
v_snd_128_ = lean_ctor_get(v_a_127_, 1);
lean_inc(v_snd_128_);
lean_dec(v_a_127_);
v_as_117_ = v_tail_124_;
v___y_119_ = v_snd_128_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__2___boxed(lean_object* v_f_149_, lean_object* v_as_150_, lean_object* v___y_151_, lean_object* v___y_152_){
_start:
{
lean_object* v_res_153_; 
v_res_153_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__2(v_f_149_, v_as_150_, v___y_151_, v___y_152_);
lean_dec_ref(v___y_151_);
return v_res_153_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0(lean_object* v_info_158_, lean_object* v_f_159_, lean_object* v___y_160_, lean_object* v___y_161_){
_start:
{
lean_object* v___y_163_; lean_object* v___y_164_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___y_185_; lean_object* v___x_211_; lean_object* v___x_212_; uint8_t v___x_213_; 
v___x_181_ = l_Lean_ConstantInfo_type(v_info_158_);
v___x_182_ = l_Lean_Expr_getUsedConstants(v___x_181_);
v___x_183_ = lean_unsigned_to_nat(0u);
v___x_211_ = lean_array_get_size(v___x_182_);
v___x_212_ = lean_box(0);
v___x_213_ = lean_nat_dec_lt(v___x_183_, v___x_211_);
if (v___x_213_ == 0)
{
lean_object* v___f_214_; 
lean_dec_ref(v___x_182_);
v___f_214_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___closed__0));
v___y_185_ = v___f_214_;
goto v___jp_184_;
}
else
{
uint8_t v___x_215_; 
v___x_215_ = lean_nat_dec_le(v___x_211_, v___x_211_);
if (v___x_215_ == 0)
{
if (v___x_213_ == 0)
{
lean_object* v___f_216_; 
lean_dec_ref(v___x_182_);
v___f_216_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___closed__0));
v___y_185_ = v___f_216_;
goto v___jp_184_;
}
else
{
size_t v___x_217_; lean_object* v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; 
v___x_217_ = lean_usize_of_nat(v___x_211_);
v___x_218_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed__const__1));
v___x_219_ = lean_box_usize(v___x_217_);
lean_inc_ref(v_f_159_);
v___x_220_ = lean_alloc_closure((void*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0___boxed), 7, 5);
lean_closure_set(v___x_220_, 0, v_f_159_);
lean_closure_set(v___x_220_, 1, v___x_182_);
lean_closure_set(v___x_220_, 2, v___x_218_);
lean_closure_set(v___x_220_, 3, v___x_219_);
lean_closure_set(v___x_220_, 4, v___x_212_);
v___y_185_ = v___x_220_;
goto v___jp_184_;
}
}
else
{
size_t v___x_221_; lean_object* v___x_222_; lean_object* v___x_223_; lean_object* v___x_224_; 
v___x_221_ = lean_usize_of_nat(v___x_211_);
v___x_222_ = ((lean_object*)(lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed__const__1));
v___x_223_ = lean_box_usize(v___x_221_);
lean_inc_ref(v_f_159_);
v___x_224_ = lean_alloc_closure((void*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0___boxed), 7, 5);
lean_closure_set(v___x_224_, 0, v_f_159_);
lean_closure_set(v___x_224_, 1, v___x_182_);
lean_closure_set(v___x_224_, 2, v___x_222_);
lean_closure_set(v___x_224_, 3, v___x_223_);
lean_closure_set(v___x_224_, 4, v___x_212_);
v___y_185_ = v___x_224_;
goto v___jp_184_;
}
}
v___jp_162_:
{
switch(lean_obj_tag(v_info_158_))
{
case 5:
{
lean_object* v_val_165_; lean_object* v_all_166_; lean_object* v_ctors_167_; lean_object* v___x_168_; 
v_val_165_ = lean_ctor_get(v_info_158_, 0);
lean_inc_ref(v_val_165_);
lean_dec_ref_known(v_info_158_, 1);
v_all_166_ = lean_ctor_get(v_val_165_, 3);
lean_inc(v_all_166_);
v_ctors_167_ = lean_ctor_get(v_val_165_, 4);
lean_inc(v_ctors_167_);
lean_dec_ref(v_val_165_);
lean_inc_ref(v_f_159_);
v___x_168_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1(v_f_159_, v_ctors_167_, v___y_163_, v___y_164_);
if (lean_obj_tag(v___x_168_) == 0)
{
lean_dec(v_all_166_);
lean_dec_ref(v_f_159_);
return v___x_168_;
}
else
{
lean_object* v_a_169_; lean_object* v_snd_170_; lean_object* v___x_171_; 
v_a_169_ = lean_ctor_get(v___x_168_, 0);
lean_inc(v_a_169_);
lean_dec_ref_known(v___x_168_, 1);
v_snd_170_ = lean_ctor_get(v_a_169_, 1);
lean_inc(v_snd_170_);
lean_dec(v_a_169_);
v___x_171_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__1(v_f_159_, v_all_166_, v___y_163_, v_snd_170_);
return v___x_171_;
}
}
case 6:
{
lean_object* v_val_172_; lean_object* v_induct_173_; lean_object* v___x_174_; 
v_val_172_ = lean_ctor_get(v_info_158_, 0);
lean_inc_ref(v_val_172_);
lean_dec_ref_known(v_info_158_, 1);
v_induct_173_ = lean_ctor_get(v_val_172_, 1);
lean_inc(v_induct_173_);
lean_dec_ref(v_val_172_);
lean_inc_ref(v___y_163_);
v___x_174_ = lean_apply_3(v_f_159_, v_induct_173_, v___y_163_, v___y_164_);
return v___x_174_;
}
case 7:
{
lean_object* v_val_175_; lean_object* v_rules_176_; lean_object* v___x_177_; 
v_val_175_ = lean_ctor_get(v_info_158_, 0);
lean_inc_ref(v_val_175_);
lean_dec_ref_known(v_info_158_, 1);
v_rules_176_ = lean_ctor_get(v_val_175_, 6);
lean_inc(v_rules_176_);
lean_dec_ref(v_val_175_);
v___x_177_ = lp_proofEnvironment_List_forM___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__2(v_f_159_, v_rules_176_, v___y_163_, v___y_164_);
return v___x_177_;
}
default: 
{
lean_object* v___x_178_; lean_object* v___x_179_; lean_object* v___x_180_; 
lean_dec_ref(v_f_159_);
lean_dec_ref(v_info_158_);
v___x_178_ = lean_box(0);
v___x_179_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_179_, 0, v___x_178_);
lean_ctor_set(v___x_179_, 1, v___y_164_);
v___x_180_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_180_, 0, v___x_179_);
return v___x_180_;
}
}
}
v___jp_184_:
{
lean_object* v___x_186_; 
lean_inc_ref(v___y_160_);
v___x_186_ = lean_apply_2(v___y_185_, v___y_160_, v___y_161_);
if (lean_obj_tag(v___x_186_) == 0)
{
lean_dec_ref(v_f_159_);
lean_dec_ref(v_info_158_);
return v___x_186_;
}
else
{
lean_object* v_a_187_; lean_object* v_snd_188_; lean_object* v___x_189_; lean_object* v___x_190_; 
v_a_187_ = lean_ctor_get(v___x_186_, 0);
lean_inc(v_a_187_);
lean_dec_ref_known(v___x_186_, 1);
v_snd_188_ = lean_ctor_get(v_a_187_, 1);
lean_inc(v_snd_188_);
lean_dec(v_a_187_);
v___x_189_ = l_Lean_ConstantInfo_name(v_info_158_);
lean_inc_ref(v_f_159_);
lean_inc_ref(v___y_160_);
v___x_190_ = lean_apply_3(v_f_159_, v___x_189_, v___y_160_, v_snd_188_);
if (lean_obj_tag(v___x_190_) == 0)
{
lean_dec_ref(v_f_159_);
lean_dec_ref(v_info_158_);
return v___x_190_;
}
else
{
lean_object* v_a_191_; lean_object* v_snd_192_; uint8_t v___x_193_; lean_object* v___x_194_; 
v_a_191_ = lean_ctor_get(v___x_190_, 0);
lean_inc(v_a_191_);
lean_dec_ref_known(v___x_190_, 1);
v_snd_192_ = lean_ctor_get(v_a_191_, 1);
lean_inc(v_snd_192_);
lean_dec(v_a_191_);
v___x_193_ = 1;
lean_inc_ref(v_info_158_);
v___x_194_ = l_Lean_ConstantInfo_value_x3f(v_info_158_, v___x_193_);
if (lean_obj_tag(v___x_194_) == 1)
{
lean_object* v_val_195_; lean_object* v___x_196_; lean_object* v___x_197_; uint8_t v___x_198_; 
v_val_195_ = lean_ctor_get(v___x_194_, 0);
lean_inc(v_val_195_);
lean_dec_ref_known(v___x_194_, 1);
v___x_196_ = l_Lean_Expr_getUsedConstants(v_val_195_);
v___x_197_ = lean_array_get_size(v___x_196_);
v___x_198_ = lean_nat_dec_lt(v___x_183_, v___x_197_);
if (v___x_198_ == 0)
{
lean_dec_ref(v___x_196_);
v___y_163_ = v___y_160_;
v___y_164_ = v_snd_192_;
goto v___jp_162_;
}
else
{
lean_object* v___x_199_; uint8_t v___x_200_; 
v___x_199_ = lean_box(0);
v___x_200_ = lean_nat_dec_le(v___x_197_, v___x_197_);
if (v___x_200_ == 0)
{
if (v___x_198_ == 0)
{
lean_dec_ref(v___x_196_);
v___y_163_ = v___y_160_;
v___y_164_ = v_snd_192_;
goto v___jp_162_;
}
else
{
size_t v___x_201_; size_t v___x_202_; lean_object* v___x_203_; 
v___x_201_ = ((size_t)0ULL);
v___x_202_ = lean_usize_of_nat(v___x_197_);
lean_inc_ref(v_f_159_);
v___x_203_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(v_f_159_, v___x_196_, v___x_201_, v___x_202_, v___x_199_, v___y_160_, v_snd_192_);
lean_dec_ref(v___x_196_);
if (lean_obj_tag(v___x_203_) == 0)
{
lean_dec_ref(v_f_159_);
lean_dec_ref(v_info_158_);
return v___x_203_;
}
else
{
lean_object* v_a_204_; lean_object* v_snd_205_; 
v_a_204_ = lean_ctor_get(v___x_203_, 0);
lean_inc(v_a_204_);
lean_dec_ref_known(v___x_203_, 1);
v_snd_205_ = lean_ctor_get(v_a_204_, 1);
lean_inc(v_snd_205_);
lean_dec(v_a_204_);
v___y_163_ = v___y_160_;
v___y_164_ = v_snd_205_;
goto v___jp_162_;
}
}
}
else
{
size_t v___x_206_; size_t v___x_207_; lean_object* v___x_208_; 
v___x_206_ = ((size_t)0ULL);
v___x_207_ = lean_usize_of_nat(v___x_197_);
lean_inc_ref(v_f_159_);
v___x_208_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0_spec__0(v_f_159_, v___x_196_, v___x_206_, v___x_207_, v___x_199_, v___y_160_, v_snd_192_);
lean_dec_ref(v___x_196_);
if (lean_obj_tag(v___x_208_) == 0)
{
lean_dec_ref(v_f_159_);
lean_dec_ref(v_info_158_);
return v___x_208_;
}
else
{
lean_object* v_a_209_; lean_object* v_snd_210_; 
v_a_209_ = lean_ctor_get(v___x_208_, 0);
lean_inc(v_a_209_);
lean_dec_ref_known(v___x_208_, 1);
v_snd_210_ = lean_ctor_get(v_a_209_, 1);
lean_inc(v_snd_210_);
lean_dec(v_a_209_);
v___y_163_ = v___y_160_;
v___y_164_ = v_snd_210_;
goto v___jp_162_;
}
}
}
}
else
{
lean_dec(v___x_194_);
v___y_163_ = v___y_160_;
v___y_164_ = v_snd_192_;
goto v___jp_162_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0___boxed(lean_object* v_info_225_, lean_object* v_f_226_, lean_object* v___y_227_, lean_object* v___y_228_){
_start:
{
lean_object* v_res_229_; 
v_res_229_ = lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0(v_info_225_, v_f_226_, v___y_227_, v___y_228_);
lean_dec_ref(v___y_227_);
return v_res_229_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop(lean_object* v_a_231_, lean_object* v_a_232_){
_start:
{
lean_object* v_worklist_233_; lean_object* v_checked_234_; lean_object* v___x_235_; lean_object* v___x_236_; uint8_t v___x_237_; 
v_worklist_233_ = lean_ctor_get(v_a_232_, 0);
v_checked_234_ = lean_ctor_get(v_a_232_, 1);
v___x_235_ = lean_array_get_size(v_worklist_233_);
v___x_236_ = lean_unsigned_to_nat(0u);
v___x_237_ = lean_nat_dec_eq(v___x_235_, v___x_236_);
if (v___x_237_ == 0)
{
lean_object* v___x_239_; uint8_t v_isShared_240_; uint8_t v_isSharedCheck_278_; 
lean_inc_ref(v_checked_234_);
lean_inc_ref(v_worklist_233_);
v_isSharedCheck_278_ = !lean_is_exclusive(v_a_232_);
if (v_isSharedCheck_278_ == 0)
{
lean_object* v_unused_279_; lean_object* v_unused_280_; 
v_unused_279_ = lean_ctor_get(v_a_232_, 1);
lean_dec(v_unused_279_);
v_unused_280_ = lean_ctor_get(v_a_232_, 0);
lean_dec(v_unused_280_);
v___x_239_ = v_a_232_;
v_isShared_240_ = v_isSharedCheck_278_;
goto v_resetjp_238_;
}
else
{
lean_dec(v_a_232_);
v___x_239_ = lean_box(0);
v_isShared_240_ = v_isSharedCheck_278_;
goto v_resetjp_238_;
}
v_resetjp_238_:
{
lean_object* v___x_241_; lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; lean_object* v___x_247_; 
v___x_241_ = lean_box(0);
v___x_242_ = lean_unsigned_to_nat(1u);
v___x_243_ = lean_nat_sub(v___x_235_, v___x_242_);
v___x_244_ = lean_array_get(v___x_241_, v_worklist_233_, v___x_243_);
lean_dec(v___x_243_);
v___x_245_ = lean_array_pop(v_worklist_233_);
lean_inc_ref(v_checked_234_);
if (v_isShared_240_ == 0)
{
lean_ctor_set(v___x_239_, 0, v___x_245_);
v___x_247_ = v___x_239_;
goto v_reusejp_246_;
}
else
{
lean_object* v_reuseFailAlloc_277_; 
v_reuseFailAlloc_277_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_277_, 0, v___x_245_);
lean_ctor_set(v_reuseFailAlloc_277_, 1, v_checked_234_);
v___x_247_ = v_reuseFailAlloc_277_;
goto v_reusejp_246_;
}
v_reusejp_246_:
{
uint8_t v___x_248_; 
v___x_248_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_Environment_areRealizationsEnabledForConst_spec__0___redArg(v_checked_234_, v___x_244_);
lean_dec_ref(v_checked_234_);
if (v___x_248_ == 0)
{
lean_object* v_solution_249_; lean_object* v_constMap_250_; lean_object* v___x_251_; 
v_solution_249_ = lean_ctor_get(v_a_231_, 0);
v_constMap_250_ = lean_ctor_get(v_solution_249_, 0);
v___x_251_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_250_, v___x_244_);
if (lean_obj_tag(v___x_251_) == 1)
{
lean_object* v_val_252_; lean_object* v___x_253_; lean_object* v___x_254_; 
v_val_252_ = lean_ctor_get(v___x_251_, 0);
lean_inc(v_val_252_);
lean_dec_ref_known(v___x_251_, 1);
v___x_253_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop___closed__0));
v___x_254_ = lp_proofEnvironment_Comparator_runForUsedConsts___at___00Comparator_Axioms_loop_spec__0(v_val_252_, v___x_253_, v_a_231_, v___x_247_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_dec(v___x_244_);
return v___x_254_;
}
else
{
lean_object* v_a_255_; lean_object* v_snd_256_; lean_object* v_worklist_257_; lean_object* v_checked_258_; lean_object* v___x_260_; uint8_t v_isShared_261_; uint8_t v_isSharedCheck_268_; 
v_a_255_ = lean_ctor_get(v___x_254_, 0);
lean_inc(v_a_255_);
lean_dec_ref_known(v___x_254_, 1);
v_snd_256_ = lean_ctor_get(v_a_255_, 1);
lean_inc(v_snd_256_);
lean_dec(v_a_255_);
v_worklist_257_ = lean_ctor_get(v_snd_256_, 0);
v_checked_258_ = lean_ctor_get(v_snd_256_, 1);
v_isSharedCheck_268_ = !lean_is_exclusive(v_snd_256_);
if (v_isSharedCheck_268_ == 0)
{
v___x_260_ = v_snd_256_;
v_isShared_261_ = v_isSharedCheck_268_;
goto v_resetjp_259_;
}
else
{
lean_inc(v_checked_258_);
lean_inc(v_worklist_257_);
lean_dec(v_snd_256_);
v___x_260_ = lean_box(0);
v_isShared_261_ = v_isSharedCheck_268_;
goto v_resetjp_259_;
}
v_resetjp_259_:
{
lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v___x_265_; 
v___x_262_ = lean_box(0);
v___x_263_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_finalizeImport_spec__5___redArg(v_checked_258_, v___x_244_, v___x_262_);
if (v_isShared_261_ == 0)
{
lean_ctor_set(v___x_260_, 1, v___x_263_);
v___x_265_ = v___x_260_;
goto v_reusejp_264_;
}
else
{
lean_object* v_reuseFailAlloc_267_; 
v_reuseFailAlloc_267_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_267_, 0, v_worklist_257_);
lean_ctor_set(v_reuseFailAlloc_267_, 1, v___x_263_);
v___x_265_ = v_reuseFailAlloc_267_;
goto v_reusejp_264_;
}
v_reusejp_264_:
{
v_a_232_ = v___x_265_;
goto _start;
}
}
}
}
else
{
lean_object* v___x_269_; uint8_t v___x_270_; lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_275_; 
lean_dec(v___x_251_);
lean_dec_ref(v___x_247_);
v___x_269_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__2));
v___x_270_ = 1;
v___x_271_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_244_, v___x_270_);
v___x_272_ = lean_string_append(v___x_269_, v___x_271_);
lean_dec_ref(v___x_271_);
v___x_273_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_274_ = lean_string_append(v___x_272_, v___x_273_);
v___x_275_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_275_, 0, v___x_274_);
return v___x_275_;
}
}
else
{
lean_dec(v___x_244_);
v_a_232_ = v___x_247_;
goto _start;
}
}
}
}
else
{
lean_object* v___x_281_; lean_object* v___x_282_; lean_object* v___x_283_; 
v___x_281_ = lean_box(0);
v___x_282_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_282_, 0, v___x_281_);
lean_ctor_set(v___x_282_, 1, v_a_232_);
v___x_283_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_283_, 0, v___x_282_);
return v___x_283_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_Axioms_loop___boxed(lean_object* v_a_284_, lean_object* v_a_285_){
_start:
{
lean_object* v_res_286_; 
v_res_286_ = lp_proofEnvironment_Comparator_Axioms_loop(v_a_284_, v_a_285_);
lean_dec_ref(v_a_284_);
return v_res_286_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2_spec__2(lean_object* v_as_287_, size_t v_sz_288_, size_t v_i_289_, lean_object* v_b_290_){
_start:
{
uint8_t v___x_291_; 
v___x_291_ = lean_usize_dec_lt(v_i_289_, v_sz_288_);
if (v___x_291_ == 0)
{
return v_b_290_;
}
else
{
lean_object* v_a_292_; lean_object* v___x_293_; lean_object* v_r_294_; size_t v___x_295_; size_t v___x_296_; 
v_a_292_ = lean_array_uget_borrowed(v_as_287_, v_i_289_);
v___x_293_ = lean_box(0);
lean_inc(v_a_292_);
v_r_294_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_finalizeImport_spec__5___redArg(v_b_290_, v_a_292_, v___x_293_);
v___x_295_ = ((size_t)1ULL);
v___x_296_ = lean_usize_add(v_i_289_, v___x_295_);
v_i_289_ = v___x_296_;
v_b_290_ = v_r_294_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2_spec__2___boxed(lean_object* v_as_298_, lean_object* v_sz_299_, lean_object* v_i_300_, lean_object* v_b_301_){
_start:
{
size_t v_sz_boxed_302_; size_t v_i_boxed_303_; lean_object* v_res_304_; 
v_sz_boxed_302_ = lean_unbox_usize(v_sz_299_);
lean_dec(v_sz_299_);
v_i_boxed_303_ = lean_unbox_usize(v_i_300_);
lean_dec(v_i_300_);
v_res_304_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2_spec__2(v_as_298_, v_sz_boxed_302_, v_i_boxed_303_, v_b_301_);
lean_dec_ref(v_as_298_);
return v_res_304_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(lean_object* v_m_305_, lean_object* v_l_306_){
_start:
{
size_t v_sz_307_; size_t v___x_308_; lean_object* v___x_309_; 
v_sz_307_ = lean_array_size(v_l_306_);
v___x_308_ = ((size_t)0ULL);
v___x_309_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2_spec__2(v_l_306_, v_sz_307_, v___x_308_, v_m_305_);
return v___x_309_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2___boxed(lean_object* v_m_310_, lean_object* v_l_311_){
_start:
{
lean_object* v_res_312_; 
v_res_312_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v_m_310_, v_l_311_);
lean_dec_ref(v_l_311_);
return v_res_312_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0(lean_object* v_solution_315_, lean_object* v_as_316_, size_t v_sz_317_, size_t v_i_318_, lean_object* v_b_319_){
_start:
{
uint8_t v___x_320_; 
v___x_320_ = lean_usize_dec_lt(v_i_318_, v_sz_317_);
if (v___x_320_ == 0)
{
lean_object* v___x_321_; 
v___x_321_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_321_, 0, v_b_319_);
return v___x_321_;
}
else
{
lean_object* v_constMap_322_; lean_object* v_a_323_; lean_object* v___x_324_; 
v_constMap_322_ = lean_ctor_get(v_solution_315_, 0);
v_a_323_ = lean_array_uget_borrowed(v_as_316_, v_i_318_);
v___x_324_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_322_, v_a_323_);
if (lean_obj_tag(v___x_324_) == 1)
{
lean_object* v_val_325_; lean_object* v___x_327_; uint8_t v_isShared_328_; uint8_t v_isSharedCheck_344_; 
v_val_325_ = lean_ctor_get(v___x_324_, 0);
v_isSharedCheck_344_ = !lean_is_exclusive(v___x_324_);
if (v_isSharedCheck_344_ == 0)
{
v___x_327_ = v___x_324_;
v_isShared_328_ = v_isSharedCheck_344_;
goto v_resetjp_326_;
}
else
{
lean_inc(v_val_325_);
lean_dec(v___x_324_);
v___x_327_ = lean_box(0);
v_isShared_328_ = v_isSharedCheck_344_;
goto v_resetjp_326_;
}
v_resetjp_326_:
{
if (lean_obj_tag(v_val_325_) == 2)
{
lean_object* v_val_329_; lean_object* v_toConstantVal_330_; lean_object* v_name_331_; lean_object* v___x_332_; size_t v___x_333_; size_t v___x_334_; 
lean_del_object(v___x_327_);
v_val_329_ = lean_ctor_get(v_val_325_, 0);
lean_inc_ref(v_val_329_);
lean_dec_ref_known(v_val_325_, 1);
v_toConstantVal_330_ = lean_ctor_get(v_val_329_, 0);
lean_inc_ref(v_toConstantVal_330_);
lean_dec_ref(v_val_329_);
v_name_331_ = lean_ctor_get(v_toConstantVal_330_, 0);
lean_inc(v_name_331_);
lean_dec_ref(v_toConstantVal_330_);
v___x_332_ = lean_array_push(v_b_319_, v_name_331_);
v___x_333_ = ((size_t)1ULL);
v___x_334_ = lean_usize_add(v_i_318_, v___x_333_);
v_i_318_ = v___x_334_;
v_b_319_ = v___x_332_;
goto _start;
}
else
{
lean_object* v___x_336_; lean_object* v___x_337_; lean_object* v___x_338_; lean_object* v___x_339_; lean_object* v___x_340_; lean_object* v___x_342_; 
lean_dec(v_val_325_);
lean_dec_ref(v_b_319_);
v___x_336_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__0));
lean_inc(v_a_323_);
v___x_337_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_323_, v___x_320_);
v___x_338_ = lean_string_append(v___x_336_, v___x_337_);
lean_dec_ref(v___x_337_);
v___x_339_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_340_ = lean_string_append(v___x_338_, v___x_339_);
if (v_isShared_328_ == 0)
{
lean_ctor_set_tag(v___x_327_, 0);
lean_ctor_set(v___x_327_, 0, v___x_340_);
v___x_342_ = v___x_327_;
goto v_reusejp_341_;
}
else
{
lean_object* v_reuseFailAlloc_343_; 
v_reuseFailAlloc_343_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_343_, 0, v___x_340_);
v___x_342_ = v_reuseFailAlloc_343_;
goto v_reusejp_341_;
}
v_reusejp_341_:
{
return v___x_342_;
}
}
}
}
else
{
lean_object* v___x_345_; lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v___x_349_; lean_object* v___x_350_; 
lean_dec(v___x_324_);
lean_dec_ref(v_b_319_);
v___x_345_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__1));
lean_inc(v_a_323_);
v___x_346_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_323_, v___x_320_);
v___x_347_ = lean_string_append(v___x_345_, v___x_346_);
lean_dec_ref(v___x_346_);
v___x_348_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_349_ = lean_string_append(v___x_347_, v___x_348_);
v___x_350_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_350_, 0, v___x_349_);
return v___x_350_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___boxed(lean_object* v_solution_351_, lean_object* v_as_352_, lean_object* v_sz_353_, lean_object* v_i_354_, lean_object* v_b_355_){
_start:
{
size_t v_sz_boxed_356_; size_t v_i_boxed_357_; lean_object* v_res_358_; 
v_sz_boxed_356_ = lean_unbox_usize(v_sz_353_);
lean_dec(v_sz_353_);
v_i_boxed_357_ = lean_unbox_usize(v_i_354_);
lean_dec(v_i_354_);
v_res_358_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0(v_solution_351_, v_as_352_, v_sz_boxed_356_, v_i_boxed_357_, v_b_355_);
lean_dec_ref(v_as_352_);
lean_dec_ref(v_solution_351_);
return v_res_358_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1(lean_object* v_solution_360_, lean_object* v_as_361_, size_t v_sz_362_, size_t v_i_363_, lean_object* v_b_364_){
_start:
{
uint8_t v___x_365_; 
v___x_365_ = lean_usize_dec_lt(v_i_363_, v_sz_362_);
if (v___x_365_ == 0)
{
lean_object* v___x_366_; 
v___x_366_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_366_, 0, v_b_364_);
return v___x_366_;
}
else
{
lean_object* v_constMap_367_; lean_object* v_a_368_; lean_object* v___x_369_; 
v_constMap_367_ = lean_ctor_get(v_solution_360_, 0);
v_a_368_ = lean_array_uget_borrowed(v_as_361_, v_i_363_);
v___x_369_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Std_DTreeMap_Internal_Impl___aux__Std__Data__DTreeMap__Internal__Lemmas______macroRules__Std__DTreeMap__Internal__Impl__tacticSimp__to__model_x5b___x5dUsing____1_spec__0___redArg(v_constMap_367_, v_a_368_);
if (lean_obj_tag(v___x_369_) == 1)
{
lean_object* v_val_370_; lean_object* v___x_372_; uint8_t v_isShared_373_; uint8_t v_isSharedCheck_389_; 
v_val_370_ = lean_ctor_get(v___x_369_, 0);
v_isSharedCheck_389_ = !lean_is_exclusive(v___x_369_);
if (v_isSharedCheck_389_ == 0)
{
v___x_372_ = v___x_369_;
v_isShared_373_ = v_isSharedCheck_389_;
goto v_resetjp_371_;
}
else
{
lean_inc(v_val_370_);
lean_dec(v___x_369_);
v___x_372_ = lean_box(0);
v_isShared_373_ = v_isSharedCheck_389_;
goto v_resetjp_371_;
}
v_resetjp_371_:
{
if (lean_obj_tag(v_val_370_) == 1)
{
lean_object* v_val_374_; lean_object* v_toConstantVal_375_; lean_object* v_name_376_; lean_object* v___x_377_; size_t v___x_378_; size_t v___x_379_; 
lean_del_object(v___x_372_);
v_val_374_ = lean_ctor_get(v_val_370_, 0);
lean_inc_ref(v_val_374_);
lean_dec_ref_known(v_val_370_, 1);
v_toConstantVal_375_ = lean_ctor_get(v_val_374_, 0);
lean_inc_ref(v_toConstantVal_375_);
lean_dec_ref(v_val_374_);
v_name_376_ = lean_ctor_get(v_toConstantVal_375_, 0);
lean_inc(v_name_376_);
lean_dec_ref(v_toConstantVal_375_);
v___x_377_ = lean_array_push(v_b_364_, v_name_376_);
v___x_378_ = ((size_t)1ULL);
v___x_379_ = lean_usize_add(v_i_363_, v___x_378_);
v_i_363_ = v___x_379_;
v_b_364_ = v___x_377_;
goto _start;
}
else
{
lean_object* v___x_381_; lean_object* v___x_382_; lean_object* v___x_383_; lean_object* v___x_384_; lean_object* v___x_385_; lean_object* v___x_387_; 
lean_dec(v_val_370_);
lean_dec_ref(v_b_364_);
v___x_381_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1___closed__0));
lean_inc(v_a_368_);
v___x_382_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_368_, v___x_365_);
v___x_383_ = lean_string_append(v___x_381_, v___x_382_);
lean_dec_ref(v___x_382_);
v___x_384_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_385_ = lean_string_append(v___x_383_, v___x_384_);
if (v_isShared_373_ == 0)
{
lean_ctor_set_tag(v___x_372_, 0);
lean_ctor_set(v___x_372_, 0, v___x_385_);
v___x_387_ = v___x_372_;
goto v_reusejp_386_;
}
else
{
lean_object* v_reuseFailAlloc_388_; 
v_reuseFailAlloc_388_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_388_, 0, v___x_385_);
v___x_387_ = v_reuseFailAlloc_388_;
goto v_reusejp_386_;
}
v_reusejp_386_:
{
return v___x_387_;
}
}
}
}
else
{
lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; lean_object* v___x_394_; lean_object* v___x_395_; 
lean_dec(v___x_369_);
lean_dec_ref(v_b_364_);
v___x_390_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0___closed__1));
lean_inc(v_a_368_);
v___x_391_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_368_, v___x_365_);
v___x_392_ = lean_string_append(v___x_390_, v___x_391_);
lean_dec_ref(v___x_391_);
v___x_393_ = ((lean_object*)(lp_proofEnvironment_Comparator_Axioms_loop_validateConst___closed__1));
v___x_394_ = lean_string_append(v___x_392_, v___x_393_);
v___x_395_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_395_, 0, v___x_394_);
return v___x_395_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1___boxed(lean_object* v_solution_396_, lean_object* v_as_397_, lean_object* v_sz_398_, lean_object* v_i_399_, lean_object* v_b_400_){
_start:
{
size_t v_sz_boxed_401_; size_t v_i_boxed_402_; lean_object* v_res_403_; 
v_sz_boxed_401_ = lean_unbox_usize(v_sz_398_);
lean_dec(v_sz_398_);
v_i_boxed_402_ = lean_unbox_usize(v_i_399_);
lean_dec(v_i_399_);
v_res_403_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1(v_solution_396_, v_as_397_, v_sz_boxed_401_, v_i_boxed_402_, v_b_400_);
lean_dec_ref(v_as_397_);
lean_dec_ref(v_solution_396_);
return v_res_403_;
}
}
static lean_object* _init_lp_proofEnvironment_Comparator_checkAxioms___closed__1(void){
_start:
{
lean_object* v___x_406_; lean_object* v___x_407_; lean_object* v___x_408_; 
v___x_406_ = lean_box(0);
v___x_407_ = lean_unsigned_to_nat(16u);
v___x_408_ = lean_mk_array(v___x_407_, v___x_406_);
return v___x_408_;
}
}
static lean_object* _init_lp_proofEnvironment_Comparator_checkAxioms___closed__2(void){
_start:
{
lean_object* v___x_409_; lean_object* v___x_410_; lean_object* v___x_411_; 
v___x_409_ = lean_obj_once(&lp_proofEnvironment_Comparator_checkAxioms___closed__1, &lp_proofEnvironment_Comparator_checkAxioms___closed__1_once, _init_lp_proofEnvironment_Comparator_checkAxioms___closed__1);
v___x_410_ = lean_unsigned_to_nat(0u);
v___x_411_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_411_, 0, v___x_410_);
lean_ctor_set(v___x_411_, 1, v___x_409_);
return v___x_411_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_checkAxioms(lean_object* v_solution_412_, lean_object* v_theoremTargets_413_, lean_object* v_definitionTargets_414_, lean_object* v_legalAxioms_415_){
_start:
{
lean_object* v_worklist_416_; size_t v_sz_417_; size_t v___x_418_; lean_object* v___x_419_; 
v_worklist_416_ = ((lean_object*)(lp_proofEnvironment_Comparator_checkAxioms___closed__0));
v_sz_417_ = lean_array_size(v_theoremTargets_413_);
v___x_418_ = ((size_t)0ULL);
v___x_419_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__0(v_solution_412_, v_theoremTargets_413_, v_sz_417_, v___x_418_, v_worklist_416_);
if (lean_obj_tag(v___x_419_) == 0)
{
lean_object* v_a_420_; lean_object* v___x_422_; uint8_t v_isShared_423_; uint8_t v_isSharedCheck_427_; 
lean_dec_ref(v_solution_412_);
v_a_420_ = lean_ctor_get(v___x_419_, 0);
v_isSharedCheck_427_ = !lean_is_exclusive(v___x_419_);
if (v_isSharedCheck_427_ == 0)
{
v___x_422_ = v___x_419_;
v_isShared_423_ = v_isSharedCheck_427_;
goto v_resetjp_421_;
}
else
{
lean_inc(v_a_420_);
lean_dec(v___x_419_);
v___x_422_ = lean_box(0);
v_isShared_423_ = v_isSharedCheck_427_;
goto v_resetjp_421_;
}
v_resetjp_421_:
{
lean_object* v___x_425_; 
if (v_isShared_423_ == 0)
{
v___x_425_ = v___x_422_;
goto v_reusejp_424_;
}
else
{
lean_object* v_reuseFailAlloc_426_; 
v_reuseFailAlloc_426_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_426_, 0, v_a_420_);
v___x_425_ = v_reuseFailAlloc_426_;
goto v_reusejp_424_;
}
v_reusejp_424_:
{
return v___x_425_;
}
}
}
else
{
lean_object* v_a_428_; size_t v_sz_429_; lean_object* v___x_430_; 
v_a_428_ = lean_ctor_get(v___x_419_, 0);
lean_inc(v_a_428_);
lean_dec_ref_known(v___x_419_, 1);
v_sz_429_ = lean_array_size(v_definitionTargets_414_);
v___x_430_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Comparator_checkAxioms_spec__1(v_solution_412_, v_definitionTargets_414_, v_sz_429_, v___x_418_, v_a_428_);
if (lean_obj_tag(v___x_430_) == 0)
{
lean_object* v_a_431_; lean_object* v___x_433_; uint8_t v_isShared_434_; uint8_t v_isSharedCheck_438_; 
lean_dec_ref(v_solution_412_);
v_a_431_ = lean_ctor_get(v___x_430_, 0);
v_isSharedCheck_438_ = !lean_is_exclusive(v___x_430_);
if (v_isSharedCheck_438_ == 0)
{
v___x_433_ = v___x_430_;
v_isShared_434_ = v_isSharedCheck_438_;
goto v_resetjp_432_;
}
else
{
lean_inc(v_a_431_);
lean_dec(v___x_430_);
v___x_433_ = lean_box(0);
v_isShared_434_ = v_isSharedCheck_438_;
goto v_resetjp_432_;
}
v_resetjp_432_:
{
lean_object* v___x_436_; 
if (v_isShared_434_ == 0)
{
v___x_436_ = v___x_433_;
goto v_reusejp_435_;
}
else
{
lean_object* v_reuseFailAlloc_437_; 
v_reuseFailAlloc_437_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_437_, 0, v_a_431_);
v___x_436_ = v_reuseFailAlloc_437_;
goto v_reusejp_435_;
}
v_reusejp_435_:
{
return v___x_436_;
}
}
}
else
{
lean_object* v_a_439_; lean_object* v___x_440_; lean_object* v___x_441_; lean_object* v___x_442_; lean_object* v___x_443_; lean_object* v___x_444_; 
v_a_439_ = lean_ctor_get(v___x_430_, 0);
lean_inc(v_a_439_);
lean_dec_ref_known(v___x_430_, 1);
v___x_440_ = lean_obj_once(&lp_proofEnvironment_Comparator_checkAxioms___closed__2, &lp_proofEnvironment_Comparator_checkAxioms___closed__2_once, _init_lp_proofEnvironment_Comparator_checkAxioms___closed__2);
v___x_441_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_440_, v_legalAxioms_415_);
v___x_442_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_442_, 0, v_solution_412_);
lean_ctor_set(v___x_442_, 1, v___x_441_);
v___x_443_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_443_, 0, v_a_439_);
lean_ctor_set(v___x_443_, 1, v___x_440_);
v___x_444_ = lp_proofEnvironment_Comparator_Axioms_loop(v___x_442_, v___x_443_);
lean_dec_ref_known(v___x_442_, 2);
if (lean_obj_tag(v___x_444_) == 0)
{
lean_object* v_a_445_; lean_object* v___x_447_; uint8_t v_isShared_448_; uint8_t v_isSharedCheck_452_; 
v_a_445_ = lean_ctor_get(v___x_444_, 0);
v_isSharedCheck_452_ = !lean_is_exclusive(v___x_444_);
if (v_isSharedCheck_452_ == 0)
{
v___x_447_ = v___x_444_;
v_isShared_448_ = v_isSharedCheck_452_;
goto v_resetjp_446_;
}
else
{
lean_inc(v_a_445_);
lean_dec(v___x_444_);
v___x_447_ = lean_box(0);
v_isShared_448_ = v_isSharedCheck_452_;
goto v_resetjp_446_;
}
v_resetjp_446_:
{
lean_object* v___x_450_; 
if (v_isShared_448_ == 0)
{
v___x_450_ = v___x_447_;
goto v_reusejp_449_;
}
else
{
lean_object* v_reuseFailAlloc_451_; 
v_reuseFailAlloc_451_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_451_, 0, v_a_445_);
v___x_450_ = v_reuseFailAlloc_451_;
goto v_reusejp_449_;
}
v_reusejp_449_:
{
return v___x_450_;
}
}
}
else
{
lean_object* v_a_453_; lean_object* v___x_455_; uint8_t v_isShared_456_; uint8_t v_isSharedCheck_461_; 
v_a_453_ = lean_ctor_get(v___x_444_, 0);
v_isSharedCheck_461_ = !lean_is_exclusive(v___x_444_);
if (v_isSharedCheck_461_ == 0)
{
v___x_455_ = v___x_444_;
v_isShared_456_ = v_isSharedCheck_461_;
goto v_resetjp_454_;
}
else
{
lean_inc(v_a_453_);
lean_dec(v___x_444_);
v___x_455_ = lean_box(0);
v_isShared_456_ = v_isSharedCheck_461_;
goto v_resetjp_454_;
}
v_resetjp_454_:
{
lean_object* v_fst_457_; lean_object* v___x_459_; 
v_fst_457_ = lean_ctor_get(v_a_453_, 0);
lean_inc(v_fst_457_);
lean_dec(v_a_453_);
if (v_isShared_456_ == 0)
{
lean_ctor_set(v___x_455_, 0, v_fst_457_);
v___x_459_ = v___x_455_;
goto v_reusejp_458_;
}
else
{
lean_object* v_reuseFailAlloc_460_; 
v_reuseFailAlloc_460_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_460_, 0, v_fst_457_);
v___x_459_ = v_reuseFailAlloc_460_;
goto v_reusejp_458_;
}
v_reusejp_458_:
{
return v___x_459_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Comparator_checkAxioms___boxed(lean_object* v_solution_462_, lean_object* v_theoremTargets_463_, lean_object* v_definitionTargets_464_, lean_object* v_legalAxioms_465_){
_start:
{
lean_object* v_res_466_; 
v_res_466_ = lp_proofEnvironment_Comparator_checkAxioms(v_solution_462_, v_theoremTargets_463_, v_definitionTargets_464_, v_legalAxioms_465_);
lean_dec_ref(v_legalAxioms_465_);
lean_dec_ref(v_definitionTargets_464_);
lean_dec_ref(v_theoremTargets_463_);
return v_res_466_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_Comparator_Util(uint8_t builtin);
lean_object* initialize_proofEnvironment_Export_Parse(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_Comparator_Axioms(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Comparator_Util(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Export_Parse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
