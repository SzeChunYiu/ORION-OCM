// Lean compiler output
// Module: Export.Parse
// Imports: public import Init public meta import Init public import Std.Data.HashMap public import Lean.Declaration public import Std.Internal.Parsec.String public import Lean.Data.Json.Parser
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_Json_Parser_anyCore(lean_object*);
lean_object* l_Std_Internal_Parsec_String_Parser_run___redArg(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
size_t lean_uint64_to_usize(uint64_t);
size_t lean_usize_of_nat(lean_object*);
size_t lean_usize_sub(size_t, size_t);
size_t lean_usize_land(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_abs(lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* l_Lean_Level_imax___override(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_UInt64_ofNat___boxed(lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
size_t lean_usize_add(size_t, size_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* lean_string_push(lean_object*, uint32_t);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
lean_object* l_Lean_Expr_mdata___override(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* l_Lean_Expr_lit___override(lean_object*);
lean_object* l_String_Slice_toNat_x3f(lean_object*);
lean_object* l_Lean_Expr_proj___override(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_letE___override(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_forallE___override(lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_lam___override(lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_app___override(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
lean_object* l_Lean_Expr_sort___override(lean_object*);
lean_object* l_Lean_Expr_bvar___override(lean_object*);
lean_object* l_Lean_Level_param___override(lean_object*);
lean_object* l_Lean_Level_max___override(lean_object*, lean_object*);
lean_object* l_Lean_Level_succ___override(lean_object*);
lean_object* l_Lean_Name_num___override(lean_object*, lean_object*);
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_Lean_Name_beq___boxed(lean_object*, lean_object*);
lean_object* l_Lean_Name_hash___override___boxed(lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__0;
static lean_once_cell_t lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__1;
static const lean_array_object lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__3;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_instInhabitedExportedEnv_default;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_instInhabitedExportedEnv;
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2_spec__3___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_Export_Parse_M_run___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___closed__0;
static lean_once_cell_t lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1;
static lean_once_cell_t lp_proofEnvironment_Export_Parse_M_run___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___closed__2;
static lean_once_cell_t lp_proofEnvironment_Export_Parse_M_run___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___closed__3;
static const lean_array_object lp_proofEnvironment_Export_Parse_M_run___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Export_Parse_getName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_UInt64_ofNat___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Export_Parse_getName___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_getName___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_Export_Parse_getName___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_Parse_getName___closed__1;
static const lean_string_object lp_proofEnvironment_Export_Parse_getName___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "Name not found "};
static const lean_object* lp_proofEnvironment_Export_Parse_getName___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_getName___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getName(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getName___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addName(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addName___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_getLevel___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "Level not found "};
static const lean_object* lp_proofEnvironment_Export_Parse_getLevel___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_getLevel___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getLevel(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getLevel___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addLevel(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addLevel___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_getExpr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "Expr not found "};
static const lean_object* lp_proofEnvironment_Export_Parse_getExpr___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_getExpr___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getExpr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getExpr___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addExpr(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addExpr___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_getRecursorRule___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "RecursorRule not found "};
static const lean_object* lp_proofEnvironment_Export_Parse_getRecursorRule___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_getRecursorRule___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getRecursorRule(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getRecursorRule___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addRecursorRule(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addRecursorRule___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_Export_Parse_addConst___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Lean_Name_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Export_Parse_addConst___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_addConst___closed__0_value;
static const lean_closure_object lp_proofEnvironment_Export_Parse_addConst___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Lean_Name_hash___override___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Export_Parse_addConst___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_addConst___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_addConst___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "Duplicate declaration: "};
static const lean_object* lp_proofEnvironment_Export_Parse_addConst___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_addConst___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addConst(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addConst___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseJsonObj___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "Expected JSON object"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseJsonObj___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseJsonObj___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseJsonObj___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseJsonObj___closed__1_value;
static const lean_closure_object lp_proofEnvironment_Export_Parse_parseJsonObj___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Lean_Json_Parser_anyCore, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseJsonObj___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseNameStr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "Name.str invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameStr___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseNameStr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseNameStr___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameStr___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseNameStr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "pre"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameStr___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___closed__3;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseNameStr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "str"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameStr___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameStr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseNameNum___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "Name.num invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameNum___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameNum___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseNameNum___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseNameNum___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameNum___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameNum___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseNameNum___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "i"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseNameNum___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseNameNum___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameNum(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameNum___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "Level.succ invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelSucc(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelSucc___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseLevelMax___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "Level.max invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelMax___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelMax___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseLevelMax___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelMax___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelMax___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelMax___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelMax(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelMax___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseLevelImax___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "Level.imax invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelImax___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelImax___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseLevelImax___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelImax___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelImax___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelImax___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelImax(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelImax___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseLevelParam___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "Level.param invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelParam___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelParam___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseLevelParam___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelParam___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseLevelParam___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseLevelParam___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelParam(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelParam___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprBVar___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "Expr.bvar invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprBVar___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprBVar___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprBVar___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprBVar___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprBVar___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprBVar___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprBVar(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprBVar___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprSort___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "Expr.sort invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprSort___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprSort___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprSort___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprSort___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprSort___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprSort___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprSort(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprSort___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "Expr.const invalid"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__0_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__0_value)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0(size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprConst___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "name"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprConst___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprConst___closed__0_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprConst___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "us"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprConst___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprConst___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprConst(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprConst___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprApp___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "Expr.app invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprApp___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprApp___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprApp___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprApp___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprApp___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprApp___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprApp___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "fn"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprApp___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprApp___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprApp___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "arg"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprApp___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprApp___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprApp(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprApp___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "default"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__0_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "implicit"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "strictImplicit"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "instImplicit"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "Invalid binder info: "};
static const lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLam___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "Expr.lam invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLam___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprLam___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLam___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLam___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLam___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "type"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLam___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLam___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "body"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLam___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLam___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "binderInfo"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLam___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLam(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprForallE___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "Expr.forallE invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprForallE___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprForallE___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprForallE___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprForallE(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprForallE___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLetE___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "Expr.letE invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLetE___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLetE___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "value"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprLetE___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "nondep"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprLetE___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprProj___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "Expr.proj invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprProj___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprProj___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprProj___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprProj___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprProj___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "typeName"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprProj___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprProj___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "idx"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprProj___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprProj___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "struct"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprProj___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprProj(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "Expr.lit natVal invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprNatLit(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprNatLit___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "Expr.lit strVal invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprStrLit(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprStrLit___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprMdata___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "Expr.mdata invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprMdata___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseExprMdata___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseExprMdata___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprMdata___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprMdata___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "expr"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprMdata___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseExprMdata___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "data"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseExprMdata___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "failed to convert to name idx"};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__0_value)}};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getNameList(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getNameList___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "axiomInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "levelParams"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "isUnsafe"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "defnInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "hints"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "safety"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "all"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "unsafe"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__5 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__5_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "safe"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__6 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__6_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "partial"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__7 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__7_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "Unknown safety parameter: "};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__8 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__8_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "opaque"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__9 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__9_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "abbrev"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__10 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__10_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "regular"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__11 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__11_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseThmInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "thmInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseThmInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseThmInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseThmInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseThmInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseThmInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "opaqueInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseOpaqueInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseOpaqueInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "quotInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "kind"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "ctor"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__4_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__5 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__5_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "unknown quot kind: "};
static const lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__6 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__6_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "inductInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numParams"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numIndices"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ctors"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__4_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numNested"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__5 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__5_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "isRec"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__6 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__6_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "isReflexive"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__7 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__7_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 41, .m_capacity = 41, .m_length = 40, .m_data = "inductInfo invalid: Expected JSON object"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__8 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseInductInfo___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__8_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___closed__9 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductInfo___closed__9_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "ctorInfo invalid"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "induct"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "cidx"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numFields"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "recInfo invalid"};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__0_value)}};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "nfields"};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__2 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__2_value;
static const lean_string_object lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "rhs"};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__3 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseRecInfo___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numMotives"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseRecInfo___closed__0_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseRecInfo___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numMinors"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseRecInfo___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseRecInfo___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "k"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseRecInfo___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseRecInfo___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "rules"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseRecInfo___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductive___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "Inductive invalid, no `recs`"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseInductive___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductive___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "Inductive invalid, no `ctors`"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseInductive___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__2_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductive___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "Inductive invalid, no `types`"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_Export_Parse_parseInductive___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__4_value)}};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__5 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__5_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductive___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "types"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__6 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__6_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseInductive___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "recs"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseInductive___closed__7 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseInductive___closed__7_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductive(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductive___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = ", "};
static const lean_object* lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1___closed__0 = (const lean_object*)&lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "[]"};
static const lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__0 = (const lean_object*)&lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "["};
static const lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__1 = (const lean_object*)&lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "]"};
static const lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__2 = (const lean_object*)&lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "Unknown export object with keys "};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__0 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__0_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "in"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__1 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__1_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "il"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__2 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__2_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "ie"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__3 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__3_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "axiom"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__4 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__4_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "def"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__5 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__5_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "thm"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__6 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__6_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "quot"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__7 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__7_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inductive"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__8 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__8_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "bvar"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__9 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__9_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "sort"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__10 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__10_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "const"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__11 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__11_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "app"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__12 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__12_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lam"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__13 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__13_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "forallE"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__14 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__14_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "letE"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__15 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__15_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "proj"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__16 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__16_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "natVal"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__17 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__17_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "strVal"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__18 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__18_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "mdata"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__19 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__19_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "succ"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__20 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__20_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "max"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__21 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__21_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "imax"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__22 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__22_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "param"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__23 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__23_value;
static const lean_string_object lp_proofEnvironment_Export_Parse_parseItem___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "num"};
static const lean_object* lp_proofEnvironment_Export_Parse_parseItem___closed__24 = (const lean_object*)&lp_proofEnvironment_Export_Parse_parseItem___closed__24_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItem(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItem___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems_go(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems_go___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseMdata(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseMdata___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseFile(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseFile___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_parseStream(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_parseStream___boxed(lean_object*, lean_object*);
static lean_object* _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_1_ = lean_box(0);
v___x_2_ = lean_unsigned_to_nat(16u);
v___x_3_ = lean_mk_array(v___x_2_, v___x_1_);
return v___x_3_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__1(void){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = lean_obj_once(&lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__0, &lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__0_once, _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__0);
v___x_5_ = lean_unsigned_to_nat(0u);
v___x_6_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6_, 0, v___x_5_);
lean_ctor_set(v___x_6_, 1, v___x_4_);
return v___x_6_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__3(void){
_start:
{
lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; 
v___x_9_ = ((lean_object*)(lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__2));
v___x_10_ = lean_obj_once(&lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__1, &lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__1_once, _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__1);
v___x_11_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_11_, 0, v___x_10_);
lean_ctor_set(v___x_11_, 1, v___x_9_);
return v___x_11_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default(void){
_start:
{
lean_object* v___x_12_; 
v___x_12_ = lean_obj_once(&lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__3, &lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__3_once, _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default___closed__3);
return v___x_12_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_instInhabitedExportedEnv(void){
_start:
{
lean_object* v___x_13_; 
v___x_13_ = lp_proofEnvironment_Export_instInhabitedExportedEnv_default;
return v___x_13_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg(lean_object* v_a_14_, lean_object* v_x_15_){
_start:
{
if (lean_obj_tag(v_x_15_) == 0)
{
uint8_t v___x_16_; 
v___x_16_ = 0;
return v___x_16_;
}
else
{
lean_object* v_key_17_; lean_object* v_tail_18_; uint8_t v___x_19_; 
v_key_17_ = lean_ctor_get(v_x_15_, 0);
v_tail_18_ = lean_ctor_get(v_x_15_, 2);
v___x_19_ = lean_nat_dec_eq(v_key_17_, v_a_14_);
if (v___x_19_ == 0)
{
v_x_15_ = v_tail_18_;
goto _start;
}
else
{
return v___x_19_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg___boxed(lean_object* v_a_21_, lean_object* v_x_22_){
_start:
{
uint8_t v_res_23_; lean_object* v_r_24_; 
v_res_23_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg(v_a_21_, v_x_22_);
lean_dec(v_x_22_);
lean_dec(v_a_21_);
v_r_24_ = lean_box(v_res_23_);
return v_r_24_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2___redArg(lean_object* v_a_25_, lean_object* v_b_26_, lean_object* v_x_27_){
_start:
{
if (lean_obj_tag(v_x_27_) == 0)
{
lean_dec(v_b_26_);
lean_dec(v_a_25_);
return v_x_27_;
}
else
{
lean_object* v_key_28_; lean_object* v_value_29_; lean_object* v_tail_30_; lean_object* v___x_32_; uint8_t v_isShared_33_; uint8_t v_isSharedCheck_42_; 
v_key_28_ = lean_ctor_get(v_x_27_, 0);
v_value_29_ = lean_ctor_get(v_x_27_, 1);
v_tail_30_ = lean_ctor_get(v_x_27_, 2);
v_isSharedCheck_42_ = !lean_is_exclusive(v_x_27_);
if (v_isSharedCheck_42_ == 0)
{
v___x_32_ = v_x_27_;
v_isShared_33_ = v_isSharedCheck_42_;
goto v_resetjp_31_;
}
else
{
lean_inc(v_tail_30_);
lean_inc(v_value_29_);
lean_inc(v_key_28_);
lean_dec(v_x_27_);
v___x_32_ = lean_box(0);
v_isShared_33_ = v_isSharedCheck_42_;
goto v_resetjp_31_;
}
v_resetjp_31_:
{
uint8_t v___x_34_; 
v___x_34_ = lean_nat_dec_eq(v_key_28_, v_a_25_);
if (v___x_34_ == 0)
{
lean_object* v___x_35_; lean_object* v___x_37_; 
v___x_35_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2___redArg(v_a_25_, v_b_26_, v_tail_30_);
if (v_isShared_33_ == 0)
{
lean_ctor_set(v___x_32_, 2, v___x_35_);
v___x_37_ = v___x_32_;
goto v_reusejp_36_;
}
else
{
lean_object* v_reuseFailAlloc_38_; 
v_reuseFailAlloc_38_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_38_, 0, v_key_28_);
lean_ctor_set(v_reuseFailAlloc_38_, 1, v_value_29_);
lean_ctor_set(v_reuseFailAlloc_38_, 2, v___x_35_);
v___x_37_ = v_reuseFailAlloc_38_;
goto v_reusejp_36_;
}
v_reusejp_36_:
{
return v___x_37_;
}
}
else
{
lean_object* v___x_40_; 
lean_dec(v_value_29_);
lean_dec(v_key_28_);
if (v_isShared_33_ == 0)
{
lean_ctor_set(v___x_32_, 1, v_b_26_);
lean_ctor_set(v___x_32_, 0, v_a_25_);
v___x_40_ = v___x_32_;
goto v_reusejp_39_;
}
else
{
lean_object* v_reuseFailAlloc_41_; 
v_reuseFailAlloc_41_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_41_, 0, v_a_25_);
lean_ctor_set(v_reuseFailAlloc_41_, 1, v_b_26_);
lean_ctor_set(v_reuseFailAlloc_41_, 2, v_tail_30_);
v___x_40_ = v_reuseFailAlloc_41_;
goto v_reusejp_39_;
}
v_reusejp_39_:
{
return v___x_40_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2_spec__3___redArg(lean_object* v_x_43_, lean_object* v_x_44_){
_start:
{
if (lean_obj_tag(v_x_44_) == 0)
{
return v_x_43_;
}
else
{
lean_object* v_key_45_; lean_object* v_value_46_; lean_object* v_tail_47_; lean_object* v___x_49_; uint8_t v_isShared_50_; uint8_t v_isSharedCheck_70_; 
v_key_45_ = lean_ctor_get(v_x_44_, 0);
v_value_46_ = lean_ctor_get(v_x_44_, 1);
v_tail_47_ = lean_ctor_get(v_x_44_, 2);
v_isSharedCheck_70_ = !lean_is_exclusive(v_x_44_);
if (v_isSharedCheck_70_ == 0)
{
v___x_49_ = v_x_44_;
v_isShared_50_ = v_isSharedCheck_70_;
goto v_resetjp_48_;
}
else
{
lean_inc(v_tail_47_);
lean_inc(v_value_46_);
lean_inc(v_key_45_);
lean_dec(v_x_44_);
v___x_49_ = lean_box(0);
v_isShared_50_ = v_isSharedCheck_70_;
goto v_resetjp_48_;
}
v_resetjp_48_:
{
lean_object* v___x_51_; uint64_t v___x_52_; uint64_t v___x_53_; uint64_t v___x_54_; uint64_t v_fold_55_; uint64_t v___x_56_; uint64_t v___x_57_; uint64_t v___x_58_; size_t v___x_59_; size_t v___x_60_; size_t v___x_61_; size_t v___x_62_; size_t v___x_63_; lean_object* v___x_64_; lean_object* v___x_66_; 
v___x_51_ = lean_array_get_size(v_x_43_);
v___x_52_ = lean_uint64_of_nat(v_key_45_);
v___x_53_ = 32ULL;
v___x_54_ = lean_uint64_shift_right(v___x_52_, v___x_53_);
v_fold_55_ = lean_uint64_xor(v___x_52_, v___x_54_);
v___x_56_ = 16ULL;
v___x_57_ = lean_uint64_shift_right(v_fold_55_, v___x_56_);
v___x_58_ = lean_uint64_xor(v_fold_55_, v___x_57_);
v___x_59_ = lean_uint64_to_usize(v___x_58_);
v___x_60_ = lean_usize_of_nat(v___x_51_);
v___x_61_ = ((size_t)1ULL);
v___x_62_ = lean_usize_sub(v___x_60_, v___x_61_);
v___x_63_ = lean_usize_land(v___x_59_, v___x_62_);
v___x_64_ = lean_array_uget_borrowed(v_x_43_, v___x_63_);
lean_inc(v___x_64_);
if (v_isShared_50_ == 0)
{
lean_ctor_set(v___x_49_, 2, v___x_64_);
v___x_66_ = v___x_49_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_69_; 
v_reuseFailAlloc_69_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_69_, 0, v_key_45_);
lean_ctor_set(v_reuseFailAlloc_69_, 1, v_value_46_);
lean_ctor_set(v_reuseFailAlloc_69_, 2, v___x_64_);
v___x_66_ = v_reuseFailAlloc_69_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
lean_object* v___x_67_; 
v___x_67_ = lean_array_uset(v_x_43_, v___x_63_, v___x_66_);
v_x_43_ = v___x_67_;
v_x_44_ = v_tail_47_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2___redArg(lean_object* v_i_71_, lean_object* v_source_72_, lean_object* v_target_73_){
_start:
{
lean_object* v___x_74_; uint8_t v___x_75_; 
v___x_74_ = lean_array_get_size(v_source_72_);
v___x_75_ = lean_nat_dec_lt(v_i_71_, v___x_74_);
if (v___x_75_ == 0)
{
lean_dec_ref(v_source_72_);
lean_dec(v_i_71_);
return v_target_73_;
}
else
{
lean_object* v_es_76_; lean_object* v___x_77_; lean_object* v_source_78_; lean_object* v_target_79_; lean_object* v___x_80_; lean_object* v___x_81_; 
v_es_76_ = lean_array_fget(v_source_72_, v_i_71_);
v___x_77_ = lean_box(0);
v_source_78_ = lean_array_fset(v_source_72_, v_i_71_, v___x_77_);
v_target_79_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2_spec__3___redArg(v_target_73_, v_es_76_);
v___x_80_ = lean_unsigned_to_nat(1u);
v___x_81_ = lean_nat_add(v_i_71_, v___x_80_);
lean_dec(v_i_71_);
v_i_71_ = v___x_81_;
v_source_72_ = v_source_78_;
v_target_73_ = v_target_79_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1___redArg(lean_object* v_data_83_){
_start:
{
lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v_nbuckets_86_; lean_object* v___x_87_; lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_90_; 
v___x_84_ = lean_array_get_size(v_data_83_);
v___x_85_ = lean_unsigned_to_nat(2u);
v_nbuckets_86_ = lean_nat_mul(v___x_84_, v___x_85_);
v___x_87_ = lean_unsigned_to_nat(0u);
v___x_88_ = lean_box(0);
v___x_89_ = lean_mk_array(v_nbuckets_86_, v___x_88_);
v___x_90_ = lp_proofEnvironment___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2___redArg(v___x_87_, v_data_83_, v___x_89_);
return v___x_90_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(lean_object* v_m_91_, lean_object* v_a_92_, lean_object* v_b_93_){
_start:
{
lean_object* v_size_94_; lean_object* v_buckets_95_; lean_object* v___x_97_; uint8_t v_isShared_98_; uint8_t v_isSharedCheck_138_; 
v_size_94_ = lean_ctor_get(v_m_91_, 0);
v_buckets_95_ = lean_ctor_get(v_m_91_, 1);
v_isSharedCheck_138_ = !lean_is_exclusive(v_m_91_);
if (v_isSharedCheck_138_ == 0)
{
v___x_97_ = v_m_91_;
v_isShared_98_ = v_isSharedCheck_138_;
goto v_resetjp_96_;
}
else
{
lean_inc(v_buckets_95_);
lean_inc(v_size_94_);
lean_dec(v_m_91_);
v___x_97_ = lean_box(0);
v_isShared_98_ = v_isSharedCheck_138_;
goto v_resetjp_96_;
}
v_resetjp_96_:
{
lean_object* v___x_99_; uint64_t v___x_100_; uint64_t v___x_101_; uint64_t v___x_102_; uint64_t v_fold_103_; uint64_t v___x_104_; uint64_t v___x_105_; uint64_t v___x_106_; size_t v___x_107_; size_t v___x_108_; size_t v___x_109_; size_t v___x_110_; size_t v___x_111_; lean_object* v_bkt_112_; uint8_t v___x_113_; 
v___x_99_ = lean_array_get_size(v_buckets_95_);
v___x_100_ = lean_uint64_of_nat(v_a_92_);
v___x_101_ = 32ULL;
v___x_102_ = lean_uint64_shift_right(v___x_100_, v___x_101_);
v_fold_103_ = lean_uint64_xor(v___x_100_, v___x_102_);
v___x_104_ = 16ULL;
v___x_105_ = lean_uint64_shift_right(v_fold_103_, v___x_104_);
v___x_106_ = lean_uint64_xor(v_fold_103_, v___x_105_);
v___x_107_ = lean_uint64_to_usize(v___x_106_);
v___x_108_ = lean_usize_of_nat(v___x_99_);
v___x_109_ = ((size_t)1ULL);
v___x_110_ = lean_usize_sub(v___x_108_, v___x_109_);
v___x_111_ = lean_usize_land(v___x_107_, v___x_110_);
v_bkt_112_ = lean_array_uget_borrowed(v_buckets_95_, v___x_111_);
v___x_113_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg(v_a_92_, v_bkt_112_);
if (v___x_113_ == 0)
{
lean_object* v___x_114_; lean_object* v_size_x27_115_; lean_object* v___x_116_; lean_object* v_buckets_x27_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; lean_object* v___x_121_; lean_object* v___x_122_; uint8_t v___x_123_; 
v___x_114_ = lean_unsigned_to_nat(1u);
v_size_x27_115_ = lean_nat_add(v_size_94_, v___x_114_);
lean_dec(v_size_94_);
lean_inc(v_bkt_112_);
v___x_116_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v___x_116_, 0, v_a_92_);
lean_ctor_set(v___x_116_, 1, v_b_93_);
lean_ctor_set(v___x_116_, 2, v_bkt_112_);
v_buckets_x27_117_ = lean_array_uset(v_buckets_95_, v___x_111_, v___x_116_);
v___x_118_ = lean_unsigned_to_nat(4u);
v___x_119_ = lean_nat_mul(v_size_x27_115_, v___x_118_);
v___x_120_ = lean_unsigned_to_nat(3u);
v___x_121_ = lean_nat_div(v___x_119_, v___x_120_);
lean_dec(v___x_119_);
v___x_122_ = lean_array_get_size(v_buckets_x27_117_);
v___x_123_ = lean_nat_dec_le(v___x_121_, v___x_122_);
lean_dec(v___x_121_);
if (v___x_123_ == 0)
{
lean_object* v_val_124_; lean_object* v___x_126_; 
v_val_124_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1___redArg(v_buckets_x27_117_);
if (v_isShared_98_ == 0)
{
lean_ctor_set(v___x_97_, 1, v_val_124_);
lean_ctor_set(v___x_97_, 0, v_size_x27_115_);
v___x_126_ = v___x_97_;
goto v_reusejp_125_;
}
else
{
lean_object* v_reuseFailAlloc_127_; 
v_reuseFailAlloc_127_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_127_, 0, v_size_x27_115_);
lean_ctor_set(v_reuseFailAlloc_127_, 1, v_val_124_);
v___x_126_ = v_reuseFailAlloc_127_;
goto v_reusejp_125_;
}
v_reusejp_125_:
{
return v___x_126_;
}
}
else
{
lean_object* v___x_129_; 
if (v_isShared_98_ == 0)
{
lean_ctor_set(v___x_97_, 1, v_buckets_x27_117_);
lean_ctor_set(v___x_97_, 0, v_size_x27_115_);
v___x_129_ = v___x_97_;
goto v_reusejp_128_;
}
else
{
lean_object* v_reuseFailAlloc_130_; 
v_reuseFailAlloc_130_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_130_, 0, v_size_x27_115_);
lean_ctor_set(v_reuseFailAlloc_130_, 1, v_buckets_x27_117_);
v___x_129_ = v_reuseFailAlloc_130_;
goto v_reusejp_128_;
}
v_reusejp_128_:
{
return v___x_129_;
}
}
}
else
{
lean_object* v___x_131_; lean_object* v_buckets_x27_132_; lean_object* v___x_133_; lean_object* v___x_134_; lean_object* v___x_136_; 
lean_inc(v_bkt_112_);
v___x_131_ = lean_box(0);
v_buckets_x27_132_ = lean_array_uset(v_buckets_95_, v___x_111_, v___x_131_);
v___x_133_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2___redArg(v_a_92_, v_b_93_, v_bkt_112_);
v___x_134_ = lean_array_uset(v_buckets_x27_132_, v___x_111_, v___x_133_);
if (v_isShared_98_ == 0)
{
lean_ctor_set(v___x_97_, 1, v___x_134_);
v___x_136_ = v___x_97_;
goto v_reusejp_135_;
}
else
{
lean_object* v_reuseFailAlloc_137_; 
v_reuseFailAlloc_137_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_137_, 0, v_size_94_);
lean_ctor_set(v_reuseFailAlloc_137_, 1, v___x_134_);
v___x_136_ = v_reuseFailAlloc_137_;
goto v_reusejp_135_;
}
v_reusejp_135_:
{
return v___x_136_;
}
}
}
}
}
static lean_object* _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__0(void){
_start:
{
lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; 
v___x_139_ = lean_box(0);
v___x_140_ = lean_unsigned_to_nat(16u);
v___x_141_ = lean_mk_array(v___x_140_, v___x_139_);
return v___x_141_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1(void){
_start:
{
lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; 
v___x_142_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__0, &lp_proofEnvironment_Export_Parse_M_run___redArg___closed__0_once, _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__0);
v___x_143_ = lean_unsigned_to_nat(0u);
v___x_144_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_144_, 0, v___x_143_);
lean_ctor_set(v___x_144_, 1, v___x_142_);
return v___x_144_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__2(void){
_start:
{
lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; 
v___x_145_ = lean_box(0);
v___x_146_ = lean_unsigned_to_nat(0u);
v___x_147_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1, &lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1_once, _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1);
v___x_148_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v___x_147_, v___x_146_, v___x_145_);
return v___x_148_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__3(void){
_start:
{
lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; 
v___x_149_ = lean_box(0);
v___x_150_ = lean_unsigned_to_nat(0u);
v___x_151_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1, &lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1_once, _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1);
v___x_152_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v___x_151_, v___x_150_, v___x_149_);
return v___x_152_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg(lean_object* v_x_155_, lean_object* v_stream_156_){
_start:
{
lean_object* v___x_158_; lean_object* v___x_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; 
v___x_158_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1, &lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1_once, _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__1);
v___x_159_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__2, &lp_proofEnvironment_Export_Parse_M_run___redArg___closed__2_once, _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__2);
v___x_160_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_M_run___redArg___closed__3, &lp_proofEnvironment_Export_Parse_M_run___redArg___closed__3_once, _init_lp_proofEnvironment_Export_Parse_M_run___redArg___closed__3);
v___x_161_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_M_run___redArg___closed__4));
v___x_162_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_162_, 0, v_stream_156_);
lean_ctor_set(v___x_162_, 1, v___x_159_);
lean_ctor_set(v___x_162_, 2, v___x_160_);
lean_ctor_set(v___x_162_, 3, v___x_158_);
lean_ctor_set(v___x_162_, 4, v___x_158_);
lean_ctor_set(v___x_162_, 5, v___x_158_);
lean_ctor_set(v___x_162_, 6, v___x_161_);
v___x_163_ = lean_apply_2(v_x_155_, v___x_162_, lean_box(0));
return v___x_163_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg___boxed(lean_object* v_x_164_, lean_object* v_stream_165_, lean_object* v_a_166_){
_start:
{
lean_object* v_res_167_; 
v_res_167_ = lp_proofEnvironment_Export_Parse_M_run___redArg(v_x_164_, v_stream_165_);
return v_res_167_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run(lean_object* v_00_u03b1_168_, lean_object* v_x_169_, lean_object* v_stream_170_){
_start:
{
lean_object* v___x_172_; 
v___x_172_ = lp_proofEnvironment_Export_Parse_M_run___redArg(v_x_169_, v_stream_170_);
return v___x_172_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_M_run___boxed(lean_object* v_00_u03b1_173_, lean_object* v_x_174_, lean_object* v_stream_175_, lean_object* v_a_176_){
_start:
{
lean_object* v_res_177_; 
v_res_177_ = lp_proofEnvironment_Export_Parse_M_run(v_00_u03b1_173_, v_x_174_, v_stream_175_);
return v_res_177_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0(lean_object* v_00_u03b2_178_, lean_object* v_m_179_, lean_object* v_a_180_, lean_object* v_b_181_){
_start:
{
lean_object* v___x_182_; 
v___x_182_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_m_179_, v_a_180_, v_b_181_);
return v___x_182_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0(lean_object* v_00_u03b2_183_, lean_object* v_a_184_, lean_object* v_x_185_){
_start:
{
uint8_t v___x_186_; 
v___x_186_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___redArg(v_a_184_, v_x_185_);
return v___x_186_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0___boxed(lean_object* v_00_u03b2_187_, lean_object* v_a_188_, lean_object* v_x_189_){
_start:
{
uint8_t v_res_190_; lean_object* v_r_191_; 
v_res_190_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__0(v_00_u03b2_187_, v_a_188_, v_x_189_);
lean_dec(v_x_189_);
lean_dec(v_a_188_);
v_r_191_ = lean_box(v_res_190_);
return v_r_191_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1(lean_object* v_00_u03b2_192_, lean_object* v_data_193_){
_start:
{
lean_object* v___x_194_; 
v___x_194_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1___redArg(v_data_193_);
return v___x_194_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2(lean_object* v_00_u03b2_195_, lean_object* v_a_196_, lean_object* v_b_197_, lean_object* v_x_198_){
_start:
{
lean_object* v___x_199_; 
v___x_199_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__2___redArg(v_a_196_, v_b_197_, v_x_198_);
return v___x_199_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2(lean_object* v_00_u03b2_200_, lean_object* v_i_201_, lean_object* v_source_202_, lean_object* v_target_203_){
_start:
{
lean_object* v___x_204_; 
v___x_204_ = lp_proofEnvironment___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2___redArg(v_i_201_, v_source_202_, v_target_203_);
return v___x_204_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2_spec__3(lean_object* v_00_u03b2_205_, lean_object* v_x_206_, lean_object* v_x_207_){
_start:
{
lean_object* v___x_208_; 
v___x_208_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0_spec__1_spec__2_spec__3___redArg(v_x_206_, v_x_207_);
return v___x_208_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail___redArg(lean_object* v_msg_209_){
_start:
{
lean_object* v___x_211_; lean_object* v___x_212_; 
v___x_211_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_211_, 0, v_msg_209_);
v___x_212_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_212_, 0, v___x_211_);
return v___x_212_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail___redArg___boxed(lean_object* v_msg_213_, lean_object* v_a_214_){
_start:
{
lean_object* v_res_215_; 
v_res_215_ = lp_proofEnvironment_Export_Parse_fail___redArg(v_msg_213_);
return v_res_215_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail(lean_object* v_00_u03b1_216_, lean_object* v_msg_217_, lean_object* v_a_218_){
_start:
{
lean_object* v___x_220_; lean_object* v___x_221_; 
v___x_220_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_220_, 0, v_msg_217_);
v___x_221_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_221_, 0, v___x_220_);
return v___x_221_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_fail___boxed(lean_object* v_00_u03b1_222_, lean_object* v_msg_223_, lean_object* v_a_224_, lean_object* v_a_225_){
_start:
{
lean_object* v_res_226_; 
v_res_226_ = lp_proofEnvironment_Export_Parse_fail(v_00_u03b1_222_, v_msg_223_, v_a_224_);
lean_dec_ref(v_a_224_);
return v_res_226_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_Parse_getName___closed__1(void){
_start:
{
lean_object* v___x_228_; lean_object* v___f_229_; 
v___x_228_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___f_229_ = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(v___f_229_, 0, v___x_228_);
return v___f_229_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getName(lean_object* v_nidx_231_, lean_object* v_a_232_){
_start:
{
lean_object* v_nameMap_234_; lean_object* v___f_235_; lean_object* v___f_236_; lean_object* v___x_237_; 
v_nameMap_234_ = lean_ctor_get(v_a_232_, 1);
v___f_235_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___f_236_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
lean_inc(v_nidx_231_);
v___x_237_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v___f_236_, v___f_235_, v_nameMap_234_, v_nidx_231_);
if (lean_obj_tag(v___x_237_) == 1)
{
lean_object* v_val_238_; lean_object* v___x_240_; uint8_t v_isShared_241_; uint8_t v_isSharedCheck_246_; 
lean_dec(v_nidx_231_);
v_val_238_ = lean_ctor_get(v___x_237_, 0);
v_isSharedCheck_246_ = !lean_is_exclusive(v___x_237_);
if (v_isSharedCheck_246_ == 0)
{
v___x_240_ = v___x_237_;
v_isShared_241_ = v_isSharedCheck_246_;
goto v_resetjp_239_;
}
else
{
lean_inc(v_val_238_);
lean_dec(v___x_237_);
v___x_240_ = lean_box(0);
v_isShared_241_ = v_isSharedCheck_246_;
goto v_resetjp_239_;
}
v_resetjp_239_:
{
lean_object* v___x_242_; lean_object* v___x_244_; 
v___x_242_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_242_, 0, v_val_238_);
lean_ctor_set(v___x_242_, 1, v_a_232_);
if (v_isShared_241_ == 0)
{
lean_ctor_set_tag(v___x_240_, 0);
lean_ctor_set(v___x_240_, 0, v___x_242_);
v___x_244_ = v___x_240_;
goto v_reusejp_243_;
}
else
{
lean_object* v_reuseFailAlloc_245_; 
v_reuseFailAlloc_245_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_245_, 0, v___x_242_);
v___x_244_ = v_reuseFailAlloc_245_;
goto v_reusejp_243_;
}
v_reusejp_243_:
{
return v___x_244_;
}
}
}
else
{
lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; lean_object* v___x_250_; lean_object* v___x_251_; 
lean_dec(v___x_237_);
lean_dec_ref(v_a_232_);
v___x_247_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_248_ = l_Nat_reprFast(v_nidx_231_);
v___x_249_ = lean_string_append(v___x_247_, v___x_248_);
lean_dec_ref(v___x_248_);
v___x_250_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_250_, 0, v___x_249_);
v___x_251_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_251_, 0, v___x_250_);
return v___x_251_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getName___boxed(lean_object* v_nidx_252_, lean_object* v_a_253_, lean_object* v_a_254_){
_start:
{
lean_object* v_res_255_; 
v_res_255_ = lp_proofEnvironment_Export_Parse_getName(v_nidx_252_, v_a_253_);
return v_res_255_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addName(lean_object* v_nidx_256_, lean_object* v_n_257_, lean_object* v_a_258_){
_start:
{
lean_object* v_stream_260_; lean_object* v_nameMap_261_; lean_object* v_levelMap_262_; lean_object* v_exprMap_263_; lean_object* v_recursorRuleMap_264_; lean_object* v_constMap_265_; lean_object* v_constOrder_266_; lean_object* v___x_268_; uint8_t v_isShared_269_; uint8_t v_isSharedCheck_279_; 
v_stream_260_ = lean_ctor_get(v_a_258_, 0);
v_nameMap_261_ = lean_ctor_get(v_a_258_, 1);
v_levelMap_262_ = lean_ctor_get(v_a_258_, 2);
v_exprMap_263_ = lean_ctor_get(v_a_258_, 3);
v_recursorRuleMap_264_ = lean_ctor_get(v_a_258_, 4);
v_constMap_265_ = lean_ctor_get(v_a_258_, 5);
v_constOrder_266_ = lean_ctor_get(v_a_258_, 6);
v_isSharedCheck_279_ = !lean_is_exclusive(v_a_258_);
if (v_isSharedCheck_279_ == 0)
{
v___x_268_ = v_a_258_;
v_isShared_269_ = v_isSharedCheck_279_;
goto v_resetjp_267_;
}
else
{
lean_inc(v_constOrder_266_);
lean_inc(v_constMap_265_);
lean_inc(v_recursorRuleMap_264_);
lean_inc(v_exprMap_263_);
lean_inc(v_levelMap_262_);
lean_inc(v_nameMap_261_);
lean_inc(v_stream_260_);
lean_dec(v_a_258_);
v___x_268_ = lean_box(0);
v_isShared_269_ = v_isSharedCheck_279_;
goto v_resetjp_267_;
}
v_resetjp_267_:
{
lean_object* v___f_270_; lean_object* v___x_271_; lean_object* v___f_272_; lean_object* v___x_273_; lean_object* v___x_275_; 
v___f_270_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___x_271_ = lean_box(0);
v___f_272_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
v___x_273_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v___f_272_, v___f_270_, v_nameMap_261_, v_nidx_256_, v_n_257_);
if (v_isShared_269_ == 0)
{
lean_ctor_set(v___x_268_, 1, v___x_273_);
v___x_275_ = v___x_268_;
goto v_reusejp_274_;
}
else
{
lean_object* v_reuseFailAlloc_278_; 
v_reuseFailAlloc_278_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_278_, 0, v_stream_260_);
lean_ctor_set(v_reuseFailAlloc_278_, 1, v___x_273_);
lean_ctor_set(v_reuseFailAlloc_278_, 2, v_levelMap_262_);
lean_ctor_set(v_reuseFailAlloc_278_, 3, v_exprMap_263_);
lean_ctor_set(v_reuseFailAlloc_278_, 4, v_recursorRuleMap_264_);
lean_ctor_set(v_reuseFailAlloc_278_, 5, v_constMap_265_);
lean_ctor_set(v_reuseFailAlloc_278_, 6, v_constOrder_266_);
v___x_275_ = v_reuseFailAlloc_278_;
goto v_reusejp_274_;
}
v_reusejp_274_:
{
lean_object* v___x_276_; lean_object* v___x_277_; 
v___x_276_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_276_, 0, v___x_271_);
lean_ctor_set(v___x_276_, 1, v___x_275_);
v___x_277_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_277_, 0, v___x_276_);
return v___x_277_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addName___boxed(lean_object* v_nidx_280_, lean_object* v_n_281_, lean_object* v_a_282_, lean_object* v_a_283_){
_start:
{
lean_object* v_res_284_; 
v_res_284_ = lp_proofEnvironment_Export_Parse_addName(v_nidx_280_, v_n_281_, v_a_282_);
return v_res_284_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getLevel(lean_object* v_uidx_286_, lean_object* v_a_287_){
_start:
{
lean_object* v_levelMap_289_; lean_object* v___f_290_; lean_object* v___f_291_; lean_object* v___x_292_; 
v_levelMap_289_ = lean_ctor_get(v_a_287_, 2);
v___f_290_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___f_291_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
lean_inc(v_uidx_286_);
v___x_292_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v___f_291_, v___f_290_, v_levelMap_289_, v_uidx_286_);
if (lean_obj_tag(v___x_292_) == 1)
{
lean_object* v_val_293_; lean_object* v___x_295_; uint8_t v_isShared_296_; uint8_t v_isSharedCheck_301_; 
lean_dec(v_uidx_286_);
v_val_293_ = lean_ctor_get(v___x_292_, 0);
v_isSharedCheck_301_ = !lean_is_exclusive(v___x_292_);
if (v_isSharedCheck_301_ == 0)
{
v___x_295_ = v___x_292_;
v_isShared_296_ = v_isSharedCheck_301_;
goto v_resetjp_294_;
}
else
{
lean_inc(v_val_293_);
lean_dec(v___x_292_);
v___x_295_ = lean_box(0);
v_isShared_296_ = v_isSharedCheck_301_;
goto v_resetjp_294_;
}
v_resetjp_294_:
{
lean_object* v___x_297_; lean_object* v___x_299_; 
v___x_297_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_297_, 0, v_val_293_);
lean_ctor_set(v___x_297_, 1, v_a_287_);
if (v_isShared_296_ == 0)
{
lean_ctor_set_tag(v___x_295_, 0);
lean_ctor_set(v___x_295_, 0, v___x_297_);
v___x_299_ = v___x_295_;
goto v_reusejp_298_;
}
else
{
lean_object* v_reuseFailAlloc_300_; 
v_reuseFailAlloc_300_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_300_, 0, v___x_297_);
v___x_299_ = v_reuseFailAlloc_300_;
goto v_reusejp_298_;
}
v_reusejp_298_:
{
return v___x_299_;
}
}
}
else
{
lean_object* v___x_302_; lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; 
lean_dec(v___x_292_);
lean_dec_ref(v_a_287_);
v___x_302_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_303_ = l_Nat_reprFast(v_uidx_286_);
v___x_304_ = lean_string_append(v___x_302_, v___x_303_);
lean_dec_ref(v___x_303_);
v___x_305_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_305_, 0, v___x_304_);
v___x_306_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_306_, 0, v___x_305_);
return v___x_306_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getLevel___boxed(lean_object* v_uidx_307_, lean_object* v_a_308_, lean_object* v_a_309_){
_start:
{
lean_object* v_res_310_; 
v_res_310_ = lp_proofEnvironment_Export_Parse_getLevel(v_uidx_307_, v_a_308_);
return v_res_310_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addLevel(lean_object* v_uidx_311_, lean_object* v_l_312_, lean_object* v_a_313_){
_start:
{
lean_object* v_stream_315_; lean_object* v_nameMap_316_; lean_object* v_levelMap_317_; lean_object* v_exprMap_318_; lean_object* v_recursorRuleMap_319_; lean_object* v_constMap_320_; lean_object* v_constOrder_321_; lean_object* v___x_323_; uint8_t v_isShared_324_; uint8_t v_isSharedCheck_334_; 
v_stream_315_ = lean_ctor_get(v_a_313_, 0);
v_nameMap_316_ = lean_ctor_get(v_a_313_, 1);
v_levelMap_317_ = lean_ctor_get(v_a_313_, 2);
v_exprMap_318_ = lean_ctor_get(v_a_313_, 3);
v_recursorRuleMap_319_ = lean_ctor_get(v_a_313_, 4);
v_constMap_320_ = lean_ctor_get(v_a_313_, 5);
v_constOrder_321_ = lean_ctor_get(v_a_313_, 6);
v_isSharedCheck_334_ = !lean_is_exclusive(v_a_313_);
if (v_isSharedCheck_334_ == 0)
{
v___x_323_ = v_a_313_;
v_isShared_324_ = v_isSharedCheck_334_;
goto v_resetjp_322_;
}
else
{
lean_inc(v_constOrder_321_);
lean_inc(v_constMap_320_);
lean_inc(v_recursorRuleMap_319_);
lean_inc(v_exprMap_318_);
lean_inc(v_levelMap_317_);
lean_inc(v_nameMap_316_);
lean_inc(v_stream_315_);
lean_dec(v_a_313_);
v___x_323_ = lean_box(0);
v_isShared_324_ = v_isSharedCheck_334_;
goto v_resetjp_322_;
}
v_resetjp_322_:
{
lean_object* v___f_325_; lean_object* v___x_326_; lean_object* v___f_327_; lean_object* v___x_328_; lean_object* v___x_330_; 
v___f_325_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___x_326_ = lean_box(0);
v___f_327_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
v___x_328_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v___f_327_, v___f_325_, v_levelMap_317_, v_uidx_311_, v_l_312_);
if (v_isShared_324_ == 0)
{
lean_ctor_set(v___x_323_, 2, v___x_328_);
v___x_330_ = v___x_323_;
goto v_reusejp_329_;
}
else
{
lean_object* v_reuseFailAlloc_333_; 
v_reuseFailAlloc_333_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_333_, 0, v_stream_315_);
lean_ctor_set(v_reuseFailAlloc_333_, 1, v_nameMap_316_);
lean_ctor_set(v_reuseFailAlloc_333_, 2, v___x_328_);
lean_ctor_set(v_reuseFailAlloc_333_, 3, v_exprMap_318_);
lean_ctor_set(v_reuseFailAlloc_333_, 4, v_recursorRuleMap_319_);
lean_ctor_set(v_reuseFailAlloc_333_, 5, v_constMap_320_);
lean_ctor_set(v_reuseFailAlloc_333_, 6, v_constOrder_321_);
v___x_330_ = v_reuseFailAlloc_333_;
goto v_reusejp_329_;
}
v_reusejp_329_:
{
lean_object* v___x_331_; lean_object* v___x_332_; 
v___x_331_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_331_, 0, v___x_326_);
lean_ctor_set(v___x_331_, 1, v___x_330_);
v___x_332_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_332_, 0, v___x_331_);
return v___x_332_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addLevel___boxed(lean_object* v_uidx_335_, lean_object* v_l_336_, lean_object* v_a_337_, lean_object* v_a_338_){
_start:
{
lean_object* v_res_339_; 
v_res_339_ = lp_proofEnvironment_Export_Parse_addLevel(v_uidx_335_, v_l_336_, v_a_337_);
return v_res_339_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getExpr(lean_object* v_eidx_341_, lean_object* v_a_342_){
_start:
{
lean_object* v_exprMap_344_; lean_object* v___f_345_; lean_object* v___f_346_; lean_object* v___x_347_; 
v_exprMap_344_ = lean_ctor_get(v_a_342_, 3);
v___f_345_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___f_346_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
lean_inc(v_eidx_341_);
v___x_347_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v___f_346_, v___f_345_, v_exprMap_344_, v_eidx_341_);
if (lean_obj_tag(v___x_347_) == 1)
{
lean_object* v_val_348_; lean_object* v___x_350_; uint8_t v_isShared_351_; uint8_t v_isSharedCheck_356_; 
lean_dec(v_eidx_341_);
v_val_348_ = lean_ctor_get(v___x_347_, 0);
v_isSharedCheck_356_ = !lean_is_exclusive(v___x_347_);
if (v_isSharedCheck_356_ == 0)
{
v___x_350_ = v___x_347_;
v_isShared_351_ = v_isSharedCheck_356_;
goto v_resetjp_349_;
}
else
{
lean_inc(v_val_348_);
lean_dec(v___x_347_);
v___x_350_ = lean_box(0);
v_isShared_351_ = v_isSharedCheck_356_;
goto v_resetjp_349_;
}
v_resetjp_349_:
{
lean_object* v___x_352_; lean_object* v___x_354_; 
v___x_352_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_352_, 0, v_val_348_);
lean_ctor_set(v___x_352_, 1, v_a_342_);
if (v_isShared_351_ == 0)
{
lean_ctor_set_tag(v___x_350_, 0);
lean_ctor_set(v___x_350_, 0, v___x_352_);
v___x_354_ = v___x_350_;
goto v_reusejp_353_;
}
else
{
lean_object* v_reuseFailAlloc_355_; 
v_reuseFailAlloc_355_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_355_, 0, v___x_352_);
v___x_354_ = v_reuseFailAlloc_355_;
goto v_reusejp_353_;
}
v_reusejp_353_:
{
return v___x_354_;
}
}
}
else
{
lean_object* v___x_357_; lean_object* v___x_358_; lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v___x_361_; 
lean_dec(v___x_347_);
lean_dec_ref(v_a_342_);
v___x_357_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_358_ = l_Nat_reprFast(v_eidx_341_);
v___x_359_ = lean_string_append(v___x_357_, v___x_358_);
lean_dec_ref(v___x_358_);
v___x_360_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_360_, 0, v___x_359_);
v___x_361_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_361_, 0, v___x_360_);
return v___x_361_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getExpr___boxed(lean_object* v_eidx_362_, lean_object* v_a_363_, lean_object* v_a_364_){
_start:
{
lean_object* v_res_365_; 
v_res_365_ = lp_proofEnvironment_Export_Parse_getExpr(v_eidx_362_, v_a_363_);
return v_res_365_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addExpr(lean_object* v_eidx_366_, lean_object* v_e_367_, lean_object* v_a_368_){
_start:
{
lean_object* v_stream_370_; lean_object* v_nameMap_371_; lean_object* v_levelMap_372_; lean_object* v_exprMap_373_; lean_object* v_recursorRuleMap_374_; lean_object* v_constMap_375_; lean_object* v_constOrder_376_; lean_object* v___x_378_; uint8_t v_isShared_379_; uint8_t v_isSharedCheck_389_; 
v_stream_370_ = lean_ctor_get(v_a_368_, 0);
v_nameMap_371_ = lean_ctor_get(v_a_368_, 1);
v_levelMap_372_ = lean_ctor_get(v_a_368_, 2);
v_exprMap_373_ = lean_ctor_get(v_a_368_, 3);
v_recursorRuleMap_374_ = lean_ctor_get(v_a_368_, 4);
v_constMap_375_ = lean_ctor_get(v_a_368_, 5);
v_constOrder_376_ = lean_ctor_get(v_a_368_, 6);
v_isSharedCheck_389_ = !lean_is_exclusive(v_a_368_);
if (v_isSharedCheck_389_ == 0)
{
v___x_378_ = v_a_368_;
v_isShared_379_ = v_isSharedCheck_389_;
goto v_resetjp_377_;
}
else
{
lean_inc(v_constOrder_376_);
lean_inc(v_constMap_375_);
lean_inc(v_recursorRuleMap_374_);
lean_inc(v_exprMap_373_);
lean_inc(v_levelMap_372_);
lean_inc(v_nameMap_371_);
lean_inc(v_stream_370_);
lean_dec(v_a_368_);
v___x_378_ = lean_box(0);
v_isShared_379_ = v_isSharedCheck_389_;
goto v_resetjp_377_;
}
v_resetjp_377_:
{
lean_object* v___f_380_; lean_object* v___x_381_; lean_object* v___f_382_; lean_object* v___x_383_; lean_object* v___x_385_; 
v___f_380_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___x_381_ = lean_box(0);
v___f_382_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
v___x_383_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v___f_382_, v___f_380_, v_exprMap_373_, v_eidx_366_, v_e_367_);
if (v_isShared_379_ == 0)
{
lean_ctor_set(v___x_378_, 3, v___x_383_);
v___x_385_ = v___x_378_;
goto v_reusejp_384_;
}
else
{
lean_object* v_reuseFailAlloc_388_; 
v_reuseFailAlloc_388_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_388_, 0, v_stream_370_);
lean_ctor_set(v_reuseFailAlloc_388_, 1, v_nameMap_371_);
lean_ctor_set(v_reuseFailAlloc_388_, 2, v_levelMap_372_);
lean_ctor_set(v_reuseFailAlloc_388_, 3, v___x_383_);
lean_ctor_set(v_reuseFailAlloc_388_, 4, v_recursorRuleMap_374_);
lean_ctor_set(v_reuseFailAlloc_388_, 5, v_constMap_375_);
lean_ctor_set(v_reuseFailAlloc_388_, 6, v_constOrder_376_);
v___x_385_ = v_reuseFailAlloc_388_;
goto v_reusejp_384_;
}
v_reusejp_384_:
{
lean_object* v___x_386_; lean_object* v___x_387_; 
v___x_386_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_386_, 0, v___x_381_);
lean_ctor_set(v___x_386_, 1, v___x_385_);
v___x_387_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_387_, 0, v___x_386_);
return v___x_387_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addExpr___boxed(lean_object* v_eidx_390_, lean_object* v_e_391_, lean_object* v_a_392_, lean_object* v_a_393_){
_start:
{
lean_object* v_res_394_; 
v_res_394_ = lp_proofEnvironment_Export_Parse_addExpr(v_eidx_390_, v_e_391_, v_a_392_);
return v_res_394_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getRecursorRule(lean_object* v_ridx_396_, lean_object* v_a_397_){
_start:
{
lean_object* v_recursorRuleMap_399_; lean_object* v___f_400_; lean_object* v___f_401_; lean_object* v___x_402_; 
v_recursorRuleMap_399_ = lean_ctor_get(v_a_397_, 4);
v___f_400_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___f_401_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
lean_inc(v_ridx_396_);
v___x_402_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v___f_401_, v___f_400_, v_recursorRuleMap_399_, v_ridx_396_);
if (lean_obj_tag(v___x_402_) == 1)
{
lean_object* v_val_403_; lean_object* v___x_405_; uint8_t v_isShared_406_; uint8_t v_isSharedCheck_411_; 
lean_dec(v_ridx_396_);
v_val_403_ = lean_ctor_get(v___x_402_, 0);
v_isSharedCheck_411_ = !lean_is_exclusive(v___x_402_);
if (v_isSharedCheck_411_ == 0)
{
v___x_405_ = v___x_402_;
v_isShared_406_ = v_isSharedCheck_411_;
goto v_resetjp_404_;
}
else
{
lean_inc(v_val_403_);
lean_dec(v___x_402_);
v___x_405_ = lean_box(0);
v_isShared_406_ = v_isSharedCheck_411_;
goto v_resetjp_404_;
}
v_resetjp_404_:
{
lean_object* v___x_407_; lean_object* v___x_409_; 
v___x_407_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_407_, 0, v_val_403_);
lean_ctor_set(v___x_407_, 1, v_a_397_);
if (v_isShared_406_ == 0)
{
lean_ctor_set_tag(v___x_405_, 0);
lean_ctor_set(v___x_405_, 0, v___x_407_);
v___x_409_ = v___x_405_;
goto v_reusejp_408_;
}
else
{
lean_object* v_reuseFailAlloc_410_; 
v_reuseFailAlloc_410_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_410_, 0, v___x_407_);
v___x_409_ = v_reuseFailAlloc_410_;
goto v_reusejp_408_;
}
v_reusejp_408_:
{
return v___x_409_;
}
}
}
else
{
lean_object* v___x_412_; lean_object* v___x_413_; lean_object* v___x_414_; lean_object* v___x_415_; lean_object* v___x_416_; 
lean_dec(v___x_402_);
lean_dec_ref(v_a_397_);
v___x_412_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getRecursorRule___closed__0));
v___x_413_ = l_Nat_reprFast(v_ridx_396_);
v___x_414_ = lean_string_append(v___x_412_, v___x_413_);
lean_dec_ref(v___x_413_);
v___x_415_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_415_, 0, v___x_414_);
v___x_416_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_416_, 0, v___x_415_);
return v___x_416_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getRecursorRule___boxed(lean_object* v_ridx_417_, lean_object* v_a_418_, lean_object* v_a_419_){
_start:
{
lean_object* v_res_420_; 
v_res_420_ = lp_proofEnvironment_Export_Parse_getRecursorRule(v_ridx_417_, v_a_418_);
return v_res_420_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addRecursorRule(lean_object* v_ridx_421_, lean_object* v_r_422_, lean_object* v_a_423_){
_start:
{
lean_object* v_stream_425_; lean_object* v_nameMap_426_; lean_object* v_levelMap_427_; lean_object* v_exprMap_428_; lean_object* v_recursorRuleMap_429_; lean_object* v_constMap_430_; lean_object* v_constOrder_431_; lean_object* v___x_433_; uint8_t v_isShared_434_; uint8_t v_isSharedCheck_444_; 
v_stream_425_ = lean_ctor_get(v_a_423_, 0);
v_nameMap_426_ = lean_ctor_get(v_a_423_, 1);
v_levelMap_427_ = lean_ctor_get(v_a_423_, 2);
v_exprMap_428_ = lean_ctor_get(v_a_423_, 3);
v_recursorRuleMap_429_ = lean_ctor_get(v_a_423_, 4);
v_constMap_430_ = lean_ctor_get(v_a_423_, 5);
v_constOrder_431_ = lean_ctor_get(v_a_423_, 6);
v_isSharedCheck_444_ = !lean_is_exclusive(v_a_423_);
if (v_isSharedCheck_444_ == 0)
{
v___x_433_ = v_a_423_;
v_isShared_434_ = v_isSharedCheck_444_;
goto v_resetjp_432_;
}
else
{
lean_inc(v_constOrder_431_);
lean_inc(v_constMap_430_);
lean_inc(v_recursorRuleMap_429_);
lean_inc(v_exprMap_428_);
lean_inc(v_levelMap_427_);
lean_inc(v_nameMap_426_);
lean_inc(v_stream_425_);
lean_dec(v_a_423_);
v___x_433_ = lean_box(0);
v_isShared_434_ = v_isSharedCheck_444_;
goto v_resetjp_432_;
}
v_resetjp_432_:
{
lean_object* v___f_435_; lean_object* v___x_436_; lean_object* v___f_437_; lean_object* v___x_438_; lean_object* v___x_440_; 
v___f_435_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__0));
v___x_436_ = lean_box(0);
v___f_437_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_getName___closed__1, &lp_proofEnvironment_Export_Parse_getName___closed__1_once, _init_lp_proofEnvironment_Export_Parse_getName___closed__1);
v___x_438_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v___f_437_, v___f_435_, v_recursorRuleMap_429_, v_ridx_421_, v_r_422_);
if (v_isShared_434_ == 0)
{
lean_ctor_set(v___x_433_, 4, v___x_438_);
v___x_440_ = v___x_433_;
goto v_reusejp_439_;
}
else
{
lean_object* v_reuseFailAlloc_443_; 
v_reuseFailAlloc_443_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_443_, 0, v_stream_425_);
lean_ctor_set(v_reuseFailAlloc_443_, 1, v_nameMap_426_);
lean_ctor_set(v_reuseFailAlloc_443_, 2, v_levelMap_427_);
lean_ctor_set(v_reuseFailAlloc_443_, 3, v_exprMap_428_);
lean_ctor_set(v_reuseFailAlloc_443_, 4, v___x_438_);
lean_ctor_set(v_reuseFailAlloc_443_, 5, v_constMap_430_);
lean_ctor_set(v_reuseFailAlloc_443_, 6, v_constOrder_431_);
v___x_440_ = v_reuseFailAlloc_443_;
goto v_reusejp_439_;
}
v_reusejp_439_:
{
lean_object* v___x_441_; lean_object* v___x_442_; 
v___x_441_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_441_, 0, v___x_436_);
lean_ctor_set(v___x_441_, 1, v___x_440_);
v___x_442_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_442_, 0, v___x_441_);
return v___x_442_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addRecursorRule___boxed(lean_object* v_ridx_445_, lean_object* v_r_446_, lean_object* v_a_447_, lean_object* v_a_448_){
_start:
{
lean_object* v_res_449_; 
v_res_449_ = lp_proofEnvironment_Export_Parse_addRecursorRule(v_ridx_445_, v_r_446_, v_a_447_);
return v_res_449_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addConst(lean_object* v_name_453_, lean_object* v_d_454_, lean_object* v_a_455_){
_start:
{
lean_object* v_stream_457_; lean_object* v_nameMap_458_; lean_object* v_levelMap_459_; lean_object* v_exprMap_460_; lean_object* v_recursorRuleMap_461_; lean_object* v_constMap_462_; lean_object* v_constOrder_463_; lean_object* v___x_465_; uint8_t v_isShared_466_; uint8_t v_isSharedCheck_483_; 
v_stream_457_ = lean_ctor_get(v_a_455_, 0);
v_nameMap_458_ = lean_ctor_get(v_a_455_, 1);
v_levelMap_459_ = lean_ctor_get(v_a_455_, 2);
v_exprMap_460_ = lean_ctor_get(v_a_455_, 3);
v_recursorRuleMap_461_ = lean_ctor_get(v_a_455_, 4);
v_constMap_462_ = lean_ctor_get(v_a_455_, 5);
v_constOrder_463_ = lean_ctor_get(v_a_455_, 6);
v_isSharedCheck_483_ = !lean_is_exclusive(v_a_455_);
if (v_isSharedCheck_483_ == 0)
{
v___x_465_ = v_a_455_;
v_isShared_466_ = v_isSharedCheck_483_;
goto v_resetjp_464_;
}
else
{
lean_inc(v_constOrder_463_);
lean_inc(v_constMap_462_);
lean_inc(v_recursorRuleMap_461_);
lean_inc(v_exprMap_460_);
lean_inc(v_levelMap_459_);
lean_inc(v_nameMap_458_);
lean_inc(v_stream_457_);
lean_dec(v_a_455_);
v___x_465_ = lean_box(0);
v_isShared_466_ = v_isSharedCheck_483_;
goto v_resetjp_464_;
}
v_resetjp_464_:
{
lean_object* v___x_467_; lean_object* v___x_468_; uint8_t v___x_469_; 
v___x_467_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__0));
v___x_468_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__1));
lean_inc(v_name_453_);
v___x_469_ = l_Std_DHashMap_Internal_Raw_u2080_contains___redArg(v___x_467_, v___x_468_, v_constMap_462_, v_name_453_);
if (v___x_469_ == 0)
{
lean_object* v___x_470_; lean_object* v___x_471_; lean_object* v___x_472_; lean_object* v___x_474_; 
v___x_470_ = lean_box(0);
lean_inc(v_name_453_);
v___x_471_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v___x_467_, v___x_468_, v_constMap_462_, v_name_453_, v_d_454_);
v___x_472_ = lean_array_push(v_constOrder_463_, v_name_453_);
if (v_isShared_466_ == 0)
{
lean_ctor_set(v___x_465_, 6, v___x_472_);
lean_ctor_set(v___x_465_, 5, v___x_471_);
v___x_474_ = v___x_465_;
goto v_reusejp_473_;
}
else
{
lean_object* v_reuseFailAlloc_477_; 
v_reuseFailAlloc_477_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_477_, 0, v_stream_457_);
lean_ctor_set(v_reuseFailAlloc_477_, 1, v_nameMap_458_);
lean_ctor_set(v_reuseFailAlloc_477_, 2, v_levelMap_459_);
lean_ctor_set(v_reuseFailAlloc_477_, 3, v_exprMap_460_);
lean_ctor_set(v_reuseFailAlloc_477_, 4, v_recursorRuleMap_461_);
lean_ctor_set(v_reuseFailAlloc_477_, 5, v___x_471_);
lean_ctor_set(v_reuseFailAlloc_477_, 6, v___x_472_);
v___x_474_ = v_reuseFailAlloc_477_;
goto v_reusejp_473_;
}
v_reusejp_473_:
{
lean_object* v___x_475_; lean_object* v___x_476_; 
v___x_475_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_475_, 0, v___x_470_);
lean_ctor_set(v___x_475_, 1, v___x_474_);
v___x_476_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_476_, 0, v___x_475_);
return v___x_476_;
}
}
else
{
lean_object* v___x_478_; lean_object* v___x_479_; lean_object* v___x_480_; lean_object* v___x_481_; lean_object* v___x_482_; 
lean_del_object(v___x_465_);
lean_dec_ref(v_constOrder_463_);
lean_dec_ref(v_constMap_462_);
lean_dec_ref(v_recursorRuleMap_461_);
lean_dec_ref(v_exprMap_460_);
lean_dec_ref(v_levelMap_459_);
lean_dec_ref(v_nameMap_458_);
lean_dec_ref(v_stream_457_);
lean_dec_ref(v_d_454_);
v___x_478_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_479_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_453_, v___x_469_);
v___x_480_ = lean_string_append(v___x_478_, v___x_479_);
lean_dec_ref(v___x_479_);
v___x_481_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_481_, 0, v___x_480_);
v___x_482_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_482_, 0, v___x_481_);
return v___x_482_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_addConst___boxed(lean_object* v_name_484_, lean_object* v_d_485_, lean_object* v_a_486_, lean_object* v_a_487_){
_start:
{
lean_object* v_res_488_; 
v_res_488_ = lp_proofEnvironment_Export_Parse_addConst(v_name_484_, v_d_485_, v_a_486_);
return v_res_488_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj(lean_object* v_line_493_, lean_object* v_a_494_){
_start:
{
lean_object* v___x_499_; lean_object* v___x_500_; 
v___x_499_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseJsonObj___closed__2));
v___x_500_ = l_Std_Internal_Parsec_String_Parser_run___redArg(v___x_499_, v_line_493_);
if (lean_obj_tag(v___x_500_) == 1)
{
lean_object* v_a_501_; 
v_a_501_ = lean_ctor_get(v___x_500_, 0);
lean_inc(v_a_501_);
lean_dec_ref_known(v___x_500_, 1);
if (lean_obj_tag(v_a_501_) == 5)
{
lean_object* v_kvPairs_502_; lean_object* v___x_504_; uint8_t v_isShared_505_; uint8_t v_isSharedCheck_510_; 
v_kvPairs_502_ = lean_ctor_get(v_a_501_, 0);
v_isSharedCheck_510_ = !lean_is_exclusive(v_a_501_);
if (v_isSharedCheck_510_ == 0)
{
v___x_504_ = v_a_501_;
v_isShared_505_ = v_isSharedCheck_510_;
goto v_resetjp_503_;
}
else
{
lean_inc(v_kvPairs_502_);
lean_dec(v_a_501_);
v___x_504_ = lean_box(0);
v_isShared_505_ = v_isSharedCheck_510_;
goto v_resetjp_503_;
}
v_resetjp_503_:
{
lean_object* v___x_506_; lean_object* v___x_508_; 
v___x_506_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_506_, 0, v_kvPairs_502_);
lean_ctor_set(v___x_506_, 1, v_a_494_);
if (v_isShared_505_ == 0)
{
lean_ctor_set_tag(v___x_504_, 0);
lean_ctor_set(v___x_504_, 0, v___x_506_);
v___x_508_ = v___x_504_;
goto v_reusejp_507_;
}
else
{
lean_object* v_reuseFailAlloc_509_; 
v_reuseFailAlloc_509_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_509_, 0, v___x_506_);
v___x_508_ = v_reuseFailAlloc_509_;
goto v_reusejp_507_;
}
v_reusejp_507_:
{
return v___x_508_;
}
}
}
else
{
lean_dec(v_a_501_);
lean_dec_ref(v_a_494_);
goto v___jp_496_;
}
}
else
{
lean_dec_ref(v___x_500_);
lean_dec_ref(v_a_494_);
goto v___jp_496_;
}
v___jp_496_:
{
lean_object* v___x_497_; lean_object* v___x_498_; 
v___x_497_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseJsonObj___closed__1));
v___x_498_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_498_, 0, v___x_497_);
return v___x_498_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseJsonObj___boxed(lean_object* v_line_511_, lean_object* v_a_512_, lean_object* v_a_513_){
_start:
{
lean_object* v_res_514_; 
v_res_514_ = lp_proofEnvironment_Export_Parse_parseJsonObj(v_line_511_, v_a_512_);
return v_res_514_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg(lean_object* v_a_515_, lean_object* v_x_516_){
_start:
{
if (lean_obj_tag(v_x_516_) == 0)
{
lean_object* v___x_517_; 
v___x_517_ = lean_box(0);
return v___x_517_;
}
else
{
lean_object* v_key_518_; lean_object* v_value_519_; lean_object* v_tail_520_; uint8_t v___x_521_; 
v_key_518_ = lean_ctor_get(v_x_516_, 0);
v_value_519_ = lean_ctor_get(v_x_516_, 1);
v_tail_520_ = lean_ctor_get(v_x_516_, 2);
v___x_521_ = lean_nat_dec_eq(v_key_518_, v_a_515_);
if (v___x_521_ == 0)
{
v_x_516_ = v_tail_520_;
goto _start;
}
else
{
lean_object* v___x_523_; 
lean_inc(v_value_519_);
v___x_523_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_523_, 0, v_value_519_);
return v___x_523_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg___boxed(lean_object* v_a_524_, lean_object* v_x_525_){
_start:
{
lean_object* v_res_526_; 
v_res_526_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg(v_a_524_, v_x_525_);
lean_dec(v_x_525_);
lean_dec(v_a_524_);
return v_res_526_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(lean_object* v_m_527_, lean_object* v_a_528_){
_start:
{
lean_object* v_buckets_529_; lean_object* v___x_530_; uint64_t v___x_531_; uint64_t v___x_532_; uint64_t v___x_533_; uint64_t v_fold_534_; uint64_t v___x_535_; uint64_t v___x_536_; uint64_t v___x_537_; size_t v___x_538_; size_t v___x_539_; size_t v___x_540_; size_t v___x_541_; size_t v___x_542_; lean_object* v___x_543_; lean_object* v___x_544_; 
v_buckets_529_ = lean_ctor_get(v_m_527_, 1);
v___x_530_ = lean_array_get_size(v_buckets_529_);
v___x_531_ = lean_uint64_of_nat(v_a_528_);
v___x_532_ = 32ULL;
v___x_533_ = lean_uint64_shift_right(v___x_531_, v___x_532_);
v_fold_534_ = lean_uint64_xor(v___x_531_, v___x_533_);
v___x_535_ = 16ULL;
v___x_536_ = lean_uint64_shift_right(v_fold_534_, v___x_535_);
v___x_537_ = lean_uint64_xor(v_fold_534_, v___x_536_);
v___x_538_ = lean_uint64_to_usize(v___x_537_);
v___x_539_ = lean_usize_of_nat(v___x_530_);
v___x_540_ = ((size_t)1ULL);
v___x_541_ = lean_usize_sub(v___x_539_, v___x_540_);
v___x_542_ = lean_usize_land(v___x_538_, v___x_541_);
v___x_543_ = lean_array_uget_borrowed(v_buckets_529_, v___x_542_);
v___x_544_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg(v_a_528_, v___x_543_);
return v___x_544_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg___boxed(lean_object* v_m_545_, lean_object* v_a_546_){
_start:
{
lean_object* v_res_547_; 
v_res_547_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_m_545_, v_a_546_);
lean_dec(v_a_546_);
lean_dec_ref(v_m_545_);
return v_res_547_;
}
}
static lean_object* _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3(void){
_start:
{
lean_object* v_natZero_552_; lean_object* v_intZero_553_; 
v_natZero_552_ = lean_unsigned_to_nat(0u);
v_intZero_553_ = lean_nat_to_int(v_natZero_552_);
return v_intZero_553_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameStr(lean_object* v_json_555_, lean_object* v_a_556_){
_start:
{
if (lean_obj_tag(v_json_555_) == 5)
{
lean_object* v_kvPairs_564_; lean_object* v___x_565_; lean_object* v___x_566_; 
v_kvPairs_564_ = lean_ctor_get(v_json_555_, 0);
v___x_565_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__2));
v___x_566_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_564_, v___x_565_);
if (lean_obj_tag(v___x_566_) == 1)
{
lean_object* v_val_567_; 
v_val_567_ = lean_ctor_get(v___x_566_, 0);
lean_inc(v_val_567_);
lean_dec_ref_known(v___x_566_, 1);
if (lean_obj_tag(v_val_567_) == 2)
{
lean_object* v_n_568_; lean_object* v_mantissa_569_; lean_object* v_exponent_570_; lean_object* v___x_572_; uint8_t v_isShared_573_; uint8_t v_isSharedCheck_614_; 
v_n_568_ = lean_ctor_get(v_val_567_, 0);
lean_inc_ref(v_n_568_);
lean_dec_ref_known(v_val_567_, 1);
v_mantissa_569_ = lean_ctor_get(v_n_568_, 0);
v_exponent_570_ = lean_ctor_get(v_n_568_, 1);
v_isSharedCheck_614_ = !lean_is_exclusive(v_n_568_);
if (v_isSharedCheck_614_ == 0)
{
v___x_572_ = v_n_568_;
v_isShared_573_ = v_isSharedCheck_614_;
goto v_resetjp_571_;
}
else
{
lean_inc(v_exponent_570_);
lean_inc(v_mantissa_569_);
lean_dec(v_n_568_);
v___x_572_ = lean_box(0);
v_isShared_573_ = v_isSharedCheck_614_;
goto v_resetjp_571_;
}
v_resetjp_571_:
{
lean_object* v_natZero_574_; lean_object* v_intZero_575_; uint8_t v_isNeg_576_; 
v_natZero_574_ = lean_unsigned_to_nat(0u);
v_intZero_575_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_576_ = lean_int_dec_lt(v_mantissa_569_, v_intZero_575_);
if (v_isNeg_576_ == 0)
{
uint8_t v___x_577_; 
v___x_577_ = lean_nat_dec_eq(v_exponent_570_, v_natZero_574_);
lean_dec(v_exponent_570_);
if (v___x_577_ == 0)
{
lean_del_object(v___x_572_);
lean_dec(v_mantissa_569_);
lean_dec_ref(v_a_556_);
goto v___jp_558_;
}
else
{
lean_object* v___x_578_; lean_object* v___x_579_; 
v___x_578_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__4));
v___x_579_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_564_, v___x_578_);
if (lean_obj_tag(v___x_579_) == 1)
{
lean_object* v_val_580_; lean_object* v___x_582_; uint8_t v_isShared_583_; uint8_t v_isSharedCheck_613_; 
v_val_580_ = lean_ctor_get(v___x_579_, 0);
v_isSharedCheck_613_ = !lean_is_exclusive(v___x_579_);
if (v_isSharedCheck_613_ == 0)
{
v___x_582_ = v___x_579_;
v_isShared_583_ = v_isSharedCheck_613_;
goto v_resetjp_581_;
}
else
{
lean_inc(v_val_580_);
lean_dec(v___x_579_);
v___x_582_ = lean_box(0);
v_isShared_583_ = v_isSharedCheck_613_;
goto v_resetjp_581_;
}
v_resetjp_581_:
{
if (lean_obj_tag(v_val_580_) == 3)
{
lean_object* v_s_584_; lean_object* v___x_586_; uint8_t v_isShared_587_; uint8_t v_isSharedCheck_612_; 
v_s_584_ = lean_ctor_get(v_val_580_, 0);
v_isSharedCheck_612_ = !lean_is_exclusive(v_val_580_);
if (v_isSharedCheck_612_ == 0)
{
v___x_586_ = v_val_580_;
v_isShared_587_ = v_isSharedCheck_612_;
goto v_resetjp_585_;
}
else
{
lean_inc(v_s_584_);
lean_dec(v_val_580_);
v___x_586_ = lean_box(0);
v_isShared_587_ = v_isSharedCheck_612_;
goto v_resetjp_585_;
}
v_resetjp_585_:
{
lean_object* v_nameMap_588_; lean_object* v_a_589_; lean_object* v___x_590_; 
v_nameMap_588_ = lean_ctor_get(v_a_556_, 1);
v_a_589_ = lean_nat_abs(v_mantissa_569_);
lean_dec(v_mantissa_569_);
v___x_590_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_588_, v_a_589_);
if (lean_obj_tag(v___x_590_) == 1)
{
lean_object* v_val_591_; lean_object* v___x_593_; uint8_t v_isShared_594_; uint8_t v_isSharedCheck_602_; 
lean_dec(v_a_589_);
lean_del_object(v___x_586_);
lean_del_object(v___x_582_);
v_val_591_ = lean_ctor_get(v___x_590_, 0);
v_isSharedCheck_602_ = !lean_is_exclusive(v___x_590_);
if (v_isSharedCheck_602_ == 0)
{
v___x_593_ = v___x_590_;
v_isShared_594_ = v_isSharedCheck_602_;
goto v_resetjp_592_;
}
else
{
lean_inc(v_val_591_);
lean_dec(v___x_590_);
v___x_593_ = lean_box(0);
v_isShared_594_ = v_isSharedCheck_602_;
goto v_resetjp_592_;
}
v_resetjp_592_:
{
lean_object* v___x_595_; lean_object* v___x_597_; 
v___x_595_ = l_Lean_Name_str___override(v_val_591_, v_s_584_);
if (v_isShared_573_ == 0)
{
lean_ctor_set(v___x_572_, 1, v_a_556_);
lean_ctor_set(v___x_572_, 0, v___x_595_);
v___x_597_ = v___x_572_;
goto v_reusejp_596_;
}
else
{
lean_object* v_reuseFailAlloc_601_; 
v_reuseFailAlloc_601_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_601_, 0, v___x_595_);
lean_ctor_set(v_reuseFailAlloc_601_, 1, v_a_556_);
v___x_597_ = v_reuseFailAlloc_601_;
goto v_reusejp_596_;
}
v_reusejp_596_:
{
lean_object* v___x_599_; 
if (v_isShared_594_ == 0)
{
lean_ctor_set_tag(v___x_593_, 0);
lean_ctor_set(v___x_593_, 0, v___x_597_);
v___x_599_ = v___x_593_;
goto v_reusejp_598_;
}
else
{
lean_object* v_reuseFailAlloc_600_; 
v_reuseFailAlloc_600_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_600_, 0, v___x_597_);
v___x_599_ = v_reuseFailAlloc_600_;
goto v_reusejp_598_;
}
v_reusejp_598_:
{
return v___x_599_;
}
}
}
}
else
{
lean_object* v___x_603_; lean_object* v___x_604_; lean_object* v___x_605_; lean_object* v___x_607_; 
lean_dec(v___x_590_);
lean_dec_ref(v_s_584_);
lean_del_object(v___x_572_);
lean_dec_ref(v_a_556_);
v___x_603_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_604_ = l_Nat_reprFast(v_a_589_);
v___x_605_ = lean_string_append(v___x_603_, v___x_604_);
lean_dec_ref(v___x_604_);
if (v_isShared_587_ == 0)
{
lean_ctor_set_tag(v___x_586_, 18);
lean_ctor_set(v___x_586_, 0, v___x_605_);
v___x_607_ = v___x_586_;
goto v_reusejp_606_;
}
else
{
lean_object* v_reuseFailAlloc_611_; 
v_reuseFailAlloc_611_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_611_, 0, v___x_605_);
v___x_607_ = v_reuseFailAlloc_611_;
goto v_reusejp_606_;
}
v_reusejp_606_:
{
lean_object* v___x_609_; 
if (v_isShared_583_ == 0)
{
lean_ctor_set(v___x_582_, 0, v___x_607_);
v___x_609_ = v___x_582_;
goto v_reusejp_608_;
}
else
{
lean_object* v_reuseFailAlloc_610_; 
v_reuseFailAlloc_610_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_610_, 0, v___x_607_);
v___x_609_ = v_reuseFailAlloc_610_;
goto v_reusejp_608_;
}
v_reusejp_608_:
{
return v___x_609_;
}
}
}
}
}
else
{
lean_del_object(v___x_582_);
lean_dec(v_val_580_);
lean_del_object(v___x_572_);
lean_dec(v_mantissa_569_);
lean_dec_ref(v_a_556_);
goto v___jp_561_;
}
}
}
else
{
lean_dec(v___x_579_);
lean_del_object(v___x_572_);
lean_dec(v_mantissa_569_);
lean_dec_ref(v_a_556_);
goto v___jp_561_;
}
}
}
else
{
lean_del_object(v___x_572_);
lean_dec(v_exponent_570_);
lean_dec(v_mantissa_569_);
lean_dec_ref(v_a_556_);
goto v___jp_558_;
}
}
}
else
{
lean_dec(v_val_567_);
lean_dec_ref(v_a_556_);
goto v___jp_558_;
}
}
else
{
lean_dec(v___x_566_);
lean_dec_ref(v_a_556_);
goto v___jp_558_;
}
}
else
{
lean_object* v___x_615_; lean_object* v___x_616_; 
lean_dec_ref(v_a_556_);
v___x_615_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__1));
v___x_616_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_616_, 0, v___x_615_);
return v___x_616_;
}
v___jp_558_:
{
lean_object* v___x_559_; lean_object* v___x_560_; 
v___x_559_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__1));
v___x_560_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_560_, 0, v___x_559_);
return v___x_560_;
}
v___jp_561_:
{
lean_object* v___x_562_; lean_object* v___x_563_; 
v___x_562_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__1));
v___x_563_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_563_, 0, v___x_562_);
return v___x_563_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameStr___boxed(lean_object* v_json_617_, lean_object* v_a_618_, lean_object* v_a_619_){
_start:
{
lean_object* v_res_620_; 
v_res_620_ = lp_proofEnvironment_Export_Parse_parseNameStr(v_json_617_, v_a_618_);
lean_dec(v_json_617_);
return v_res_620_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0(lean_object* v_00_u03b2_621_, lean_object* v_m_622_, lean_object* v_a_623_){
_start:
{
lean_object* v___x_624_; 
v___x_624_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_m_622_, v_a_623_);
return v___x_624_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___boxed(lean_object* v_00_u03b2_625_, lean_object* v_m_626_, lean_object* v_a_627_){
_start:
{
lean_object* v_res_628_; 
v_res_628_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0(v_00_u03b2_625_, v_m_626_, v_a_627_);
lean_dec(v_a_627_);
lean_dec_ref(v_m_626_);
return v_res_628_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0(lean_object* v_00_u03b2_629_, lean_object* v_a_630_, lean_object* v_x_631_){
_start:
{
lean_object* v___x_632_; 
v___x_632_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___redArg(v_a_630_, v_x_631_);
return v___x_632_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0___boxed(lean_object* v_00_u03b2_633_, lean_object* v_a_634_, lean_object* v_x_635_){
_start:
{
lean_object* v_res_636_; 
v_res_636_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0_spec__0(v_00_u03b2_633_, v_a_634_, v_x_635_);
lean_dec(v_x_635_);
lean_dec(v_a_634_);
return v_res_636_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameNum(lean_object* v_json_641_, lean_object* v_a_642_){
_start:
{
if (lean_obj_tag(v_json_641_) == 5)
{
lean_object* v_kvPairs_650_; lean_object* v___x_651_; lean_object* v___x_652_; 
v_kvPairs_650_ = lean_ctor_get(v_json_641_, 0);
v___x_651_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__2));
v___x_652_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_650_, v___x_651_);
if (lean_obj_tag(v___x_652_) == 1)
{
lean_object* v_val_653_; 
v_val_653_ = lean_ctor_get(v___x_652_, 0);
lean_inc(v_val_653_);
lean_dec_ref_known(v___x_652_, 1);
if (lean_obj_tag(v_val_653_) == 2)
{
lean_object* v_n_654_; lean_object* v_mantissa_655_; lean_object* v_exponent_656_; lean_object* v_natZero_657_; lean_object* v_intZero_658_; uint8_t v_isNeg_659_; 
v_n_654_ = lean_ctor_get(v_val_653_, 0);
lean_inc_ref(v_n_654_);
lean_dec_ref_known(v_val_653_, 1);
v_mantissa_655_ = lean_ctor_get(v_n_654_, 0);
lean_inc(v_mantissa_655_);
v_exponent_656_ = lean_ctor_get(v_n_654_, 1);
lean_inc(v_exponent_656_);
lean_dec_ref(v_n_654_);
v_natZero_657_ = lean_unsigned_to_nat(0u);
v_intZero_658_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_659_ = lean_int_dec_lt(v_mantissa_655_, v_intZero_658_);
if (v_isNeg_659_ == 0)
{
uint8_t v___x_660_; 
v___x_660_ = lean_nat_dec_eq(v_exponent_656_, v_natZero_657_);
lean_dec(v_exponent_656_);
if (v___x_660_ == 0)
{
lean_dec(v_mantissa_655_);
lean_dec_ref(v_a_642_);
goto v___jp_644_;
}
else
{
lean_object* v___x_661_; lean_object* v___x_662_; 
v___x_661_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameNum___closed__2));
v___x_662_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_650_, v___x_661_);
if (lean_obj_tag(v___x_662_) == 1)
{
lean_object* v_val_663_; lean_object* v___x_665_; uint8_t v_isShared_666_; uint8_t v_isSharedCheck_705_; 
v_val_663_ = lean_ctor_get(v___x_662_, 0);
v_isSharedCheck_705_ = !lean_is_exclusive(v___x_662_);
if (v_isSharedCheck_705_ == 0)
{
v___x_665_ = v___x_662_;
v_isShared_666_ = v_isSharedCheck_705_;
goto v_resetjp_664_;
}
else
{
lean_inc(v_val_663_);
lean_dec(v___x_662_);
v___x_665_ = lean_box(0);
v_isShared_666_ = v_isSharedCheck_705_;
goto v_resetjp_664_;
}
v_resetjp_664_:
{
if (lean_obj_tag(v_val_663_) == 2)
{
lean_object* v_n_667_; lean_object* v___x_669_; uint8_t v_isShared_670_; uint8_t v_isSharedCheck_704_; 
v_n_667_ = lean_ctor_get(v_val_663_, 0);
v_isSharedCheck_704_ = !lean_is_exclusive(v_val_663_);
if (v_isSharedCheck_704_ == 0)
{
v___x_669_ = v_val_663_;
v_isShared_670_ = v_isSharedCheck_704_;
goto v_resetjp_668_;
}
else
{
lean_inc(v_n_667_);
lean_dec(v_val_663_);
v___x_669_ = lean_box(0);
v_isShared_670_ = v_isSharedCheck_704_;
goto v_resetjp_668_;
}
v_resetjp_668_:
{
lean_object* v_mantissa_671_; lean_object* v_exponent_672_; lean_object* v___x_674_; uint8_t v_isShared_675_; uint8_t v_isSharedCheck_703_; 
v_mantissa_671_ = lean_ctor_get(v_n_667_, 0);
v_exponent_672_ = lean_ctor_get(v_n_667_, 1);
v_isSharedCheck_703_ = !lean_is_exclusive(v_n_667_);
if (v_isSharedCheck_703_ == 0)
{
v___x_674_ = v_n_667_;
v_isShared_675_ = v_isSharedCheck_703_;
goto v_resetjp_673_;
}
else
{
lean_inc(v_exponent_672_);
lean_inc(v_mantissa_671_);
lean_dec(v_n_667_);
v___x_674_ = lean_box(0);
v_isShared_675_ = v_isSharedCheck_703_;
goto v_resetjp_673_;
}
v_resetjp_673_:
{
uint8_t v_isNeg_676_; 
v_isNeg_676_ = lean_int_dec_lt(v_mantissa_671_, v_intZero_658_);
if (v_isNeg_676_ == 0)
{
uint8_t v___x_677_; 
v___x_677_ = lean_nat_dec_eq(v_exponent_672_, v_natZero_657_);
lean_dec(v_exponent_672_);
if (v___x_677_ == 0)
{
lean_del_object(v___x_674_);
lean_dec(v_mantissa_671_);
lean_del_object(v___x_669_);
lean_del_object(v___x_665_);
lean_dec(v_mantissa_655_);
lean_dec_ref(v_a_642_);
goto v___jp_647_;
}
else
{
lean_object* v_nameMap_678_; lean_object* v_a_679_; lean_object* v___x_680_; 
v_nameMap_678_ = lean_ctor_get(v_a_642_, 1);
v_a_679_ = lean_nat_abs(v_mantissa_655_);
lean_dec(v_mantissa_655_);
v___x_680_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_678_, v_a_679_);
if (lean_obj_tag(v___x_680_) == 1)
{
lean_object* v_val_681_; lean_object* v___x_683_; uint8_t v_isShared_684_; uint8_t v_isSharedCheck_693_; 
lean_dec(v_a_679_);
lean_del_object(v___x_669_);
lean_del_object(v___x_665_);
v_val_681_ = lean_ctor_get(v___x_680_, 0);
v_isSharedCheck_693_ = !lean_is_exclusive(v___x_680_);
if (v_isSharedCheck_693_ == 0)
{
v___x_683_ = v___x_680_;
v_isShared_684_ = v_isSharedCheck_693_;
goto v_resetjp_682_;
}
else
{
lean_inc(v_val_681_);
lean_dec(v___x_680_);
v___x_683_ = lean_box(0);
v_isShared_684_ = v_isSharedCheck_693_;
goto v_resetjp_682_;
}
v_resetjp_682_:
{
lean_object* v_a_685_; lean_object* v___x_686_; lean_object* v___x_688_; 
v_a_685_ = lean_nat_abs(v_mantissa_671_);
lean_dec(v_mantissa_671_);
v___x_686_ = l_Lean_Name_num___override(v_val_681_, v_a_685_);
if (v_isShared_675_ == 0)
{
lean_ctor_set(v___x_674_, 1, v_a_642_);
lean_ctor_set(v___x_674_, 0, v___x_686_);
v___x_688_ = v___x_674_;
goto v_reusejp_687_;
}
else
{
lean_object* v_reuseFailAlloc_692_; 
v_reuseFailAlloc_692_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_692_, 0, v___x_686_);
lean_ctor_set(v_reuseFailAlloc_692_, 1, v_a_642_);
v___x_688_ = v_reuseFailAlloc_692_;
goto v_reusejp_687_;
}
v_reusejp_687_:
{
lean_object* v___x_690_; 
if (v_isShared_684_ == 0)
{
lean_ctor_set_tag(v___x_683_, 0);
lean_ctor_set(v___x_683_, 0, v___x_688_);
v___x_690_ = v___x_683_;
goto v_reusejp_689_;
}
else
{
lean_object* v_reuseFailAlloc_691_; 
v_reuseFailAlloc_691_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_691_, 0, v___x_688_);
v___x_690_ = v_reuseFailAlloc_691_;
goto v_reusejp_689_;
}
v_reusejp_689_:
{
return v___x_690_;
}
}
}
}
else
{
lean_object* v___x_694_; lean_object* v___x_695_; lean_object* v___x_696_; lean_object* v___x_698_; 
lean_dec(v___x_680_);
lean_del_object(v___x_674_);
lean_dec(v_mantissa_671_);
lean_dec_ref(v_a_642_);
v___x_694_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_695_ = l_Nat_reprFast(v_a_679_);
v___x_696_ = lean_string_append(v___x_694_, v___x_695_);
lean_dec_ref(v___x_695_);
if (v_isShared_670_ == 0)
{
lean_ctor_set_tag(v___x_669_, 18);
lean_ctor_set(v___x_669_, 0, v___x_696_);
v___x_698_ = v___x_669_;
goto v_reusejp_697_;
}
else
{
lean_object* v_reuseFailAlloc_702_; 
v_reuseFailAlloc_702_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_702_, 0, v___x_696_);
v___x_698_ = v_reuseFailAlloc_702_;
goto v_reusejp_697_;
}
v_reusejp_697_:
{
lean_object* v___x_700_; 
if (v_isShared_666_ == 0)
{
lean_ctor_set(v___x_665_, 0, v___x_698_);
v___x_700_ = v___x_665_;
goto v_reusejp_699_;
}
else
{
lean_object* v_reuseFailAlloc_701_; 
v_reuseFailAlloc_701_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_701_, 0, v___x_698_);
v___x_700_ = v_reuseFailAlloc_701_;
goto v_reusejp_699_;
}
v_reusejp_699_:
{
return v___x_700_;
}
}
}
}
}
else
{
lean_del_object(v___x_674_);
lean_dec(v_exponent_672_);
lean_dec(v_mantissa_671_);
lean_del_object(v___x_669_);
lean_del_object(v___x_665_);
lean_dec(v_mantissa_655_);
lean_dec_ref(v_a_642_);
goto v___jp_647_;
}
}
}
}
else
{
lean_del_object(v___x_665_);
lean_dec(v_val_663_);
lean_dec(v_mantissa_655_);
lean_dec_ref(v_a_642_);
goto v___jp_647_;
}
}
}
else
{
lean_dec(v___x_662_);
lean_dec(v_mantissa_655_);
lean_dec_ref(v_a_642_);
goto v___jp_647_;
}
}
}
else
{
lean_dec(v_exponent_656_);
lean_dec(v_mantissa_655_);
lean_dec_ref(v_a_642_);
goto v___jp_644_;
}
}
else
{
lean_dec(v_val_653_);
lean_dec_ref(v_a_642_);
goto v___jp_644_;
}
}
else
{
lean_dec(v___x_652_);
lean_dec_ref(v_a_642_);
goto v___jp_644_;
}
}
else
{
lean_object* v___x_706_; lean_object* v___x_707_; 
lean_dec_ref(v_a_642_);
v___x_706_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameNum___closed__1));
v___x_707_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_707_, 0, v___x_706_);
return v___x_707_;
}
v___jp_644_:
{
lean_object* v___x_645_; lean_object* v___x_646_; 
v___x_645_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__1));
v___x_646_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_646_, 0, v___x_645_);
return v___x_646_;
}
v___jp_647_:
{
lean_object* v___x_648_; lean_object* v___x_649_; 
v___x_648_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameNum___closed__1));
v___x_649_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_649_, 0, v___x_648_);
return v___x_649_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseNameNum___boxed(lean_object* v_json_708_, lean_object* v_a_709_, lean_object* v_a_710_){
_start:
{
lean_object* v_res_711_; 
v_res_711_ = lp_proofEnvironment_Export_Parse_parseNameNum(v_json_708_, v_a_709_);
lean_dec(v_json_708_);
return v_res_711_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelSucc(lean_object* v_json_715_, lean_object* v_a_716_){
_start:
{
if (lean_obj_tag(v_json_715_) == 2)
{
lean_object* v_n_721_; lean_object* v___x_723_; uint8_t v_isShared_724_; uint8_t v_isSharedCheck_757_; 
v_n_721_ = lean_ctor_get(v_json_715_, 0);
v_isSharedCheck_757_ = !lean_is_exclusive(v_json_715_);
if (v_isSharedCheck_757_ == 0)
{
v___x_723_ = v_json_715_;
v_isShared_724_ = v_isSharedCheck_757_;
goto v_resetjp_722_;
}
else
{
lean_inc(v_n_721_);
lean_dec(v_json_715_);
v___x_723_ = lean_box(0);
v_isShared_724_ = v_isSharedCheck_757_;
goto v_resetjp_722_;
}
v_resetjp_722_:
{
lean_object* v_mantissa_725_; lean_object* v_exponent_726_; lean_object* v___x_728_; uint8_t v_isShared_729_; uint8_t v_isSharedCheck_756_; 
v_mantissa_725_ = lean_ctor_get(v_n_721_, 0);
v_exponent_726_ = lean_ctor_get(v_n_721_, 1);
v_isSharedCheck_756_ = !lean_is_exclusive(v_n_721_);
if (v_isSharedCheck_756_ == 0)
{
v___x_728_ = v_n_721_;
v_isShared_729_ = v_isSharedCheck_756_;
goto v_resetjp_727_;
}
else
{
lean_inc(v_exponent_726_);
lean_inc(v_mantissa_725_);
lean_dec(v_n_721_);
v___x_728_ = lean_box(0);
v_isShared_729_ = v_isSharedCheck_756_;
goto v_resetjp_727_;
}
v_resetjp_727_:
{
lean_object* v_natZero_730_; lean_object* v_intZero_731_; uint8_t v_isNeg_732_; 
v_natZero_730_ = lean_unsigned_to_nat(0u);
v_intZero_731_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_732_ = lean_int_dec_lt(v_mantissa_725_, v_intZero_731_);
if (v_isNeg_732_ == 0)
{
uint8_t v___x_733_; 
v___x_733_ = lean_nat_dec_eq(v_exponent_726_, v_natZero_730_);
lean_dec(v_exponent_726_);
if (v___x_733_ == 0)
{
lean_del_object(v___x_728_);
lean_dec(v_mantissa_725_);
lean_del_object(v___x_723_);
lean_dec_ref(v_a_716_);
goto v___jp_718_;
}
else
{
lean_object* v_levelMap_734_; lean_object* v_a_735_; lean_object* v___x_736_; 
v_levelMap_734_ = lean_ctor_get(v_a_716_, 2);
v_a_735_ = lean_nat_abs(v_mantissa_725_);
lean_dec(v_mantissa_725_);
v___x_736_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_734_, v_a_735_);
if (lean_obj_tag(v___x_736_) == 1)
{
lean_object* v_val_737_; lean_object* v___x_739_; uint8_t v_isShared_740_; uint8_t v_isSharedCheck_748_; 
lean_dec(v_a_735_);
lean_del_object(v___x_723_);
v_val_737_ = lean_ctor_get(v___x_736_, 0);
v_isSharedCheck_748_ = !lean_is_exclusive(v___x_736_);
if (v_isSharedCheck_748_ == 0)
{
v___x_739_ = v___x_736_;
v_isShared_740_ = v_isSharedCheck_748_;
goto v_resetjp_738_;
}
else
{
lean_inc(v_val_737_);
lean_dec(v___x_736_);
v___x_739_ = lean_box(0);
v_isShared_740_ = v_isSharedCheck_748_;
goto v_resetjp_738_;
}
v_resetjp_738_:
{
lean_object* v___x_741_; lean_object* v___x_743_; 
v___x_741_ = l_Lean_Level_succ___override(v_val_737_);
if (v_isShared_729_ == 0)
{
lean_ctor_set(v___x_728_, 1, v_a_716_);
lean_ctor_set(v___x_728_, 0, v___x_741_);
v___x_743_ = v___x_728_;
goto v_reusejp_742_;
}
else
{
lean_object* v_reuseFailAlloc_747_; 
v_reuseFailAlloc_747_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_747_, 0, v___x_741_);
lean_ctor_set(v_reuseFailAlloc_747_, 1, v_a_716_);
v___x_743_ = v_reuseFailAlloc_747_;
goto v_reusejp_742_;
}
v_reusejp_742_:
{
lean_object* v___x_745_; 
if (v_isShared_740_ == 0)
{
lean_ctor_set_tag(v___x_739_, 0);
lean_ctor_set(v___x_739_, 0, v___x_743_);
v___x_745_ = v___x_739_;
goto v_reusejp_744_;
}
else
{
lean_object* v_reuseFailAlloc_746_; 
v_reuseFailAlloc_746_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_746_, 0, v___x_743_);
v___x_745_ = v_reuseFailAlloc_746_;
goto v_reusejp_744_;
}
v_reusejp_744_:
{
return v___x_745_;
}
}
}
}
else
{
lean_object* v___x_749_; lean_object* v___x_750_; lean_object* v___x_751_; lean_object* v___x_753_; 
lean_dec(v___x_736_);
lean_del_object(v___x_728_);
lean_dec_ref(v_a_716_);
v___x_749_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_750_ = l_Nat_reprFast(v_a_735_);
v___x_751_ = lean_string_append(v___x_749_, v___x_750_);
lean_dec_ref(v___x_750_);
if (v_isShared_724_ == 0)
{
lean_ctor_set_tag(v___x_723_, 18);
lean_ctor_set(v___x_723_, 0, v___x_751_);
v___x_753_ = v___x_723_;
goto v_reusejp_752_;
}
else
{
lean_object* v_reuseFailAlloc_755_; 
v_reuseFailAlloc_755_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_755_, 0, v___x_751_);
v___x_753_ = v_reuseFailAlloc_755_;
goto v_reusejp_752_;
}
v_reusejp_752_:
{
lean_object* v___x_754_; 
v___x_754_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_754_, 0, v___x_753_);
return v___x_754_;
}
}
}
}
else
{
lean_del_object(v___x_728_);
lean_dec(v_exponent_726_);
lean_dec(v_mantissa_725_);
lean_del_object(v___x_723_);
lean_dec_ref(v_a_716_);
goto v___jp_718_;
}
}
}
}
else
{
lean_dec_ref(v_a_716_);
lean_dec(v_json_715_);
goto v___jp_718_;
}
v___jp_718_:
{
lean_object* v___x_719_; lean_object* v___x_720_; 
v___x_719_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseLevelSucc___closed__1));
v___x_720_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_720_, 0, v___x_719_);
return v___x_720_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelSucc___boxed(lean_object* v_json_758_, lean_object* v_a_759_, lean_object* v_a_760_){
_start:
{
lean_object* v_res_761_; 
v_res_761_ = lp_proofEnvironment_Export_Parse_parseLevelSucc(v_json_758_, v_a_759_);
return v_res_761_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelMax(lean_object* v_json_765_, lean_object* v_a_766_){
_start:
{
if (lean_obj_tag(v_json_765_) == 4)
{
lean_object* v_elems_771_; lean_object* v___x_772_; lean_object* v___x_773_; uint8_t v___x_774_; 
v_elems_771_ = lean_ctor_get(v_json_765_, 0);
v___x_772_ = lean_array_get_size(v_elems_771_);
v___x_773_ = lean_unsigned_to_nat(2u);
v___x_774_ = lean_nat_dec_eq(v___x_772_, v___x_773_);
if (v___x_774_ == 0)
{
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
else
{
lean_object* v___x_775_; lean_object* v___x_776_; 
v___x_775_ = lean_unsigned_to_nat(0u);
v___x_776_ = lean_array_fget(v_elems_771_, v___x_775_);
if (lean_obj_tag(v___x_776_) == 2)
{
lean_object* v_n_777_; lean_object* v___x_779_; uint8_t v_isShared_780_; uint8_t v_isSharedCheck_841_; 
v_n_777_ = lean_ctor_get(v___x_776_, 0);
v_isSharedCheck_841_ = !lean_is_exclusive(v___x_776_);
if (v_isSharedCheck_841_ == 0)
{
v___x_779_ = v___x_776_;
v_isShared_780_ = v_isSharedCheck_841_;
goto v_resetjp_778_;
}
else
{
lean_inc(v_n_777_);
lean_dec(v___x_776_);
v___x_779_ = lean_box(0);
v_isShared_780_ = v_isSharedCheck_841_;
goto v_resetjp_778_;
}
v_resetjp_778_:
{
lean_object* v_mantissa_781_; lean_object* v_exponent_782_; lean_object* v_intZero_783_; uint8_t v_isNeg_784_; 
v_mantissa_781_ = lean_ctor_get(v_n_777_, 0);
lean_inc(v_mantissa_781_);
v_exponent_782_ = lean_ctor_get(v_n_777_, 1);
lean_inc(v_exponent_782_);
lean_dec_ref(v_n_777_);
v_intZero_783_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_784_ = lean_int_dec_lt(v_mantissa_781_, v_intZero_783_);
if (v_isNeg_784_ == 0)
{
uint8_t v___x_785_; 
v___x_785_ = lean_nat_dec_eq(v_exponent_782_, v___x_775_);
lean_dec(v_exponent_782_);
if (v___x_785_ == 0)
{
lean_dec(v_mantissa_781_);
lean_del_object(v___x_779_);
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
else
{
lean_object* v___x_786_; lean_object* v___x_787_; 
v___x_786_ = lean_unsigned_to_nat(1u);
v___x_787_ = lean_array_fget(v_elems_771_, v___x_786_);
if (lean_obj_tag(v___x_787_) == 2)
{
lean_object* v_n_788_; lean_object* v___x_790_; uint8_t v_isShared_791_; uint8_t v_isSharedCheck_840_; 
v_n_788_ = lean_ctor_get(v___x_787_, 0);
v_isSharedCheck_840_ = !lean_is_exclusive(v___x_787_);
if (v_isSharedCheck_840_ == 0)
{
v___x_790_ = v___x_787_;
v_isShared_791_ = v_isSharedCheck_840_;
goto v_resetjp_789_;
}
else
{
lean_inc(v_n_788_);
lean_dec(v___x_787_);
v___x_790_ = lean_box(0);
v_isShared_791_ = v_isSharedCheck_840_;
goto v_resetjp_789_;
}
v_resetjp_789_:
{
lean_object* v_mantissa_792_; lean_object* v_exponent_793_; lean_object* v___x_795_; uint8_t v_isShared_796_; uint8_t v_isSharedCheck_839_; 
v_mantissa_792_ = lean_ctor_get(v_n_788_, 0);
v_exponent_793_ = lean_ctor_get(v_n_788_, 1);
v_isSharedCheck_839_ = !lean_is_exclusive(v_n_788_);
if (v_isSharedCheck_839_ == 0)
{
v___x_795_ = v_n_788_;
v_isShared_796_ = v_isSharedCheck_839_;
goto v_resetjp_794_;
}
else
{
lean_inc(v_exponent_793_);
lean_inc(v_mantissa_792_);
lean_dec(v_n_788_);
v___x_795_ = lean_box(0);
v_isShared_796_ = v_isSharedCheck_839_;
goto v_resetjp_794_;
}
v_resetjp_794_:
{
uint8_t v_isNeg_797_; 
v_isNeg_797_ = lean_int_dec_lt(v_mantissa_792_, v_intZero_783_);
if (v_isNeg_797_ == 0)
{
uint8_t v___x_798_; 
v___x_798_ = lean_nat_dec_eq(v_exponent_793_, v___x_775_);
lean_dec(v_exponent_793_);
if (v___x_798_ == 0)
{
lean_del_object(v___x_795_);
lean_dec(v_mantissa_792_);
lean_del_object(v___x_790_);
lean_dec(v_mantissa_781_);
lean_del_object(v___x_779_);
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
else
{
lean_object* v_levelMap_799_; lean_object* v_a_800_; lean_object* v___x_801_; 
v_levelMap_799_ = lean_ctor_get(v_a_766_, 2);
v_a_800_ = lean_nat_abs(v_mantissa_781_);
lean_dec(v_mantissa_781_);
v___x_801_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_799_, v_a_800_);
if (lean_obj_tag(v___x_801_) == 1)
{
lean_object* v_val_802_; lean_object* v___x_804_; uint8_t v_isShared_805_; uint8_t v_isSharedCheck_829_; 
lean_dec(v_a_800_);
lean_del_object(v___x_779_);
v_val_802_ = lean_ctor_get(v___x_801_, 0);
v_isSharedCheck_829_ = !lean_is_exclusive(v___x_801_);
if (v_isSharedCheck_829_ == 0)
{
v___x_804_ = v___x_801_;
v_isShared_805_ = v_isSharedCheck_829_;
goto v_resetjp_803_;
}
else
{
lean_inc(v_val_802_);
lean_dec(v___x_801_);
v___x_804_ = lean_box(0);
v_isShared_805_ = v_isSharedCheck_829_;
goto v_resetjp_803_;
}
v_resetjp_803_:
{
lean_object* v_a_806_; lean_object* v___x_807_; 
v_a_806_ = lean_nat_abs(v_mantissa_792_);
lean_dec(v_mantissa_792_);
v___x_807_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_799_, v_a_806_);
if (lean_obj_tag(v___x_807_) == 1)
{
lean_object* v_val_808_; lean_object* v___x_810_; uint8_t v_isShared_811_; uint8_t v_isSharedCheck_819_; 
lean_dec(v_a_806_);
lean_del_object(v___x_804_);
lean_del_object(v___x_790_);
v_val_808_ = lean_ctor_get(v___x_807_, 0);
v_isSharedCheck_819_ = !lean_is_exclusive(v___x_807_);
if (v_isSharedCheck_819_ == 0)
{
v___x_810_ = v___x_807_;
v_isShared_811_ = v_isSharedCheck_819_;
goto v_resetjp_809_;
}
else
{
lean_inc(v_val_808_);
lean_dec(v___x_807_);
v___x_810_ = lean_box(0);
v_isShared_811_ = v_isSharedCheck_819_;
goto v_resetjp_809_;
}
v_resetjp_809_:
{
lean_object* v___x_812_; lean_object* v___x_814_; 
v___x_812_ = l_Lean_Level_max___override(v_val_802_, v_val_808_);
if (v_isShared_796_ == 0)
{
lean_ctor_set(v___x_795_, 1, v_a_766_);
lean_ctor_set(v___x_795_, 0, v___x_812_);
v___x_814_ = v___x_795_;
goto v_reusejp_813_;
}
else
{
lean_object* v_reuseFailAlloc_818_; 
v_reuseFailAlloc_818_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_818_, 0, v___x_812_);
lean_ctor_set(v_reuseFailAlloc_818_, 1, v_a_766_);
v___x_814_ = v_reuseFailAlloc_818_;
goto v_reusejp_813_;
}
v_reusejp_813_:
{
lean_object* v___x_816_; 
if (v_isShared_811_ == 0)
{
lean_ctor_set_tag(v___x_810_, 0);
lean_ctor_set(v___x_810_, 0, v___x_814_);
v___x_816_ = v___x_810_;
goto v_reusejp_815_;
}
else
{
lean_object* v_reuseFailAlloc_817_; 
v_reuseFailAlloc_817_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_817_, 0, v___x_814_);
v___x_816_ = v_reuseFailAlloc_817_;
goto v_reusejp_815_;
}
v_reusejp_815_:
{
return v___x_816_;
}
}
}
}
else
{
lean_object* v___x_820_; lean_object* v___x_821_; lean_object* v___x_822_; lean_object* v___x_824_; 
lean_dec(v___x_807_);
lean_dec(v_val_802_);
lean_del_object(v___x_795_);
lean_dec_ref(v_a_766_);
v___x_820_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_821_ = l_Nat_reprFast(v_a_806_);
v___x_822_ = lean_string_append(v___x_820_, v___x_821_);
lean_dec_ref(v___x_821_);
if (v_isShared_805_ == 0)
{
lean_ctor_set_tag(v___x_804_, 18);
lean_ctor_set(v___x_804_, 0, v___x_822_);
v___x_824_ = v___x_804_;
goto v_reusejp_823_;
}
else
{
lean_object* v_reuseFailAlloc_828_; 
v_reuseFailAlloc_828_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_828_, 0, v___x_822_);
v___x_824_ = v_reuseFailAlloc_828_;
goto v_reusejp_823_;
}
v_reusejp_823_:
{
lean_object* v___x_826_; 
if (v_isShared_791_ == 0)
{
lean_ctor_set_tag(v___x_790_, 1);
lean_ctor_set(v___x_790_, 0, v___x_824_);
v___x_826_ = v___x_790_;
goto v_reusejp_825_;
}
else
{
lean_object* v_reuseFailAlloc_827_; 
v_reuseFailAlloc_827_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_827_, 0, v___x_824_);
v___x_826_ = v_reuseFailAlloc_827_;
goto v_reusejp_825_;
}
v_reusejp_825_:
{
return v___x_826_;
}
}
}
}
}
else
{
lean_object* v___x_830_; lean_object* v___x_831_; lean_object* v___x_832_; lean_object* v___x_834_; 
lean_dec(v___x_801_);
lean_del_object(v___x_795_);
lean_dec(v_mantissa_792_);
lean_dec_ref(v_a_766_);
v___x_830_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_831_ = l_Nat_reprFast(v_a_800_);
v___x_832_ = lean_string_append(v___x_830_, v___x_831_);
lean_dec_ref(v___x_831_);
if (v_isShared_791_ == 0)
{
lean_ctor_set_tag(v___x_790_, 18);
lean_ctor_set(v___x_790_, 0, v___x_832_);
v___x_834_ = v___x_790_;
goto v_reusejp_833_;
}
else
{
lean_object* v_reuseFailAlloc_838_; 
v_reuseFailAlloc_838_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_838_, 0, v___x_832_);
v___x_834_ = v_reuseFailAlloc_838_;
goto v_reusejp_833_;
}
v_reusejp_833_:
{
lean_object* v___x_836_; 
if (v_isShared_780_ == 0)
{
lean_ctor_set_tag(v___x_779_, 1);
lean_ctor_set(v___x_779_, 0, v___x_834_);
v___x_836_ = v___x_779_;
goto v_reusejp_835_;
}
else
{
lean_object* v_reuseFailAlloc_837_; 
v_reuseFailAlloc_837_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_837_, 0, v___x_834_);
v___x_836_ = v_reuseFailAlloc_837_;
goto v_reusejp_835_;
}
v_reusejp_835_:
{
return v___x_836_;
}
}
}
}
}
else
{
lean_del_object(v___x_795_);
lean_dec(v_exponent_793_);
lean_dec(v_mantissa_792_);
lean_del_object(v___x_790_);
lean_dec(v_mantissa_781_);
lean_del_object(v___x_779_);
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
}
}
}
else
{
lean_dec(v___x_787_);
lean_dec(v_mantissa_781_);
lean_del_object(v___x_779_);
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
}
}
else
{
lean_dec(v_exponent_782_);
lean_dec(v_mantissa_781_);
lean_del_object(v___x_779_);
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
}
}
else
{
lean_dec(v___x_776_);
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
}
}
else
{
lean_dec_ref(v_a_766_);
goto v___jp_768_;
}
v___jp_768_:
{
lean_object* v___x_769_; lean_object* v___x_770_; 
v___x_769_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseLevelMax___closed__1));
v___x_770_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_770_, 0, v___x_769_);
return v___x_770_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelMax___boxed(lean_object* v_json_842_, lean_object* v_a_843_, lean_object* v_a_844_){
_start:
{
lean_object* v_res_845_; 
v_res_845_ = lp_proofEnvironment_Export_Parse_parseLevelMax(v_json_842_, v_a_843_);
lean_dec(v_json_842_);
return v_res_845_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelImax(lean_object* v_json_849_, lean_object* v_a_850_){
_start:
{
if (lean_obj_tag(v_json_849_) == 4)
{
lean_object* v_elems_855_; lean_object* v___x_856_; lean_object* v___x_857_; uint8_t v___x_858_; 
v_elems_855_ = lean_ctor_get(v_json_849_, 0);
v___x_856_ = lean_array_get_size(v_elems_855_);
v___x_857_ = lean_unsigned_to_nat(2u);
v___x_858_ = lean_nat_dec_eq(v___x_856_, v___x_857_);
if (v___x_858_ == 0)
{
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
else
{
lean_object* v___x_859_; lean_object* v___x_860_; 
v___x_859_ = lean_unsigned_to_nat(0u);
v___x_860_ = lean_array_fget(v_elems_855_, v___x_859_);
if (lean_obj_tag(v___x_860_) == 2)
{
lean_object* v_n_861_; lean_object* v___x_863_; uint8_t v_isShared_864_; uint8_t v_isSharedCheck_925_; 
v_n_861_ = lean_ctor_get(v___x_860_, 0);
v_isSharedCheck_925_ = !lean_is_exclusive(v___x_860_);
if (v_isSharedCheck_925_ == 0)
{
v___x_863_ = v___x_860_;
v_isShared_864_ = v_isSharedCheck_925_;
goto v_resetjp_862_;
}
else
{
lean_inc(v_n_861_);
lean_dec(v___x_860_);
v___x_863_ = lean_box(0);
v_isShared_864_ = v_isSharedCheck_925_;
goto v_resetjp_862_;
}
v_resetjp_862_:
{
lean_object* v_mantissa_865_; lean_object* v_exponent_866_; lean_object* v_intZero_867_; uint8_t v_isNeg_868_; 
v_mantissa_865_ = lean_ctor_get(v_n_861_, 0);
lean_inc(v_mantissa_865_);
v_exponent_866_ = lean_ctor_get(v_n_861_, 1);
lean_inc(v_exponent_866_);
lean_dec_ref(v_n_861_);
v_intZero_867_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_868_ = lean_int_dec_lt(v_mantissa_865_, v_intZero_867_);
if (v_isNeg_868_ == 0)
{
uint8_t v___x_869_; 
v___x_869_ = lean_nat_dec_eq(v_exponent_866_, v___x_859_);
lean_dec(v_exponent_866_);
if (v___x_869_ == 0)
{
lean_dec(v_mantissa_865_);
lean_del_object(v___x_863_);
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
else
{
lean_object* v___x_870_; lean_object* v___x_871_; 
v___x_870_ = lean_unsigned_to_nat(1u);
v___x_871_ = lean_array_fget(v_elems_855_, v___x_870_);
if (lean_obj_tag(v___x_871_) == 2)
{
lean_object* v_n_872_; lean_object* v___x_874_; uint8_t v_isShared_875_; uint8_t v_isSharedCheck_924_; 
v_n_872_ = lean_ctor_get(v___x_871_, 0);
v_isSharedCheck_924_ = !lean_is_exclusive(v___x_871_);
if (v_isSharedCheck_924_ == 0)
{
v___x_874_ = v___x_871_;
v_isShared_875_ = v_isSharedCheck_924_;
goto v_resetjp_873_;
}
else
{
lean_inc(v_n_872_);
lean_dec(v___x_871_);
v___x_874_ = lean_box(0);
v_isShared_875_ = v_isSharedCheck_924_;
goto v_resetjp_873_;
}
v_resetjp_873_:
{
lean_object* v_mantissa_876_; lean_object* v_exponent_877_; lean_object* v___x_879_; uint8_t v_isShared_880_; uint8_t v_isSharedCheck_923_; 
v_mantissa_876_ = lean_ctor_get(v_n_872_, 0);
v_exponent_877_ = lean_ctor_get(v_n_872_, 1);
v_isSharedCheck_923_ = !lean_is_exclusive(v_n_872_);
if (v_isSharedCheck_923_ == 0)
{
v___x_879_ = v_n_872_;
v_isShared_880_ = v_isSharedCheck_923_;
goto v_resetjp_878_;
}
else
{
lean_inc(v_exponent_877_);
lean_inc(v_mantissa_876_);
lean_dec(v_n_872_);
v___x_879_ = lean_box(0);
v_isShared_880_ = v_isSharedCheck_923_;
goto v_resetjp_878_;
}
v_resetjp_878_:
{
uint8_t v_isNeg_881_; 
v_isNeg_881_ = lean_int_dec_lt(v_mantissa_876_, v_intZero_867_);
if (v_isNeg_881_ == 0)
{
uint8_t v___x_882_; 
v___x_882_ = lean_nat_dec_eq(v_exponent_877_, v___x_859_);
lean_dec(v_exponent_877_);
if (v___x_882_ == 0)
{
lean_del_object(v___x_879_);
lean_dec(v_mantissa_876_);
lean_del_object(v___x_874_);
lean_dec(v_mantissa_865_);
lean_del_object(v___x_863_);
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
else
{
lean_object* v_levelMap_883_; lean_object* v_a_884_; lean_object* v___x_885_; 
v_levelMap_883_ = lean_ctor_get(v_a_850_, 2);
v_a_884_ = lean_nat_abs(v_mantissa_865_);
lean_dec(v_mantissa_865_);
v___x_885_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_883_, v_a_884_);
if (lean_obj_tag(v___x_885_) == 1)
{
lean_object* v_val_886_; lean_object* v___x_888_; uint8_t v_isShared_889_; uint8_t v_isSharedCheck_913_; 
lean_dec(v_a_884_);
lean_del_object(v___x_863_);
v_val_886_ = lean_ctor_get(v___x_885_, 0);
v_isSharedCheck_913_ = !lean_is_exclusive(v___x_885_);
if (v_isSharedCheck_913_ == 0)
{
v___x_888_ = v___x_885_;
v_isShared_889_ = v_isSharedCheck_913_;
goto v_resetjp_887_;
}
else
{
lean_inc(v_val_886_);
lean_dec(v___x_885_);
v___x_888_ = lean_box(0);
v_isShared_889_ = v_isSharedCheck_913_;
goto v_resetjp_887_;
}
v_resetjp_887_:
{
lean_object* v_a_890_; lean_object* v___x_891_; 
v_a_890_ = lean_nat_abs(v_mantissa_876_);
lean_dec(v_mantissa_876_);
v___x_891_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_883_, v_a_890_);
if (lean_obj_tag(v___x_891_) == 1)
{
lean_object* v_val_892_; lean_object* v___x_894_; uint8_t v_isShared_895_; uint8_t v_isSharedCheck_903_; 
lean_dec(v_a_890_);
lean_del_object(v___x_888_);
lean_del_object(v___x_874_);
v_val_892_ = lean_ctor_get(v___x_891_, 0);
v_isSharedCheck_903_ = !lean_is_exclusive(v___x_891_);
if (v_isSharedCheck_903_ == 0)
{
v___x_894_ = v___x_891_;
v_isShared_895_ = v_isSharedCheck_903_;
goto v_resetjp_893_;
}
else
{
lean_inc(v_val_892_);
lean_dec(v___x_891_);
v___x_894_ = lean_box(0);
v_isShared_895_ = v_isSharedCheck_903_;
goto v_resetjp_893_;
}
v_resetjp_893_:
{
lean_object* v___x_896_; lean_object* v___x_898_; 
v___x_896_ = l_Lean_Level_imax___override(v_val_886_, v_val_892_);
if (v_isShared_880_ == 0)
{
lean_ctor_set(v___x_879_, 1, v_a_850_);
lean_ctor_set(v___x_879_, 0, v___x_896_);
v___x_898_ = v___x_879_;
goto v_reusejp_897_;
}
else
{
lean_object* v_reuseFailAlloc_902_; 
v_reuseFailAlloc_902_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_902_, 0, v___x_896_);
lean_ctor_set(v_reuseFailAlloc_902_, 1, v_a_850_);
v___x_898_ = v_reuseFailAlloc_902_;
goto v_reusejp_897_;
}
v_reusejp_897_:
{
lean_object* v___x_900_; 
if (v_isShared_895_ == 0)
{
lean_ctor_set_tag(v___x_894_, 0);
lean_ctor_set(v___x_894_, 0, v___x_898_);
v___x_900_ = v___x_894_;
goto v_reusejp_899_;
}
else
{
lean_object* v_reuseFailAlloc_901_; 
v_reuseFailAlloc_901_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_901_, 0, v___x_898_);
v___x_900_ = v_reuseFailAlloc_901_;
goto v_reusejp_899_;
}
v_reusejp_899_:
{
return v___x_900_;
}
}
}
}
else
{
lean_object* v___x_904_; lean_object* v___x_905_; lean_object* v___x_906_; lean_object* v___x_908_; 
lean_dec(v___x_891_);
lean_dec(v_val_886_);
lean_del_object(v___x_879_);
lean_dec_ref(v_a_850_);
v___x_904_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_905_ = l_Nat_reprFast(v_a_890_);
v___x_906_ = lean_string_append(v___x_904_, v___x_905_);
lean_dec_ref(v___x_905_);
if (v_isShared_889_ == 0)
{
lean_ctor_set_tag(v___x_888_, 18);
lean_ctor_set(v___x_888_, 0, v___x_906_);
v___x_908_ = v___x_888_;
goto v_reusejp_907_;
}
else
{
lean_object* v_reuseFailAlloc_912_; 
v_reuseFailAlloc_912_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_912_, 0, v___x_906_);
v___x_908_ = v_reuseFailAlloc_912_;
goto v_reusejp_907_;
}
v_reusejp_907_:
{
lean_object* v___x_910_; 
if (v_isShared_875_ == 0)
{
lean_ctor_set_tag(v___x_874_, 1);
lean_ctor_set(v___x_874_, 0, v___x_908_);
v___x_910_ = v___x_874_;
goto v_reusejp_909_;
}
else
{
lean_object* v_reuseFailAlloc_911_; 
v_reuseFailAlloc_911_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_911_, 0, v___x_908_);
v___x_910_ = v_reuseFailAlloc_911_;
goto v_reusejp_909_;
}
v_reusejp_909_:
{
return v___x_910_;
}
}
}
}
}
else
{
lean_object* v___x_914_; lean_object* v___x_915_; lean_object* v___x_916_; lean_object* v___x_918_; 
lean_dec(v___x_885_);
lean_del_object(v___x_879_);
lean_dec(v_mantissa_876_);
lean_dec_ref(v_a_850_);
v___x_914_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_915_ = l_Nat_reprFast(v_a_884_);
v___x_916_ = lean_string_append(v___x_914_, v___x_915_);
lean_dec_ref(v___x_915_);
if (v_isShared_875_ == 0)
{
lean_ctor_set_tag(v___x_874_, 18);
lean_ctor_set(v___x_874_, 0, v___x_916_);
v___x_918_ = v___x_874_;
goto v_reusejp_917_;
}
else
{
lean_object* v_reuseFailAlloc_922_; 
v_reuseFailAlloc_922_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_922_, 0, v___x_916_);
v___x_918_ = v_reuseFailAlloc_922_;
goto v_reusejp_917_;
}
v_reusejp_917_:
{
lean_object* v___x_920_; 
if (v_isShared_864_ == 0)
{
lean_ctor_set_tag(v___x_863_, 1);
lean_ctor_set(v___x_863_, 0, v___x_918_);
v___x_920_ = v___x_863_;
goto v_reusejp_919_;
}
else
{
lean_object* v_reuseFailAlloc_921_; 
v_reuseFailAlloc_921_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_921_, 0, v___x_918_);
v___x_920_ = v_reuseFailAlloc_921_;
goto v_reusejp_919_;
}
v_reusejp_919_:
{
return v___x_920_;
}
}
}
}
}
else
{
lean_del_object(v___x_879_);
lean_dec(v_exponent_877_);
lean_dec(v_mantissa_876_);
lean_del_object(v___x_874_);
lean_dec(v_mantissa_865_);
lean_del_object(v___x_863_);
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
}
}
}
else
{
lean_dec(v___x_871_);
lean_dec(v_mantissa_865_);
lean_del_object(v___x_863_);
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
}
}
else
{
lean_dec(v_exponent_866_);
lean_dec(v_mantissa_865_);
lean_del_object(v___x_863_);
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
}
}
else
{
lean_dec(v___x_860_);
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
}
}
else
{
lean_dec_ref(v_a_850_);
goto v___jp_852_;
}
v___jp_852_:
{
lean_object* v___x_853_; lean_object* v___x_854_; 
v___x_853_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseLevelImax___closed__1));
v___x_854_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_854_, 0, v___x_853_);
return v___x_854_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelImax___boxed(lean_object* v_json_926_, lean_object* v_a_927_, lean_object* v_a_928_){
_start:
{
lean_object* v_res_929_; 
v_res_929_ = lp_proofEnvironment_Export_Parse_parseLevelImax(v_json_926_, v_a_927_);
lean_dec(v_json_926_);
return v_res_929_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelParam(lean_object* v_json_933_, lean_object* v_a_934_){
_start:
{
if (lean_obj_tag(v_json_933_) == 2)
{
lean_object* v_n_939_; lean_object* v___x_941_; uint8_t v_isShared_942_; uint8_t v_isSharedCheck_975_; 
v_n_939_ = lean_ctor_get(v_json_933_, 0);
v_isSharedCheck_975_ = !lean_is_exclusive(v_json_933_);
if (v_isSharedCheck_975_ == 0)
{
v___x_941_ = v_json_933_;
v_isShared_942_ = v_isSharedCheck_975_;
goto v_resetjp_940_;
}
else
{
lean_inc(v_n_939_);
lean_dec(v_json_933_);
v___x_941_ = lean_box(0);
v_isShared_942_ = v_isSharedCheck_975_;
goto v_resetjp_940_;
}
v_resetjp_940_:
{
lean_object* v_mantissa_943_; lean_object* v_exponent_944_; lean_object* v___x_946_; uint8_t v_isShared_947_; uint8_t v_isSharedCheck_974_; 
v_mantissa_943_ = lean_ctor_get(v_n_939_, 0);
v_exponent_944_ = lean_ctor_get(v_n_939_, 1);
v_isSharedCheck_974_ = !lean_is_exclusive(v_n_939_);
if (v_isSharedCheck_974_ == 0)
{
v___x_946_ = v_n_939_;
v_isShared_947_ = v_isSharedCheck_974_;
goto v_resetjp_945_;
}
else
{
lean_inc(v_exponent_944_);
lean_inc(v_mantissa_943_);
lean_dec(v_n_939_);
v___x_946_ = lean_box(0);
v_isShared_947_ = v_isSharedCheck_974_;
goto v_resetjp_945_;
}
v_resetjp_945_:
{
lean_object* v_natZero_948_; lean_object* v_intZero_949_; uint8_t v_isNeg_950_; 
v_natZero_948_ = lean_unsigned_to_nat(0u);
v_intZero_949_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_950_ = lean_int_dec_lt(v_mantissa_943_, v_intZero_949_);
if (v_isNeg_950_ == 0)
{
uint8_t v___x_951_; 
v___x_951_ = lean_nat_dec_eq(v_exponent_944_, v_natZero_948_);
lean_dec(v_exponent_944_);
if (v___x_951_ == 0)
{
lean_del_object(v___x_946_);
lean_dec(v_mantissa_943_);
lean_del_object(v___x_941_);
lean_dec_ref(v_a_934_);
goto v___jp_936_;
}
else
{
lean_object* v_nameMap_952_; lean_object* v_a_953_; lean_object* v___x_954_; 
v_nameMap_952_ = lean_ctor_get(v_a_934_, 1);
v_a_953_ = lean_nat_abs(v_mantissa_943_);
lean_dec(v_mantissa_943_);
v___x_954_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_952_, v_a_953_);
if (lean_obj_tag(v___x_954_) == 1)
{
lean_object* v_val_955_; lean_object* v___x_957_; uint8_t v_isShared_958_; uint8_t v_isSharedCheck_966_; 
lean_dec(v_a_953_);
lean_del_object(v___x_941_);
v_val_955_ = lean_ctor_get(v___x_954_, 0);
v_isSharedCheck_966_ = !lean_is_exclusive(v___x_954_);
if (v_isSharedCheck_966_ == 0)
{
v___x_957_ = v___x_954_;
v_isShared_958_ = v_isSharedCheck_966_;
goto v_resetjp_956_;
}
else
{
lean_inc(v_val_955_);
lean_dec(v___x_954_);
v___x_957_ = lean_box(0);
v_isShared_958_ = v_isSharedCheck_966_;
goto v_resetjp_956_;
}
v_resetjp_956_:
{
lean_object* v___x_959_; lean_object* v___x_961_; 
v___x_959_ = l_Lean_Level_param___override(v_val_955_);
if (v_isShared_947_ == 0)
{
lean_ctor_set(v___x_946_, 1, v_a_934_);
lean_ctor_set(v___x_946_, 0, v___x_959_);
v___x_961_ = v___x_946_;
goto v_reusejp_960_;
}
else
{
lean_object* v_reuseFailAlloc_965_; 
v_reuseFailAlloc_965_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_965_, 0, v___x_959_);
lean_ctor_set(v_reuseFailAlloc_965_, 1, v_a_934_);
v___x_961_ = v_reuseFailAlloc_965_;
goto v_reusejp_960_;
}
v_reusejp_960_:
{
lean_object* v___x_963_; 
if (v_isShared_958_ == 0)
{
lean_ctor_set_tag(v___x_957_, 0);
lean_ctor_set(v___x_957_, 0, v___x_961_);
v___x_963_ = v___x_957_;
goto v_reusejp_962_;
}
else
{
lean_object* v_reuseFailAlloc_964_; 
v_reuseFailAlloc_964_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_964_, 0, v___x_961_);
v___x_963_ = v_reuseFailAlloc_964_;
goto v_reusejp_962_;
}
v_reusejp_962_:
{
return v___x_963_;
}
}
}
}
else
{
lean_object* v___x_967_; lean_object* v___x_968_; lean_object* v___x_969_; lean_object* v___x_971_; 
lean_dec(v___x_954_);
lean_del_object(v___x_946_);
lean_dec_ref(v_a_934_);
v___x_967_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_968_ = l_Nat_reprFast(v_a_953_);
v___x_969_ = lean_string_append(v___x_967_, v___x_968_);
lean_dec_ref(v___x_968_);
if (v_isShared_942_ == 0)
{
lean_ctor_set_tag(v___x_941_, 18);
lean_ctor_set(v___x_941_, 0, v___x_969_);
v___x_971_ = v___x_941_;
goto v_reusejp_970_;
}
else
{
lean_object* v_reuseFailAlloc_973_; 
v_reuseFailAlloc_973_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_973_, 0, v___x_969_);
v___x_971_ = v_reuseFailAlloc_973_;
goto v_reusejp_970_;
}
v_reusejp_970_:
{
lean_object* v___x_972_; 
v___x_972_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_972_, 0, v___x_971_);
return v___x_972_;
}
}
}
}
else
{
lean_del_object(v___x_946_);
lean_dec(v_exponent_944_);
lean_dec(v_mantissa_943_);
lean_del_object(v___x_941_);
lean_dec_ref(v_a_934_);
goto v___jp_936_;
}
}
}
}
else
{
lean_dec_ref(v_a_934_);
lean_dec(v_json_933_);
goto v___jp_936_;
}
v___jp_936_:
{
lean_object* v___x_937_; lean_object* v___x_938_; 
v___x_937_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseLevelParam___closed__1));
v___x_938_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_938_, 0, v___x_937_);
return v___x_938_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseLevelParam___boxed(lean_object* v_json_976_, lean_object* v_a_977_, lean_object* v_a_978_){
_start:
{
lean_object* v_res_979_; 
v_res_979_ = lp_proofEnvironment_Export_Parse_parseLevelParam(v_json_976_, v_a_977_);
return v_res_979_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprBVar(lean_object* v_json_983_, lean_object* v_a_984_){
_start:
{
if (lean_obj_tag(v_json_983_) == 2)
{
lean_object* v_n_989_; lean_object* v___x_991_; uint8_t v_isShared_992_; uint8_t v_isSharedCheck_1011_; 
v_n_989_ = lean_ctor_get(v_json_983_, 0);
v_isSharedCheck_1011_ = !lean_is_exclusive(v_json_983_);
if (v_isSharedCheck_1011_ == 0)
{
v___x_991_ = v_json_983_;
v_isShared_992_ = v_isSharedCheck_1011_;
goto v_resetjp_990_;
}
else
{
lean_inc(v_n_989_);
lean_dec(v_json_983_);
v___x_991_ = lean_box(0);
v_isShared_992_ = v_isSharedCheck_1011_;
goto v_resetjp_990_;
}
v_resetjp_990_:
{
lean_object* v_mantissa_993_; lean_object* v_exponent_994_; lean_object* v___x_996_; uint8_t v_isShared_997_; uint8_t v_isSharedCheck_1010_; 
v_mantissa_993_ = lean_ctor_get(v_n_989_, 0);
v_exponent_994_ = lean_ctor_get(v_n_989_, 1);
v_isSharedCheck_1010_ = !lean_is_exclusive(v_n_989_);
if (v_isSharedCheck_1010_ == 0)
{
v___x_996_ = v_n_989_;
v_isShared_997_ = v_isSharedCheck_1010_;
goto v_resetjp_995_;
}
else
{
lean_inc(v_exponent_994_);
lean_inc(v_mantissa_993_);
lean_dec(v_n_989_);
v___x_996_ = lean_box(0);
v_isShared_997_ = v_isSharedCheck_1010_;
goto v_resetjp_995_;
}
v_resetjp_995_:
{
lean_object* v_natZero_998_; lean_object* v_intZero_999_; uint8_t v_isNeg_1000_; 
v_natZero_998_ = lean_unsigned_to_nat(0u);
v_intZero_999_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1000_ = lean_int_dec_lt(v_mantissa_993_, v_intZero_999_);
if (v_isNeg_1000_ == 0)
{
uint8_t v___x_1001_; 
v___x_1001_ = lean_nat_dec_eq(v_exponent_994_, v_natZero_998_);
lean_dec(v_exponent_994_);
if (v___x_1001_ == 0)
{
lean_del_object(v___x_996_);
lean_dec(v_mantissa_993_);
lean_del_object(v___x_991_);
lean_dec_ref(v_a_984_);
goto v___jp_986_;
}
else
{
lean_object* v_a_1002_; lean_object* v___x_1003_; lean_object* v___x_1005_; 
v_a_1002_ = lean_nat_abs(v_mantissa_993_);
lean_dec(v_mantissa_993_);
v___x_1003_ = l_Lean_Expr_bvar___override(v_a_1002_);
if (v_isShared_997_ == 0)
{
lean_ctor_set(v___x_996_, 1, v_a_984_);
lean_ctor_set(v___x_996_, 0, v___x_1003_);
v___x_1005_ = v___x_996_;
goto v_reusejp_1004_;
}
else
{
lean_object* v_reuseFailAlloc_1009_; 
v_reuseFailAlloc_1009_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1009_, 0, v___x_1003_);
lean_ctor_set(v_reuseFailAlloc_1009_, 1, v_a_984_);
v___x_1005_ = v_reuseFailAlloc_1009_;
goto v_reusejp_1004_;
}
v_reusejp_1004_:
{
lean_object* v___x_1007_; 
if (v_isShared_992_ == 0)
{
lean_ctor_set_tag(v___x_991_, 0);
lean_ctor_set(v___x_991_, 0, v___x_1005_);
v___x_1007_ = v___x_991_;
goto v_reusejp_1006_;
}
else
{
lean_object* v_reuseFailAlloc_1008_; 
v_reuseFailAlloc_1008_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1008_, 0, v___x_1005_);
v___x_1007_ = v_reuseFailAlloc_1008_;
goto v_reusejp_1006_;
}
v_reusejp_1006_:
{
return v___x_1007_;
}
}
}
}
else
{
lean_del_object(v___x_996_);
lean_dec(v_exponent_994_);
lean_dec(v_mantissa_993_);
lean_del_object(v___x_991_);
lean_dec_ref(v_a_984_);
goto v___jp_986_;
}
}
}
}
else
{
lean_dec_ref(v_a_984_);
lean_dec(v_json_983_);
goto v___jp_986_;
}
v___jp_986_:
{
lean_object* v___x_987_; lean_object* v___x_988_; 
v___x_987_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprBVar___closed__1));
v___x_988_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_988_, 0, v___x_987_);
return v___x_988_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprBVar___boxed(lean_object* v_json_1012_, lean_object* v_a_1013_, lean_object* v_a_1014_){
_start:
{
lean_object* v_res_1015_; 
v_res_1015_ = lp_proofEnvironment_Export_Parse_parseExprBVar(v_json_1012_, v_a_1013_);
return v_res_1015_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprSort(lean_object* v_json_1019_, lean_object* v_a_1020_){
_start:
{
if (lean_obj_tag(v_json_1019_) == 2)
{
lean_object* v_n_1025_; lean_object* v___x_1027_; uint8_t v_isShared_1028_; uint8_t v_isSharedCheck_1061_; 
v_n_1025_ = lean_ctor_get(v_json_1019_, 0);
v_isSharedCheck_1061_ = !lean_is_exclusive(v_json_1019_);
if (v_isSharedCheck_1061_ == 0)
{
v___x_1027_ = v_json_1019_;
v_isShared_1028_ = v_isSharedCheck_1061_;
goto v_resetjp_1026_;
}
else
{
lean_inc(v_n_1025_);
lean_dec(v_json_1019_);
v___x_1027_ = lean_box(0);
v_isShared_1028_ = v_isSharedCheck_1061_;
goto v_resetjp_1026_;
}
v_resetjp_1026_:
{
lean_object* v_mantissa_1029_; lean_object* v_exponent_1030_; lean_object* v___x_1032_; uint8_t v_isShared_1033_; uint8_t v_isSharedCheck_1060_; 
v_mantissa_1029_ = lean_ctor_get(v_n_1025_, 0);
v_exponent_1030_ = lean_ctor_get(v_n_1025_, 1);
v_isSharedCheck_1060_ = !lean_is_exclusive(v_n_1025_);
if (v_isSharedCheck_1060_ == 0)
{
v___x_1032_ = v_n_1025_;
v_isShared_1033_ = v_isSharedCheck_1060_;
goto v_resetjp_1031_;
}
else
{
lean_inc(v_exponent_1030_);
lean_inc(v_mantissa_1029_);
lean_dec(v_n_1025_);
v___x_1032_ = lean_box(0);
v_isShared_1033_ = v_isSharedCheck_1060_;
goto v_resetjp_1031_;
}
v_resetjp_1031_:
{
lean_object* v_natZero_1034_; lean_object* v_intZero_1035_; uint8_t v_isNeg_1036_; 
v_natZero_1034_ = lean_unsigned_to_nat(0u);
v_intZero_1035_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1036_ = lean_int_dec_lt(v_mantissa_1029_, v_intZero_1035_);
if (v_isNeg_1036_ == 0)
{
uint8_t v___x_1037_; 
v___x_1037_ = lean_nat_dec_eq(v_exponent_1030_, v_natZero_1034_);
lean_dec(v_exponent_1030_);
if (v___x_1037_ == 0)
{
lean_del_object(v___x_1032_);
lean_dec(v_mantissa_1029_);
lean_del_object(v___x_1027_);
lean_dec_ref(v_a_1020_);
goto v___jp_1022_;
}
else
{
lean_object* v_levelMap_1038_; lean_object* v_a_1039_; lean_object* v___x_1040_; 
v_levelMap_1038_ = lean_ctor_get(v_a_1020_, 2);
v_a_1039_ = lean_nat_abs(v_mantissa_1029_);
lean_dec(v_mantissa_1029_);
v___x_1040_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_1038_, v_a_1039_);
if (lean_obj_tag(v___x_1040_) == 1)
{
lean_object* v_val_1041_; lean_object* v___x_1043_; uint8_t v_isShared_1044_; uint8_t v_isSharedCheck_1052_; 
lean_dec(v_a_1039_);
lean_del_object(v___x_1027_);
v_val_1041_ = lean_ctor_get(v___x_1040_, 0);
v_isSharedCheck_1052_ = !lean_is_exclusive(v___x_1040_);
if (v_isSharedCheck_1052_ == 0)
{
v___x_1043_ = v___x_1040_;
v_isShared_1044_ = v_isSharedCheck_1052_;
goto v_resetjp_1042_;
}
else
{
lean_inc(v_val_1041_);
lean_dec(v___x_1040_);
v___x_1043_ = lean_box(0);
v_isShared_1044_ = v_isSharedCheck_1052_;
goto v_resetjp_1042_;
}
v_resetjp_1042_:
{
lean_object* v___x_1045_; lean_object* v___x_1047_; 
v___x_1045_ = l_Lean_Expr_sort___override(v_val_1041_);
if (v_isShared_1033_ == 0)
{
lean_ctor_set(v___x_1032_, 1, v_a_1020_);
lean_ctor_set(v___x_1032_, 0, v___x_1045_);
v___x_1047_ = v___x_1032_;
goto v_reusejp_1046_;
}
else
{
lean_object* v_reuseFailAlloc_1051_; 
v_reuseFailAlloc_1051_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1051_, 0, v___x_1045_);
lean_ctor_set(v_reuseFailAlloc_1051_, 1, v_a_1020_);
v___x_1047_ = v_reuseFailAlloc_1051_;
goto v_reusejp_1046_;
}
v_reusejp_1046_:
{
lean_object* v___x_1049_; 
if (v_isShared_1044_ == 0)
{
lean_ctor_set_tag(v___x_1043_, 0);
lean_ctor_set(v___x_1043_, 0, v___x_1047_);
v___x_1049_ = v___x_1043_;
goto v_reusejp_1048_;
}
else
{
lean_object* v_reuseFailAlloc_1050_; 
v_reuseFailAlloc_1050_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1050_, 0, v___x_1047_);
v___x_1049_ = v_reuseFailAlloc_1050_;
goto v_reusejp_1048_;
}
v_reusejp_1048_:
{
return v___x_1049_;
}
}
}
}
else
{
lean_object* v___x_1053_; lean_object* v___x_1054_; lean_object* v___x_1055_; lean_object* v___x_1057_; 
lean_dec(v___x_1040_);
lean_del_object(v___x_1032_);
lean_dec_ref(v_a_1020_);
v___x_1053_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_1054_ = l_Nat_reprFast(v_a_1039_);
v___x_1055_ = lean_string_append(v___x_1053_, v___x_1054_);
lean_dec_ref(v___x_1054_);
if (v_isShared_1028_ == 0)
{
lean_ctor_set_tag(v___x_1027_, 18);
lean_ctor_set(v___x_1027_, 0, v___x_1055_);
v___x_1057_ = v___x_1027_;
goto v_reusejp_1056_;
}
else
{
lean_object* v_reuseFailAlloc_1059_; 
v_reuseFailAlloc_1059_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1059_, 0, v___x_1055_);
v___x_1057_ = v_reuseFailAlloc_1059_;
goto v_reusejp_1056_;
}
v_reusejp_1056_:
{
lean_object* v___x_1058_; 
v___x_1058_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1058_, 0, v___x_1057_);
return v___x_1058_;
}
}
}
}
else
{
lean_del_object(v___x_1032_);
lean_dec(v_exponent_1030_);
lean_dec(v_mantissa_1029_);
lean_del_object(v___x_1027_);
lean_dec_ref(v_a_1020_);
goto v___jp_1022_;
}
}
}
}
else
{
lean_dec_ref(v_a_1020_);
lean_dec(v_json_1019_);
goto v___jp_1022_;
}
v___jp_1022_:
{
lean_object* v___x_1023_; lean_object* v___x_1024_; 
v___x_1023_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprSort___closed__1));
v___x_1024_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1024_, 0, v___x_1023_);
return v___x_1024_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprSort___boxed(lean_object* v_json_1062_, lean_object* v_a_1063_, lean_object* v_a_1064_){
_start:
{
lean_object* v_res_1065_; 
v_res_1065_ = lp_proofEnvironment_Export_Parse_parseExprSort(v_json_1062_, v_a_1063_);
return v_res_1065_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0(size_t v_sz_1069_, size_t v_i_1070_, lean_object* v_bs_1071_, lean_object* v___y_1072_){
_start:
{
uint8_t v___x_1077_; 
v___x_1077_ = lean_usize_dec_lt(v_i_1070_, v_sz_1069_);
if (v___x_1077_ == 0)
{
lean_object* v___x_1078_; lean_object* v___x_1079_; 
v___x_1078_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1078_, 0, v_bs_1071_);
lean_ctor_set(v___x_1078_, 1, v___y_1072_);
v___x_1079_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1079_, 0, v___x_1078_);
return v___x_1079_;
}
else
{
lean_object* v_v_1080_; 
v_v_1080_ = lean_array_uget(v_bs_1071_, v_i_1070_);
if (lean_obj_tag(v_v_1080_) == 2)
{
lean_object* v_n_1081_; lean_object* v___x_1083_; uint8_t v_isShared_1084_; uint8_t v_isSharedCheck_1107_; 
v_n_1081_ = lean_ctor_get(v_v_1080_, 0);
v_isSharedCheck_1107_ = !lean_is_exclusive(v_v_1080_);
if (v_isSharedCheck_1107_ == 0)
{
v___x_1083_ = v_v_1080_;
v_isShared_1084_ = v_isSharedCheck_1107_;
goto v_resetjp_1082_;
}
else
{
lean_inc(v_n_1081_);
lean_dec(v_v_1080_);
v___x_1083_ = lean_box(0);
v_isShared_1084_ = v_isSharedCheck_1107_;
goto v_resetjp_1082_;
}
v_resetjp_1082_:
{
lean_object* v_mantissa_1085_; lean_object* v_exponent_1086_; lean_object* v_natZero_1087_; lean_object* v_intZero_1088_; uint8_t v_isNeg_1089_; 
v_mantissa_1085_ = lean_ctor_get(v_n_1081_, 0);
lean_inc(v_mantissa_1085_);
v_exponent_1086_ = lean_ctor_get(v_n_1081_, 1);
lean_inc(v_exponent_1086_);
lean_dec_ref(v_n_1081_);
v_natZero_1087_ = lean_unsigned_to_nat(0u);
v_intZero_1088_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1089_ = lean_int_dec_lt(v_mantissa_1085_, v_intZero_1088_);
if (v_isNeg_1089_ == 0)
{
uint8_t v___x_1090_; 
v___x_1090_ = lean_nat_dec_eq(v_exponent_1086_, v_natZero_1087_);
lean_dec(v_exponent_1086_);
if (v___x_1090_ == 0)
{
lean_dec(v_mantissa_1085_);
lean_del_object(v___x_1083_);
lean_dec_ref(v___y_1072_);
lean_dec_ref(v_bs_1071_);
goto v___jp_1074_;
}
else
{
lean_object* v_levelMap_1091_; lean_object* v_a_1092_; lean_object* v___x_1093_; 
v_levelMap_1091_ = lean_ctor_get(v___y_1072_, 2);
v_a_1092_ = lean_nat_abs(v_mantissa_1085_);
lean_dec(v_mantissa_1085_);
v___x_1093_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_levelMap_1091_, v_a_1092_);
if (lean_obj_tag(v___x_1093_) == 1)
{
lean_object* v_val_1094_; lean_object* v_bs_x27_1095_; size_t v___x_1096_; size_t v___x_1097_; lean_object* v___x_1098_; 
lean_dec(v_a_1092_);
lean_del_object(v___x_1083_);
v_val_1094_ = lean_ctor_get(v___x_1093_, 0);
lean_inc(v_val_1094_);
lean_dec_ref_known(v___x_1093_, 1);
v_bs_x27_1095_ = lean_array_uset(v_bs_1071_, v_i_1070_, v_natZero_1087_);
v___x_1096_ = ((size_t)1ULL);
v___x_1097_ = lean_usize_add(v_i_1070_, v___x_1096_);
v___x_1098_ = lean_array_uset(v_bs_x27_1095_, v_i_1070_, v_val_1094_);
v_i_1070_ = v___x_1097_;
v_bs_1071_ = v___x_1098_;
goto _start;
}
else
{
lean_object* v___x_1100_; lean_object* v___x_1101_; lean_object* v___x_1102_; lean_object* v___x_1104_; 
lean_dec(v___x_1093_);
lean_dec_ref(v___y_1072_);
lean_dec_ref(v_bs_1071_);
v___x_1100_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getLevel___closed__0));
v___x_1101_ = l_Nat_reprFast(v_a_1092_);
v___x_1102_ = lean_string_append(v___x_1100_, v___x_1101_);
lean_dec_ref(v___x_1101_);
if (v_isShared_1084_ == 0)
{
lean_ctor_set_tag(v___x_1083_, 18);
lean_ctor_set(v___x_1083_, 0, v___x_1102_);
v___x_1104_ = v___x_1083_;
goto v_reusejp_1103_;
}
else
{
lean_object* v_reuseFailAlloc_1106_; 
v_reuseFailAlloc_1106_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1106_, 0, v___x_1102_);
v___x_1104_ = v_reuseFailAlloc_1106_;
goto v_reusejp_1103_;
}
v_reusejp_1103_:
{
lean_object* v___x_1105_; 
v___x_1105_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1105_, 0, v___x_1104_);
return v___x_1105_;
}
}
}
}
else
{
lean_dec(v_exponent_1086_);
lean_dec(v_mantissa_1085_);
lean_del_object(v___x_1083_);
lean_dec_ref(v___y_1072_);
lean_dec_ref(v_bs_1071_);
goto v___jp_1074_;
}
}
}
else
{
lean_dec(v_v_1080_);
lean_dec_ref(v___y_1072_);
lean_dec_ref(v_bs_1071_);
goto v___jp_1074_;
}
}
v___jp_1074_:
{
lean_object* v___x_1075_; lean_object* v___x_1076_; 
v___x_1075_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1));
v___x_1076_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1076_, 0, v___x_1075_);
return v___x_1076_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___boxed(lean_object* v_sz_1108_, lean_object* v_i_1109_, lean_object* v_bs_1110_, lean_object* v___y_1111_, lean_object* v___y_1112_){
_start:
{
size_t v_sz_boxed_1113_; size_t v_i_boxed_1114_; lean_object* v_res_1115_; 
v_sz_boxed_1113_ = lean_unbox_usize(v_sz_1108_);
lean_dec(v_sz_1108_);
v_i_boxed_1114_ = lean_unbox_usize(v_i_1109_);
lean_dec(v_i_1109_);
v_res_1115_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0(v_sz_boxed_1113_, v_i_boxed_1114_, v_bs_1110_, v___y_1111_);
return v_res_1115_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprConst(lean_object* v_json_1118_, lean_object* v_a_1119_){
_start:
{
if (lean_obj_tag(v_json_1118_) == 5)
{
lean_object* v_kvPairs_1127_; lean_object* v___x_1128_; lean_object* v___x_1129_; 
v_kvPairs_1127_ = lean_ctor_get(v_json_1118_, 0);
v___x_1128_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_1129_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1127_, v___x_1128_);
if (lean_obj_tag(v___x_1129_) == 1)
{
lean_object* v_val_1130_; 
v_val_1130_ = lean_ctor_get(v___x_1129_, 0);
lean_inc(v_val_1130_);
lean_dec_ref_known(v___x_1129_, 1);
if (lean_obj_tag(v_val_1130_) == 2)
{
lean_object* v_n_1131_; lean_object* v_mantissa_1132_; lean_object* v_exponent_1133_; lean_object* v_natZero_1134_; lean_object* v_intZero_1135_; uint8_t v_isNeg_1136_; 
v_n_1131_ = lean_ctor_get(v_val_1130_, 0);
lean_inc_ref(v_n_1131_);
lean_dec_ref_known(v_val_1130_, 1);
v_mantissa_1132_ = lean_ctor_get(v_n_1131_, 0);
lean_inc(v_mantissa_1132_);
v_exponent_1133_ = lean_ctor_get(v_n_1131_, 1);
lean_inc(v_exponent_1133_);
lean_dec_ref(v_n_1131_);
v_natZero_1134_ = lean_unsigned_to_nat(0u);
v_intZero_1135_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1136_ = lean_int_dec_lt(v_mantissa_1132_, v_intZero_1135_);
if (v_isNeg_1136_ == 0)
{
uint8_t v___x_1137_; 
v___x_1137_ = lean_nat_dec_eq(v_exponent_1133_, v_natZero_1134_);
lean_dec(v_exponent_1133_);
if (v___x_1137_ == 0)
{
lean_dec(v_mantissa_1132_);
lean_dec_ref(v_a_1119_);
goto v___jp_1121_;
}
else
{
lean_object* v___x_1138_; lean_object* v___x_1139_; 
v___x_1138_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__1));
v___x_1139_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1127_, v___x_1138_);
if (lean_obj_tag(v___x_1139_) == 1)
{
lean_object* v_val_1140_; lean_object* v___x_1142_; uint8_t v_isShared_1143_; uint8_t v_isSharedCheck_1192_; 
v_val_1140_ = lean_ctor_get(v___x_1139_, 0);
v_isSharedCheck_1192_ = !lean_is_exclusive(v___x_1139_);
if (v_isSharedCheck_1192_ == 0)
{
v___x_1142_ = v___x_1139_;
v_isShared_1143_ = v_isSharedCheck_1192_;
goto v_resetjp_1141_;
}
else
{
lean_inc(v_val_1140_);
lean_dec(v___x_1139_);
v___x_1142_ = lean_box(0);
v_isShared_1143_ = v_isSharedCheck_1192_;
goto v_resetjp_1141_;
}
v_resetjp_1141_:
{
if (lean_obj_tag(v_val_1140_) == 4)
{
lean_object* v_elems_1144_; lean_object* v___x_1146_; uint8_t v_isShared_1147_; uint8_t v_isSharedCheck_1191_; 
v_elems_1144_ = lean_ctor_get(v_val_1140_, 0);
v_isSharedCheck_1191_ = !lean_is_exclusive(v_val_1140_);
if (v_isSharedCheck_1191_ == 0)
{
v___x_1146_ = v_val_1140_;
v_isShared_1147_ = v_isSharedCheck_1191_;
goto v_resetjp_1145_;
}
else
{
lean_inc(v_elems_1144_);
lean_dec(v_val_1140_);
v___x_1146_ = lean_box(0);
v_isShared_1147_ = v_isSharedCheck_1191_;
goto v_resetjp_1145_;
}
v_resetjp_1145_:
{
lean_object* v_nameMap_1148_; lean_object* v_a_1149_; lean_object* v___x_1150_; 
v_nameMap_1148_ = lean_ctor_get(v_a_1119_, 1);
v_a_1149_ = lean_nat_abs(v_mantissa_1132_);
lean_dec(v_mantissa_1132_);
v___x_1150_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_1148_, v_a_1149_);
if (lean_obj_tag(v___x_1150_) == 1)
{
lean_object* v_val_1151_; size_t v_sz_1152_; size_t v___x_1153_; lean_object* v___x_1154_; 
lean_dec(v_a_1149_);
lean_del_object(v___x_1146_);
lean_del_object(v___x_1142_);
v_val_1151_ = lean_ctor_get(v___x_1150_, 0);
lean_inc(v_val_1151_);
lean_dec_ref_known(v___x_1150_, 1);
v_sz_1152_ = lean_array_size(v_elems_1144_);
v___x_1153_ = ((size_t)0ULL);
v___x_1154_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0(v_sz_1152_, v___x_1153_, v_elems_1144_, v_a_1119_);
if (lean_obj_tag(v___x_1154_) == 0)
{
lean_object* v_a_1155_; lean_object* v___x_1157_; uint8_t v_isShared_1158_; uint8_t v_isSharedCheck_1173_; 
v_a_1155_ = lean_ctor_get(v___x_1154_, 0);
v_isSharedCheck_1173_ = !lean_is_exclusive(v___x_1154_);
if (v_isSharedCheck_1173_ == 0)
{
v___x_1157_ = v___x_1154_;
v_isShared_1158_ = v_isSharedCheck_1173_;
goto v_resetjp_1156_;
}
else
{
lean_inc(v_a_1155_);
lean_dec(v___x_1154_);
v___x_1157_ = lean_box(0);
v_isShared_1158_ = v_isSharedCheck_1173_;
goto v_resetjp_1156_;
}
v_resetjp_1156_:
{
lean_object* v_fst_1159_; lean_object* v_snd_1160_; lean_object* v___x_1162_; uint8_t v_isShared_1163_; uint8_t v_isSharedCheck_1172_; 
v_fst_1159_ = lean_ctor_get(v_a_1155_, 0);
v_snd_1160_ = lean_ctor_get(v_a_1155_, 1);
v_isSharedCheck_1172_ = !lean_is_exclusive(v_a_1155_);
if (v_isSharedCheck_1172_ == 0)
{
v___x_1162_ = v_a_1155_;
v_isShared_1163_ = v_isSharedCheck_1172_;
goto v_resetjp_1161_;
}
else
{
lean_inc(v_snd_1160_);
lean_inc(v_fst_1159_);
lean_dec(v_a_1155_);
v___x_1162_ = lean_box(0);
v_isShared_1163_ = v_isSharedCheck_1172_;
goto v_resetjp_1161_;
}
v_resetjp_1161_:
{
lean_object* v___x_1164_; lean_object* v___x_1165_; lean_object* v___x_1167_; 
v___x_1164_ = lean_array_to_list(v_fst_1159_);
v___x_1165_ = l_Lean_Expr_const___override(v_val_1151_, v___x_1164_);
if (v_isShared_1163_ == 0)
{
lean_ctor_set(v___x_1162_, 0, v___x_1165_);
v___x_1167_ = v___x_1162_;
goto v_reusejp_1166_;
}
else
{
lean_object* v_reuseFailAlloc_1171_; 
v_reuseFailAlloc_1171_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1171_, 0, v___x_1165_);
lean_ctor_set(v_reuseFailAlloc_1171_, 1, v_snd_1160_);
v___x_1167_ = v_reuseFailAlloc_1171_;
goto v_reusejp_1166_;
}
v_reusejp_1166_:
{
lean_object* v___x_1169_; 
if (v_isShared_1158_ == 0)
{
lean_ctor_set(v___x_1157_, 0, v___x_1167_);
v___x_1169_ = v___x_1157_;
goto v_reusejp_1168_;
}
else
{
lean_object* v_reuseFailAlloc_1170_; 
v_reuseFailAlloc_1170_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1170_, 0, v___x_1167_);
v___x_1169_ = v_reuseFailAlloc_1170_;
goto v_reusejp_1168_;
}
v_reusejp_1168_:
{
return v___x_1169_;
}
}
}
}
}
else
{
lean_object* v_a_1174_; lean_object* v___x_1176_; uint8_t v_isShared_1177_; uint8_t v_isSharedCheck_1181_; 
lean_dec(v_val_1151_);
v_a_1174_ = lean_ctor_get(v___x_1154_, 0);
v_isSharedCheck_1181_ = !lean_is_exclusive(v___x_1154_);
if (v_isSharedCheck_1181_ == 0)
{
v___x_1176_ = v___x_1154_;
v_isShared_1177_ = v_isSharedCheck_1181_;
goto v_resetjp_1175_;
}
else
{
lean_inc(v_a_1174_);
lean_dec(v___x_1154_);
v___x_1176_ = lean_box(0);
v_isShared_1177_ = v_isSharedCheck_1181_;
goto v_resetjp_1175_;
}
v_resetjp_1175_:
{
lean_object* v___x_1179_; 
if (v_isShared_1177_ == 0)
{
v___x_1179_ = v___x_1176_;
goto v_reusejp_1178_;
}
else
{
lean_object* v_reuseFailAlloc_1180_; 
v_reuseFailAlloc_1180_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1180_, 0, v_a_1174_);
v___x_1179_ = v_reuseFailAlloc_1180_;
goto v_reusejp_1178_;
}
v_reusejp_1178_:
{
return v___x_1179_;
}
}
}
}
else
{
lean_object* v___x_1182_; lean_object* v___x_1183_; lean_object* v___x_1184_; lean_object* v___x_1186_; 
lean_dec(v___x_1150_);
lean_dec_ref(v_elems_1144_);
lean_dec_ref(v_a_1119_);
v___x_1182_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_1183_ = l_Nat_reprFast(v_a_1149_);
v___x_1184_ = lean_string_append(v___x_1182_, v___x_1183_);
lean_dec_ref(v___x_1183_);
if (v_isShared_1147_ == 0)
{
lean_ctor_set_tag(v___x_1146_, 18);
lean_ctor_set(v___x_1146_, 0, v___x_1184_);
v___x_1186_ = v___x_1146_;
goto v_reusejp_1185_;
}
else
{
lean_object* v_reuseFailAlloc_1190_; 
v_reuseFailAlloc_1190_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1190_, 0, v___x_1184_);
v___x_1186_ = v_reuseFailAlloc_1190_;
goto v_reusejp_1185_;
}
v_reusejp_1185_:
{
lean_object* v___x_1188_; 
if (v_isShared_1143_ == 0)
{
lean_ctor_set(v___x_1142_, 0, v___x_1186_);
v___x_1188_ = v___x_1142_;
goto v_reusejp_1187_;
}
else
{
lean_object* v_reuseFailAlloc_1189_; 
v_reuseFailAlloc_1189_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1189_, 0, v___x_1186_);
v___x_1188_ = v_reuseFailAlloc_1189_;
goto v_reusejp_1187_;
}
v_reusejp_1187_:
{
return v___x_1188_;
}
}
}
}
}
else
{
lean_del_object(v___x_1142_);
lean_dec(v_val_1140_);
lean_dec(v_mantissa_1132_);
lean_dec_ref(v_a_1119_);
goto v___jp_1124_;
}
}
}
else
{
lean_dec(v___x_1139_);
lean_dec(v_mantissa_1132_);
lean_dec_ref(v_a_1119_);
goto v___jp_1124_;
}
}
}
else
{
lean_dec(v_exponent_1133_);
lean_dec(v_mantissa_1132_);
lean_dec_ref(v_a_1119_);
goto v___jp_1121_;
}
}
else
{
lean_dec(v_val_1130_);
lean_dec_ref(v_a_1119_);
goto v___jp_1121_;
}
}
else
{
lean_dec(v___x_1129_);
lean_dec_ref(v_a_1119_);
goto v___jp_1121_;
}
}
else
{
lean_object* v___x_1193_; lean_object* v___x_1194_; 
lean_dec_ref(v_a_1119_);
v___x_1193_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1));
v___x_1194_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1194_, 0, v___x_1193_);
return v___x_1194_;
}
v___jp_1121_:
{
lean_object* v___x_1122_; lean_object* v___x_1123_; 
v___x_1122_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1));
v___x_1123_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1123_, 0, v___x_1122_);
return v___x_1123_;
}
v___jp_1124_:
{
lean_object* v___x_1125_; lean_object* v___x_1126_; 
v___x_1125_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Export_Parse_parseExprConst_spec__0___closed__1));
v___x_1126_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1126_, 0, v___x_1125_);
return v___x_1126_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprConst___boxed(lean_object* v_json_1195_, lean_object* v_a_1196_, lean_object* v_a_1197_){
_start:
{
lean_object* v_res_1198_; 
v_res_1198_ = lp_proofEnvironment_Export_Parse_parseExprConst(v_json_1195_, v_a_1196_);
lean_dec(v_json_1195_);
return v_res_1198_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprApp(lean_object* v_json_1204_, lean_object* v_a_1205_){
_start:
{
if (lean_obj_tag(v_json_1204_) == 5)
{
lean_object* v_kvPairs_1213_; lean_object* v___x_1214_; lean_object* v___x_1215_; 
v_kvPairs_1213_ = lean_ctor_get(v_json_1204_, 0);
v___x_1214_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprApp___closed__2));
v___x_1215_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1213_, v___x_1214_);
if (lean_obj_tag(v___x_1215_) == 1)
{
lean_object* v_val_1216_; 
v_val_1216_ = lean_ctor_get(v___x_1215_, 0);
lean_inc(v_val_1216_);
lean_dec_ref_known(v___x_1215_, 1);
if (lean_obj_tag(v_val_1216_) == 2)
{
lean_object* v_n_1217_; lean_object* v_mantissa_1218_; lean_object* v_exponent_1219_; lean_object* v_natZero_1220_; lean_object* v_intZero_1221_; uint8_t v_isNeg_1222_; 
v_n_1217_ = lean_ctor_get(v_val_1216_, 0);
lean_inc_ref(v_n_1217_);
lean_dec_ref_known(v_val_1216_, 1);
v_mantissa_1218_ = lean_ctor_get(v_n_1217_, 0);
lean_inc(v_mantissa_1218_);
v_exponent_1219_ = lean_ctor_get(v_n_1217_, 1);
lean_inc(v_exponent_1219_);
lean_dec_ref(v_n_1217_);
v_natZero_1220_ = lean_unsigned_to_nat(0u);
v_intZero_1221_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1222_ = lean_int_dec_lt(v_mantissa_1218_, v_intZero_1221_);
if (v_isNeg_1222_ == 0)
{
uint8_t v___x_1223_; 
v___x_1223_ = lean_nat_dec_eq(v_exponent_1219_, v_natZero_1220_);
lean_dec(v_exponent_1219_);
if (v___x_1223_ == 0)
{
lean_dec(v_mantissa_1218_);
lean_dec_ref(v_a_1205_);
goto v___jp_1207_;
}
else
{
lean_object* v___x_1224_; lean_object* v___x_1225_; 
v___x_1224_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprApp___closed__3));
v___x_1225_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1213_, v___x_1224_);
if (lean_obj_tag(v___x_1225_) == 1)
{
lean_object* v_val_1226_; lean_object* v___x_1228_; uint8_t v_isShared_1229_; uint8_t v_isSharedCheck_1283_; 
v_val_1226_ = lean_ctor_get(v___x_1225_, 0);
v_isSharedCheck_1283_ = !lean_is_exclusive(v___x_1225_);
if (v_isSharedCheck_1283_ == 0)
{
v___x_1228_ = v___x_1225_;
v_isShared_1229_ = v_isSharedCheck_1283_;
goto v_resetjp_1227_;
}
else
{
lean_inc(v_val_1226_);
lean_dec(v___x_1225_);
v___x_1228_ = lean_box(0);
v_isShared_1229_ = v_isSharedCheck_1283_;
goto v_resetjp_1227_;
}
v_resetjp_1227_:
{
if (lean_obj_tag(v_val_1226_) == 2)
{
lean_object* v_n_1230_; lean_object* v___x_1232_; uint8_t v_isShared_1233_; uint8_t v_isSharedCheck_1282_; 
v_n_1230_ = lean_ctor_get(v_val_1226_, 0);
v_isSharedCheck_1282_ = !lean_is_exclusive(v_val_1226_);
if (v_isSharedCheck_1282_ == 0)
{
v___x_1232_ = v_val_1226_;
v_isShared_1233_ = v_isSharedCheck_1282_;
goto v_resetjp_1231_;
}
else
{
lean_inc(v_n_1230_);
lean_dec(v_val_1226_);
v___x_1232_ = lean_box(0);
v_isShared_1233_ = v_isSharedCheck_1282_;
goto v_resetjp_1231_;
}
v_resetjp_1231_:
{
lean_object* v_mantissa_1234_; lean_object* v_exponent_1235_; lean_object* v___x_1237_; uint8_t v_isShared_1238_; uint8_t v_isSharedCheck_1281_; 
v_mantissa_1234_ = lean_ctor_get(v_n_1230_, 0);
v_exponent_1235_ = lean_ctor_get(v_n_1230_, 1);
v_isSharedCheck_1281_ = !lean_is_exclusive(v_n_1230_);
if (v_isSharedCheck_1281_ == 0)
{
v___x_1237_ = v_n_1230_;
v_isShared_1238_ = v_isSharedCheck_1281_;
goto v_resetjp_1236_;
}
else
{
lean_inc(v_exponent_1235_);
lean_inc(v_mantissa_1234_);
lean_dec(v_n_1230_);
v___x_1237_ = lean_box(0);
v_isShared_1238_ = v_isSharedCheck_1281_;
goto v_resetjp_1236_;
}
v_resetjp_1236_:
{
uint8_t v_isNeg_1239_; 
v_isNeg_1239_ = lean_int_dec_lt(v_mantissa_1234_, v_intZero_1221_);
if (v_isNeg_1239_ == 0)
{
uint8_t v___x_1240_; 
v___x_1240_ = lean_nat_dec_eq(v_exponent_1235_, v_natZero_1220_);
lean_dec(v_exponent_1235_);
if (v___x_1240_ == 0)
{
lean_del_object(v___x_1237_);
lean_dec(v_mantissa_1234_);
lean_del_object(v___x_1232_);
lean_del_object(v___x_1228_);
lean_dec(v_mantissa_1218_);
lean_dec_ref(v_a_1205_);
goto v___jp_1210_;
}
else
{
lean_object* v_exprMap_1241_; lean_object* v_a_1242_; lean_object* v___x_1243_; 
v_exprMap_1241_ = lean_ctor_get(v_a_1205_, 3);
v_a_1242_ = lean_nat_abs(v_mantissa_1218_);
lean_dec(v_mantissa_1218_);
v___x_1243_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1241_, v_a_1242_);
if (lean_obj_tag(v___x_1243_) == 1)
{
lean_object* v_val_1244_; lean_object* v___x_1246_; uint8_t v_isShared_1247_; uint8_t v_isSharedCheck_1271_; 
lean_dec(v_a_1242_);
lean_del_object(v___x_1228_);
v_val_1244_ = lean_ctor_get(v___x_1243_, 0);
v_isSharedCheck_1271_ = !lean_is_exclusive(v___x_1243_);
if (v_isSharedCheck_1271_ == 0)
{
v___x_1246_ = v___x_1243_;
v_isShared_1247_ = v_isSharedCheck_1271_;
goto v_resetjp_1245_;
}
else
{
lean_inc(v_val_1244_);
lean_dec(v___x_1243_);
v___x_1246_ = lean_box(0);
v_isShared_1247_ = v_isSharedCheck_1271_;
goto v_resetjp_1245_;
}
v_resetjp_1245_:
{
lean_object* v_a_1248_; lean_object* v___x_1249_; 
v_a_1248_ = lean_nat_abs(v_mantissa_1234_);
lean_dec(v_mantissa_1234_);
v___x_1249_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1241_, v_a_1248_);
if (lean_obj_tag(v___x_1249_) == 1)
{
lean_object* v_val_1250_; lean_object* v___x_1252_; uint8_t v_isShared_1253_; uint8_t v_isSharedCheck_1261_; 
lean_dec(v_a_1248_);
lean_del_object(v___x_1246_);
lean_del_object(v___x_1232_);
v_val_1250_ = lean_ctor_get(v___x_1249_, 0);
v_isSharedCheck_1261_ = !lean_is_exclusive(v___x_1249_);
if (v_isSharedCheck_1261_ == 0)
{
v___x_1252_ = v___x_1249_;
v_isShared_1253_ = v_isSharedCheck_1261_;
goto v_resetjp_1251_;
}
else
{
lean_inc(v_val_1250_);
lean_dec(v___x_1249_);
v___x_1252_ = lean_box(0);
v_isShared_1253_ = v_isSharedCheck_1261_;
goto v_resetjp_1251_;
}
v_resetjp_1251_:
{
lean_object* v___x_1254_; lean_object* v___x_1256_; 
v___x_1254_ = l_Lean_Expr_app___override(v_val_1244_, v_val_1250_);
if (v_isShared_1238_ == 0)
{
lean_ctor_set(v___x_1237_, 1, v_a_1205_);
lean_ctor_set(v___x_1237_, 0, v___x_1254_);
v___x_1256_ = v___x_1237_;
goto v_reusejp_1255_;
}
else
{
lean_object* v_reuseFailAlloc_1260_; 
v_reuseFailAlloc_1260_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1260_, 0, v___x_1254_);
lean_ctor_set(v_reuseFailAlloc_1260_, 1, v_a_1205_);
v___x_1256_ = v_reuseFailAlloc_1260_;
goto v_reusejp_1255_;
}
v_reusejp_1255_:
{
lean_object* v___x_1258_; 
if (v_isShared_1253_ == 0)
{
lean_ctor_set_tag(v___x_1252_, 0);
lean_ctor_set(v___x_1252_, 0, v___x_1256_);
v___x_1258_ = v___x_1252_;
goto v_reusejp_1257_;
}
else
{
lean_object* v_reuseFailAlloc_1259_; 
v_reuseFailAlloc_1259_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1259_, 0, v___x_1256_);
v___x_1258_ = v_reuseFailAlloc_1259_;
goto v_reusejp_1257_;
}
v_reusejp_1257_:
{
return v___x_1258_;
}
}
}
}
else
{
lean_object* v___x_1262_; lean_object* v___x_1263_; lean_object* v___x_1264_; lean_object* v___x_1266_; 
lean_dec(v___x_1249_);
lean_dec(v_val_1244_);
lean_del_object(v___x_1237_);
lean_dec_ref(v_a_1205_);
v___x_1262_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1263_ = l_Nat_reprFast(v_a_1248_);
v___x_1264_ = lean_string_append(v___x_1262_, v___x_1263_);
lean_dec_ref(v___x_1263_);
if (v_isShared_1247_ == 0)
{
lean_ctor_set_tag(v___x_1246_, 18);
lean_ctor_set(v___x_1246_, 0, v___x_1264_);
v___x_1266_ = v___x_1246_;
goto v_reusejp_1265_;
}
else
{
lean_object* v_reuseFailAlloc_1270_; 
v_reuseFailAlloc_1270_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1270_, 0, v___x_1264_);
v___x_1266_ = v_reuseFailAlloc_1270_;
goto v_reusejp_1265_;
}
v_reusejp_1265_:
{
lean_object* v___x_1268_; 
if (v_isShared_1233_ == 0)
{
lean_ctor_set_tag(v___x_1232_, 1);
lean_ctor_set(v___x_1232_, 0, v___x_1266_);
v___x_1268_ = v___x_1232_;
goto v_reusejp_1267_;
}
else
{
lean_object* v_reuseFailAlloc_1269_; 
v_reuseFailAlloc_1269_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1269_, 0, v___x_1266_);
v___x_1268_ = v_reuseFailAlloc_1269_;
goto v_reusejp_1267_;
}
v_reusejp_1267_:
{
return v___x_1268_;
}
}
}
}
}
else
{
lean_object* v___x_1272_; lean_object* v___x_1273_; lean_object* v___x_1274_; lean_object* v___x_1276_; 
lean_dec(v___x_1243_);
lean_del_object(v___x_1237_);
lean_dec(v_mantissa_1234_);
lean_dec_ref(v_a_1205_);
v___x_1272_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1273_ = l_Nat_reprFast(v_a_1242_);
v___x_1274_ = lean_string_append(v___x_1272_, v___x_1273_);
lean_dec_ref(v___x_1273_);
if (v_isShared_1233_ == 0)
{
lean_ctor_set_tag(v___x_1232_, 18);
lean_ctor_set(v___x_1232_, 0, v___x_1274_);
v___x_1276_ = v___x_1232_;
goto v_reusejp_1275_;
}
else
{
lean_object* v_reuseFailAlloc_1280_; 
v_reuseFailAlloc_1280_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1280_, 0, v___x_1274_);
v___x_1276_ = v_reuseFailAlloc_1280_;
goto v_reusejp_1275_;
}
v_reusejp_1275_:
{
lean_object* v___x_1278_; 
if (v_isShared_1229_ == 0)
{
lean_ctor_set(v___x_1228_, 0, v___x_1276_);
v___x_1278_ = v___x_1228_;
goto v_reusejp_1277_;
}
else
{
lean_object* v_reuseFailAlloc_1279_; 
v_reuseFailAlloc_1279_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1279_, 0, v___x_1276_);
v___x_1278_ = v_reuseFailAlloc_1279_;
goto v_reusejp_1277_;
}
v_reusejp_1277_:
{
return v___x_1278_;
}
}
}
}
}
else
{
lean_del_object(v___x_1237_);
lean_dec(v_exponent_1235_);
lean_dec(v_mantissa_1234_);
lean_del_object(v___x_1232_);
lean_del_object(v___x_1228_);
lean_dec(v_mantissa_1218_);
lean_dec_ref(v_a_1205_);
goto v___jp_1210_;
}
}
}
}
else
{
lean_del_object(v___x_1228_);
lean_dec(v_val_1226_);
lean_dec(v_mantissa_1218_);
lean_dec_ref(v_a_1205_);
goto v___jp_1210_;
}
}
}
else
{
lean_dec(v___x_1225_);
lean_dec(v_mantissa_1218_);
lean_dec_ref(v_a_1205_);
goto v___jp_1210_;
}
}
}
else
{
lean_dec(v_exponent_1219_);
lean_dec(v_mantissa_1218_);
lean_dec_ref(v_a_1205_);
goto v___jp_1207_;
}
}
else
{
lean_dec(v_val_1216_);
lean_dec_ref(v_a_1205_);
goto v___jp_1207_;
}
}
else
{
lean_dec(v___x_1215_);
lean_dec_ref(v_a_1205_);
goto v___jp_1207_;
}
}
else
{
lean_object* v___x_1284_; lean_object* v___x_1285_; 
lean_dec_ref(v_a_1205_);
v___x_1284_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprApp___closed__1));
v___x_1285_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1285_, 0, v___x_1284_);
return v___x_1285_;
}
v___jp_1207_:
{
lean_object* v___x_1208_; lean_object* v___x_1209_; 
v___x_1208_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprApp___closed__1));
v___x_1209_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1209_, 0, v___x_1208_);
return v___x_1209_;
}
v___jp_1210_:
{
lean_object* v___x_1211_; lean_object* v___x_1212_; 
v___x_1211_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprApp___closed__1));
v___x_1212_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1212_, 0, v___x_1211_);
return v___x_1212_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprApp___boxed(lean_object* v_json_1286_, lean_object* v_a_1287_, lean_object* v_a_1288_){
_start:
{
lean_object* v_res_1289_; 
v_res_1289_ = lp_proofEnvironment_Export_Parse_parseExprApp(v_json_1286_, v_a_1287_);
lean_dec(v_json_1286_);
return v_res_1289_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo(lean_object* v_info_1295_, lean_object* v_a_1296_){
_start:
{
lean_object* v___x_1298_; uint8_t v___x_1299_; 
v___x_1298_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__0));
v___x_1299_ = lean_string_dec_eq(v_info_1295_, v___x_1298_);
if (v___x_1299_ == 0)
{
lean_object* v___x_1300_; uint8_t v___x_1301_; 
v___x_1300_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__1));
v___x_1301_ = lean_string_dec_eq(v_info_1295_, v___x_1300_);
if (v___x_1301_ == 0)
{
lean_object* v___x_1302_; uint8_t v___x_1303_; 
v___x_1302_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__2));
v___x_1303_ = lean_string_dec_eq(v_info_1295_, v___x_1302_);
if (v___x_1303_ == 0)
{
lean_object* v___x_1304_; uint8_t v___x_1305_; 
v___x_1304_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__3));
v___x_1305_ = lean_string_dec_eq(v_info_1295_, v___x_1304_);
if (v___x_1305_ == 0)
{
lean_object* v___x_1306_; lean_object* v___x_1307_; lean_object* v___x_1308_; lean_object* v___x_1309_; 
lean_dec_ref(v_a_1296_);
v___x_1306_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseBinderInfo___closed__4));
v___x_1307_ = lean_string_append(v___x_1306_, v_info_1295_);
v___x_1308_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_1308_, 0, v___x_1307_);
v___x_1309_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1309_, 0, v___x_1308_);
return v___x_1309_;
}
else
{
uint8_t v___x_1310_; lean_object* v___x_1311_; lean_object* v___x_1312_; lean_object* v___x_1313_; 
v___x_1310_ = 3;
v___x_1311_ = lean_box(v___x_1310_);
v___x_1312_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1312_, 0, v___x_1311_);
lean_ctor_set(v___x_1312_, 1, v_a_1296_);
v___x_1313_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1313_, 0, v___x_1312_);
return v___x_1313_;
}
}
else
{
uint8_t v___x_1314_; lean_object* v___x_1315_; lean_object* v___x_1316_; lean_object* v___x_1317_; 
v___x_1314_ = 2;
v___x_1315_ = lean_box(v___x_1314_);
v___x_1316_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1316_, 0, v___x_1315_);
lean_ctor_set(v___x_1316_, 1, v_a_1296_);
v___x_1317_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1317_, 0, v___x_1316_);
return v___x_1317_;
}
}
else
{
uint8_t v___x_1318_; lean_object* v___x_1319_; lean_object* v___x_1320_; lean_object* v___x_1321_; 
v___x_1318_ = 1;
v___x_1319_ = lean_box(v___x_1318_);
v___x_1320_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1320_, 0, v___x_1319_);
lean_ctor_set(v___x_1320_, 1, v_a_1296_);
v___x_1321_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1321_, 0, v___x_1320_);
return v___x_1321_;
}
}
else
{
uint8_t v___x_1322_; lean_object* v___x_1323_; lean_object* v___x_1324_; lean_object* v___x_1325_; 
v___x_1322_ = 0;
v___x_1323_ = lean_box(v___x_1322_);
v___x_1324_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1324_, 0, v___x_1323_);
lean_ctor_set(v___x_1324_, 1, v_a_1296_);
v___x_1325_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1325_, 0, v___x_1324_);
return v___x_1325_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseBinderInfo___boxed(lean_object* v_info_1326_, lean_object* v_a_1327_, lean_object* v_a_1328_){
_start:
{
lean_object* v_res_1329_; 
v_res_1329_ = lp_proofEnvironment_Export_Parse_parseBinderInfo(v_info_1326_, v_a_1327_);
lean_dec_ref(v_info_1326_);
return v_res_1329_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLam(lean_object* v_json_1336_, lean_object* v_a_1337_){
_start:
{
if (lean_obj_tag(v_json_1336_) == 5)
{
lean_object* v_kvPairs_1351_; lean_object* v___x_1352_; lean_object* v___x_1353_; 
v_kvPairs_1351_ = lean_ctor_get(v_json_1336_, 0);
v___x_1352_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_1353_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1351_, v___x_1352_);
if (lean_obj_tag(v___x_1353_) == 1)
{
lean_object* v_val_1354_; 
v_val_1354_ = lean_ctor_get(v___x_1353_, 0);
lean_inc(v_val_1354_);
lean_dec_ref_known(v___x_1353_, 1);
if (lean_obj_tag(v_val_1354_) == 2)
{
lean_object* v_n_1355_; lean_object* v_mantissa_1356_; lean_object* v_exponent_1357_; lean_object* v_natZero_1358_; lean_object* v_intZero_1359_; uint8_t v_isNeg_1360_; 
v_n_1355_ = lean_ctor_get(v_val_1354_, 0);
lean_inc_ref(v_n_1355_);
lean_dec_ref_known(v_val_1354_, 1);
v_mantissa_1356_ = lean_ctor_get(v_n_1355_, 0);
lean_inc(v_mantissa_1356_);
v_exponent_1357_ = lean_ctor_get(v_n_1355_, 1);
lean_inc(v_exponent_1357_);
lean_dec_ref(v_n_1355_);
v_natZero_1358_ = lean_unsigned_to_nat(0u);
v_intZero_1359_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1360_ = lean_int_dec_lt(v_mantissa_1356_, v_intZero_1359_);
if (v_isNeg_1360_ == 0)
{
uint8_t v___x_1361_; 
v___x_1361_ = lean_nat_dec_eq(v_exponent_1357_, v_natZero_1358_);
lean_dec(v_exponent_1357_);
if (v___x_1361_ == 0)
{
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1339_;
}
else
{
lean_object* v___x_1362_; lean_object* v___x_1363_; 
v___x_1362_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_1363_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1351_, v___x_1362_);
if (lean_obj_tag(v___x_1363_) == 1)
{
lean_object* v_val_1364_; 
v_val_1364_ = lean_ctor_get(v___x_1363_, 0);
lean_inc(v_val_1364_);
lean_dec_ref_known(v___x_1363_, 1);
if (lean_obj_tag(v_val_1364_) == 2)
{
lean_object* v_n_1365_; lean_object* v_mantissa_1366_; lean_object* v_exponent_1367_; uint8_t v_isNeg_1368_; 
v_n_1365_ = lean_ctor_get(v_val_1364_, 0);
lean_inc_ref(v_n_1365_);
lean_dec_ref_known(v_val_1364_, 1);
v_mantissa_1366_ = lean_ctor_get(v_n_1365_, 0);
lean_inc(v_mantissa_1366_);
v_exponent_1367_ = lean_ctor_get(v_n_1365_, 1);
lean_inc(v_exponent_1367_);
lean_dec_ref(v_n_1365_);
v_isNeg_1368_ = lean_int_dec_lt(v_mantissa_1366_, v_intZero_1359_);
if (v_isNeg_1368_ == 0)
{
uint8_t v___x_1369_; 
v___x_1369_ = lean_nat_dec_eq(v_exponent_1367_, v_natZero_1358_);
lean_dec(v_exponent_1367_);
if (v___x_1369_ == 0)
{
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1342_;
}
else
{
lean_object* v___x_1370_; lean_object* v___x_1371_; 
v___x_1370_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__3));
v___x_1371_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1351_, v___x_1370_);
if (lean_obj_tag(v___x_1371_) == 1)
{
lean_object* v_val_1372_; 
v_val_1372_ = lean_ctor_get(v___x_1371_, 0);
lean_inc(v_val_1372_);
lean_dec_ref_known(v___x_1371_, 1);
if (lean_obj_tag(v_val_1372_) == 2)
{
lean_object* v_n_1373_; lean_object* v_mantissa_1374_; lean_object* v_exponent_1375_; uint8_t v_isNeg_1376_; 
v_n_1373_ = lean_ctor_get(v_val_1372_, 0);
lean_inc_ref(v_n_1373_);
lean_dec_ref_known(v_val_1372_, 1);
v_mantissa_1374_ = lean_ctor_get(v_n_1373_, 0);
lean_inc(v_mantissa_1374_);
v_exponent_1375_ = lean_ctor_get(v_n_1373_, 1);
lean_inc(v_exponent_1375_);
lean_dec_ref(v_n_1373_);
v_isNeg_1376_ = lean_int_dec_lt(v_mantissa_1374_, v_intZero_1359_);
if (v_isNeg_1376_ == 0)
{
uint8_t v___x_1377_; 
v___x_1377_ = lean_nat_dec_eq(v_exponent_1375_, v_natZero_1358_);
lean_dec(v_exponent_1375_);
if (v___x_1377_ == 0)
{
lean_dec(v_mantissa_1374_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1345_;
}
else
{
lean_object* v___x_1378_; lean_object* v___x_1379_; 
v___x_1378_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__4));
v___x_1379_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1351_, v___x_1378_);
if (lean_obj_tag(v___x_1379_) == 1)
{
lean_object* v_val_1380_; lean_object* v___x_1382_; uint8_t v_isShared_1383_; uint8_t v_isSharedCheck_1463_; 
v_val_1380_ = lean_ctor_get(v___x_1379_, 0);
v_isSharedCheck_1463_ = !lean_is_exclusive(v___x_1379_);
if (v_isSharedCheck_1463_ == 0)
{
v___x_1382_ = v___x_1379_;
v_isShared_1383_ = v_isSharedCheck_1463_;
goto v_resetjp_1381_;
}
else
{
lean_inc(v_val_1380_);
lean_dec(v___x_1379_);
v___x_1382_ = lean_box(0);
v_isShared_1383_ = v_isSharedCheck_1463_;
goto v_resetjp_1381_;
}
v_resetjp_1381_:
{
if (lean_obj_tag(v_val_1380_) == 3)
{
lean_object* v_s_1384_; lean_object* v___x_1386_; uint8_t v_isShared_1387_; uint8_t v_isSharedCheck_1462_; 
v_s_1384_ = lean_ctor_get(v_val_1380_, 0);
v_isSharedCheck_1462_ = !lean_is_exclusive(v_val_1380_);
if (v_isSharedCheck_1462_ == 0)
{
v___x_1386_ = v_val_1380_;
v_isShared_1387_ = v_isSharedCheck_1462_;
goto v_resetjp_1385_;
}
else
{
lean_inc(v_s_1384_);
lean_dec(v_val_1380_);
v___x_1386_ = lean_box(0);
v_isShared_1387_ = v_isSharedCheck_1462_;
goto v_resetjp_1385_;
}
v_resetjp_1385_:
{
lean_object* v_nameMap_1388_; lean_object* v_exprMap_1389_; lean_object* v_a_1390_; lean_object* v___x_1391_; 
v_nameMap_1388_ = lean_ctor_get(v_a_1337_, 1);
v_exprMap_1389_ = lean_ctor_get(v_a_1337_, 3);
v_a_1390_ = lean_nat_abs(v_mantissa_1356_);
lean_dec(v_mantissa_1356_);
v___x_1391_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_1388_, v_a_1390_);
if (lean_obj_tag(v___x_1391_) == 1)
{
lean_object* v_val_1392_; lean_object* v___x_1394_; uint8_t v_isShared_1395_; uint8_t v_isSharedCheck_1452_; 
lean_dec(v_a_1390_);
lean_del_object(v___x_1382_);
v_val_1392_ = lean_ctor_get(v___x_1391_, 0);
v_isSharedCheck_1452_ = !lean_is_exclusive(v___x_1391_);
if (v_isSharedCheck_1452_ == 0)
{
v___x_1394_ = v___x_1391_;
v_isShared_1395_ = v_isSharedCheck_1452_;
goto v_resetjp_1393_;
}
else
{
lean_inc(v_val_1392_);
lean_dec(v___x_1391_);
v___x_1394_ = lean_box(0);
v_isShared_1395_ = v_isSharedCheck_1452_;
goto v_resetjp_1393_;
}
v_resetjp_1393_:
{
lean_object* v_a_1396_; lean_object* v___x_1397_; 
v_a_1396_ = lean_nat_abs(v_mantissa_1366_);
lean_dec(v_mantissa_1366_);
v___x_1397_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1389_, v_a_1396_);
if (lean_obj_tag(v___x_1397_) == 1)
{
lean_object* v_val_1398_; lean_object* v___x_1400_; uint8_t v_isShared_1401_; uint8_t v_isSharedCheck_1442_; 
lean_dec(v_a_1396_);
lean_del_object(v___x_1386_);
v_val_1398_ = lean_ctor_get(v___x_1397_, 0);
v_isSharedCheck_1442_ = !lean_is_exclusive(v___x_1397_);
if (v_isSharedCheck_1442_ == 0)
{
v___x_1400_ = v___x_1397_;
v_isShared_1401_ = v_isSharedCheck_1442_;
goto v_resetjp_1399_;
}
else
{
lean_inc(v_val_1398_);
lean_dec(v___x_1397_);
v___x_1400_ = lean_box(0);
v_isShared_1401_ = v_isSharedCheck_1442_;
goto v_resetjp_1399_;
}
v_resetjp_1399_:
{
lean_object* v_a_1402_; lean_object* v___x_1403_; 
v_a_1402_ = lean_nat_abs(v_mantissa_1374_);
lean_dec(v_mantissa_1374_);
v___x_1403_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1389_, v_a_1402_);
if (lean_obj_tag(v___x_1403_) == 1)
{
lean_object* v_val_1404_; lean_object* v___x_1405_; 
lean_dec(v_a_1402_);
lean_del_object(v___x_1400_);
lean_del_object(v___x_1394_);
v_val_1404_ = lean_ctor_get(v___x_1403_, 0);
lean_inc(v_val_1404_);
lean_dec_ref_known(v___x_1403_, 1);
v___x_1405_ = lp_proofEnvironment_Export_Parse_parseBinderInfo(v_s_1384_, v_a_1337_);
lean_dec_ref(v_s_1384_);
if (lean_obj_tag(v___x_1405_) == 0)
{
lean_object* v_a_1406_; lean_object* v___x_1408_; uint8_t v_isShared_1409_; uint8_t v_isSharedCheck_1424_; 
v_a_1406_ = lean_ctor_get(v___x_1405_, 0);
v_isSharedCheck_1424_ = !lean_is_exclusive(v___x_1405_);
if (v_isSharedCheck_1424_ == 0)
{
v___x_1408_ = v___x_1405_;
v_isShared_1409_ = v_isSharedCheck_1424_;
goto v_resetjp_1407_;
}
else
{
lean_inc(v_a_1406_);
lean_dec(v___x_1405_);
v___x_1408_ = lean_box(0);
v_isShared_1409_ = v_isSharedCheck_1424_;
goto v_resetjp_1407_;
}
v_resetjp_1407_:
{
lean_object* v_fst_1410_; lean_object* v_snd_1411_; lean_object* v___x_1413_; uint8_t v_isShared_1414_; uint8_t v_isSharedCheck_1423_; 
v_fst_1410_ = lean_ctor_get(v_a_1406_, 0);
v_snd_1411_ = lean_ctor_get(v_a_1406_, 1);
v_isSharedCheck_1423_ = !lean_is_exclusive(v_a_1406_);
if (v_isSharedCheck_1423_ == 0)
{
v___x_1413_ = v_a_1406_;
v_isShared_1414_ = v_isSharedCheck_1423_;
goto v_resetjp_1412_;
}
else
{
lean_inc(v_snd_1411_);
lean_inc(v_fst_1410_);
lean_dec(v_a_1406_);
v___x_1413_ = lean_box(0);
v_isShared_1414_ = v_isSharedCheck_1423_;
goto v_resetjp_1412_;
}
v_resetjp_1412_:
{
uint8_t v___x_1415_; lean_object* v___x_1416_; lean_object* v___x_1418_; 
v___x_1415_ = lean_unbox(v_fst_1410_);
lean_dec(v_fst_1410_);
v___x_1416_ = l_Lean_Expr_lam___override(v_val_1392_, v_val_1398_, v_val_1404_, v___x_1415_);
if (v_isShared_1414_ == 0)
{
lean_ctor_set(v___x_1413_, 0, v___x_1416_);
v___x_1418_ = v___x_1413_;
goto v_reusejp_1417_;
}
else
{
lean_object* v_reuseFailAlloc_1422_; 
v_reuseFailAlloc_1422_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1422_, 0, v___x_1416_);
lean_ctor_set(v_reuseFailAlloc_1422_, 1, v_snd_1411_);
v___x_1418_ = v_reuseFailAlloc_1422_;
goto v_reusejp_1417_;
}
v_reusejp_1417_:
{
lean_object* v___x_1420_; 
if (v_isShared_1409_ == 0)
{
lean_ctor_set(v___x_1408_, 0, v___x_1418_);
v___x_1420_ = v___x_1408_;
goto v_reusejp_1419_;
}
else
{
lean_object* v_reuseFailAlloc_1421_; 
v_reuseFailAlloc_1421_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1421_, 0, v___x_1418_);
v___x_1420_ = v_reuseFailAlloc_1421_;
goto v_reusejp_1419_;
}
v_reusejp_1419_:
{
return v___x_1420_;
}
}
}
}
}
else
{
lean_object* v_a_1425_; lean_object* v___x_1427_; uint8_t v_isShared_1428_; uint8_t v_isSharedCheck_1432_; 
lean_dec(v_val_1404_);
lean_dec(v_val_1398_);
lean_dec(v_val_1392_);
v_a_1425_ = lean_ctor_get(v___x_1405_, 0);
v_isSharedCheck_1432_ = !lean_is_exclusive(v___x_1405_);
if (v_isSharedCheck_1432_ == 0)
{
v___x_1427_ = v___x_1405_;
v_isShared_1428_ = v_isSharedCheck_1432_;
goto v_resetjp_1426_;
}
else
{
lean_inc(v_a_1425_);
lean_dec(v___x_1405_);
v___x_1427_ = lean_box(0);
v_isShared_1428_ = v_isSharedCheck_1432_;
goto v_resetjp_1426_;
}
v_resetjp_1426_:
{
lean_object* v___x_1430_; 
if (v_isShared_1428_ == 0)
{
v___x_1430_ = v___x_1427_;
goto v_reusejp_1429_;
}
else
{
lean_object* v_reuseFailAlloc_1431_; 
v_reuseFailAlloc_1431_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1431_, 0, v_a_1425_);
v___x_1430_ = v_reuseFailAlloc_1431_;
goto v_reusejp_1429_;
}
v_reusejp_1429_:
{
return v___x_1430_;
}
}
}
}
else
{
lean_object* v___x_1433_; lean_object* v___x_1434_; lean_object* v___x_1435_; lean_object* v___x_1437_; 
lean_dec(v___x_1403_);
lean_dec(v_val_1398_);
lean_dec(v_val_1392_);
lean_dec_ref(v_s_1384_);
lean_dec_ref(v_a_1337_);
v___x_1433_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1434_ = l_Nat_reprFast(v_a_1402_);
v___x_1435_ = lean_string_append(v___x_1433_, v___x_1434_);
lean_dec_ref(v___x_1434_);
if (v_isShared_1401_ == 0)
{
lean_ctor_set_tag(v___x_1400_, 18);
lean_ctor_set(v___x_1400_, 0, v___x_1435_);
v___x_1437_ = v___x_1400_;
goto v_reusejp_1436_;
}
else
{
lean_object* v_reuseFailAlloc_1441_; 
v_reuseFailAlloc_1441_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1441_, 0, v___x_1435_);
v___x_1437_ = v_reuseFailAlloc_1441_;
goto v_reusejp_1436_;
}
v_reusejp_1436_:
{
lean_object* v___x_1439_; 
if (v_isShared_1395_ == 0)
{
lean_ctor_set(v___x_1394_, 0, v___x_1437_);
v___x_1439_ = v___x_1394_;
goto v_reusejp_1438_;
}
else
{
lean_object* v_reuseFailAlloc_1440_; 
v_reuseFailAlloc_1440_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1440_, 0, v___x_1437_);
v___x_1439_ = v_reuseFailAlloc_1440_;
goto v_reusejp_1438_;
}
v_reusejp_1438_:
{
return v___x_1439_;
}
}
}
}
}
else
{
lean_object* v___x_1443_; lean_object* v___x_1444_; lean_object* v___x_1445_; lean_object* v___x_1447_; 
lean_dec(v___x_1397_);
lean_dec(v_val_1392_);
lean_dec_ref(v_s_1384_);
lean_dec(v_mantissa_1374_);
lean_dec_ref(v_a_1337_);
v___x_1443_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1444_ = l_Nat_reprFast(v_a_1396_);
v___x_1445_ = lean_string_append(v___x_1443_, v___x_1444_);
lean_dec_ref(v___x_1444_);
if (v_isShared_1395_ == 0)
{
lean_ctor_set_tag(v___x_1394_, 18);
lean_ctor_set(v___x_1394_, 0, v___x_1445_);
v___x_1447_ = v___x_1394_;
goto v_reusejp_1446_;
}
else
{
lean_object* v_reuseFailAlloc_1451_; 
v_reuseFailAlloc_1451_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1451_, 0, v___x_1445_);
v___x_1447_ = v_reuseFailAlloc_1451_;
goto v_reusejp_1446_;
}
v_reusejp_1446_:
{
lean_object* v___x_1449_; 
if (v_isShared_1387_ == 0)
{
lean_ctor_set_tag(v___x_1386_, 1);
lean_ctor_set(v___x_1386_, 0, v___x_1447_);
v___x_1449_ = v___x_1386_;
goto v_reusejp_1448_;
}
else
{
lean_object* v_reuseFailAlloc_1450_; 
v_reuseFailAlloc_1450_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1450_, 0, v___x_1447_);
v___x_1449_ = v_reuseFailAlloc_1450_;
goto v_reusejp_1448_;
}
v_reusejp_1448_:
{
return v___x_1449_;
}
}
}
}
}
else
{
lean_object* v___x_1453_; lean_object* v___x_1454_; lean_object* v___x_1455_; lean_object* v___x_1457_; 
lean_dec(v___x_1391_);
lean_dec_ref(v_s_1384_);
lean_dec(v_mantissa_1374_);
lean_dec(v_mantissa_1366_);
lean_dec_ref(v_a_1337_);
v___x_1453_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_1454_ = l_Nat_reprFast(v_a_1390_);
v___x_1455_ = lean_string_append(v___x_1453_, v___x_1454_);
lean_dec_ref(v___x_1454_);
if (v_isShared_1387_ == 0)
{
lean_ctor_set_tag(v___x_1386_, 18);
lean_ctor_set(v___x_1386_, 0, v___x_1455_);
v___x_1457_ = v___x_1386_;
goto v_reusejp_1456_;
}
else
{
lean_object* v_reuseFailAlloc_1461_; 
v_reuseFailAlloc_1461_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1461_, 0, v___x_1455_);
v___x_1457_ = v_reuseFailAlloc_1461_;
goto v_reusejp_1456_;
}
v_reusejp_1456_:
{
lean_object* v___x_1459_; 
if (v_isShared_1383_ == 0)
{
lean_ctor_set(v___x_1382_, 0, v___x_1457_);
v___x_1459_ = v___x_1382_;
goto v_reusejp_1458_;
}
else
{
lean_object* v_reuseFailAlloc_1460_; 
v_reuseFailAlloc_1460_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1460_, 0, v___x_1457_);
v___x_1459_ = v_reuseFailAlloc_1460_;
goto v_reusejp_1458_;
}
v_reusejp_1458_:
{
return v___x_1459_;
}
}
}
}
}
else
{
lean_del_object(v___x_1382_);
lean_dec(v_val_1380_);
lean_dec(v_mantissa_1374_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1348_;
}
}
}
else
{
lean_dec(v___x_1379_);
lean_dec(v_mantissa_1374_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1348_;
}
}
}
else
{
lean_dec(v_exponent_1375_);
lean_dec(v_mantissa_1374_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1345_;
}
}
else
{
lean_dec(v_val_1372_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1345_;
}
}
else
{
lean_dec(v___x_1371_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1345_;
}
}
}
else
{
lean_dec(v_exponent_1367_);
lean_dec(v_mantissa_1366_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1342_;
}
}
else
{
lean_dec(v_val_1364_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1342_;
}
}
else
{
lean_dec(v___x_1363_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1342_;
}
}
}
else
{
lean_dec(v_exponent_1357_);
lean_dec(v_mantissa_1356_);
lean_dec_ref(v_a_1337_);
goto v___jp_1339_;
}
}
else
{
lean_dec(v_val_1354_);
lean_dec_ref(v_a_1337_);
goto v___jp_1339_;
}
}
else
{
lean_dec(v___x_1353_);
lean_dec_ref(v_a_1337_);
goto v___jp_1339_;
}
}
else
{
lean_object* v___x_1464_; lean_object* v___x_1465_; 
lean_dec_ref(v_a_1337_);
v___x_1464_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__1));
v___x_1465_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1465_, 0, v___x_1464_);
return v___x_1465_;
}
v___jp_1339_:
{
lean_object* v___x_1340_; lean_object* v___x_1341_; 
v___x_1340_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__1));
v___x_1341_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1341_, 0, v___x_1340_);
return v___x_1341_;
}
v___jp_1342_:
{
lean_object* v___x_1343_; lean_object* v___x_1344_; 
v___x_1343_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__1));
v___x_1344_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1344_, 0, v___x_1343_);
return v___x_1344_;
}
v___jp_1345_:
{
lean_object* v___x_1346_; lean_object* v___x_1347_; 
v___x_1346_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__1));
v___x_1347_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1347_, 0, v___x_1346_);
return v___x_1347_;
}
v___jp_1348_:
{
lean_object* v___x_1349_; lean_object* v___x_1350_; 
v___x_1349_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__1));
v___x_1350_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1350_, 0, v___x_1349_);
return v___x_1350_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLam___boxed(lean_object* v_json_1466_, lean_object* v_a_1467_, lean_object* v_a_1468_){
_start:
{
lean_object* v_res_1469_; 
v_res_1469_ = lp_proofEnvironment_Export_Parse_parseExprLam(v_json_1466_, v_a_1467_);
lean_dec(v_json_1466_);
return v_res_1469_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprForallE(lean_object* v_json_1473_, lean_object* v_a_1474_){
_start:
{
if (lean_obj_tag(v_json_1473_) == 5)
{
lean_object* v_kvPairs_1488_; lean_object* v___x_1489_; lean_object* v___x_1490_; 
v_kvPairs_1488_ = lean_ctor_get(v_json_1473_, 0);
v___x_1489_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_1490_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1488_, v___x_1489_);
if (lean_obj_tag(v___x_1490_) == 1)
{
lean_object* v_val_1491_; 
v_val_1491_ = lean_ctor_get(v___x_1490_, 0);
lean_inc(v_val_1491_);
lean_dec_ref_known(v___x_1490_, 1);
if (lean_obj_tag(v_val_1491_) == 2)
{
lean_object* v_n_1492_; lean_object* v_mantissa_1493_; lean_object* v_exponent_1494_; lean_object* v_natZero_1495_; lean_object* v_intZero_1496_; uint8_t v_isNeg_1497_; 
v_n_1492_ = lean_ctor_get(v_val_1491_, 0);
lean_inc_ref(v_n_1492_);
lean_dec_ref_known(v_val_1491_, 1);
v_mantissa_1493_ = lean_ctor_get(v_n_1492_, 0);
lean_inc(v_mantissa_1493_);
v_exponent_1494_ = lean_ctor_get(v_n_1492_, 1);
lean_inc(v_exponent_1494_);
lean_dec_ref(v_n_1492_);
v_natZero_1495_ = lean_unsigned_to_nat(0u);
v_intZero_1496_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1497_ = lean_int_dec_lt(v_mantissa_1493_, v_intZero_1496_);
if (v_isNeg_1497_ == 0)
{
uint8_t v___x_1498_; 
v___x_1498_ = lean_nat_dec_eq(v_exponent_1494_, v_natZero_1495_);
lean_dec(v_exponent_1494_);
if (v___x_1498_ == 0)
{
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1476_;
}
else
{
lean_object* v___x_1499_; lean_object* v___x_1500_; 
v___x_1499_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_1500_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1488_, v___x_1499_);
if (lean_obj_tag(v___x_1500_) == 1)
{
lean_object* v_val_1501_; 
v_val_1501_ = lean_ctor_get(v___x_1500_, 0);
lean_inc(v_val_1501_);
lean_dec_ref_known(v___x_1500_, 1);
if (lean_obj_tag(v_val_1501_) == 2)
{
lean_object* v_n_1502_; lean_object* v_mantissa_1503_; lean_object* v_exponent_1504_; uint8_t v_isNeg_1505_; 
v_n_1502_ = lean_ctor_get(v_val_1501_, 0);
lean_inc_ref(v_n_1502_);
lean_dec_ref_known(v_val_1501_, 1);
v_mantissa_1503_ = lean_ctor_get(v_n_1502_, 0);
lean_inc(v_mantissa_1503_);
v_exponent_1504_ = lean_ctor_get(v_n_1502_, 1);
lean_inc(v_exponent_1504_);
lean_dec_ref(v_n_1502_);
v_isNeg_1505_ = lean_int_dec_lt(v_mantissa_1503_, v_intZero_1496_);
if (v_isNeg_1505_ == 0)
{
uint8_t v___x_1506_; 
v___x_1506_ = lean_nat_dec_eq(v_exponent_1504_, v_natZero_1495_);
lean_dec(v_exponent_1504_);
if (v___x_1506_ == 0)
{
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1479_;
}
else
{
lean_object* v___x_1507_; lean_object* v___x_1508_; 
v___x_1507_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__3));
v___x_1508_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1488_, v___x_1507_);
if (lean_obj_tag(v___x_1508_) == 1)
{
lean_object* v_val_1509_; 
v_val_1509_ = lean_ctor_get(v___x_1508_, 0);
lean_inc(v_val_1509_);
lean_dec_ref_known(v___x_1508_, 1);
if (lean_obj_tag(v_val_1509_) == 2)
{
lean_object* v_n_1510_; lean_object* v_mantissa_1511_; lean_object* v_exponent_1512_; uint8_t v_isNeg_1513_; 
v_n_1510_ = lean_ctor_get(v_val_1509_, 0);
lean_inc_ref(v_n_1510_);
lean_dec_ref_known(v_val_1509_, 1);
v_mantissa_1511_ = lean_ctor_get(v_n_1510_, 0);
lean_inc(v_mantissa_1511_);
v_exponent_1512_ = lean_ctor_get(v_n_1510_, 1);
lean_inc(v_exponent_1512_);
lean_dec_ref(v_n_1510_);
v_isNeg_1513_ = lean_int_dec_lt(v_mantissa_1511_, v_intZero_1496_);
if (v_isNeg_1513_ == 0)
{
uint8_t v___x_1514_; 
v___x_1514_ = lean_nat_dec_eq(v_exponent_1512_, v_natZero_1495_);
lean_dec(v_exponent_1512_);
if (v___x_1514_ == 0)
{
lean_dec(v_mantissa_1511_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1482_;
}
else
{
lean_object* v___x_1515_; lean_object* v___x_1516_; 
v___x_1515_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__4));
v___x_1516_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1488_, v___x_1515_);
if (lean_obj_tag(v___x_1516_) == 1)
{
lean_object* v_val_1517_; lean_object* v___x_1519_; uint8_t v_isShared_1520_; uint8_t v_isSharedCheck_1600_; 
v_val_1517_ = lean_ctor_get(v___x_1516_, 0);
v_isSharedCheck_1600_ = !lean_is_exclusive(v___x_1516_);
if (v_isSharedCheck_1600_ == 0)
{
v___x_1519_ = v___x_1516_;
v_isShared_1520_ = v_isSharedCheck_1600_;
goto v_resetjp_1518_;
}
else
{
lean_inc(v_val_1517_);
lean_dec(v___x_1516_);
v___x_1519_ = lean_box(0);
v_isShared_1520_ = v_isSharedCheck_1600_;
goto v_resetjp_1518_;
}
v_resetjp_1518_:
{
if (lean_obj_tag(v_val_1517_) == 3)
{
lean_object* v_s_1521_; lean_object* v___x_1523_; uint8_t v_isShared_1524_; uint8_t v_isSharedCheck_1599_; 
v_s_1521_ = lean_ctor_get(v_val_1517_, 0);
v_isSharedCheck_1599_ = !lean_is_exclusive(v_val_1517_);
if (v_isSharedCheck_1599_ == 0)
{
v___x_1523_ = v_val_1517_;
v_isShared_1524_ = v_isSharedCheck_1599_;
goto v_resetjp_1522_;
}
else
{
lean_inc(v_s_1521_);
lean_dec(v_val_1517_);
v___x_1523_ = lean_box(0);
v_isShared_1524_ = v_isSharedCheck_1599_;
goto v_resetjp_1522_;
}
v_resetjp_1522_:
{
lean_object* v_nameMap_1525_; lean_object* v_exprMap_1526_; lean_object* v_a_1527_; lean_object* v___x_1528_; 
v_nameMap_1525_ = lean_ctor_get(v_a_1474_, 1);
v_exprMap_1526_ = lean_ctor_get(v_a_1474_, 3);
v_a_1527_ = lean_nat_abs(v_mantissa_1493_);
lean_dec(v_mantissa_1493_);
v___x_1528_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_1525_, v_a_1527_);
if (lean_obj_tag(v___x_1528_) == 1)
{
lean_object* v_val_1529_; lean_object* v___x_1531_; uint8_t v_isShared_1532_; uint8_t v_isSharedCheck_1589_; 
lean_dec(v_a_1527_);
lean_del_object(v___x_1519_);
v_val_1529_ = lean_ctor_get(v___x_1528_, 0);
v_isSharedCheck_1589_ = !lean_is_exclusive(v___x_1528_);
if (v_isSharedCheck_1589_ == 0)
{
v___x_1531_ = v___x_1528_;
v_isShared_1532_ = v_isSharedCheck_1589_;
goto v_resetjp_1530_;
}
else
{
lean_inc(v_val_1529_);
lean_dec(v___x_1528_);
v___x_1531_ = lean_box(0);
v_isShared_1532_ = v_isSharedCheck_1589_;
goto v_resetjp_1530_;
}
v_resetjp_1530_:
{
lean_object* v_a_1533_; lean_object* v___x_1534_; 
v_a_1533_ = lean_nat_abs(v_mantissa_1503_);
lean_dec(v_mantissa_1503_);
v___x_1534_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1526_, v_a_1533_);
if (lean_obj_tag(v___x_1534_) == 1)
{
lean_object* v_val_1535_; lean_object* v___x_1537_; uint8_t v_isShared_1538_; uint8_t v_isSharedCheck_1579_; 
lean_dec(v_a_1533_);
lean_del_object(v___x_1523_);
v_val_1535_ = lean_ctor_get(v___x_1534_, 0);
v_isSharedCheck_1579_ = !lean_is_exclusive(v___x_1534_);
if (v_isSharedCheck_1579_ == 0)
{
v___x_1537_ = v___x_1534_;
v_isShared_1538_ = v_isSharedCheck_1579_;
goto v_resetjp_1536_;
}
else
{
lean_inc(v_val_1535_);
lean_dec(v___x_1534_);
v___x_1537_ = lean_box(0);
v_isShared_1538_ = v_isSharedCheck_1579_;
goto v_resetjp_1536_;
}
v_resetjp_1536_:
{
lean_object* v_a_1539_; lean_object* v___x_1540_; 
v_a_1539_ = lean_nat_abs(v_mantissa_1511_);
lean_dec(v_mantissa_1511_);
v___x_1540_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1526_, v_a_1539_);
if (lean_obj_tag(v___x_1540_) == 1)
{
lean_object* v_val_1541_; lean_object* v___x_1542_; 
lean_dec(v_a_1539_);
lean_del_object(v___x_1537_);
lean_del_object(v___x_1531_);
v_val_1541_ = lean_ctor_get(v___x_1540_, 0);
lean_inc(v_val_1541_);
lean_dec_ref_known(v___x_1540_, 1);
v___x_1542_ = lp_proofEnvironment_Export_Parse_parseBinderInfo(v_s_1521_, v_a_1474_);
lean_dec_ref(v_s_1521_);
if (lean_obj_tag(v___x_1542_) == 0)
{
lean_object* v_a_1543_; lean_object* v___x_1545_; uint8_t v_isShared_1546_; uint8_t v_isSharedCheck_1561_; 
v_a_1543_ = lean_ctor_get(v___x_1542_, 0);
v_isSharedCheck_1561_ = !lean_is_exclusive(v___x_1542_);
if (v_isSharedCheck_1561_ == 0)
{
v___x_1545_ = v___x_1542_;
v_isShared_1546_ = v_isSharedCheck_1561_;
goto v_resetjp_1544_;
}
else
{
lean_inc(v_a_1543_);
lean_dec(v___x_1542_);
v___x_1545_ = lean_box(0);
v_isShared_1546_ = v_isSharedCheck_1561_;
goto v_resetjp_1544_;
}
v_resetjp_1544_:
{
lean_object* v_fst_1547_; lean_object* v_snd_1548_; lean_object* v___x_1550_; uint8_t v_isShared_1551_; uint8_t v_isSharedCheck_1560_; 
v_fst_1547_ = lean_ctor_get(v_a_1543_, 0);
v_snd_1548_ = lean_ctor_get(v_a_1543_, 1);
v_isSharedCheck_1560_ = !lean_is_exclusive(v_a_1543_);
if (v_isSharedCheck_1560_ == 0)
{
v___x_1550_ = v_a_1543_;
v_isShared_1551_ = v_isSharedCheck_1560_;
goto v_resetjp_1549_;
}
else
{
lean_inc(v_snd_1548_);
lean_inc(v_fst_1547_);
lean_dec(v_a_1543_);
v___x_1550_ = lean_box(0);
v_isShared_1551_ = v_isSharedCheck_1560_;
goto v_resetjp_1549_;
}
v_resetjp_1549_:
{
uint8_t v___x_1552_; lean_object* v___x_1553_; lean_object* v___x_1555_; 
v___x_1552_ = lean_unbox(v_fst_1547_);
lean_dec(v_fst_1547_);
v___x_1553_ = l_Lean_Expr_forallE___override(v_val_1529_, v_val_1535_, v_val_1541_, v___x_1552_);
if (v_isShared_1551_ == 0)
{
lean_ctor_set(v___x_1550_, 0, v___x_1553_);
v___x_1555_ = v___x_1550_;
goto v_reusejp_1554_;
}
else
{
lean_object* v_reuseFailAlloc_1559_; 
v_reuseFailAlloc_1559_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1559_, 0, v___x_1553_);
lean_ctor_set(v_reuseFailAlloc_1559_, 1, v_snd_1548_);
v___x_1555_ = v_reuseFailAlloc_1559_;
goto v_reusejp_1554_;
}
v_reusejp_1554_:
{
lean_object* v___x_1557_; 
if (v_isShared_1546_ == 0)
{
lean_ctor_set(v___x_1545_, 0, v___x_1555_);
v___x_1557_ = v___x_1545_;
goto v_reusejp_1556_;
}
else
{
lean_object* v_reuseFailAlloc_1558_; 
v_reuseFailAlloc_1558_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1558_, 0, v___x_1555_);
v___x_1557_ = v_reuseFailAlloc_1558_;
goto v_reusejp_1556_;
}
v_reusejp_1556_:
{
return v___x_1557_;
}
}
}
}
}
else
{
lean_object* v_a_1562_; lean_object* v___x_1564_; uint8_t v_isShared_1565_; uint8_t v_isSharedCheck_1569_; 
lean_dec(v_val_1541_);
lean_dec(v_val_1535_);
lean_dec(v_val_1529_);
v_a_1562_ = lean_ctor_get(v___x_1542_, 0);
v_isSharedCheck_1569_ = !lean_is_exclusive(v___x_1542_);
if (v_isSharedCheck_1569_ == 0)
{
v___x_1564_ = v___x_1542_;
v_isShared_1565_ = v_isSharedCheck_1569_;
goto v_resetjp_1563_;
}
else
{
lean_inc(v_a_1562_);
lean_dec(v___x_1542_);
v___x_1564_ = lean_box(0);
v_isShared_1565_ = v_isSharedCheck_1569_;
goto v_resetjp_1563_;
}
v_resetjp_1563_:
{
lean_object* v___x_1567_; 
if (v_isShared_1565_ == 0)
{
v___x_1567_ = v___x_1564_;
goto v_reusejp_1566_;
}
else
{
lean_object* v_reuseFailAlloc_1568_; 
v_reuseFailAlloc_1568_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1568_, 0, v_a_1562_);
v___x_1567_ = v_reuseFailAlloc_1568_;
goto v_reusejp_1566_;
}
v_reusejp_1566_:
{
return v___x_1567_;
}
}
}
}
else
{
lean_object* v___x_1570_; lean_object* v___x_1571_; lean_object* v___x_1572_; lean_object* v___x_1574_; 
lean_dec(v___x_1540_);
lean_dec(v_val_1535_);
lean_dec(v_val_1529_);
lean_dec_ref(v_s_1521_);
lean_dec_ref(v_a_1474_);
v___x_1570_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1571_ = l_Nat_reprFast(v_a_1539_);
v___x_1572_ = lean_string_append(v___x_1570_, v___x_1571_);
lean_dec_ref(v___x_1571_);
if (v_isShared_1538_ == 0)
{
lean_ctor_set_tag(v___x_1537_, 18);
lean_ctor_set(v___x_1537_, 0, v___x_1572_);
v___x_1574_ = v___x_1537_;
goto v_reusejp_1573_;
}
else
{
lean_object* v_reuseFailAlloc_1578_; 
v_reuseFailAlloc_1578_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1578_, 0, v___x_1572_);
v___x_1574_ = v_reuseFailAlloc_1578_;
goto v_reusejp_1573_;
}
v_reusejp_1573_:
{
lean_object* v___x_1576_; 
if (v_isShared_1532_ == 0)
{
lean_ctor_set(v___x_1531_, 0, v___x_1574_);
v___x_1576_ = v___x_1531_;
goto v_reusejp_1575_;
}
else
{
lean_object* v_reuseFailAlloc_1577_; 
v_reuseFailAlloc_1577_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1577_, 0, v___x_1574_);
v___x_1576_ = v_reuseFailAlloc_1577_;
goto v_reusejp_1575_;
}
v_reusejp_1575_:
{
return v___x_1576_;
}
}
}
}
}
else
{
lean_object* v___x_1580_; lean_object* v___x_1581_; lean_object* v___x_1582_; lean_object* v___x_1584_; 
lean_dec(v___x_1534_);
lean_dec(v_val_1529_);
lean_dec_ref(v_s_1521_);
lean_dec(v_mantissa_1511_);
lean_dec_ref(v_a_1474_);
v___x_1580_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1581_ = l_Nat_reprFast(v_a_1533_);
v___x_1582_ = lean_string_append(v___x_1580_, v___x_1581_);
lean_dec_ref(v___x_1581_);
if (v_isShared_1532_ == 0)
{
lean_ctor_set_tag(v___x_1531_, 18);
lean_ctor_set(v___x_1531_, 0, v___x_1582_);
v___x_1584_ = v___x_1531_;
goto v_reusejp_1583_;
}
else
{
lean_object* v_reuseFailAlloc_1588_; 
v_reuseFailAlloc_1588_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1588_, 0, v___x_1582_);
v___x_1584_ = v_reuseFailAlloc_1588_;
goto v_reusejp_1583_;
}
v_reusejp_1583_:
{
lean_object* v___x_1586_; 
if (v_isShared_1524_ == 0)
{
lean_ctor_set_tag(v___x_1523_, 1);
lean_ctor_set(v___x_1523_, 0, v___x_1584_);
v___x_1586_ = v___x_1523_;
goto v_reusejp_1585_;
}
else
{
lean_object* v_reuseFailAlloc_1587_; 
v_reuseFailAlloc_1587_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1587_, 0, v___x_1584_);
v___x_1586_ = v_reuseFailAlloc_1587_;
goto v_reusejp_1585_;
}
v_reusejp_1585_:
{
return v___x_1586_;
}
}
}
}
}
else
{
lean_object* v___x_1590_; lean_object* v___x_1591_; lean_object* v___x_1592_; lean_object* v___x_1594_; 
lean_dec(v___x_1528_);
lean_dec_ref(v_s_1521_);
lean_dec(v_mantissa_1511_);
lean_dec(v_mantissa_1503_);
lean_dec_ref(v_a_1474_);
v___x_1590_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_1591_ = l_Nat_reprFast(v_a_1527_);
v___x_1592_ = lean_string_append(v___x_1590_, v___x_1591_);
lean_dec_ref(v___x_1591_);
if (v_isShared_1524_ == 0)
{
lean_ctor_set_tag(v___x_1523_, 18);
lean_ctor_set(v___x_1523_, 0, v___x_1592_);
v___x_1594_ = v___x_1523_;
goto v_reusejp_1593_;
}
else
{
lean_object* v_reuseFailAlloc_1598_; 
v_reuseFailAlloc_1598_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1598_, 0, v___x_1592_);
v___x_1594_ = v_reuseFailAlloc_1598_;
goto v_reusejp_1593_;
}
v_reusejp_1593_:
{
lean_object* v___x_1596_; 
if (v_isShared_1520_ == 0)
{
lean_ctor_set(v___x_1519_, 0, v___x_1594_);
v___x_1596_ = v___x_1519_;
goto v_reusejp_1595_;
}
else
{
lean_object* v_reuseFailAlloc_1597_; 
v_reuseFailAlloc_1597_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1597_, 0, v___x_1594_);
v___x_1596_ = v_reuseFailAlloc_1597_;
goto v_reusejp_1595_;
}
v_reusejp_1595_:
{
return v___x_1596_;
}
}
}
}
}
else
{
lean_del_object(v___x_1519_);
lean_dec(v_val_1517_);
lean_dec(v_mantissa_1511_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1485_;
}
}
}
else
{
lean_dec(v___x_1516_);
lean_dec(v_mantissa_1511_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1485_;
}
}
}
else
{
lean_dec(v_exponent_1512_);
lean_dec(v_mantissa_1511_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1482_;
}
}
else
{
lean_dec(v_val_1509_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1482_;
}
}
else
{
lean_dec(v___x_1508_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1482_;
}
}
}
else
{
lean_dec(v_exponent_1504_);
lean_dec(v_mantissa_1503_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1479_;
}
}
else
{
lean_dec(v_val_1501_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1479_;
}
}
else
{
lean_dec(v___x_1500_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1479_;
}
}
}
else
{
lean_dec(v_exponent_1494_);
lean_dec(v_mantissa_1493_);
lean_dec_ref(v_a_1474_);
goto v___jp_1476_;
}
}
else
{
lean_dec(v_val_1491_);
lean_dec_ref(v_a_1474_);
goto v___jp_1476_;
}
}
else
{
lean_dec(v___x_1490_);
lean_dec_ref(v_a_1474_);
goto v___jp_1476_;
}
}
else
{
lean_object* v___x_1601_; lean_object* v___x_1602_; 
lean_dec_ref(v_a_1474_);
v___x_1601_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1));
v___x_1602_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1602_, 0, v___x_1601_);
return v___x_1602_;
}
v___jp_1476_:
{
lean_object* v___x_1477_; lean_object* v___x_1478_; 
v___x_1477_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1));
v___x_1478_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1478_, 0, v___x_1477_);
return v___x_1478_;
}
v___jp_1479_:
{
lean_object* v___x_1480_; lean_object* v___x_1481_; 
v___x_1480_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1));
v___x_1481_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1481_, 0, v___x_1480_);
return v___x_1481_;
}
v___jp_1482_:
{
lean_object* v___x_1483_; lean_object* v___x_1484_; 
v___x_1483_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1));
v___x_1484_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1484_, 0, v___x_1483_);
return v___x_1484_;
}
v___jp_1485_:
{
lean_object* v___x_1486_; lean_object* v___x_1487_; 
v___x_1486_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprForallE___closed__1));
v___x_1487_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1487_, 0, v___x_1486_);
return v___x_1487_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprForallE___boxed(lean_object* v_json_1603_, lean_object* v_a_1604_, lean_object* v_a_1605_){
_start:
{
lean_object* v_res_1606_; 
v_res_1606_ = lp_proofEnvironment_Export_Parse_parseExprForallE(v_json_1603_, v_a_1604_);
lean_dec(v_json_1603_);
return v_res_1606_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE(lean_object* v_json_1612_, lean_object* v_a_1613_){
_start:
{
if (lean_obj_tag(v_json_1612_) == 5)
{
lean_object* v_kvPairs_1630_; lean_object* v___x_1631_; lean_object* v___x_1632_; 
v_kvPairs_1630_ = lean_ctor_get(v_json_1612_, 0);
v___x_1631_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_1632_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1630_, v___x_1631_);
if (lean_obj_tag(v___x_1632_) == 1)
{
lean_object* v_val_1633_; 
v_val_1633_ = lean_ctor_get(v___x_1632_, 0);
lean_inc(v_val_1633_);
lean_dec_ref_known(v___x_1632_, 1);
if (lean_obj_tag(v_val_1633_) == 2)
{
lean_object* v_n_1634_; lean_object* v_mantissa_1635_; lean_object* v_exponent_1636_; lean_object* v_natZero_1637_; lean_object* v_intZero_1638_; uint8_t v_isNeg_1639_; 
v_n_1634_ = lean_ctor_get(v_val_1633_, 0);
lean_inc_ref(v_n_1634_);
lean_dec_ref_known(v_val_1633_, 1);
v_mantissa_1635_ = lean_ctor_get(v_n_1634_, 0);
lean_inc(v_mantissa_1635_);
v_exponent_1636_ = lean_ctor_get(v_n_1634_, 1);
lean_inc(v_exponent_1636_);
lean_dec_ref(v_n_1634_);
v_natZero_1637_ = lean_unsigned_to_nat(0u);
v_intZero_1638_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1639_ = lean_int_dec_lt(v_mantissa_1635_, v_intZero_1638_);
if (v_isNeg_1639_ == 0)
{
uint8_t v___x_1640_; 
v___x_1640_ = lean_nat_dec_eq(v_exponent_1636_, v_natZero_1637_);
lean_dec(v_exponent_1636_);
if (v___x_1640_ == 0)
{
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1615_;
}
else
{
lean_object* v___x_1641_; lean_object* v___x_1642_; 
v___x_1641_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_1642_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1630_, v___x_1641_);
if (lean_obj_tag(v___x_1642_) == 1)
{
lean_object* v_val_1643_; 
v_val_1643_ = lean_ctor_get(v___x_1642_, 0);
lean_inc(v_val_1643_);
lean_dec_ref_known(v___x_1642_, 1);
if (lean_obj_tag(v_val_1643_) == 2)
{
lean_object* v_n_1644_; lean_object* v_mantissa_1645_; lean_object* v_exponent_1646_; uint8_t v_isNeg_1647_; 
v_n_1644_ = lean_ctor_get(v_val_1643_, 0);
lean_inc_ref(v_n_1644_);
lean_dec_ref_known(v_val_1643_, 1);
v_mantissa_1645_ = lean_ctor_get(v_n_1644_, 0);
lean_inc(v_mantissa_1645_);
v_exponent_1646_ = lean_ctor_get(v_n_1644_, 1);
lean_inc(v_exponent_1646_);
lean_dec_ref(v_n_1644_);
v_isNeg_1647_ = lean_int_dec_lt(v_mantissa_1645_, v_intZero_1638_);
if (v_isNeg_1647_ == 0)
{
uint8_t v___x_1648_; 
v___x_1648_ = lean_nat_dec_eq(v_exponent_1646_, v_natZero_1637_);
lean_dec(v_exponent_1646_);
if (v___x_1648_ == 0)
{
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1618_;
}
else
{
lean_object* v___x_1649_; lean_object* v___x_1650_; 
v___x_1649_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2));
v___x_1650_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1630_, v___x_1649_);
if (lean_obj_tag(v___x_1650_) == 1)
{
lean_object* v_val_1651_; 
v_val_1651_ = lean_ctor_get(v___x_1650_, 0);
lean_inc(v_val_1651_);
lean_dec_ref_known(v___x_1650_, 1);
if (lean_obj_tag(v_val_1651_) == 2)
{
lean_object* v_n_1652_; lean_object* v_mantissa_1653_; lean_object* v_exponent_1654_; uint8_t v_isNeg_1655_; 
v_n_1652_ = lean_ctor_get(v_val_1651_, 0);
lean_inc_ref(v_n_1652_);
lean_dec_ref_known(v_val_1651_, 1);
v_mantissa_1653_ = lean_ctor_get(v_n_1652_, 0);
lean_inc(v_mantissa_1653_);
v_exponent_1654_ = lean_ctor_get(v_n_1652_, 1);
lean_inc(v_exponent_1654_);
lean_dec_ref(v_n_1652_);
v_isNeg_1655_ = lean_int_dec_lt(v_mantissa_1653_, v_intZero_1638_);
if (v_isNeg_1655_ == 0)
{
uint8_t v___x_1656_; 
v___x_1656_ = lean_nat_dec_eq(v_exponent_1654_, v_natZero_1637_);
lean_dec(v_exponent_1654_);
if (v___x_1656_ == 0)
{
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1621_;
}
else
{
lean_object* v___x_1657_; lean_object* v___x_1658_; 
v___x_1657_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__3));
v___x_1658_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1630_, v___x_1657_);
if (lean_obj_tag(v___x_1658_) == 1)
{
lean_object* v_val_1659_; 
v_val_1659_ = lean_ctor_get(v___x_1658_, 0);
lean_inc(v_val_1659_);
lean_dec_ref_known(v___x_1658_, 1);
if (lean_obj_tag(v_val_1659_) == 2)
{
lean_object* v_n_1660_; lean_object* v___x_1662_; uint8_t v_isShared_1663_; uint8_t v_isSharedCheck_1753_; 
v_n_1660_ = lean_ctor_get(v_val_1659_, 0);
v_isSharedCheck_1753_ = !lean_is_exclusive(v_val_1659_);
if (v_isSharedCheck_1753_ == 0)
{
v___x_1662_ = v_val_1659_;
v_isShared_1663_ = v_isSharedCheck_1753_;
goto v_resetjp_1661_;
}
else
{
lean_inc(v_n_1660_);
lean_dec(v_val_1659_);
v___x_1662_ = lean_box(0);
v_isShared_1663_ = v_isSharedCheck_1753_;
goto v_resetjp_1661_;
}
v_resetjp_1661_:
{
lean_object* v_mantissa_1664_; lean_object* v_exponent_1665_; lean_object* v___x_1667_; uint8_t v_isShared_1668_; uint8_t v_isSharedCheck_1752_; 
v_mantissa_1664_ = lean_ctor_get(v_n_1660_, 0);
v_exponent_1665_ = lean_ctor_get(v_n_1660_, 1);
v_isSharedCheck_1752_ = !lean_is_exclusive(v_n_1660_);
if (v_isSharedCheck_1752_ == 0)
{
v___x_1667_ = v_n_1660_;
v_isShared_1668_ = v_isSharedCheck_1752_;
goto v_resetjp_1666_;
}
else
{
lean_inc(v_exponent_1665_);
lean_inc(v_mantissa_1664_);
lean_dec(v_n_1660_);
v___x_1667_ = lean_box(0);
v_isShared_1668_ = v_isSharedCheck_1752_;
goto v_resetjp_1666_;
}
v_resetjp_1666_:
{
uint8_t v_isNeg_1669_; 
v_isNeg_1669_ = lean_int_dec_lt(v_mantissa_1664_, v_intZero_1638_);
if (v_isNeg_1669_ == 0)
{
uint8_t v___x_1670_; 
v___x_1670_ = lean_nat_dec_eq(v_exponent_1665_, v_natZero_1637_);
lean_dec(v_exponent_1665_);
if (v___x_1670_ == 0)
{
lean_del_object(v___x_1667_);
lean_dec(v_mantissa_1664_);
lean_del_object(v___x_1662_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1624_;
}
else
{
lean_object* v___x_1671_; lean_object* v___x_1672_; 
v___x_1671_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__3));
v___x_1672_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1630_, v___x_1671_);
if (lean_obj_tag(v___x_1672_) == 1)
{
lean_object* v_val_1673_; lean_object* v___x_1675_; uint8_t v_isShared_1676_; uint8_t v_isSharedCheck_1751_; 
v_val_1673_ = lean_ctor_get(v___x_1672_, 0);
v_isSharedCheck_1751_ = !lean_is_exclusive(v___x_1672_);
if (v_isSharedCheck_1751_ == 0)
{
v___x_1675_ = v___x_1672_;
v_isShared_1676_ = v_isSharedCheck_1751_;
goto v_resetjp_1674_;
}
else
{
lean_inc(v_val_1673_);
lean_dec(v___x_1672_);
v___x_1675_ = lean_box(0);
v_isShared_1676_ = v_isSharedCheck_1751_;
goto v_resetjp_1674_;
}
v_resetjp_1674_:
{
if (lean_obj_tag(v_val_1673_) == 1)
{
uint8_t v_b_1677_; lean_object* v_nameMap_1678_; lean_object* v_exprMap_1679_; lean_object* v_a_1680_; lean_object* v___x_1681_; 
v_b_1677_ = lean_ctor_get_uint8(v_val_1673_, 0);
lean_dec_ref_known(v_val_1673_, 0);
v_nameMap_1678_ = lean_ctor_get(v_a_1613_, 1);
v_exprMap_1679_ = lean_ctor_get(v_a_1613_, 3);
v_a_1680_ = lean_nat_abs(v_mantissa_1635_);
lean_dec(v_mantissa_1635_);
v___x_1681_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_1678_, v_a_1680_);
if (lean_obj_tag(v___x_1681_) == 1)
{
lean_object* v_val_1682_; lean_object* v___x_1684_; uint8_t v_isShared_1685_; uint8_t v_isSharedCheck_1741_; 
lean_dec(v_a_1680_);
lean_del_object(v___x_1662_);
v_val_1682_ = lean_ctor_get(v___x_1681_, 0);
v_isSharedCheck_1741_ = !lean_is_exclusive(v___x_1681_);
if (v_isSharedCheck_1741_ == 0)
{
v___x_1684_ = v___x_1681_;
v_isShared_1685_ = v_isSharedCheck_1741_;
goto v_resetjp_1683_;
}
else
{
lean_inc(v_val_1682_);
lean_dec(v___x_1681_);
v___x_1684_ = lean_box(0);
v_isShared_1685_ = v_isSharedCheck_1741_;
goto v_resetjp_1683_;
}
v_resetjp_1683_:
{
lean_object* v_a_1686_; lean_object* v___x_1687_; 
v_a_1686_ = lean_nat_abs(v_mantissa_1645_);
lean_dec(v_mantissa_1645_);
v___x_1687_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1679_, v_a_1686_);
if (lean_obj_tag(v___x_1687_) == 1)
{
lean_object* v_val_1688_; lean_object* v___x_1690_; uint8_t v_isShared_1691_; uint8_t v_isSharedCheck_1731_; 
lean_dec(v_a_1686_);
lean_del_object(v___x_1675_);
v_val_1688_ = lean_ctor_get(v___x_1687_, 0);
v_isSharedCheck_1731_ = !lean_is_exclusive(v___x_1687_);
if (v_isSharedCheck_1731_ == 0)
{
v___x_1690_ = v___x_1687_;
v_isShared_1691_ = v_isSharedCheck_1731_;
goto v_resetjp_1689_;
}
else
{
lean_inc(v_val_1688_);
lean_dec(v___x_1687_);
v___x_1690_ = lean_box(0);
v_isShared_1691_ = v_isSharedCheck_1731_;
goto v_resetjp_1689_;
}
v_resetjp_1689_:
{
lean_object* v_a_1692_; lean_object* v___x_1693_; 
v_a_1692_ = lean_nat_abs(v_mantissa_1653_);
lean_dec(v_mantissa_1653_);
v___x_1693_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1679_, v_a_1692_);
if (lean_obj_tag(v___x_1693_) == 1)
{
lean_object* v_val_1694_; lean_object* v___x_1696_; uint8_t v_isShared_1697_; uint8_t v_isSharedCheck_1721_; 
lean_dec(v_a_1692_);
lean_del_object(v___x_1684_);
v_val_1694_ = lean_ctor_get(v___x_1693_, 0);
v_isSharedCheck_1721_ = !lean_is_exclusive(v___x_1693_);
if (v_isSharedCheck_1721_ == 0)
{
v___x_1696_ = v___x_1693_;
v_isShared_1697_ = v_isSharedCheck_1721_;
goto v_resetjp_1695_;
}
else
{
lean_inc(v_val_1694_);
lean_dec(v___x_1693_);
v___x_1696_ = lean_box(0);
v_isShared_1697_ = v_isSharedCheck_1721_;
goto v_resetjp_1695_;
}
v_resetjp_1695_:
{
lean_object* v_a_1698_; lean_object* v___x_1699_; 
v_a_1698_ = lean_nat_abs(v_mantissa_1664_);
lean_dec(v_mantissa_1664_);
v___x_1699_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1679_, v_a_1698_);
if (lean_obj_tag(v___x_1699_) == 1)
{
lean_object* v_val_1700_; lean_object* v___x_1702_; uint8_t v_isShared_1703_; uint8_t v_isSharedCheck_1711_; 
lean_dec(v_a_1698_);
lean_del_object(v___x_1696_);
lean_del_object(v___x_1690_);
v_val_1700_ = lean_ctor_get(v___x_1699_, 0);
v_isSharedCheck_1711_ = !lean_is_exclusive(v___x_1699_);
if (v_isSharedCheck_1711_ == 0)
{
v___x_1702_ = v___x_1699_;
v_isShared_1703_ = v_isSharedCheck_1711_;
goto v_resetjp_1701_;
}
else
{
lean_inc(v_val_1700_);
lean_dec(v___x_1699_);
v___x_1702_ = lean_box(0);
v_isShared_1703_ = v_isSharedCheck_1711_;
goto v_resetjp_1701_;
}
v_resetjp_1701_:
{
lean_object* v___x_1704_; lean_object* v___x_1706_; 
v___x_1704_ = l_Lean_Expr_letE___override(v_val_1682_, v_val_1688_, v_val_1694_, v_val_1700_, v_b_1677_);
if (v_isShared_1668_ == 0)
{
lean_ctor_set(v___x_1667_, 1, v_a_1613_);
lean_ctor_set(v___x_1667_, 0, v___x_1704_);
v___x_1706_ = v___x_1667_;
goto v_reusejp_1705_;
}
else
{
lean_object* v_reuseFailAlloc_1710_; 
v_reuseFailAlloc_1710_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1710_, 0, v___x_1704_);
lean_ctor_set(v_reuseFailAlloc_1710_, 1, v_a_1613_);
v___x_1706_ = v_reuseFailAlloc_1710_;
goto v_reusejp_1705_;
}
v_reusejp_1705_:
{
lean_object* v___x_1708_; 
if (v_isShared_1703_ == 0)
{
lean_ctor_set_tag(v___x_1702_, 0);
lean_ctor_set(v___x_1702_, 0, v___x_1706_);
v___x_1708_ = v___x_1702_;
goto v_reusejp_1707_;
}
else
{
lean_object* v_reuseFailAlloc_1709_; 
v_reuseFailAlloc_1709_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1709_, 0, v___x_1706_);
v___x_1708_ = v_reuseFailAlloc_1709_;
goto v_reusejp_1707_;
}
v_reusejp_1707_:
{
return v___x_1708_;
}
}
}
}
else
{
lean_object* v___x_1712_; lean_object* v___x_1713_; lean_object* v___x_1714_; lean_object* v___x_1716_; 
lean_dec(v___x_1699_);
lean_dec(v_val_1694_);
lean_dec(v_val_1688_);
lean_dec(v_val_1682_);
lean_del_object(v___x_1667_);
lean_dec_ref(v_a_1613_);
v___x_1712_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1713_ = l_Nat_reprFast(v_a_1698_);
v___x_1714_ = lean_string_append(v___x_1712_, v___x_1713_);
lean_dec_ref(v___x_1713_);
if (v_isShared_1697_ == 0)
{
lean_ctor_set_tag(v___x_1696_, 18);
lean_ctor_set(v___x_1696_, 0, v___x_1714_);
v___x_1716_ = v___x_1696_;
goto v_reusejp_1715_;
}
else
{
lean_object* v_reuseFailAlloc_1720_; 
v_reuseFailAlloc_1720_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1720_, 0, v___x_1714_);
v___x_1716_ = v_reuseFailAlloc_1720_;
goto v_reusejp_1715_;
}
v_reusejp_1715_:
{
lean_object* v___x_1718_; 
if (v_isShared_1691_ == 0)
{
lean_ctor_set(v___x_1690_, 0, v___x_1716_);
v___x_1718_ = v___x_1690_;
goto v_reusejp_1717_;
}
else
{
lean_object* v_reuseFailAlloc_1719_; 
v_reuseFailAlloc_1719_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1719_, 0, v___x_1716_);
v___x_1718_ = v_reuseFailAlloc_1719_;
goto v_reusejp_1717_;
}
v_reusejp_1717_:
{
return v___x_1718_;
}
}
}
}
}
else
{
lean_object* v___x_1722_; lean_object* v___x_1723_; lean_object* v___x_1724_; lean_object* v___x_1726_; 
lean_dec(v___x_1693_);
lean_dec(v_val_1688_);
lean_dec(v_val_1682_);
lean_del_object(v___x_1667_);
lean_dec(v_mantissa_1664_);
lean_dec_ref(v_a_1613_);
v___x_1722_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1723_ = l_Nat_reprFast(v_a_1692_);
v___x_1724_ = lean_string_append(v___x_1722_, v___x_1723_);
lean_dec_ref(v___x_1723_);
if (v_isShared_1691_ == 0)
{
lean_ctor_set_tag(v___x_1690_, 18);
lean_ctor_set(v___x_1690_, 0, v___x_1724_);
v___x_1726_ = v___x_1690_;
goto v_reusejp_1725_;
}
else
{
lean_object* v_reuseFailAlloc_1730_; 
v_reuseFailAlloc_1730_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1730_, 0, v___x_1724_);
v___x_1726_ = v_reuseFailAlloc_1730_;
goto v_reusejp_1725_;
}
v_reusejp_1725_:
{
lean_object* v___x_1728_; 
if (v_isShared_1685_ == 0)
{
lean_ctor_set(v___x_1684_, 0, v___x_1726_);
v___x_1728_ = v___x_1684_;
goto v_reusejp_1727_;
}
else
{
lean_object* v_reuseFailAlloc_1729_; 
v_reuseFailAlloc_1729_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1729_, 0, v___x_1726_);
v___x_1728_ = v_reuseFailAlloc_1729_;
goto v_reusejp_1727_;
}
v_reusejp_1727_:
{
return v___x_1728_;
}
}
}
}
}
else
{
lean_object* v___x_1732_; lean_object* v___x_1733_; lean_object* v___x_1734_; lean_object* v___x_1736_; 
lean_dec(v___x_1687_);
lean_dec(v_val_1682_);
lean_del_object(v___x_1667_);
lean_dec(v_mantissa_1664_);
lean_dec(v_mantissa_1653_);
lean_dec_ref(v_a_1613_);
v___x_1732_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1733_ = l_Nat_reprFast(v_a_1686_);
v___x_1734_ = lean_string_append(v___x_1732_, v___x_1733_);
lean_dec_ref(v___x_1733_);
if (v_isShared_1685_ == 0)
{
lean_ctor_set_tag(v___x_1684_, 18);
lean_ctor_set(v___x_1684_, 0, v___x_1734_);
v___x_1736_ = v___x_1684_;
goto v_reusejp_1735_;
}
else
{
lean_object* v_reuseFailAlloc_1740_; 
v_reuseFailAlloc_1740_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1740_, 0, v___x_1734_);
v___x_1736_ = v_reuseFailAlloc_1740_;
goto v_reusejp_1735_;
}
v_reusejp_1735_:
{
lean_object* v___x_1738_; 
if (v_isShared_1676_ == 0)
{
lean_ctor_set(v___x_1675_, 0, v___x_1736_);
v___x_1738_ = v___x_1675_;
goto v_reusejp_1737_;
}
else
{
lean_object* v_reuseFailAlloc_1739_; 
v_reuseFailAlloc_1739_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1739_, 0, v___x_1736_);
v___x_1738_ = v_reuseFailAlloc_1739_;
goto v_reusejp_1737_;
}
v_reusejp_1737_:
{
return v___x_1738_;
}
}
}
}
}
else
{
lean_object* v___x_1742_; lean_object* v___x_1743_; lean_object* v___x_1744_; lean_object* v___x_1746_; 
lean_dec(v___x_1681_);
lean_del_object(v___x_1667_);
lean_dec(v_mantissa_1664_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec_ref(v_a_1613_);
v___x_1742_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_1743_ = l_Nat_reprFast(v_a_1680_);
v___x_1744_ = lean_string_append(v___x_1742_, v___x_1743_);
lean_dec_ref(v___x_1743_);
if (v_isShared_1676_ == 0)
{
lean_ctor_set_tag(v___x_1675_, 18);
lean_ctor_set(v___x_1675_, 0, v___x_1744_);
v___x_1746_ = v___x_1675_;
goto v_reusejp_1745_;
}
else
{
lean_object* v_reuseFailAlloc_1750_; 
v_reuseFailAlloc_1750_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1750_, 0, v___x_1744_);
v___x_1746_ = v_reuseFailAlloc_1750_;
goto v_reusejp_1745_;
}
v_reusejp_1745_:
{
lean_object* v___x_1748_; 
if (v_isShared_1663_ == 0)
{
lean_ctor_set_tag(v___x_1662_, 1);
lean_ctor_set(v___x_1662_, 0, v___x_1746_);
v___x_1748_ = v___x_1662_;
goto v_reusejp_1747_;
}
else
{
lean_object* v_reuseFailAlloc_1749_; 
v_reuseFailAlloc_1749_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1749_, 0, v___x_1746_);
v___x_1748_ = v_reuseFailAlloc_1749_;
goto v_reusejp_1747_;
}
v_reusejp_1747_:
{
return v___x_1748_;
}
}
}
}
else
{
lean_del_object(v___x_1675_);
lean_dec(v_val_1673_);
lean_del_object(v___x_1667_);
lean_dec(v_mantissa_1664_);
lean_del_object(v___x_1662_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1627_;
}
}
}
else
{
lean_dec(v___x_1672_);
lean_del_object(v___x_1667_);
lean_dec(v_mantissa_1664_);
lean_del_object(v___x_1662_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1627_;
}
}
}
else
{
lean_del_object(v___x_1667_);
lean_dec(v_exponent_1665_);
lean_dec(v_mantissa_1664_);
lean_del_object(v___x_1662_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1624_;
}
}
}
}
else
{
lean_dec(v_val_1659_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1624_;
}
}
else
{
lean_dec(v___x_1658_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1624_;
}
}
}
else
{
lean_dec(v_exponent_1654_);
lean_dec(v_mantissa_1653_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1621_;
}
}
else
{
lean_dec(v_val_1651_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1621_;
}
}
else
{
lean_dec(v___x_1650_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1621_;
}
}
}
else
{
lean_dec(v_exponent_1646_);
lean_dec(v_mantissa_1645_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1618_;
}
}
else
{
lean_dec(v_val_1643_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1618_;
}
}
else
{
lean_dec(v___x_1642_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1618_;
}
}
}
else
{
lean_dec(v_exponent_1636_);
lean_dec(v_mantissa_1635_);
lean_dec_ref(v_a_1613_);
goto v___jp_1615_;
}
}
else
{
lean_dec(v_val_1633_);
lean_dec_ref(v_a_1613_);
goto v___jp_1615_;
}
}
else
{
lean_dec(v___x_1632_);
lean_dec_ref(v_a_1613_);
goto v___jp_1615_;
}
}
else
{
lean_object* v___x_1754_; lean_object* v___x_1755_; 
lean_dec_ref(v_a_1613_);
v___x_1754_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1));
v___x_1755_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1755_, 0, v___x_1754_);
return v___x_1755_;
}
v___jp_1615_:
{
lean_object* v___x_1616_; lean_object* v___x_1617_; 
v___x_1616_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1));
v___x_1617_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1617_, 0, v___x_1616_);
return v___x_1617_;
}
v___jp_1618_:
{
lean_object* v___x_1619_; lean_object* v___x_1620_; 
v___x_1619_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1));
v___x_1620_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1620_, 0, v___x_1619_);
return v___x_1620_;
}
v___jp_1621_:
{
lean_object* v___x_1622_; lean_object* v___x_1623_; 
v___x_1622_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1));
v___x_1623_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1623_, 0, v___x_1622_);
return v___x_1623_;
}
v___jp_1624_:
{
lean_object* v___x_1625_; lean_object* v___x_1626_; 
v___x_1625_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1));
v___x_1626_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1626_, 0, v___x_1625_);
return v___x_1626_;
}
v___jp_1627_:
{
lean_object* v___x_1628_; lean_object* v___x_1629_; 
v___x_1628_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__1));
v___x_1629_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1629_, 0, v___x_1628_);
return v___x_1629_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprLetE___boxed(lean_object* v_json_1756_, lean_object* v_a_1757_, lean_object* v_a_1758_){
_start:
{
lean_object* v_res_1759_; 
v_res_1759_ = lp_proofEnvironment_Export_Parse_parseExprLetE(v_json_1756_, v_a_1757_);
lean_dec(v_json_1756_);
return v_res_1759_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprProj(lean_object* v_json_1766_, lean_object* v_a_1767_){
_start:
{
if (lean_obj_tag(v_json_1766_) == 5)
{
lean_object* v_kvPairs_1778_; lean_object* v___x_1779_; lean_object* v___x_1780_; 
v_kvPairs_1778_ = lean_ctor_get(v_json_1766_, 0);
v___x_1779_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__2));
v___x_1780_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1778_, v___x_1779_);
if (lean_obj_tag(v___x_1780_) == 1)
{
lean_object* v_val_1781_; 
v_val_1781_ = lean_ctor_get(v___x_1780_, 0);
lean_inc(v_val_1781_);
lean_dec_ref_known(v___x_1780_, 1);
if (lean_obj_tag(v_val_1781_) == 2)
{
lean_object* v_n_1782_; lean_object* v_mantissa_1783_; lean_object* v_exponent_1784_; lean_object* v_natZero_1785_; lean_object* v_intZero_1786_; uint8_t v_isNeg_1787_; 
v_n_1782_ = lean_ctor_get(v_val_1781_, 0);
lean_inc_ref(v_n_1782_);
lean_dec_ref_known(v_val_1781_, 1);
v_mantissa_1783_ = lean_ctor_get(v_n_1782_, 0);
lean_inc(v_mantissa_1783_);
v_exponent_1784_ = lean_ctor_get(v_n_1782_, 1);
lean_inc(v_exponent_1784_);
lean_dec_ref(v_n_1782_);
v_natZero_1785_ = lean_unsigned_to_nat(0u);
v_intZero_1786_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1787_ = lean_int_dec_lt(v_mantissa_1783_, v_intZero_1786_);
if (v_isNeg_1787_ == 0)
{
uint8_t v___x_1788_; 
v___x_1788_ = lean_nat_dec_eq(v_exponent_1784_, v_natZero_1785_);
lean_dec(v_exponent_1784_);
if (v___x_1788_ == 0)
{
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1769_;
}
else
{
lean_object* v___x_1789_; lean_object* v___x_1790_; 
v___x_1789_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__3));
v___x_1790_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1778_, v___x_1789_);
if (lean_obj_tag(v___x_1790_) == 1)
{
lean_object* v_val_1791_; 
v_val_1791_ = lean_ctor_get(v___x_1790_, 0);
lean_inc(v_val_1791_);
lean_dec_ref_known(v___x_1790_, 1);
if (lean_obj_tag(v_val_1791_) == 2)
{
lean_object* v_n_1792_; lean_object* v_mantissa_1793_; lean_object* v_exponent_1794_; uint8_t v_isNeg_1795_; 
v_n_1792_ = lean_ctor_get(v_val_1791_, 0);
lean_inc_ref(v_n_1792_);
lean_dec_ref_known(v_val_1791_, 1);
v_mantissa_1793_ = lean_ctor_get(v_n_1792_, 0);
lean_inc(v_mantissa_1793_);
v_exponent_1794_ = lean_ctor_get(v_n_1792_, 1);
lean_inc(v_exponent_1794_);
lean_dec_ref(v_n_1792_);
v_isNeg_1795_ = lean_int_dec_lt(v_mantissa_1793_, v_intZero_1786_);
if (v_isNeg_1795_ == 0)
{
uint8_t v___x_1796_; 
v___x_1796_ = lean_nat_dec_eq(v_exponent_1794_, v_natZero_1785_);
lean_dec(v_exponent_1794_);
if (v___x_1796_ == 0)
{
lean_dec(v_mantissa_1793_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1772_;
}
else
{
lean_object* v___x_1797_; lean_object* v___x_1798_; 
v___x_1797_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__4));
v___x_1798_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1778_, v___x_1797_);
if (lean_obj_tag(v___x_1798_) == 1)
{
lean_object* v_val_1799_; lean_object* v___x_1801_; uint8_t v_isShared_1802_; uint8_t v_isSharedCheck_1858_; 
v_val_1799_ = lean_ctor_get(v___x_1798_, 0);
v_isSharedCheck_1858_ = !lean_is_exclusive(v___x_1798_);
if (v_isSharedCheck_1858_ == 0)
{
v___x_1801_ = v___x_1798_;
v_isShared_1802_ = v_isSharedCheck_1858_;
goto v_resetjp_1800_;
}
else
{
lean_inc(v_val_1799_);
lean_dec(v___x_1798_);
v___x_1801_ = lean_box(0);
v_isShared_1802_ = v_isSharedCheck_1858_;
goto v_resetjp_1800_;
}
v_resetjp_1800_:
{
if (lean_obj_tag(v_val_1799_) == 2)
{
lean_object* v_n_1803_; lean_object* v___x_1805_; uint8_t v_isShared_1806_; uint8_t v_isSharedCheck_1857_; 
v_n_1803_ = lean_ctor_get(v_val_1799_, 0);
v_isSharedCheck_1857_ = !lean_is_exclusive(v_val_1799_);
if (v_isSharedCheck_1857_ == 0)
{
v___x_1805_ = v_val_1799_;
v_isShared_1806_ = v_isSharedCheck_1857_;
goto v_resetjp_1804_;
}
else
{
lean_inc(v_n_1803_);
lean_dec(v_val_1799_);
v___x_1805_ = lean_box(0);
v_isShared_1806_ = v_isSharedCheck_1857_;
goto v_resetjp_1804_;
}
v_resetjp_1804_:
{
lean_object* v_mantissa_1807_; lean_object* v_exponent_1808_; lean_object* v___x_1810_; uint8_t v_isShared_1811_; uint8_t v_isSharedCheck_1856_; 
v_mantissa_1807_ = lean_ctor_get(v_n_1803_, 0);
v_exponent_1808_ = lean_ctor_get(v_n_1803_, 1);
v_isSharedCheck_1856_ = !lean_is_exclusive(v_n_1803_);
if (v_isSharedCheck_1856_ == 0)
{
v___x_1810_ = v_n_1803_;
v_isShared_1811_ = v_isSharedCheck_1856_;
goto v_resetjp_1809_;
}
else
{
lean_inc(v_exponent_1808_);
lean_inc(v_mantissa_1807_);
lean_dec(v_n_1803_);
v___x_1810_ = lean_box(0);
v_isShared_1811_ = v_isSharedCheck_1856_;
goto v_resetjp_1809_;
}
v_resetjp_1809_:
{
uint8_t v_isNeg_1812_; 
v_isNeg_1812_ = lean_int_dec_lt(v_mantissa_1807_, v_intZero_1786_);
if (v_isNeg_1812_ == 0)
{
uint8_t v___x_1813_; 
v___x_1813_ = lean_nat_dec_eq(v_exponent_1808_, v_natZero_1785_);
lean_dec(v_exponent_1808_);
if (v___x_1813_ == 0)
{
lean_del_object(v___x_1810_);
lean_dec(v_mantissa_1807_);
lean_del_object(v___x_1805_);
lean_del_object(v___x_1801_);
lean_dec(v_mantissa_1793_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1775_;
}
else
{
lean_object* v_nameMap_1814_; lean_object* v_exprMap_1815_; lean_object* v_a_1816_; lean_object* v___x_1817_; 
v_nameMap_1814_ = lean_ctor_get(v_a_1767_, 1);
v_exprMap_1815_ = lean_ctor_get(v_a_1767_, 3);
v_a_1816_ = lean_nat_abs(v_mantissa_1783_);
lean_dec(v_mantissa_1783_);
v___x_1817_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_1814_, v_a_1816_);
if (lean_obj_tag(v___x_1817_) == 1)
{
lean_object* v_val_1818_; lean_object* v___x_1820_; uint8_t v_isShared_1821_; uint8_t v_isSharedCheck_1846_; 
lean_dec(v_a_1816_);
lean_del_object(v___x_1801_);
v_val_1818_ = lean_ctor_get(v___x_1817_, 0);
v_isSharedCheck_1846_ = !lean_is_exclusive(v___x_1817_);
if (v_isSharedCheck_1846_ == 0)
{
v___x_1820_ = v___x_1817_;
v_isShared_1821_ = v_isSharedCheck_1846_;
goto v_resetjp_1819_;
}
else
{
lean_inc(v_val_1818_);
lean_dec(v___x_1817_);
v___x_1820_ = lean_box(0);
v_isShared_1821_ = v_isSharedCheck_1846_;
goto v_resetjp_1819_;
}
v_resetjp_1819_:
{
lean_object* v_a_1822_; lean_object* v___x_1823_; 
v_a_1822_ = lean_nat_abs(v_mantissa_1807_);
lean_dec(v_mantissa_1807_);
v___x_1823_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1815_, v_a_1822_);
if (lean_obj_tag(v___x_1823_) == 1)
{
lean_object* v_val_1824_; lean_object* v___x_1826_; uint8_t v_isShared_1827_; uint8_t v_isSharedCheck_1836_; 
lean_dec(v_a_1822_);
lean_del_object(v___x_1820_);
lean_del_object(v___x_1805_);
v_val_1824_ = lean_ctor_get(v___x_1823_, 0);
v_isSharedCheck_1836_ = !lean_is_exclusive(v___x_1823_);
if (v_isSharedCheck_1836_ == 0)
{
v___x_1826_ = v___x_1823_;
v_isShared_1827_ = v_isSharedCheck_1836_;
goto v_resetjp_1825_;
}
else
{
lean_inc(v_val_1824_);
lean_dec(v___x_1823_);
v___x_1826_ = lean_box(0);
v_isShared_1827_ = v_isSharedCheck_1836_;
goto v_resetjp_1825_;
}
v_resetjp_1825_:
{
lean_object* v_a_1828_; lean_object* v___x_1829_; lean_object* v___x_1831_; 
v_a_1828_ = lean_nat_abs(v_mantissa_1793_);
lean_dec(v_mantissa_1793_);
v___x_1829_ = l_Lean_Expr_proj___override(v_val_1818_, v_a_1828_, v_val_1824_);
if (v_isShared_1811_ == 0)
{
lean_ctor_set(v___x_1810_, 1, v_a_1767_);
lean_ctor_set(v___x_1810_, 0, v___x_1829_);
v___x_1831_ = v___x_1810_;
goto v_reusejp_1830_;
}
else
{
lean_object* v_reuseFailAlloc_1835_; 
v_reuseFailAlloc_1835_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1835_, 0, v___x_1829_);
lean_ctor_set(v_reuseFailAlloc_1835_, 1, v_a_1767_);
v___x_1831_ = v_reuseFailAlloc_1835_;
goto v_reusejp_1830_;
}
v_reusejp_1830_:
{
lean_object* v___x_1833_; 
if (v_isShared_1827_ == 0)
{
lean_ctor_set_tag(v___x_1826_, 0);
lean_ctor_set(v___x_1826_, 0, v___x_1831_);
v___x_1833_ = v___x_1826_;
goto v_reusejp_1832_;
}
else
{
lean_object* v_reuseFailAlloc_1834_; 
v_reuseFailAlloc_1834_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1834_, 0, v___x_1831_);
v___x_1833_ = v_reuseFailAlloc_1834_;
goto v_reusejp_1832_;
}
v_reusejp_1832_:
{
return v___x_1833_;
}
}
}
}
else
{
lean_object* v___x_1837_; lean_object* v___x_1838_; lean_object* v___x_1839_; lean_object* v___x_1841_; 
lean_dec(v___x_1823_);
lean_dec(v_val_1818_);
lean_del_object(v___x_1810_);
lean_dec(v_mantissa_1793_);
lean_dec_ref(v_a_1767_);
v___x_1837_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1838_ = l_Nat_reprFast(v_a_1822_);
v___x_1839_ = lean_string_append(v___x_1837_, v___x_1838_);
lean_dec_ref(v___x_1838_);
if (v_isShared_1821_ == 0)
{
lean_ctor_set_tag(v___x_1820_, 18);
lean_ctor_set(v___x_1820_, 0, v___x_1839_);
v___x_1841_ = v___x_1820_;
goto v_reusejp_1840_;
}
else
{
lean_object* v_reuseFailAlloc_1845_; 
v_reuseFailAlloc_1845_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1845_, 0, v___x_1839_);
v___x_1841_ = v_reuseFailAlloc_1845_;
goto v_reusejp_1840_;
}
v_reusejp_1840_:
{
lean_object* v___x_1843_; 
if (v_isShared_1806_ == 0)
{
lean_ctor_set_tag(v___x_1805_, 1);
lean_ctor_set(v___x_1805_, 0, v___x_1841_);
v___x_1843_ = v___x_1805_;
goto v_reusejp_1842_;
}
else
{
lean_object* v_reuseFailAlloc_1844_; 
v_reuseFailAlloc_1844_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1844_, 0, v___x_1841_);
v___x_1843_ = v_reuseFailAlloc_1844_;
goto v_reusejp_1842_;
}
v_reusejp_1842_:
{
return v___x_1843_;
}
}
}
}
}
else
{
lean_object* v___x_1847_; lean_object* v___x_1848_; lean_object* v___x_1849_; lean_object* v___x_1851_; 
lean_dec(v___x_1817_);
lean_del_object(v___x_1810_);
lean_dec(v_mantissa_1807_);
lean_dec(v_mantissa_1793_);
lean_dec_ref(v_a_1767_);
v___x_1847_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_1848_ = l_Nat_reprFast(v_a_1816_);
v___x_1849_ = lean_string_append(v___x_1847_, v___x_1848_);
lean_dec_ref(v___x_1848_);
if (v_isShared_1806_ == 0)
{
lean_ctor_set_tag(v___x_1805_, 18);
lean_ctor_set(v___x_1805_, 0, v___x_1849_);
v___x_1851_ = v___x_1805_;
goto v_reusejp_1850_;
}
else
{
lean_object* v_reuseFailAlloc_1855_; 
v_reuseFailAlloc_1855_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1855_, 0, v___x_1849_);
v___x_1851_ = v_reuseFailAlloc_1855_;
goto v_reusejp_1850_;
}
v_reusejp_1850_:
{
lean_object* v___x_1853_; 
if (v_isShared_1802_ == 0)
{
lean_ctor_set(v___x_1801_, 0, v___x_1851_);
v___x_1853_ = v___x_1801_;
goto v_reusejp_1852_;
}
else
{
lean_object* v_reuseFailAlloc_1854_; 
v_reuseFailAlloc_1854_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1854_, 0, v___x_1851_);
v___x_1853_ = v_reuseFailAlloc_1854_;
goto v_reusejp_1852_;
}
v_reusejp_1852_:
{
return v___x_1853_;
}
}
}
}
}
else
{
lean_del_object(v___x_1810_);
lean_dec(v_exponent_1808_);
lean_dec(v_mantissa_1807_);
lean_del_object(v___x_1805_);
lean_del_object(v___x_1801_);
lean_dec(v_mantissa_1793_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1775_;
}
}
}
}
else
{
lean_del_object(v___x_1801_);
lean_dec(v_val_1799_);
lean_dec(v_mantissa_1793_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1775_;
}
}
}
else
{
lean_dec(v___x_1798_);
lean_dec(v_mantissa_1793_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1775_;
}
}
}
else
{
lean_dec(v_exponent_1794_);
lean_dec(v_mantissa_1793_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1772_;
}
}
else
{
lean_dec(v_val_1791_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1772_;
}
}
else
{
lean_dec(v___x_1790_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1772_;
}
}
}
else
{
lean_dec(v_exponent_1784_);
lean_dec(v_mantissa_1783_);
lean_dec_ref(v_a_1767_);
goto v___jp_1769_;
}
}
else
{
lean_dec(v_val_1781_);
lean_dec_ref(v_a_1767_);
goto v___jp_1769_;
}
}
else
{
lean_dec(v___x_1780_);
lean_dec_ref(v_a_1767_);
goto v___jp_1769_;
}
}
else
{
lean_object* v___x_1859_; lean_object* v___x_1860_; 
lean_dec_ref(v_a_1767_);
v___x_1859_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__1));
v___x_1860_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1860_, 0, v___x_1859_);
return v___x_1860_;
}
v___jp_1769_:
{
lean_object* v___x_1770_; lean_object* v___x_1771_; 
v___x_1770_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__1));
v___x_1771_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1771_, 0, v___x_1770_);
return v___x_1771_;
}
v___jp_1772_:
{
lean_object* v___x_1773_; lean_object* v___x_1774_; 
v___x_1773_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__1));
v___x_1774_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1774_, 0, v___x_1773_);
return v___x_1774_;
}
v___jp_1775_:
{
lean_object* v___x_1776_; lean_object* v___x_1777_; 
v___x_1776_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprProj___closed__1));
v___x_1777_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1777_, 0, v___x_1776_);
return v___x_1777_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprProj___boxed(lean_object* v_json_1861_, lean_object* v_a_1862_, lean_object* v_a_1863_){
_start:
{
lean_object* v_res_1864_; 
v_res_1864_ = lp_proofEnvironment_Export_Parse_parseExprProj(v_json_1861_, v_a_1862_);
lean_dec(v_json_1861_);
return v_res_1864_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprNatLit(lean_object* v_json_1868_, lean_object* v_a_1869_){
_start:
{
if (lean_obj_tag(v_json_1868_) == 3)
{
lean_object* v_s_1871_; lean_object* v___x_1873_; uint8_t v_isShared_1874_; uint8_t v_isSharedCheck_1896_; 
v_s_1871_ = lean_ctor_get(v_json_1868_, 0);
v_isSharedCheck_1896_ = !lean_is_exclusive(v_json_1868_);
if (v_isSharedCheck_1896_ == 0)
{
v___x_1873_ = v_json_1868_;
v_isShared_1874_ = v_isSharedCheck_1896_;
goto v_resetjp_1872_;
}
else
{
lean_inc(v_s_1871_);
lean_dec(v_json_1868_);
v___x_1873_ = lean_box(0);
v_isShared_1874_ = v_isSharedCheck_1896_;
goto v_resetjp_1872_;
}
v_resetjp_1872_:
{
lean_object* v___x_1875_; lean_object* v___x_1876_; lean_object* v___x_1877_; lean_object* v___x_1878_; 
v___x_1875_ = lean_unsigned_to_nat(0u);
v___x_1876_ = lean_string_utf8_byte_size(v_s_1871_);
v___x_1877_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1877_, 0, v_s_1871_);
lean_ctor_set(v___x_1877_, 1, v___x_1875_);
lean_ctor_set(v___x_1877_, 2, v___x_1876_);
v___x_1878_ = l_String_Slice_toNat_x3f(v___x_1877_);
lean_dec_ref_known(v___x_1877_, 3);
if (lean_obj_tag(v___x_1878_) == 1)
{
lean_object* v_val_1879_; lean_object* v___x_1881_; uint8_t v_isShared_1882_; uint8_t v_isSharedCheck_1891_; 
v_val_1879_ = lean_ctor_get(v___x_1878_, 0);
v_isSharedCheck_1891_ = !lean_is_exclusive(v___x_1878_);
if (v_isSharedCheck_1891_ == 0)
{
v___x_1881_ = v___x_1878_;
v_isShared_1882_ = v_isSharedCheck_1891_;
goto v_resetjp_1880_;
}
else
{
lean_inc(v_val_1879_);
lean_dec(v___x_1878_);
v___x_1881_ = lean_box(0);
v_isShared_1882_ = v_isSharedCheck_1891_;
goto v_resetjp_1880_;
}
v_resetjp_1880_:
{
lean_object* v___x_1884_; 
if (v_isShared_1882_ == 0)
{
lean_ctor_set_tag(v___x_1881_, 0);
v___x_1884_ = v___x_1881_;
goto v_reusejp_1883_;
}
else
{
lean_object* v_reuseFailAlloc_1890_; 
v_reuseFailAlloc_1890_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1890_, 0, v_val_1879_);
v___x_1884_ = v_reuseFailAlloc_1890_;
goto v_reusejp_1883_;
}
v_reusejp_1883_:
{
lean_object* v___x_1885_; lean_object* v___x_1886_; lean_object* v___x_1888_; 
v___x_1885_ = l_Lean_Expr_lit___override(v___x_1884_);
v___x_1886_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1886_, 0, v___x_1885_);
lean_ctor_set(v___x_1886_, 1, v_a_1869_);
if (v_isShared_1874_ == 0)
{
lean_ctor_set_tag(v___x_1873_, 0);
lean_ctor_set(v___x_1873_, 0, v___x_1886_);
v___x_1888_ = v___x_1873_;
goto v_reusejp_1887_;
}
else
{
lean_object* v_reuseFailAlloc_1889_; 
v_reuseFailAlloc_1889_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1889_, 0, v___x_1886_);
v___x_1888_ = v_reuseFailAlloc_1889_;
goto v_reusejp_1887_;
}
v_reusejp_1887_:
{
return v___x_1888_;
}
}
}
}
else
{
lean_object* v___x_1892_; lean_object* v___x_1894_; 
lean_dec(v___x_1878_);
lean_dec_ref(v_a_1869_);
v___x_1892_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__1));
if (v_isShared_1874_ == 0)
{
lean_ctor_set_tag(v___x_1873_, 1);
lean_ctor_set(v___x_1873_, 0, v___x_1892_);
v___x_1894_ = v___x_1873_;
goto v_reusejp_1893_;
}
else
{
lean_object* v_reuseFailAlloc_1895_; 
v_reuseFailAlloc_1895_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1895_, 0, v___x_1892_);
v___x_1894_ = v_reuseFailAlloc_1895_;
goto v_reusejp_1893_;
}
v_reusejp_1893_:
{
return v___x_1894_;
}
}
}
}
else
{
lean_object* v___x_1897_; lean_object* v___x_1898_; 
lean_dec_ref(v_a_1869_);
lean_dec(v_json_1868_);
v___x_1897_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprNatLit___closed__1));
v___x_1898_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1898_, 0, v___x_1897_);
return v___x_1898_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprNatLit___boxed(lean_object* v_json_1899_, lean_object* v_a_1900_, lean_object* v_a_1901_){
_start:
{
lean_object* v_res_1902_; 
v_res_1902_ = lp_proofEnvironment_Export_Parse_parseExprNatLit(v_json_1899_, v_a_1900_);
return v_res_1902_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprStrLit(lean_object* v_json_1906_, lean_object* v_a_1907_){
_start:
{
if (lean_obj_tag(v_json_1906_) == 3)
{
lean_object* v_s_1909_; lean_object* v___x_1911_; uint8_t v_isShared_1912_; uint8_t v_isSharedCheck_1919_; 
v_s_1909_ = lean_ctor_get(v_json_1906_, 0);
v_isSharedCheck_1919_ = !lean_is_exclusive(v_json_1906_);
if (v_isSharedCheck_1919_ == 0)
{
v___x_1911_ = v_json_1906_;
v_isShared_1912_ = v_isSharedCheck_1919_;
goto v_resetjp_1910_;
}
else
{
lean_inc(v_s_1909_);
lean_dec(v_json_1906_);
v___x_1911_ = lean_box(0);
v_isShared_1912_ = v_isSharedCheck_1919_;
goto v_resetjp_1910_;
}
v_resetjp_1910_:
{
lean_object* v___x_1914_; 
if (v_isShared_1912_ == 0)
{
lean_ctor_set_tag(v___x_1911_, 1);
v___x_1914_ = v___x_1911_;
goto v_reusejp_1913_;
}
else
{
lean_object* v_reuseFailAlloc_1918_; 
v_reuseFailAlloc_1918_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1918_, 0, v_s_1909_);
v___x_1914_ = v_reuseFailAlloc_1918_;
goto v_reusejp_1913_;
}
v_reusejp_1913_:
{
lean_object* v___x_1915_; lean_object* v___x_1916_; lean_object* v___x_1917_; 
v___x_1915_ = l_Lean_Expr_lit___override(v___x_1914_);
v___x_1916_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1916_, 0, v___x_1915_);
lean_ctor_set(v___x_1916_, 1, v_a_1907_);
v___x_1917_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1917_, 0, v___x_1916_);
return v___x_1917_;
}
}
}
else
{
lean_object* v___x_1920_; lean_object* v___x_1921_; 
lean_dec_ref(v_a_1907_);
lean_dec(v_json_1906_);
v___x_1920_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprStrLit___closed__1));
v___x_1921_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1921_, 0, v___x_1920_);
return v___x_1921_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprStrLit___boxed(lean_object* v_json_1922_, lean_object* v_a_1923_, lean_object* v_a_1924_){
_start:
{
lean_object* v_res_1925_; 
v_res_1925_ = lp_proofEnvironment_Export_Parse_parseExprStrLit(v_json_1922_, v_a_1923_);
return v_res_1925_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata(lean_object* v_json_1931_, lean_object* v_a_1932_){
_start:
{
if (lean_obj_tag(v_json_1931_) == 5)
{
lean_object* v_kvPairs_1940_; lean_object* v___x_1941_; lean_object* v___x_1942_; 
v_kvPairs_1940_ = lean_ctor_get(v_json_1931_, 0);
v___x_1941_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprMdata___closed__2));
v___x_1942_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1940_, v___x_1941_);
if (lean_obj_tag(v___x_1942_) == 1)
{
lean_object* v_val_1943_; 
v_val_1943_ = lean_ctor_get(v___x_1942_, 0);
lean_inc(v_val_1943_);
lean_dec_ref_known(v___x_1942_, 1);
if (lean_obj_tag(v_val_1943_) == 2)
{
lean_object* v_n_1944_; lean_object* v_mantissa_1945_; lean_object* v_exponent_1946_; lean_object* v___x_1948_; uint8_t v_isShared_1949_; uint8_t v_isSharedCheck_1991_; 
v_n_1944_ = lean_ctor_get(v_val_1943_, 0);
lean_inc_ref(v_n_1944_);
lean_dec_ref_known(v_val_1943_, 1);
v_mantissa_1945_ = lean_ctor_get(v_n_1944_, 0);
v_exponent_1946_ = lean_ctor_get(v_n_1944_, 1);
v_isSharedCheck_1991_ = !lean_is_exclusive(v_n_1944_);
if (v_isSharedCheck_1991_ == 0)
{
v___x_1948_ = v_n_1944_;
v_isShared_1949_ = v_isSharedCheck_1991_;
goto v_resetjp_1947_;
}
else
{
lean_inc(v_exponent_1946_);
lean_inc(v_mantissa_1945_);
lean_dec(v_n_1944_);
v___x_1948_ = lean_box(0);
v_isShared_1949_ = v_isSharedCheck_1991_;
goto v_resetjp_1947_;
}
v_resetjp_1947_:
{
lean_object* v_natZero_1950_; lean_object* v_intZero_1951_; uint8_t v_isNeg_1952_; 
v_natZero_1950_ = lean_unsigned_to_nat(0u);
v_intZero_1951_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_1952_ = lean_int_dec_lt(v_mantissa_1945_, v_intZero_1951_);
if (v_isNeg_1952_ == 0)
{
uint8_t v___x_1953_; 
v___x_1953_ = lean_nat_dec_eq(v_exponent_1946_, v_natZero_1950_);
lean_dec(v_exponent_1946_);
if (v___x_1953_ == 0)
{
lean_del_object(v___x_1948_);
lean_dec(v_mantissa_1945_);
lean_dec_ref(v_a_1932_);
goto v___jp_1934_;
}
else
{
lean_object* v___x_1954_; lean_object* v___x_1955_; 
v___x_1954_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprMdata___closed__3));
v___x_1955_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_1940_, v___x_1954_);
if (lean_obj_tag(v___x_1955_) == 1)
{
lean_object* v_val_1956_; lean_object* v___x_1958_; uint8_t v_isShared_1959_; uint8_t v_isSharedCheck_1990_; 
v_val_1956_ = lean_ctor_get(v___x_1955_, 0);
v_isSharedCheck_1990_ = !lean_is_exclusive(v___x_1955_);
if (v_isSharedCheck_1990_ == 0)
{
v___x_1958_ = v___x_1955_;
v_isShared_1959_ = v_isSharedCheck_1990_;
goto v_resetjp_1957_;
}
else
{
lean_inc(v_val_1956_);
lean_dec(v___x_1955_);
v___x_1958_ = lean_box(0);
v_isShared_1959_ = v_isSharedCheck_1990_;
goto v_resetjp_1957_;
}
v_resetjp_1957_:
{
if (lean_obj_tag(v_val_1956_) == 5)
{
lean_object* v___x_1961_; uint8_t v_isShared_1962_; uint8_t v_isSharedCheck_1988_; 
v_isSharedCheck_1988_ = !lean_is_exclusive(v_val_1956_);
if (v_isSharedCheck_1988_ == 0)
{
lean_object* v_unused_1989_; 
v_unused_1989_ = lean_ctor_get(v_val_1956_, 0);
lean_dec(v_unused_1989_);
v___x_1961_ = v_val_1956_;
v_isShared_1962_ = v_isSharedCheck_1988_;
goto v_resetjp_1960_;
}
else
{
lean_dec(v_val_1956_);
v___x_1961_ = lean_box(0);
v_isShared_1962_ = v_isSharedCheck_1988_;
goto v_resetjp_1960_;
}
v_resetjp_1960_:
{
lean_object* v_exprMap_1963_; lean_object* v_a_1964_; lean_object* v___x_1965_; 
v_exprMap_1963_ = lean_ctor_get(v_a_1932_, 3);
v_a_1964_ = lean_nat_abs(v_mantissa_1945_);
lean_dec(v_mantissa_1945_);
v___x_1965_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_1963_, v_a_1964_);
if (lean_obj_tag(v___x_1965_) == 1)
{
lean_object* v_val_1966_; lean_object* v___x_1968_; uint8_t v_isShared_1969_; uint8_t v_isSharedCheck_1978_; 
lean_dec(v_a_1964_);
lean_del_object(v___x_1961_);
lean_del_object(v___x_1958_);
v_val_1966_ = lean_ctor_get(v___x_1965_, 0);
v_isSharedCheck_1978_ = !lean_is_exclusive(v___x_1965_);
if (v_isSharedCheck_1978_ == 0)
{
v___x_1968_ = v___x_1965_;
v_isShared_1969_ = v_isSharedCheck_1978_;
goto v_resetjp_1967_;
}
else
{
lean_inc(v_val_1966_);
lean_dec(v___x_1965_);
v___x_1968_ = lean_box(0);
v_isShared_1969_ = v_isSharedCheck_1978_;
goto v_resetjp_1967_;
}
v_resetjp_1967_:
{
lean_object* v___x_1970_; lean_object* v___x_1971_; lean_object* v___x_1973_; 
v___x_1970_ = lean_box(0);
v___x_1971_ = l_Lean_Expr_mdata___override(v___x_1970_, v_val_1966_);
if (v_isShared_1949_ == 0)
{
lean_ctor_set(v___x_1948_, 1, v_a_1932_);
lean_ctor_set(v___x_1948_, 0, v___x_1971_);
v___x_1973_ = v___x_1948_;
goto v_reusejp_1972_;
}
else
{
lean_object* v_reuseFailAlloc_1977_; 
v_reuseFailAlloc_1977_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1977_, 0, v___x_1971_);
lean_ctor_set(v_reuseFailAlloc_1977_, 1, v_a_1932_);
v___x_1973_ = v_reuseFailAlloc_1977_;
goto v_reusejp_1972_;
}
v_reusejp_1972_:
{
lean_object* v___x_1975_; 
if (v_isShared_1969_ == 0)
{
lean_ctor_set_tag(v___x_1968_, 0);
lean_ctor_set(v___x_1968_, 0, v___x_1973_);
v___x_1975_ = v___x_1968_;
goto v_reusejp_1974_;
}
else
{
lean_object* v_reuseFailAlloc_1976_; 
v_reuseFailAlloc_1976_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1976_, 0, v___x_1973_);
v___x_1975_ = v_reuseFailAlloc_1976_;
goto v_reusejp_1974_;
}
v_reusejp_1974_:
{
return v___x_1975_;
}
}
}
}
else
{
lean_object* v___x_1979_; lean_object* v___x_1980_; lean_object* v___x_1981_; lean_object* v___x_1983_; 
lean_dec(v___x_1965_);
lean_del_object(v___x_1948_);
lean_dec_ref(v_a_1932_);
v___x_1979_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_1980_ = l_Nat_reprFast(v_a_1964_);
v___x_1981_ = lean_string_append(v___x_1979_, v___x_1980_);
lean_dec_ref(v___x_1980_);
if (v_isShared_1962_ == 0)
{
lean_ctor_set_tag(v___x_1961_, 18);
lean_ctor_set(v___x_1961_, 0, v___x_1981_);
v___x_1983_ = v___x_1961_;
goto v_reusejp_1982_;
}
else
{
lean_object* v_reuseFailAlloc_1987_; 
v_reuseFailAlloc_1987_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1987_, 0, v___x_1981_);
v___x_1983_ = v_reuseFailAlloc_1987_;
goto v_reusejp_1982_;
}
v_reusejp_1982_:
{
lean_object* v___x_1985_; 
if (v_isShared_1959_ == 0)
{
lean_ctor_set(v___x_1958_, 0, v___x_1983_);
v___x_1985_ = v___x_1958_;
goto v_reusejp_1984_;
}
else
{
lean_object* v_reuseFailAlloc_1986_; 
v_reuseFailAlloc_1986_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1986_, 0, v___x_1983_);
v___x_1985_ = v_reuseFailAlloc_1986_;
goto v_reusejp_1984_;
}
v_reusejp_1984_:
{
return v___x_1985_;
}
}
}
}
}
else
{
lean_del_object(v___x_1958_);
lean_dec(v_val_1956_);
lean_del_object(v___x_1948_);
lean_dec(v_mantissa_1945_);
lean_dec_ref(v_a_1932_);
goto v___jp_1937_;
}
}
}
else
{
lean_dec(v___x_1955_);
lean_del_object(v___x_1948_);
lean_dec(v_mantissa_1945_);
lean_dec_ref(v_a_1932_);
goto v___jp_1937_;
}
}
}
else
{
lean_del_object(v___x_1948_);
lean_dec(v_exponent_1946_);
lean_dec(v_mantissa_1945_);
lean_dec_ref(v_a_1932_);
goto v___jp_1934_;
}
}
}
else
{
lean_dec(v_val_1943_);
lean_dec_ref(v_a_1932_);
goto v___jp_1934_;
}
}
else
{
lean_dec(v___x_1942_);
lean_dec_ref(v_a_1932_);
goto v___jp_1934_;
}
}
else
{
lean_object* v___x_1992_; lean_object* v___x_1993_; 
lean_dec_ref(v_a_1932_);
v___x_1992_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprMdata___closed__1));
v___x_1993_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1993_, 0, v___x_1992_);
return v___x_1993_;
}
v___jp_1934_:
{
lean_object* v___x_1935_; lean_object* v___x_1936_; 
v___x_1935_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprMdata___closed__1));
v___x_1936_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1936_, 0, v___x_1935_);
return v___x_1936_;
}
v___jp_1937_:
{
lean_object* v___x_1938_; lean_object* v___x_1939_; 
v___x_1938_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprMdata___closed__1));
v___x_1939_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1939_, 0, v___x_1938_);
return v___x_1939_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseExprMdata___boxed(lean_object* v_json_1994_, lean_object* v_a_1995_, lean_object* v_a_1996_){
_start:
{
lean_object* v_res_1997_; 
v_res_1997_ = lp_proofEnvironment_Export_Parse_parseExprMdata(v_json_1994_, v_a_1995_);
lean_dec(v_json_1994_);
return v_res_1997_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0(lean_object* v_x_2001_, lean_object* v_x_2002_, lean_object* v___y_2003_){
_start:
{
if (lean_obj_tag(v_x_2001_) == 0)
{
lean_object* v___x_2008_; lean_object* v___x_2009_; lean_object* v___x_2010_; 
v___x_2008_ = l_List_reverse___redArg(v_x_2002_);
v___x_2009_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2009_, 0, v___x_2008_);
lean_ctor_set(v___x_2009_, 1, v___y_2003_);
v___x_2010_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2010_, 0, v___x_2009_);
return v___x_2010_;
}
else
{
lean_object* v_head_2011_; 
v_head_2011_ = lean_ctor_get(v_x_2001_, 0);
lean_inc(v_head_2011_);
if (lean_obj_tag(v_head_2011_) == 2)
{
lean_object* v_n_2012_; lean_object* v___x_2014_; uint8_t v_isShared_2015_; uint8_t v_isSharedCheck_2043_; 
v_n_2012_ = lean_ctor_get(v_head_2011_, 0);
v_isSharedCheck_2043_ = !lean_is_exclusive(v_head_2011_);
if (v_isSharedCheck_2043_ == 0)
{
v___x_2014_ = v_head_2011_;
v_isShared_2015_ = v_isSharedCheck_2043_;
goto v_resetjp_2013_;
}
else
{
lean_inc(v_n_2012_);
lean_dec(v_head_2011_);
v___x_2014_ = lean_box(0);
v_isShared_2015_ = v_isSharedCheck_2043_;
goto v_resetjp_2013_;
}
v_resetjp_2013_:
{
lean_object* v_tail_2016_; lean_object* v___x_2018_; uint8_t v_isShared_2019_; uint8_t v_isSharedCheck_2041_; 
v_tail_2016_ = lean_ctor_get(v_x_2001_, 1);
v_isSharedCheck_2041_ = !lean_is_exclusive(v_x_2001_);
if (v_isSharedCheck_2041_ == 0)
{
lean_object* v_unused_2042_; 
v_unused_2042_ = lean_ctor_get(v_x_2001_, 0);
lean_dec(v_unused_2042_);
v___x_2018_ = v_x_2001_;
v_isShared_2019_ = v_isSharedCheck_2041_;
goto v_resetjp_2017_;
}
else
{
lean_inc(v_tail_2016_);
lean_dec(v_x_2001_);
v___x_2018_ = lean_box(0);
v_isShared_2019_ = v_isSharedCheck_2041_;
goto v_resetjp_2017_;
}
v_resetjp_2017_:
{
lean_object* v_mantissa_2020_; lean_object* v_exponent_2021_; lean_object* v_natZero_2022_; lean_object* v_intZero_2023_; uint8_t v_isNeg_2024_; 
v_mantissa_2020_ = lean_ctor_get(v_n_2012_, 0);
lean_inc(v_mantissa_2020_);
v_exponent_2021_ = lean_ctor_get(v_n_2012_, 1);
lean_inc(v_exponent_2021_);
lean_dec_ref(v_n_2012_);
v_natZero_2022_ = lean_unsigned_to_nat(0u);
v_intZero_2023_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_2024_ = lean_int_dec_lt(v_mantissa_2020_, v_intZero_2023_);
if (v_isNeg_2024_ == 0)
{
uint8_t v___x_2025_; 
v___x_2025_ = lean_nat_dec_eq(v_exponent_2021_, v_natZero_2022_);
lean_dec(v_exponent_2021_);
if (v___x_2025_ == 0)
{
lean_dec(v_mantissa_2020_);
lean_del_object(v___x_2018_);
lean_dec(v_tail_2016_);
lean_del_object(v___x_2014_);
lean_dec_ref(v___y_2003_);
lean_dec(v_x_2002_);
goto v___jp_2005_;
}
else
{
lean_object* v_nameMap_2026_; lean_object* v_a_2027_; lean_object* v___x_2028_; 
v_nameMap_2026_ = lean_ctor_get(v___y_2003_, 1);
v_a_2027_ = lean_nat_abs(v_mantissa_2020_);
lean_dec(v_mantissa_2020_);
v___x_2028_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_2026_, v_a_2027_);
if (lean_obj_tag(v___x_2028_) == 1)
{
lean_object* v_val_2029_; lean_object* v___x_2031_; 
lean_dec(v_a_2027_);
lean_del_object(v___x_2014_);
v_val_2029_ = lean_ctor_get(v___x_2028_, 0);
lean_inc(v_val_2029_);
lean_dec_ref_known(v___x_2028_, 1);
if (v_isShared_2019_ == 0)
{
lean_ctor_set(v___x_2018_, 1, v_x_2002_);
lean_ctor_set(v___x_2018_, 0, v_val_2029_);
v___x_2031_ = v___x_2018_;
goto v_reusejp_2030_;
}
else
{
lean_object* v_reuseFailAlloc_2033_; 
v_reuseFailAlloc_2033_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2033_, 0, v_val_2029_);
lean_ctor_set(v_reuseFailAlloc_2033_, 1, v_x_2002_);
v___x_2031_ = v_reuseFailAlloc_2033_;
goto v_reusejp_2030_;
}
v_reusejp_2030_:
{
v_x_2001_ = v_tail_2016_;
v_x_2002_ = v___x_2031_;
goto _start;
}
}
else
{
lean_object* v___x_2034_; lean_object* v___x_2035_; lean_object* v___x_2036_; lean_object* v___x_2038_; 
lean_dec(v___x_2028_);
lean_del_object(v___x_2018_);
lean_dec(v_tail_2016_);
lean_dec_ref(v___y_2003_);
lean_dec(v_x_2002_);
v___x_2034_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_2035_ = l_Nat_reprFast(v_a_2027_);
v___x_2036_ = lean_string_append(v___x_2034_, v___x_2035_);
lean_dec_ref(v___x_2035_);
if (v_isShared_2015_ == 0)
{
lean_ctor_set_tag(v___x_2014_, 18);
lean_ctor_set(v___x_2014_, 0, v___x_2036_);
v___x_2038_ = v___x_2014_;
goto v_reusejp_2037_;
}
else
{
lean_object* v_reuseFailAlloc_2040_; 
v_reuseFailAlloc_2040_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2040_, 0, v___x_2036_);
v___x_2038_ = v_reuseFailAlloc_2040_;
goto v_reusejp_2037_;
}
v_reusejp_2037_:
{
lean_object* v___x_2039_; 
v___x_2039_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2039_, 0, v___x_2038_);
return v___x_2039_;
}
}
}
}
else
{
lean_dec(v_exponent_2021_);
lean_dec(v_mantissa_2020_);
lean_del_object(v___x_2018_);
lean_dec(v_tail_2016_);
lean_del_object(v___x_2014_);
lean_dec_ref(v___y_2003_);
lean_dec(v_x_2002_);
goto v___jp_2005_;
}
}
}
}
else
{
lean_dec(v_head_2011_);
lean_dec_ref_known(v_x_2001_, 2);
lean_dec_ref(v___y_2003_);
lean_dec(v_x_2002_);
goto v___jp_2005_;
}
}
v___jp_2005_:
{
lean_object* v___x_2006_; lean_object* v___x_2007_; 
v___x_2006_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___closed__1));
v___x_2007_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2007_, 0, v___x_2006_);
return v___x_2007_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0___boxed(lean_object* v_x_2044_, lean_object* v_x_2045_, lean_object* v___y_2046_, lean_object* v___y_2047_){
_start:
{
lean_object* v_res_2048_; 
v_res_2048_ = lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0(v_x_2044_, v_x_2045_, v___y_2046_);
return v_res_2048_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getNameList(lean_object* v_idxs_2049_, lean_object* v_a_2050_){
_start:
{
lean_object* v___x_2052_; lean_object* v___x_2053_; lean_object* v___x_2054_; 
v___x_2052_ = lean_array_to_list(v_idxs_2049_);
v___x_2053_ = lean_box(0);
v___x_2054_ = lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_getNameList_spec__0(v___x_2052_, v___x_2053_, v_a_2050_);
return v___x_2054_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_getNameList___boxed(lean_object* v_idxs_2055_, lean_object* v_a_2056_, lean_object* v_a_2057_){
_start:
{
lean_object* v_res_2058_; 
v_res_2058_ = lp_proofEnvironment_Export_Parse_getNameList(v_idxs_2055_, v_a_2056_);
return v_res_2058_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo(lean_object* v_data_2064_, lean_object* v_a_2065_){
_start:
{
lean_object* v___x_2079_; lean_object* v___x_2080_; 
v___x_2079_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_2080_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2064_, v___x_2079_);
if (lean_obj_tag(v___x_2080_) == 1)
{
lean_object* v_val_2081_; 
v_val_2081_ = lean_ctor_get(v___x_2080_, 0);
lean_inc(v_val_2081_);
lean_dec_ref_known(v___x_2080_, 1);
if (lean_obj_tag(v_val_2081_) == 2)
{
lean_object* v_n_2082_; lean_object* v_mantissa_2083_; lean_object* v_exponent_2084_; lean_object* v_natZero_2085_; lean_object* v_intZero_2086_; uint8_t v_isNeg_2087_; 
v_n_2082_ = lean_ctor_get(v_val_2081_, 0);
lean_inc_ref(v_n_2082_);
lean_dec_ref_known(v_val_2081_, 1);
v_mantissa_2083_ = lean_ctor_get(v_n_2082_, 0);
lean_inc(v_mantissa_2083_);
v_exponent_2084_ = lean_ctor_get(v_n_2082_, 1);
lean_inc(v_exponent_2084_);
lean_dec_ref(v_n_2082_);
v_natZero_2085_ = lean_unsigned_to_nat(0u);
v_intZero_2086_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_2087_ = lean_int_dec_lt(v_mantissa_2083_, v_intZero_2086_);
if (v_isNeg_2087_ == 0)
{
uint8_t v___x_2088_; 
v___x_2088_ = lean_nat_dec_eq(v_exponent_2084_, v_natZero_2085_);
lean_dec(v_exponent_2084_);
if (v___x_2088_ == 0)
{
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2067_;
}
else
{
lean_object* v___x_2089_; lean_object* v___x_2090_; 
v___x_2089_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_2090_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2064_, v___x_2089_);
if (lean_obj_tag(v___x_2090_) == 1)
{
lean_object* v_val_2091_; 
v_val_2091_ = lean_ctor_get(v___x_2090_, 0);
lean_inc(v_val_2091_);
lean_dec_ref_known(v___x_2090_, 1);
if (lean_obj_tag(v_val_2091_) == 4)
{
lean_object* v_elems_2092_; lean_object* v___x_2093_; lean_object* v___x_2094_; 
v_elems_2092_ = lean_ctor_get(v_val_2091_, 0);
lean_inc_ref(v_elems_2092_);
lean_dec_ref_known(v_val_2091_, 1);
v___x_2093_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_2094_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2064_, v___x_2093_);
if (lean_obj_tag(v___x_2094_) == 1)
{
lean_object* v_val_2095_; 
v_val_2095_ = lean_ctor_get(v___x_2094_, 0);
lean_inc(v_val_2095_);
lean_dec_ref_known(v___x_2094_, 1);
if (lean_obj_tag(v_val_2095_) == 2)
{
lean_object* v_n_2096_; lean_object* v___x_2098_; uint8_t v_isShared_2099_; uint8_t v_isSharedCheck_2203_; 
v_n_2096_ = lean_ctor_get(v_val_2095_, 0);
v_isSharedCheck_2203_ = !lean_is_exclusive(v_val_2095_);
if (v_isSharedCheck_2203_ == 0)
{
v___x_2098_ = v_val_2095_;
v_isShared_2099_ = v_isSharedCheck_2203_;
goto v_resetjp_2097_;
}
else
{
lean_inc(v_n_2096_);
lean_dec(v_val_2095_);
v___x_2098_ = lean_box(0);
v_isShared_2099_ = v_isSharedCheck_2203_;
goto v_resetjp_2097_;
}
v_resetjp_2097_:
{
lean_object* v_mantissa_2100_; lean_object* v_exponent_2101_; uint8_t v_isNeg_2102_; 
v_mantissa_2100_ = lean_ctor_get(v_n_2096_, 0);
lean_inc(v_mantissa_2100_);
v_exponent_2101_ = lean_ctor_get(v_n_2096_, 1);
lean_inc(v_exponent_2101_);
lean_dec_ref(v_n_2096_);
v_isNeg_2102_ = lean_int_dec_lt(v_mantissa_2100_, v_intZero_2086_);
if (v_isNeg_2102_ == 0)
{
uint8_t v___x_2103_; 
v___x_2103_ = lean_nat_dec_eq(v_exponent_2101_, v_natZero_2085_);
lean_dec(v_exponent_2101_);
if (v___x_2103_ == 0)
{
lean_dec(v_mantissa_2100_);
lean_del_object(v___x_2098_);
lean_dec_ref(v_elems_2092_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2073_;
}
else
{
lean_object* v___x_2104_; lean_object* v___x_2105_; 
v___x_2104_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3));
v___x_2105_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2064_, v___x_2104_);
if (lean_obj_tag(v___x_2105_) == 1)
{
lean_object* v_val_2106_; lean_object* v___x_2108_; uint8_t v_isShared_2109_; uint8_t v_isSharedCheck_2202_; 
v_val_2106_ = lean_ctor_get(v___x_2105_, 0);
v_isSharedCheck_2202_ = !lean_is_exclusive(v___x_2105_);
if (v_isSharedCheck_2202_ == 0)
{
v___x_2108_ = v___x_2105_;
v_isShared_2109_ = v_isSharedCheck_2202_;
goto v_resetjp_2107_;
}
else
{
lean_inc(v_val_2106_);
lean_dec(v___x_2105_);
v___x_2108_ = lean_box(0);
v_isShared_2109_ = v_isSharedCheck_2202_;
goto v_resetjp_2107_;
}
v_resetjp_2107_:
{
if (lean_obj_tag(v_val_2106_) == 1)
{
uint8_t v_b_2110_; lean_object* v_nameMap_2111_; lean_object* v_a_2112_; lean_object* v___x_2113_; 
v_b_2110_ = lean_ctor_get_uint8(v_val_2106_, 0);
lean_dec_ref_known(v_val_2106_, 0);
v_nameMap_2111_ = lean_ctor_get(v_a_2065_, 1);
v_a_2112_ = lean_nat_abs(v_mantissa_2083_);
lean_dec(v_mantissa_2083_);
v___x_2113_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_2111_, v_a_2112_);
if (lean_obj_tag(v___x_2113_) == 1)
{
lean_object* v_val_2114_; lean_object* v___x_2116_; uint8_t v_isShared_2117_; uint8_t v_isSharedCheck_2192_; 
lean_dec(v_a_2112_);
lean_del_object(v___x_2108_);
lean_del_object(v___x_2098_);
v_val_2114_ = lean_ctor_get(v___x_2113_, 0);
v_isSharedCheck_2192_ = !lean_is_exclusive(v___x_2113_);
if (v_isSharedCheck_2192_ == 0)
{
v___x_2116_ = v___x_2113_;
v_isShared_2117_ = v_isSharedCheck_2192_;
goto v_resetjp_2115_;
}
else
{
lean_inc(v_val_2114_);
lean_dec(v___x_2113_);
v___x_2116_ = lean_box(0);
v_isShared_2117_ = v_isSharedCheck_2192_;
goto v_resetjp_2115_;
}
v_resetjp_2115_:
{
lean_object* v___x_2118_; 
v___x_2118_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2092_, v_a_2065_);
if (lean_obj_tag(v___x_2118_) == 0)
{
lean_object* v_a_2119_; lean_object* v___x_2121_; uint8_t v_isShared_2122_; uint8_t v_isSharedCheck_2183_; 
v_a_2119_ = lean_ctor_get(v___x_2118_, 0);
v_isSharedCheck_2183_ = !lean_is_exclusive(v___x_2118_);
if (v_isSharedCheck_2183_ == 0)
{
v___x_2121_ = v___x_2118_;
v_isShared_2122_ = v_isSharedCheck_2183_;
goto v_resetjp_2120_;
}
else
{
lean_inc(v_a_2119_);
lean_dec(v___x_2118_);
v___x_2121_ = lean_box(0);
v_isShared_2122_ = v_isSharedCheck_2183_;
goto v_resetjp_2120_;
}
v_resetjp_2120_:
{
lean_object* v_snd_2123_; lean_object* v_fst_2124_; lean_object* v___x_2126_; uint8_t v_isShared_2127_; uint8_t v_isSharedCheck_2182_; 
v_snd_2123_ = lean_ctor_get(v_a_2119_, 1);
v_fst_2124_ = lean_ctor_get(v_a_2119_, 0);
v_isSharedCheck_2182_ = !lean_is_exclusive(v_a_2119_);
if (v_isSharedCheck_2182_ == 0)
{
v___x_2126_ = v_a_2119_;
v_isShared_2127_ = v_isSharedCheck_2182_;
goto v_resetjp_2125_;
}
else
{
lean_inc(v_snd_2123_);
lean_inc(v_fst_2124_);
lean_dec(v_a_2119_);
v___x_2126_ = lean_box(0);
v_isShared_2127_ = v_isSharedCheck_2182_;
goto v_resetjp_2125_;
}
v_resetjp_2125_:
{
lean_object* v_stream_2128_; lean_object* v_nameMap_2129_; lean_object* v_levelMap_2130_; lean_object* v_exprMap_2131_; lean_object* v_recursorRuleMap_2132_; lean_object* v_constMap_2133_; lean_object* v_constOrder_2134_; lean_object* v___x_2136_; uint8_t v_isShared_2137_; uint8_t v_isSharedCheck_2181_; 
v_stream_2128_ = lean_ctor_get(v_snd_2123_, 0);
v_nameMap_2129_ = lean_ctor_get(v_snd_2123_, 1);
v_levelMap_2130_ = lean_ctor_get(v_snd_2123_, 2);
v_exprMap_2131_ = lean_ctor_get(v_snd_2123_, 3);
v_recursorRuleMap_2132_ = lean_ctor_get(v_snd_2123_, 4);
v_constMap_2133_ = lean_ctor_get(v_snd_2123_, 5);
v_constOrder_2134_ = lean_ctor_get(v_snd_2123_, 6);
v_isSharedCheck_2181_ = !lean_is_exclusive(v_snd_2123_);
if (v_isSharedCheck_2181_ == 0)
{
v___x_2136_ = v_snd_2123_;
v_isShared_2137_ = v_isSharedCheck_2181_;
goto v_resetjp_2135_;
}
else
{
lean_inc(v_constOrder_2134_);
lean_inc(v_constMap_2133_);
lean_inc(v_recursorRuleMap_2132_);
lean_inc(v_exprMap_2131_);
lean_inc(v_levelMap_2130_);
lean_inc(v_nameMap_2129_);
lean_inc(v_stream_2128_);
lean_dec(v_snd_2123_);
v___x_2136_ = lean_box(0);
v_isShared_2137_ = v_isSharedCheck_2181_;
goto v_resetjp_2135_;
}
v_resetjp_2135_:
{
lean_object* v_a_2138_; lean_object* v___x_2139_; 
v_a_2138_ = lean_nat_abs(v_mantissa_2100_);
lean_dec(v_mantissa_2100_);
v___x_2139_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2131_, v_a_2138_);
if (lean_obj_tag(v___x_2139_) == 1)
{
lean_object* v_val_2140_; lean_object* v___x_2142_; uint8_t v_isShared_2143_; uint8_t v_isSharedCheck_2171_; 
lean_dec(v_a_2138_);
lean_del_object(v___x_2116_);
v_val_2140_ = lean_ctor_get(v___x_2139_, 0);
v_isSharedCheck_2171_ = !lean_is_exclusive(v___x_2139_);
if (v_isSharedCheck_2171_ == 0)
{
v___x_2142_ = v___x_2139_;
v_isShared_2143_ = v_isSharedCheck_2171_;
goto v_resetjp_2141_;
}
else
{
lean_inc(v_val_2140_);
lean_dec(v___x_2139_);
v___x_2142_ = lean_box(0);
v_isShared_2143_ = v_isSharedCheck_2171_;
goto v_resetjp_2141_;
}
v_resetjp_2141_:
{
uint8_t v___x_2144_; 
v___x_2144_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_2133_, v_val_2114_);
if (v___x_2144_ == 0)
{
lean_object* v___x_2145_; lean_object* v___x_2146_; lean_object* v___x_2148_; 
lean_inc(v_val_2114_);
v___x_2145_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2145_, 0, v_val_2114_);
lean_ctor_set(v___x_2145_, 1, v_fst_2124_);
lean_ctor_set(v___x_2145_, 2, v_val_2140_);
v___x_2146_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2146_, 0, v___x_2145_);
lean_ctor_set_uint8(v___x_2146_, sizeof(void*)*1, v_b_2110_);
if (v_isShared_2143_ == 0)
{
lean_ctor_set_tag(v___x_2142_, 0);
lean_ctor_set(v___x_2142_, 0, v___x_2146_);
v___x_2148_ = v___x_2142_;
goto v_reusejp_2147_;
}
else
{
lean_object* v_reuseFailAlloc_2161_; 
v_reuseFailAlloc_2161_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2161_, 0, v___x_2146_);
v___x_2148_ = v_reuseFailAlloc_2161_;
goto v_reusejp_2147_;
}
v_reusejp_2147_:
{
lean_object* v___x_2149_; lean_object* v___x_2150_; lean_object* v___x_2151_; lean_object* v___x_2153_; 
v___x_2149_ = lean_box(0);
lean_inc(v_val_2114_);
v___x_2150_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_2133_, v_val_2114_, v___x_2148_);
v___x_2151_ = lean_array_push(v_constOrder_2134_, v_val_2114_);
if (v_isShared_2137_ == 0)
{
lean_ctor_set(v___x_2136_, 6, v___x_2151_);
lean_ctor_set(v___x_2136_, 5, v___x_2150_);
v___x_2153_ = v___x_2136_;
goto v_reusejp_2152_;
}
else
{
lean_object* v_reuseFailAlloc_2160_; 
v_reuseFailAlloc_2160_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_2160_, 0, v_stream_2128_);
lean_ctor_set(v_reuseFailAlloc_2160_, 1, v_nameMap_2129_);
lean_ctor_set(v_reuseFailAlloc_2160_, 2, v_levelMap_2130_);
lean_ctor_set(v_reuseFailAlloc_2160_, 3, v_exprMap_2131_);
lean_ctor_set(v_reuseFailAlloc_2160_, 4, v_recursorRuleMap_2132_);
lean_ctor_set(v_reuseFailAlloc_2160_, 5, v___x_2150_);
lean_ctor_set(v_reuseFailAlloc_2160_, 6, v___x_2151_);
v___x_2153_ = v_reuseFailAlloc_2160_;
goto v_reusejp_2152_;
}
v_reusejp_2152_:
{
lean_object* v___x_2155_; 
if (v_isShared_2127_ == 0)
{
lean_ctor_set(v___x_2126_, 1, v___x_2153_);
lean_ctor_set(v___x_2126_, 0, v___x_2149_);
v___x_2155_ = v___x_2126_;
goto v_reusejp_2154_;
}
else
{
lean_object* v_reuseFailAlloc_2159_; 
v_reuseFailAlloc_2159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2159_, 0, v___x_2149_);
lean_ctor_set(v_reuseFailAlloc_2159_, 1, v___x_2153_);
v___x_2155_ = v_reuseFailAlloc_2159_;
goto v_reusejp_2154_;
}
v_reusejp_2154_:
{
lean_object* v___x_2157_; 
if (v_isShared_2122_ == 0)
{
lean_ctor_set(v___x_2121_, 0, v___x_2155_);
v___x_2157_ = v___x_2121_;
goto v_reusejp_2156_;
}
else
{
lean_object* v_reuseFailAlloc_2158_; 
v_reuseFailAlloc_2158_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2158_, 0, v___x_2155_);
v___x_2157_ = v_reuseFailAlloc_2158_;
goto v_reusejp_2156_;
}
v_reusejp_2156_:
{
return v___x_2157_;
}
}
}
}
}
else
{
lean_object* v___x_2162_; lean_object* v___x_2163_; lean_object* v___x_2164_; lean_object* v___x_2166_; 
lean_dec(v_val_2140_);
lean_del_object(v___x_2136_);
lean_dec_ref(v_constOrder_2134_);
lean_dec_ref(v_constMap_2133_);
lean_dec_ref(v_recursorRuleMap_2132_);
lean_dec_ref(v_exprMap_2131_);
lean_dec_ref(v_levelMap_2130_);
lean_dec_ref(v_nameMap_2129_);
lean_dec_ref(v_stream_2128_);
lean_del_object(v___x_2126_);
lean_dec(v_fst_2124_);
v___x_2162_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_2163_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_2114_, v___x_2144_);
v___x_2164_ = lean_string_append(v___x_2162_, v___x_2163_);
lean_dec_ref(v___x_2163_);
if (v_isShared_2143_ == 0)
{
lean_ctor_set_tag(v___x_2142_, 18);
lean_ctor_set(v___x_2142_, 0, v___x_2164_);
v___x_2166_ = v___x_2142_;
goto v_reusejp_2165_;
}
else
{
lean_object* v_reuseFailAlloc_2170_; 
v_reuseFailAlloc_2170_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2170_, 0, v___x_2164_);
v___x_2166_ = v_reuseFailAlloc_2170_;
goto v_reusejp_2165_;
}
v_reusejp_2165_:
{
lean_object* v___x_2168_; 
if (v_isShared_2122_ == 0)
{
lean_ctor_set_tag(v___x_2121_, 1);
lean_ctor_set(v___x_2121_, 0, v___x_2166_);
v___x_2168_ = v___x_2121_;
goto v_reusejp_2167_;
}
else
{
lean_object* v_reuseFailAlloc_2169_; 
v_reuseFailAlloc_2169_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2169_, 0, v___x_2166_);
v___x_2168_ = v_reuseFailAlloc_2169_;
goto v_reusejp_2167_;
}
v_reusejp_2167_:
{
return v___x_2168_;
}
}
}
}
}
else
{
lean_object* v___x_2172_; lean_object* v___x_2173_; lean_object* v___x_2174_; lean_object* v___x_2176_; 
lean_dec(v___x_2139_);
lean_del_object(v___x_2136_);
lean_dec_ref(v_constOrder_2134_);
lean_dec_ref(v_constMap_2133_);
lean_dec_ref(v_recursorRuleMap_2132_);
lean_dec_ref(v_exprMap_2131_);
lean_dec_ref(v_levelMap_2130_);
lean_dec_ref(v_nameMap_2129_);
lean_dec_ref(v_stream_2128_);
lean_del_object(v___x_2126_);
lean_dec(v_fst_2124_);
lean_dec(v_val_2114_);
v___x_2172_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2173_ = l_Nat_reprFast(v_a_2138_);
v___x_2174_ = lean_string_append(v___x_2172_, v___x_2173_);
lean_dec_ref(v___x_2173_);
if (v_isShared_2117_ == 0)
{
lean_ctor_set_tag(v___x_2116_, 18);
lean_ctor_set(v___x_2116_, 0, v___x_2174_);
v___x_2176_ = v___x_2116_;
goto v_reusejp_2175_;
}
else
{
lean_object* v_reuseFailAlloc_2180_; 
v_reuseFailAlloc_2180_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2180_, 0, v___x_2174_);
v___x_2176_ = v_reuseFailAlloc_2180_;
goto v_reusejp_2175_;
}
v_reusejp_2175_:
{
lean_object* v___x_2178_; 
if (v_isShared_2122_ == 0)
{
lean_ctor_set_tag(v___x_2121_, 1);
lean_ctor_set(v___x_2121_, 0, v___x_2176_);
v___x_2178_ = v___x_2121_;
goto v_reusejp_2177_;
}
else
{
lean_object* v_reuseFailAlloc_2179_; 
v_reuseFailAlloc_2179_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2179_, 0, v___x_2176_);
v___x_2178_ = v_reuseFailAlloc_2179_;
goto v_reusejp_2177_;
}
v_reusejp_2177_:
{
return v___x_2178_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_2184_; lean_object* v___x_2186_; uint8_t v_isShared_2187_; uint8_t v_isSharedCheck_2191_; 
lean_del_object(v___x_2116_);
lean_dec(v_val_2114_);
lean_dec(v_mantissa_2100_);
v_a_2184_ = lean_ctor_get(v___x_2118_, 0);
v_isSharedCheck_2191_ = !lean_is_exclusive(v___x_2118_);
if (v_isSharedCheck_2191_ == 0)
{
v___x_2186_ = v___x_2118_;
v_isShared_2187_ = v_isSharedCheck_2191_;
goto v_resetjp_2185_;
}
else
{
lean_inc(v_a_2184_);
lean_dec(v___x_2118_);
v___x_2186_ = lean_box(0);
v_isShared_2187_ = v_isSharedCheck_2191_;
goto v_resetjp_2185_;
}
v_resetjp_2185_:
{
lean_object* v___x_2189_; 
if (v_isShared_2187_ == 0)
{
v___x_2189_ = v___x_2186_;
goto v_reusejp_2188_;
}
else
{
lean_object* v_reuseFailAlloc_2190_; 
v_reuseFailAlloc_2190_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2190_, 0, v_a_2184_);
v___x_2189_ = v_reuseFailAlloc_2190_;
goto v_reusejp_2188_;
}
v_reusejp_2188_:
{
return v___x_2189_;
}
}
}
}
}
else
{
lean_object* v___x_2193_; lean_object* v___x_2194_; lean_object* v___x_2195_; lean_object* v___x_2197_; 
lean_dec(v___x_2113_);
lean_dec(v_mantissa_2100_);
lean_dec_ref(v_elems_2092_);
lean_dec_ref(v_a_2065_);
v___x_2193_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_2194_ = l_Nat_reprFast(v_a_2112_);
v___x_2195_ = lean_string_append(v___x_2193_, v___x_2194_);
lean_dec_ref(v___x_2194_);
if (v_isShared_2109_ == 0)
{
lean_ctor_set_tag(v___x_2108_, 18);
lean_ctor_set(v___x_2108_, 0, v___x_2195_);
v___x_2197_ = v___x_2108_;
goto v_reusejp_2196_;
}
else
{
lean_object* v_reuseFailAlloc_2201_; 
v_reuseFailAlloc_2201_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2201_, 0, v___x_2195_);
v___x_2197_ = v_reuseFailAlloc_2201_;
goto v_reusejp_2196_;
}
v_reusejp_2196_:
{
lean_object* v___x_2199_; 
if (v_isShared_2099_ == 0)
{
lean_ctor_set_tag(v___x_2098_, 1);
lean_ctor_set(v___x_2098_, 0, v___x_2197_);
v___x_2199_ = v___x_2098_;
goto v_reusejp_2198_;
}
else
{
lean_object* v_reuseFailAlloc_2200_; 
v_reuseFailAlloc_2200_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2200_, 0, v___x_2197_);
v___x_2199_ = v_reuseFailAlloc_2200_;
goto v_reusejp_2198_;
}
v_reusejp_2198_:
{
return v___x_2199_;
}
}
}
}
else
{
lean_del_object(v___x_2108_);
lean_dec(v_val_2106_);
lean_dec(v_mantissa_2100_);
lean_del_object(v___x_2098_);
lean_dec_ref(v_elems_2092_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2076_;
}
}
}
else
{
lean_dec(v___x_2105_);
lean_dec(v_mantissa_2100_);
lean_del_object(v___x_2098_);
lean_dec_ref(v_elems_2092_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2076_;
}
}
}
else
{
lean_dec(v_exponent_2101_);
lean_dec(v_mantissa_2100_);
lean_del_object(v___x_2098_);
lean_dec_ref(v_elems_2092_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2073_;
}
}
}
else
{
lean_dec(v_val_2095_);
lean_dec_ref(v_elems_2092_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2073_;
}
}
else
{
lean_dec(v___x_2094_);
lean_dec_ref(v_elems_2092_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2073_;
}
}
else
{
lean_dec(v_val_2091_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2070_;
}
}
else
{
lean_dec(v___x_2090_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2070_;
}
}
}
else
{
lean_dec(v_exponent_2084_);
lean_dec(v_mantissa_2083_);
lean_dec_ref(v_a_2065_);
goto v___jp_2067_;
}
}
else
{
lean_dec(v_val_2081_);
lean_dec_ref(v_a_2065_);
goto v___jp_2067_;
}
}
else
{
lean_dec(v___x_2080_);
lean_dec_ref(v_a_2065_);
goto v___jp_2067_;
}
v___jp_2067_:
{
lean_object* v___x_2068_; lean_object* v___x_2069_; 
v___x_2068_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1));
v___x_2069_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2069_, 0, v___x_2068_);
return v___x_2069_;
}
v___jp_2070_:
{
lean_object* v___x_2071_; lean_object* v___x_2072_; 
v___x_2071_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1));
v___x_2072_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2072_, 0, v___x_2071_);
return v___x_2072_;
}
v___jp_2073_:
{
lean_object* v___x_2074_; lean_object* v___x_2075_; 
v___x_2074_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1));
v___x_2075_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2075_, 0, v___x_2074_);
return v___x_2075_;
}
v___jp_2076_:
{
lean_object* v___x_2077_; lean_object* v___x_2078_; 
v___x_2077_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1));
v___x_2078_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2078_, 0, v___x_2077_);
return v___x_2078_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseAxiomInfo___boxed(lean_object* v_data_2204_, lean_object* v_a_2205_, lean_object* v_a_2206_){
_start:
{
lean_object* v_res_2207_; 
v_res_2207_ = lp_proofEnvironment_Export_Parse_parseAxiomInfo(v_data_2204_, v_a_2205_);
lean_dec(v_data_2204_);
return v_res_2207_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo(lean_object* v_data_2221_, lean_object* v_a_2222_){
_start:
{
lean_object* v___x_2248_; lean_object* v___x_2249_; 
v___x_2248_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_2249_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2248_);
if (lean_obj_tag(v___x_2249_) == 1)
{
lean_object* v_val_2250_; 
v_val_2250_ = lean_ctor_get(v___x_2249_, 0);
lean_inc(v_val_2250_);
lean_dec_ref_known(v___x_2249_, 1);
if (lean_obj_tag(v_val_2250_) == 2)
{
lean_object* v_n_2251_; lean_object* v_mantissa_2252_; lean_object* v_exponent_2253_; lean_object* v_natZero_2254_; lean_object* v_intZero_2255_; uint8_t v_isNeg_2256_; 
v_n_2251_ = lean_ctor_get(v_val_2250_, 0);
lean_inc_ref(v_n_2251_);
lean_dec_ref_known(v_val_2250_, 1);
v_mantissa_2252_ = lean_ctor_get(v_n_2251_, 0);
lean_inc(v_mantissa_2252_);
v_exponent_2253_ = lean_ctor_get(v_n_2251_, 1);
lean_inc(v_exponent_2253_);
lean_dec_ref(v_n_2251_);
v_natZero_2254_ = lean_unsigned_to_nat(0u);
v_intZero_2255_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_2256_ = lean_int_dec_lt(v_mantissa_2252_, v_intZero_2255_);
if (v_isNeg_2256_ == 0)
{
uint8_t v___x_2257_; 
v___x_2257_ = lean_nat_dec_eq(v_exponent_2253_, v_natZero_2254_);
lean_dec(v_exponent_2253_);
if (v___x_2257_ == 0)
{
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2224_;
}
else
{
lean_object* v___x_2258_; lean_object* v___x_2259_; 
v___x_2258_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_2259_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2258_);
if (lean_obj_tag(v___x_2259_) == 1)
{
lean_object* v_val_2260_; 
v_val_2260_ = lean_ctor_get(v___x_2259_, 0);
lean_inc(v_val_2260_);
lean_dec_ref_known(v___x_2259_, 1);
if (lean_obj_tag(v_val_2260_) == 4)
{
lean_object* v_elems_2261_; lean_object* v___x_2262_; lean_object* v___x_2263_; 
v_elems_2261_ = lean_ctor_get(v_val_2260_, 0);
lean_inc_ref(v_elems_2261_);
lean_dec_ref_known(v_val_2260_, 1);
v___x_2262_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_2263_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2262_);
if (lean_obj_tag(v___x_2263_) == 1)
{
lean_object* v_val_2264_; 
v_val_2264_ = lean_ctor_get(v___x_2263_, 0);
lean_inc(v_val_2264_);
lean_dec_ref_known(v___x_2263_, 1);
if (lean_obj_tag(v_val_2264_) == 2)
{
lean_object* v_n_2265_; lean_object* v_mantissa_2266_; lean_object* v_exponent_2267_; uint8_t v_isNeg_2268_; 
v_n_2265_ = lean_ctor_get(v_val_2264_, 0);
lean_inc_ref(v_n_2265_);
lean_dec_ref_known(v_val_2264_, 1);
v_mantissa_2266_ = lean_ctor_get(v_n_2265_, 0);
lean_inc(v_mantissa_2266_);
v_exponent_2267_ = lean_ctor_get(v_n_2265_, 1);
lean_inc(v_exponent_2267_);
lean_dec_ref(v_n_2265_);
v_isNeg_2268_ = lean_int_dec_lt(v_mantissa_2266_, v_intZero_2255_);
if (v_isNeg_2268_ == 0)
{
uint8_t v___x_2269_; 
v___x_2269_ = lean_nat_dec_eq(v_exponent_2267_, v_natZero_2254_);
lean_dec(v_exponent_2267_);
if (v___x_2269_ == 0)
{
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2230_;
}
else
{
lean_object* v___x_2270_; lean_object* v___x_2271_; 
v___x_2270_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2));
v___x_2271_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2270_);
if (lean_obj_tag(v___x_2271_) == 1)
{
lean_object* v_val_2272_; 
v_val_2272_ = lean_ctor_get(v___x_2271_, 0);
lean_inc(v_val_2272_);
lean_dec_ref_known(v___x_2271_, 1);
if (lean_obj_tag(v_val_2272_) == 2)
{
lean_object* v_n_2273_; lean_object* v___x_2275_; uint8_t v_isShared_2276_; uint8_t v_isSharedCheck_2471_; 
v_n_2273_ = lean_ctor_get(v_val_2272_, 0);
v_isSharedCheck_2471_ = !lean_is_exclusive(v_val_2272_);
if (v_isSharedCheck_2471_ == 0)
{
v___x_2275_ = v_val_2272_;
v_isShared_2276_ = v_isSharedCheck_2471_;
goto v_resetjp_2274_;
}
else
{
lean_inc(v_n_2273_);
lean_dec(v_val_2272_);
v___x_2275_ = lean_box(0);
v_isShared_2276_ = v_isSharedCheck_2471_;
goto v_resetjp_2274_;
}
v_resetjp_2274_:
{
lean_object* v_mantissa_2277_; lean_object* v_exponent_2278_; uint8_t v_isNeg_2279_; 
v_mantissa_2277_ = lean_ctor_get(v_n_2273_, 0);
lean_inc(v_mantissa_2277_);
v_exponent_2278_ = lean_ctor_get(v_n_2273_, 1);
lean_inc(v_exponent_2278_);
lean_dec_ref(v_n_2273_);
v_isNeg_2279_ = lean_int_dec_lt(v_mantissa_2277_, v_intZero_2255_);
if (v_isNeg_2279_ == 0)
{
uint8_t v___x_2280_; 
v___x_2280_ = lean_nat_dec_eq(v_exponent_2278_, v_natZero_2254_);
lean_dec(v_exponent_2278_);
if (v___x_2280_ == 0)
{
lean_dec(v_mantissa_2277_);
lean_del_object(v___x_2275_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2233_;
}
else
{
lean_object* v___x_2281_; lean_object* v___x_2282_; 
v___x_2281_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__2));
v___x_2282_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2281_);
if (lean_obj_tag(v___x_2282_) == 1)
{
lean_object* v_val_2283_; lean_object* v___x_2284_; lean_object* v___x_2285_; 
lean_del_object(v___x_2275_);
v_val_2283_ = lean_ctor_get(v___x_2282_, 0);
lean_inc(v_val_2283_);
lean_dec_ref_known(v___x_2282_, 1);
v___x_2284_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__3));
v___x_2285_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2284_);
if (lean_obj_tag(v___x_2285_) == 1)
{
lean_object* v_val_2286_; 
v_val_2286_ = lean_ctor_get(v___x_2285_, 0);
lean_inc(v_val_2286_);
lean_dec_ref_known(v___x_2285_, 1);
if (lean_obj_tag(v_val_2286_) == 3)
{
lean_object* v_s_2287_; lean_object* v___x_2288_; lean_object* v___x_2289_; 
v_s_2287_ = lean_ctor_get(v_val_2286_, 0);
lean_inc_ref(v_s_2287_);
lean_dec_ref_known(v_val_2286_, 1);
v___x_2288_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4));
v___x_2289_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2221_, v___x_2288_);
if (lean_obj_tag(v___x_2289_) == 1)
{
lean_object* v_val_2290_; lean_object* v___x_2292_; uint8_t v_isShared_2293_; uint8_t v_isSharedCheck_2466_; 
v_val_2290_ = lean_ctor_get(v___x_2289_, 0);
v_isSharedCheck_2466_ = !lean_is_exclusive(v___x_2289_);
if (v_isSharedCheck_2466_ == 0)
{
v___x_2292_ = v___x_2289_;
v_isShared_2293_ = v_isSharedCheck_2466_;
goto v_resetjp_2291_;
}
else
{
lean_inc(v_val_2290_);
lean_dec(v___x_2289_);
v___x_2292_ = lean_box(0);
v_isShared_2293_ = v_isSharedCheck_2466_;
goto v_resetjp_2291_;
}
v_resetjp_2291_:
{
if (lean_obj_tag(v_val_2290_) == 4)
{
lean_object* v_elems_2294_; lean_object* v___x_2296_; uint8_t v_isShared_2297_; uint8_t v_isSharedCheck_2465_; 
v_elems_2294_ = lean_ctor_get(v_val_2290_, 0);
v_isSharedCheck_2465_ = !lean_is_exclusive(v_val_2290_);
if (v_isSharedCheck_2465_ == 0)
{
v___x_2296_ = v_val_2290_;
v_isShared_2297_ = v_isSharedCheck_2465_;
goto v_resetjp_2295_;
}
else
{
lean_inc(v_elems_2294_);
lean_dec(v_val_2290_);
v___x_2296_ = lean_box(0);
v_isShared_2297_ = v_isSharedCheck_2465_;
goto v_resetjp_2295_;
}
v_resetjp_2295_:
{
lean_object* v_nameMap_2298_; lean_object* v_a_2299_; lean_object* v___x_2300_; 
v_nameMap_2298_ = lean_ctor_get(v_a_2222_, 1);
v_a_2299_ = lean_nat_abs(v_mantissa_2252_);
lean_dec(v_mantissa_2252_);
v___x_2300_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_2298_, v_a_2299_);
if (lean_obj_tag(v___x_2300_) == 1)
{
lean_object* v_val_2301_; lean_object* v___x_2303_; uint8_t v_isShared_2304_; uint8_t v_isSharedCheck_2455_; 
lean_dec(v_a_2299_);
lean_del_object(v___x_2296_);
lean_del_object(v___x_2292_);
v_val_2301_ = lean_ctor_get(v___x_2300_, 0);
v_isSharedCheck_2455_ = !lean_is_exclusive(v___x_2300_);
if (v_isSharedCheck_2455_ == 0)
{
v___x_2303_ = v___x_2300_;
v_isShared_2304_ = v_isSharedCheck_2455_;
goto v_resetjp_2302_;
}
else
{
lean_inc(v_val_2301_);
lean_dec(v___x_2300_);
v___x_2303_ = lean_box(0);
v_isShared_2304_ = v_isSharedCheck_2455_;
goto v_resetjp_2302_;
}
v_resetjp_2302_:
{
lean_object* v___x_2305_; 
v___x_2305_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2261_, v_a_2222_);
if (lean_obj_tag(v___x_2305_) == 0)
{
lean_object* v_a_2306_; lean_object* v___x_2308_; uint8_t v_isShared_2309_; uint8_t v_isSharedCheck_2446_; 
v_a_2306_ = lean_ctor_get(v___x_2305_, 0);
v_isSharedCheck_2446_ = !lean_is_exclusive(v___x_2305_);
if (v_isSharedCheck_2446_ == 0)
{
v___x_2308_ = v___x_2305_;
v_isShared_2309_ = v_isSharedCheck_2446_;
goto v_resetjp_2307_;
}
else
{
lean_inc(v_a_2306_);
lean_dec(v___x_2305_);
v___x_2308_ = lean_box(0);
v_isShared_2309_ = v_isSharedCheck_2446_;
goto v_resetjp_2307_;
}
v_resetjp_2307_:
{
lean_object* v_snd_2310_; lean_object* v_fst_2311_; lean_object* v_exprMap_2312_; lean_object* v_a_2313_; lean_object* v___x_2314_; 
v_snd_2310_ = lean_ctor_get(v_a_2306_, 1);
lean_inc(v_snd_2310_);
v_fst_2311_ = lean_ctor_get(v_a_2306_, 0);
lean_inc(v_fst_2311_);
lean_dec(v_a_2306_);
v_exprMap_2312_ = lean_ctor_get(v_snd_2310_, 3);
v_a_2313_ = lean_nat_abs(v_mantissa_2266_);
lean_dec(v_mantissa_2266_);
v___x_2314_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2312_, v_a_2313_);
if (lean_obj_tag(v___x_2314_) == 1)
{
lean_object* v_val_2315_; lean_object* v___x_2317_; uint8_t v_isShared_2318_; uint8_t v_isSharedCheck_2436_; 
lean_dec(v_a_2313_);
lean_del_object(v___x_2303_);
v_val_2315_ = lean_ctor_get(v___x_2314_, 0);
v_isSharedCheck_2436_ = !lean_is_exclusive(v___x_2314_);
if (v_isSharedCheck_2436_ == 0)
{
v___x_2317_ = v___x_2314_;
v_isShared_2318_ = v_isSharedCheck_2436_;
goto v_resetjp_2316_;
}
else
{
lean_inc(v_val_2315_);
lean_dec(v___x_2314_);
v___x_2317_ = lean_box(0);
v_isShared_2318_ = v_isSharedCheck_2436_;
goto v_resetjp_2316_;
}
v_resetjp_2316_:
{
lean_object* v_a_2319_; lean_object* v___x_2320_; 
v_a_2319_ = lean_nat_abs(v_mantissa_2277_);
lean_dec(v_mantissa_2277_);
v___x_2320_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2312_, v_a_2319_);
if (lean_obj_tag(v___x_2320_) == 1)
{
lean_object* v_val_2321_; lean_object* v___x_2323_; uint8_t v_isShared_2324_; uint8_t v_isSharedCheck_2426_; 
lean_dec(v_a_2319_);
v_val_2321_ = lean_ctor_get(v___x_2320_, 0);
v_isSharedCheck_2426_ = !lean_is_exclusive(v___x_2320_);
if (v_isSharedCheck_2426_ == 0)
{
v___x_2323_ = v___x_2320_;
v_isShared_2324_ = v_isSharedCheck_2426_;
goto v_resetjp_2322_;
}
else
{
lean_inc(v_val_2321_);
lean_dec(v___x_2320_);
v___x_2323_ = lean_box(0);
v_isShared_2324_ = v_isSharedCheck_2426_;
goto v_resetjp_2322_;
}
v_resetjp_2322_:
{
lean_object* v___y_2326_; uint8_t v_safety_2327_; lean_object* v___y_2328_; lean_object* v_hints_2388_; lean_object* v___y_2389_; 
switch(lean_obj_tag(v_val_2283_))
{
case 3:
{
lean_object* v_s_2407_; lean_object* v___x_2408_; uint8_t v___x_2409_; 
v_s_2407_ = lean_ctor_get(v_val_2283_, 0);
lean_inc_ref(v_s_2407_);
lean_dec_ref_known(v_val_2283_, 1);
v___x_2408_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__9));
v___x_2409_ = lean_string_dec_eq(v_s_2407_, v___x_2408_);
if (v___x_2409_ == 0)
{
lean_object* v___x_2410_; uint8_t v___x_2411_; 
v___x_2410_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__10));
v___x_2411_ = lean_string_dec_eq(v_s_2407_, v___x_2410_);
lean_dec_ref(v_s_2407_);
if (v___x_2411_ == 0)
{
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_del_object(v___x_2317_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_del_object(v___x_2308_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
goto v___jp_2242_;
}
else
{
lean_object* v___x_2412_; 
v___x_2412_ = lean_box(1);
v_hints_2388_ = v___x_2412_;
v___y_2389_ = v_snd_2310_;
goto v___jp_2387_;
}
}
else
{
lean_object* v___x_2413_; 
lean_dec_ref(v_s_2407_);
v___x_2413_ = lean_box(0);
v_hints_2388_ = v___x_2413_;
v___y_2389_ = v_snd_2310_;
goto v___jp_2387_;
}
}
case 5:
{
lean_object* v_kvPairs_2414_; lean_object* v___x_2415_; lean_object* v___x_2416_; 
v_kvPairs_2414_ = lean_ctor_get(v_val_2283_, 0);
lean_inc(v_kvPairs_2414_);
lean_dec_ref_known(v_val_2283_, 1);
v___x_2415_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__11));
v___x_2416_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_2414_, v___x_2415_);
lean_dec(v_kvPairs_2414_);
if (lean_obj_tag(v___x_2416_) == 1)
{
lean_object* v_val_2417_; 
v_val_2417_ = lean_ctor_get(v___x_2416_, 0);
lean_inc(v_val_2417_);
lean_dec_ref_known(v___x_2416_, 1);
if (lean_obj_tag(v_val_2417_) == 2)
{
lean_object* v_n_2418_; lean_object* v_mantissa_2419_; lean_object* v_exponent_2420_; uint8_t v_isNeg_2421_; 
v_n_2418_ = lean_ctor_get(v_val_2417_, 0);
lean_inc_ref(v_n_2418_);
lean_dec_ref_known(v_val_2417_, 1);
v_mantissa_2419_ = lean_ctor_get(v_n_2418_, 0);
lean_inc(v_mantissa_2419_);
v_exponent_2420_ = lean_ctor_get(v_n_2418_, 1);
lean_inc(v_exponent_2420_);
lean_dec_ref(v_n_2418_);
v_isNeg_2421_ = lean_int_dec_lt(v_mantissa_2419_, v_intZero_2255_);
if (v_isNeg_2421_ == 0)
{
uint8_t v___x_2422_; 
v___x_2422_ = lean_nat_dec_eq(v_exponent_2420_, v_natZero_2254_);
lean_dec(v_exponent_2420_);
if (v___x_2422_ == 0)
{
lean_dec(v_mantissa_2419_);
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_del_object(v___x_2317_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_del_object(v___x_2308_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
goto v___jp_2245_;
}
else
{
lean_object* v_a_2423_; uint32_t v___x_2424_; lean_object* v___x_2425_; 
v_a_2423_ = lean_nat_abs(v_mantissa_2419_);
lean_dec(v_mantissa_2419_);
v___x_2424_ = lean_uint32_of_nat(v_a_2423_);
lean_dec(v_a_2423_);
v___x_2425_ = lean_alloc_ctor(2, 0, 4);
lean_ctor_set_uint32(v___x_2425_, 0, v___x_2424_);
v_hints_2388_ = v___x_2425_;
v___y_2389_ = v_snd_2310_;
goto v___jp_2387_;
}
}
else
{
lean_dec(v_exponent_2420_);
lean_dec(v_mantissa_2419_);
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_del_object(v___x_2317_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_del_object(v___x_2308_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
goto v___jp_2245_;
}
}
else
{
lean_dec(v_val_2417_);
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_del_object(v___x_2317_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_del_object(v___x_2308_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
goto v___jp_2245_;
}
}
else
{
lean_dec(v___x_2416_);
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_del_object(v___x_2317_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_del_object(v___x_2308_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
goto v___jp_2245_;
}
}
default: 
{
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_del_object(v___x_2317_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_del_object(v___x_2308_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
goto v___jp_2242_;
}
}
v___jp_2325_:
{
lean_object* v___x_2329_; 
v___x_2329_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2294_, v___y_2328_);
if (lean_obj_tag(v___x_2329_) == 0)
{
lean_object* v_a_2330_; lean_object* v___x_2332_; uint8_t v_isShared_2333_; uint8_t v_isSharedCheck_2378_; 
v_a_2330_ = lean_ctor_get(v___x_2329_, 0);
v_isSharedCheck_2378_ = !lean_is_exclusive(v___x_2329_);
if (v_isSharedCheck_2378_ == 0)
{
v___x_2332_ = v___x_2329_;
v_isShared_2333_ = v_isSharedCheck_2378_;
goto v_resetjp_2331_;
}
else
{
lean_inc(v_a_2330_);
lean_dec(v___x_2329_);
v___x_2332_ = lean_box(0);
v_isShared_2333_ = v_isSharedCheck_2378_;
goto v_resetjp_2331_;
}
v_resetjp_2331_:
{
lean_object* v_snd_2334_; lean_object* v_fst_2335_; lean_object* v___x_2337_; uint8_t v_isShared_2338_; uint8_t v_isSharedCheck_2377_; 
v_snd_2334_ = lean_ctor_get(v_a_2330_, 1);
v_fst_2335_ = lean_ctor_get(v_a_2330_, 0);
v_isSharedCheck_2377_ = !lean_is_exclusive(v_a_2330_);
if (v_isSharedCheck_2377_ == 0)
{
v___x_2337_ = v_a_2330_;
v_isShared_2338_ = v_isSharedCheck_2377_;
goto v_resetjp_2336_;
}
else
{
lean_inc(v_snd_2334_);
lean_inc(v_fst_2335_);
lean_dec(v_a_2330_);
v___x_2337_ = lean_box(0);
v_isShared_2338_ = v_isSharedCheck_2377_;
goto v_resetjp_2336_;
}
v_resetjp_2336_:
{
lean_object* v_stream_2339_; lean_object* v_nameMap_2340_; lean_object* v_levelMap_2341_; lean_object* v_exprMap_2342_; lean_object* v_recursorRuleMap_2343_; lean_object* v_constMap_2344_; lean_object* v_constOrder_2345_; lean_object* v___x_2347_; uint8_t v_isShared_2348_; uint8_t v_isSharedCheck_2376_; 
v_stream_2339_ = lean_ctor_get(v_snd_2334_, 0);
v_nameMap_2340_ = lean_ctor_get(v_snd_2334_, 1);
v_levelMap_2341_ = lean_ctor_get(v_snd_2334_, 2);
v_exprMap_2342_ = lean_ctor_get(v_snd_2334_, 3);
v_recursorRuleMap_2343_ = lean_ctor_get(v_snd_2334_, 4);
v_constMap_2344_ = lean_ctor_get(v_snd_2334_, 5);
v_constOrder_2345_ = lean_ctor_get(v_snd_2334_, 6);
v_isSharedCheck_2376_ = !lean_is_exclusive(v_snd_2334_);
if (v_isSharedCheck_2376_ == 0)
{
v___x_2347_ = v_snd_2334_;
v_isShared_2348_ = v_isSharedCheck_2376_;
goto v_resetjp_2346_;
}
else
{
lean_inc(v_constOrder_2345_);
lean_inc(v_constMap_2344_);
lean_inc(v_recursorRuleMap_2343_);
lean_inc(v_exprMap_2342_);
lean_inc(v_levelMap_2341_);
lean_inc(v_nameMap_2340_);
lean_inc(v_stream_2339_);
lean_dec(v_snd_2334_);
v___x_2347_ = lean_box(0);
v_isShared_2348_ = v_isSharedCheck_2376_;
goto v_resetjp_2346_;
}
v_resetjp_2346_:
{
uint8_t v___x_2349_; 
v___x_2349_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_2344_, v_val_2301_);
if (v___x_2349_ == 0)
{
lean_object* v___x_2350_; lean_object* v___x_2351_; lean_object* v___x_2353_; 
lean_inc(v_val_2301_);
v___x_2350_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2350_, 0, v_val_2301_);
lean_ctor_set(v___x_2350_, 1, v_fst_2311_);
lean_ctor_set(v___x_2350_, 2, v_val_2315_);
v___x_2351_ = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(v___x_2351_, 0, v___x_2350_);
lean_ctor_set(v___x_2351_, 1, v_val_2321_);
lean_ctor_set(v___x_2351_, 2, v___y_2326_);
lean_ctor_set(v___x_2351_, 3, v_fst_2335_);
lean_ctor_set_uint8(v___x_2351_, sizeof(void*)*4, v_safety_2327_);
if (v_isShared_2324_ == 0)
{
lean_ctor_set(v___x_2323_, 0, v___x_2351_);
v___x_2353_ = v___x_2323_;
goto v_reusejp_2352_;
}
else
{
lean_object* v_reuseFailAlloc_2366_; 
v_reuseFailAlloc_2366_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2366_, 0, v___x_2351_);
v___x_2353_ = v_reuseFailAlloc_2366_;
goto v_reusejp_2352_;
}
v_reusejp_2352_:
{
lean_object* v___x_2354_; lean_object* v___x_2355_; lean_object* v___x_2356_; lean_object* v___x_2358_; 
v___x_2354_ = lean_box(0);
lean_inc(v_val_2301_);
v___x_2355_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_2344_, v_val_2301_, v___x_2353_);
v___x_2356_ = lean_array_push(v_constOrder_2345_, v_val_2301_);
if (v_isShared_2348_ == 0)
{
lean_ctor_set(v___x_2347_, 6, v___x_2356_);
lean_ctor_set(v___x_2347_, 5, v___x_2355_);
v___x_2358_ = v___x_2347_;
goto v_reusejp_2357_;
}
else
{
lean_object* v_reuseFailAlloc_2365_; 
v_reuseFailAlloc_2365_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_2365_, 0, v_stream_2339_);
lean_ctor_set(v_reuseFailAlloc_2365_, 1, v_nameMap_2340_);
lean_ctor_set(v_reuseFailAlloc_2365_, 2, v_levelMap_2341_);
lean_ctor_set(v_reuseFailAlloc_2365_, 3, v_exprMap_2342_);
lean_ctor_set(v_reuseFailAlloc_2365_, 4, v_recursorRuleMap_2343_);
lean_ctor_set(v_reuseFailAlloc_2365_, 5, v___x_2355_);
lean_ctor_set(v_reuseFailAlloc_2365_, 6, v___x_2356_);
v___x_2358_ = v_reuseFailAlloc_2365_;
goto v_reusejp_2357_;
}
v_reusejp_2357_:
{
lean_object* v___x_2360_; 
if (v_isShared_2338_ == 0)
{
lean_ctor_set(v___x_2337_, 1, v___x_2358_);
lean_ctor_set(v___x_2337_, 0, v___x_2354_);
v___x_2360_ = v___x_2337_;
goto v_reusejp_2359_;
}
else
{
lean_object* v_reuseFailAlloc_2364_; 
v_reuseFailAlloc_2364_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2364_, 0, v___x_2354_);
lean_ctor_set(v_reuseFailAlloc_2364_, 1, v___x_2358_);
v___x_2360_ = v_reuseFailAlloc_2364_;
goto v_reusejp_2359_;
}
v_reusejp_2359_:
{
lean_object* v___x_2362_; 
if (v_isShared_2333_ == 0)
{
lean_ctor_set(v___x_2332_, 0, v___x_2360_);
v___x_2362_ = v___x_2332_;
goto v_reusejp_2361_;
}
else
{
lean_object* v_reuseFailAlloc_2363_; 
v_reuseFailAlloc_2363_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2363_, 0, v___x_2360_);
v___x_2362_ = v_reuseFailAlloc_2363_;
goto v_reusejp_2361_;
}
v_reusejp_2361_:
{
return v___x_2362_;
}
}
}
}
}
else
{
lean_object* v___x_2367_; lean_object* v___x_2368_; lean_object* v___x_2369_; lean_object* v___x_2371_; 
lean_del_object(v___x_2347_);
lean_dec_ref(v_constOrder_2345_);
lean_dec_ref(v_constMap_2344_);
lean_dec_ref(v_recursorRuleMap_2343_);
lean_dec_ref(v_exprMap_2342_);
lean_dec_ref(v_levelMap_2341_);
lean_dec_ref(v_nameMap_2340_);
lean_dec_ref(v_stream_2339_);
lean_del_object(v___x_2337_);
lean_dec(v_fst_2335_);
lean_dec(v___y_2326_);
lean_dec(v_val_2321_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
v___x_2367_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_2368_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_2301_, v___x_2349_);
v___x_2369_ = lean_string_append(v___x_2367_, v___x_2368_);
lean_dec_ref(v___x_2368_);
if (v_isShared_2324_ == 0)
{
lean_ctor_set_tag(v___x_2323_, 18);
lean_ctor_set(v___x_2323_, 0, v___x_2369_);
v___x_2371_ = v___x_2323_;
goto v_reusejp_2370_;
}
else
{
lean_object* v_reuseFailAlloc_2375_; 
v_reuseFailAlloc_2375_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2375_, 0, v___x_2369_);
v___x_2371_ = v_reuseFailAlloc_2375_;
goto v_reusejp_2370_;
}
v_reusejp_2370_:
{
lean_object* v___x_2373_; 
if (v_isShared_2333_ == 0)
{
lean_ctor_set_tag(v___x_2332_, 1);
lean_ctor_set(v___x_2332_, 0, v___x_2371_);
v___x_2373_ = v___x_2332_;
goto v_reusejp_2372_;
}
else
{
lean_object* v_reuseFailAlloc_2374_; 
v_reuseFailAlloc_2374_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2374_, 0, v___x_2371_);
v___x_2373_ = v_reuseFailAlloc_2374_;
goto v_reusejp_2372_;
}
v_reusejp_2372_:
{
return v___x_2373_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_2379_; lean_object* v___x_2381_; uint8_t v_isShared_2382_; uint8_t v_isSharedCheck_2386_; 
lean_dec(v___y_2326_);
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_val_2301_);
v_a_2379_ = lean_ctor_get(v___x_2329_, 0);
v_isSharedCheck_2386_ = !lean_is_exclusive(v___x_2329_);
if (v_isSharedCheck_2386_ == 0)
{
v___x_2381_ = v___x_2329_;
v_isShared_2382_ = v_isSharedCheck_2386_;
goto v_resetjp_2380_;
}
else
{
lean_inc(v_a_2379_);
lean_dec(v___x_2329_);
v___x_2381_ = lean_box(0);
v_isShared_2382_ = v_isSharedCheck_2386_;
goto v_resetjp_2380_;
}
v_resetjp_2380_:
{
lean_object* v___x_2384_; 
if (v_isShared_2382_ == 0)
{
v___x_2384_ = v___x_2381_;
goto v_reusejp_2383_;
}
else
{
lean_object* v_reuseFailAlloc_2385_; 
v_reuseFailAlloc_2385_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2385_, 0, v_a_2379_);
v___x_2384_ = v_reuseFailAlloc_2385_;
goto v_reusejp_2383_;
}
v_reusejp_2383_:
{
return v___x_2384_;
}
}
}
}
v___jp_2387_:
{
lean_object* v___x_2390_; uint8_t v___x_2391_; 
v___x_2390_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__5));
v___x_2391_ = lean_string_dec_eq(v_s_2287_, v___x_2390_);
if (v___x_2391_ == 0)
{
lean_object* v___x_2392_; uint8_t v___x_2393_; 
v___x_2392_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__6));
v___x_2393_ = lean_string_dec_eq(v_s_2287_, v___x_2392_);
if (v___x_2393_ == 0)
{
lean_object* v___x_2394_; uint8_t v___x_2395_; 
v___x_2394_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__7));
v___x_2395_ = lean_string_dec_eq(v_s_2287_, v___x_2394_);
if (v___x_2395_ == 0)
{
lean_object* v___x_2396_; lean_object* v___x_2397_; lean_object* v___x_2399_; 
lean_dec_ref(v___y_2389_);
lean_dec(v_hints_2388_);
lean_del_object(v___x_2323_);
lean_dec(v_val_2321_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
v___x_2396_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__8));
v___x_2397_ = lean_string_append(v___x_2396_, v_s_2287_);
lean_dec_ref(v_s_2287_);
if (v_isShared_2318_ == 0)
{
lean_ctor_set_tag(v___x_2317_, 18);
lean_ctor_set(v___x_2317_, 0, v___x_2397_);
v___x_2399_ = v___x_2317_;
goto v_reusejp_2398_;
}
else
{
lean_object* v_reuseFailAlloc_2403_; 
v_reuseFailAlloc_2403_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2403_, 0, v___x_2397_);
v___x_2399_ = v_reuseFailAlloc_2403_;
goto v_reusejp_2398_;
}
v_reusejp_2398_:
{
lean_object* v___x_2401_; 
if (v_isShared_2309_ == 0)
{
lean_ctor_set_tag(v___x_2308_, 1);
lean_ctor_set(v___x_2308_, 0, v___x_2399_);
v___x_2401_ = v___x_2308_;
goto v_reusejp_2400_;
}
else
{
lean_object* v_reuseFailAlloc_2402_; 
v_reuseFailAlloc_2402_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2402_, 0, v___x_2399_);
v___x_2401_ = v_reuseFailAlloc_2402_;
goto v_reusejp_2400_;
}
v_reusejp_2400_:
{
return v___x_2401_;
}
}
}
else
{
uint8_t v___x_2404_; 
lean_del_object(v___x_2317_);
lean_del_object(v___x_2308_);
lean_dec_ref(v_s_2287_);
v___x_2404_ = 2;
v___y_2326_ = v_hints_2388_;
v_safety_2327_ = v___x_2404_;
v___y_2328_ = v___y_2389_;
goto v___jp_2325_;
}
}
else
{
uint8_t v___x_2405_; 
lean_del_object(v___x_2317_);
lean_del_object(v___x_2308_);
lean_dec_ref(v_s_2287_);
v___x_2405_ = 1;
v___y_2326_ = v_hints_2388_;
v_safety_2327_ = v___x_2405_;
v___y_2328_ = v___y_2389_;
goto v___jp_2325_;
}
}
else
{
uint8_t v___x_2406_; 
lean_del_object(v___x_2317_);
lean_del_object(v___x_2308_);
lean_dec_ref(v_s_2287_);
v___x_2406_ = 0;
v___y_2326_ = v_hints_2388_;
v_safety_2327_ = v___x_2406_;
v___y_2328_ = v___y_2389_;
goto v___jp_2325_;
}
}
}
}
else
{
lean_object* v___x_2427_; lean_object* v___x_2428_; lean_object* v___x_2429_; lean_object* v___x_2431_; 
lean_dec(v___x_2320_);
lean_dec(v_val_2315_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
v___x_2427_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2428_ = l_Nat_reprFast(v_a_2319_);
v___x_2429_ = lean_string_append(v___x_2427_, v___x_2428_);
lean_dec_ref(v___x_2428_);
if (v_isShared_2318_ == 0)
{
lean_ctor_set_tag(v___x_2317_, 18);
lean_ctor_set(v___x_2317_, 0, v___x_2429_);
v___x_2431_ = v___x_2317_;
goto v_reusejp_2430_;
}
else
{
lean_object* v_reuseFailAlloc_2435_; 
v_reuseFailAlloc_2435_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2435_, 0, v___x_2429_);
v___x_2431_ = v_reuseFailAlloc_2435_;
goto v_reusejp_2430_;
}
v_reusejp_2430_:
{
lean_object* v___x_2433_; 
if (v_isShared_2309_ == 0)
{
lean_ctor_set_tag(v___x_2308_, 1);
lean_ctor_set(v___x_2308_, 0, v___x_2431_);
v___x_2433_ = v___x_2308_;
goto v_reusejp_2432_;
}
else
{
lean_object* v_reuseFailAlloc_2434_; 
v_reuseFailAlloc_2434_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2434_, 0, v___x_2431_);
v___x_2433_ = v_reuseFailAlloc_2434_;
goto v_reusejp_2432_;
}
v_reusejp_2432_:
{
return v___x_2433_;
}
}
}
}
}
else
{
lean_object* v___x_2437_; lean_object* v___x_2438_; lean_object* v___x_2439_; lean_object* v___x_2441_; 
lean_dec(v___x_2314_);
lean_dec(v_fst_2311_);
lean_dec(v_snd_2310_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
v___x_2437_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2438_ = l_Nat_reprFast(v_a_2313_);
v___x_2439_ = lean_string_append(v___x_2437_, v___x_2438_);
lean_dec_ref(v___x_2438_);
if (v_isShared_2304_ == 0)
{
lean_ctor_set_tag(v___x_2303_, 18);
lean_ctor_set(v___x_2303_, 0, v___x_2439_);
v___x_2441_ = v___x_2303_;
goto v_reusejp_2440_;
}
else
{
lean_object* v_reuseFailAlloc_2445_; 
v_reuseFailAlloc_2445_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2445_, 0, v___x_2439_);
v___x_2441_ = v_reuseFailAlloc_2445_;
goto v_reusejp_2440_;
}
v_reusejp_2440_:
{
lean_object* v___x_2443_; 
if (v_isShared_2309_ == 0)
{
lean_ctor_set_tag(v___x_2308_, 1);
lean_ctor_set(v___x_2308_, 0, v___x_2441_);
v___x_2443_ = v___x_2308_;
goto v_reusejp_2442_;
}
else
{
lean_object* v_reuseFailAlloc_2444_; 
v_reuseFailAlloc_2444_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2444_, 0, v___x_2441_);
v___x_2443_ = v_reuseFailAlloc_2444_;
goto v_reusejp_2442_;
}
v_reusejp_2442_:
{
return v___x_2443_;
}
}
}
}
}
else
{
lean_object* v_a_2447_; lean_object* v___x_2449_; uint8_t v_isShared_2450_; uint8_t v_isSharedCheck_2454_; 
lean_del_object(v___x_2303_);
lean_dec(v_val_2301_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
v_a_2447_ = lean_ctor_get(v___x_2305_, 0);
v_isSharedCheck_2454_ = !lean_is_exclusive(v___x_2305_);
if (v_isSharedCheck_2454_ == 0)
{
v___x_2449_ = v___x_2305_;
v_isShared_2450_ = v_isSharedCheck_2454_;
goto v_resetjp_2448_;
}
else
{
lean_inc(v_a_2447_);
lean_dec(v___x_2305_);
v___x_2449_ = lean_box(0);
v_isShared_2450_ = v_isSharedCheck_2454_;
goto v_resetjp_2448_;
}
v_resetjp_2448_:
{
lean_object* v___x_2452_; 
if (v_isShared_2450_ == 0)
{
v___x_2452_ = v___x_2449_;
goto v_reusejp_2451_;
}
else
{
lean_object* v_reuseFailAlloc_2453_; 
v_reuseFailAlloc_2453_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2453_, 0, v_a_2447_);
v___x_2452_ = v_reuseFailAlloc_2453_;
goto v_reusejp_2451_;
}
v_reusejp_2451_:
{
return v___x_2452_;
}
}
}
}
}
else
{
lean_object* v___x_2456_; lean_object* v___x_2457_; lean_object* v___x_2458_; lean_object* v___x_2460_; 
lean_dec(v___x_2300_);
lean_dec_ref(v_elems_2294_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec_ref(v_a_2222_);
v___x_2456_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_2457_ = l_Nat_reprFast(v_a_2299_);
v___x_2458_ = lean_string_append(v___x_2456_, v___x_2457_);
lean_dec_ref(v___x_2457_);
if (v_isShared_2297_ == 0)
{
lean_ctor_set_tag(v___x_2296_, 18);
lean_ctor_set(v___x_2296_, 0, v___x_2458_);
v___x_2460_ = v___x_2296_;
goto v_reusejp_2459_;
}
else
{
lean_object* v_reuseFailAlloc_2464_; 
v_reuseFailAlloc_2464_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2464_, 0, v___x_2458_);
v___x_2460_ = v_reuseFailAlloc_2464_;
goto v_reusejp_2459_;
}
v_reusejp_2459_:
{
lean_object* v___x_2462_; 
if (v_isShared_2293_ == 0)
{
lean_ctor_set(v___x_2292_, 0, v___x_2460_);
v___x_2462_ = v___x_2292_;
goto v_reusejp_2461_;
}
else
{
lean_object* v_reuseFailAlloc_2463_; 
v_reuseFailAlloc_2463_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2463_, 0, v___x_2460_);
v___x_2462_ = v_reuseFailAlloc_2463_;
goto v_reusejp_2461_;
}
v_reusejp_2461_:
{
return v___x_2462_;
}
}
}
}
}
else
{
lean_del_object(v___x_2292_);
lean_dec(v_val_2290_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2239_;
}
}
}
else
{
lean_dec(v___x_2289_);
lean_dec_ref(v_s_2287_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2239_;
}
}
else
{
lean_dec(v_val_2286_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2236_;
}
}
else
{
lean_dec(v___x_2285_);
lean_dec(v_val_2283_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2236_;
}
}
else
{
lean_object* v___x_2467_; lean_object* v___x_2469_; 
lean_dec(v___x_2282_);
lean_dec(v_mantissa_2277_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
v___x_2467_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
if (v_isShared_2276_ == 0)
{
lean_ctor_set_tag(v___x_2275_, 1);
lean_ctor_set(v___x_2275_, 0, v___x_2467_);
v___x_2469_ = v___x_2275_;
goto v_reusejp_2468_;
}
else
{
lean_object* v_reuseFailAlloc_2470_; 
v_reuseFailAlloc_2470_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2470_, 0, v___x_2467_);
v___x_2469_ = v_reuseFailAlloc_2470_;
goto v_reusejp_2468_;
}
v_reusejp_2468_:
{
return v___x_2469_;
}
}
}
}
else
{
lean_dec(v_exponent_2278_);
lean_dec(v_mantissa_2277_);
lean_del_object(v___x_2275_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2233_;
}
}
}
else
{
lean_dec(v_val_2272_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2233_;
}
}
else
{
lean_dec(v___x_2271_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2233_;
}
}
}
else
{
lean_dec(v_exponent_2267_);
lean_dec(v_mantissa_2266_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2230_;
}
}
else
{
lean_dec(v_val_2264_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2230_;
}
}
else
{
lean_dec(v___x_2263_);
lean_dec_ref(v_elems_2261_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2230_;
}
}
else
{
lean_dec(v_val_2260_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2227_;
}
}
else
{
lean_dec(v___x_2259_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2227_;
}
}
}
else
{
lean_dec(v_exponent_2253_);
lean_dec(v_mantissa_2252_);
lean_dec_ref(v_a_2222_);
goto v___jp_2224_;
}
}
else
{
lean_dec(v_val_2250_);
lean_dec_ref(v_a_2222_);
goto v___jp_2224_;
}
}
else
{
lean_dec(v___x_2249_);
lean_dec_ref(v_a_2222_);
goto v___jp_2224_;
}
v___jp_2224_:
{
lean_object* v___x_2225_; lean_object* v___x_2226_; 
v___x_2225_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2226_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2226_, 0, v___x_2225_);
return v___x_2226_;
}
v___jp_2227_:
{
lean_object* v___x_2228_; lean_object* v___x_2229_; 
v___x_2228_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2229_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2229_, 0, v___x_2228_);
return v___x_2229_;
}
v___jp_2230_:
{
lean_object* v___x_2231_; lean_object* v___x_2232_; 
v___x_2231_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2232_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2232_, 0, v___x_2231_);
return v___x_2232_;
}
v___jp_2233_:
{
lean_object* v___x_2234_; lean_object* v___x_2235_; 
v___x_2234_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2235_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2235_, 0, v___x_2234_);
return v___x_2235_;
}
v___jp_2236_:
{
lean_object* v___x_2237_; lean_object* v___x_2238_; 
v___x_2237_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2238_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2238_, 0, v___x_2237_);
return v___x_2238_;
}
v___jp_2239_:
{
lean_object* v___x_2240_; lean_object* v___x_2241_; 
v___x_2240_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2241_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2241_, 0, v___x_2240_);
return v___x_2241_;
}
v___jp_2242_:
{
lean_object* v___x_2243_; lean_object* v___x_2244_; 
v___x_2243_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2244_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2244_, 0, v___x_2243_);
return v___x_2244_;
}
v___jp_2245_:
{
lean_object* v___x_2246_; lean_object* v___x_2247_; 
v___x_2246_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__1));
v___x_2247_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2247_, 0, v___x_2246_);
return v___x_2247_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseDefnInfo___boxed(lean_object* v_data_2472_, lean_object* v_a_2473_, lean_object* v_a_2474_){
_start:
{
lean_object* v_res_2475_; 
v_res_2475_ = lp_proofEnvironment_Export_Parse_parseDefnInfo(v_data_2472_, v_a_2473_);
lean_dec(v_data_2472_);
return v_res_2475_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseThmInfo(lean_object* v_data_2479_, lean_object* v_a_2480_){
_start:
{
lean_object* v___x_2497_; lean_object* v___x_2498_; 
v___x_2497_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_2498_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2479_, v___x_2497_);
if (lean_obj_tag(v___x_2498_) == 1)
{
lean_object* v_val_2499_; 
v_val_2499_ = lean_ctor_get(v___x_2498_, 0);
lean_inc(v_val_2499_);
lean_dec_ref_known(v___x_2498_, 1);
if (lean_obj_tag(v_val_2499_) == 2)
{
lean_object* v_n_2500_; lean_object* v_mantissa_2501_; lean_object* v_exponent_2502_; lean_object* v_natZero_2503_; lean_object* v_intZero_2504_; uint8_t v_isNeg_2505_; 
v_n_2500_ = lean_ctor_get(v_val_2499_, 0);
lean_inc_ref(v_n_2500_);
lean_dec_ref_known(v_val_2499_, 1);
v_mantissa_2501_ = lean_ctor_get(v_n_2500_, 0);
lean_inc(v_mantissa_2501_);
v_exponent_2502_ = lean_ctor_get(v_n_2500_, 1);
lean_inc(v_exponent_2502_);
lean_dec_ref(v_n_2500_);
v_natZero_2503_ = lean_unsigned_to_nat(0u);
v_intZero_2504_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_2505_ = lean_int_dec_lt(v_mantissa_2501_, v_intZero_2504_);
if (v_isNeg_2505_ == 0)
{
uint8_t v___x_2506_; 
v___x_2506_ = lean_nat_dec_eq(v_exponent_2502_, v_natZero_2503_);
lean_dec(v_exponent_2502_);
if (v___x_2506_ == 0)
{
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2482_;
}
else
{
lean_object* v___x_2507_; lean_object* v___x_2508_; 
v___x_2507_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_2508_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2479_, v___x_2507_);
if (lean_obj_tag(v___x_2508_) == 1)
{
lean_object* v_val_2509_; 
v_val_2509_ = lean_ctor_get(v___x_2508_, 0);
lean_inc(v_val_2509_);
lean_dec_ref_known(v___x_2508_, 1);
if (lean_obj_tag(v_val_2509_) == 4)
{
lean_object* v_elems_2510_; lean_object* v___x_2511_; lean_object* v___x_2512_; 
v_elems_2510_ = lean_ctor_get(v_val_2509_, 0);
lean_inc_ref(v_elems_2510_);
lean_dec_ref_known(v_val_2509_, 1);
v___x_2511_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_2512_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2479_, v___x_2511_);
if (lean_obj_tag(v___x_2512_) == 1)
{
lean_object* v_val_2513_; 
v_val_2513_ = lean_ctor_get(v___x_2512_, 0);
lean_inc(v_val_2513_);
lean_dec_ref_known(v___x_2512_, 1);
if (lean_obj_tag(v_val_2513_) == 2)
{
lean_object* v_n_2514_; lean_object* v_mantissa_2515_; lean_object* v_exponent_2516_; uint8_t v_isNeg_2517_; 
v_n_2514_ = lean_ctor_get(v_val_2513_, 0);
lean_inc_ref(v_n_2514_);
lean_dec_ref_known(v_val_2513_, 1);
v_mantissa_2515_ = lean_ctor_get(v_n_2514_, 0);
lean_inc(v_mantissa_2515_);
v_exponent_2516_ = lean_ctor_get(v_n_2514_, 1);
lean_inc(v_exponent_2516_);
lean_dec_ref(v_n_2514_);
v_isNeg_2517_ = lean_int_dec_lt(v_mantissa_2515_, v_intZero_2504_);
if (v_isNeg_2517_ == 0)
{
uint8_t v___x_2518_; 
v___x_2518_ = lean_nat_dec_eq(v_exponent_2516_, v_natZero_2503_);
lean_dec(v_exponent_2516_);
if (v___x_2518_ == 0)
{
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2488_;
}
else
{
lean_object* v___x_2519_; lean_object* v___x_2520_; 
v___x_2519_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2));
v___x_2520_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2479_, v___x_2519_);
if (lean_obj_tag(v___x_2520_) == 1)
{
lean_object* v_val_2521_; 
v_val_2521_ = lean_ctor_get(v___x_2520_, 0);
lean_inc(v_val_2521_);
lean_dec_ref_known(v___x_2520_, 1);
if (lean_obj_tag(v_val_2521_) == 2)
{
lean_object* v_n_2522_; lean_object* v_mantissa_2523_; lean_object* v_exponent_2524_; uint8_t v_isNeg_2525_; 
v_n_2522_ = lean_ctor_get(v_val_2521_, 0);
lean_inc_ref(v_n_2522_);
lean_dec_ref_known(v_val_2521_, 1);
v_mantissa_2523_ = lean_ctor_get(v_n_2522_, 0);
lean_inc(v_mantissa_2523_);
v_exponent_2524_ = lean_ctor_get(v_n_2522_, 1);
lean_inc(v_exponent_2524_);
lean_dec_ref(v_n_2522_);
v_isNeg_2525_ = lean_int_dec_lt(v_mantissa_2523_, v_intZero_2504_);
if (v_isNeg_2525_ == 0)
{
uint8_t v___x_2526_; 
v___x_2526_ = lean_nat_dec_eq(v_exponent_2524_, v_natZero_2503_);
lean_dec(v_exponent_2524_);
if (v___x_2526_ == 0)
{
lean_dec(v_mantissa_2523_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2491_;
}
else
{
lean_object* v___x_2527_; lean_object* v___x_2528_; 
v___x_2527_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4));
v___x_2528_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2479_, v___x_2527_);
if (lean_obj_tag(v___x_2528_) == 1)
{
lean_object* v_val_2529_; lean_object* v___x_2531_; uint8_t v_isShared_2532_; uint8_t v_isSharedCheck_2662_; 
v_val_2529_ = lean_ctor_get(v___x_2528_, 0);
v_isSharedCheck_2662_ = !lean_is_exclusive(v___x_2528_);
if (v_isSharedCheck_2662_ == 0)
{
v___x_2531_ = v___x_2528_;
v_isShared_2532_ = v_isSharedCheck_2662_;
goto v_resetjp_2530_;
}
else
{
lean_inc(v_val_2529_);
lean_dec(v___x_2528_);
v___x_2531_ = lean_box(0);
v_isShared_2532_ = v_isSharedCheck_2662_;
goto v_resetjp_2530_;
}
v_resetjp_2530_:
{
if (lean_obj_tag(v_val_2529_) == 4)
{
lean_object* v_elems_2533_; lean_object* v___x_2535_; uint8_t v_isShared_2536_; uint8_t v_isSharedCheck_2661_; 
v_elems_2533_ = lean_ctor_get(v_val_2529_, 0);
v_isSharedCheck_2661_ = !lean_is_exclusive(v_val_2529_);
if (v_isSharedCheck_2661_ == 0)
{
v___x_2535_ = v_val_2529_;
v_isShared_2536_ = v_isSharedCheck_2661_;
goto v_resetjp_2534_;
}
else
{
lean_inc(v_elems_2533_);
lean_dec(v_val_2529_);
v___x_2535_ = lean_box(0);
v_isShared_2536_ = v_isSharedCheck_2661_;
goto v_resetjp_2534_;
}
v_resetjp_2534_:
{
lean_object* v_nameMap_2537_; lean_object* v_a_2538_; lean_object* v___x_2539_; 
v_nameMap_2537_ = lean_ctor_get(v_a_2480_, 1);
v_a_2538_ = lean_nat_abs(v_mantissa_2501_);
lean_dec(v_mantissa_2501_);
v___x_2539_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_2537_, v_a_2538_);
if (lean_obj_tag(v___x_2539_) == 1)
{
lean_object* v_val_2540_; lean_object* v___x_2542_; uint8_t v_isShared_2543_; uint8_t v_isSharedCheck_2651_; 
lean_dec(v_a_2538_);
lean_del_object(v___x_2535_);
lean_del_object(v___x_2531_);
v_val_2540_ = lean_ctor_get(v___x_2539_, 0);
v_isSharedCheck_2651_ = !lean_is_exclusive(v___x_2539_);
if (v_isSharedCheck_2651_ == 0)
{
v___x_2542_ = v___x_2539_;
v_isShared_2543_ = v_isSharedCheck_2651_;
goto v_resetjp_2541_;
}
else
{
lean_inc(v_val_2540_);
lean_dec(v___x_2539_);
v___x_2542_ = lean_box(0);
v_isShared_2543_ = v_isSharedCheck_2651_;
goto v_resetjp_2541_;
}
v_resetjp_2541_:
{
lean_object* v___x_2544_; 
v___x_2544_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2510_, v_a_2480_);
if (lean_obj_tag(v___x_2544_) == 0)
{
lean_object* v_a_2545_; lean_object* v___x_2547_; uint8_t v_isShared_2548_; uint8_t v_isSharedCheck_2642_; 
v_a_2545_ = lean_ctor_get(v___x_2544_, 0);
v_isSharedCheck_2642_ = !lean_is_exclusive(v___x_2544_);
if (v_isSharedCheck_2642_ == 0)
{
v___x_2547_ = v___x_2544_;
v_isShared_2548_ = v_isSharedCheck_2642_;
goto v_resetjp_2546_;
}
else
{
lean_inc(v_a_2545_);
lean_dec(v___x_2544_);
v___x_2547_ = lean_box(0);
v_isShared_2548_ = v_isSharedCheck_2642_;
goto v_resetjp_2546_;
}
v_resetjp_2546_:
{
lean_object* v_snd_2549_; lean_object* v_fst_2550_; lean_object* v_exprMap_2551_; lean_object* v_a_2552_; lean_object* v___x_2553_; 
v_snd_2549_ = lean_ctor_get(v_a_2545_, 1);
lean_inc(v_snd_2549_);
v_fst_2550_ = lean_ctor_get(v_a_2545_, 0);
lean_inc(v_fst_2550_);
lean_dec(v_a_2545_);
v_exprMap_2551_ = lean_ctor_get(v_snd_2549_, 3);
v_a_2552_ = lean_nat_abs(v_mantissa_2515_);
lean_dec(v_mantissa_2515_);
v___x_2553_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2551_, v_a_2552_);
if (lean_obj_tag(v___x_2553_) == 1)
{
lean_object* v_val_2554_; lean_object* v___x_2556_; uint8_t v_isShared_2557_; uint8_t v_isSharedCheck_2632_; 
lean_dec(v_a_2552_);
lean_del_object(v___x_2542_);
v_val_2554_ = lean_ctor_get(v___x_2553_, 0);
v_isSharedCheck_2632_ = !lean_is_exclusive(v___x_2553_);
if (v_isSharedCheck_2632_ == 0)
{
v___x_2556_ = v___x_2553_;
v_isShared_2557_ = v_isSharedCheck_2632_;
goto v_resetjp_2555_;
}
else
{
lean_inc(v_val_2554_);
lean_dec(v___x_2553_);
v___x_2556_ = lean_box(0);
v_isShared_2557_ = v_isSharedCheck_2632_;
goto v_resetjp_2555_;
}
v_resetjp_2555_:
{
lean_object* v_a_2558_; lean_object* v___x_2559_; 
v_a_2558_ = lean_nat_abs(v_mantissa_2523_);
lean_dec(v_mantissa_2523_);
v___x_2559_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2551_, v_a_2558_);
if (lean_obj_tag(v___x_2559_) == 1)
{
lean_object* v_val_2560_; lean_object* v___x_2562_; uint8_t v_isShared_2563_; uint8_t v_isSharedCheck_2622_; 
lean_dec(v_a_2558_);
lean_del_object(v___x_2556_);
lean_del_object(v___x_2547_);
v_val_2560_ = lean_ctor_get(v___x_2559_, 0);
v_isSharedCheck_2622_ = !lean_is_exclusive(v___x_2559_);
if (v_isSharedCheck_2622_ == 0)
{
v___x_2562_ = v___x_2559_;
v_isShared_2563_ = v_isSharedCheck_2622_;
goto v_resetjp_2561_;
}
else
{
lean_inc(v_val_2560_);
lean_dec(v___x_2559_);
v___x_2562_ = lean_box(0);
v_isShared_2563_ = v_isSharedCheck_2622_;
goto v_resetjp_2561_;
}
v_resetjp_2561_:
{
lean_object* v___x_2564_; 
v___x_2564_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2533_, v_snd_2549_);
if (lean_obj_tag(v___x_2564_) == 0)
{
lean_object* v_a_2565_; lean_object* v___x_2567_; uint8_t v_isShared_2568_; uint8_t v_isSharedCheck_2613_; 
v_a_2565_ = lean_ctor_get(v___x_2564_, 0);
v_isSharedCheck_2613_ = !lean_is_exclusive(v___x_2564_);
if (v_isSharedCheck_2613_ == 0)
{
v___x_2567_ = v___x_2564_;
v_isShared_2568_ = v_isSharedCheck_2613_;
goto v_resetjp_2566_;
}
else
{
lean_inc(v_a_2565_);
lean_dec(v___x_2564_);
v___x_2567_ = lean_box(0);
v_isShared_2568_ = v_isSharedCheck_2613_;
goto v_resetjp_2566_;
}
v_resetjp_2566_:
{
lean_object* v_snd_2569_; lean_object* v_fst_2570_; lean_object* v___x_2572_; uint8_t v_isShared_2573_; uint8_t v_isSharedCheck_2612_; 
v_snd_2569_ = lean_ctor_get(v_a_2565_, 1);
v_fst_2570_ = lean_ctor_get(v_a_2565_, 0);
v_isSharedCheck_2612_ = !lean_is_exclusive(v_a_2565_);
if (v_isSharedCheck_2612_ == 0)
{
v___x_2572_ = v_a_2565_;
v_isShared_2573_ = v_isSharedCheck_2612_;
goto v_resetjp_2571_;
}
else
{
lean_inc(v_snd_2569_);
lean_inc(v_fst_2570_);
lean_dec(v_a_2565_);
v___x_2572_ = lean_box(0);
v_isShared_2573_ = v_isSharedCheck_2612_;
goto v_resetjp_2571_;
}
v_resetjp_2571_:
{
lean_object* v_stream_2574_; lean_object* v_nameMap_2575_; lean_object* v_levelMap_2576_; lean_object* v_exprMap_2577_; lean_object* v_recursorRuleMap_2578_; lean_object* v_constMap_2579_; lean_object* v_constOrder_2580_; lean_object* v___x_2582_; uint8_t v_isShared_2583_; uint8_t v_isSharedCheck_2611_; 
v_stream_2574_ = lean_ctor_get(v_snd_2569_, 0);
v_nameMap_2575_ = lean_ctor_get(v_snd_2569_, 1);
v_levelMap_2576_ = lean_ctor_get(v_snd_2569_, 2);
v_exprMap_2577_ = lean_ctor_get(v_snd_2569_, 3);
v_recursorRuleMap_2578_ = lean_ctor_get(v_snd_2569_, 4);
v_constMap_2579_ = lean_ctor_get(v_snd_2569_, 5);
v_constOrder_2580_ = lean_ctor_get(v_snd_2569_, 6);
v_isSharedCheck_2611_ = !lean_is_exclusive(v_snd_2569_);
if (v_isSharedCheck_2611_ == 0)
{
v___x_2582_ = v_snd_2569_;
v_isShared_2583_ = v_isSharedCheck_2611_;
goto v_resetjp_2581_;
}
else
{
lean_inc(v_constOrder_2580_);
lean_inc(v_constMap_2579_);
lean_inc(v_recursorRuleMap_2578_);
lean_inc(v_exprMap_2577_);
lean_inc(v_levelMap_2576_);
lean_inc(v_nameMap_2575_);
lean_inc(v_stream_2574_);
lean_dec(v_snd_2569_);
v___x_2582_ = lean_box(0);
v_isShared_2583_ = v_isSharedCheck_2611_;
goto v_resetjp_2581_;
}
v_resetjp_2581_:
{
uint8_t v___x_2584_; 
v___x_2584_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_2579_, v_val_2540_);
if (v___x_2584_ == 0)
{
lean_object* v___x_2585_; lean_object* v___x_2586_; lean_object* v___x_2588_; 
lean_inc(v_val_2540_);
v___x_2585_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2585_, 0, v_val_2540_);
lean_ctor_set(v___x_2585_, 1, v_fst_2550_);
lean_ctor_set(v___x_2585_, 2, v_val_2554_);
v___x_2586_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2586_, 0, v___x_2585_);
lean_ctor_set(v___x_2586_, 1, v_val_2560_);
lean_ctor_set(v___x_2586_, 2, v_fst_2570_);
if (v_isShared_2563_ == 0)
{
lean_ctor_set_tag(v___x_2562_, 2);
lean_ctor_set(v___x_2562_, 0, v___x_2586_);
v___x_2588_ = v___x_2562_;
goto v_reusejp_2587_;
}
else
{
lean_object* v_reuseFailAlloc_2601_; 
v_reuseFailAlloc_2601_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2601_, 0, v___x_2586_);
v___x_2588_ = v_reuseFailAlloc_2601_;
goto v_reusejp_2587_;
}
v_reusejp_2587_:
{
lean_object* v___x_2589_; lean_object* v___x_2590_; lean_object* v___x_2591_; lean_object* v___x_2593_; 
v___x_2589_ = lean_box(0);
lean_inc(v_val_2540_);
v___x_2590_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_2579_, v_val_2540_, v___x_2588_);
v___x_2591_ = lean_array_push(v_constOrder_2580_, v_val_2540_);
if (v_isShared_2583_ == 0)
{
lean_ctor_set(v___x_2582_, 6, v___x_2591_);
lean_ctor_set(v___x_2582_, 5, v___x_2590_);
v___x_2593_ = v___x_2582_;
goto v_reusejp_2592_;
}
else
{
lean_object* v_reuseFailAlloc_2600_; 
v_reuseFailAlloc_2600_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_2600_, 0, v_stream_2574_);
lean_ctor_set(v_reuseFailAlloc_2600_, 1, v_nameMap_2575_);
lean_ctor_set(v_reuseFailAlloc_2600_, 2, v_levelMap_2576_);
lean_ctor_set(v_reuseFailAlloc_2600_, 3, v_exprMap_2577_);
lean_ctor_set(v_reuseFailAlloc_2600_, 4, v_recursorRuleMap_2578_);
lean_ctor_set(v_reuseFailAlloc_2600_, 5, v___x_2590_);
lean_ctor_set(v_reuseFailAlloc_2600_, 6, v___x_2591_);
v___x_2593_ = v_reuseFailAlloc_2600_;
goto v_reusejp_2592_;
}
v_reusejp_2592_:
{
lean_object* v___x_2595_; 
if (v_isShared_2573_ == 0)
{
lean_ctor_set(v___x_2572_, 1, v___x_2593_);
lean_ctor_set(v___x_2572_, 0, v___x_2589_);
v___x_2595_ = v___x_2572_;
goto v_reusejp_2594_;
}
else
{
lean_object* v_reuseFailAlloc_2599_; 
v_reuseFailAlloc_2599_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2599_, 0, v___x_2589_);
lean_ctor_set(v_reuseFailAlloc_2599_, 1, v___x_2593_);
v___x_2595_ = v_reuseFailAlloc_2599_;
goto v_reusejp_2594_;
}
v_reusejp_2594_:
{
lean_object* v___x_2597_; 
if (v_isShared_2568_ == 0)
{
lean_ctor_set(v___x_2567_, 0, v___x_2595_);
v___x_2597_ = v___x_2567_;
goto v_reusejp_2596_;
}
else
{
lean_object* v_reuseFailAlloc_2598_; 
v_reuseFailAlloc_2598_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2598_, 0, v___x_2595_);
v___x_2597_ = v_reuseFailAlloc_2598_;
goto v_reusejp_2596_;
}
v_reusejp_2596_:
{
return v___x_2597_;
}
}
}
}
}
else
{
lean_object* v___x_2602_; lean_object* v___x_2603_; lean_object* v___x_2604_; lean_object* v___x_2606_; 
lean_del_object(v___x_2582_);
lean_dec_ref(v_constOrder_2580_);
lean_dec_ref(v_constMap_2579_);
lean_dec_ref(v_recursorRuleMap_2578_);
lean_dec_ref(v_exprMap_2577_);
lean_dec_ref(v_levelMap_2576_);
lean_dec_ref(v_nameMap_2575_);
lean_dec_ref(v_stream_2574_);
lean_del_object(v___x_2572_);
lean_dec(v_fst_2570_);
lean_dec(v_val_2560_);
lean_dec(v_val_2554_);
lean_dec(v_fst_2550_);
v___x_2602_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_2603_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_2540_, v___x_2584_);
v___x_2604_ = lean_string_append(v___x_2602_, v___x_2603_);
lean_dec_ref(v___x_2603_);
if (v_isShared_2563_ == 0)
{
lean_ctor_set_tag(v___x_2562_, 18);
lean_ctor_set(v___x_2562_, 0, v___x_2604_);
v___x_2606_ = v___x_2562_;
goto v_reusejp_2605_;
}
else
{
lean_object* v_reuseFailAlloc_2610_; 
v_reuseFailAlloc_2610_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2610_, 0, v___x_2604_);
v___x_2606_ = v_reuseFailAlloc_2610_;
goto v_reusejp_2605_;
}
v_reusejp_2605_:
{
lean_object* v___x_2608_; 
if (v_isShared_2568_ == 0)
{
lean_ctor_set_tag(v___x_2567_, 1);
lean_ctor_set(v___x_2567_, 0, v___x_2606_);
v___x_2608_ = v___x_2567_;
goto v_reusejp_2607_;
}
else
{
lean_object* v_reuseFailAlloc_2609_; 
v_reuseFailAlloc_2609_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2609_, 0, v___x_2606_);
v___x_2608_ = v_reuseFailAlloc_2609_;
goto v_reusejp_2607_;
}
v_reusejp_2607_:
{
return v___x_2608_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_2614_; lean_object* v___x_2616_; uint8_t v_isShared_2617_; uint8_t v_isSharedCheck_2621_; 
lean_del_object(v___x_2562_);
lean_dec(v_val_2560_);
lean_dec(v_val_2554_);
lean_dec(v_fst_2550_);
lean_dec(v_val_2540_);
v_a_2614_ = lean_ctor_get(v___x_2564_, 0);
v_isSharedCheck_2621_ = !lean_is_exclusive(v___x_2564_);
if (v_isSharedCheck_2621_ == 0)
{
v___x_2616_ = v___x_2564_;
v_isShared_2617_ = v_isSharedCheck_2621_;
goto v_resetjp_2615_;
}
else
{
lean_inc(v_a_2614_);
lean_dec(v___x_2564_);
v___x_2616_ = lean_box(0);
v_isShared_2617_ = v_isSharedCheck_2621_;
goto v_resetjp_2615_;
}
v_resetjp_2615_:
{
lean_object* v___x_2619_; 
if (v_isShared_2617_ == 0)
{
v___x_2619_ = v___x_2616_;
goto v_reusejp_2618_;
}
else
{
lean_object* v_reuseFailAlloc_2620_; 
v_reuseFailAlloc_2620_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2620_, 0, v_a_2614_);
v___x_2619_ = v_reuseFailAlloc_2620_;
goto v_reusejp_2618_;
}
v_reusejp_2618_:
{
return v___x_2619_;
}
}
}
}
}
else
{
lean_object* v___x_2623_; lean_object* v___x_2624_; lean_object* v___x_2625_; lean_object* v___x_2627_; 
lean_dec(v___x_2559_);
lean_dec(v_val_2554_);
lean_dec(v_fst_2550_);
lean_dec(v_snd_2549_);
lean_dec(v_val_2540_);
lean_dec_ref(v_elems_2533_);
v___x_2623_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2624_ = l_Nat_reprFast(v_a_2558_);
v___x_2625_ = lean_string_append(v___x_2623_, v___x_2624_);
lean_dec_ref(v___x_2624_);
if (v_isShared_2557_ == 0)
{
lean_ctor_set_tag(v___x_2556_, 18);
lean_ctor_set(v___x_2556_, 0, v___x_2625_);
v___x_2627_ = v___x_2556_;
goto v_reusejp_2626_;
}
else
{
lean_object* v_reuseFailAlloc_2631_; 
v_reuseFailAlloc_2631_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2631_, 0, v___x_2625_);
v___x_2627_ = v_reuseFailAlloc_2631_;
goto v_reusejp_2626_;
}
v_reusejp_2626_:
{
lean_object* v___x_2629_; 
if (v_isShared_2548_ == 0)
{
lean_ctor_set_tag(v___x_2547_, 1);
lean_ctor_set(v___x_2547_, 0, v___x_2627_);
v___x_2629_ = v___x_2547_;
goto v_reusejp_2628_;
}
else
{
lean_object* v_reuseFailAlloc_2630_; 
v_reuseFailAlloc_2630_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2630_, 0, v___x_2627_);
v___x_2629_ = v_reuseFailAlloc_2630_;
goto v_reusejp_2628_;
}
v_reusejp_2628_:
{
return v___x_2629_;
}
}
}
}
}
else
{
lean_object* v___x_2633_; lean_object* v___x_2634_; lean_object* v___x_2635_; lean_object* v___x_2637_; 
lean_dec(v___x_2553_);
lean_dec(v_fst_2550_);
lean_dec(v_snd_2549_);
lean_dec(v_val_2540_);
lean_dec_ref(v_elems_2533_);
lean_dec(v_mantissa_2523_);
v___x_2633_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2634_ = l_Nat_reprFast(v_a_2552_);
v___x_2635_ = lean_string_append(v___x_2633_, v___x_2634_);
lean_dec_ref(v___x_2634_);
if (v_isShared_2543_ == 0)
{
lean_ctor_set_tag(v___x_2542_, 18);
lean_ctor_set(v___x_2542_, 0, v___x_2635_);
v___x_2637_ = v___x_2542_;
goto v_reusejp_2636_;
}
else
{
lean_object* v_reuseFailAlloc_2641_; 
v_reuseFailAlloc_2641_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2641_, 0, v___x_2635_);
v___x_2637_ = v_reuseFailAlloc_2641_;
goto v_reusejp_2636_;
}
v_reusejp_2636_:
{
lean_object* v___x_2639_; 
if (v_isShared_2548_ == 0)
{
lean_ctor_set_tag(v___x_2547_, 1);
lean_ctor_set(v___x_2547_, 0, v___x_2637_);
v___x_2639_ = v___x_2547_;
goto v_reusejp_2638_;
}
else
{
lean_object* v_reuseFailAlloc_2640_; 
v_reuseFailAlloc_2640_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2640_, 0, v___x_2637_);
v___x_2639_ = v_reuseFailAlloc_2640_;
goto v_reusejp_2638_;
}
v_reusejp_2638_:
{
return v___x_2639_;
}
}
}
}
}
else
{
lean_object* v_a_2643_; lean_object* v___x_2645_; uint8_t v_isShared_2646_; uint8_t v_isSharedCheck_2650_; 
lean_del_object(v___x_2542_);
lean_dec(v_val_2540_);
lean_dec_ref(v_elems_2533_);
lean_dec(v_mantissa_2523_);
lean_dec(v_mantissa_2515_);
v_a_2643_ = lean_ctor_get(v___x_2544_, 0);
v_isSharedCheck_2650_ = !lean_is_exclusive(v___x_2544_);
if (v_isSharedCheck_2650_ == 0)
{
v___x_2645_ = v___x_2544_;
v_isShared_2646_ = v_isSharedCheck_2650_;
goto v_resetjp_2644_;
}
else
{
lean_inc(v_a_2643_);
lean_dec(v___x_2544_);
v___x_2645_ = lean_box(0);
v_isShared_2646_ = v_isSharedCheck_2650_;
goto v_resetjp_2644_;
}
v_resetjp_2644_:
{
lean_object* v___x_2648_; 
if (v_isShared_2646_ == 0)
{
v___x_2648_ = v___x_2645_;
goto v_reusejp_2647_;
}
else
{
lean_object* v_reuseFailAlloc_2649_; 
v_reuseFailAlloc_2649_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2649_, 0, v_a_2643_);
v___x_2648_ = v_reuseFailAlloc_2649_;
goto v_reusejp_2647_;
}
v_reusejp_2647_:
{
return v___x_2648_;
}
}
}
}
}
else
{
lean_object* v___x_2652_; lean_object* v___x_2653_; lean_object* v___x_2654_; lean_object* v___x_2656_; 
lean_dec(v___x_2539_);
lean_dec_ref(v_elems_2533_);
lean_dec(v_mantissa_2523_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec_ref(v_a_2480_);
v___x_2652_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_2653_ = l_Nat_reprFast(v_a_2538_);
v___x_2654_ = lean_string_append(v___x_2652_, v___x_2653_);
lean_dec_ref(v___x_2653_);
if (v_isShared_2536_ == 0)
{
lean_ctor_set_tag(v___x_2535_, 18);
lean_ctor_set(v___x_2535_, 0, v___x_2654_);
v___x_2656_ = v___x_2535_;
goto v_reusejp_2655_;
}
else
{
lean_object* v_reuseFailAlloc_2660_; 
v_reuseFailAlloc_2660_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2660_, 0, v___x_2654_);
v___x_2656_ = v_reuseFailAlloc_2660_;
goto v_reusejp_2655_;
}
v_reusejp_2655_:
{
lean_object* v___x_2658_; 
if (v_isShared_2532_ == 0)
{
lean_ctor_set(v___x_2531_, 0, v___x_2656_);
v___x_2658_ = v___x_2531_;
goto v_reusejp_2657_;
}
else
{
lean_object* v_reuseFailAlloc_2659_; 
v_reuseFailAlloc_2659_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2659_, 0, v___x_2656_);
v___x_2658_ = v_reuseFailAlloc_2659_;
goto v_reusejp_2657_;
}
v_reusejp_2657_:
{
return v___x_2658_;
}
}
}
}
}
else
{
lean_del_object(v___x_2531_);
lean_dec(v_val_2529_);
lean_dec(v_mantissa_2523_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2494_;
}
}
}
else
{
lean_dec(v___x_2528_);
lean_dec(v_mantissa_2523_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2494_;
}
}
}
else
{
lean_dec(v_exponent_2524_);
lean_dec(v_mantissa_2523_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2491_;
}
}
else
{
lean_dec(v_val_2521_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2491_;
}
}
else
{
lean_dec(v___x_2520_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2491_;
}
}
}
else
{
lean_dec(v_exponent_2516_);
lean_dec(v_mantissa_2515_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2488_;
}
}
else
{
lean_dec(v_val_2513_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2488_;
}
}
else
{
lean_dec(v___x_2512_);
lean_dec_ref(v_elems_2510_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2488_;
}
}
else
{
lean_dec(v_val_2509_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2485_;
}
}
else
{
lean_dec(v___x_2508_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2485_;
}
}
}
else
{
lean_dec(v_exponent_2502_);
lean_dec(v_mantissa_2501_);
lean_dec_ref(v_a_2480_);
goto v___jp_2482_;
}
}
else
{
lean_dec(v_val_2499_);
lean_dec_ref(v_a_2480_);
goto v___jp_2482_;
}
}
else
{
lean_dec(v___x_2498_);
lean_dec_ref(v_a_2480_);
goto v___jp_2482_;
}
v___jp_2482_:
{
lean_object* v___x_2483_; lean_object* v___x_2484_; 
v___x_2483_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1));
v___x_2484_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2484_, 0, v___x_2483_);
return v___x_2484_;
}
v___jp_2485_:
{
lean_object* v___x_2486_; lean_object* v___x_2487_; 
v___x_2486_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1));
v___x_2487_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2487_, 0, v___x_2486_);
return v___x_2487_;
}
v___jp_2488_:
{
lean_object* v___x_2489_; lean_object* v___x_2490_; 
v___x_2489_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1));
v___x_2490_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2490_, 0, v___x_2489_);
return v___x_2490_;
}
v___jp_2491_:
{
lean_object* v___x_2492_; lean_object* v___x_2493_; 
v___x_2492_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1));
v___x_2493_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2493_, 0, v___x_2492_);
return v___x_2493_;
}
v___jp_2494_:
{
lean_object* v___x_2495_; lean_object* v___x_2496_; 
v___x_2495_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseThmInfo___closed__1));
v___x_2496_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2496_, 0, v___x_2495_);
return v___x_2496_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseThmInfo___boxed(lean_object* v_data_2663_, lean_object* v_a_2664_, lean_object* v_a_2665_){
_start:
{
lean_object* v_res_2666_; 
v_res_2666_ = lp_proofEnvironment_Export_Parse_parseThmInfo(v_data_2663_, v_a_2664_);
lean_dec(v_data_2663_);
return v_res_2666_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseOpaqueInfo(lean_object* v_data_2670_, lean_object* v_a_2671_){
_start:
{
lean_object* v___x_2688_; lean_object* v___x_2689_; 
v___x_2688_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_2689_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2670_, v___x_2688_);
if (lean_obj_tag(v___x_2689_) == 1)
{
lean_object* v_val_2690_; 
v_val_2690_ = lean_ctor_get(v___x_2689_, 0);
lean_inc(v_val_2690_);
lean_dec_ref_known(v___x_2689_, 1);
if (lean_obj_tag(v_val_2690_) == 2)
{
lean_object* v_n_2691_; lean_object* v_mantissa_2692_; lean_object* v_exponent_2693_; lean_object* v_natZero_2694_; lean_object* v_intZero_2695_; uint8_t v_isNeg_2696_; 
v_n_2691_ = lean_ctor_get(v_val_2690_, 0);
lean_inc_ref(v_n_2691_);
lean_dec_ref_known(v_val_2690_, 1);
v_mantissa_2692_ = lean_ctor_get(v_n_2691_, 0);
lean_inc(v_mantissa_2692_);
v_exponent_2693_ = lean_ctor_get(v_n_2691_, 1);
lean_inc(v_exponent_2693_);
lean_dec_ref(v_n_2691_);
v_natZero_2694_ = lean_unsigned_to_nat(0u);
v_intZero_2695_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_2696_ = lean_int_dec_lt(v_mantissa_2692_, v_intZero_2695_);
if (v_isNeg_2696_ == 0)
{
uint8_t v___x_2697_; 
v___x_2697_ = lean_nat_dec_eq(v_exponent_2693_, v_natZero_2694_);
lean_dec(v_exponent_2693_);
if (v___x_2697_ == 0)
{
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2685_;
}
else
{
lean_object* v___x_2698_; lean_object* v___x_2699_; 
v___x_2698_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_2699_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2670_, v___x_2698_);
if (lean_obj_tag(v___x_2699_) == 1)
{
lean_object* v_val_2700_; 
v_val_2700_ = lean_ctor_get(v___x_2699_, 0);
lean_inc(v_val_2700_);
lean_dec_ref_known(v___x_2699_, 1);
if (lean_obj_tag(v_val_2700_) == 4)
{
lean_object* v_elems_2701_; lean_object* v___x_2702_; lean_object* v___x_2703_; 
v_elems_2701_ = lean_ctor_get(v_val_2700_, 0);
lean_inc_ref(v_elems_2701_);
lean_dec_ref_known(v_val_2700_, 1);
v___x_2702_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_2703_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2670_, v___x_2702_);
if (lean_obj_tag(v___x_2703_) == 1)
{
lean_object* v_val_2704_; 
v_val_2704_ = lean_ctor_get(v___x_2703_, 0);
lean_inc(v_val_2704_);
lean_dec_ref_known(v___x_2703_, 1);
if (lean_obj_tag(v_val_2704_) == 2)
{
lean_object* v_n_2705_; lean_object* v_mantissa_2706_; lean_object* v_exponent_2707_; uint8_t v_isNeg_2708_; 
v_n_2705_ = lean_ctor_get(v_val_2704_, 0);
lean_inc_ref(v_n_2705_);
lean_dec_ref_known(v_val_2704_, 1);
v_mantissa_2706_ = lean_ctor_get(v_n_2705_, 0);
lean_inc(v_mantissa_2706_);
v_exponent_2707_ = lean_ctor_get(v_n_2705_, 1);
lean_inc(v_exponent_2707_);
lean_dec_ref(v_n_2705_);
v_isNeg_2708_ = lean_int_dec_lt(v_mantissa_2706_, v_intZero_2695_);
if (v_isNeg_2708_ == 0)
{
uint8_t v___x_2709_; 
v___x_2709_ = lean_nat_dec_eq(v_exponent_2707_, v_natZero_2694_);
lean_dec(v_exponent_2707_);
if (v___x_2709_ == 0)
{
lean_dec(v_mantissa_2706_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2679_;
}
else
{
lean_object* v___x_2710_; lean_object* v___x_2711_; 
v___x_2710_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLetE___closed__2));
v___x_2711_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2670_, v___x_2710_);
if (lean_obj_tag(v___x_2711_) == 1)
{
lean_object* v_val_2712_; 
v_val_2712_ = lean_ctor_get(v___x_2711_, 0);
lean_inc(v_val_2712_);
lean_dec_ref_known(v___x_2711_, 1);
if (lean_obj_tag(v_val_2712_) == 2)
{
lean_object* v_n_2713_; lean_object* v_mantissa_2714_; lean_object* v_exponent_2715_; uint8_t v_isNeg_2716_; 
v_n_2713_ = lean_ctor_get(v_val_2712_, 0);
lean_inc_ref(v_n_2713_);
lean_dec_ref_known(v_val_2712_, 1);
v_mantissa_2714_ = lean_ctor_get(v_n_2713_, 0);
lean_inc(v_mantissa_2714_);
v_exponent_2715_ = lean_ctor_get(v_n_2713_, 1);
lean_inc(v_exponent_2715_);
lean_dec_ref(v_n_2713_);
v_isNeg_2716_ = lean_int_dec_lt(v_mantissa_2714_, v_intZero_2695_);
if (v_isNeg_2716_ == 0)
{
uint8_t v___x_2717_; 
v___x_2717_ = lean_nat_dec_eq(v_exponent_2715_, v_natZero_2694_);
lean_dec(v_exponent_2715_);
if (v___x_2717_ == 0)
{
lean_dec(v_mantissa_2714_);
lean_dec(v_mantissa_2706_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2676_;
}
else
{
lean_object* v_a_2718_; lean_object* v_a_2719_; lean_object* v_a_2720_; uint8_t v_b_2722_; lean_object* v___x_2856_; lean_object* v___x_2857_; 
v_a_2718_ = lean_nat_abs(v_mantissa_2692_);
lean_dec(v_mantissa_2692_);
v_a_2719_ = lean_nat_abs(v_mantissa_2706_);
lean_dec(v_mantissa_2706_);
v_a_2720_ = lean_nat_abs(v_mantissa_2714_);
lean_dec(v_mantissa_2714_);
v___x_2856_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3));
v___x_2857_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2670_, v___x_2856_);
if (lean_obj_tag(v___x_2857_) == 0)
{
v_b_2722_ = v_isNeg_2716_;
goto v___jp_2721_;
}
else
{
lean_object* v_val_2858_; lean_object* v___x_2860_; uint8_t v_isShared_2861_; uint8_t v_isSharedCheck_2867_; 
v_val_2858_ = lean_ctor_get(v___x_2857_, 0);
v_isSharedCheck_2867_ = !lean_is_exclusive(v___x_2857_);
if (v_isSharedCheck_2867_ == 0)
{
v___x_2860_ = v___x_2857_;
v_isShared_2861_ = v_isSharedCheck_2867_;
goto v_resetjp_2859_;
}
else
{
lean_inc(v_val_2858_);
lean_dec(v___x_2857_);
v___x_2860_ = lean_box(0);
v_isShared_2861_ = v_isSharedCheck_2867_;
goto v_resetjp_2859_;
}
v_resetjp_2859_:
{
if (lean_obj_tag(v_val_2858_) == 1)
{
uint8_t v_b_2862_; 
lean_del_object(v___x_2860_);
v_b_2862_ = lean_ctor_get_uint8(v_val_2858_, 0);
lean_dec_ref_known(v_val_2858_, 0);
v_b_2722_ = v_b_2862_;
goto v___jp_2721_;
}
else
{
lean_object* v___x_2863_; lean_object* v___x_2865_; 
lean_dec(v_val_2858_);
lean_dec(v_a_2720_);
lean_dec(v_a_2719_);
lean_dec(v_a_2718_);
lean_dec_ref(v_elems_2701_);
lean_dec_ref(v_a_2671_);
v___x_2863_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__1));
if (v_isShared_2861_ == 0)
{
lean_ctor_set(v___x_2860_, 0, v___x_2863_);
v___x_2865_ = v___x_2860_;
goto v_reusejp_2864_;
}
else
{
lean_object* v_reuseFailAlloc_2866_; 
v_reuseFailAlloc_2866_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2866_, 0, v___x_2863_);
v___x_2865_ = v_reuseFailAlloc_2866_;
goto v_reusejp_2864_;
}
v_reusejp_2864_:
{
return v___x_2865_;
}
}
}
}
v___jp_2721_:
{
lean_object* v___x_2723_; lean_object* v___x_2724_; 
v___x_2723_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4));
v___x_2724_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2670_, v___x_2723_);
if (lean_obj_tag(v___x_2724_) == 1)
{
lean_object* v_val_2725_; lean_object* v___x_2727_; uint8_t v_isShared_2728_; uint8_t v_isSharedCheck_2855_; 
v_val_2725_ = lean_ctor_get(v___x_2724_, 0);
v_isSharedCheck_2855_ = !lean_is_exclusive(v___x_2724_);
if (v_isSharedCheck_2855_ == 0)
{
v___x_2727_ = v___x_2724_;
v_isShared_2728_ = v_isSharedCheck_2855_;
goto v_resetjp_2726_;
}
else
{
lean_inc(v_val_2725_);
lean_dec(v___x_2724_);
v___x_2727_ = lean_box(0);
v_isShared_2728_ = v_isSharedCheck_2855_;
goto v_resetjp_2726_;
}
v_resetjp_2726_:
{
if (lean_obj_tag(v_val_2725_) == 4)
{
lean_object* v_elems_2729_; lean_object* v___x_2731_; uint8_t v_isShared_2732_; uint8_t v_isSharedCheck_2854_; 
v_elems_2729_ = lean_ctor_get(v_val_2725_, 0);
v_isSharedCheck_2854_ = !lean_is_exclusive(v_val_2725_);
if (v_isSharedCheck_2854_ == 0)
{
v___x_2731_ = v_val_2725_;
v_isShared_2732_ = v_isSharedCheck_2854_;
goto v_resetjp_2730_;
}
else
{
lean_inc(v_elems_2729_);
lean_dec(v_val_2725_);
v___x_2731_ = lean_box(0);
v_isShared_2732_ = v_isSharedCheck_2854_;
goto v_resetjp_2730_;
}
v_resetjp_2730_:
{
lean_object* v_nameMap_2733_; lean_object* v___x_2734_; 
v_nameMap_2733_ = lean_ctor_get(v_a_2671_, 1);
v___x_2734_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_2733_, v_a_2718_);
if (lean_obj_tag(v___x_2734_) == 1)
{
lean_object* v_val_2735_; lean_object* v___x_2737_; uint8_t v_isShared_2738_; uint8_t v_isSharedCheck_2844_; 
lean_del_object(v___x_2731_);
lean_del_object(v___x_2727_);
lean_dec(v_a_2718_);
v_val_2735_ = lean_ctor_get(v___x_2734_, 0);
v_isSharedCheck_2844_ = !lean_is_exclusive(v___x_2734_);
if (v_isSharedCheck_2844_ == 0)
{
v___x_2737_ = v___x_2734_;
v_isShared_2738_ = v_isSharedCheck_2844_;
goto v_resetjp_2736_;
}
else
{
lean_inc(v_val_2735_);
lean_dec(v___x_2734_);
v___x_2737_ = lean_box(0);
v_isShared_2738_ = v_isSharedCheck_2844_;
goto v_resetjp_2736_;
}
v_resetjp_2736_:
{
lean_object* v___x_2739_; 
v___x_2739_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2701_, v_a_2671_);
if (lean_obj_tag(v___x_2739_) == 0)
{
lean_object* v_a_2740_; lean_object* v___x_2742_; uint8_t v_isShared_2743_; uint8_t v_isSharedCheck_2835_; 
v_a_2740_ = lean_ctor_get(v___x_2739_, 0);
v_isSharedCheck_2835_ = !lean_is_exclusive(v___x_2739_);
if (v_isSharedCheck_2835_ == 0)
{
v___x_2742_ = v___x_2739_;
v_isShared_2743_ = v_isSharedCheck_2835_;
goto v_resetjp_2741_;
}
else
{
lean_inc(v_a_2740_);
lean_dec(v___x_2739_);
v___x_2742_ = lean_box(0);
v_isShared_2743_ = v_isSharedCheck_2835_;
goto v_resetjp_2741_;
}
v_resetjp_2741_:
{
lean_object* v_snd_2744_; lean_object* v_fst_2745_; lean_object* v_exprMap_2746_; lean_object* v___x_2747_; 
v_snd_2744_ = lean_ctor_get(v_a_2740_, 1);
lean_inc(v_snd_2744_);
v_fst_2745_ = lean_ctor_get(v_a_2740_, 0);
lean_inc(v_fst_2745_);
lean_dec(v_a_2740_);
v_exprMap_2746_ = lean_ctor_get(v_snd_2744_, 3);
v___x_2747_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2746_, v_a_2719_);
if (lean_obj_tag(v___x_2747_) == 1)
{
lean_object* v_val_2748_; lean_object* v___x_2750_; uint8_t v_isShared_2751_; uint8_t v_isSharedCheck_2825_; 
lean_del_object(v___x_2737_);
lean_dec(v_a_2719_);
v_val_2748_ = lean_ctor_get(v___x_2747_, 0);
v_isSharedCheck_2825_ = !lean_is_exclusive(v___x_2747_);
if (v_isSharedCheck_2825_ == 0)
{
v___x_2750_ = v___x_2747_;
v_isShared_2751_ = v_isSharedCheck_2825_;
goto v_resetjp_2749_;
}
else
{
lean_inc(v_val_2748_);
lean_dec(v___x_2747_);
v___x_2750_ = lean_box(0);
v_isShared_2751_ = v_isSharedCheck_2825_;
goto v_resetjp_2749_;
}
v_resetjp_2749_:
{
lean_object* v___x_2752_; 
v___x_2752_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2746_, v_a_2720_);
if (lean_obj_tag(v___x_2752_) == 1)
{
lean_object* v_val_2753_; lean_object* v___x_2755_; uint8_t v_isShared_2756_; uint8_t v_isSharedCheck_2815_; 
lean_del_object(v___x_2750_);
lean_del_object(v___x_2742_);
lean_dec(v_a_2720_);
v_val_2753_ = lean_ctor_get(v___x_2752_, 0);
v_isSharedCheck_2815_ = !lean_is_exclusive(v___x_2752_);
if (v_isSharedCheck_2815_ == 0)
{
v___x_2755_ = v___x_2752_;
v_isShared_2756_ = v_isSharedCheck_2815_;
goto v_resetjp_2754_;
}
else
{
lean_inc(v_val_2753_);
lean_dec(v___x_2752_);
v___x_2755_ = lean_box(0);
v_isShared_2756_ = v_isSharedCheck_2815_;
goto v_resetjp_2754_;
}
v_resetjp_2754_:
{
lean_object* v___x_2757_; 
v___x_2757_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2729_, v_snd_2744_);
if (lean_obj_tag(v___x_2757_) == 0)
{
lean_object* v_a_2758_; lean_object* v___x_2760_; uint8_t v_isShared_2761_; uint8_t v_isSharedCheck_2806_; 
v_a_2758_ = lean_ctor_get(v___x_2757_, 0);
v_isSharedCheck_2806_ = !lean_is_exclusive(v___x_2757_);
if (v_isSharedCheck_2806_ == 0)
{
v___x_2760_ = v___x_2757_;
v_isShared_2761_ = v_isSharedCheck_2806_;
goto v_resetjp_2759_;
}
else
{
lean_inc(v_a_2758_);
lean_dec(v___x_2757_);
v___x_2760_ = lean_box(0);
v_isShared_2761_ = v_isSharedCheck_2806_;
goto v_resetjp_2759_;
}
v_resetjp_2759_:
{
lean_object* v_snd_2762_; lean_object* v_fst_2763_; lean_object* v___x_2765_; uint8_t v_isShared_2766_; uint8_t v_isSharedCheck_2805_; 
v_snd_2762_ = lean_ctor_get(v_a_2758_, 1);
v_fst_2763_ = lean_ctor_get(v_a_2758_, 0);
v_isSharedCheck_2805_ = !lean_is_exclusive(v_a_2758_);
if (v_isSharedCheck_2805_ == 0)
{
v___x_2765_ = v_a_2758_;
v_isShared_2766_ = v_isSharedCheck_2805_;
goto v_resetjp_2764_;
}
else
{
lean_inc(v_snd_2762_);
lean_inc(v_fst_2763_);
lean_dec(v_a_2758_);
v___x_2765_ = lean_box(0);
v_isShared_2766_ = v_isSharedCheck_2805_;
goto v_resetjp_2764_;
}
v_resetjp_2764_:
{
lean_object* v_stream_2767_; lean_object* v_nameMap_2768_; lean_object* v_levelMap_2769_; lean_object* v_exprMap_2770_; lean_object* v_recursorRuleMap_2771_; lean_object* v_constMap_2772_; lean_object* v_constOrder_2773_; lean_object* v___x_2775_; uint8_t v_isShared_2776_; uint8_t v_isSharedCheck_2804_; 
v_stream_2767_ = lean_ctor_get(v_snd_2762_, 0);
v_nameMap_2768_ = lean_ctor_get(v_snd_2762_, 1);
v_levelMap_2769_ = lean_ctor_get(v_snd_2762_, 2);
v_exprMap_2770_ = lean_ctor_get(v_snd_2762_, 3);
v_recursorRuleMap_2771_ = lean_ctor_get(v_snd_2762_, 4);
v_constMap_2772_ = lean_ctor_get(v_snd_2762_, 5);
v_constOrder_2773_ = lean_ctor_get(v_snd_2762_, 6);
v_isSharedCheck_2804_ = !lean_is_exclusive(v_snd_2762_);
if (v_isSharedCheck_2804_ == 0)
{
v___x_2775_ = v_snd_2762_;
v_isShared_2776_ = v_isSharedCheck_2804_;
goto v_resetjp_2774_;
}
else
{
lean_inc(v_constOrder_2773_);
lean_inc(v_constMap_2772_);
lean_inc(v_recursorRuleMap_2771_);
lean_inc(v_exprMap_2770_);
lean_inc(v_levelMap_2769_);
lean_inc(v_nameMap_2768_);
lean_inc(v_stream_2767_);
lean_dec(v_snd_2762_);
v___x_2775_ = lean_box(0);
v_isShared_2776_ = v_isSharedCheck_2804_;
goto v_resetjp_2774_;
}
v_resetjp_2774_:
{
uint8_t v___x_2777_; 
v___x_2777_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_2772_, v_val_2735_);
if (v___x_2777_ == 0)
{
lean_object* v___x_2778_; lean_object* v___x_2779_; lean_object* v___x_2781_; 
lean_inc(v_val_2735_);
v___x_2778_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2778_, 0, v_val_2735_);
lean_ctor_set(v___x_2778_, 1, v_fst_2745_);
lean_ctor_set(v___x_2778_, 2, v_val_2748_);
v___x_2779_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_2779_, 0, v___x_2778_);
lean_ctor_set(v___x_2779_, 1, v_val_2753_);
lean_ctor_set(v___x_2779_, 2, v_fst_2763_);
lean_ctor_set_uint8(v___x_2779_, sizeof(void*)*3, v_b_2722_);
if (v_isShared_2756_ == 0)
{
lean_ctor_set_tag(v___x_2755_, 3);
lean_ctor_set(v___x_2755_, 0, v___x_2779_);
v___x_2781_ = v___x_2755_;
goto v_reusejp_2780_;
}
else
{
lean_object* v_reuseFailAlloc_2794_; 
v_reuseFailAlloc_2794_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2794_, 0, v___x_2779_);
v___x_2781_ = v_reuseFailAlloc_2794_;
goto v_reusejp_2780_;
}
v_reusejp_2780_:
{
lean_object* v___x_2782_; lean_object* v___x_2783_; lean_object* v___x_2784_; lean_object* v___x_2786_; 
v___x_2782_ = lean_box(0);
lean_inc(v_val_2735_);
v___x_2783_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_2772_, v_val_2735_, v___x_2781_);
v___x_2784_ = lean_array_push(v_constOrder_2773_, v_val_2735_);
if (v_isShared_2776_ == 0)
{
lean_ctor_set(v___x_2775_, 6, v___x_2784_);
lean_ctor_set(v___x_2775_, 5, v___x_2783_);
v___x_2786_ = v___x_2775_;
goto v_reusejp_2785_;
}
else
{
lean_object* v_reuseFailAlloc_2793_; 
v_reuseFailAlloc_2793_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_2793_, 0, v_stream_2767_);
lean_ctor_set(v_reuseFailAlloc_2793_, 1, v_nameMap_2768_);
lean_ctor_set(v_reuseFailAlloc_2793_, 2, v_levelMap_2769_);
lean_ctor_set(v_reuseFailAlloc_2793_, 3, v_exprMap_2770_);
lean_ctor_set(v_reuseFailAlloc_2793_, 4, v_recursorRuleMap_2771_);
lean_ctor_set(v_reuseFailAlloc_2793_, 5, v___x_2783_);
lean_ctor_set(v_reuseFailAlloc_2793_, 6, v___x_2784_);
v___x_2786_ = v_reuseFailAlloc_2793_;
goto v_reusejp_2785_;
}
v_reusejp_2785_:
{
lean_object* v___x_2788_; 
if (v_isShared_2766_ == 0)
{
lean_ctor_set(v___x_2765_, 1, v___x_2786_);
lean_ctor_set(v___x_2765_, 0, v___x_2782_);
v___x_2788_ = v___x_2765_;
goto v_reusejp_2787_;
}
else
{
lean_object* v_reuseFailAlloc_2792_; 
v_reuseFailAlloc_2792_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2792_, 0, v___x_2782_);
lean_ctor_set(v_reuseFailAlloc_2792_, 1, v___x_2786_);
v___x_2788_ = v_reuseFailAlloc_2792_;
goto v_reusejp_2787_;
}
v_reusejp_2787_:
{
lean_object* v___x_2790_; 
if (v_isShared_2761_ == 0)
{
lean_ctor_set(v___x_2760_, 0, v___x_2788_);
v___x_2790_ = v___x_2760_;
goto v_reusejp_2789_;
}
else
{
lean_object* v_reuseFailAlloc_2791_; 
v_reuseFailAlloc_2791_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2791_, 0, v___x_2788_);
v___x_2790_ = v_reuseFailAlloc_2791_;
goto v_reusejp_2789_;
}
v_reusejp_2789_:
{
return v___x_2790_;
}
}
}
}
}
else
{
lean_object* v___x_2795_; lean_object* v___x_2796_; lean_object* v___x_2797_; lean_object* v___x_2799_; 
lean_del_object(v___x_2775_);
lean_dec_ref(v_constOrder_2773_);
lean_dec_ref(v_constMap_2772_);
lean_dec_ref(v_recursorRuleMap_2771_);
lean_dec_ref(v_exprMap_2770_);
lean_dec_ref(v_levelMap_2769_);
lean_dec_ref(v_nameMap_2768_);
lean_dec_ref(v_stream_2767_);
lean_del_object(v___x_2765_);
lean_dec(v_fst_2763_);
lean_dec(v_val_2753_);
lean_dec(v_val_2748_);
lean_dec(v_fst_2745_);
v___x_2795_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_2796_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_2735_, v___x_2777_);
v___x_2797_ = lean_string_append(v___x_2795_, v___x_2796_);
lean_dec_ref(v___x_2796_);
if (v_isShared_2756_ == 0)
{
lean_ctor_set_tag(v___x_2755_, 18);
lean_ctor_set(v___x_2755_, 0, v___x_2797_);
v___x_2799_ = v___x_2755_;
goto v_reusejp_2798_;
}
else
{
lean_object* v_reuseFailAlloc_2803_; 
v_reuseFailAlloc_2803_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2803_, 0, v___x_2797_);
v___x_2799_ = v_reuseFailAlloc_2803_;
goto v_reusejp_2798_;
}
v_reusejp_2798_:
{
lean_object* v___x_2801_; 
if (v_isShared_2761_ == 0)
{
lean_ctor_set_tag(v___x_2760_, 1);
lean_ctor_set(v___x_2760_, 0, v___x_2799_);
v___x_2801_ = v___x_2760_;
goto v_reusejp_2800_;
}
else
{
lean_object* v_reuseFailAlloc_2802_; 
v_reuseFailAlloc_2802_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2802_, 0, v___x_2799_);
v___x_2801_ = v_reuseFailAlloc_2802_;
goto v_reusejp_2800_;
}
v_reusejp_2800_:
{
return v___x_2801_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_2807_; lean_object* v___x_2809_; uint8_t v_isShared_2810_; uint8_t v_isSharedCheck_2814_; 
lean_del_object(v___x_2755_);
lean_dec(v_val_2753_);
lean_dec(v_val_2748_);
lean_dec(v_fst_2745_);
lean_dec(v_val_2735_);
v_a_2807_ = lean_ctor_get(v___x_2757_, 0);
v_isSharedCheck_2814_ = !lean_is_exclusive(v___x_2757_);
if (v_isSharedCheck_2814_ == 0)
{
v___x_2809_ = v___x_2757_;
v_isShared_2810_ = v_isSharedCheck_2814_;
goto v_resetjp_2808_;
}
else
{
lean_inc(v_a_2807_);
lean_dec(v___x_2757_);
v___x_2809_ = lean_box(0);
v_isShared_2810_ = v_isSharedCheck_2814_;
goto v_resetjp_2808_;
}
v_resetjp_2808_:
{
lean_object* v___x_2812_; 
if (v_isShared_2810_ == 0)
{
v___x_2812_ = v___x_2809_;
goto v_reusejp_2811_;
}
else
{
lean_object* v_reuseFailAlloc_2813_; 
v_reuseFailAlloc_2813_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2813_, 0, v_a_2807_);
v___x_2812_ = v_reuseFailAlloc_2813_;
goto v_reusejp_2811_;
}
v_reusejp_2811_:
{
return v___x_2812_;
}
}
}
}
}
else
{
lean_object* v___x_2816_; lean_object* v___x_2817_; lean_object* v___x_2818_; lean_object* v___x_2820_; 
lean_dec(v___x_2752_);
lean_dec(v_val_2748_);
lean_dec(v_fst_2745_);
lean_dec(v_snd_2744_);
lean_dec(v_val_2735_);
lean_dec_ref(v_elems_2729_);
v___x_2816_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2817_ = l_Nat_reprFast(v_a_2720_);
v___x_2818_ = lean_string_append(v___x_2816_, v___x_2817_);
lean_dec_ref(v___x_2817_);
if (v_isShared_2751_ == 0)
{
lean_ctor_set_tag(v___x_2750_, 18);
lean_ctor_set(v___x_2750_, 0, v___x_2818_);
v___x_2820_ = v___x_2750_;
goto v_reusejp_2819_;
}
else
{
lean_object* v_reuseFailAlloc_2824_; 
v_reuseFailAlloc_2824_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2824_, 0, v___x_2818_);
v___x_2820_ = v_reuseFailAlloc_2824_;
goto v_reusejp_2819_;
}
v_reusejp_2819_:
{
lean_object* v___x_2822_; 
if (v_isShared_2743_ == 0)
{
lean_ctor_set_tag(v___x_2742_, 1);
lean_ctor_set(v___x_2742_, 0, v___x_2820_);
v___x_2822_ = v___x_2742_;
goto v_reusejp_2821_;
}
else
{
lean_object* v_reuseFailAlloc_2823_; 
v_reuseFailAlloc_2823_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2823_, 0, v___x_2820_);
v___x_2822_ = v_reuseFailAlloc_2823_;
goto v_reusejp_2821_;
}
v_reusejp_2821_:
{
return v___x_2822_;
}
}
}
}
}
else
{
lean_object* v___x_2826_; lean_object* v___x_2827_; lean_object* v___x_2828_; lean_object* v___x_2830_; 
lean_dec(v___x_2747_);
lean_dec(v_fst_2745_);
lean_dec(v_snd_2744_);
lean_dec(v_val_2735_);
lean_dec_ref(v_elems_2729_);
lean_dec(v_a_2720_);
v___x_2826_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_2827_ = l_Nat_reprFast(v_a_2719_);
v___x_2828_ = lean_string_append(v___x_2826_, v___x_2827_);
lean_dec_ref(v___x_2827_);
if (v_isShared_2738_ == 0)
{
lean_ctor_set_tag(v___x_2737_, 18);
lean_ctor_set(v___x_2737_, 0, v___x_2828_);
v___x_2830_ = v___x_2737_;
goto v_reusejp_2829_;
}
else
{
lean_object* v_reuseFailAlloc_2834_; 
v_reuseFailAlloc_2834_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2834_, 0, v___x_2828_);
v___x_2830_ = v_reuseFailAlloc_2834_;
goto v_reusejp_2829_;
}
v_reusejp_2829_:
{
lean_object* v___x_2832_; 
if (v_isShared_2743_ == 0)
{
lean_ctor_set_tag(v___x_2742_, 1);
lean_ctor_set(v___x_2742_, 0, v___x_2830_);
v___x_2832_ = v___x_2742_;
goto v_reusejp_2831_;
}
else
{
lean_object* v_reuseFailAlloc_2833_; 
v_reuseFailAlloc_2833_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2833_, 0, v___x_2830_);
v___x_2832_ = v_reuseFailAlloc_2833_;
goto v_reusejp_2831_;
}
v_reusejp_2831_:
{
return v___x_2832_;
}
}
}
}
}
else
{
lean_object* v_a_2836_; lean_object* v___x_2838_; uint8_t v_isShared_2839_; uint8_t v_isSharedCheck_2843_; 
lean_del_object(v___x_2737_);
lean_dec(v_val_2735_);
lean_dec_ref(v_elems_2729_);
lean_dec(v_a_2720_);
lean_dec(v_a_2719_);
v_a_2836_ = lean_ctor_get(v___x_2739_, 0);
v_isSharedCheck_2843_ = !lean_is_exclusive(v___x_2739_);
if (v_isSharedCheck_2843_ == 0)
{
v___x_2838_ = v___x_2739_;
v_isShared_2839_ = v_isSharedCheck_2843_;
goto v_resetjp_2837_;
}
else
{
lean_inc(v_a_2836_);
lean_dec(v___x_2739_);
v___x_2838_ = lean_box(0);
v_isShared_2839_ = v_isSharedCheck_2843_;
goto v_resetjp_2837_;
}
v_resetjp_2837_:
{
lean_object* v___x_2841_; 
if (v_isShared_2839_ == 0)
{
v___x_2841_ = v___x_2838_;
goto v_reusejp_2840_;
}
else
{
lean_object* v_reuseFailAlloc_2842_; 
v_reuseFailAlloc_2842_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2842_, 0, v_a_2836_);
v___x_2841_ = v_reuseFailAlloc_2842_;
goto v_reusejp_2840_;
}
v_reusejp_2840_:
{
return v___x_2841_;
}
}
}
}
}
else
{
lean_object* v___x_2845_; lean_object* v___x_2846_; lean_object* v___x_2847_; lean_object* v___x_2849_; 
lean_dec(v___x_2734_);
lean_dec_ref(v_elems_2729_);
lean_dec(v_a_2720_);
lean_dec(v_a_2719_);
lean_dec_ref(v_elems_2701_);
lean_dec_ref(v_a_2671_);
v___x_2845_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_2846_ = l_Nat_reprFast(v_a_2718_);
v___x_2847_ = lean_string_append(v___x_2845_, v___x_2846_);
lean_dec_ref(v___x_2846_);
if (v_isShared_2732_ == 0)
{
lean_ctor_set_tag(v___x_2731_, 18);
lean_ctor_set(v___x_2731_, 0, v___x_2847_);
v___x_2849_ = v___x_2731_;
goto v_reusejp_2848_;
}
else
{
lean_object* v_reuseFailAlloc_2853_; 
v_reuseFailAlloc_2853_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2853_, 0, v___x_2847_);
v___x_2849_ = v_reuseFailAlloc_2853_;
goto v_reusejp_2848_;
}
v_reusejp_2848_:
{
lean_object* v___x_2851_; 
if (v_isShared_2728_ == 0)
{
lean_ctor_set(v___x_2727_, 0, v___x_2849_);
v___x_2851_ = v___x_2727_;
goto v_reusejp_2850_;
}
else
{
lean_object* v_reuseFailAlloc_2852_; 
v_reuseFailAlloc_2852_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2852_, 0, v___x_2849_);
v___x_2851_ = v_reuseFailAlloc_2852_;
goto v_reusejp_2850_;
}
v_reusejp_2850_:
{
return v___x_2851_;
}
}
}
}
}
else
{
lean_del_object(v___x_2727_);
lean_dec(v_val_2725_);
lean_dec(v_a_2720_);
lean_dec(v_a_2719_);
lean_dec(v_a_2718_);
lean_dec_ref(v_elems_2701_);
lean_dec_ref(v_a_2671_);
goto v___jp_2673_;
}
}
}
else
{
lean_dec(v___x_2724_);
lean_dec(v_a_2720_);
lean_dec(v_a_2719_);
lean_dec(v_a_2718_);
lean_dec_ref(v_elems_2701_);
lean_dec_ref(v_a_2671_);
goto v___jp_2673_;
}
}
}
}
else
{
lean_dec(v_exponent_2715_);
lean_dec(v_mantissa_2714_);
lean_dec(v_mantissa_2706_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2676_;
}
}
else
{
lean_dec(v_val_2712_);
lean_dec(v_mantissa_2706_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2676_;
}
}
else
{
lean_dec(v___x_2711_);
lean_dec(v_mantissa_2706_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2676_;
}
}
}
else
{
lean_dec(v_exponent_2707_);
lean_dec(v_mantissa_2706_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2679_;
}
}
else
{
lean_dec(v_val_2704_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2679_;
}
}
else
{
lean_dec(v___x_2703_);
lean_dec_ref(v_elems_2701_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2679_;
}
}
else
{
lean_dec(v_val_2700_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2682_;
}
}
else
{
lean_dec(v___x_2699_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2682_;
}
}
}
else
{
lean_dec(v_exponent_2693_);
lean_dec(v_mantissa_2692_);
lean_dec_ref(v_a_2671_);
goto v___jp_2685_;
}
}
else
{
lean_dec(v_val_2690_);
lean_dec_ref(v_a_2671_);
goto v___jp_2685_;
}
}
else
{
lean_dec(v___x_2689_);
lean_dec_ref(v_a_2671_);
goto v___jp_2685_;
}
v___jp_2673_:
{
lean_object* v___x_2674_; lean_object* v___x_2675_; 
v___x_2674_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1));
v___x_2675_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2675_, 0, v___x_2674_);
return v___x_2675_;
}
v___jp_2676_:
{
lean_object* v___x_2677_; lean_object* v___x_2678_; 
v___x_2677_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1));
v___x_2678_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2678_, 0, v___x_2677_);
return v___x_2678_;
}
v___jp_2679_:
{
lean_object* v___x_2680_; lean_object* v___x_2681_; 
v___x_2680_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1));
v___x_2681_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2681_, 0, v___x_2680_);
return v___x_2681_;
}
v___jp_2682_:
{
lean_object* v___x_2683_; lean_object* v___x_2684_; 
v___x_2683_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1));
v___x_2684_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2684_, 0, v___x_2683_);
return v___x_2684_;
}
v___jp_2685_:
{
lean_object* v___x_2686_; lean_object* v___x_2687_; 
v___x_2686_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseOpaqueInfo___closed__1));
v___x_2687_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2687_, 0, v___x_2686_);
return v___x_2687_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseOpaqueInfo___boxed(lean_object* v_data_2868_, lean_object* v_a_2869_, lean_object* v_a_2870_){
_start:
{
lean_object* v_res_2871_; 
v_res_2871_ = lp_proofEnvironment_Export_Parse_parseOpaqueInfo(v_data_2868_, v_a_2869_);
lean_dec(v_data_2868_);
return v_res_2871_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo(lean_object* v_data_2880_, lean_object* v_a_2881_){
_start:
{
lean_object* v___x_2895_; lean_object* v___x_2896_; 
v___x_2895_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_2896_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2880_, v___x_2895_);
if (lean_obj_tag(v___x_2896_) == 1)
{
lean_object* v_val_2897_; 
v_val_2897_ = lean_ctor_get(v___x_2896_, 0);
lean_inc(v_val_2897_);
lean_dec_ref_known(v___x_2896_, 1);
if (lean_obj_tag(v_val_2897_) == 2)
{
lean_object* v_n_2898_; lean_object* v_mantissa_2899_; lean_object* v_exponent_2900_; lean_object* v_natZero_2901_; lean_object* v_intZero_2902_; uint8_t v_isNeg_2903_; 
v_n_2898_ = lean_ctor_get(v_val_2897_, 0);
lean_inc_ref(v_n_2898_);
lean_dec_ref_known(v_val_2897_, 1);
v_mantissa_2899_ = lean_ctor_get(v_n_2898_, 0);
lean_inc(v_mantissa_2899_);
v_exponent_2900_ = lean_ctor_get(v_n_2898_, 1);
lean_inc(v_exponent_2900_);
lean_dec_ref(v_n_2898_);
v_natZero_2901_ = lean_unsigned_to_nat(0u);
v_intZero_2902_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_2903_ = lean_int_dec_lt(v_mantissa_2899_, v_intZero_2902_);
if (v_isNeg_2903_ == 0)
{
uint8_t v___x_2904_; 
v___x_2904_ = lean_nat_dec_eq(v_exponent_2900_, v_natZero_2901_);
lean_dec(v_exponent_2900_);
if (v___x_2904_ == 0)
{
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2892_;
}
else
{
lean_object* v___x_2905_; lean_object* v___x_2906_; 
v___x_2905_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_2906_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2880_, v___x_2905_);
if (lean_obj_tag(v___x_2906_) == 1)
{
lean_object* v_val_2907_; 
v_val_2907_ = lean_ctor_get(v___x_2906_, 0);
lean_inc(v_val_2907_);
lean_dec_ref_known(v___x_2906_, 1);
if (lean_obj_tag(v_val_2907_) == 4)
{
lean_object* v_elems_2908_; lean_object* v___x_2909_; lean_object* v___x_2910_; 
v_elems_2908_ = lean_ctor_get(v_val_2907_, 0);
lean_inc_ref(v_elems_2908_);
lean_dec_ref_known(v_val_2907_, 1);
v___x_2909_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_2910_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2880_, v___x_2909_);
if (lean_obj_tag(v___x_2910_) == 1)
{
lean_object* v_val_2911_; 
v_val_2911_ = lean_ctor_get(v___x_2910_, 0);
lean_inc(v_val_2911_);
lean_dec_ref_known(v___x_2910_, 1);
if (lean_obj_tag(v_val_2911_) == 2)
{
lean_object* v_n_2912_; lean_object* v_mantissa_2913_; lean_object* v_exponent_2914_; uint8_t v_isNeg_2915_; 
v_n_2912_ = lean_ctor_get(v_val_2911_, 0);
lean_inc_ref(v_n_2912_);
lean_dec_ref_known(v_val_2911_, 1);
v_mantissa_2913_ = lean_ctor_get(v_n_2912_, 0);
lean_inc(v_mantissa_2913_);
v_exponent_2914_ = lean_ctor_get(v_n_2912_, 1);
lean_inc(v_exponent_2914_);
lean_dec_ref(v_n_2912_);
v_isNeg_2915_ = lean_int_dec_lt(v_mantissa_2913_, v_intZero_2902_);
if (v_isNeg_2915_ == 0)
{
uint8_t v___x_2916_; 
v___x_2916_ = lean_nat_dec_eq(v_exponent_2914_, v_natZero_2901_);
lean_dec(v_exponent_2914_);
if (v___x_2916_ == 0)
{
lean_dec(v_mantissa_2913_);
lean_dec_ref(v_elems_2908_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2886_;
}
else
{
lean_object* v___x_2917_; lean_object* v___x_2918_; 
v___x_2917_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__2));
v___x_2918_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_2880_, v___x_2917_);
if (lean_obj_tag(v___x_2918_) == 1)
{
lean_object* v_val_2919_; lean_object* v___x_2921_; uint8_t v_isShared_2922_; uint8_t v_isSharedCheck_3047_; 
v_val_2919_ = lean_ctor_get(v___x_2918_, 0);
v_isSharedCheck_3047_ = !lean_is_exclusive(v___x_2918_);
if (v_isSharedCheck_3047_ == 0)
{
v___x_2921_ = v___x_2918_;
v_isShared_2922_ = v_isSharedCheck_3047_;
goto v_resetjp_2920_;
}
else
{
lean_inc(v_val_2919_);
lean_dec(v___x_2918_);
v___x_2921_ = lean_box(0);
v_isShared_2922_ = v_isSharedCheck_3047_;
goto v_resetjp_2920_;
}
v_resetjp_2920_:
{
if (lean_obj_tag(v_val_2919_) == 3)
{
lean_object* v_s_2923_; lean_object* v___x_2925_; uint8_t v_isShared_2926_; uint8_t v_isSharedCheck_3046_; 
v_s_2923_ = lean_ctor_get(v_val_2919_, 0);
v_isSharedCheck_3046_ = !lean_is_exclusive(v_val_2919_);
if (v_isSharedCheck_3046_ == 0)
{
v___x_2925_ = v_val_2919_;
v_isShared_2926_ = v_isSharedCheck_3046_;
goto v_resetjp_2924_;
}
else
{
lean_inc(v_s_2923_);
lean_dec(v_val_2919_);
v___x_2925_ = lean_box(0);
v_isShared_2926_ = v_isSharedCheck_3046_;
goto v_resetjp_2924_;
}
v_resetjp_2924_:
{
lean_object* v_nameMap_2927_; lean_object* v_a_2928_; lean_object* v___x_2929_; 
v_nameMap_2927_ = lean_ctor_get(v_a_2881_, 1);
v_a_2928_ = lean_nat_abs(v_mantissa_2899_);
lean_dec(v_mantissa_2899_);
v___x_2929_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_2927_, v_a_2928_);
if (lean_obj_tag(v___x_2929_) == 1)
{
lean_object* v_val_2930_; lean_object* v___x_2932_; uint8_t v_isShared_2933_; uint8_t v_isSharedCheck_3036_; 
lean_dec(v_a_2928_);
lean_del_object(v___x_2921_);
v_val_2930_ = lean_ctor_get(v___x_2929_, 0);
v_isSharedCheck_3036_ = !lean_is_exclusive(v___x_2929_);
if (v_isSharedCheck_3036_ == 0)
{
v___x_2932_ = v___x_2929_;
v_isShared_2933_ = v_isSharedCheck_3036_;
goto v_resetjp_2931_;
}
else
{
lean_inc(v_val_2930_);
lean_dec(v___x_2929_);
v___x_2932_ = lean_box(0);
v_isShared_2933_ = v_isSharedCheck_3036_;
goto v_resetjp_2931_;
}
v_resetjp_2931_:
{
lean_object* v___x_2934_; 
v___x_2934_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_2908_, v_a_2881_);
if (lean_obj_tag(v___x_2934_) == 0)
{
lean_object* v_a_2935_; lean_object* v___x_2937_; uint8_t v_isShared_2938_; uint8_t v_isSharedCheck_3027_; 
v_a_2935_ = lean_ctor_get(v___x_2934_, 0);
v_isSharedCheck_3027_ = !lean_is_exclusive(v___x_2934_);
if (v_isSharedCheck_3027_ == 0)
{
v___x_2937_ = v___x_2934_;
v_isShared_2938_ = v_isSharedCheck_3027_;
goto v_resetjp_2936_;
}
else
{
lean_inc(v_a_2935_);
lean_dec(v___x_2934_);
v___x_2937_ = lean_box(0);
v_isShared_2938_ = v_isSharedCheck_3027_;
goto v_resetjp_2936_;
}
v_resetjp_2936_:
{
lean_object* v_snd_2939_; lean_object* v_fst_2940_; lean_object* v___x_2942_; uint8_t v_isShared_2943_; uint8_t v_isSharedCheck_3026_; 
v_snd_2939_ = lean_ctor_get(v_a_2935_, 1);
v_fst_2940_ = lean_ctor_get(v_a_2935_, 0);
v_isSharedCheck_3026_ = !lean_is_exclusive(v_a_2935_);
if (v_isSharedCheck_3026_ == 0)
{
v___x_2942_ = v_a_2935_;
v_isShared_2943_ = v_isSharedCheck_3026_;
goto v_resetjp_2941_;
}
else
{
lean_inc(v_snd_2939_);
lean_inc(v_fst_2940_);
lean_dec(v_a_2935_);
v___x_2942_ = lean_box(0);
v_isShared_2943_ = v_isSharedCheck_3026_;
goto v_resetjp_2941_;
}
v_resetjp_2941_:
{
lean_object* v_stream_2944_; lean_object* v_nameMap_2945_; lean_object* v_levelMap_2946_; lean_object* v_exprMap_2947_; lean_object* v_recursorRuleMap_2948_; lean_object* v_constMap_2949_; lean_object* v_constOrder_2950_; lean_object* v___x_2952_; uint8_t v_isShared_2953_; uint8_t v_isSharedCheck_3025_; 
v_stream_2944_ = lean_ctor_get(v_snd_2939_, 0);
v_nameMap_2945_ = lean_ctor_get(v_snd_2939_, 1);
v_levelMap_2946_ = lean_ctor_get(v_snd_2939_, 2);
v_exprMap_2947_ = lean_ctor_get(v_snd_2939_, 3);
v_recursorRuleMap_2948_ = lean_ctor_get(v_snd_2939_, 4);
v_constMap_2949_ = lean_ctor_get(v_snd_2939_, 5);
v_constOrder_2950_ = lean_ctor_get(v_snd_2939_, 6);
v_isSharedCheck_3025_ = !lean_is_exclusive(v_snd_2939_);
if (v_isSharedCheck_3025_ == 0)
{
v___x_2952_ = v_snd_2939_;
v_isShared_2953_ = v_isSharedCheck_3025_;
goto v_resetjp_2951_;
}
else
{
lean_inc(v_constOrder_2950_);
lean_inc(v_constMap_2949_);
lean_inc(v_recursorRuleMap_2948_);
lean_inc(v_exprMap_2947_);
lean_inc(v_levelMap_2946_);
lean_inc(v_nameMap_2945_);
lean_inc(v_stream_2944_);
lean_dec(v_snd_2939_);
v___x_2952_ = lean_box(0);
v_isShared_2953_ = v_isSharedCheck_3025_;
goto v_resetjp_2951_;
}
v_resetjp_2951_:
{
lean_object* v_a_2954_; lean_object* v___x_2955_; 
v_a_2954_ = lean_nat_abs(v_mantissa_2913_);
lean_dec(v_mantissa_2913_);
v___x_2955_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_2947_, v_a_2954_);
if (lean_obj_tag(v___x_2955_) == 1)
{
lean_object* v_val_2956_; lean_object* v___x_2958_; uint8_t v_isShared_2959_; uint8_t v_isSharedCheck_3015_; 
lean_dec(v_a_2954_);
v_val_2956_ = lean_ctor_get(v___x_2955_, 0);
v_isSharedCheck_3015_ = !lean_is_exclusive(v___x_2955_);
if (v_isSharedCheck_3015_ == 0)
{
v___x_2958_ = v___x_2955_;
v_isShared_2959_ = v_isSharedCheck_3015_;
goto v_resetjp_2957_;
}
else
{
lean_inc(v_val_2956_);
lean_dec(v___x_2955_);
v___x_2958_ = lean_box(0);
v_isShared_2959_ = v_isSharedCheck_3015_;
goto v_resetjp_2957_;
}
v_resetjp_2957_:
{
uint8_t v_kind_2961_; lean_object* v_stream_2962_; lean_object* v_nameMap_2963_; lean_object* v_levelMap_2964_; lean_object* v_exprMap_2965_; lean_object* v_recursorRuleMap_2966_; lean_object* v_constMap_2967_; lean_object* v_constOrder_2968_; uint8_t v___x_2996_; 
v___x_2996_ = lean_string_dec_eq(v_s_2923_, v___x_2909_);
if (v___x_2996_ == 0)
{
lean_object* v___x_2997_; uint8_t v___x_2998_; 
v___x_2997_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__3));
v___x_2998_ = lean_string_dec_eq(v_s_2923_, v___x_2997_);
if (v___x_2998_ == 0)
{
lean_object* v___x_2999_; uint8_t v___x_3000_; 
v___x_2999_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__4));
v___x_3000_ = lean_string_dec_eq(v_s_2923_, v___x_2999_);
if (v___x_3000_ == 0)
{
lean_object* v___x_3001_; uint8_t v___x_3002_; 
v___x_3001_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__5));
v___x_3002_ = lean_string_dec_eq(v_s_2923_, v___x_3001_);
if (v___x_3002_ == 0)
{
lean_object* v___x_3003_; lean_object* v___x_3004_; lean_object* v___x_3006_; 
lean_del_object(v___x_2958_);
lean_dec(v_val_2956_);
lean_del_object(v___x_2952_);
lean_dec_ref(v_constOrder_2950_);
lean_dec_ref(v_constMap_2949_);
lean_dec_ref(v_recursorRuleMap_2948_);
lean_dec_ref(v_exprMap_2947_);
lean_dec_ref(v_levelMap_2946_);
lean_dec_ref(v_nameMap_2945_);
lean_dec_ref(v_stream_2944_);
lean_del_object(v___x_2942_);
lean_dec(v_fst_2940_);
lean_del_object(v___x_2937_);
lean_dec(v_val_2930_);
v___x_3003_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__6));
v___x_3004_ = lean_string_append(v___x_3003_, v_s_2923_);
lean_dec_ref(v_s_2923_);
if (v_isShared_2933_ == 0)
{
lean_ctor_set_tag(v___x_2932_, 18);
lean_ctor_set(v___x_2932_, 0, v___x_3004_);
v___x_3006_ = v___x_2932_;
goto v_reusejp_3005_;
}
else
{
lean_object* v_reuseFailAlloc_3010_; 
v_reuseFailAlloc_3010_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3010_, 0, v___x_3004_);
v___x_3006_ = v_reuseFailAlloc_3010_;
goto v_reusejp_3005_;
}
v_reusejp_3005_:
{
lean_object* v___x_3008_; 
if (v_isShared_2926_ == 0)
{
lean_ctor_set_tag(v___x_2925_, 1);
lean_ctor_set(v___x_2925_, 0, v___x_3006_);
v___x_3008_ = v___x_2925_;
goto v_reusejp_3007_;
}
else
{
lean_object* v_reuseFailAlloc_3009_; 
v_reuseFailAlloc_3009_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3009_, 0, v___x_3006_);
v___x_3008_ = v_reuseFailAlloc_3009_;
goto v_reusejp_3007_;
}
v_reusejp_3007_:
{
return v___x_3008_;
}
}
}
else
{
uint8_t v___x_3011_; 
lean_del_object(v___x_2932_);
lean_del_object(v___x_2925_);
lean_dec_ref(v_s_2923_);
v___x_3011_ = 3;
v_kind_2961_ = v___x_3011_;
v_stream_2962_ = v_stream_2944_;
v_nameMap_2963_ = v_nameMap_2945_;
v_levelMap_2964_ = v_levelMap_2946_;
v_exprMap_2965_ = v_exprMap_2947_;
v_recursorRuleMap_2966_ = v_recursorRuleMap_2948_;
v_constMap_2967_ = v_constMap_2949_;
v_constOrder_2968_ = v_constOrder_2950_;
goto v___jp_2960_;
}
}
else
{
uint8_t v___x_3012_; 
lean_del_object(v___x_2932_);
lean_del_object(v___x_2925_);
lean_dec_ref(v_s_2923_);
v___x_3012_ = 2;
v_kind_2961_ = v___x_3012_;
v_stream_2962_ = v_stream_2944_;
v_nameMap_2963_ = v_nameMap_2945_;
v_levelMap_2964_ = v_levelMap_2946_;
v_exprMap_2965_ = v_exprMap_2947_;
v_recursorRuleMap_2966_ = v_recursorRuleMap_2948_;
v_constMap_2967_ = v_constMap_2949_;
v_constOrder_2968_ = v_constOrder_2950_;
goto v___jp_2960_;
}
}
else
{
uint8_t v___x_3013_; 
lean_del_object(v___x_2932_);
lean_del_object(v___x_2925_);
lean_dec_ref(v_s_2923_);
v___x_3013_ = 1;
v_kind_2961_ = v___x_3013_;
v_stream_2962_ = v_stream_2944_;
v_nameMap_2963_ = v_nameMap_2945_;
v_levelMap_2964_ = v_levelMap_2946_;
v_exprMap_2965_ = v_exprMap_2947_;
v_recursorRuleMap_2966_ = v_recursorRuleMap_2948_;
v_constMap_2967_ = v_constMap_2949_;
v_constOrder_2968_ = v_constOrder_2950_;
goto v___jp_2960_;
}
}
else
{
uint8_t v___x_3014_; 
lean_del_object(v___x_2932_);
lean_del_object(v___x_2925_);
lean_dec_ref(v_s_2923_);
v___x_3014_ = 0;
v_kind_2961_ = v___x_3014_;
v_stream_2962_ = v_stream_2944_;
v_nameMap_2963_ = v_nameMap_2945_;
v_levelMap_2964_ = v_levelMap_2946_;
v_exprMap_2965_ = v_exprMap_2947_;
v_recursorRuleMap_2966_ = v_recursorRuleMap_2948_;
v_constMap_2967_ = v_constMap_2949_;
v_constOrder_2968_ = v_constOrder_2950_;
goto v___jp_2960_;
}
v___jp_2960_:
{
uint8_t v___x_2969_; 
v___x_2969_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_2967_, v_val_2930_);
if (v___x_2969_ == 0)
{
lean_object* v___x_2970_; lean_object* v___x_2971_; lean_object* v___x_2973_; 
lean_inc(v_val_2930_);
v___x_2970_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2970_, 0, v_val_2930_);
lean_ctor_set(v___x_2970_, 1, v_fst_2940_);
lean_ctor_set(v___x_2970_, 2, v_val_2956_);
v___x_2971_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2971_, 0, v___x_2970_);
lean_ctor_set_uint8(v___x_2971_, sizeof(void*)*1, v_kind_2961_);
if (v_isShared_2959_ == 0)
{
lean_ctor_set_tag(v___x_2958_, 4);
lean_ctor_set(v___x_2958_, 0, v___x_2971_);
v___x_2973_ = v___x_2958_;
goto v_reusejp_2972_;
}
else
{
lean_object* v_reuseFailAlloc_2986_; 
v_reuseFailAlloc_2986_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2986_, 0, v___x_2971_);
v___x_2973_ = v_reuseFailAlloc_2986_;
goto v_reusejp_2972_;
}
v_reusejp_2972_:
{
lean_object* v___x_2974_; lean_object* v___x_2975_; lean_object* v___x_2976_; lean_object* v___x_2978_; 
v___x_2974_ = lean_box(0);
lean_inc(v_val_2930_);
v___x_2975_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_2967_, v_val_2930_, v___x_2973_);
v___x_2976_ = lean_array_push(v_constOrder_2968_, v_val_2930_);
if (v_isShared_2953_ == 0)
{
lean_ctor_set(v___x_2952_, 6, v___x_2976_);
lean_ctor_set(v___x_2952_, 5, v___x_2975_);
lean_ctor_set(v___x_2952_, 4, v_recursorRuleMap_2966_);
lean_ctor_set(v___x_2952_, 3, v_exprMap_2965_);
lean_ctor_set(v___x_2952_, 2, v_levelMap_2964_);
lean_ctor_set(v___x_2952_, 1, v_nameMap_2963_);
lean_ctor_set(v___x_2952_, 0, v_stream_2962_);
v___x_2978_ = v___x_2952_;
goto v_reusejp_2977_;
}
else
{
lean_object* v_reuseFailAlloc_2985_; 
v_reuseFailAlloc_2985_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_2985_, 0, v_stream_2962_);
lean_ctor_set(v_reuseFailAlloc_2985_, 1, v_nameMap_2963_);
lean_ctor_set(v_reuseFailAlloc_2985_, 2, v_levelMap_2964_);
lean_ctor_set(v_reuseFailAlloc_2985_, 3, v_exprMap_2965_);
lean_ctor_set(v_reuseFailAlloc_2985_, 4, v_recursorRuleMap_2966_);
lean_ctor_set(v_reuseFailAlloc_2985_, 5, v___x_2975_);
lean_ctor_set(v_reuseFailAlloc_2985_, 6, v___x_2976_);
v___x_2978_ = v_reuseFailAlloc_2985_;
goto v_reusejp_2977_;
}
v_reusejp_2977_:
{
lean_object* v___x_2980_; 
if (v_isShared_2943_ == 0)
{
lean_ctor_set(v___x_2942_, 1, v___x_2978_);
lean_ctor_set(v___x_2942_, 0, v___x_2974_);
v___x_2980_ = v___x_2942_;
goto v_reusejp_2979_;
}
else
{
lean_object* v_reuseFailAlloc_2984_; 
v_reuseFailAlloc_2984_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2984_, 0, v___x_2974_);
lean_ctor_set(v_reuseFailAlloc_2984_, 1, v___x_2978_);
v___x_2980_ = v_reuseFailAlloc_2984_;
goto v_reusejp_2979_;
}
v_reusejp_2979_:
{
lean_object* v___x_2982_; 
if (v_isShared_2938_ == 0)
{
lean_ctor_set(v___x_2937_, 0, v___x_2980_);
v___x_2982_ = v___x_2937_;
goto v_reusejp_2981_;
}
else
{
lean_object* v_reuseFailAlloc_2983_; 
v_reuseFailAlloc_2983_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2983_, 0, v___x_2980_);
v___x_2982_ = v_reuseFailAlloc_2983_;
goto v_reusejp_2981_;
}
v_reusejp_2981_:
{
return v___x_2982_;
}
}
}
}
}
else
{
lean_object* v___x_2987_; lean_object* v___x_2988_; lean_object* v___x_2989_; lean_object* v___x_2991_; 
lean_dec_ref(v_constOrder_2968_);
lean_dec_ref(v_constMap_2967_);
lean_dec_ref(v_recursorRuleMap_2966_);
lean_dec_ref(v_exprMap_2965_);
lean_dec_ref(v_levelMap_2964_);
lean_dec_ref(v_nameMap_2963_);
lean_dec_ref(v_stream_2962_);
lean_dec(v_val_2956_);
lean_del_object(v___x_2952_);
lean_del_object(v___x_2942_);
lean_dec(v_fst_2940_);
v___x_2987_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_2988_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_2930_, v___x_2969_);
v___x_2989_ = lean_string_append(v___x_2987_, v___x_2988_);
lean_dec_ref(v___x_2988_);
if (v_isShared_2959_ == 0)
{
lean_ctor_set_tag(v___x_2958_, 18);
lean_ctor_set(v___x_2958_, 0, v___x_2989_);
v___x_2991_ = v___x_2958_;
goto v_reusejp_2990_;
}
else
{
lean_object* v_reuseFailAlloc_2995_; 
v_reuseFailAlloc_2995_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2995_, 0, v___x_2989_);
v___x_2991_ = v_reuseFailAlloc_2995_;
goto v_reusejp_2990_;
}
v_reusejp_2990_:
{
lean_object* v___x_2993_; 
if (v_isShared_2938_ == 0)
{
lean_ctor_set_tag(v___x_2937_, 1);
lean_ctor_set(v___x_2937_, 0, v___x_2991_);
v___x_2993_ = v___x_2937_;
goto v_reusejp_2992_;
}
else
{
lean_object* v_reuseFailAlloc_2994_; 
v_reuseFailAlloc_2994_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2994_, 0, v___x_2991_);
v___x_2993_ = v_reuseFailAlloc_2994_;
goto v_reusejp_2992_;
}
v_reusejp_2992_:
{
return v___x_2993_;
}
}
}
}
}
}
else
{
lean_object* v___x_3016_; lean_object* v___x_3017_; lean_object* v___x_3018_; lean_object* v___x_3020_; 
lean_dec(v___x_2955_);
lean_del_object(v___x_2952_);
lean_dec_ref(v_constOrder_2950_);
lean_dec_ref(v_constMap_2949_);
lean_dec_ref(v_recursorRuleMap_2948_);
lean_dec_ref(v_exprMap_2947_);
lean_dec_ref(v_levelMap_2946_);
lean_dec_ref(v_nameMap_2945_);
lean_dec_ref(v_stream_2944_);
lean_del_object(v___x_2942_);
lean_dec(v_fst_2940_);
lean_dec(v_val_2930_);
lean_del_object(v___x_2925_);
lean_dec_ref(v_s_2923_);
v___x_3016_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_3017_ = l_Nat_reprFast(v_a_2954_);
v___x_3018_ = lean_string_append(v___x_3016_, v___x_3017_);
lean_dec_ref(v___x_3017_);
if (v_isShared_2933_ == 0)
{
lean_ctor_set_tag(v___x_2932_, 18);
lean_ctor_set(v___x_2932_, 0, v___x_3018_);
v___x_3020_ = v___x_2932_;
goto v_reusejp_3019_;
}
else
{
lean_object* v_reuseFailAlloc_3024_; 
v_reuseFailAlloc_3024_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3024_, 0, v___x_3018_);
v___x_3020_ = v_reuseFailAlloc_3024_;
goto v_reusejp_3019_;
}
v_reusejp_3019_:
{
lean_object* v___x_3022_; 
if (v_isShared_2938_ == 0)
{
lean_ctor_set_tag(v___x_2937_, 1);
lean_ctor_set(v___x_2937_, 0, v___x_3020_);
v___x_3022_ = v___x_2937_;
goto v_reusejp_3021_;
}
else
{
lean_object* v_reuseFailAlloc_3023_; 
v_reuseFailAlloc_3023_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3023_, 0, v___x_3020_);
v___x_3022_ = v_reuseFailAlloc_3023_;
goto v_reusejp_3021_;
}
v_reusejp_3021_:
{
return v___x_3022_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3028_; lean_object* v___x_3030_; uint8_t v_isShared_3031_; uint8_t v_isSharedCheck_3035_; 
lean_del_object(v___x_2932_);
lean_dec(v_val_2930_);
lean_del_object(v___x_2925_);
lean_dec_ref(v_s_2923_);
lean_dec(v_mantissa_2913_);
v_a_3028_ = lean_ctor_get(v___x_2934_, 0);
v_isSharedCheck_3035_ = !lean_is_exclusive(v___x_2934_);
if (v_isSharedCheck_3035_ == 0)
{
v___x_3030_ = v___x_2934_;
v_isShared_3031_ = v_isSharedCheck_3035_;
goto v_resetjp_3029_;
}
else
{
lean_inc(v_a_3028_);
lean_dec(v___x_2934_);
v___x_3030_ = lean_box(0);
v_isShared_3031_ = v_isSharedCheck_3035_;
goto v_resetjp_3029_;
}
v_resetjp_3029_:
{
lean_object* v___x_3033_; 
if (v_isShared_3031_ == 0)
{
v___x_3033_ = v___x_3030_;
goto v_reusejp_3032_;
}
else
{
lean_object* v_reuseFailAlloc_3034_; 
v_reuseFailAlloc_3034_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3034_, 0, v_a_3028_);
v___x_3033_ = v_reuseFailAlloc_3034_;
goto v_reusejp_3032_;
}
v_reusejp_3032_:
{
return v___x_3033_;
}
}
}
}
}
else
{
lean_object* v___x_3037_; lean_object* v___x_3038_; lean_object* v___x_3039_; lean_object* v___x_3041_; 
lean_dec(v___x_2929_);
lean_dec_ref(v_s_2923_);
lean_dec(v_mantissa_2913_);
lean_dec_ref(v_elems_2908_);
lean_dec_ref(v_a_2881_);
v___x_3037_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_3038_ = l_Nat_reprFast(v_a_2928_);
v___x_3039_ = lean_string_append(v___x_3037_, v___x_3038_);
lean_dec_ref(v___x_3038_);
if (v_isShared_2926_ == 0)
{
lean_ctor_set_tag(v___x_2925_, 18);
lean_ctor_set(v___x_2925_, 0, v___x_3039_);
v___x_3041_ = v___x_2925_;
goto v_reusejp_3040_;
}
else
{
lean_object* v_reuseFailAlloc_3045_; 
v_reuseFailAlloc_3045_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3045_, 0, v___x_3039_);
v___x_3041_ = v_reuseFailAlloc_3045_;
goto v_reusejp_3040_;
}
v_reusejp_3040_:
{
lean_object* v___x_3043_; 
if (v_isShared_2922_ == 0)
{
lean_ctor_set(v___x_2921_, 0, v___x_3041_);
v___x_3043_ = v___x_2921_;
goto v_reusejp_3042_;
}
else
{
lean_object* v_reuseFailAlloc_3044_; 
v_reuseFailAlloc_3044_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3044_, 0, v___x_3041_);
v___x_3043_ = v_reuseFailAlloc_3044_;
goto v_reusejp_3042_;
}
v_reusejp_3042_:
{
return v___x_3043_;
}
}
}
}
}
else
{
lean_del_object(v___x_2921_);
lean_dec(v_val_2919_);
lean_dec(v_mantissa_2913_);
lean_dec_ref(v_elems_2908_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2883_;
}
}
}
else
{
lean_dec(v___x_2918_);
lean_dec(v_mantissa_2913_);
lean_dec_ref(v_elems_2908_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2883_;
}
}
}
else
{
lean_dec(v_exponent_2914_);
lean_dec(v_mantissa_2913_);
lean_dec_ref(v_elems_2908_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2886_;
}
}
else
{
lean_dec(v_val_2911_);
lean_dec_ref(v_elems_2908_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2886_;
}
}
else
{
lean_dec(v___x_2910_);
lean_dec_ref(v_elems_2908_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2886_;
}
}
else
{
lean_dec(v_val_2907_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2889_;
}
}
else
{
lean_dec(v___x_2906_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2889_;
}
}
}
else
{
lean_dec(v_exponent_2900_);
lean_dec(v_mantissa_2899_);
lean_dec_ref(v_a_2881_);
goto v___jp_2892_;
}
}
else
{
lean_dec(v_val_2897_);
lean_dec_ref(v_a_2881_);
goto v___jp_2892_;
}
}
else
{
lean_dec(v___x_2896_);
lean_dec_ref(v_a_2881_);
goto v___jp_2892_;
}
v___jp_2883_:
{
lean_object* v___x_2884_; lean_object* v___x_2885_; 
v___x_2884_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1));
v___x_2885_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2885_, 0, v___x_2884_);
return v___x_2885_;
}
v___jp_2886_:
{
lean_object* v___x_2887_; lean_object* v___x_2888_; 
v___x_2887_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1));
v___x_2888_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2888_, 0, v___x_2887_);
return v___x_2888_;
}
v___jp_2889_:
{
lean_object* v___x_2890_; lean_object* v___x_2891_; 
v___x_2890_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1));
v___x_2891_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2891_, 0, v___x_2890_);
return v___x_2891_;
}
v___jp_2892_:
{
lean_object* v___x_2893_; lean_object* v___x_2894_; 
v___x_2893_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__1));
v___x_2894_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2894_, 0, v___x_2893_);
return v___x_2894_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseQuotInfo___boxed(lean_object* v_data_3048_, lean_object* v_a_3049_, lean_object* v_a_3050_){
_start:
{
lean_object* v_res_3051_; 
v_res_3051_ = lp_proofEnvironment_Export_Parse_parseQuotInfo(v_data_3048_, v_a_3049_);
lean_dec(v_data_3048_);
return v_res_3051_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo(lean_object* v_json_3064_, lean_object* v_a_3065_){
_start:
{
if (lean_obj_tag(v_json_3064_) == 5)
{
lean_object* v_kvPairs_3100_; lean_object* v___x_3101_; lean_object* v___x_3102_; 
v_kvPairs_3100_ = lean_ctor_get(v_json_3064_, 0);
v___x_3101_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_3102_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3101_);
if (lean_obj_tag(v___x_3102_) == 1)
{
lean_object* v_val_3103_; 
v_val_3103_ = lean_ctor_get(v___x_3102_, 0);
lean_inc(v_val_3103_);
lean_dec_ref_known(v___x_3102_, 1);
if (lean_obj_tag(v_val_3103_) == 2)
{
lean_object* v_n_3104_; lean_object* v_mantissa_3105_; lean_object* v_exponent_3106_; lean_object* v_natZero_3107_; lean_object* v_intZero_3108_; uint8_t v_isNeg_3109_; 
v_n_3104_ = lean_ctor_get(v_val_3103_, 0);
lean_inc_ref(v_n_3104_);
lean_dec_ref_known(v_val_3103_, 1);
v_mantissa_3105_ = lean_ctor_get(v_n_3104_, 0);
lean_inc(v_mantissa_3105_);
v_exponent_3106_ = lean_ctor_get(v_n_3104_, 1);
lean_inc(v_exponent_3106_);
lean_dec_ref(v_n_3104_);
v_natZero_3107_ = lean_unsigned_to_nat(0u);
v_intZero_3108_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_3109_ = lean_int_dec_lt(v_mantissa_3105_, v_intZero_3108_);
if (v_isNeg_3109_ == 0)
{
uint8_t v___x_3110_; 
v___x_3110_ = lean_nat_dec_eq(v_exponent_3106_, v_natZero_3107_);
lean_dec(v_exponent_3106_);
if (v___x_3110_ == 0)
{
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3067_;
}
else
{
lean_object* v___x_3111_; lean_object* v___x_3112_; 
v___x_3111_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_3112_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3111_);
if (lean_obj_tag(v___x_3112_) == 1)
{
lean_object* v_val_3113_; 
v_val_3113_ = lean_ctor_get(v___x_3112_, 0);
lean_inc(v_val_3113_);
lean_dec_ref_known(v___x_3112_, 1);
if (lean_obj_tag(v_val_3113_) == 4)
{
lean_object* v_elems_3114_; lean_object* v___x_3115_; lean_object* v___x_3116_; 
v_elems_3114_ = lean_ctor_get(v_val_3113_, 0);
lean_inc_ref(v_elems_3114_);
lean_dec_ref_known(v_val_3113_, 1);
v___x_3115_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_3116_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3115_);
if (lean_obj_tag(v___x_3116_) == 1)
{
lean_object* v_val_3117_; 
v_val_3117_ = lean_ctor_get(v___x_3116_, 0);
lean_inc(v_val_3117_);
lean_dec_ref_known(v___x_3116_, 1);
if (lean_obj_tag(v_val_3117_) == 2)
{
lean_object* v_n_3118_; lean_object* v_mantissa_3119_; lean_object* v_exponent_3120_; uint8_t v_isNeg_3121_; 
v_n_3118_ = lean_ctor_get(v_val_3117_, 0);
lean_inc_ref(v_n_3118_);
lean_dec_ref_known(v_val_3117_, 1);
v_mantissa_3119_ = lean_ctor_get(v_n_3118_, 0);
lean_inc(v_mantissa_3119_);
v_exponent_3120_ = lean_ctor_get(v_n_3118_, 1);
lean_inc(v_exponent_3120_);
lean_dec_ref(v_n_3118_);
v_isNeg_3121_ = lean_int_dec_lt(v_mantissa_3119_, v_intZero_3108_);
if (v_isNeg_3121_ == 0)
{
uint8_t v___x_3122_; 
v___x_3122_ = lean_nat_dec_eq(v_exponent_3120_, v_natZero_3107_);
lean_dec(v_exponent_3120_);
if (v___x_3122_ == 0)
{
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3073_;
}
else
{
lean_object* v___x_3123_; lean_object* v___x_3124_; 
v___x_3123_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__2));
v___x_3124_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3123_);
if (lean_obj_tag(v___x_3124_) == 1)
{
lean_object* v_val_3125_; 
v_val_3125_ = lean_ctor_get(v___x_3124_, 0);
lean_inc(v_val_3125_);
lean_dec_ref_known(v___x_3124_, 1);
if (lean_obj_tag(v_val_3125_) == 2)
{
lean_object* v_n_3126_; lean_object* v_mantissa_3127_; lean_object* v_exponent_3128_; uint8_t v_isNeg_3129_; 
v_n_3126_ = lean_ctor_get(v_val_3125_, 0);
lean_inc_ref(v_n_3126_);
lean_dec_ref_known(v_val_3125_, 1);
v_mantissa_3127_ = lean_ctor_get(v_n_3126_, 0);
lean_inc(v_mantissa_3127_);
v_exponent_3128_ = lean_ctor_get(v_n_3126_, 1);
lean_inc(v_exponent_3128_);
lean_dec_ref(v_n_3126_);
v_isNeg_3129_ = lean_int_dec_lt(v_mantissa_3127_, v_intZero_3108_);
if (v_isNeg_3129_ == 0)
{
uint8_t v___x_3130_; 
v___x_3130_ = lean_nat_dec_eq(v_exponent_3128_, v_natZero_3107_);
lean_dec(v_exponent_3128_);
if (v___x_3130_ == 0)
{
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3076_;
}
else
{
lean_object* v___x_3131_; lean_object* v___x_3132_; 
v___x_3131_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__3));
v___x_3132_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3131_);
if (lean_obj_tag(v___x_3132_) == 1)
{
lean_object* v_val_3133_; 
v_val_3133_ = lean_ctor_get(v___x_3132_, 0);
lean_inc(v_val_3133_);
lean_dec_ref_known(v___x_3132_, 1);
if (lean_obj_tag(v_val_3133_) == 2)
{
lean_object* v_n_3134_; lean_object* v_mantissa_3135_; lean_object* v_exponent_3136_; uint8_t v_isNeg_3137_; 
v_n_3134_ = lean_ctor_get(v_val_3133_, 0);
lean_inc_ref(v_n_3134_);
lean_dec_ref_known(v_val_3133_, 1);
v_mantissa_3135_ = lean_ctor_get(v_n_3134_, 0);
lean_inc(v_mantissa_3135_);
v_exponent_3136_ = lean_ctor_get(v_n_3134_, 1);
lean_inc(v_exponent_3136_);
lean_dec_ref(v_n_3134_);
v_isNeg_3137_ = lean_int_dec_lt(v_mantissa_3135_, v_intZero_3108_);
if (v_isNeg_3137_ == 0)
{
uint8_t v___x_3138_; 
v___x_3138_ = lean_nat_dec_eq(v_exponent_3136_, v_natZero_3107_);
lean_dec(v_exponent_3136_);
if (v___x_3138_ == 0)
{
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3079_;
}
else
{
lean_object* v___x_3139_; lean_object* v___x_3140_; 
v___x_3139_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4));
v___x_3140_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3139_);
if (lean_obj_tag(v___x_3140_) == 1)
{
lean_object* v_val_3141_; 
v_val_3141_ = lean_ctor_get(v___x_3140_, 0);
lean_inc(v_val_3141_);
lean_dec_ref_known(v___x_3140_, 1);
if (lean_obj_tag(v_val_3141_) == 4)
{
lean_object* v_elems_3142_; lean_object* v___x_3143_; lean_object* v___x_3144_; 
v_elems_3142_ = lean_ctor_get(v_val_3141_, 0);
lean_inc_ref(v_elems_3142_);
lean_dec_ref_known(v_val_3141_, 1);
v___x_3143_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__4));
v___x_3144_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3143_);
if (lean_obj_tag(v___x_3144_) == 1)
{
lean_object* v_val_3145_; 
v_val_3145_ = lean_ctor_get(v___x_3144_, 0);
lean_inc(v_val_3145_);
lean_dec_ref_known(v___x_3144_, 1);
if (lean_obj_tag(v_val_3145_) == 4)
{
lean_object* v_elems_3146_; lean_object* v___x_3147_; lean_object* v___x_3148_; 
v_elems_3146_ = lean_ctor_get(v_val_3145_, 0);
lean_inc_ref(v_elems_3146_);
lean_dec_ref_known(v_val_3145_, 1);
v___x_3147_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__5));
v___x_3148_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3147_);
if (lean_obj_tag(v___x_3148_) == 1)
{
lean_object* v_val_3149_; 
v_val_3149_ = lean_ctor_get(v___x_3148_, 0);
lean_inc(v_val_3149_);
lean_dec_ref_known(v___x_3148_, 1);
if (lean_obj_tag(v_val_3149_) == 2)
{
lean_object* v_n_3150_; lean_object* v_mantissa_3151_; lean_object* v_exponent_3152_; uint8_t v_isNeg_3153_; 
v_n_3150_ = lean_ctor_get(v_val_3149_, 0);
lean_inc_ref(v_n_3150_);
lean_dec_ref_known(v_val_3149_, 1);
v_mantissa_3151_ = lean_ctor_get(v_n_3150_, 0);
lean_inc(v_mantissa_3151_);
v_exponent_3152_ = lean_ctor_get(v_n_3150_, 1);
lean_inc(v_exponent_3152_);
lean_dec_ref(v_n_3150_);
v_isNeg_3153_ = lean_int_dec_lt(v_mantissa_3151_, v_intZero_3108_);
if (v_isNeg_3153_ == 0)
{
uint8_t v___x_3154_; 
v___x_3154_ = lean_nat_dec_eq(v_exponent_3152_, v_natZero_3107_);
lean_dec(v_exponent_3152_);
if (v___x_3154_ == 0)
{
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3088_;
}
else
{
lean_object* v___x_3155_; lean_object* v___x_3156_; 
v___x_3155_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__6));
v___x_3156_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3155_);
if (lean_obj_tag(v___x_3156_) == 1)
{
lean_object* v_val_3157_; 
v_val_3157_ = lean_ctor_get(v___x_3156_, 0);
lean_inc(v_val_3157_);
lean_dec_ref_known(v___x_3156_, 1);
if (lean_obj_tag(v_val_3157_) == 1)
{
uint8_t v_b_3158_; lean_object* v___x_3159_; lean_object* v___x_3160_; 
v_b_3158_ = lean_ctor_get_uint8(v_val_3157_, 0);
lean_dec_ref_known(v_val_3157_, 0);
v___x_3159_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3));
v___x_3160_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3159_);
if (lean_obj_tag(v___x_3160_) == 1)
{
lean_object* v_val_3161_; lean_object* v___x_3163_; uint8_t v_isShared_3164_; uint8_t v_isSharedCheck_3297_; 
v_val_3161_ = lean_ctor_get(v___x_3160_, 0);
v_isSharedCheck_3297_ = !lean_is_exclusive(v___x_3160_);
if (v_isSharedCheck_3297_ == 0)
{
v___x_3163_ = v___x_3160_;
v_isShared_3164_ = v_isSharedCheck_3297_;
goto v_resetjp_3162_;
}
else
{
lean_inc(v_val_3161_);
lean_dec(v___x_3160_);
v___x_3163_ = lean_box(0);
v_isShared_3164_ = v_isSharedCheck_3297_;
goto v_resetjp_3162_;
}
v_resetjp_3162_:
{
if (lean_obj_tag(v_val_3161_) == 1)
{
uint8_t v_b_3165_; lean_object* v___x_3166_; lean_object* v___x_3167_; 
v_b_3165_ = lean_ctor_get_uint8(v_val_3161_, 0);
lean_dec_ref_known(v_val_3161_, 0);
v___x_3166_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__7));
v___x_3167_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3100_, v___x_3166_);
if (lean_obj_tag(v___x_3167_) == 1)
{
lean_object* v_val_3168_; lean_object* v___x_3170_; uint8_t v_isShared_3171_; uint8_t v_isSharedCheck_3296_; 
v_val_3168_ = lean_ctor_get(v___x_3167_, 0);
v_isSharedCheck_3296_ = !lean_is_exclusive(v___x_3167_);
if (v_isSharedCheck_3296_ == 0)
{
v___x_3170_ = v___x_3167_;
v_isShared_3171_ = v_isSharedCheck_3296_;
goto v_resetjp_3169_;
}
else
{
lean_inc(v_val_3168_);
lean_dec(v___x_3167_);
v___x_3170_ = lean_box(0);
v_isShared_3171_ = v_isSharedCheck_3296_;
goto v_resetjp_3169_;
}
v_resetjp_3169_:
{
if (lean_obj_tag(v_val_3168_) == 1)
{
uint8_t v_b_3172_; lean_object* v_nameMap_3173_; lean_object* v_a_3174_; lean_object* v___x_3175_; 
v_b_3172_ = lean_ctor_get_uint8(v_val_3168_, 0);
lean_dec_ref_known(v_val_3168_, 0);
v_nameMap_3173_ = lean_ctor_get(v_a_3065_, 1);
v_a_3174_ = lean_nat_abs(v_mantissa_3105_);
lean_dec(v_mantissa_3105_);
v___x_3175_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_3173_, v_a_3174_);
if (lean_obj_tag(v___x_3175_) == 1)
{
lean_object* v_val_3176_; lean_object* v___x_3178_; uint8_t v_isShared_3179_; uint8_t v_isSharedCheck_3286_; 
lean_dec(v_a_3174_);
lean_del_object(v___x_3170_);
lean_del_object(v___x_3163_);
v_val_3176_ = lean_ctor_get(v___x_3175_, 0);
v_isSharedCheck_3286_ = !lean_is_exclusive(v___x_3175_);
if (v_isSharedCheck_3286_ == 0)
{
v___x_3178_ = v___x_3175_;
v_isShared_3179_ = v_isSharedCheck_3286_;
goto v_resetjp_3177_;
}
else
{
lean_inc(v_val_3176_);
lean_dec(v___x_3175_);
v___x_3178_ = lean_box(0);
v_isShared_3179_ = v_isSharedCheck_3286_;
goto v_resetjp_3177_;
}
v_resetjp_3177_:
{
lean_object* v___x_3180_; 
v___x_3180_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_3114_, v_a_3065_);
if (lean_obj_tag(v___x_3180_) == 0)
{
lean_object* v_a_3181_; lean_object* v___x_3183_; uint8_t v_isShared_3184_; uint8_t v_isSharedCheck_3277_; 
v_a_3181_ = lean_ctor_get(v___x_3180_, 0);
v_isSharedCheck_3277_ = !lean_is_exclusive(v___x_3180_);
if (v_isSharedCheck_3277_ == 0)
{
v___x_3183_ = v___x_3180_;
v_isShared_3184_ = v_isSharedCheck_3277_;
goto v_resetjp_3182_;
}
else
{
lean_inc(v_a_3181_);
lean_dec(v___x_3180_);
v___x_3183_ = lean_box(0);
v_isShared_3184_ = v_isSharedCheck_3277_;
goto v_resetjp_3182_;
}
v_resetjp_3182_:
{
lean_object* v_snd_3185_; lean_object* v_fst_3186_; lean_object* v_exprMap_3187_; lean_object* v_a_3188_; lean_object* v___x_3189_; 
v_snd_3185_ = lean_ctor_get(v_a_3181_, 1);
lean_inc(v_snd_3185_);
v_fst_3186_ = lean_ctor_get(v_a_3181_, 0);
lean_inc(v_fst_3186_);
lean_dec(v_a_3181_);
v_exprMap_3187_ = lean_ctor_get(v_snd_3185_, 3);
v_a_3188_ = lean_nat_abs(v_mantissa_3119_);
lean_dec(v_mantissa_3119_);
v___x_3189_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_3187_, v_a_3188_);
if (lean_obj_tag(v___x_3189_) == 1)
{
lean_object* v_val_3190_; lean_object* v___x_3192_; uint8_t v_isShared_3193_; uint8_t v_isSharedCheck_3267_; 
lean_dec(v_a_3188_);
lean_del_object(v___x_3183_);
lean_del_object(v___x_3178_);
v_val_3190_ = lean_ctor_get(v___x_3189_, 0);
v_isSharedCheck_3267_ = !lean_is_exclusive(v___x_3189_);
if (v_isSharedCheck_3267_ == 0)
{
v___x_3192_ = v___x_3189_;
v_isShared_3193_ = v_isSharedCheck_3267_;
goto v_resetjp_3191_;
}
else
{
lean_inc(v_val_3190_);
lean_dec(v___x_3189_);
v___x_3192_ = lean_box(0);
v_isShared_3193_ = v_isSharedCheck_3267_;
goto v_resetjp_3191_;
}
v_resetjp_3191_:
{
lean_object* v___x_3194_; 
v___x_3194_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_3142_, v_snd_3185_);
if (lean_obj_tag(v___x_3194_) == 0)
{
lean_object* v_a_3195_; lean_object* v_fst_3196_; lean_object* v_snd_3197_; lean_object* v___x_3198_; 
v_a_3195_ = lean_ctor_get(v___x_3194_, 0);
lean_inc(v_a_3195_);
lean_dec_ref_known(v___x_3194_, 1);
v_fst_3196_ = lean_ctor_get(v_a_3195_, 0);
lean_inc(v_fst_3196_);
v_snd_3197_ = lean_ctor_get(v_a_3195_, 1);
lean_inc(v_snd_3197_);
lean_dec(v_a_3195_);
v___x_3198_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_3146_, v_snd_3197_);
if (lean_obj_tag(v___x_3198_) == 0)
{
lean_object* v_a_3199_; lean_object* v___x_3201_; uint8_t v_isShared_3202_; uint8_t v_isSharedCheck_3250_; 
v_a_3199_ = lean_ctor_get(v___x_3198_, 0);
v_isSharedCheck_3250_ = !lean_is_exclusive(v___x_3198_);
if (v_isSharedCheck_3250_ == 0)
{
v___x_3201_ = v___x_3198_;
v_isShared_3202_ = v_isSharedCheck_3250_;
goto v_resetjp_3200_;
}
else
{
lean_inc(v_a_3199_);
lean_dec(v___x_3198_);
v___x_3201_ = lean_box(0);
v_isShared_3202_ = v_isSharedCheck_3250_;
goto v_resetjp_3200_;
}
v_resetjp_3200_:
{
lean_object* v_snd_3203_; lean_object* v_fst_3204_; lean_object* v___x_3206_; uint8_t v_isShared_3207_; uint8_t v_isSharedCheck_3249_; 
v_snd_3203_ = lean_ctor_get(v_a_3199_, 1);
v_fst_3204_ = lean_ctor_get(v_a_3199_, 0);
v_isSharedCheck_3249_ = !lean_is_exclusive(v_a_3199_);
if (v_isSharedCheck_3249_ == 0)
{
v___x_3206_ = v_a_3199_;
v_isShared_3207_ = v_isSharedCheck_3249_;
goto v_resetjp_3205_;
}
else
{
lean_inc(v_snd_3203_);
lean_inc(v_fst_3204_);
lean_dec(v_a_3199_);
v___x_3206_ = lean_box(0);
v_isShared_3207_ = v_isSharedCheck_3249_;
goto v_resetjp_3205_;
}
v_resetjp_3205_:
{
lean_object* v_stream_3208_; lean_object* v_nameMap_3209_; lean_object* v_levelMap_3210_; lean_object* v_exprMap_3211_; lean_object* v_recursorRuleMap_3212_; lean_object* v_constMap_3213_; lean_object* v_constOrder_3214_; lean_object* v___x_3216_; uint8_t v_isShared_3217_; uint8_t v_isSharedCheck_3248_; 
v_stream_3208_ = lean_ctor_get(v_snd_3203_, 0);
v_nameMap_3209_ = lean_ctor_get(v_snd_3203_, 1);
v_levelMap_3210_ = lean_ctor_get(v_snd_3203_, 2);
v_exprMap_3211_ = lean_ctor_get(v_snd_3203_, 3);
v_recursorRuleMap_3212_ = lean_ctor_get(v_snd_3203_, 4);
v_constMap_3213_ = lean_ctor_get(v_snd_3203_, 5);
v_constOrder_3214_ = lean_ctor_get(v_snd_3203_, 6);
v_isSharedCheck_3248_ = !lean_is_exclusive(v_snd_3203_);
if (v_isSharedCheck_3248_ == 0)
{
v___x_3216_ = v_snd_3203_;
v_isShared_3217_ = v_isSharedCheck_3248_;
goto v_resetjp_3215_;
}
else
{
lean_inc(v_constOrder_3214_);
lean_inc(v_constMap_3213_);
lean_inc(v_recursorRuleMap_3212_);
lean_inc(v_exprMap_3211_);
lean_inc(v_levelMap_3210_);
lean_inc(v_nameMap_3209_);
lean_inc(v_stream_3208_);
lean_dec(v_snd_3203_);
v___x_3216_ = lean_box(0);
v_isShared_3217_ = v_isSharedCheck_3248_;
goto v_resetjp_3215_;
}
v_resetjp_3215_:
{
uint8_t v___x_3218_; 
v___x_3218_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_3213_, v_val_3176_);
if (v___x_3218_ == 0)
{
lean_object* v_a_3219_; lean_object* v_a_3220_; lean_object* v_a_3221_; lean_object* v___x_3222_; lean_object* v___x_3223_; lean_object* v___x_3225_; 
v_a_3219_ = lean_nat_abs(v_mantissa_3127_);
lean_dec(v_mantissa_3127_);
v_a_3220_ = lean_nat_abs(v_mantissa_3135_);
lean_dec(v_mantissa_3135_);
v_a_3221_ = lean_nat_abs(v_mantissa_3151_);
lean_dec(v_mantissa_3151_);
lean_inc(v_val_3176_);
v___x_3222_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3222_, 0, v_val_3176_);
lean_ctor_set(v___x_3222_, 1, v_fst_3186_);
lean_ctor_set(v___x_3222_, 2, v_val_3190_);
v___x_3223_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_3223_, 0, v___x_3222_);
lean_ctor_set(v___x_3223_, 1, v_a_3219_);
lean_ctor_set(v___x_3223_, 2, v_a_3220_);
lean_ctor_set(v___x_3223_, 3, v_fst_3196_);
lean_ctor_set(v___x_3223_, 4, v_fst_3204_);
lean_ctor_set(v___x_3223_, 5, v_a_3221_);
lean_ctor_set_uint8(v___x_3223_, sizeof(void*)*6, v_b_3158_);
lean_ctor_set_uint8(v___x_3223_, sizeof(void*)*6 + 1, v_b_3165_);
lean_ctor_set_uint8(v___x_3223_, sizeof(void*)*6 + 2, v_b_3172_);
if (v_isShared_3193_ == 0)
{
lean_ctor_set_tag(v___x_3192_, 5);
lean_ctor_set(v___x_3192_, 0, v___x_3223_);
v___x_3225_ = v___x_3192_;
goto v_reusejp_3224_;
}
else
{
lean_object* v_reuseFailAlloc_3238_; 
v_reuseFailAlloc_3238_ = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3238_, 0, v___x_3223_);
v___x_3225_ = v_reuseFailAlloc_3238_;
goto v_reusejp_3224_;
}
v_reusejp_3224_:
{
lean_object* v___x_3226_; lean_object* v___x_3227_; lean_object* v___x_3228_; lean_object* v___x_3230_; 
v___x_3226_ = lean_box(0);
lean_inc(v_val_3176_);
v___x_3227_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_3213_, v_val_3176_, v___x_3225_);
v___x_3228_ = lean_array_push(v_constOrder_3214_, v_val_3176_);
if (v_isShared_3217_ == 0)
{
lean_ctor_set(v___x_3216_, 6, v___x_3228_);
lean_ctor_set(v___x_3216_, 5, v___x_3227_);
v___x_3230_ = v___x_3216_;
goto v_reusejp_3229_;
}
else
{
lean_object* v_reuseFailAlloc_3237_; 
v_reuseFailAlloc_3237_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_3237_, 0, v_stream_3208_);
lean_ctor_set(v_reuseFailAlloc_3237_, 1, v_nameMap_3209_);
lean_ctor_set(v_reuseFailAlloc_3237_, 2, v_levelMap_3210_);
lean_ctor_set(v_reuseFailAlloc_3237_, 3, v_exprMap_3211_);
lean_ctor_set(v_reuseFailAlloc_3237_, 4, v_recursorRuleMap_3212_);
lean_ctor_set(v_reuseFailAlloc_3237_, 5, v___x_3227_);
lean_ctor_set(v_reuseFailAlloc_3237_, 6, v___x_3228_);
v___x_3230_ = v_reuseFailAlloc_3237_;
goto v_reusejp_3229_;
}
v_reusejp_3229_:
{
lean_object* v___x_3232_; 
if (v_isShared_3207_ == 0)
{
lean_ctor_set(v___x_3206_, 1, v___x_3230_);
lean_ctor_set(v___x_3206_, 0, v___x_3226_);
v___x_3232_ = v___x_3206_;
goto v_reusejp_3231_;
}
else
{
lean_object* v_reuseFailAlloc_3236_; 
v_reuseFailAlloc_3236_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3236_, 0, v___x_3226_);
lean_ctor_set(v_reuseFailAlloc_3236_, 1, v___x_3230_);
v___x_3232_ = v_reuseFailAlloc_3236_;
goto v_reusejp_3231_;
}
v_reusejp_3231_:
{
lean_object* v___x_3234_; 
if (v_isShared_3202_ == 0)
{
lean_ctor_set(v___x_3201_, 0, v___x_3232_);
v___x_3234_ = v___x_3201_;
goto v_reusejp_3233_;
}
else
{
lean_object* v_reuseFailAlloc_3235_; 
v_reuseFailAlloc_3235_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3235_, 0, v___x_3232_);
v___x_3234_ = v_reuseFailAlloc_3235_;
goto v_reusejp_3233_;
}
v_reusejp_3233_:
{
return v___x_3234_;
}
}
}
}
}
else
{
lean_object* v___x_3239_; lean_object* v___x_3240_; lean_object* v___x_3241_; lean_object* v___x_3243_; 
lean_del_object(v___x_3216_);
lean_dec_ref(v_constOrder_3214_);
lean_dec_ref(v_constMap_3213_);
lean_dec_ref(v_recursorRuleMap_3212_);
lean_dec_ref(v_exprMap_3211_);
lean_dec_ref(v_levelMap_3210_);
lean_dec_ref(v_nameMap_3209_);
lean_dec_ref(v_stream_3208_);
lean_del_object(v___x_3206_);
lean_dec(v_fst_3204_);
lean_dec(v_fst_3196_);
lean_dec(v_val_3190_);
lean_dec(v_fst_3186_);
lean_dec(v_mantissa_3151_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
v___x_3239_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_3240_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_3176_, v___x_3218_);
v___x_3241_ = lean_string_append(v___x_3239_, v___x_3240_);
lean_dec_ref(v___x_3240_);
if (v_isShared_3193_ == 0)
{
lean_ctor_set_tag(v___x_3192_, 18);
lean_ctor_set(v___x_3192_, 0, v___x_3241_);
v___x_3243_ = v___x_3192_;
goto v_reusejp_3242_;
}
else
{
lean_object* v_reuseFailAlloc_3247_; 
v_reuseFailAlloc_3247_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3247_, 0, v___x_3241_);
v___x_3243_ = v_reuseFailAlloc_3247_;
goto v_reusejp_3242_;
}
v_reusejp_3242_:
{
lean_object* v___x_3245_; 
if (v_isShared_3202_ == 0)
{
lean_ctor_set_tag(v___x_3201_, 1);
lean_ctor_set(v___x_3201_, 0, v___x_3243_);
v___x_3245_ = v___x_3201_;
goto v_reusejp_3244_;
}
else
{
lean_object* v_reuseFailAlloc_3246_; 
v_reuseFailAlloc_3246_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3246_, 0, v___x_3243_);
v___x_3245_ = v_reuseFailAlloc_3246_;
goto v_reusejp_3244_;
}
v_reusejp_3244_:
{
return v___x_3245_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3251_; lean_object* v___x_3253_; uint8_t v_isShared_3254_; uint8_t v_isSharedCheck_3258_; 
lean_dec(v_fst_3196_);
lean_del_object(v___x_3192_);
lean_dec(v_val_3190_);
lean_dec(v_fst_3186_);
lean_dec(v_val_3176_);
lean_dec(v_mantissa_3151_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
v_a_3251_ = lean_ctor_get(v___x_3198_, 0);
v_isSharedCheck_3258_ = !lean_is_exclusive(v___x_3198_);
if (v_isSharedCheck_3258_ == 0)
{
v___x_3253_ = v___x_3198_;
v_isShared_3254_ = v_isSharedCheck_3258_;
goto v_resetjp_3252_;
}
else
{
lean_inc(v_a_3251_);
lean_dec(v___x_3198_);
v___x_3253_ = lean_box(0);
v_isShared_3254_ = v_isSharedCheck_3258_;
goto v_resetjp_3252_;
}
v_resetjp_3252_:
{
lean_object* v___x_3256_; 
if (v_isShared_3254_ == 0)
{
v___x_3256_ = v___x_3253_;
goto v_reusejp_3255_;
}
else
{
lean_object* v_reuseFailAlloc_3257_; 
v_reuseFailAlloc_3257_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3257_, 0, v_a_3251_);
v___x_3256_ = v_reuseFailAlloc_3257_;
goto v_reusejp_3255_;
}
v_reusejp_3255_:
{
return v___x_3256_;
}
}
}
}
else
{
lean_object* v_a_3259_; lean_object* v___x_3261_; uint8_t v_isShared_3262_; uint8_t v_isSharedCheck_3266_; 
lean_del_object(v___x_3192_);
lean_dec(v_val_3190_);
lean_dec(v_fst_3186_);
lean_dec(v_val_3176_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
v_a_3259_ = lean_ctor_get(v___x_3194_, 0);
v_isSharedCheck_3266_ = !lean_is_exclusive(v___x_3194_);
if (v_isSharedCheck_3266_ == 0)
{
v___x_3261_ = v___x_3194_;
v_isShared_3262_ = v_isSharedCheck_3266_;
goto v_resetjp_3260_;
}
else
{
lean_inc(v_a_3259_);
lean_dec(v___x_3194_);
v___x_3261_ = lean_box(0);
v_isShared_3262_ = v_isSharedCheck_3266_;
goto v_resetjp_3260_;
}
v_resetjp_3260_:
{
lean_object* v___x_3264_; 
if (v_isShared_3262_ == 0)
{
v___x_3264_ = v___x_3261_;
goto v_reusejp_3263_;
}
else
{
lean_object* v_reuseFailAlloc_3265_; 
v_reuseFailAlloc_3265_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3265_, 0, v_a_3259_);
v___x_3264_ = v_reuseFailAlloc_3265_;
goto v_reusejp_3263_;
}
v_reusejp_3263_:
{
return v___x_3264_;
}
}
}
}
}
else
{
lean_object* v___x_3268_; lean_object* v___x_3269_; lean_object* v___x_3270_; lean_object* v___x_3272_; 
lean_dec(v___x_3189_);
lean_dec(v_fst_3186_);
lean_dec(v_snd_3185_);
lean_dec(v_val_3176_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
v___x_3268_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_3269_ = l_Nat_reprFast(v_a_3188_);
v___x_3270_ = lean_string_append(v___x_3268_, v___x_3269_);
lean_dec_ref(v___x_3269_);
if (v_isShared_3179_ == 0)
{
lean_ctor_set_tag(v___x_3178_, 18);
lean_ctor_set(v___x_3178_, 0, v___x_3270_);
v___x_3272_ = v___x_3178_;
goto v_reusejp_3271_;
}
else
{
lean_object* v_reuseFailAlloc_3276_; 
v_reuseFailAlloc_3276_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3276_, 0, v___x_3270_);
v___x_3272_ = v_reuseFailAlloc_3276_;
goto v_reusejp_3271_;
}
v_reusejp_3271_:
{
lean_object* v___x_3274_; 
if (v_isShared_3184_ == 0)
{
lean_ctor_set_tag(v___x_3183_, 1);
lean_ctor_set(v___x_3183_, 0, v___x_3272_);
v___x_3274_ = v___x_3183_;
goto v_reusejp_3273_;
}
else
{
lean_object* v_reuseFailAlloc_3275_; 
v_reuseFailAlloc_3275_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3275_, 0, v___x_3272_);
v___x_3274_ = v_reuseFailAlloc_3275_;
goto v_reusejp_3273_;
}
v_reusejp_3273_:
{
return v___x_3274_;
}
}
}
}
}
else
{
lean_object* v_a_3278_; lean_object* v___x_3280_; uint8_t v_isShared_3281_; uint8_t v_isSharedCheck_3285_; 
lean_del_object(v___x_3178_);
lean_dec(v_val_3176_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
v_a_3278_ = lean_ctor_get(v___x_3180_, 0);
v_isSharedCheck_3285_ = !lean_is_exclusive(v___x_3180_);
if (v_isSharedCheck_3285_ == 0)
{
v___x_3280_ = v___x_3180_;
v_isShared_3281_ = v_isSharedCheck_3285_;
goto v_resetjp_3279_;
}
else
{
lean_inc(v_a_3278_);
lean_dec(v___x_3180_);
v___x_3280_ = lean_box(0);
v_isShared_3281_ = v_isSharedCheck_3285_;
goto v_resetjp_3279_;
}
v_resetjp_3279_:
{
lean_object* v___x_3283_; 
if (v_isShared_3281_ == 0)
{
v___x_3283_ = v___x_3280_;
goto v_reusejp_3282_;
}
else
{
lean_object* v_reuseFailAlloc_3284_; 
v_reuseFailAlloc_3284_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3284_, 0, v_a_3278_);
v___x_3283_ = v_reuseFailAlloc_3284_;
goto v_reusejp_3282_;
}
v_reusejp_3282_:
{
return v___x_3283_;
}
}
}
}
}
else
{
lean_object* v___x_3287_; lean_object* v___x_3288_; lean_object* v___x_3289_; lean_object* v___x_3291_; 
lean_dec(v___x_3175_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec_ref(v_a_3065_);
v___x_3287_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_3288_ = l_Nat_reprFast(v_a_3174_);
v___x_3289_ = lean_string_append(v___x_3287_, v___x_3288_);
lean_dec_ref(v___x_3288_);
if (v_isShared_3171_ == 0)
{
lean_ctor_set_tag(v___x_3170_, 18);
lean_ctor_set(v___x_3170_, 0, v___x_3289_);
v___x_3291_ = v___x_3170_;
goto v_reusejp_3290_;
}
else
{
lean_object* v_reuseFailAlloc_3295_; 
v_reuseFailAlloc_3295_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3295_, 0, v___x_3289_);
v___x_3291_ = v_reuseFailAlloc_3295_;
goto v_reusejp_3290_;
}
v_reusejp_3290_:
{
lean_object* v___x_3293_; 
if (v_isShared_3164_ == 0)
{
lean_ctor_set(v___x_3163_, 0, v___x_3291_);
v___x_3293_ = v___x_3163_;
goto v_reusejp_3292_;
}
else
{
lean_object* v_reuseFailAlloc_3294_; 
v_reuseFailAlloc_3294_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3294_, 0, v___x_3291_);
v___x_3293_ = v_reuseFailAlloc_3294_;
goto v_reusejp_3292_;
}
v_reusejp_3292_:
{
return v___x_3293_;
}
}
}
}
else
{
lean_del_object(v___x_3170_);
lean_dec(v_val_3168_);
lean_del_object(v___x_3163_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3097_;
}
}
}
else
{
lean_dec(v___x_3167_);
lean_del_object(v___x_3163_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3097_;
}
}
else
{
lean_del_object(v___x_3163_);
lean_dec(v_val_3161_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3094_;
}
}
}
else
{
lean_dec(v___x_3160_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3094_;
}
}
else
{
lean_dec(v_val_3157_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3091_;
}
}
else
{
lean_dec(v___x_3156_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3091_;
}
}
}
else
{
lean_dec(v_exponent_3152_);
lean_dec(v_mantissa_3151_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3088_;
}
}
else
{
lean_dec(v_val_3149_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3088_;
}
}
else
{
lean_dec(v___x_3148_);
lean_dec_ref(v_elems_3146_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3088_;
}
}
else
{
lean_dec(v_val_3145_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3085_;
}
}
else
{
lean_dec(v___x_3144_);
lean_dec_ref(v_elems_3142_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3085_;
}
}
else
{
lean_dec(v_val_3141_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3082_;
}
}
else
{
lean_dec(v___x_3140_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3082_;
}
}
}
else
{
lean_dec(v_exponent_3136_);
lean_dec(v_mantissa_3135_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3079_;
}
}
else
{
lean_dec(v_val_3133_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3079_;
}
}
else
{
lean_dec(v___x_3132_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3079_;
}
}
}
else
{
lean_dec(v_exponent_3128_);
lean_dec(v_mantissa_3127_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3076_;
}
}
else
{
lean_dec(v_val_3125_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3076_;
}
}
else
{
lean_dec(v___x_3124_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3076_;
}
}
}
else
{
lean_dec(v_exponent_3120_);
lean_dec(v_mantissa_3119_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3073_;
}
}
else
{
lean_dec(v_val_3117_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3073_;
}
}
else
{
lean_dec(v___x_3116_);
lean_dec_ref(v_elems_3114_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3073_;
}
}
else
{
lean_dec(v_val_3113_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3070_;
}
}
else
{
lean_dec(v___x_3112_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3070_;
}
}
}
else
{
lean_dec(v_exponent_3106_);
lean_dec(v_mantissa_3105_);
lean_dec_ref(v_a_3065_);
goto v___jp_3067_;
}
}
else
{
lean_dec(v_val_3103_);
lean_dec_ref(v_a_3065_);
goto v___jp_3067_;
}
}
else
{
lean_dec(v___x_3102_);
lean_dec_ref(v_a_3065_);
goto v___jp_3067_;
}
}
else
{
lean_object* v___x_3298_; lean_object* v___x_3299_; 
lean_dec_ref(v_a_3065_);
v___x_3298_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__9));
v___x_3299_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3299_, 0, v___x_3298_);
return v___x_3299_;
}
v___jp_3067_:
{
lean_object* v___x_3068_; lean_object* v___x_3069_; 
v___x_3068_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3069_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3069_, 0, v___x_3068_);
return v___x_3069_;
}
v___jp_3070_:
{
lean_object* v___x_3071_; lean_object* v___x_3072_; 
v___x_3071_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3072_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3072_, 0, v___x_3071_);
return v___x_3072_;
}
v___jp_3073_:
{
lean_object* v___x_3074_; lean_object* v___x_3075_; 
v___x_3074_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3075_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3075_, 0, v___x_3074_);
return v___x_3075_;
}
v___jp_3076_:
{
lean_object* v___x_3077_; lean_object* v___x_3078_; 
v___x_3077_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3078_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3078_, 0, v___x_3077_);
return v___x_3078_;
}
v___jp_3079_:
{
lean_object* v___x_3080_; lean_object* v___x_3081_; 
v___x_3080_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3081_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3081_, 0, v___x_3080_);
return v___x_3081_;
}
v___jp_3082_:
{
lean_object* v___x_3083_; lean_object* v___x_3084_; 
v___x_3083_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3084_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3084_, 0, v___x_3083_);
return v___x_3084_;
}
v___jp_3085_:
{
lean_object* v___x_3086_; lean_object* v___x_3087_; 
v___x_3086_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3087_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3087_, 0, v___x_3086_);
return v___x_3087_;
}
v___jp_3088_:
{
lean_object* v___x_3089_; lean_object* v___x_3090_; 
v___x_3089_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3090_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3090_, 0, v___x_3089_);
return v___x_3090_;
}
v___jp_3091_:
{
lean_object* v___x_3092_; lean_object* v___x_3093_; 
v___x_3092_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3093_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3093_, 0, v___x_3092_);
return v___x_3093_;
}
v___jp_3094_:
{
lean_object* v___x_3095_; lean_object* v___x_3096_; 
v___x_3095_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3096_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3096_, 0, v___x_3095_);
return v___x_3096_;
}
v___jp_3097_:
{
lean_object* v___x_3098_; lean_object* v___x_3099_; 
v___x_3098_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__1));
v___x_3099_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3099_, 0, v___x_3098_);
return v___x_3099_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductInfo___boxed(lean_object* v_json_3300_, lean_object* v_a_3301_, lean_object* v_a_3302_){
_start:
{
lean_object* v_res_3303_; 
v_res_3303_ = lp_proofEnvironment_Export_Parse_parseInductInfo(v_json_3300_, v_a_3301_);
lean_dec(v_json_3300_);
return v_res_3303_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo(lean_object* v_json_3310_, lean_object* v_a_3311_){
_start:
{
if (lean_obj_tag(v_json_3310_) == 5)
{
lean_object* v_kvPairs_3337_; lean_object* v___x_3338_; lean_object* v___x_3339_; 
v_kvPairs_3337_ = lean_ctor_get(v_json_3310_, 0);
v___x_3338_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_3339_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3338_);
if (lean_obj_tag(v___x_3339_) == 1)
{
lean_object* v_val_3340_; 
v_val_3340_ = lean_ctor_get(v___x_3339_, 0);
lean_inc(v_val_3340_);
lean_dec_ref_known(v___x_3339_, 1);
if (lean_obj_tag(v_val_3340_) == 2)
{
lean_object* v_n_3341_; lean_object* v_mantissa_3342_; lean_object* v_exponent_3343_; lean_object* v_natZero_3344_; lean_object* v_intZero_3345_; uint8_t v_isNeg_3346_; 
v_n_3341_ = lean_ctor_get(v_val_3340_, 0);
lean_inc_ref(v_n_3341_);
lean_dec_ref_known(v_val_3340_, 1);
v_mantissa_3342_ = lean_ctor_get(v_n_3341_, 0);
lean_inc(v_mantissa_3342_);
v_exponent_3343_ = lean_ctor_get(v_n_3341_, 1);
lean_inc(v_exponent_3343_);
lean_dec_ref(v_n_3341_);
v_natZero_3344_ = lean_unsigned_to_nat(0u);
v_intZero_3345_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_3346_ = lean_int_dec_lt(v_mantissa_3342_, v_intZero_3345_);
if (v_isNeg_3346_ == 0)
{
uint8_t v___x_3347_; 
v___x_3347_ = lean_nat_dec_eq(v_exponent_3343_, v_natZero_3344_);
lean_dec(v_exponent_3343_);
if (v___x_3347_ == 0)
{
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3313_;
}
else
{
lean_object* v___x_3348_; lean_object* v___x_3349_; 
v___x_3348_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_3349_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3348_);
if (lean_obj_tag(v___x_3349_) == 1)
{
lean_object* v_val_3350_; 
v_val_3350_ = lean_ctor_get(v___x_3349_, 0);
lean_inc(v_val_3350_);
lean_dec_ref_known(v___x_3349_, 1);
if (lean_obj_tag(v_val_3350_) == 4)
{
lean_object* v_elems_3351_; lean_object* v___x_3352_; lean_object* v___x_3353_; 
v_elems_3351_ = lean_ctor_get(v_val_3350_, 0);
lean_inc_ref(v_elems_3351_);
lean_dec_ref_known(v_val_3350_, 1);
v___x_3352_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_3353_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3352_);
if (lean_obj_tag(v___x_3353_) == 1)
{
lean_object* v_val_3354_; 
v_val_3354_ = lean_ctor_get(v___x_3353_, 0);
lean_inc(v_val_3354_);
lean_dec_ref_known(v___x_3353_, 1);
if (lean_obj_tag(v_val_3354_) == 2)
{
lean_object* v_n_3355_; lean_object* v_mantissa_3356_; lean_object* v_exponent_3357_; uint8_t v_isNeg_3358_; 
v_n_3355_ = lean_ctor_get(v_val_3354_, 0);
lean_inc_ref(v_n_3355_);
lean_dec_ref_known(v_val_3354_, 1);
v_mantissa_3356_ = lean_ctor_get(v_n_3355_, 0);
lean_inc(v_mantissa_3356_);
v_exponent_3357_ = lean_ctor_get(v_n_3355_, 1);
lean_inc(v_exponent_3357_);
lean_dec_ref(v_n_3355_);
v_isNeg_3358_ = lean_int_dec_lt(v_mantissa_3356_, v_intZero_3345_);
if (v_isNeg_3358_ == 0)
{
uint8_t v___x_3359_; 
v___x_3359_ = lean_nat_dec_eq(v_exponent_3357_, v_natZero_3344_);
lean_dec(v_exponent_3357_);
if (v___x_3359_ == 0)
{
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3319_;
}
else
{
lean_object* v___x_3360_; lean_object* v___x_3361_; 
v___x_3360_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__2));
v___x_3361_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3360_);
if (lean_obj_tag(v___x_3361_) == 1)
{
lean_object* v_val_3362_; 
v_val_3362_ = lean_ctor_get(v___x_3361_, 0);
lean_inc(v_val_3362_);
lean_dec_ref_known(v___x_3361_, 1);
if (lean_obj_tag(v_val_3362_) == 2)
{
lean_object* v_n_3363_; lean_object* v_mantissa_3364_; lean_object* v_exponent_3365_; uint8_t v_isNeg_3366_; 
v_n_3363_ = lean_ctor_get(v_val_3362_, 0);
lean_inc_ref(v_n_3363_);
lean_dec_ref_known(v_val_3362_, 1);
v_mantissa_3364_ = lean_ctor_get(v_n_3363_, 0);
lean_inc(v_mantissa_3364_);
v_exponent_3365_ = lean_ctor_get(v_n_3363_, 1);
lean_inc(v_exponent_3365_);
lean_dec_ref(v_n_3363_);
v_isNeg_3366_ = lean_int_dec_lt(v_mantissa_3364_, v_intZero_3345_);
if (v_isNeg_3366_ == 0)
{
uint8_t v___x_3367_; 
v___x_3367_ = lean_nat_dec_eq(v_exponent_3365_, v_natZero_3344_);
lean_dec(v_exponent_3365_);
if (v___x_3367_ == 0)
{
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3322_;
}
else
{
lean_object* v___x_3368_; lean_object* v___x_3369_; 
v___x_3368_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__3));
v___x_3369_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3368_);
if (lean_obj_tag(v___x_3369_) == 1)
{
lean_object* v_val_3370_; 
v_val_3370_ = lean_ctor_get(v___x_3369_, 0);
lean_inc(v_val_3370_);
lean_dec_ref_known(v___x_3369_, 1);
if (lean_obj_tag(v_val_3370_) == 2)
{
lean_object* v_n_3371_; lean_object* v_mantissa_3372_; lean_object* v_exponent_3373_; uint8_t v_isNeg_3374_; 
v_n_3371_ = lean_ctor_get(v_val_3370_, 0);
lean_inc_ref(v_n_3371_);
lean_dec_ref_known(v_val_3370_, 1);
v_mantissa_3372_ = lean_ctor_get(v_n_3371_, 0);
lean_inc(v_mantissa_3372_);
v_exponent_3373_ = lean_ctor_get(v_n_3371_, 1);
lean_inc(v_exponent_3373_);
lean_dec_ref(v_n_3371_);
v_isNeg_3374_ = lean_int_dec_lt(v_mantissa_3372_, v_intZero_3345_);
if (v_isNeg_3374_ == 0)
{
uint8_t v___x_3375_; 
v___x_3375_ = lean_nat_dec_eq(v_exponent_3373_, v_natZero_3344_);
lean_dec(v_exponent_3373_);
if (v___x_3375_ == 0)
{
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3325_;
}
else
{
lean_object* v___x_3376_; lean_object* v___x_3377_; 
v___x_3376_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__2));
v___x_3377_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3376_);
if (lean_obj_tag(v___x_3377_) == 1)
{
lean_object* v_val_3378_; 
v_val_3378_ = lean_ctor_get(v___x_3377_, 0);
lean_inc(v_val_3378_);
lean_dec_ref_known(v___x_3377_, 1);
if (lean_obj_tag(v_val_3378_) == 2)
{
lean_object* v_n_3379_; lean_object* v_mantissa_3380_; lean_object* v_exponent_3381_; uint8_t v_isNeg_3382_; 
v_n_3379_ = lean_ctor_get(v_val_3378_, 0);
lean_inc_ref(v_n_3379_);
lean_dec_ref_known(v_val_3378_, 1);
v_mantissa_3380_ = lean_ctor_get(v_n_3379_, 0);
lean_inc(v_mantissa_3380_);
v_exponent_3381_ = lean_ctor_get(v_n_3379_, 1);
lean_inc(v_exponent_3381_);
lean_dec_ref(v_n_3379_);
v_isNeg_3382_ = lean_int_dec_lt(v_mantissa_3380_, v_intZero_3345_);
if (v_isNeg_3382_ == 0)
{
uint8_t v___x_3383_; 
v___x_3383_ = lean_nat_dec_eq(v_exponent_3381_, v_natZero_3344_);
lean_dec(v_exponent_3381_);
if (v___x_3383_ == 0)
{
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3328_;
}
else
{
lean_object* v___x_3384_; lean_object* v___x_3385_; 
v___x_3384_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__4));
v___x_3385_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3384_);
if (lean_obj_tag(v___x_3385_) == 1)
{
lean_object* v_val_3386_; 
v_val_3386_ = lean_ctor_get(v___x_3385_, 0);
lean_inc(v_val_3386_);
lean_dec_ref_known(v___x_3385_, 1);
if (lean_obj_tag(v_val_3386_) == 2)
{
lean_object* v_n_3387_; lean_object* v___x_3389_; uint8_t v_isShared_3390_; uint8_t v_isSharedCheck_3513_; 
v_n_3387_ = lean_ctor_get(v_val_3386_, 0);
v_isSharedCheck_3513_ = !lean_is_exclusive(v_val_3386_);
if (v_isSharedCheck_3513_ == 0)
{
v___x_3389_ = v_val_3386_;
v_isShared_3390_ = v_isSharedCheck_3513_;
goto v_resetjp_3388_;
}
else
{
lean_inc(v_n_3387_);
lean_dec(v_val_3386_);
v___x_3389_ = lean_box(0);
v_isShared_3390_ = v_isSharedCheck_3513_;
goto v_resetjp_3388_;
}
v_resetjp_3388_:
{
lean_object* v_mantissa_3391_; lean_object* v_exponent_3392_; uint8_t v_isNeg_3393_; 
v_mantissa_3391_ = lean_ctor_get(v_n_3387_, 0);
lean_inc(v_mantissa_3391_);
v_exponent_3392_ = lean_ctor_get(v_n_3387_, 1);
lean_inc(v_exponent_3392_);
lean_dec_ref(v_n_3387_);
v_isNeg_3393_ = lean_int_dec_lt(v_mantissa_3391_, v_intZero_3345_);
if (v_isNeg_3393_ == 0)
{
uint8_t v___x_3394_; 
v___x_3394_ = lean_nat_dec_eq(v_exponent_3392_, v_natZero_3344_);
lean_dec(v_exponent_3392_);
if (v___x_3394_ == 0)
{
lean_dec(v_mantissa_3391_);
lean_del_object(v___x_3389_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3331_;
}
else
{
lean_object* v___x_3395_; lean_object* v___x_3396_; 
v___x_3395_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3));
v___x_3396_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3337_, v___x_3395_);
if (lean_obj_tag(v___x_3396_) == 1)
{
lean_object* v_val_3397_; lean_object* v___x_3399_; uint8_t v_isShared_3400_; uint8_t v_isSharedCheck_3512_; 
v_val_3397_ = lean_ctor_get(v___x_3396_, 0);
v_isSharedCheck_3512_ = !lean_is_exclusive(v___x_3396_);
if (v_isSharedCheck_3512_ == 0)
{
v___x_3399_ = v___x_3396_;
v_isShared_3400_ = v_isSharedCheck_3512_;
goto v_resetjp_3398_;
}
else
{
lean_inc(v_val_3397_);
lean_dec(v___x_3396_);
v___x_3399_ = lean_box(0);
v_isShared_3400_ = v_isSharedCheck_3512_;
goto v_resetjp_3398_;
}
v_resetjp_3398_:
{
if (lean_obj_tag(v_val_3397_) == 1)
{
uint8_t v_b_3401_; lean_object* v_nameMap_3402_; lean_object* v_a_3403_; lean_object* v___x_3404_; 
v_b_3401_ = lean_ctor_get_uint8(v_val_3397_, 0);
lean_dec_ref_known(v_val_3397_, 0);
v_nameMap_3402_ = lean_ctor_get(v_a_3311_, 1);
v_a_3403_ = lean_nat_abs(v_mantissa_3342_);
lean_dec(v_mantissa_3342_);
v___x_3404_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_3402_, v_a_3403_);
if (lean_obj_tag(v___x_3404_) == 1)
{
lean_object* v_val_3405_; lean_object* v___x_3407_; uint8_t v_isShared_3408_; uint8_t v_isSharedCheck_3502_; 
lean_dec(v_a_3403_);
lean_del_object(v___x_3399_);
lean_del_object(v___x_3389_);
v_val_3405_ = lean_ctor_get(v___x_3404_, 0);
v_isSharedCheck_3502_ = !lean_is_exclusive(v___x_3404_);
if (v_isSharedCheck_3502_ == 0)
{
v___x_3407_ = v___x_3404_;
v_isShared_3408_ = v_isSharedCheck_3502_;
goto v_resetjp_3406_;
}
else
{
lean_inc(v_val_3405_);
lean_dec(v___x_3404_);
v___x_3407_ = lean_box(0);
v_isShared_3408_ = v_isSharedCheck_3502_;
goto v_resetjp_3406_;
}
v_resetjp_3406_:
{
lean_object* v___x_3409_; 
v___x_3409_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_3351_, v_a_3311_);
if (lean_obj_tag(v___x_3409_) == 0)
{
lean_object* v_a_3410_; lean_object* v___x_3412_; uint8_t v_isShared_3413_; uint8_t v_isSharedCheck_3493_; 
v_a_3410_ = lean_ctor_get(v___x_3409_, 0);
v_isSharedCheck_3493_ = !lean_is_exclusive(v___x_3409_);
if (v_isSharedCheck_3493_ == 0)
{
v___x_3412_ = v___x_3409_;
v_isShared_3413_ = v_isSharedCheck_3493_;
goto v_resetjp_3411_;
}
else
{
lean_inc(v_a_3410_);
lean_dec(v___x_3409_);
v___x_3412_ = lean_box(0);
v_isShared_3413_ = v_isSharedCheck_3493_;
goto v_resetjp_3411_;
}
v_resetjp_3411_:
{
lean_object* v_snd_3414_; lean_object* v_fst_3415_; lean_object* v___x_3417_; uint8_t v_isShared_3418_; uint8_t v_isSharedCheck_3492_; 
v_snd_3414_ = lean_ctor_get(v_a_3410_, 1);
v_fst_3415_ = lean_ctor_get(v_a_3410_, 0);
v_isSharedCheck_3492_ = !lean_is_exclusive(v_a_3410_);
if (v_isSharedCheck_3492_ == 0)
{
v___x_3417_ = v_a_3410_;
v_isShared_3418_ = v_isSharedCheck_3492_;
goto v_resetjp_3416_;
}
else
{
lean_inc(v_snd_3414_);
lean_inc(v_fst_3415_);
lean_dec(v_a_3410_);
v___x_3417_ = lean_box(0);
v_isShared_3418_ = v_isSharedCheck_3492_;
goto v_resetjp_3416_;
}
v_resetjp_3416_:
{
lean_object* v_stream_3419_; lean_object* v_nameMap_3420_; lean_object* v_levelMap_3421_; lean_object* v_exprMap_3422_; lean_object* v_recursorRuleMap_3423_; lean_object* v_constMap_3424_; lean_object* v_constOrder_3425_; lean_object* v___x_3427_; uint8_t v_isShared_3428_; uint8_t v_isSharedCheck_3491_; 
v_stream_3419_ = lean_ctor_get(v_snd_3414_, 0);
v_nameMap_3420_ = lean_ctor_get(v_snd_3414_, 1);
v_levelMap_3421_ = lean_ctor_get(v_snd_3414_, 2);
v_exprMap_3422_ = lean_ctor_get(v_snd_3414_, 3);
v_recursorRuleMap_3423_ = lean_ctor_get(v_snd_3414_, 4);
v_constMap_3424_ = lean_ctor_get(v_snd_3414_, 5);
v_constOrder_3425_ = lean_ctor_get(v_snd_3414_, 6);
v_isSharedCheck_3491_ = !lean_is_exclusive(v_snd_3414_);
if (v_isSharedCheck_3491_ == 0)
{
v___x_3427_ = v_snd_3414_;
v_isShared_3428_ = v_isSharedCheck_3491_;
goto v_resetjp_3426_;
}
else
{
lean_inc(v_constOrder_3425_);
lean_inc(v_constMap_3424_);
lean_inc(v_recursorRuleMap_3423_);
lean_inc(v_exprMap_3422_);
lean_inc(v_levelMap_3421_);
lean_inc(v_nameMap_3420_);
lean_inc(v_stream_3419_);
lean_dec(v_snd_3414_);
v___x_3427_ = lean_box(0);
v_isShared_3428_ = v_isSharedCheck_3491_;
goto v_resetjp_3426_;
}
v_resetjp_3426_:
{
lean_object* v_a_3429_; lean_object* v___x_3430_; 
v_a_3429_ = lean_nat_abs(v_mantissa_3356_);
lean_dec(v_mantissa_3356_);
v___x_3430_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_3422_, v_a_3429_);
if (lean_obj_tag(v___x_3430_) == 1)
{
lean_object* v_val_3431_; lean_object* v___x_3433_; uint8_t v_isShared_3434_; uint8_t v_isSharedCheck_3481_; 
lean_dec(v_a_3429_);
lean_del_object(v___x_3407_);
v_val_3431_ = lean_ctor_get(v___x_3430_, 0);
v_isSharedCheck_3481_ = !lean_is_exclusive(v___x_3430_);
if (v_isSharedCheck_3481_ == 0)
{
v___x_3433_ = v___x_3430_;
v_isShared_3434_ = v_isSharedCheck_3481_;
goto v_resetjp_3432_;
}
else
{
lean_inc(v_val_3431_);
lean_dec(v___x_3430_);
v___x_3433_ = lean_box(0);
v_isShared_3434_ = v_isSharedCheck_3481_;
goto v_resetjp_3432_;
}
v_resetjp_3432_:
{
lean_object* v_a_3435_; lean_object* v___x_3436_; 
v_a_3435_ = lean_nat_abs(v_mantissa_3364_);
lean_dec(v_mantissa_3364_);
v___x_3436_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_3420_, v_a_3435_);
if (lean_obj_tag(v___x_3436_) == 1)
{
lean_object* v_val_3437_; lean_object* v___x_3439_; uint8_t v_isShared_3440_; uint8_t v_isSharedCheck_3471_; 
lean_dec(v_a_3435_);
lean_del_object(v___x_3433_);
v_val_3437_ = lean_ctor_get(v___x_3436_, 0);
v_isSharedCheck_3471_ = !lean_is_exclusive(v___x_3436_);
if (v_isSharedCheck_3471_ == 0)
{
v___x_3439_ = v___x_3436_;
v_isShared_3440_ = v_isSharedCheck_3471_;
goto v_resetjp_3438_;
}
else
{
lean_inc(v_val_3437_);
lean_dec(v___x_3436_);
v___x_3439_ = lean_box(0);
v_isShared_3440_ = v_isSharedCheck_3471_;
goto v_resetjp_3438_;
}
v_resetjp_3438_:
{
uint8_t v___x_3441_; 
v___x_3441_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_3424_, v_val_3405_);
if (v___x_3441_ == 0)
{
lean_object* v_a_3442_; lean_object* v_a_3443_; lean_object* v_a_3444_; lean_object* v___x_3445_; lean_object* v___x_3446_; lean_object* v___x_3448_; 
v_a_3442_ = lean_nat_abs(v_mantissa_3372_);
lean_dec(v_mantissa_3372_);
v_a_3443_ = lean_nat_abs(v_mantissa_3380_);
lean_dec(v_mantissa_3380_);
v_a_3444_ = lean_nat_abs(v_mantissa_3391_);
lean_dec(v_mantissa_3391_);
lean_inc(v_val_3405_);
v___x_3445_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3445_, 0, v_val_3405_);
lean_ctor_set(v___x_3445_, 1, v_fst_3415_);
lean_ctor_set(v___x_3445_, 2, v_val_3431_);
v___x_3446_ = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(v___x_3446_, 0, v___x_3445_);
lean_ctor_set(v___x_3446_, 1, v_val_3437_);
lean_ctor_set(v___x_3446_, 2, v_a_3442_);
lean_ctor_set(v___x_3446_, 3, v_a_3443_);
lean_ctor_set(v___x_3446_, 4, v_a_3444_);
lean_ctor_set_uint8(v___x_3446_, sizeof(void*)*5, v_b_3401_);
if (v_isShared_3440_ == 0)
{
lean_ctor_set_tag(v___x_3439_, 6);
lean_ctor_set(v___x_3439_, 0, v___x_3446_);
v___x_3448_ = v___x_3439_;
goto v_reusejp_3447_;
}
else
{
lean_object* v_reuseFailAlloc_3461_; 
v_reuseFailAlloc_3461_ = lean_alloc_ctor(6, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3461_, 0, v___x_3446_);
v___x_3448_ = v_reuseFailAlloc_3461_;
goto v_reusejp_3447_;
}
v_reusejp_3447_:
{
lean_object* v___x_3449_; lean_object* v___x_3450_; lean_object* v___x_3451_; lean_object* v___x_3453_; 
v___x_3449_ = lean_box(0);
lean_inc(v_val_3405_);
v___x_3450_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_3424_, v_val_3405_, v___x_3448_);
v___x_3451_ = lean_array_push(v_constOrder_3425_, v_val_3405_);
if (v_isShared_3428_ == 0)
{
lean_ctor_set(v___x_3427_, 6, v___x_3451_);
lean_ctor_set(v___x_3427_, 5, v___x_3450_);
v___x_3453_ = v___x_3427_;
goto v_reusejp_3452_;
}
else
{
lean_object* v_reuseFailAlloc_3460_; 
v_reuseFailAlloc_3460_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_3460_, 0, v_stream_3419_);
lean_ctor_set(v_reuseFailAlloc_3460_, 1, v_nameMap_3420_);
lean_ctor_set(v_reuseFailAlloc_3460_, 2, v_levelMap_3421_);
lean_ctor_set(v_reuseFailAlloc_3460_, 3, v_exprMap_3422_);
lean_ctor_set(v_reuseFailAlloc_3460_, 4, v_recursorRuleMap_3423_);
lean_ctor_set(v_reuseFailAlloc_3460_, 5, v___x_3450_);
lean_ctor_set(v_reuseFailAlloc_3460_, 6, v___x_3451_);
v___x_3453_ = v_reuseFailAlloc_3460_;
goto v_reusejp_3452_;
}
v_reusejp_3452_:
{
lean_object* v___x_3455_; 
if (v_isShared_3418_ == 0)
{
lean_ctor_set(v___x_3417_, 1, v___x_3453_);
lean_ctor_set(v___x_3417_, 0, v___x_3449_);
v___x_3455_ = v___x_3417_;
goto v_reusejp_3454_;
}
else
{
lean_object* v_reuseFailAlloc_3459_; 
v_reuseFailAlloc_3459_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3459_, 0, v___x_3449_);
lean_ctor_set(v_reuseFailAlloc_3459_, 1, v___x_3453_);
v___x_3455_ = v_reuseFailAlloc_3459_;
goto v_reusejp_3454_;
}
v_reusejp_3454_:
{
lean_object* v___x_3457_; 
if (v_isShared_3413_ == 0)
{
lean_ctor_set(v___x_3412_, 0, v___x_3455_);
v___x_3457_ = v___x_3412_;
goto v_reusejp_3456_;
}
else
{
lean_object* v_reuseFailAlloc_3458_; 
v_reuseFailAlloc_3458_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3458_, 0, v___x_3455_);
v___x_3457_ = v_reuseFailAlloc_3458_;
goto v_reusejp_3456_;
}
v_reusejp_3456_:
{
return v___x_3457_;
}
}
}
}
}
else
{
lean_object* v___x_3462_; lean_object* v___x_3463_; lean_object* v___x_3464_; lean_object* v___x_3466_; 
lean_dec(v_val_3437_);
lean_dec(v_val_3431_);
lean_del_object(v___x_3427_);
lean_dec_ref(v_constOrder_3425_);
lean_dec_ref(v_constMap_3424_);
lean_dec_ref(v_recursorRuleMap_3423_);
lean_dec_ref(v_exprMap_3422_);
lean_dec_ref(v_levelMap_3421_);
lean_dec_ref(v_nameMap_3420_);
lean_dec_ref(v_stream_3419_);
lean_del_object(v___x_3417_);
lean_dec(v_fst_3415_);
lean_dec(v_mantissa_3391_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
v___x_3462_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_3463_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_3405_, v___x_3441_);
v___x_3464_ = lean_string_append(v___x_3462_, v___x_3463_);
lean_dec_ref(v___x_3463_);
if (v_isShared_3440_ == 0)
{
lean_ctor_set_tag(v___x_3439_, 18);
lean_ctor_set(v___x_3439_, 0, v___x_3464_);
v___x_3466_ = v___x_3439_;
goto v_reusejp_3465_;
}
else
{
lean_object* v_reuseFailAlloc_3470_; 
v_reuseFailAlloc_3470_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3470_, 0, v___x_3464_);
v___x_3466_ = v_reuseFailAlloc_3470_;
goto v_reusejp_3465_;
}
v_reusejp_3465_:
{
lean_object* v___x_3468_; 
if (v_isShared_3413_ == 0)
{
lean_ctor_set_tag(v___x_3412_, 1);
lean_ctor_set(v___x_3412_, 0, v___x_3466_);
v___x_3468_ = v___x_3412_;
goto v_reusejp_3467_;
}
else
{
lean_object* v_reuseFailAlloc_3469_; 
v_reuseFailAlloc_3469_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3469_, 0, v___x_3466_);
v___x_3468_ = v_reuseFailAlloc_3469_;
goto v_reusejp_3467_;
}
v_reusejp_3467_:
{
return v___x_3468_;
}
}
}
}
}
else
{
lean_object* v___x_3472_; lean_object* v___x_3473_; lean_object* v___x_3474_; lean_object* v___x_3476_; 
lean_dec(v___x_3436_);
lean_dec(v_val_3431_);
lean_del_object(v___x_3427_);
lean_dec_ref(v_constOrder_3425_);
lean_dec_ref(v_constMap_3424_);
lean_dec_ref(v_recursorRuleMap_3423_);
lean_dec_ref(v_exprMap_3422_);
lean_dec_ref(v_levelMap_3421_);
lean_dec_ref(v_nameMap_3420_);
lean_dec_ref(v_stream_3419_);
lean_del_object(v___x_3417_);
lean_dec(v_fst_3415_);
lean_dec(v_val_3405_);
lean_dec(v_mantissa_3391_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
v___x_3472_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_3473_ = l_Nat_reprFast(v_a_3435_);
v___x_3474_ = lean_string_append(v___x_3472_, v___x_3473_);
lean_dec_ref(v___x_3473_);
if (v_isShared_3434_ == 0)
{
lean_ctor_set_tag(v___x_3433_, 18);
lean_ctor_set(v___x_3433_, 0, v___x_3474_);
v___x_3476_ = v___x_3433_;
goto v_reusejp_3475_;
}
else
{
lean_object* v_reuseFailAlloc_3480_; 
v_reuseFailAlloc_3480_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3480_, 0, v___x_3474_);
v___x_3476_ = v_reuseFailAlloc_3480_;
goto v_reusejp_3475_;
}
v_reusejp_3475_:
{
lean_object* v___x_3478_; 
if (v_isShared_3413_ == 0)
{
lean_ctor_set_tag(v___x_3412_, 1);
lean_ctor_set(v___x_3412_, 0, v___x_3476_);
v___x_3478_ = v___x_3412_;
goto v_reusejp_3477_;
}
else
{
lean_object* v_reuseFailAlloc_3479_; 
v_reuseFailAlloc_3479_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3479_, 0, v___x_3476_);
v___x_3478_ = v_reuseFailAlloc_3479_;
goto v_reusejp_3477_;
}
v_reusejp_3477_:
{
return v___x_3478_;
}
}
}
}
}
else
{
lean_object* v___x_3482_; lean_object* v___x_3483_; lean_object* v___x_3484_; lean_object* v___x_3486_; 
lean_dec(v___x_3430_);
lean_del_object(v___x_3427_);
lean_dec_ref(v_constOrder_3425_);
lean_dec_ref(v_constMap_3424_);
lean_dec_ref(v_recursorRuleMap_3423_);
lean_dec_ref(v_exprMap_3422_);
lean_dec_ref(v_levelMap_3421_);
lean_dec_ref(v_nameMap_3420_);
lean_dec_ref(v_stream_3419_);
lean_del_object(v___x_3417_);
lean_dec(v_fst_3415_);
lean_dec(v_val_3405_);
lean_dec(v_mantissa_3391_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
v___x_3482_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_3483_ = l_Nat_reprFast(v_a_3429_);
v___x_3484_ = lean_string_append(v___x_3482_, v___x_3483_);
lean_dec_ref(v___x_3483_);
if (v_isShared_3408_ == 0)
{
lean_ctor_set_tag(v___x_3407_, 18);
lean_ctor_set(v___x_3407_, 0, v___x_3484_);
v___x_3486_ = v___x_3407_;
goto v_reusejp_3485_;
}
else
{
lean_object* v_reuseFailAlloc_3490_; 
v_reuseFailAlloc_3490_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3490_, 0, v___x_3484_);
v___x_3486_ = v_reuseFailAlloc_3490_;
goto v_reusejp_3485_;
}
v_reusejp_3485_:
{
lean_object* v___x_3488_; 
if (v_isShared_3413_ == 0)
{
lean_ctor_set_tag(v___x_3412_, 1);
lean_ctor_set(v___x_3412_, 0, v___x_3486_);
v___x_3488_ = v___x_3412_;
goto v_reusejp_3487_;
}
else
{
lean_object* v_reuseFailAlloc_3489_; 
v_reuseFailAlloc_3489_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3489_, 0, v___x_3486_);
v___x_3488_ = v_reuseFailAlloc_3489_;
goto v_reusejp_3487_;
}
v_reusejp_3487_:
{
return v___x_3488_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3494_; lean_object* v___x_3496_; uint8_t v_isShared_3497_; uint8_t v_isSharedCheck_3501_; 
lean_del_object(v___x_3407_);
lean_dec(v_val_3405_);
lean_dec(v_mantissa_3391_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
v_a_3494_ = lean_ctor_get(v___x_3409_, 0);
v_isSharedCheck_3501_ = !lean_is_exclusive(v___x_3409_);
if (v_isSharedCheck_3501_ == 0)
{
v___x_3496_ = v___x_3409_;
v_isShared_3497_ = v_isSharedCheck_3501_;
goto v_resetjp_3495_;
}
else
{
lean_inc(v_a_3494_);
lean_dec(v___x_3409_);
v___x_3496_ = lean_box(0);
v_isShared_3497_ = v_isSharedCheck_3501_;
goto v_resetjp_3495_;
}
v_resetjp_3495_:
{
lean_object* v___x_3499_; 
if (v_isShared_3497_ == 0)
{
v___x_3499_ = v___x_3496_;
goto v_reusejp_3498_;
}
else
{
lean_object* v_reuseFailAlloc_3500_; 
v_reuseFailAlloc_3500_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3500_, 0, v_a_3494_);
v___x_3499_ = v_reuseFailAlloc_3500_;
goto v_reusejp_3498_;
}
v_reusejp_3498_:
{
return v___x_3499_;
}
}
}
}
}
else
{
lean_object* v___x_3503_; lean_object* v___x_3504_; lean_object* v___x_3505_; lean_object* v___x_3507_; 
lean_dec(v___x_3404_);
lean_dec(v_mantissa_3391_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec_ref(v_a_3311_);
v___x_3503_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_3504_ = l_Nat_reprFast(v_a_3403_);
v___x_3505_ = lean_string_append(v___x_3503_, v___x_3504_);
lean_dec_ref(v___x_3504_);
if (v_isShared_3400_ == 0)
{
lean_ctor_set_tag(v___x_3399_, 18);
lean_ctor_set(v___x_3399_, 0, v___x_3505_);
v___x_3507_ = v___x_3399_;
goto v_reusejp_3506_;
}
else
{
lean_object* v_reuseFailAlloc_3511_; 
v_reuseFailAlloc_3511_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3511_, 0, v___x_3505_);
v___x_3507_ = v_reuseFailAlloc_3511_;
goto v_reusejp_3506_;
}
v_reusejp_3506_:
{
lean_object* v___x_3509_; 
if (v_isShared_3390_ == 0)
{
lean_ctor_set_tag(v___x_3389_, 1);
lean_ctor_set(v___x_3389_, 0, v___x_3507_);
v___x_3509_ = v___x_3389_;
goto v_reusejp_3508_;
}
else
{
lean_object* v_reuseFailAlloc_3510_; 
v_reuseFailAlloc_3510_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3510_, 0, v___x_3507_);
v___x_3509_ = v_reuseFailAlloc_3510_;
goto v_reusejp_3508_;
}
v_reusejp_3508_:
{
return v___x_3509_;
}
}
}
}
else
{
lean_del_object(v___x_3399_);
lean_dec(v_val_3397_);
lean_dec(v_mantissa_3391_);
lean_del_object(v___x_3389_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3334_;
}
}
}
else
{
lean_dec(v___x_3396_);
lean_dec(v_mantissa_3391_);
lean_del_object(v___x_3389_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3334_;
}
}
}
else
{
lean_dec(v_exponent_3392_);
lean_dec(v_mantissa_3391_);
lean_del_object(v___x_3389_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3331_;
}
}
}
else
{
lean_dec(v_val_3386_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3331_;
}
}
else
{
lean_dec(v___x_3385_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3331_;
}
}
}
else
{
lean_dec(v_exponent_3381_);
lean_dec(v_mantissa_3380_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3328_;
}
}
else
{
lean_dec(v_val_3378_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3328_;
}
}
else
{
lean_dec(v___x_3377_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3328_;
}
}
}
else
{
lean_dec(v_exponent_3373_);
lean_dec(v_mantissa_3372_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3325_;
}
}
else
{
lean_dec(v_val_3370_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3325_;
}
}
else
{
lean_dec(v___x_3369_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3325_;
}
}
}
else
{
lean_dec(v_exponent_3365_);
lean_dec(v_mantissa_3364_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3322_;
}
}
else
{
lean_dec(v_val_3362_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3322_;
}
}
else
{
lean_dec(v___x_3361_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3322_;
}
}
}
else
{
lean_dec(v_exponent_3357_);
lean_dec(v_mantissa_3356_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3319_;
}
}
else
{
lean_dec(v_val_3354_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3319_;
}
}
else
{
lean_dec(v___x_3353_);
lean_dec_ref(v_elems_3351_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3319_;
}
}
else
{
lean_dec(v_val_3350_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3316_;
}
}
else
{
lean_dec(v___x_3349_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3316_;
}
}
}
else
{
lean_dec(v_exponent_3343_);
lean_dec(v_mantissa_3342_);
lean_dec_ref(v_a_3311_);
goto v___jp_3313_;
}
}
else
{
lean_dec(v_val_3340_);
lean_dec_ref(v_a_3311_);
goto v___jp_3313_;
}
}
else
{
lean_dec(v___x_3339_);
lean_dec_ref(v_a_3311_);
goto v___jp_3313_;
}
}
else
{
lean_object* v___x_3514_; lean_object* v___x_3515_; 
lean_dec_ref(v_a_3311_);
v___x_3514_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3515_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3515_, 0, v___x_3514_);
return v___x_3515_;
}
v___jp_3313_:
{
lean_object* v___x_3314_; lean_object* v___x_3315_; 
v___x_3314_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3315_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3315_, 0, v___x_3314_);
return v___x_3315_;
}
v___jp_3316_:
{
lean_object* v___x_3317_; lean_object* v___x_3318_; 
v___x_3317_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3318_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3318_, 0, v___x_3317_);
return v___x_3318_;
}
v___jp_3319_:
{
lean_object* v___x_3320_; lean_object* v___x_3321_; 
v___x_3320_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3321_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3321_, 0, v___x_3320_);
return v___x_3321_;
}
v___jp_3322_:
{
lean_object* v___x_3323_; lean_object* v___x_3324_; 
v___x_3323_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3324_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3324_, 0, v___x_3323_);
return v___x_3324_;
}
v___jp_3325_:
{
lean_object* v___x_3326_; lean_object* v___x_3327_; 
v___x_3326_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3327_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3327_, 0, v___x_3326_);
return v___x_3327_;
}
v___jp_3328_:
{
lean_object* v___x_3329_; lean_object* v___x_3330_; 
v___x_3329_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3330_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3330_, 0, v___x_3329_);
return v___x_3330_;
}
v___jp_3331_:
{
lean_object* v___x_3332_; lean_object* v___x_3333_; 
v___x_3332_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3333_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3333_, 0, v___x_3332_);
return v___x_3333_;
}
v___jp_3334_:
{
lean_object* v___x_3335_; lean_object* v___x_3336_; 
v___x_3335_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseCtorInfo___closed__1));
v___x_3336_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3336_, 0, v___x_3335_);
return v___x_3336_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseCtorInfo___boxed(lean_object* v_json_3516_, lean_object* v_a_3517_, lean_object* v_a_3518_){
_start:
{
lean_object* v_res_3519_; 
v_res_3519_ = lp_proofEnvironment_Export_Parse_parseCtorInfo(v_json_3516_, v_a_3517_);
lean_dec(v_json_3516_);
return v_res_3519_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0(lean_object* v_x_3525_, lean_object* v_x_3526_, lean_object* v___y_3527_){
_start:
{
if (lean_obj_tag(v_x_3525_) == 0)
{
lean_object* v___x_3538_; lean_object* v___x_3539_; lean_object* v___x_3540_; 
v___x_3538_ = l_List_reverse___redArg(v_x_3526_);
v___x_3539_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3539_, 0, v___x_3538_);
lean_ctor_set(v___x_3539_, 1, v___y_3527_);
v___x_3540_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3540_, 0, v___x_3539_);
return v___x_3540_;
}
else
{
lean_object* v_head_3541_; 
v_head_3541_ = lean_ctor_get(v_x_3525_, 0);
lean_inc(v_head_3541_);
if (lean_obj_tag(v_head_3541_) == 5)
{
lean_object* v_tail_3542_; lean_object* v___x_3544_; uint8_t v_isShared_3545_; uint8_t v_isSharedCheck_3617_; 
v_tail_3542_ = lean_ctor_get(v_x_3525_, 1);
v_isSharedCheck_3617_ = !lean_is_exclusive(v_x_3525_);
if (v_isSharedCheck_3617_ == 0)
{
lean_object* v_unused_3618_; 
v_unused_3618_ = lean_ctor_get(v_x_3525_, 0);
lean_dec(v_unused_3618_);
v___x_3544_ = v_x_3525_;
v_isShared_3545_ = v_isSharedCheck_3617_;
goto v_resetjp_3543_;
}
else
{
lean_inc(v_tail_3542_);
lean_dec(v_x_3525_);
v___x_3544_ = lean_box(0);
v_isShared_3545_ = v_isSharedCheck_3617_;
goto v_resetjp_3543_;
}
v_resetjp_3543_:
{
lean_object* v_kvPairs_3546_; lean_object* v___x_3547_; lean_object* v___x_3548_; 
v_kvPairs_3546_ = lean_ctor_get(v_head_3541_, 0);
lean_inc(v_kvPairs_3546_);
lean_dec_ref_known(v_head_3541_, 1);
v___x_3547_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseQuotInfo___closed__3));
v___x_3548_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3546_, v___x_3547_);
if (lean_obj_tag(v___x_3548_) == 1)
{
lean_object* v_val_3549_; 
v_val_3549_ = lean_ctor_get(v___x_3548_, 0);
lean_inc(v_val_3549_);
lean_dec_ref_known(v___x_3548_, 1);
if (lean_obj_tag(v_val_3549_) == 2)
{
lean_object* v_n_3550_; lean_object* v_mantissa_3551_; lean_object* v_exponent_3552_; lean_object* v_natZero_3553_; lean_object* v_intZero_3554_; uint8_t v_isNeg_3555_; 
v_n_3550_ = lean_ctor_get(v_val_3549_, 0);
lean_inc_ref(v_n_3550_);
lean_dec_ref_known(v_val_3549_, 1);
v_mantissa_3551_ = lean_ctor_get(v_n_3550_, 0);
lean_inc(v_mantissa_3551_);
v_exponent_3552_ = lean_ctor_get(v_n_3550_, 1);
lean_inc(v_exponent_3552_);
lean_dec_ref(v_n_3550_);
v_natZero_3553_ = lean_unsigned_to_nat(0u);
v_intZero_3554_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_3555_ = lean_int_dec_lt(v_mantissa_3551_, v_intZero_3554_);
if (v_isNeg_3555_ == 0)
{
uint8_t v___x_3556_; 
v___x_3556_ = lean_nat_dec_eq(v_exponent_3552_, v_natZero_3553_);
lean_dec(v_exponent_3552_);
if (v___x_3556_ == 0)
{
lean_dec(v_mantissa_3551_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3529_;
}
else
{
lean_object* v___x_3557_; lean_object* v___x_3558_; 
v___x_3557_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__2));
v___x_3558_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3546_, v___x_3557_);
if (lean_obj_tag(v___x_3558_) == 1)
{
lean_object* v_val_3559_; 
v_val_3559_ = lean_ctor_get(v___x_3558_, 0);
lean_inc(v_val_3559_);
lean_dec_ref_known(v___x_3558_, 1);
if (lean_obj_tag(v_val_3559_) == 2)
{
lean_object* v_n_3560_; lean_object* v_mantissa_3561_; lean_object* v_exponent_3562_; uint8_t v_isNeg_3563_; 
v_n_3560_ = lean_ctor_get(v_val_3559_, 0);
lean_inc_ref(v_n_3560_);
lean_dec_ref_known(v_val_3559_, 1);
v_mantissa_3561_ = lean_ctor_get(v_n_3560_, 0);
lean_inc(v_mantissa_3561_);
v_exponent_3562_ = lean_ctor_get(v_n_3560_, 1);
lean_inc(v_exponent_3562_);
lean_dec_ref(v_n_3560_);
v_isNeg_3563_ = lean_int_dec_lt(v_mantissa_3561_, v_intZero_3554_);
if (v_isNeg_3563_ == 0)
{
uint8_t v___x_3564_; 
v___x_3564_ = lean_nat_dec_eq(v_exponent_3562_, v_natZero_3553_);
lean_dec(v_exponent_3562_);
if (v___x_3564_ == 0)
{
lean_dec(v_mantissa_3561_);
lean_dec(v_mantissa_3551_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3532_;
}
else
{
lean_object* v___x_3565_; lean_object* v___x_3566_; 
v___x_3565_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__3));
v___x_3566_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3546_, v___x_3565_);
lean_dec(v_kvPairs_3546_);
if (lean_obj_tag(v___x_3566_) == 1)
{
lean_object* v_val_3567_; lean_object* v___x_3569_; uint8_t v_isShared_3570_; uint8_t v_isSharedCheck_3616_; 
v_val_3567_ = lean_ctor_get(v___x_3566_, 0);
v_isSharedCheck_3616_ = !lean_is_exclusive(v___x_3566_);
if (v_isSharedCheck_3616_ == 0)
{
v___x_3569_ = v___x_3566_;
v_isShared_3570_ = v_isSharedCheck_3616_;
goto v_resetjp_3568_;
}
else
{
lean_inc(v_val_3567_);
lean_dec(v___x_3566_);
v___x_3569_ = lean_box(0);
v_isShared_3570_ = v_isSharedCheck_3616_;
goto v_resetjp_3568_;
}
v_resetjp_3568_:
{
if (lean_obj_tag(v_val_3567_) == 2)
{
lean_object* v_n_3571_; lean_object* v___x_3573_; uint8_t v_isShared_3574_; uint8_t v_isSharedCheck_3615_; 
v_n_3571_ = lean_ctor_get(v_val_3567_, 0);
v_isSharedCheck_3615_ = !lean_is_exclusive(v_val_3567_);
if (v_isSharedCheck_3615_ == 0)
{
v___x_3573_ = v_val_3567_;
v_isShared_3574_ = v_isSharedCheck_3615_;
goto v_resetjp_3572_;
}
else
{
lean_inc(v_n_3571_);
lean_dec(v_val_3567_);
v___x_3573_ = lean_box(0);
v_isShared_3574_ = v_isSharedCheck_3615_;
goto v_resetjp_3572_;
}
v_resetjp_3572_:
{
lean_object* v_mantissa_3575_; lean_object* v_exponent_3576_; uint8_t v_isNeg_3577_; 
v_mantissa_3575_ = lean_ctor_get(v_n_3571_, 0);
lean_inc(v_mantissa_3575_);
v_exponent_3576_ = lean_ctor_get(v_n_3571_, 1);
lean_inc(v_exponent_3576_);
lean_dec_ref(v_n_3571_);
v_isNeg_3577_ = lean_int_dec_lt(v_mantissa_3575_, v_intZero_3554_);
if (v_isNeg_3577_ == 0)
{
uint8_t v___x_3578_; 
v___x_3578_ = lean_nat_dec_eq(v_exponent_3576_, v_natZero_3553_);
lean_dec(v_exponent_3576_);
if (v___x_3578_ == 0)
{
lean_dec(v_mantissa_3575_);
lean_del_object(v___x_3573_);
lean_del_object(v___x_3569_);
lean_dec(v_mantissa_3561_);
lean_dec(v_mantissa_3551_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3535_;
}
else
{
lean_object* v_nameMap_3579_; lean_object* v_exprMap_3580_; lean_object* v_a_3581_; lean_object* v___x_3582_; 
v_nameMap_3579_ = lean_ctor_get(v___y_3527_, 1);
v_exprMap_3580_ = lean_ctor_get(v___y_3527_, 3);
v_a_3581_ = lean_nat_abs(v_mantissa_3551_);
lean_dec(v_mantissa_3551_);
v___x_3582_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_3579_, v_a_3581_);
if (lean_obj_tag(v___x_3582_) == 1)
{
lean_object* v_val_3583_; lean_object* v___x_3585_; uint8_t v_isShared_3586_; uint8_t v_isSharedCheck_3605_; 
lean_dec(v_a_3581_);
lean_del_object(v___x_3569_);
v_val_3583_ = lean_ctor_get(v___x_3582_, 0);
v_isSharedCheck_3605_ = !lean_is_exclusive(v___x_3582_);
if (v_isSharedCheck_3605_ == 0)
{
v___x_3585_ = v___x_3582_;
v_isShared_3586_ = v_isSharedCheck_3605_;
goto v_resetjp_3584_;
}
else
{
lean_inc(v_val_3583_);
lean_dec(v___x_3582_);
v___x_3585_ = lean_box(0);
v_isShared_3586_ = v_isSharedCheck_3605_;
goto v_resetjp_3584_;
}
v_resetjp_3584_:
{
lean_object* v_a_3587_; lean_object* v___x_3588_; 
v_a_3587_ = lean_nat_abs(v_mantissa_3575_);
lean_dec(v_mantissa_3575_);
v___x_3588_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_3580_, v_a_3587_);
if (lean_obj_tag(v___x_3588_) == 1)
{
lean_object* v_val_3589_; lean_object* v_a_3590_; lean_object* v___x_3591_; lean_object* v___x_3593_; 
lean_dec(v_a_3587_);
lean_del_object(v___x_3585_);
lean_del_object(v___x_3573_);
v_val_3589_ = lean_ctor_get(v___x_3588_, 0);
lean_inc(v_val_3589_);
lean_dec_ref_known(v___x_3588_, 1);
v_a_3590_ = lean_nat_abs(v_mantissa_3561_);
lean_dec(v_mantissa_3561_);
v___x_3591_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3591_, 0, v_val_3583_);
lean_ctor_set(v___x_3591_, 1, v_a_3590_);
lean_ctor_set(v___x_3591_, 2, v_val_3589_);
if (v_isShared_3545_ == 0)
{
lean_ctor_set(v___x_3544_, 1, v_x_3526_);
lean_ctor_set(v___x_3544_, 0, v___x_3591_);
v___x_3593_ = v___x_3544_;
goto v_reusejp_3592_;
}
else
{
lean_object* v_reuseFailAlloc_3595_; 
v_reuseFailAlloc_3595_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3595_, 0, v___x_3591_);
lean_ctor_set(v_reuseFailAlloc_3595_, 1, v_x_3526_);
v___x_3593_ = v_reuseFailAlloc_3595_;
goto v_reusejp_3592_;
}
v_reusejp_3592_:
{
v_x_3525_ = v_tail_3542_;
v_x_3526_ = v___x_3593_;
goto _start;
}
}
else
{
lean_object* v___x_3596_; lean_object* v___x_3597_; lean_object* v___x_3598_; lean_object* v___x_3600_; 
lean_dec(v___x_3588_);
lean_dec(v_val_3583_);
lean_dec(v_mantissa_3561_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
v___x_3596_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_3597_ = l_Nat_reprFast(v_a_3587_);
v___x_3598_ = lean_string_append(v___x_3596_, v___x_3597_);
lean_dec_ref(v___x_3597_);
if (v_isShared_3586_ == 0)
{
lean_ctor_set_tag(v___x_3585_, 18);
lean_ctor_set(v___x_3585_, 0, v___x_3598_);
v___x_3600_ = v___x_3585_;
goto v_reusejp_3599_;
}
else
{
lean_object* v_reuseFailAlloc_3604_; 
v_reuseFailAlloc_3604_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3604_, 0, v___x_3598_);
v___x_3600_ = v_reuseFailAlloc_3604_;
goto v_reusejp_3599_;
}
v_reusejp_3599_:
{
lean_object* v___x_3602_; 
if (v_isShared_3574_ == 0)
{
lean_ctor_set_tag(v___x_3573_, 1);
lean_ctor_set(v___x_3573_, 0, v___x_3600_);
v___x_3602_ = v___x_3573_;
goto v_reusejp_3601_;
}
else
{
lean_object* v_reuseFailAlloc_3603_; 
v_reuseFailAlloc_3603_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3603_, 0, v___x_3600_);
v___x_3602_ = v_reuseFailAlloc_3603_;
goto v_reusejp_3601_;
}
v_reusejp_3601_:
{
return v___x_3602_;
}
}
}
}
}
else
{
lean_object* v___x_3606_; lean_object* v___x_3607_; lean_object* v___x_3608_; lean_object* v___x_3610_; 
lean_dec(v___x_3582_);
lean_dec(v_mantissa_3575_);
lean_dec(v_mantissa_3561_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
v___x_3606_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_3607_ = l_Nat_reprFast(v_a_3581_);
v___x_3608_ = lean_string_append(v___x_3606_, v___x_3607_);
lean_dec_ref(v___x_3607_);
if (v_isShared_3574_ == 0)
{
lean_ctor_set_tag(v___x_3573_, 18);
lean_ctor_set(v___x_3573_, 0, v___x_3608_);
v___x_3610_ = v___x_3573_;
goto v_reusejp_3609_;
}
else
{
lean_object* v_reuseFailAlloc_3614_; 
v_reuseFailAlloc_3614_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3614_, 0, v___x_3608_);
v___x_3610_ = v_reuseFailAlloc_3614_;
goto v_reusejp_3609_;
}
v_reusejp_3609_:
{
lean_object* v___x_3612_; 
if (v_isShared_3570_ == 0)
{
lean_ctor_set(v___x_3569_, 0, v___x_3610_);
v___x_3612_ = v___x_3569_;
goto v_reusejp_3611_;
}
else
{
lean_object* v_reuseFailAlloc_3613_; 
v_reuseFailAlloc_3613_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3613_, 0, v___x_3610_);
v___x_3612_ = v_reuseFailAlloc_3613_;
goto v_reusejp_3611_;
}
v_reusejp_3611_:
{
return v___x_3612_;
}
}
}
}
}
else
{
lean_dec(v_exponent_3576_);
lean_dec(v_mantissa_3575_);
lean_del_object(v___x_3573_);
lean_del_object(v___x_3569_);
lean_dec(v_mantissa_3561_);
lean_dec(v_mantissa_3551_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3535_;
}
}
}
else
{
lean_del_object(v___x_3569_);
lean_dec(v_val_3567_);
lean_dec(v_mantissa_3561_);
lean_dec(v_mantissa_3551_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3535_;
}
}
}
else
{
lean_dec(v___x_3566_);
lean_dec(v_mantissa_3561_);
lean_dec(v_mantissa_3551_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3535_;
}
}
}
else
{
lean_dec(v_exponent_3562_);
lean_dec(v_mantissa_3561_);
lean_dec(v_mantissa_3551_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3532_;
}
}
else
{
lean_dec(v_val_3559_);
lean_dec(v_mantissa_3551_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3532_;
}
}
else
{
lean_dec(v___x_3558_);
lean_dec(v_mantissa_3551_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3532_;
}
}
}
else
{
lean_dec(v_exponent_3552_);
lean_dec(v_mantissa_3551_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3529_;
}
}
else
{
lean_dec(v_val_3549_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3529_;
}
}
else
{
lean_dec(v___x_3548_);
lean_dec(v_kvPairs_3546_);
lean_del_object(v___x_3544_);
lean_dec(v_tail_3542_);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
goto v___jp_3529_;
}
}
}
else
{
lean_object* v___x_3619_; lean_object* v___x_3620_; 
lean_dec(v_head_3541_);
lean_dec_ref_known(v_x_3525_, 2);
lean_dec_ref(v___y_3527_);
lean_dec(v_x_3526_);
v___x_3619_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3620_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3620_, 0, v___x_3619_);
return v___x_3620_;
}
}
v___jp_3529_:
{
lean_object* v___x_3530_; lean_object* v___x_3531_; 
v___x_3530_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3531_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3531_, 0, v___x_3530_);
return v___x_3531_;
}
v___jp_3532_:
{
lean_object* v___x_3533_; lean_object* v___x_3534_; 
v___x_3533_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3534_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3534_, 0, v___x_3533_);
return v___x_3534_;
}
v___jp_3535_:
{
lean_object* v___x_3536_; lean_object* v___x_3537_; 
v___x_3536_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3537_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3537_, 0, v___x_3536_);
return v___x_3537_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___boxed(lean_object* v_x_3621_, lean_object* v_x_3622_, lean_object* v___y_3623_, lean_object* v___y_3624_){
_start:
{
lean_object* v_res_3625_; 
v_res_3625_ = lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0(v_x_3621_, v_x_3622_, v___y_3623_);
return v_res_3625_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo(lean_object* v_json_3630_, lean_object* v_a_3631_){
_start:
{
if (lean_obj_tag(v_json_3630_) == 5)
{
lean_object* v_kvPairs_3666_; lean_object* v___x_3667_; lean_object* v___x_3668_; 
v_kvPairs_3666_ = lean_ctor_get(v_json_3630_, 0);
v___x_3667_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprConst___closed__0));
v___x_3668_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3667_);
if (lean_obj_tag(v___x_3668_) == 1)
{
lean_object* v_val_3669_; 
v_val_3669_ = lean_ctor_get(v___x_3668_, 0);
lean_inc(v_val_3669_);
lean_dec_ref_known(v___x_3668_, 1);
if (lean_obj_tag(v_val_3669_) == 2)
{
lean_object* v_n_3670_; lean_object* v_mantissa_3671_; lean_object* v_exponent_3672_; lean_object* v_natZero_3673_; lean_object* v_intZero_3674_; uint8_t v_isNeg_3675_; 
v_n_3670_ = lean_ctor_get(v_val_3669_, 0);
lean_inc_ref(v_n_3670_);
lean_dec_ref_known(v_val_3669_, 1);
v_mantissa_3671_ = lean_ctor_get(v_n_3670_, 0);
lean_inc(v_mantissa_3671_);
v_exponent_3672_ = lean_ctor_get(v_n_3670_, 1);
lean_inc(v_exponent_3672_);
lean_dec_ref(v_n_3670_);
v_natZero_3673_ = lean_unsigned_to_nat(0u);
v_intZero_3674_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_3675_ = lean_int_dec_lt(v_mantissa_3671_, v_intZero_3674_);
if (v_isNeg_3675_ == 0)
{
uint8_t v___x_3676_; 
v___x_3676_ = lean_nat_dec_eq(v_exponent_3672_, v_natZero_3673_);
lean_dec(v_exponent_3672_);
if (v___x_3676_ == 0)
{
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3633_;
}
else
{
lean_object* v___x_3677_; lean_object* v___x_3678_; 
v___x_3677_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__2));
v___x_3678_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3677_);
if (lean_obj_tag(v___x_3678_) == 1)
{
lean_object* v_val_3679_; 
v_val_3679_ = lean_ctor_get(v___x_3678_, 0);
lean_inc(v_val_3679_);
lean_dec_ref_known(v___x_3678_, 1);
if (lean_obj_tag(v_val_3679_) == 4)
{
lean_object* v_elems_3680_; lean_object* v___x_3681_; lean_object* v___x_3682_; 
v_elems_3680_ = lean_ctor_get(v_val_3679_, 0);
lean_inc_ref(v_elems_3680_);
lean_dec_ref_known(v_val_3679_, 1);
v___x_3681_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseExprLam___closed__2));
v___x_3682_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3681_);
if (lean_obj_tag(v___x_3682_) == 1)
{
lean_object* v_val_3683_; 
v_val_3683_ = lean_ctor_get(v___x_3682_, 0);
lean_inc(v_val_3683_);
lean_dec_ref_known(v___x_3682_, 1);
if (lean_obj_tag(v_val_3683_) == 2)
{
lean_object* v_n_3684_; lean_object* v_mantissa_3685_; lean_object* v_exponent_3686_; uint8_t v_isNeg_3687_; 
v_n_3684_ = lean_ctor_get(v_val_3683_, 0);
lean_inc_ref(v_n_3684_);
lean_dec_ref_known(v_val_3683_, 1);
v_mantissa_3685_ = lean_ctor_get(v_n_3684_, 0);
lean_inc(v_mantissa_3685_);
v_exponent_3686_ = lean_ctor_get(v_n_3684_, 1);
lean_inc(v_exponent_3686_);
lean_dec_ref(v_n_3684_);
v_isNeg_3687_ = lean_int_dec_lt(v_mantissa_3685_, v_intZero_3674_);
if (v_isNeg_3687_ == 0)
{
uint8_t v___x_3688_; 
v___x_3688_ = lean_nat_dec_eq(v_exponent_3686_, v_natZero_3673_);
lean_dec(v_exponent_3686_);
if (v___x_3688_ == 0)
{
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3639_;
}
else
{
lean_object* v___x_3689_; lean_object* v___x_3690_; 
v___x_3689_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__4));
v___x_3690_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3689_);
if (lean_obj_tag(v___x_3690_) == 1)
{
lean_object* v_val_3691_; 
v_val_3691_ = lean_ctor_get(v___x_3690_, 0);
lean_inc(v_val_3691_);
lean_dec_ref_known(v___x_3690_, 1);
if (lean_obj_tag(v_val_3691_) == 4)
{
lean_object* v_elems_3692_; lean_object* v___x_3693_; lean_object* v___x_3694_; 
v_elems_3692_ = lean_ctor_get(v_val_3691_, 0);
lean_inc_ref(v_elems_3692_);
lean_dec_ref_known(v_val_3691_, 1);
v___x_3693_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__2));
v___x_3694_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3693_);
if (lean_obj_tag(v___x_3694_) == 1)
{
lean_object* v_val_3695_; 
v_val_3695_ = lean_ctor_get(v___x_3694_, 0);
lean_inc(v_val_3695_);
lean_dec_ref_known(v___x_3694_, 1);
if (lean_obj_tag(v_val_3695_) == 2)
{
lean_object* v_n_3696_; lean_object* v_mantissa_3697_; lean_object* v_exponent_3698_; uint8_t v_isNeg_3699_; 
v_n_3696_ = lean_ctor_get(v_val_3695_, 0);
lean_inc_ref(v_n_3696_);
lean_dec_ref_known(v_val_3695_, 1);
v_mantissa_3697_ = lean_ctor_get(v_n_3696_, 0);
lean_inc(v_mantissa_3697_);
v_exponent_3698_ = lean_ctor_get(v_n_3696_, 1);
lean_inc(v_exponent_3698_);
lean_dec_ref(v_n_3696_);
v_isNeg_3699_ = lean_int_dec_lt(v_mantissa_3697_, v_intZero_3674_);
if (v_isNeg_3699_ == 0)
{
uint8_t v___x_3700_; 
v___x_3700_ = lean_nat_dec_eq(v_exponent_3698_, v_natZero_3673_);
lean_dec(v_exponent_3698_);
if (v___x_3700_ == 0)
{
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3645_;
}
else
{
lean_object* v___x_3701_; lean_object* v___x_3702_; 
v___x_3701_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__3));
v___x_3702_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3701_);
if (lean_obj_tag(v___x_3702_) == 1)
{
lean_object* v_val_3703_; 
v_val_3703_ = lean_ctor_get(v___x_3702_, 0);
lean_inc(v_val_3703_);
lean_dec_ref_known(v___x_3702_, 1);
if (lean_obj_tag(v_val_3703_) == 2)
{
lean_object* v_n_3704_; lean_object* v_mantissa_3705_; lean_object* v_exponent_3706_; uint8_t v_isNeg_3707_; 
v_n_3704_ = lean_ctor_get(v_val_3703_, 0);
lean_inc_ref(v_n_3704_);
lean_dec_ref_known(v_val_3703_, 1);
v_mantissa_3705_ = lean_ctor_get(v_n_3704_, 0);
lean_inc(v_mantissa_3705_);
v_exponent_3706_ = lean_ctor_get(v_n_3704_, 1);
lean_inc(v_exponent_3706_);
lean_dec_ref(v_n_3704_);
v_isNeg_3707_ = lean_int_dec_lt(v_mantissa_3705_, v_intZero_3674_);
if (v_isNeg_3707_ == 0)
{
uint8_t v___x_3708_; 
v___x_3708_ = lean_nat_dec_eq(v_exponent_3706_, v_natZero_3673_);
lean_dec(v_exponent_3706_);
if (v___x_3708_ == 0)
{
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3648_;
}
else
{
lean_object* v___x_3709_; lean_object* v___x_3710_; 
v___x_3709_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseRecInfo___closed__0));
v___x_3710_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3709_);
if (lean_obj_tag(v___x_3710_) == 1)
{
lean_object* v_val_3711_; 
v_val_3711_ = lean_ctor_get(v___x_3710_, 0);
lean_inc(v_val_3711_);
lean_dec_ref_known(v___x_3710_, 1);
if (lean_obj_tag(v_val_3711_) == 2)
{
lean_object* v_n_3712_; lean_object* v_mantissa_3713_; lean_object* v_exponent_3714_; uint8_t v_isNeg_3715_; 
v_n_3712_ = lean_ctor_get(v_val_3711_, 0);
lean_inc_ref(v_n_3712_);
lean_dec_ref_known(v_val_3711_, 1);
v_mantissa_3713_ = lean_ctor_get(v_n_3712_, 0);
lean_inc(v_mantissa_3713_);
v_exponent_3714_ = lean_ctor_get(v_n_3712_, 1);
lean_inc(v_exponent_3714_);
lean_dec_ref(v_n_3712_);
v_isNeg_3715_ = lean_int_dec_lt(v_mantissa_3713_, v_intZero_3674_);
if (v_isNeg_3715_ == 0)
{
uint8_t v___x_3716_; 
v___x_3716_ = lean_nat_dec_eq(v_exponent_3714_, v_natZero_3673_);
lean_dec(v_exponent_3714_);
if (v___x_3716_ == 0)
{
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3651_;
}
else
{
lean_object* v___x_3717_; lean_object* v___x_3718_; 
v___x_3717_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseRecInfo___closed__1));
v___x_3718_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3717_);
if (lean_obj_tag(v___x_3718_) == 1)
{
lean_object* v_val_3719_; 
v_val_3719_ = lean_ctor_get(v___x_3718_, 0);
lean_inc(v_val_3719_);
lean_dec_ref_known(v___x_3718_, 1);
if (lean_obj_tag(v_val_3719_) == 2)
{
lean_object* v_n_3720_; lean_object* v_mantissa_3721_; lean_object* v_exponent_3722_; uint8_t v_isNeg_3723_; 
v_n_3720_ = lean_ctor_get(v_val_3719_, 0);
lean_inc_ref(v_n_3720_);
lean_dec_ref_known(v_val_3719_, 1);
v_mantissa_3721_ = lean_ctor_get(v_n_3720_, 0);
lean_inc(v_mantissa_3721_);
v_exponent_3722_ = lean_ctor_get(v_n_3720_, 1);
lean_inc(v_exponent_3722_);
lean_dec_ref(v_n_3720_);
v_isNeg_3723_ = lean_int_dec_lt(v_mantissa_3721_, v_intZero_3674_);
if (v_isNeg_3723_ == 0)
{
uint8_t v___x_3724_; 
v___x_3724_ = lean_nat_dec_eq(v_exponent_3722_, v_natZero_3673_);
lean_dec(v_exponent_3722_);
if (v___x_3724_ == 0)
{
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3654_;
}
else
{
lean_object* v___x_3725_; lean_object* v___x_3726_; 
v___x_3725_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseRecInfo___closed__2));
v___x_3726_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3725_);
if (lean_obj_tag(v___x_3726_) == 1)
{
lean_object* v_val_3727_; 
v_val_3727_ = lean_ctor_get(v___x_3726_, 0);
lean_inc(v_val_3727_);
lean_dec_ref_known(v___x_3726_, 1);
if (lean_obj_tag(v_val_3727_) == 1)
{
uint8_t v_b_3728_; lean_object* v___x_3729_; lean_object* v___x_3730_; 
v_b_3728_ = lean_ctor_get_uint8(v_val_3727_, 0);
lean_dec_ref_known(v_val_3727_, 0);
v___x_3729_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseRecInfo___closed__3));
v___x_3730_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3729_);
if (lean_obj_tag(v___x_3730_) == 1)
{
lean_object* v_val_3731_; 
v_val_3731_ = lean_ctor_get(v___x_3730_, 0);
lean_inc(v_val_3731_);
lean_dec_ref_known(v___x_3730_, 1);
if (lean_obj_tag(v_val_3731_) == 4)
{
lean_object* v_elems_3732_; lean_object* v___x_3734_; uint8_t v_isShared_3735_; uint8_t v_isSharedCheck_3870_; 
v_elems_3732_ = lean_ctor_get(v_val_3731_, 0);
v_isSharedCheck_3870_ = !lean_is_exclusive(v_val_3731_);
if (v_isSharedCheck_3870_ == 0)
{
v___x_3734_ = v_val_3731_;
v_isShared_3735_ = v_isSharedCheck_3870_;
goto v_resetjp_3733_;
}
else
{
lean_inc(v_elems_3732_);
lean_dec(v_val_3731_);
v___x_3734_ = lean_box(0);
v_isShared_3735_ = v_isSharedCheck_3870_;
goto v_resetjp_3733_;
}
v_resetjp_3733_:
{
lean_object* v___x_3736_; lean_object* v___x_3737_; 
v___x_3736_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseAxiomInfo___closed__3));
v___x_3737_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_kvPairs_3666_, v___x_3736_);
if (lean_obj_tag(v___x_3737_) == 1)
{
lean_object* v_val_3738_; lean_object* v___x_3740_; uint8_t v_isShared_3741_; uint8_t v_isSharedCheck_3869_; 
v_val_3738_ = lean_ctor_get(v___x_3737_, 0);
v_isSharedCheck_3869_ = !lean_is_exclusive(v___x_3737_);
if (v_isSharedCheck_3869_ == 0)
{
v___x_3740_ = v___x_3737_;
v_isShared_3741_ = v_isSharedCheck_3869_;
goto v_resetjp_3739_;
}
else
{
lean_inc(v_val_3738_);
lean_dec(v___x_3737_);
v___x_3740_ = lean_box(0);
v_isShared_3741_ = v_isSharedCheck_3869_;
goto v_resetjp_3739_;
}
v_resetjp_3739_:
{
if (lean_obj_tag(v_val_3738_) == 1)
{
uint8_t v_b_3742_; lean_object* v_nameMap_3743_; lean_object* v_a_3744_; lean_object* v___x_3745_; 
v_b_3742_ = lean_ctor_get_uint8(v_val_3738_, 0);
lean_dec_ref_known(v_val_3738_, 0);
v_nameMap_3743_ = lean_ctor_get(v_a_3631_, 1);
v_a_3744_ = lean_nat_abs(v_mantissa_3671_);
lean_dec(v_mantissa_3671_);
v___x_3745_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_3743_, v_a_3744_);
if (lean_obj_tag(v___x_3745_) == 1)
{
lean_object* v_val_3746_; lean_object* v___x_3748_; uint8_t v_isShared_3749_; uint8_t v_isSharedCheck_3859_; 
lean_dec(v_a_3744_);
lean_del_object(v___x_3740_);
lean_del_object(v___x_3734_);
v_val_3746_ = lean_ctor_get(v___x_3745_, 0);
v_isSharedCheck_3859_ = !lean_is_exclusive(v___x_3745_);
if (v_isSharedCheck_3859_ == 0)
{
v___x_3748_ = v___x_3745_;
v_isShared_3749_ = v_isSharedCheck_3859_;
goto v_resetjp_3747_;
}
else
{
lean_inc(v_val_3746_);
lean_dec(v___x_3745_);
v___x_3748_ = lean_box(0);
v_isShared_3749_ = v_isSharedCheck_3859_;
goto v_resetjp_3747_;
}
v_resetjp_3747_:
{
lean_object* v___x_3750_; 
v___x_3750_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_3680_, v_a_3631_);
if (lean_obj_tag(v___x_3750_) == 0)
{
lean_object* v_a_3751_; lean_object* v___x_3753_; uint8_t v_isShared_3754_; uint8_t v_isSharedCheck_3850_; 
v_a_3751_ = lean_ctor_get(v___x_3750_, 0);
v_isSharedCheck_3850_ = !lean_is_exclusive(v___x_3750_);
if (v_isSharedCheck_3850_ == 0)
{
v___x_3753_ = v___x_3750_;
v_isShared_3754_ = v_isSharedCheck_3850_;
goto v_resetjp_3752_;
}
else
{
lean_inc(v_a_3751_);
lean_dec(v___x_3750_);
v___x_3753_ = lean_box(0);
v_isShared_3754_ = v_isSharedCheck_3850_;
goto v_resetjp_3752_;
}
v_resetjp_3752_:
{
lean_object* v_snd_3755_; lean_object* v_fst_3756_; lean_object* v_exprMap_3757_; lean_object* v_a_3758_; lean_object* v___x_3759_; 
v_snd_3755_ = lean_ctor_get(v_a_3751_, 1);
lean_inc(v_snd_3755_);
v_fst_3756_ = lean_ctor_get(v_a_3751_, 0);
lean_inc(v_fst_3756_);
lean_dec(v_a_3751_);
v_exprMap_3757_ = lean_ctor_get(v_snd_3755_, 3);
v_a_3758_ = lean_nat_abs(v_mantissa_3685_);
lean_dec(v_mantissa_3685_);
v___x_3759_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_3757_, v_a_3758_);
if (lean_obj_tag(v___x_3759_) == 1)
{
lean_object* v_val_3760_; lean_object* v___x_3762_; uint8_t v_isShared_3763_; uint8_t v_isSharedCheck_3840_; 
lean_dec(v_a_3758_);
lean_del_object(v___x_3753_);
lean_del_object(v___x_3748_);
v_val_3760_ = lean_ctor_get(v___x_3759_, 0);
v_isSharedCheck_3840_ = !lean_is_exclusive(v___x_3759_);
if (v_isSharedCheck_3840_ == 0)
{
v___x_3762_ = v___x_3759_;
v_isShared_3763_ = v_isSharedCheck_3840_;
goto v_resetjp_3761_;
}
else
{
lean_inc(v_val_3760_);
lean_dec(v___x_3759_);
v___x_3762_ = lean_box(0);
v_isShared_3763_ = v_isSharedCheck_3840_;
goto v_resetjp_3761_;
}
v_resetjp_3761_:
{
lean_object* v___x_3764_; 
v___x_3764_ = lp_proofEnvironment_Export_Parse_getNameList(v_elems_3692_, v_snd_3755_);
if (lean_obj_tag(v___x_3764_) == 0)
{
lean_object* v_a_3765_; lean_object* v_fst_3766_; lean_object* v_snd_3767_; lean_object* v___x_3768_; lean_object* v___x_3769_; lean_object* v___x_3770_; 
v_a_3765_ = lean_ctor_get(v___x_3764_, 0);
lean_inc(v_a_3765_);
lean_dec_ref_known(v___x_3764_, 1);
v_fst_3766_ = lean_ctor_get(v_a_3765_, 0);
lean_inc(v_fst_3766_);
v_snd_3767_ = lean_ctor_get(v_a_3765_, 1);
lean_inc(v_snd_3767_);
lean_dec(v_a_3765_);
v___x_3768_ = lean_array_to_list(v_elems_3732_);
v___x_3769_ = lean_box(0);
v___x_3770_ = lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0(v___x_3768_, v___x_3769_, v_snd_3767_);
if (lean_obj_tag(v___x_3770_) == 0)
{
lean_object* v_a_3771_; lean_object* v___x_3773_; uint8_t v_isShared_3774_; uint8_t v_isSharedCheck_3823_; 
v_a_3771_ = lean_ctor_get(v___x_3770_, 0);
v_isSharedCheck_3823_ = !lean_is_exclusive(v___x_3770_);
if (v_isSharedCheck_3823_ == 0)
{
v___x_3773_ = v___x_3770_;
v_isShared_3774_ = v_isSharedCheck_3823_;
goto v_resetjp_3772_;
}
else
{
lean_inc(v_a_3771_);
lean_dec(v___x_3770_);
v___x_3773_ = lean_box(0);
v_isShared_3774_ = v_isSharedCheck_3823_;
goto v_resetjp_3772_;
}
v_resetjp_3772_:
{
lean_object* v_snd_3775_; lean_object* v_fst_3776_; lean_object* v___x_3778_; uint8_t v_isShared_3779_; uint8_t v_isSharedCheck_3822_; 
v_snd_3775_ = lean_ctor_get(v_a_3771_, 1);
v_fst_3776_ = lean_ctor_get(v_a_3771_, 0);
v_isSharedCheck_3822_ = !lean_is_exclusive(v_a_3771_);
if (v_isSharedCheck_3822_ == 0)
{
v___x_3778_ = v_a_3771_;
v_isShared_3779_ = v_isSharedCheck_3822_;
goto v_resetjp_3777_;
}
else
{
lean_inc(v_snd_3775_);
lean_inc(v_fst_3776_);
lean_dec(v_a_3771_);
v___x_3778_ = lean_box(0);
v_isShared_3779_ = v_isSharedCheck_3822_;
goto v_resetjp_3777_;
}
v_resetjp_3777_:
{
lean_object* v_stream_3780_; lean_object* v_nameMap_3781_; lean_object* v_levelMap_3782_; lean_object* v_exprMap_3783_; lean_object* v_recursorRuleMap_3784_; lean_object* v_constMap_3785_; lean_object* v_constOrder_3786_; lean_object* v___x_3788_; uint8_t v_isShared_3789_; uint8_t v_isSharedCheck_3821_; 
v_stream_3780_ = lean_ctor_get(v_snd_3775_, 0);
v_nameMap_3781_ = lean_ctor_get(v_snd_3775_, 1);
v_levelMap_3782_ = lean_ctor_get(v_snd_3775_, 2);
v_exprMap_3783_ = lean_ctor_get(v_snd_3775_, 3);
v_recursorRuleMap_3784_ = lean_ctor_get(v_snd_3775_, 4);
v_constMap_3785_ = lean_ctor_get(v_snd_3775_, 5);
v_constOrder_3786_ = lean_ctor_get(v_snd_3775_, 6);
v_isSharedCheck_3821_ = !lean_is_exclusive(v_snd_3775_);
if (v_isSharedCheck_3821_ == 0)
{
v___x_3788_ = v_snd_3775_;
v_isShared_3789_ = v_isSharedCheck_3821_;
goto v_resetjp_3787_;
}
else
{
lean_inc(v_constOrder_3786_);
lean_inc(v_constMap_3785_);
lean_inc(v_recursorRuleMap_3784_);
lean_inc(v_exprMap_3783_);
lean_inc(v_levelMap_3782_);
lean_inc(v_nameMap_3781_);
lean_inc(v_stream_3780_);
lean_dec(v_snd_3775_);
v___x_3788_ = lean_box(0);
v_isShared_3789_ = v_isSharedCheck_3821_;
goto v_resetjp_3787_;
}
v_resetjp_3787_:
{
uint8_t v___x_3790_; 
v___x_3790_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_constMap_3785_, v_val_3746_);
if (v___x_3790_ == 0)
{
lean_object* v_a_3791_; lean_object* v_a_3792_; lean_object* v_a_3793_; lean_object* v_a_3794_; lean_object* v___x_3795_; lean_object* v___x_3796_; lean_object* v___x_3798_; 
v_a_3791_ = lean_nat_abs(v_mantissa_3697_);
lean_dec(v_mantissa_3697_);
v_a_3792_ = lean_nat_abs(v_mantissa_3705_);
lean_dec(v_mantissa_3705_);
v_a_3793_ = lean_nat_abs(v_mantissa_3713_);
lean_dec(v_mantissa_3713_);
v_a_3794_ = lean_nat_abs(v_mantissa_3721_);
lean_dec(v_mantissa_3721_);
lean_inc(v_val_3746_);
v___x_3795_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3795_, 0, v_val_3746_);
lean_ctor_set(v___x_3795_, 1, v_fst_3756_);
lean_ctor_set(v___x_3795_, 2, v_val_3760_);
v___x_3796_ = lean_alloc_ctor(0, 7, 2);
lean_ctor_set(v___x_3796_, 0, v___x_3795_);
lean_ctor_set(v___x_3796_, 1, v_fst_3766_);
lean_ctor_set(v___x_3796_, 2, v_a_3791_);
lean_ctor_set(v___x_3796_, 3, v_a_3792_);
lean_ctor_set(v___x_3796_, 4, v_a_3793_);
lean_ctor_set(v___x_3796_, 5, v_a_3794_);
lean_ctor_set(v___x_3796_, 6, v_fst_3776_);
lean_ctor_set_uint8(v___x_3796_, sizeof(void*)*7, v_b_3728_);
lean_ctor_set_uint8(v___x_3796_, sizeof(void*)*7 + 1, v_b_3742_);
if (v_isShared_3763_ == 0)
{
lean_ctor_set_tag(v___x_3762_, 7);
lean_ctor_set(v___x_3762_, 0, v___x_3796_);
v___x_3798_ = v___x_3762_;
goto v_reusejp_3797_;
}
else
{
lean_object* v_reuseFailAlloc_3811_; 
v_reuseFailAlloc_3811_ = lean_alloc_ctor(7, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3811_, 0, v___x_3796_);
v___x_3798_ = v_reuseFailAlloc_3811_;
goto v_reusejp_3797_;
}
v_reusejp_3797_:
{
lean_object* v___x_3799_; lean_object* v___x_3800_; lean_object* v___x_3801_; lean_object* v___x_3803_; 
v___x_3799_ = lean_box(0);
lean_inc(v_val_3746_);
v___x_3800_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertMany___at___00__private_Std_Data_DTreeMap_Internal_Lemmas_0__Std_DTreeMap_Internal_Impl_modifyMap_spec__0_spec__0___redArg(v_constMap_3785_, v_val_3746_, v___x_3798_);
v___x_3801_ = lean_array_push(v_constOrder_3786_, v_val_3746_);
if (v_isShared_3789_ == 0)
{
lean_ctor_set(v___x_3788_, 6, v___x_3801_);
lean_ctor_set(v___x_3788_, 5, v___x_3800_);
v___x_3803_ = v___x_3788_;
goto v_reusejp_3802_;
}
else
{
lean_object* v_reuseFailAlloc_3810_; 
v_reuseFailAlloc_3810_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_3810_, 0, v_stream_3780_);
lean_ctor_set(v_reuseFailAlloc_3810_, 1, v_nameMap_3781_);
lean_ctor_set(v_reuseFailAlloc_3810_, 2, v_levelMap_3782_);
lean_ctor_set(v_reuseFailAlloc_3810_, 3, v_exprMap_3783_);
lean_ctor_set(v_reuseFailAlloc_3810_, 4, v_recursorRuleMap_3784_);
lean_ctor_set(v_reuseFailAlloc_3810_, 5, v___x_3800_);
lean_ctor_set(v_reuseFailAlloc_3810_, 6, v___x_3801_);
v___x_3803_ = v_reuseFailAlloc_3810_;
goto v_reusejp_3802_;
}
v_reusejp_3802_:
{
lean_object* v___x_3805_; 
if (v_isShared_3779_ == 0)
{
lean_ctor_set(v___x_3778_, 1, v___x_3803_);
lean_ctor_set(v___x_3778_, 0, v___x_3799_);
v___x_3805_ = v___x_3778_;
goto v_reusejp_3804_;
}
else
{
lean_object* v_reuseFailAlloc_3809_; 
v_reuseFailAlloc_3809_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3809_, 0, v___x_3799_);
lean_ctor_set(v_reuseFailAlloc_3809_, 1, v___x_3803_);
v___x_3805_ = v_reuseFailAlloc_3809_;
goto v_reusejp_3804_;
}
v_reusejp_3804_:
{
lean_object* v___x_3807_; 
if (v_isShared_3774_ == 0)
{
lean_ctor_set(v___x_3773_, 0, v___x_3805_);
v___x_3807_ = v___x_3773_;
goto v_reusejp_3806_;
}
else
{
lean_object* v_reuseFailAlloc_3808_; 
v_reuseFailAlloc_3808_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3808_, 0, v___x_3805_);
v___x_3807_ = v_reuseFailAlloc_3808_;
goto v_reusejp_3806_;
}
v_reusejp_3806_:
{
return v___x_3807_;
}
}
}
}
}
else
{
lean_object* v___x_3812_; lean_object* v___x_3813_; lean_object* v___x_3814_; lean_object* v___x_3816_; 
lean_del_object(v___x_3788_);
lean_dec_ref(v_constOrder_3786_);
lean_dec_ref(v_constMap_3785_);
lean_dec_ref(v_recursorRuleMap_3784_);
lean_dec_ref(v_exprMap_3783_);
lean_dec_ref(v_levelMap_3782_);
lean_dec_ref(v_nameMap_3781_);
lean_dec_ref(v_stream_3780_);
lean_del_object(v___x_3778_);
lean_dec(v_fst_3776_);
lean_dec(v_fst_3766_);
lean_dec(v_val_3760_);
lean_dec(v_fst_3756_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
v___x_3812_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_addConst___closed__2));
v___x_3813_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_val_3746_, v___x_3790_);
v___x_3814_ = lean_string_append(v___x_3812_, v___x_3813_);
lean_dec_ref(v___x_3813_);
if (v_isShared_3763_ == 0)
{
lean_ctor_set_tag(v___x_3762_, 18);
lean_ctor_set(v___x_3762_, 0, v___x_3814_);
v___x_3816_ = v___x_3762_;
goto v_reusejp_3815_;
}
else
{
lean_object* v_reuseFailAlloc_3820_; 
v_reuseFailAlloc_3820_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3820_, 0, v___x_3814_);
v___x_3816_ = v_reuseFailAlloc_3820_;
goto v_reusejp_3815_;
}
v_reusejp_3815_:
{
lean_object* v___x_3818_; 
if (v_isShared_3774_ == 0)
{
lean_ctor_set_tag(v___x_3773_, 1);
lean_ctor_set(v___x_3773_, 0, v___x_3816_);
v___x_3818_ = v___x_3773_;
goto v_reusejp_3817_;
}
else
{
lean_object* v_reuseFailAlloc_3819_; 
v_reuseFailAlloc_3819_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3819_, 0, v___x_3816_);
v___x_3818_ = v_reuseFailAlloc_3819_;
goto v_reusejp_3817_;
}
v_reusejp_3817_:
{
return v___x_3818_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3824_; lean_object* v___x_3826_; uint8_t v_isShared_3827_; uint8_t v_isSharedCheck_3831_; 
lean_dec(v_fst_3766_);
lean_del_object(v___x_3762_);
lean_dec(v_val_3760_);
lean_dec(v_fst_3756_);
lean_dec(v_val_3746_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
v_a_3824_ = lean_ctor_get(v___x_3770_, 0);
v_isSharedCheck_3831_ = !lean_is_exclusive(v___x_3770_);
if (v_isSharedCheck_3831_ == 0)
{
v___x_3826_ = v___x_3770_;
v_isShared_3827_ = v_isSharedCheck_3831_;
goto v_resetjp_3825_;
}
else
{
lean_inc(v_a_3824_);
lean_dec(v___x_3770_);
v___x_3826_ = lean_box(0);
v_isShared_3827_ = v_isSharedCheck_3831_;
goto v_resetjp_3825_;
}
v_resetjp_3825_:
{
lean_object* v___x_3829_; 
if (v_isShared_3827_ == 0)
{
v___x_3829_ = v___x_3826_;
goto v_reusejp_3828_;
}
else
{
lean_object* v_reuseFailAlloc_3830_; 
v_reuseFailAlloc_3830_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3830_, 0, v_a_3824_);
v___x_3829_ = v_reuseFailAlloc_3830_;
goto v_reusejp_3828_;
}
v_reusejp_3828_:
{
return v___x_3829_;
}
}
}
}
else
{
lean_object* v_a_3832_; lean_object* v___x_3834_; uint8_t v_isShared_3835_; uint8_t v_isSharedCheck_3839_; 
lean_del_object(v___x_3762_);
lean_dec(v_val_3760_);
lean_dec(v_fst_3756_);
lean_dec(v_val_3746_);
lean_dec_ref(v_elems_3732_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
v_a_3832_ = lean_ctor_get(v___x_3764_, 0);
v_isSharedCheck_3839_ = !lean_is_exclusive(v___x_3764_);
if (v_isSharedCheck_3839_ == 0)
{
v___x_3834_ = v___x_3764_;
v_isShared_3835_ = v_isSharedCheck_3839_;
goto v_resetjp_3833_;
}
else
{
lean_inc(v_a_3832_);
lean_dec(v___x_3764_);
v___x_3834_ = lean_box(0);
v_isShared_3835_ = v_isSharedCheck_3839_;
goto v_resetjp_3833_;
}
v_resetjp_3833_:
{
lean_object* v___x_3837_; 
if (v_isShared_3835_ == 0)
{
v___x_3837_ = v___x_3834_;
goto v_reusejp_3836_;
}
else
{
lean_object* v_reuseFailAlloc_3838_; 
v_reuseFailAlloc_3838_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3838_, 0, v_a_3832_);
v___x_3837_ = v_reuseFailAlloc_3838_;
goto v_reusejp_3836_;
}
v_reusejp_3836_:
{
return v___x_3837_;
}
}
}
}
}
else
{
lean_object* v___x_3841_; lean_object* v___x_3842_; lean_object* v___x_3843_; lean_object* v___x_3845_; 
lean_dec(v___x_3759_);
lean_dec(v_fst_3756_);
lean_dec(v_snd_3755_);
lean_dec(v_val_3746_);
lean_dec_ref(v_elems_3732_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
v___x_3841_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getExpr___closed__0));
v___x_3842_ = l_Nat_reprFast(v_a_3758_);
v___x_3843_ = lean_string_append(v___x_3841_, v___x_3842_);
lean_dec_ref(v___x_3842_);
if (v_isShared_3749_ == 0)
{
lean_ctor_set_tag(v___x_3748_, 18);
lean_ctor_set(v___x_3748_, 0, v___x_3843_);
v___x_3845_ = v___x_3748_;
goto v_reusejp_3844_;
}
else
{
lean_object* v_reuseFailAlloc_3849_; 
v_reuseFailAlloc_3849_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3849_, 0, v___x_3843_);
v___x_3845_ = v_reuseFailAlloc_3849_;
goto v_reusejp_3844_;
}
v_reusejp_3844_:
{
lean_object* v___x_3847_; 
if (v_isShared_3754_ == 0)
{
lean_ctor_set_tag(v___x_3753_, 1);
lean_ctor_set(v___x_3753_, 0, v___x_3845_);
v___x_3847_ = v___x_3753_;
goto v_reusejp_3846_;
}
else
{
lean_object* v_reuseFailAlloc_3848_; 
v_reuseFailAlloc_3848_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3848_, 0, v___x_3845_);
v___x_3847_ = v_reuseFailAlloc_3848_;
goto v_reusejp_3846_;
}
v_reusejp_3846_:
{
return v___x_3847_;
}
}
}
}
}
else
{
lean_object* v_a_3851_; lean_object* v___x_3853_; uint8_t v_isShared_3854_; uint8_t v_isSharedCheck_3858_; 
lean_del_object(v___x_3748_);
lean_dec(v_val_3746_);
lean_dec_ref(v_elems_3732_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
v_a_3851_ = lean_ctor_get(v___x_3750_, 0);
v_isSharedCheck_3858_ = !lean_is_exclusive(v___x_3750_);
if (v_isSharedCheck_3858_ == 0)
{
v___x_3853_ = v___x_3750_;
v_isShared_3854_ = v_isSharedCheck_3858_;
goto v_resetjp_3852_;
}
else
{
lean_inc(v_a_3851_);
lean_dec(v___x_3750_);
v___x_3853_ = lean_box(0);
v_isShared_3854_ = v_isSharedCheck_3858_;
goto v_resetjp_3852_;
}
v_resetjp_3852_:
{
lean_object* v___x_3856_; 
if (v_isShared_3854_ == 0)
{
v___x_3856_ = v___x_3853_;
goto v_reusejp_3855_;
}
else
{
lean_object* v_reuseFailAlloc_3857_; 
v_reuseFailAlloc_3857_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3857_, 0, v_a_3851_);
v___x_3856_ = v_reuseFailAlloc_3857_;
goto v_reusejp_3855_;
}
v_reusejp_3855_:
{
return v___x_3856_;
}
}
}
}
}
else
{
lean_object* v___x_3860_; lean_object* v___x_3861_; lean_object* v___x_3862_; lean_object* v___x_3864_; 
lean_dec(v___x_3745_);
lean_dec_ref(v_elems_3732_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec_ref(v_a_3631_);
v___x_3860_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_getName___closed__2));
v___x_3861_ = l_Nat_reprFast(v_a_3744_);
v___x_3862_ = lean_string_append(v___x_3860_, v___x_3861_);
lean_dec_ref(v___x_3861_);
if (v_isShared_3741_ == 0)
{
lean_ctor_set_tag(v___x_3740_, 18);
lean_ctor_set(v___x_3740_, 0, v___x_3862_);
v___x_3864_ = v___x_3740_;
goto v_reusejp_3863_;
}
else
{
lean_object* v_reuseFailAlloc_3868_; 
v_reuseFailAlloc_3868_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3868_, 0, v___x_3862_);
v___x_3864_ = v_reuseFailAlloc_3868_;
goto v_reusejp_3863_;
}
v_reusejp_3863_:
{
lean_object* v___x_3866_; 
if (v_isShared_3735_ == 0)
{
lean_ctor_set_tag(v___x_3734_, 1);
lean_ctor_set(v___x_3734_, 0, v___x_3864_);
v___x_3866_ = v___x_3734_;
goto v_reusejp_3865_;
}
else
{
lean_object* v_reuseFailAlloc_3867_; 
v_reuseFailAlloc_3867_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3867_, 0, v___x_3864_);
v___x_3866_ = v_reuseFailAlloc_3867_;
goto v_reusejp_3865_;
}
v_reusejp_3865_:
{
return v___x_3866_;
}
}
}
}
else
{
lean_del_object(v___x_3740_);
lean_dec(v_val_3738_);
lean_del_object(v___x_3734_);
lean_dec_ref(v_elems_3732_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3663_;
}
}
}
else
{
lean_dec(v___x_3737_);
lean_del_object(v___x_3734_);
lean_dec_ref(v_elems_3732_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3663_;
}
}
}
else
{
lean_dec(v_val_3731_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3660_;
}
}
else
{
lean_dec(v___x_3730_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3660_;
}
}
else
{
lean_dec(v_val_3727_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3657_;
}
}
else
{
lean_dec(v___x_3726_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3657_;
}
}
}
else
{
lean_dec(v_exponent_3722_);
lean_dec(v_mantissa_3721_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3654_;
}
}
else
{
lean_dec(v_val_3719_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3654_;
}
}
else
{
lean_dec(v___x_3718_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3654_;
}
}
}
else
{
lean_dec(v_exponent_3714_);
lean_dec(v_mantissa_3713_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3651_;
}
}
else
{
lean_dec(v_val_3711_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3651_;
}
}
else
{
lean_dec(v___x_3710_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3651_;
}
}
}
else
{
lean_dec(v_exponent_3706_);
lean_dec(v_mantissa_3705_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3648_;
}
}
else
{
lean_dec(v_val_3703_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3648_;
}
}
else
{
lean_dec(v___x_3702_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3648_;
}
}
}
else
{
lean_dec(v_exponent_3698_);
lean_dec(v_mantissa_3697_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3645_;
}
}
else
{
lean_dec(v_val_3695_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3645_;
}
}
else
{
lean_dec(v___x_3694_);
lean_dec_ref(v_elems_3692_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3645_;
}
}
else
{
lean_dec(v_val_3691_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3642_;
}
}
else
{
lean_dec(v___x_3690_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3642_;
}
}
}
else
{
lean_dec(v_exponent_3686_);
lean_dec(v_mantissa_3685_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3639_;
}
}
else
{
lean_dec(v_val_3683_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3639_;
}
}
else
{
lean_dec(v___x_3682_);
lean_dec_ref(v_elems_3680_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3639_;
}
}
else
{
lean_dec(v_val_3679_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3636_;
}
}
else
{
lean_dec(v___x_3678_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3636_;
}
}
}
else
{
lean_dec(v_exponent_3672_);
lean_dec(v_mantissa_3671_);
lean_dec_ref(v_a_3631_);
goto v___jp_3633_;
}
}
else
{
lean_dec(v_val_3669_);
lean_dec_ref(v_a_3631_);
goto v___jp_3633_;
}
}
else
{
lean_dec(v___x_3668_);
lean_dec_ref(v_a_3631_);
goto v___jp_3633_;
}
}
else
{
lean_object* v___x_3871_; lean_object* v___x_3872_; 
lean_dec_ref(v_a_3631_);
v___x_3871_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3872_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3872_, 0, v___x_3871_);
return v___x_3872_;
}
v___jp_3633_:
{
lean_object* v___x_3634_; lean_object* v___x_3635_; 
v___x_3634_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3635_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3635_, 0, v___x_3634_);
return v___x_3635_;
}
v___jp_3636_:
{
lean_object* v___x_3637_; lean_object* v___x_3638_; 
v___x_3637_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3638_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3638_, 0, v___x_3637_);
return v___x_3638_;
}
v___jp_3639_:
{
lean_object* v___x_3640_; lean_object* v___x_3641_; 
v___x_3640_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3641_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3641_, 0, v___x_3640_);
return v___x_3641_;
}
v___jp_3642_:
{
lean_object* v___x_3643_; lean_object* v___x_3644_; 
v___x_3643_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3644_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3644_, 0, v___x_3643_);
return v___x_3644_;
}
v___jp_3645_:
{
lean_object* v___x_3646_; lean_object* v___x_3647_; 
v___x_3646_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3647_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3647_, 0, v___x_3646_);
return v___x_3647_;
}
v___jp_3648_:
{
lean_object* v___x_3649_; lean_object* v___x_3650_; 
v___x_3649_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3650_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3650_, 0, v___x_3649_);
return v___x_3650_;
}
v___jp_3651_:
{
lean_object* v___x_3652_; lean_object* v___x_3653_; 
v___x_3652_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3653_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3653_, 0, v___x_3652_);
return v___x_3653_;
}
v___jp_3654_:
{
lean_object* v___x_3655_; lean_object* v___x_3656_; 
v___x_3655_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3656_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3656_, 0, v___x_3655_);
return v___x_3656_;
}
v___jp_3657_:
{
lean_object* v___x_3658_; lean_object* v___x_3659_; 
v___x_3658_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3659_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3659_, 0, v___x_3658_);
return v___x_3659_;
}
v___jp_3660_:
{
lean_object* v___x_3661_; lean_object* v___x_3662_; 
v___x_3661_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3662_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3662_, 0, v___x_3661_);
return v___x_3662_;
}
v___jp_3663_:
{
lean_object* v___x_3664_; lean_object* v___x_3665_; 
v___x_3664_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00Export_Parse_parseRecInfo_spec__0___closed__1));
v___x_3665_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3665_, 0, v___x_3664_);
return v___x_3665_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseRecInfo___boxed(lean_object* v_json_3873_, lean_object* v_a_3874_, lean_object* v_a_3875_){
_start:
{
lean_object* v_res_3876_; 
v_res_3876_ = lp_proofEnvironment_Export_Parse_parseRecInfo(v_json_3873_, v_a_3874_);
lean_dec(v_json_3873_);
return v_res_3876_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1(lean_object* v_as_3877_, size_t v_i_3878_, size_t v_stop_3879_, lean_object* v_b_3880_, lean_object* v___y_3881_){
_start:
{
uint8_t v___x_3883_; 
v___x_3883_ = lean_usize_dec_eq(v_i_3878_, v_stop_3879_);
if (v___x_3883_ == 0)
{
lean_object* v___x_3884_; lean_object* v___x_3885_; 
v___x_3884_ = lean_array_uget_borrowed(v_as_3877_, v_i_3878_);
v___x_3885_ = lp_proofEnvironment_Export_Parse_parseCtorInfo(v___x_3884_, v___y_3881_);
if (lean_obj_tag(v___x_3885_) == 0)
{
lean_object* v_a_3886_; lean_object* v_fst_3887_; lean_object* v_snd_3888_; size_t v___x_3889_; size_t v___x_3890_; 
v_a_3886_ = lean_ctor_get(v___x_3885_, 0);
lean_inc(v_a_3886_);
lean_dec_ref_known(v___x_3885_, 1);
v_fst_3887_ = lean_ctor_get(v_a_3886_, 0);
lean_inc(v_fst_3887_);
v_snd_3888_ = lean_ctor_get(v_a_3886_, 1);
lean_inc(v_snd_3888_);
lean_dec(v_a_3886_);
v___x_3889_ = ((size_t)1ULL);
v___x_3890_ = lean_usize_add(v_i_3878_, v___x_3889_);
v_i_3878_ = v___x_3890_;
v_b_3880_ = v_fst_3887_;
v___y_3881_ = v_snd_3888_;
goto _start;
}
else
{
return v___x_3885_;
}
}
else
{
lean_object* v___x_3892_; lean_object* v___x_3893_; 
v___x_3892_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3892_, 0, v_b_3880_);
lean_ctor_set(v___x_3892_, 1, v___y_3881_);
v___x_3893_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3893_, 0, v___x_3892_);
return v___x_3893_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1___boxed(lean_object* v_as_3894_, lean_object* v_i_3895_, lean_object* v_stop_3896_, lean_object* v_b_3897_, lean_object* v___y_3898_, lean_object* v___y_3899_){
_start:
{
size_t v_i_boxed_3900_; size_t v_stop_boxed_3901_; lean_object* v_res_3902_; 
v_i_boxed_3900_ = lean_unbox_usize(v_i_3895_);
lean_dec(v_i_3895_);
v_stop_boxed_3901_ = lean_unbox_usize(v_stop_3896_);
lean_dec(v_stop_3896_);
v_res_3902_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1(v_as_3894_, v_i_boxed_3900_, v_stop_boxed_3901_, v_b_3897_, v___y_3898_);
lean_dec_ref(v_as_3894_);
return v_res_3902_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0(lean_object* v_as_3903_, size_t v_i_3904_, size_t v_stop_3905_, lean_object* v_b_3906_, lean_object* v___y_3907_){
_start:
{
uint8_t v___x_3909_; 
v___x_3909_ = lean_usize_dec_eq(v_i_3904_, v_stop_3905_);
if (v___x_3909_ == 0)
{
lean_object* v___x_3910_; lean_object* v___x_3911_; 
v___x_3910_ = lean_array_uget_borrowed(v_as_3903_, v_i_3904_);
v___x_3911_ = lp_proofEnvironment_Export_Parse_parseRecInfo(v___x_3910_, v___y_3907_);
if (lean_obj_tag(v___x_3911_) == 0)
{
lean_object* v_a_3912_; lean_object* v_fst_3913_; lean_object* v_snd_3914_; size_t v___x_3915_; size_t v___x_3916_; 
v_a_3912_ = lean_ctor_get(v___x_3911_, 0);
lean_inc(v_a_3912_);
lean_dec_ref_known(v___x_3911_, 1);
v_fst_3913_ = lean_ctor_get(v_a_3912_, 0);
lean_inc(v_fst_3913_);
v_snd_3914_ = lean_ctor_get(v_a_3912_, 1);
lean_inc(v_snd_3914_);
lean_dec(v_a_3912_);
v___x_3915_ = ((size_t)1ULL);
v___x_3916_ = lean_usize_add(v_i_3904_, v___x_3915_);
v_i_3904_ = v___x_3916_;
v_b_3906_ = v_fst_3913_;
v___y_3907_ = v_snd_3914_;
goto _start;
}
else
{
return v___x_3911_;
}
}
else
{
lean_object* v___x_3918_; lean_object* v___x_3919_; 
v___x_3918_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3918_, 0, v_b_3906_);
lean_ctor_set(v___x_3918_, 1, v___y_3907_);
v___x_3919_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3919_, 0, v___x_3918_);
return v___x_3919_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0___boxed(lean_object* v_as_3920_, lean_object* v_i_3921_, lean_object* v_stop_3922_, lean_object* v_b_3923_, lean_object* v___y_3924_, lean_object* v___y_3925_){
_start:
{
size_t v_i_boxed_3926_; size_t v_stop_boxed_3927_; lean_object* v_res_3928_; 
v_i_boxed_3926_ = lean_unbox_usize(v_i_3921_);
lean_dec(v_i_3921_);
v_stop_boxed_3927_ = lean_unbox_usize(v_stop_3922_);
lean_dec(v_stop_3922_);
v_res_3928_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0(v_as_3920_, v_i_boxed_3926_, v_stop_boxed_3927_, v_b_3923_, v___y_3924_);
lean_dec_ref(v_as_3920_);
return v_res_3928_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2(lean_object* v_as_3929_, size_t v_i_3930_, size_t v_stop_3931_, lean_object* v_b_3932_, lean_object* v___y_3933_){
_start:
{
uint8_t v___x_3935_; 
v___x_3935_ = lean_usize_dec_eq(v_i_3930_, v_stop_3931_);
if (v___x_3935_ == 0)
{
lean_object* v___x_3936_; lean_object* v___x_3937_; 
v___x_3936_ = lean_array_uget_borrowed(v_as_3929_, v_i_3930_);
v___x_3937_ = lp_proofEnvironment_Export_Parse_parseInductInfo(v___x_3936_, v___y_3933_);
if (lean_obj_tag(v___x_3937_) == 0)
{
lean_object* v_a_3938_; lean_object* v_fst_3939_; lean_object* v_snd_3940_; size_t v___x_3941_; size_t v___x_3942_; 
v_a_3938_ = lean_ctor_get(v___x_3937_, 0);
lean_inc(v_a_3938_);
lean_dec_ref_known(v___x_3937_, 1);
v_fst_3939_ = lean_ctor_get(v_a_3938_, 0);
lean_inc(v_fst_3939_);
v_snd_3940_ = lean_ctor_get(v_a_3938_, 1);
lean_inc(v_snd_3940_);
lean_dec(v_a_3938_);
v___x_3941_ = ((size_t)1ULL);
v___x_3942_ = lean_usize_add(v_i_3930_, v___x_3941_);
v_i_3930_ = v___x_3942_;
v_b_3932_ = v_fst_3939_;
v___y_3933_ = v_snd_3940_;
goto _start;
}
else
{
return v___x_3937_;
}
}
else
{
lean_object* v___x_3944_; lean_object* v___x_3945_; 
v___x_3944_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3944_, 0, v_b_3932_);
lean_ctor_set(v___x_3944_, 1, v___y_3933_);
v___x_3945_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3945_, 0, v___x_3944_);
return v___x_3945_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2___boxed(lean_object* v_as_3946_, lean_object* v_i_3947_, lean_object* v_stop_3948_, lean_object* v_b_3949_, lean_object* v___y_3950_, lean_object* v___y_3951_){
_start:
{
size_t v_i_boxed_3952_; size_t v_stop_boxed_3953_; lean_object* v_res_3954_; 
v_i_boxed_3952_ = lean_unbox_usize(v_i_3947_);
lean_dec(v_i_3947_);
v_stop_boxed_3953_ = lean_unbox_usize(v_stop_3948_);
lean_dec(v_stop_3948_);
v_res_3954_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2(v_as_3946_, v_i_boxed_3952_, v_stop_boxed_3953_, v_b_3949_, v___y_3950_);
lean_dec_ref(v_as_3946_);
return v_res_3954_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductive(lean_object* v_data_3966_, lean_object* v_a_3967_){
_start:
{
lean_object* v___x_3978_; lean_object* v___x_3979_; 
v___x_3978_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductive___closed__6));
v___x_3979_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_3966_, v___x_3978_);
if (lean_obj_tag(v___x_3979_) == 1)
{
lean_object* v_val_3980_; 
v_val_3980_ = lean_ctor_get(v___x_3979_, 0);
lean_inc(v_val_3980_);
lean_dec_ref_known(v___x_3979_, 1);
if (lean_obj_tag(v_val_3980_) == 4)
{
lean_object* v_elems_3981_; lean_object* v___x_3982_; lean_object* v___x_3983_; 
v_elems_3981_ = lean_ctor_get(v_val_3980_, 0);
lean_inc_ref(v_elems_3981_);
lean_dec_ref_known(v_val_3980_, 1);
v___x_3982_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductInfo___closed__4));
v___x_3983_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_3966_, v___x_3982_);
if (lean_obj_tag(v___x_3983_) == 1)
{
lean_object* v_val_3984_; 
v_val_3984_ = lean_ctor_get(v___x_3983_, 0);
lean_inc(v_val_3984_);
lean_dec_ref_known(v___x_3983_, 1);
if (lean_obj_tag(v_val_3984_) == 4)
{
lean_object* v_elems_3985_; lean_object* v___x_3986_; lean_object* v___x_3987_; 
v_elems_3985_ = lean_ctor_get(v_val_3984_, 0);
lean_inc_ref(v_elems_3985_);
lean_dec_ref_known(v_val_3984_, 1);
v___x_3986_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductive___closed__7));
v___x_3987_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27_spec__2___redArg(v_data_3966_, v___x_3986_);
if (lean_obj_tag(v___x_3987_) == 1)
{
lean_object* v_val_3988_; 
v_val_3988_ = lean_ctor_get(v___x_3987_, 0);
lean_inc(v_val_3988_);
lean_dec_ref_known(v___x_3987_, 1);
if (lean_obj_tag(v_val_3988_) == 4)
{
lean_object* v_elems_3989_; lean_object* v___x_3991_; uint8_t v_isShared_3992_; uint8_t v_isSharedCheck_4044_; 
v_elems_3989_ = lean_ctor_get(v_val_3988_, 0);
v_isSharedCheck_4044_ = !lean_is_exclusive(v_val_3988_);
if (v_isSharedCheck_4044_ == 0)
{
v___x_3991_ = v_val_3988_;
v_isShared_3992_ = v_isSharedCheck_4044_;
goto v_resetjp_3990_;
}
else
{
lean_inc(v_elems_3989_);
lean_dec(v_val_3988_);
v___x_3991_ = lean_box(0);
v_isShared_3992_ = v_isSharedCheck_4044_;
goto v_resetjp_3990_;
}
v_resetjp_3990_:
{
lean_object* v___x_3993_; lean_object* v_snd_3995_; lean_object* v___y_4015_; lean_object* v_snd_4019_; lean_object* v___y_4031_; lean_object* v___x_4034_; uint8_t v___x_4035_; 
v___x_3993_ = lean_unsigned_to_nat(0u);
v___x_4034_ = lean_array_get_size(v_elems_3981_);
v___x_4035_ = lean_nat_dec_lt(v___x_3993_, v___x_4034_);
if (v___x_4035_ == 0)
{
lean_dec_ref(v_elems_3981_);
v_snd_4019_ = v_a_3967_;
goto v___jp_4018_;
}
else
{
lean_object* v___x_4036_; uint8_t v___x_4037_; 
v___x_4036_ = lean_box(0);
v___x_4037_ = lean_nat_dec_le(v___x_4034_, v___x_4034_);
if (v___x_4037_ == 0)
{
if (v___x_4035_ == 0)
{
lean_dec_ref(v_elems_3981_);
v_snd_4019_ = v_a_3967_;
goto v___jp_4018_;
}
else
{
size_t v___x_4038_; size_t v___x_4039_; lean_object* v___x_4040_; 
v___x_4038_ = ((size_t)0ULL);
v___x_4039_ = lean_usize_of_nat(v___x_4034_);
v___x_4040_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2(v_elems_3981_, v___x_4038_, v___x_4039_, v___x_4036_, v_a_3967_);
lean_dec_ref(v_elems_3981_);
v___y_4031_ = v___x_4040_;
goto v___jp_4030_;
}
}
else
{
size_t v___x_4041_; size_t v___x_4042_; lean_object* v___x_4043_; 
v___x_4041_ = ((size_t)0ULL);
v___x_4042_ = lean_usize_of_nat(v___x_4034_);
v___x_4043_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__2(v_elems_3981_, v___x_4041_, v___x_4042_, v___x_4036_, v_a_3967_);
lean_dec_ref(v_elems_3981_);
v___y_4031_ = v___x_4043_;
goto v___jp_4030_;
}
}
v___jp_3994_:
{
lean_object* v___x_3996_; lean_object* v___x_3997_; uint8_t v___x_3998_; 
v___x_3996_ = lean_array_get_size(v_elems_3989_);
v___x_3997_ = lean_box(0);
v___x_3998_ = lean_nat_dec_lt(v___x_3993_, v___x_3996_);
if (v___x_3998_ == 0)
{
lean_object* v___x_3999_; lean_object* v___x_4001_; 
lean_dec_ref(v_elems_3989_);
v___x_3999_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3999_, 0, v___x_3997_);
lean_ctor_set(v___x_3999_, 1, v_snd_3995_);
if (v_isShared_3992_ == 0)
{
lean_ctor_set_tag(v___x_3991_, 0);
lean_ctor_set(v___x_3991_, 0, v___x_3999_);
v___x_4001_ = v___x_3991_;
goto v_reusejp_4000_;
}
else
{
lean_object* v_reuseFailAlloc_4002_; 
v_reuseFailAlloc_4002_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4002_, 0, v___x_3999_);
v___x_4001_ = v_reuseFailAlloc_4002_;
goto v_reusejp_4000_;
}
v_reusejp_4000_:
{
return v___x_4001_;
}
}
else
{
uint8_t v___x_4003_; 
v___x_4003_ = lean_nat_dec_le(v___x_3996_, v___x_3996_);
if (v___x_4003_ == 0)
{
if (v___x_3998_ == 0)
{
lean_object* v___x_4004_; lean_object* v___x_4006_; 
lean_dec_ref(v_elems_3989_);
v___x_4004_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4004_, 0, v___x_3997_);
lean_ctor_set(v___x_4004_, 1, v_snd_3995_);
if (v_isShared_3992_ == 0)
{
lean_ctor_set_tag(v___x_3991_, 0);
lean_ctor_set(v___x_3991_, 0, v___x_4004_);
v___x_4006_ = v___x_3991_;
goto v_reusejp_4005_;
}
else
{
lean_object* v_reuseFailAlloc_4007_; 
v_reuseFailAlloc_4007_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4007_, 0, v___x_4004_);
v___x_4006_ = v_reuseFailAlloc_4007_;
goto v_reusejp_4005_;
}
v_reusejp_4005_:
{
return v___x_4006_;
}
}
else
{
size_t v___x_4008_; size_t v___x_4009_; lean_object* v___x_4010_; 
lean_del_object(v___x_3991_);
v___x_4008_ = ((size_t)0ULL);
v___x_4009_ = lean_usize_of_nat(v___x_3996_);
v___x_4010_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0(v_elems_3989_, v___x_4008_, v___x_4009_, v___x_3997_, v_snd_3995_);
lean_dec_ref(v_elems_3989_);
return v___x_4010_;
}
}
else
{
size_t v___x_4011_; size_t v___x_4012_; lean_object* v___x_4013_; 
lean_del_object(v___x_3991_);
v___x_4011_ = ((size_t)0ULL);
v___x_4012_ = lean_usize_of_nat(v___x_3996_);
v___x_4013_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__0(v_elems_3989_, v___x_4011_, v___x_4012_, v___x_3997_, v_snd_3995_);
lean_dec_ref(v_elems_3989_);
return v___x_4013_;
}
}
}
v___jp_4014_:
{
if (lean_obj_tag(v___y_4015_) == 0)
{
lean_object* v_a_4016_; lean_object* v_snd_4017_; 
v_a_4016_ = lean_ctor_get(v___y_4015_, 0);
lean_inc(v_a_4016_);
lean_dec_ref_known(v___y_4015_, 1);
v_snd_4017_ = lean_ctor_get(v_a_4016_, 1);
lean_inc(v_snd_4017_);
lean_dec(v_a_4016_);
v_snd_3995_ = v_snd_4017_;
goto v___jp_3994_;
}
else
{
lean_del_object(v___x_3991_);
lean_dec_ref(v_elems_3989_);
return v___y_4015_;
}
}
v___jp_4018_:
{
lean_object* v___x_4020_; uint8_t v___x_4021_; 
v___x_4020_ = lean_array_get_size(v_elems_3985_);
v___x_4021_ = lean_nat_dec_lt(v___x_3993_, v___x_4020_);
if (v___x_4021_ == 0)
{
lean_dec_ref(v_elems_3985_);
v_snd_3995_ = v_snd_4019_;
goto v___jp_3994_;
}
else
{
lean_object* v___x_4022_; uint8_t v___x_4023_; 
v___x_4022_ = lean_box(0);
v___x_4023_ = lean_nat_dec_le(v___x_4020_, v___x_4020_);
if (v___x_4023_ == 0)
{
if (v___x_4021_ == 0)
{
lean_dec_ref(v_elems_3985_);
v_snd_3995_ = v_snd_4019_;
goto v___jp_3994_;
}
else
{
size_t v___x_4024_; size_t v___x_4025_; lean_object* v___x_4026_; 
v___x_4024_ = ((size_t)0ULL);
v___x_4025_ = lean_usize_of_nat(v___x_4020_);
v___x_4026_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1(v_elems_3985_, v___x_4024_, v___x_4025_, v___x_4022_, v_snd_4019_);
lean_dec_ref(v_elems_3985_);
v___y_4015_ = v___x_4026_;
goto v___jp_4014_;
}
}
else
{
size_t v___x_4027_; size_t v___x_4028_; lean_object* v___x_4029_; 
v___x_4027_ = ((size_t)0ULL);
v___x_4028_ = lean_usize_of_nat(v___x_4020_);
v___x_4029_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Export_Parse_parseInductive_spec__1(v_elems_3985_, v___x_4027_, v___x_4028_, v___x_4022_, v_snd_4019_);
lean_dec_ref(v_elems_3985_);
v___y_4015_ = v___x_4029_;
goto v___jp_4014_;
}
}
}
v___jp_4030_:
{
if (lean_obj_tag(v___y_4031_) == 0)
{
lean_object* v_a_4032_; lean_object* v_snd_4033_; 
v_a_4032_ = lean_ctor_get(v___y_4031_, 0);
lean_inc(v_a_4032_);
lean_dec_ref_known(v___y_4031_, 1);
v_snd_4033_ = lean_ctor_get(v_a_4032_, 1);
lean_inc(v_snd_4033_);
lean_dec(v_a_4032_);
v_snd_4019_ = v_snd_4033_;
goto v___jp_4018_;
}
else
{
lean_del_object(v___x_3991_);
lean_dec_ref(v_elems_3989_);
lean_dec_ref(v_elems_3985_);
return v___y_4031_;
}
}
}
}
else
{
lean_dec(v_val_3988_);
lean_dec_ref(v_elems_3985_);
lean_dec_ref(v_elems_3981_);
lean_dec_ref(v_a_3967_);
goto v___jp_3969_;
}
}
else
{
lean_dec(v___x_3987_);
lean_dec_ref(v_elems_3985_);
lean_dec_ref(v_elems_3981_);
lean_dec_ref(v_a_3967_);
goto v___jp_3969_;
}
}
else
{
lean_dec(v_val_3984_);
lean_dec_ref(v_elems_3981_);
lean_dec_ref(v_a_3967_);
goto v___jp_3972_;
}
}
else
{
lean_dec(v___x_3983_);
lean_dec_ref(v_elems_3981_);
lean_dec_ref(v_a_3967_);
goto v___jp_3972_;
}
}
else
{
lean_dec(v_val_3980_);
lean_dec_ref(v_a_3967_);
goto v___jp_3975_;
}
}
else
{
lean_dec(v___x_3979_);
lean_dec_ref(v_a_3967_);
goto v___jp_3975_;
}
v___jp_3969_:
{
lean_object* v___x_3970_; lean_object* v___x_3971_; 
v___x_3970_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductive___closed__1));
v___x_3971_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3971_, 0, v___x_3970_);
return v___x_3971_;
}
v___jp_3972_:
{
lean_object* v___x_3973_; lean_object* v___x_3974_; 
v___x_3973_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductive___closed__3));
v___x_3974_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3974_, 0, v___x_3973_);
return v___x_3974_;
}
v___jp_3975_:
{
lean_object* v___x_3976_; lean_object* v___x_3977_; 
v___x_3976_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseInductive___closed__5));
v___x_3977_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3977_, 0, v___x_3976_);
return v___x_3977_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseInductive___boxed(lean_object* v_data_4045_, lean_object* v_a_4046_, lean_object* v_a_4047_){
_start:
{
lean_object* v_res_4048_; 
v_res_4048_ = lp_proofEnvironment_Export_Parse_parseInductive(v_data_4045_, v_a_4046_);
lean_dec(v_data_4045_);
return v_res_4048_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1(lean_object* v_x_4050_, lean_object* v_x_4051_){
_start:
{
if (lean_obj_tag(v_x_4051_) == 0)
{
return v_x_4050_;
}
else
{
lean_object* v_head_4052_; lean_object* v_tail_4053_; lean_object* v___x_4054_; lean_object* v___x_4055_; lean_object* v___x_4056_; 
v_head_4052_ = lean_ctor_get(v_x_4051_, 0);
v_tail_4053_ = lean_ctor_get(v_x_4051_, 1);
v___x_4054_ = ((lean_object*)(lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1___closed__0));
v___x_4055_ = lean_string_append(v_x_4050_, v___x_4054_);
v___x_4056_ = lean_string_append(v___x_4055_, v_head_4052_);
v_x_4050_ = v___x_4056_;
v_x_4051_ = v_tail_4053_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1___boxed(lean_object* v_x_4058_, lean_object* v_x_4059_){
_start:
{
lean_object* v_res_4060_; 
v_res_4060_ = lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1(v_x_4058_, v_x_4059_);
lean_dec(v_x_4059_);
return v_res_4060_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(lean_object* v_x_4064_){
_start:
{
if (lean_obj_tag(v_x_4064_) == 0)
{
lean_object* v___x_4065_; 
v___x_4065_ = ((lean_object*)(lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__0));
return v___x_4065_;
}
else
{
lean_object* v_tail_4066_; 
v_tail_4066_ = lean_ctor_get(v_x_4064_, 1);
if (lean_obj_tag(v_tail_4066_) == 0)
{
lean_object* v_head_4067_; lean_object* v___x_4068_; lean_object* v___x_4069_; lean_object* v___x_4070_; lean_object* v___x_4071_; 
v_head_4067_ = lean_ctor_get(v_x_4064_, 0);
v___x_4068_ = ((lean_object*)(lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__1));
v___x_4069_ = lean_string_append(v___x_4068_, v_head_4067_);
v___x_4070_ = ((lean_object*)(lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__2));
v___x_4071_ = lean_string_append(v___x_4069_, v___x_4070_);
return v___x_4071_;
}
else
{
lean_object* v_head_4072_; lean_object* v___x_4073_; lean_object* v___x_4074_; lean_object* v___x_4075_; uint32_t v___x_4076_; lean_object* v___x_4077_; 
v_head_4072_ = lean_ctor_get(v_x_4064_, 0);
v___x_4073_ = ((lean_object*)(lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___closed__1));
v___x_4074_ = lean_string_append(v___x_4073_, v_head_4072_);
v___x_4075_ = lp_proofEnvironment_List_foldl___at___00List_toString___at___00Export_Parse_parseItem_spec__1_spec__1(v___x_4074_, v_tail_4066_);
v___x_4076_ = 93;
v___x_4077_ = lean_string_push(v___x_4075_, v___x_4076_);
return v___x_4077_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1___boxed(lean_object* v_x_4078_){
_start:
{
lean_object* v_res_4079_; 
v_res_4079_ = lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(v_x_4078_);
lean_dec(v_x_4078_);
return v_res_4079_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(lean_object* v_init_4080_, lean_object* v_x_4081_){
_start:
{
if (lean_obj_tag(v_x_4081_) == 0)
{
lean_object* v_k_4082_; lean_object* v_l_4083_; lean_object* v_r_4084_; lean_object* v___x_4085_; lean_object* v___x_4086_; 
v_k_4082_ = lean_ctor_get(v_x_4081_, 1);
v_l_4083_ = lean_ctor_get(v_x_4081_, 3);
v_r_4084_ = lean_ctor_get(v_x_4081_, 4);
v___x_4085_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(v_init_4080_, v_r_4084_);
lean_inc(v_k_4082_);
v___x_4086_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4086_, 0, v_k_4082_);
lean_ctor_set(v___x_4086_, 1, v___x_4085_);
v_init_4080_ = v___x_4086_;
v_x_4081_ = v_l_4083_;
goto _start;
}
else
{
return v_init_4080_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0___boxed(lean_object* v_init_4088_, lean_object* v_x_4089_){
_start:
{
lean_object* v_res_4090_; 
v_res_4090_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(v_init_4088_, v_x_4089_);
lean_dec(v_x_4089_);
return v_res_4090_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(lean_object* v_init_4091_, lean_object* v_x_4092_){
_start:
{
if (lean_obj_tag(v_x_4092_) == 0)
{
lean_object* v_k_4093_; lean_object* v_v_4094_; lean_object* v_l_4095_; lean_object* v_r_4096_; lean_object* v___x_4097_; lean_object* v___x_4098_; lean_object* v___x_4099_; 
v_k_4093_ = lean_ctor_get(v_x_4092_, 1);
v_v_4094_ = lean_ctor_get(v_x_4092_, 2);
v_l_4095_ = lean_ctor_get(v_x_4092_, 3);
v_r_4096_ = lean_ctor_get(v_x_4092_, 4);
v___x_4097_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(v_init_4091_, v_r_4096_);
lean_inc(v_v_4094_);
lean_inc(v_k_4093_);
v___x_4098_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4098_, 0, v_k_4093_);
lean_ctor_set(v___x_4098_, 1, v_v_4094_);
v___x_4099_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4099_, 0, v___x_4098_);
lean_ctor_set(v___x_4099_, 1, v___x_4097_);
v_init_4091_ = v___x_4099_;
v_x_4092_ = v_l_4095_;
goto _start;
}
else
{
return v_init_4091_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2___boxed(lean_object* v_init_4101_, lean_object* v_x_4102_){
_start:
{
lean_object* v_res_4103_; 
v_res_4103_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(v_init_4101_, v_x_4102_);
lean_dec(v_x_4102_);
return v_res_4103_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItem(lean_object* v_line_4129_, lean_object* v_a_4130_){
_start:
{
lean_object* v___x_4135_; lean_object* v___x_4136_; 
v___x_4135_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseJsonObj___closed__2));
v___x_4136_ = l_Std_Internal_Parsec_String_Parser_run___redArg(v___x_4135_, v_line_4129_);
if (lean_obj_tag(v___x_4136_) == 1)
{
lean_object* v_a_4137_; lean_object* v___x_4139_; uint8_t v_isShared_4140_; uint8_t v_isSharedCheck_5010_; 
v_a_4137_ = lean_ctor_get(v___x_4136_, 0);
v_isSharedCheck_5010_ = !lean_is_exclusive(v___x_4136_);
if (v_isSharedCheck_5010_ == 0)
{
v___x_4139_ = v___x_4136_;
v_isShared_4140_ = v_isSharedCheck_5010_;
goto v_resetjp_4138_;
}
else
{
lean_inc(v_a_4137_);
lean_dec(v___x_4136_);
v___x_4139_ = lean_box(0);
v_isShared_4140_ = v_isSharedCheck_5010_;
goto v_resetjp_4138_;
}
v_resetjp_4138_:
{
if (lean_obj_tag(v_a_4137_) == 5)
{
lean_object* v_kvPairs_4141_; lean_object* v___x_4143_; uint8_t v_isShared_4144_; uint8_t v_isSharedCheck_5009_; 
v_kvPairs_4141_ = lean_ctor_get(v_a_4137_, 0);
v_isSharedCheck_5009_ = !lean_is_exclusive(v_a_4137_);
if (v_isSharedCheck_5009_ == 0)
{
v___x_4143_ = v_a_4137_;
v_isShared_4144_ = v_isSharedCheck_5009_;
goto v_resetjp_4142_;
}
else
{
lean_inc(v_kvPairs_4141_);
lean_dec(v_a_4137_);
v___x_4143_ = lean_box(0);
v_isShared_4144_ = v_isSharedCheck_5009_;
goto v_resetjp_4142_;
}
v_resetjp_4142_:
{
lean_object* v_fst_4158_; lean_object* v_snd_4159_; lean_object* v_tail_4160_; lean_object* v___y_4976_; lean_object* v___x_4981_; lean_object* v___x_4982_; 
v___x_4981_ = lean_box(0);
v___x_4982_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(v___x_4981_, v_kvPairs_4141_);
if (lean_obj_tag(v___x_4982_) == 1)
{
lean_object* v_tail_4983_; 
v_tail_4983_ = lean_ctor_get(v___x_4982_, 1);
lean_inc(v_tail_4983_);
if (lean_obj_tag(v_tail_4983_) == 1)
{
lean_object* v_head_4984_; lean_object* v_head_4985_; lean_object* v_tail_4986_; lean_object* v___x_4988_; uint8_t v_isShared_4989_; uint8_t v_isSharedCheck_5007_; 
v_head_4984_ = lean_ctor_get(v_tail_4983_, 0);
lean_inc(v_head_4984_);
v_head_4985_ = lean_ctor_get(v___x_4982_, 0);
lean_inc(v_head_4985_);
v_tail_4986_ = lean_ctor_get(v_tail_4983_, 1);
v_isSharedCheck_5007_ = !lean_is_exclusive(v_tail_4983_);
if (v_isSharedCheck_5007_ == 0)
{
lean_object* v_unused_5008_; 
v_unused_5008_ = lean_ctor_get(v_tail_4983_, 0);
lean_dec(v_unused_5008_);
v___x_4988_ = v_tail_4983_;
v_isShared_4989_ = v_isSharedCheck_5007_;
goto v_resetjp_4987_;
}
else
{
lean_inc(v_tail_4986_);
lean_dec(v_tail_4983_);
v___x_4988_ = lean_box(0);
v_isShared_4989_ = v_isSharedCheck_5007_;
goto v_resetjp_4987_;
}
v_resetjp_4987_:
{
lean_object* v_fst_4990_; lean_object* v_snd_4991_; lean_object* v___x_4992_; uint8_t v___x_4993_; 
v_fst_4990_ = lean_ctor_get(v_head_4984_, 0);
lean_inc(v_fst_4990_);
v_snd_4991_ = lean_ctor_get(v_head_4984_, 1);
lean_inc(v_snd_4991_);
lean_dec(v_head_4984_);
v___x_4992_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__1));
v___x_4993_ = lean_string_dec_eq(v_fst_4990_, v___x_4992_);
if (v___x_4993_ == 0)
{
lean_object* v___x_4994_; uint8_t v___x_4995_; 
v___x_4994_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__3));
v___x_4995_ = lean_string_dec_eq(v_fst_4990_, v___x_4994_);
if (v___x_4995_ == 0)
{
lean_object* v___x_4996_; uint8_t v___x_4997_; 
v___x_4996_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__2));
v___x_4997_ = lean_string_dec_eq(v_fst_4990_, v___x_4996_);
lean_dec(v_fst_4990_);
if (v___x_4997_ == 0)
{
lean_dec(v_snd_4991_);
lean_del_object(v___x_4988_);
lean_dec(v_tail_4986_);
lean_dec(v_head_4985_);
v___y_4976_ = v___x_4982_;
goto v___jp_4975_;
}
else
{
if (lean_obj_tag(v_tail_4986_) == 0)
{
lean_object* v___x_4999_; 
lean_dec_ref_known(v___x_4982_, 2);
if (v_isShared_4989_ == 0)
{
lean_ctor_set(v___x_4988_, 0, v_head_4985_);
v___x_4999_ = v___x_4988_;
goto v_reusejp_4998_;
}
else
{
lean_object* v_reuseFailAlloc_5000_; 
v_reuseFailAlloc_5000_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5000_, 0, v_head_4985_);
lean_ctor_set(v_reuseFailAlloc_5000_, 1, v_tail_4986_);
v___x_4999_ = v_reuseFailAlloc_5000_;
goto v_reusejp_4998_;
}
v_reusejp_4998_:
{
v_fst_4158_ = v___x_4996_;
v_snd_4159_ = v_snd_4991_;
v_tail_4160_ = v___x_4999_;
goto v___jp_4157_;
}
}
else
{
lean_dec(v_snd_4991_);
lean_del_object(v___x_4988_);
lean_dec(v_tail_4986_);
lean_dec(v_head_4985_);
v___y_4976_ = v___x_4982_;
goto v___jp_4975_;
}
}
}
else
{
lean_dec(v_fst_4990_);
if (lean_obj_tag(v_tail_4986_) == 0)
{
lean_object* v___x_5002_; 
lean_dec_ref_known(v___x_4982_, 2);
if (v_isShared_4989_ == 0)
{
lean_ctor_set(v___x_4988_, 0, v_head_4985_);
v___x_5002_ = v___x_4988_;
goto v_reusejp_5001_;
}
else
{
lean_object* v_reuseFailAlloc_5003_; 
v_reuseFailAlloc_5003_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5003_, 0, v_head_4985_);
lean_ctor_set(v_reuseFailAlloc_5003_, 1, v_tail_4986_);
v___x_5002_ = v_reuseFailAlloc_5003_;
goto v_reusejp_5001_;
}
v_reusejp_5001_:
{
v_fst_4158_ = v___x_4994_;
v_snd_4159_ = v_snd_4991_;
v_tail_4160_ = v___x_5002_;
goto v___jp_4157_;
}
}
else
{
lean_dec(v_snd_4991_);
lean_del_object(v___x_4988_);
lean_dec(v_tail_4986_);
lean_dec(v_head_4985_);
v___y_4976_ = v___x_4982_;
goto v___jp_4975_;
}
}
}
else
{
lean_dec(v_fst_4990_);
if (lean_obj_tag(v_tail_4986_) == 0)
{
lean_object* v___x_5005_; 
lean_dec_ref_known(v___x_4982_, 2);
if (v_isShared_4989_ == 0)
{
lean_ctor_set(v___x_4988_, 0, v_head_4985_);
v___x_5005_ = v___x_4988_;
goto v_reusejp_5004_;
}
else
{
lean_object* v_reuseFailAlloc_5006_; 
v_reuseFailAlloc_5006_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5006_, 0, v_head_4985_);
lean_ctor_set(v_reuseFailAlloc_5006_, 1, v_tail_4986_);
v___x_5005_ = v_reuseFailAlloc_5006_;
goto v_reusejp_5004_;
}
v_reusejp_5004_:
{
v_fst_4158_ = v___x_4992_;
v_snd_4159_ = v_snd_4991_;
v_tail_4160_ = v___x_5005_;
goto v___jp_4157_;
}
}
else
{
lean_dec(v_snd_4991_);
lean_del_object(v___x_4988_);
lean_dec(v_tail_4986_);
lean_dec(v_head_4985_);
v___y_4976_ = v___x_4982_;
goto v___jp_4975_;
}
}
}
}
else
{
lean_dec(v_tail_4983_);
v___y_4976_ = v___x_4982_;
goto v___jp_4975_;
}
}
else
{
v___y_4976_ = v___x_4982_;
goto v___jp_4975_;
}
v___jp_4145_:
{
lean_object* v___x_4146_; lean_object* v___x_4147_; lean_object* v___x_4148_; lean_object* v___x_4149_; lean_object* v___x_4150_; lean_object* v___x_4152_; 
v___x_4146_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__0));
v___x_4147_ = lean_box(0);
v___x_4148_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(v___x_4147_, v_kvPairs_4141_);
lean_dec(v_kvPairs_4141_);
v___x_4149_ = lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(v___x_4148_);
lean_dec(v___x_4148_);
v___x_4150_ = lean_string_append(v___x_4146_, v___x_4149_);
lean_dec_ref(v___x_4149_);
if (v_isShared_4144_ == 0)
{
lean_ctor_set_tag(v___x_4143_, 18);
lean_ctor_set(v___x_4143_, 0, v___x_4150_);
v___x_4152_ = v___x_4143_;
goto v_reusejp_4151_;
}
else
{
lean_object* v_reuseFailAlloc_4156_; 
v_reuseFailAlloc_4156_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4156_, 0, v___x_4150_);
v___x_4152_ = v_reuseFailAlloc_4156_;
goto v_reusejp_4151_;
}
v_reusejp_4151_:
{
lean_object* v___x_4154_; 
if (v_isShared_4140_ == 0)
{
lean_ctor_set(v___x_4139_, 0, v___x_4152_);
v___x_4154_ = v___x_4139_;
goto v_reusejp_4153_;
}
else
{
lean_object* v_reuseFailAlloc_4155_; 
v_reuseFailAlloc_4155_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4155_, 0, v___x_4152_);
v___x_4154_ = v_reuseFailAlloc_4155_;
goto v_reusejp_4153_;
}
v_reusejp_4153_:
{
return v___x_4154_;
}
}
}
v___jp_4157_:
{
lean_object* v___x_4161_; uint8_t v___x_4162_; 
v___x_4161_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__1));
v___x_4162_ = lean_string_dec_eq(v_fst_4158_, v___x_4161_);
if (v___x_4162_ == 0)
{
lean_object* v___x_4163_; uint8_t v___x_4164_; 
v___x_4163_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__2));
v___x_4164_ = lean_string_dec_eq(v_fst_4158_, v___x_4163_);
if (v___x_4164_ == 0)
{
lean_object* v___x_4165_; uint8_t v___x_4166_; 
v___x_4165_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__3));
v___x_4166_ = lean_string_dec_eq(v_fst_4158_, v___x_4165_);
if (v___x_4166_ == 0)
{
lean_object* v___x_4167_; uint8_t v___x_4168_; 
v___x_4167_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__4));
v___x_4168_ = lean_string_dec_eq(v_fst_4158_, v___x_4167_);
if (v___x_4168_ == 0)
{
lean_object* v___x_4169_; uint8_t v___x_4170_; 
v___x_4169_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__5));
v___x_4170_ = lean_string_dec_eq(v_fst_4158_, v___x_4169_);
if (v___x_4170_ == 0)
{
lean_object* v___x_4171_; uint8_t v___x_4172_; 
v___x_4171_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__6));
v___x_4172_ = lean_string_dec_eq(v_fst_4158_, v___x_4171_);
if (v___x_4172_ == 0)
{
lean_object* v___x_4173_; uint8_t v___x_4174_; 
v___x_4173_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseDefnInfo___closed__9));
v___x_4174_ = lean_string_dec_eq(v_fst_4158_, v___x_4173_);
if (v___x_4174_ == 0)
{
lean_object* v___x_4175_; uint8_t v___x_4176_; 
v___x_4175_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__7));
v___x_4176_ = lean_string_dec_eq(v_fst_4158_, v___x_4175_);
if (v___x_4176_ == 0)
{
lean_object* v___x_4177_; uint8_t v___x_4178_; 
v___x_4177_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__8));
v___x_4178_ = lean_string_dec_eq(v_fst_4158_, v___x_4177_);
lean_dec_ref(v_fst_4158_);
if (v___x_4178_ == 0)
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_snd_4159_) == 5)
{
if (lean_obj_tag(v_tail_4160_) == 0)
{
lean_object* v_kvPairs_4179_; lean_object* v___x_4180_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v_kvPairs_4179_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc(v_kvPairs_4179_);
lean_dec_ref_known(v_snd_4159_, 1);
v___x_4180_ = lp_proofEnvironment_Export_Parse_parseInductive(v_kvPairs_4179_, v_a_4130_);
lean_dec(v_kvPairs_4179_);
return v___x_4180_;
}
else
{
lean_dec_ref_known(v_snd_4159_, 1);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 5)
{
if (lean_obj_tag(v_tail_4160_) == 0)
{
lean_object* v_kvPairs_4181_; lean_object* v___x_4182_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v_kvPairs_4181_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc(v_kvPairs_4181_);
lean_dec_ref_known(v_snd_4159_, 1);
v___x_4182_ = lp_proofEnvironment_Export_Parse_parseQuotInfo(v_kvPairs_4181_, v_a_4130_);
lean_dec(v_kvPairs_4181_);
return v___x_4182_;
}
else
{
lean_dec_ref_known(v_snd_4159_, 1);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 5)
{
if (lean_obj_tag(v_tail_4160_) == 0)
{
lean_object* v_kvPairs_4183_; lean_object* v___x_4184_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v_kvPairs_4183_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc(v_kvPairs_4183_);
lean_dec_ref_known(v_snd_4159_, 1);
v___x_4184_ = lp_proofEnvironment_Export_Parse_parseOpaqueInfo(v_kvPairs_4183_, v_a_4130_);
lean_dec(v_kvPairs_4183_);
return v___x_4184_;
}
else
{
lean_dec_ref_known(v_snd_4159_, 1);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 5)
{
if (lean_obj_tag(v_tail_4160_) == 0)
{
lean_object* v_kvPairs_4185_; lean_object* v___x_4186_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v_kvPairs_4185_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc(v_kvPairs_4185_);
lean_dec_ref_known(v_snd_4159_, 1);
v___x_4186_ = lp_proofEnvironment_Export_Parse_parseThmInfo(v_kvPairs_4185_, v_a_4130_);
lean_dec(v_kvPairs_4185_);
return v___x_4186_;
}
else
{
lean_dec_ref_known(v_snd_4159_, 1);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 5)
{
if (lean_obj_tag(v_tail_4160_) == 0)
{
lean_object* v_kvPairs_4187_; lean_object* v___x_4188_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v_kvPairs_4187_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc(v_kvPairs_4187_);
lean_dec_ref_known(v_snd_4159_, 1);
v___x_4188_ = lp_proofEnvironment_Export_Parse_parseDefnInfo(v_kvPairs_4187_, v_a_4130_);
lean_dec(v_kvPairs_4187_);
return v___x_4188_;
}
else
{
lean_dec_ref_known(v_snd_4159_, 1);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 5)
{
if (lean_obj_tag(v_tail_4160_) == 0)
{
lean_object* v_kvPairs_4189_; lean_object* v___x_4190_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v_kvPairs_4189_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc(v_kvPairs_4189_);
lean_dec_ref_known(v_snd_4159_, 1);
v___x_4190_ = lp_proofEnvironment_Export_Parse_parseAxiomInfo(v_kvPairs_4189_, v_a_4130_);
lean_dec(v_kvPairs_4189_);
return v___x_4190_;
}
else
{
lean_dec_ref_known(v_snd_4159_, 1);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 2)
{
lean_object* v_n_4191_; lean_object* v_mantissa_4192_; lean_object* v_exponent_4193_; lean_object* v_natZero_4194_; lean_object* v_intZero_4195_; uint8_t v_isNeg_4196_; 
v_n_4191_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc_ref(v_n_4191_);
lean_dec_ref_known(v_snd_4159_, 1);
v_mantissa_4192_ = lean_ctor_get(v_n_4191_, 0);
lean_inc(v_mantissa_4192_);
v_exponent_4193_ = lean_ctor_get(v_n_4191_, 1);
lean_inc(v_exponent_4193_);
lean_dec_ref(v_n_4191_);
v_natZero_4194_ = lean_unsigned_to_nat(0u);
v_intZero_4195_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_4196_ = lean_int_dec_lt(v_mantissa_4192_, v_intZero_4195_);
if (v_isNeg_4196_ == 0)
{
uint8_t v___x_4197_; 
v___x_4197_ = lean_nat_dec_eq(v_exponent_4193_, v_natZero_4194_);
lean_dec(v_exponent_4193_);
if (v___x_4197_ == 0)
{
lean_dec(v_mantissa_4192_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_tail_4160_) == 1)
{
lean_object* v_head_4198_; lean_object* v_tail_4199_; lean_object* v_fst_4200_; lean_object* v_snd_4201_; lean_object* v_a_4202_; lean_object* v___x_4203_; uint8_t v___x_4204_; 
v_head_4198_ = lean_ctor_get(v_tail_4160_, 0);
lean_inc(v_head_4198_);
v_tail_4199_ = lean_ctor_get(v_tail_4160_, 1);
lean_inc(v_tail_4199_);
lean_dec_ref_known(v_tail_4160_, 2);
v_fst_4200_ = lean_ctor_get(v_head_4198_, 0);
lean_inc(v_fst_4200_);
v_snd_4201_ = lean_ctor_get(v_head_4198_, 1);
lean_inc(v_snd_4201_);
lean_dec(v_head_4198_);
v_a_4202_ = lean_nat_abs(v_mantissa_4192_);
lean_dec(v_mantissa_4192_);
v___x_4203_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__9));
v___x_4204_ = lean_string_dec_eq(v_fst_4200_, v___x_4203_);
if (v___x_4204_ == 0)
{
lean_object* v___x_4205_; uint8_t v___x_4206_; 
v___x_4205_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__10));
v___x_4206_ = lean_string_dec_eq(v_fst_4200_, v___x_4205_);
if (v___x_4206_ == 0)
{
lean_object* v___x_4207_; uint8_t v___x_4208_; 
v___x_4207_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__11));
v___x_4208_ = lean_string_dec_eq(v_fst_4200_, v___x_4207_);
if (v___x_4208_ == 0)
{
lean_object* v___x_4209_; uint8_t v___x_4210_; 
v___x_4209_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__12));
v___x_4210_ = lean_string_dec_eq(v_fst_4200_, v___x_4209_);
if (v___x_4210_ == 0)
{
lean_object* v___x_4211_; uint8_t v___x_4212_; 
v___x_4211_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__13));
v___x_4212_ = lean_string_dec_eq(v_fst_4200_, v___x_4211_);
if (v___x_4212_ == 0)
{
lean_object* v___x_4213_; uint8_t v___x_4214_; 
v___x_4213_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__14));
v___x_4214_ = lean_string_dec_eq(v_fst_4200_, v___x_4213_);
if (v___x_4214_ == 0)
{
lean_object* v___x_4215_; uint8_t v___x_4216_; 
v___x_4215_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__15));
v___x_4216_ = lean_string_dec_eq(v_fst_4200_, v___x_4215_);
if (v___x_4216_ == 0)
{
lean_object* v___x_4217_; uint8_t v___x_4218_; 
v___x_4217_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__16));
v___x_4218_ = lean_string_dec_eq(v_fst_4200_, v___x_4217_);
if (v___x_4218_ == 0)
{
lean_object* v___x_4219_; uint8_t v___x_4220_; 
v___x_4219_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__17));
v___x_4220_ = lean_string_dec_eq(v_fst_4200_, v___x_4219_);
if (v___x_4220_ == 0)
{
lean_object* v___x_4221_; uint8_t v___x_4222_; 
v___x_4221_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__18));
v___x_4222_ = lean_string_dec_eq(v_fst_4200_, v___x_4221_);
if (v___x_4222_ == 0)
{
lean_object* v___x_4223_; uint8_t v___x_4224_; 
v___x_4223_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__19));
v___x_4224_ = lean_string_dec_eq(v_fst_4200_, v___x_4223_);
lean_dec(v_fst_4200_);
if (v___x_4224_ == 0)
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4225_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4225_ = lp_proofEnvironment_Export_Parse_parseExprMdata(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4225_) == 0)
{
lean_object* v_a_4226_; lean_object* v___x_4228_; uint8_t v_isShared_4229_; uint8_t v_isSharedCheck_4258_; 
v_a_4226_ = lean_ctor_get(v___x_4225_, 0);
v_isSharedCheck_4258_ = !lean_is_exclusive(v___x_4225_);
if (v_isSharedCheck_4258_ == 0)
{
v___x_4228_ = v___x_4225_;
v_isShared_4229_ = v_isSharedCheck_4258_;
goto v_resetjp_4227_;
}
else
{
lean_inc(v_a_4226_);
lean_dec(v___x_4225_);
v___x_4228_ = lean_box(0);
v_isShared_4229_ = v_isSharedCheck_4258_;
goto v_resetjp_4227_;
}
v_resetjp_4227_:
{
lean_object* v_snd_4230_; lean_object* v_fst_4231_; lean_object* v___x_4233_; uint8_t v_isShared_4234_; uint8_t v_isSharedCheck_4257_; 
v_snd_4230_ = lean_ctor_get(v_a_4226_, 1);
v_fst_4231_ = lean_ctor_get(v_a_4226_, 0);
v_isSharedCheck_4257_ = !lean_is_exclusive(v_a_4226_);
if (v_isSharedCheck_4257_ == 0)
{
v___x_4233_ = v_a_4226_;
v_isShared_4234_ = v_isSharedCheck_4257_;
goto v_resetjp_4232_;
}
else
{
lean_inc(v_snd_4230_);
lean_inc(v_fst_4231_);
lean_dec(v_a_4226_);
v___x_4233_ = lean_box(0);
v_isShared_4234_ = v_isSharedCheck_4257_;
goto v_resetjp_4232_;
}
v_resetjp_4232_:
{
lean_object* v_stream_4235_; lean_object* v_nameMap_4236_; lean_object* v_levelMap_4237_; lean_object* v_exprMap_4238_; lean_object* v_recursorRuleMap_4239_; lean_object* v_constMap_4240_; lean_object* v_constOrder_4241_; lean_object* v___x_4243_; uint8_t v_isShared_4244_; uint8_t v_isSharedCheck_4256_; 
v_stream_4235_ = lean_ctor_get(v_snd_4230_, 0);
v_nameMap_4236_ = lean_ctor_get(v_snd_4230_, 1);
v_levelMap_4237_ = lean_ctor_get(v_snd_4230_, 2);
v_exprMap_4238_ = lean_ctor_get(v_snd_4230_, 3);
v_recursorRuleMap_4239_ = lean_ctor_get(v_snd_4230_, 4);
v_constMap_4240_ = lean_ctor_get(v_snd_4230_, 5);
v_constOrder_4241_ = lean_ctor_get(v_snd_4230_, 6);
v_isSharedCheck_4256_ = !lean_is_exclusive(v_snd_4230_);
if (v_isSharedCheck_4256_ == 0)
{
v___x_4243_ = v_snd_4230_;
v_isShared_4244_ = v_isSharedCheck_4256_;
goto v_resetjp_4242_;
}
else
{
lean_inc(v_constOrder_4241_);
lean_inc(v_constMap_4240_);
lean_inc(v_recursorRuleMap_4239_);
lean_inc(v_exprMap_4238_);
lean_inc(v_levelMap_4237_);
lean_inc(v_nameMap_4236_);
lean_inc(v_stream_4235_);
lean_dec(v_snd_4230_);
v___x_4243_ = lean_box(0);
v_isShared_4244_ = v_isSharedCheck_4256_;
goto v_resetjp_4242_;
}
v_resetjp_4242_:
{
lean_object* v___x_4245_; lean_object* v___x_4246_; lean_object* v___x_4248_; 
v___x_4245_ = lean_box(0);
v___x_4246_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4238_, v_a_4202_, v_fst_4231_);
if (v_isShared_4244_ == 0)
{
lean_ctor_set(v___x_4243_, 3, v___x_4246_);
v___x_4248_ = v___x_4243_;
goto v_reusejp_4247_;
}
else
{
lean_object* v_reuseFailAlloc_4255_; 
v_reuseFailAlloc_4255_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4255_, 0, v_stream_4235_);
lean_ctor_set(v_reuseFailAlloc_4255_, 1, v_nameMap_4236_);
lean_ctor_set(v_reuseFailAlloc_4255_, 2, v_levelMap_4237_);
lean_ctor_set(v_reuseFailAlloc_4255_, 3, v___x_4246_);
lean_ctor_set(v_reuseFailAlloc_4255_, 4, v_recursorRuleMap_4239_);
lean_ctor_set(v_reuseFailAlloc_4255_, 5, v_constMap_4240_);
lean_ctor_set(v_reuseFailAlloc_4255_, 6, v_constOrder_4241_);
v___x_4248_ = v_reuseFailAlloc_4255_;
goto v_reusejp_4247_;
}
v_reusejp_4247_:
{
lean_object* v___x_4250_; 
if (v_isShared_4234_ == 0)
{
lean_ctor_set(v___x_4233_, 1, v___x_4248_);
lean_ctor_set(v___x_4233_, 0, v___x_4245_);
v___x_4250_ = v___x_4233_;
goto v_reusejp_4249_;
}
else
{
lean_object* v_reuseFailAlloc_4254_; 
v_reuseFailAlloc_4254_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4254_, 0, v___x_4245_);
lean_ctor_set(v_reuseFailAlloc_4254_, 1, v___x_4248_);
v___x_4250_ = v_reuseFailAlloc_4254_;
goto v_reusejp_4249_;
}
v_reusejp_4249_:
{
lean_object* v___x_4252_; 
if (v_isShared_4229_ == 0)
{
lean_ctor_set(v___x_4228_, 0, v___x_4250_);
v___x_4252_ = v___x_4228_;
goto v_reusejp_4251_;
}
else
{
lean_object* v_reuseFailAlloc_4253_; 
v_reuseFailAlloc_4253_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4253_, 0, v___x_4250_);
v___x_4252_ = v_reuseFailAlloc_4253_;
goto v_reusejp_4251_;
}
v_reusejp_4251_:
{
return v___x_4252_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4259_; lean_object* v___x_4261_; uint8_t v_isShared_4262_; uint8_t v_isSharedCheck_4266_; 
lean_dec(v_a_4202_);
v_a_4259_ = lean_ctor_get(v___x_4225_, 0);
v_isSharedCheck_4266_ = !lean_is_exclusive(v___x_4225_);
if (v_isSharedCheck_4266_ == 0)
{
v___x_4261_ = v___x_4225_;
v_isShared_4262_ = v_isSharedCheck_4266_;
goto v_resetjp_4260_;
}
else
{
lean_inc(v_a_4259_);
lean_dec(v___x_4225_);
v___x_4261_ = lean_box(0);
v_isShared_4262_ = v_isSharedCheck_4266_;
goto v_resetjp_4260_;
}
v_resetjp_4260_:
{
lean_object* v___x_4264_; 
if (v_isShared_4262_ == 0)
{
v___x_4264_ = v___x_4261_;
goto v_reusejp_4263_;
}
else
{
lean_object* v_reuseFailAlloc_4265_; 
v_reuseFailAlloc_4265_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4265_, 0, v_a_4259_);
v___x_4264_ = v_reuseFailAlloc_4265_;
goto v_reusejp_4263_;
}
v_reusejp_4263_:
{
return v___x_4264_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4267_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4267_ = lp_proofEnvironment_Export_Parse_parseExprStrLit(v_snd_4201_, v_a_4130_);
if (lean_obj_tag(v___x_4267_) == 0)
{
lean_object* v_a_4268_; lean_object* v___x_4270_; uint8_t v_isShared_4271_; uint8_t v_isSharedCheck_4300_; 
v_a_4268_ = lean_ctor_get(v___x_4267_, 0);
v_isSharedCheck_4300_ = !lean_is_exclusive(v___x_4267_);
if (v_isSharedCheck_4300_ == 0)
{
v___x_4270_ = v___x_4267_;
v_isShared_4271_ = v_isSharedCheck_4300_;
goto v_resetjp_4269_;
}
else
{
lean_inc(v_a_4268_);
lean_dec(v___x_4267_);
v___x_4270_ = lean_box(0);
v_isShared_4271_ = v_isSharedCheck_4300_;
goto v_resetjp_4269_;
}
v_resetjp_4269_:
{
lean_object* v_snd_4272_; lean_object* v_fst_4273_; lean_object* v___x_4275_; uint8_t v_isShared_4276_; uint8_t v_isSharedCheck_4299_; 
v_snd_4272_ = lean_ctor_get(v_a_4268_, 1);
v_fst_4273_ = lean_ctor_get(v_a_4268_, 0);
v_isSharedCheck_4299_ = !lean_is_exclusive(v_a_4268_);
if (v_isSharedCheck_4299_ == 0)
{
v___x_4275_ = v_a_4268_;
v_isShared_4276_ = v_isSharedCheck_4299_;
goto v_resetjp_4274_;
}
else
{
lean_inc(v_snd_4272_);
lean_inc(v_fst_4273_);
lean_dec(v_a_4268_);
v___x_4275_ = lean_box(0);
v_isShared_4276_ = v_isSharedCheck_4299_;
goto v_resetjp_4274_;
}
v_resetjp_4274_:
{
lean_object* v_stream_4277_; lean_object* v_nameMap_4278_; lean_object* v_levelMap_4279_; lean_object* v_exprMap_4280_; lean_object* v_recursorRuleMap_4281_; lean_object* v_constMap_4282_; lean_object* v_constOrder_4283_; lean_object* v___x_4285_; uint8_t v_isShared_4286_; uint8_t v_isSharedCheck_4298_; 
v_stream_4277_ = lean_ctor_get(v_snd_4272_, 0);
v_nameMap_4278_ = lean_ctor_get(v_snd_4272_, 1);
v_levelMap_4279_ = lean_ctor_get(v_snd_4272_, 2);
v_exprMap_4280_ = lean_ctor_get(v_snd_4272_, 3);
v_recursorRuleMap_4281_ = lean_ctor_get(v_snd_4272_, 4);
v_constMap_4282_ = lean_ctor_get(v_snd_4272_, 5);
v_constOrder_4283_ = lean_ctor_get(v_snd_4272_, 6);
v_isSharedCheck_4298_ = !lean_is_exclusive(v_snd_4272_);
if (v_isSharedCheck_4298_ == 0)
{
v___x_4285_ = v_snd_4272_;
v_isShared_4286_ = v_isSharedCheck_4298_;
goto v_resetjp_4284_;
}
else
{
lean_inc(v_constOrder_4283_);
lean_inc(v_constMap_4282_);
lean_inc(v_recursorRuleMap_4281_);
lean_inc(v_exprMap_4280_);
lean_inc(v_levelMap_4279_);
lean_inc(v_nameMap_4278_);
lean_inc(v_stream_4277_);
lean_dec(v_snd_4272_);
v___x_4285_ = lean_box(0);
v_isShared_4286_ = v_isSharedCheck_4298_;
goto v_resetjp_4284_;
}
v_resetjp_4284_:
{
lean_object* v___x_4287_; lean_object* v___x_4288_; lean_object* v___x_4290_; 
v___x_4287_ = lean_box(0);
v___x_4288_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4280_, v_a_4202_, v_fst_4273_);
if (v_isShared_4286_ == 0)
{
lean_ctor_set(v___x_4285_, 3, v___x_4288_);
v___x_4290_ = v___x_4285_;
goto v_reusejp_4289_;
}
else
{
lean_object* v_reuseFailAlloc_4297_; 
v_reuseFailAlloc_4297_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4297_, 0, v_stream_4277_);
lean_ctor_set(v_reuseFailAlloc_4297_, 1, v_nameMap_4278_);
lean_ctor_set(v_reuseFailAlloc_4297_, 2, v_levelMap_4279_);
lean_ctor_set(v_reuseFailAlloc_4297_, 3, v___x_4288_);
lean_ctor_set(v_reuseFailAlloc_4297_, 4, v_recursorRuleMap_4281_);
lean_ctor_set(v_reuseFailAlloc_4297_, 5, v_constMap_4282_);
lean_ctor_set(v_reuseFailAlloc_4297_, 6, v_constOrder_4283_);
v___x_4290_ = v_reuseFailAlloc_4297_;
goto v_reusejp_4289_;
}
v_reusejp_4289_:
{
lean_object* v___x_4292_; 
if (v_isShared_4276_ == 0)
{
lean_ctor_set(v___x_4275_, 1, v___x_4290_);
lean_ctor_set(v___x_4275_, 0, v___x_4287_);
v___x_4292_ = v___x_4275_;
goto v_reusejp_4291_;
}
else
{
lean_object* v_reuseFailAlloc_4296_; 
v_reuseFailAlloc_4296_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4296_, 0, v___x_4287_);
lean_ctor_set(v_reuseFailAlloc_4296_, 1, v___x_4290_);
v___x_4292_ = v_reuseFailAlloc_4296_;
goto v_reusejp_4291_;
}
v_reusejp_4291_:
{
lean_object* v___x_4294_; 
if (v_isShared_4271_ == 0)
{
lean_ctor_set(v___x_4270_, 0, v___x_4292_);
v___x_4294_ = v___x_4270_;
goto v_reusejp_4293_;
}
else
{
lean_object* v_reuseFailAlloc_4295_; 
v_reuseFailAlloc_4295_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4295_, 0, v___x_4292_);
v___x_4294_ = v_reuseFailAlloc_4295_;
goto v_reusejp_4293_;
}
v_reusejp_4293_:
{
return v___x_4294_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4301_; lean_object* v___x_4303_; uint8_t v_isShared_4304_; uint8_t v_isSharedCheck_4308_; 
lean_dec(v_a_4202_);
v_a_4301_ = lean_ctor_get(v___x_4267_, 0);
v_isSharedCheck_4308_ = !lean_is_exclusive(v___x_4267_);
if (v_isSharedCheck_4308_ == 0)
{
v___x_4303_ = v___x_4267_;
v_isShared_4304_ = v_isSharedCheck_4308_;
goto v_resetjp_4302_;
}
else
{
lean_inc(v_a_4301_);
lean_dec(v___x_4267_);
v___x_4303_ = lean_box(0);
v_isShared_4304_ = v_isSharedCheck_4308_;
goto v_resetjp_4302_;
}
v_resetjp_4302_:
{
lean_object* v___x_4306_; 
if (v_isShared_4304_ == 0)
{
v___x_4306_ = v___x_4303_;
goto v_reusejp_4305_;
}
else
{
lean_object* v_reuseFailAlloc_4307_; 
v_reuseFailAlloc_4307_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4307_, 0, v_a_4301_);
v___x_4306_ = v_reuseFailAlloc_4307_;
goto v_reusejp_4305_;
}
v_reusejp_4305_:
{
return v___x_4306_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4309_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4309_ = lp_proofEnvironment_Export_Parse_parseExprNatLit(v_snd_4201_, v_a_4130_);
if (lean_obj_tag(v___x_4309_) == 0)
{
lean_object* v_a_4310_; lean_object* v___x_4312_; uint8_t v_isShared_4313_; uint8_t v_isSharedCheck_4342_; 
v_a_4310_ = lean_ctor_get(v___x_4309_, 0);
v_isSharedCheck_4342_ = !lean_is_exclusive(v___x_4309_);
if (v_isSharedCheck_4342_ == 0)
{
v___x_4312_ = v___x_4309_;
v_isShared_4313_ = v_isSharedCheck_4342_;
goto v_resetjp_4311_;
}
else
{
lean_inc(v_a_4310_);
lean_dec(v___x_4309_);
v___x_4312_ = lean_box(0);
v_isShared_4313_ = v_isSharedCheck_4342_;
goto v_resetjp_4311_;
}
v_resetjp_4311_:
{
lean_object* v_snd_4314_; lean_object* v_fst_4315_; lean_object* v___x_4317_; uint8_t v_isShared_4318_; uint8_t v_isSharedCheck_4341_; 
v_snd_4314_ = lean_ctor_get(v_a_4310_, 1);
v_fst_4315_ = lean_ctor_get(v_a_4310_, 0);
v_isSharedCheck_4341_ = !lean_is_exclusive(v_a_4310_);
if (v_isSharedCheck_4341_ == 0)
{
v___x_4317_ = v_a_4310_;
v_isShared_4318_ = v_isSharedCheck_4341_;
goto v_resetjp_4316_;
}
else
{
lean_inc(v_snd_4314_);
lean_inc(v_fst_4315_);
lean_dec(v_a_4310_);
v___x_4317_ = lean_box(0);
v_isShared_4318_ = v_isSharedCheck_4341_;
goto v_resetjp_4316_;
}
v_resetjp_4316_:
{
lean_object* v_stream_4319_; lean_object* v_nameMap_4320_; lean_object* v_levelMap_4321_; lean_object* v_exprMap_4322_; lean_object* v_recursorRuleMap_4323_; lean_object* v_constMap_4324_; lean_object* v_constOrder_4325_; lean_object* v___x_4327_; uint8_t v_isShared_4328_; uint8_t v_isSharedCheck_4340_; 
v_stream_4319_ = lean_ctor_get(v_snd_4314_, 0);
v_nameMap_4320_ = lean_ctor_get(v_snd_4314_, 1);
v_levelMap_4321_ = lean_ctor_get(v_snd_4314_, 2);
v_exprMap_4322_ = lean_ctor_get(v_snd_4314_, 3);
v_recursorRuleMap_4323_ = lean_ctor_get(v_snd_4314_, 4);
v_constMap_4324_ = lean_ctor_get(v_snd_4314_, 5);
v_constOrder_4325_ = lean_ctor_get(v_snd_4314_, 6);
v_isSharedCheck_4340_ = !lean_is_exclusive(v_snd_4314_);
if (v_isSharedCheck_4340_ == 0)
{
v___x_4327_ = v_snd_4314_;
v_isShared_4328_ = v_isSharedCheck_4340_;
goto v_resetjp_4326_;
}
else
{
lean_inc(v_constOrder_4325_);
lean_inc(v_constMap_4324_);
lean_inc(v_recursorRuleMap_4323_);
lean_inc(v_exprMap_4322_);
lean_inc(v_levelMap_4321_);
lean_inc(v_nameMap_4320_);
lean_inc(v_stream_4319_);
lean_dec(v_snd_4314_);
v___x_4327_ = lean_box(0);
v_isShared_4328_ = v_isSharedCheck_4340_;
goto v_resetjp_4326_;
}
v_resetjp_4326_:
{
lean_object* v___x_4329_; lean_object* v___x_4330_; lean_object* v___x_4332_; 
v___x_4329_ = lean_box(0);
v___x_4330_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4322_, v_a_4202_, v_fst_4315_);
if (v_isShared_4328_ == 0)
{
lean_ctor_set(v___x_4327_, 3, v___x_4330_);
v___x_4332_ = v___x_4327_;
goto v_reusejp_4331_;
}
else
{
lean_object* v_reuseFailAlloc_4339_; 
v_reuseFailAlloc_4339_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4339_, 0, v_stream_4319_);
lean_ctor_set(v_reuseFailAlloc_4339_, 1, v_nameMap_4320_);
lean_ctor_set(v_reuseFailAlloc_4339_, 2, v_levelMap_4321_);
lean_ctor_set(v_reuseFailAlloc_4339_, 3, v___x_4330_);
lean_ctor_set(v_reuseFailAlloc_4339_, 4, v_recursorRuleMap_4323_);
lean_ctor_set(v_reuseFailAlloc_4339_, 5, v_constMap_4324_);
lean_ctor_set(v_reuseFailAlloc_4339_, 6, v_constOrder_4325_);
v___x_4332_ = v_reuseFailAlloc_4339_;
goto v_reusejp_4331_;
}
v_reusejp_4331_:
{
lean_object* v___x_4334_; 
if (v_isShared_4318_ == 0)
{
lean_ctor_set(v___x_4317_, 1, v___x_4332_);
lean_ctor_set(v___x_4317_, 0, v___x_4329_);
v___x_4334_ = v___x_4317_;
goto v_reusejp_4333_;
}
else
{
lean_object* v_reuseFailAlloc_4338_; 
v_reuseFailAlloc_4338_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4338_, 0, v___x_4329_);
lean_ctor_set(v_reuseFailAlloc_4338_, 1, v___x_4332_);
v___x_4334_ = v_reuseFailAlloc_4338_;
goto v_reusejp_4333_;
}
v_reusejp_4333_:
{
lean_object* v___x_4336_; 
if (v_isShared_4313_ == 0)
{
lean_ctor_set(v___x_4312_, 0, v___x_4334_);
v___x_4336_ = v___x_4312_;
goto v_reusejp_4335_;
}
else
{
lean_object* v_reuseFailAlloc_4337_; 
v_reuseFailAlloc_4337_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4337_, 0, v___x_4334_);
v___x_4336_ = v_reuseFailAlloc_4337_;
goto v_reusejp_4335_;
}
v_reusejp_4335_:
{
return v___x_4336_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4343_; lean_object* v___x_4345_; uint8_t v_isShared_4346_; uint8_t v_isSharedCheck_4350_; 
lean_dec(v_a_4202_);
v_a_4343_ = lean_ctor_get(v___x_4309_, 0);
v_isSharedCheck_4350_ = !lean_is_exclusive(v___x_4309_);
if (v_isSharedCheck_4350_ == 0)
{
v___x_4345_ = v___x_4309_;
v_isShared_4346_ = v_isSharedCheck_4350_;
goto v_resetjp_4344_;
}
else
{
lean_inc(v_a_4343_);
lean_dec(v___x_4309_);
v___x_4345_ = lean_box(0);
v_isShared_4346_ = v_isSharedCheck_4350_;
goto v_resetjp_4344_;
}
v_resetjp_4344_:
{
lean_object* v___x_4348_; 
if (v_isShared_4346_ == 0)
{
v___x_4348_ = v___x_4345_;
goto v_reusejp_4347_;
}
else
{
lean_object* v_reuseFailAlloc_4349_; 
v_reuseFailAlloc_4349_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4349_, 0, v_a_4343_);
v___x_4348_ = v_reuseFailAlloc_4349_;
goto v_reusejp_4347_;
}
v_reusejp_4347_:
{
return v___x_4348_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4351_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4351_ = lp_proofEnvironment_Export_Parse_parseExprProj(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4351_) == 0)
{
lean_object* v_a_4352_; lean_object* v___x_4354_; uint8_t v_isShared_4355_; uint8_t v_isSharedCheck_4384_; 
v_a_4352_ = lean_ctor_get(v___x_4351_, 0);
v_isSharedCheck_4384_ = !lean_is_exclusive(v___x_4351_);
if (v_isSharedCheck_4384_ == 0)
{
v___x_4354_ = v___x_4351_;
v_isShared_4355_ = v_isSharedCheck_4384_;
goto v_resetjp_4353_;
}
else
{
lean_inc(v_a_4352_);
lean_dec(v___x_4351_);
v___x_4354_ = lean_box(0);
v_isShared_4355_ = v_isSharedCheck_4384_;
goto v_resetjp_4353_;
}
v_resetjp_4353_:
{
lean_object* v_snd_4356_; lean_object* v_fst_4357_; lean_object* v___x_4359_; uint8_t v_isShared_4360_; uint8_t v_isSharedCheck_4383_; 
v_snd_4356_ = lean_ctor_get(v_a_4352_, 1);
v_fst_4357_ = lean_ctor_get(v_a_4352_, 0);
v_isSharedCheck_4383_ = !lean_is_exclusive(v_a_4352_);
if (v_isSharedCheck_4383_ == 0)
{
v___x_4359_ = v_a_4352_;
v_isShared_4360_ = v_isSharedCheck_4383_;
goto v_resetjp_4358_;
}
else
{
lean_inc(v_snd_4356_);
lean_inc(v_fst_4357_);
lean_dec(v_a_4352_);
v___x_4359_ = lean_box(0);
v_isShared_4360_ = v_isSharedCheck_4383_;
goto v_resetjp_4358_;
}
v_resetjp_4358_:
{
lean_object* v_stream_4361_; lean_object* v_nameMap_4362_; lean_object* v_levelMap_4363_; lean_object* v_exprMap_4364_; lean_object* v_recursorRuleMap_4365_; lean_object* v_constMap_4366_; lean_object* v_constOrder_4367_; lean_object* v___x_4369_; uint8_t v_isShared_4370_; uint8_t v_isSharedCheck_4382_; 
v_stream_4361_ = lean_ctor_get(v_snd_4356_, 0);
v_nameMap_4362_ = lean_ctor_get(v_snd_4356_, 1);
v_levelMap_4363_ = lean_ctor_get(v_snd_4356_, 2);
v_exprMap_4364_ = lean_ctor_get(v_snd_4356_, 3);
v_recursorRuleMap_4365_ = lean_ctor_get(v_snd_4356_, 4);
v_constMap_4366_ = lean_ctor_get(v_snd_4356_, 5);
v_constOrder_4367_ = lean_ctor_get(v_snd_4356_, 6);
v_isSharedCheck_4382_ = !lean_is_exclusive(v_snd_4356_);
if (v_isSharedCheck_4382_ == 0)
{
v___x_4369_ = v_snd_4356_;
v_isShared_4370_ = v_isSharedCheck_4382_;
goto v_resetjp_4368_;
}
else
{
lean_inc(v_constOrder_4367_);
lean_inc(v_constMap_4366_);
lean_inc(v_recursorRuleMap_4365_);
lean_inc(v_exprMap_4364_);
lean_inc(v_levelMap_4363_);
lean_inc(v_nameMap_4362_);
lean_inc(v_stream_4361_);
lean_dec(v_snd_4356_);
v___x_4369_ = lean_box(0);
v_isShared_4370_ = v_isSharedCheck_4382_;
goto v_resetjp_4368_;
}
v_resetjp_4368_:
{
lean_object* v___x_4371_; lean_object* v___x_4372_; lean_object* v___x_4374_; 
v___x_4371_ = lean_box(0);
v___x_4372_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4364_, v_a_4202_, v_fst_4357_);
if (v_isShared_4370_ == 0)
{
lean_ctor_set(v___x_4369_, 3, v___x_4372_);
v___x_4374_ = v___x_4369_;
goto v_reusejp_4373_;
}
else
{
lean_object* v_reuseFailAlloc_4381_; 
v_reuseFailAlloc_4381_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4381_, 0, v_stream_4361_);
lean_ctor_set(v_reuseFailAlloc_4381_, 1, v_nameMap_4362_);
lean_ctor_set(v_reuseFailAlloc_4381_, 2, v_levelMap_4363_);
lean_ctor_set(v_reuseFailAlloc_4381_, 3, v___x_4372_);
lean_ctor_set(v_reuseFailAlloc_4381_, 4, v_recursorRuleMap_4365_);
lean_ctor_set(v_reuseFailAlloc_4381_, 5, v_constMap_4366_);
lean_ctor_set(v_reuseFailAlloc_4381_, 6, v_constOrder_4367_);
v___x_4374_ = v_reuseFailAlloc_4381_;
goto v_reusejp_4373_;
}
v_reusejp_4373_:
{
lean_object* v___x_4376_; 
if (v_isShared_4360_ == 0)
{
lean_ctor_set(v___x_4359_, 1, v___x_4374_);
lean_ctor_set(v___x_4359_, 0, v___x_4371_);
v___x_4376_ = v___x_4359_;
goto v_reusejp_4375_;
}
else
{
lean_object* v_reuseFailAlloc_4380_; 
v_reuseFailAlloc_4380_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4380_, 0, v___x_4371_);
lean_ctor_set(v_reuseFailAlloc_4380_, 1, v___x_4374_);
v___x_4376_ = v_reuseFailAlloc_4380_;
goto v_reusejp_4375_;
}
v_reusejp_4375_:
{
lean_object* v___x_4378_; 
if (v_isShared_4355_ == 0)
{
lean_ctor_set(v___x_4354_, 0, v___x_4376_);
v___x_4378_ = v___x_4354_;
goto v_reusejp_4377_;
}
else
{
lean_object* v_reuseFailAlloc_4379_; 
v_reuseFailAlloc_4379_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4379_, 0, v___x_4376_);
v___x_4378_ = v_reuseFailAlloc_4379_;
goto v_reusejp_4377_;
}
v_reusejp_4377_:
{
return v___x_4378_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4385_; lean_object* v___x_4387_; uint8_t v_isShared_4388_; uint8_t v_isSharedCheck_4392_; 
lean_dec(v_a_4202_);
v_a_4385_ = lean_ctor_get(v___x_4351_, 0);
v_isSharedCheck_4392_ = !lean_is_exclusive(v___x_4351_);
if (v_isSharedCheck_4392_ == 0)
{
v___x_4387_ = v___x_4351_;
v_isShared_4388_ = v_isSharedCheck_4392_;
goto v_resetjp_4386_;
}
else
{
lean_inc(v_a_4385_);
lean_dec(v___x_4351_);
v___x_4387_ = lean_box(0);
v_isShared_4388_ = v_isSharedCheck_4392_;
goto v_resetjp_4386_;
}
v_resetjp_4386_:
{
lean_object* v___x_4390_; 
if (v_isShared_4388_ == 0)
{
v___x_4390_ = v___x_4387_;
goto v_reusejp_4389_;
}
else
{
lean_object* v_reuseFailAlloc_4391_; 
v_reuseFailAlloc_4391_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4391_, 0, v_a_4385_);
v___x_4390_ = v_reuseFailAlloc_4391_;
goto v_reusejp_4389_;
}
v_reusejp_4389_:
{
return v___x_4390_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4393_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4393_ = lp_proofEnvironment_Export_Parse_parseExprLetE(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4393_) == 0)
{
lean_object* v_a_4394_; lean_object* v___x_4396_; uint8_t v_isShared_4397_; uint8_t v_isSharedCheck_4426_; 
v_a_4394_ = lean_ctor_get(v___x_4393_, 0);
v_isSharedCheck_4426_ = !lean_is_exclusive(v___x_4393_);
if (v_isSharedCheck_4426_ == 0)
{
v___x_4396_ = v___x_4393_;
v_isShared_4397_ = v_isSharedCheck_4426_;
goto v_resetjp_4395_;
}
else
{
lean_inc(v_a_4394_);
lean_dec(v___x_4393_);
v___x_4396_ = lean_box(0);
v_isShared_4397_ = v_isSharedCheck_4426_;
goto v_resetjp_4395_;
}
v_resetjp_4395_:
{
lean_object* v_snd_4398_; lean_object* v_fst_4399_; lean_object* v___x_4401_; uint8_t v_isShared_4402_; uint8_t v_isSharedCheck_4425_; 
v_snd_4398_ = lean_ctor_get(v_a_4394_, 1);
v_fst_4399_ = lean_ctor_get(v_a_4394_, 0);
v_isSharedCheck_4425_ = !lean_is_exclusive(v_a_4394_);
if (v_isSharedCheck_4425_ == 0)
{
v___x_4401_ = v_a_4394_;
v_isShared_4402_ = v_isSharedCheck_4425_;
goto v_resetjp_4400_;
}
else
{
lean_inc(v_snd_4398_);
lean_inc(v_fst_4399_);
lean_dec(v_a_4394_);
v___x_4401_ = lean_box(0);
v_isShared_4402_ = v_isSharedCheck_4425_;
goto v_resetjp_4400_;
}
v_resetjp_4400_:
{
lean_object* v_stream_4403_; lean_object* v_nameMap_4404_; lean_object* v_levelMap_4405_; lean_object* v_exprMap_4406_; lean_object* v_recursorRuleMap_4407_; lean_object* v_constMap_4408_; lean_object* v_constOrder_4409_; lean_object* v___x_4411_; uint8_t v_isShared_4412_; uint8_t v_isSharedCheck_4424_; 
v_stream_4403_ = lean_ctor_get(v_snd_4398_, 0);
v_nameMap_4404_ = lean_ctor_get(v_snd_4398_, 1);
v_levelMap_4405_ = lean_ctor_get(v_snd_4398_, 2);
v_exprMap_4406_ = lean_ctor_get(v_snd_4398_, 3);
v_recursorRuleMap_4407_ = lean_ctor_get(v_snd_4398_, 4);
v_constMap_4408_ = lean_ctor_get(v_snd_4398_, 5);
v_constOrder_4409_ = lean_ctor_get(v_snd_4398_, 6);
v_isSharedCheck_4424_ = !lean_is_exclusive(v_snd_4398_);
if (v_isSharedCheck_4424_ == 0)
{
v___x_4411_ = v_snd_4398_;
v_isShared_4412_ = v_isSharedCheck_4424_;
goto v_resetjp_4410_;
}
else
{
lean_inc(v_constOrder_4409_);
lean_inc(v_constMap_4408_);
lean_inc(v_recursorRuleMap_4407_);
lean_inc(v_exprMap_4406_);
lean_inc(v_levelMap_4405_);
lean_inc(v_nameMap_4404_);
lean_inc(v_stream_4403_);
lean_dec(v_snd_4398_);
v___x_4411_ = lean_box(0);
v_isShared_4412_ = v_isSharedCheck_4424_;
goto v_resetjp_4410_;
}
v_resetjp_4410_:
{
lean_object* v___x_4413_; lean_object* v___x_4414_; lean_object* v___x_4416_; 
v___x_4413_ = lean_box(0);
v___x_4414_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4406_, v_a_4202_, v_fst_4399_);
if (v_isShared_4412_ == 0)
{
lean_ctor_set(v___x_4411_, 3, v___x_4414_);
v___x_4416_ = v___x_4411_;
goto v_reusejp_4415_;
}
else
{
lean_object* v_reuseFailAlloc_4423_; 
v_reuseFailAlloc_4423_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4423_, 0, v_stream_4403_);
lean_ctor_set(v_reuseFailAlloc_4423_, 1, v_nameMap_4404_);
lean_ctor_set(v_reuseFailAlloc_4423_, 2, v_levelMap_4405_);
lean_ctor_set(v_reuseFailAlloc_4423_, 3, v___x_4414_);
lean_ctor_set(v_reuseFailAlloc_4423_, 4, v_recursorRuleMap_4407_);
lean_ctor_set(v_reuseFailAlloc_4423_, 5, v_constMap_4408_);
lean_ctor_set(v_reuseFailAlloc_4423_, 6, v_constOrder_4409_);
v___x_4416_ = v_reuseFailAlloc_4423_;
goto v_reusejp_4415_;
}
v_reusejp_4415_:
{
lean_object* v___x_4418_; 
if (v_isShared_4402_ == 0)
{
lean_ctor_set(v___x_4401_, 1, v___x_4416_);
lean_ctor_set(v___x_4401_, 0, v___x_4413_);
v___x_4418_ = v___x_4401_;
goto v_reusejp_4417_;
}
else
{
lean_object* v_reuseFailAlloc_4422_; 
v_reuseFailAlloc_4422_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4422_, 0, v___x_4413_);
lean_ctor_set(v_reuseFailAlloc_4422_, 1, v___x_4416_);
v___x_4418_ = v_reuseFailAlloc_4422_;
goto v_reusejp_4417_;
}
v_reusejp_4417_:
{
lean_object* v___x_4420_; 
if (v_isShared_4397_ == 0)
{
lean_ctor_set(v___x_4396_, 0, v___x_4418_);
v___x_4420_ = v___x_4396_;
goto v_reusejp_4419_;
}
else
{
lean_object* v_reuseFailAlloc_4421_; 
v_reuseFailAlloc_4421_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4421_, 0, v___x_4418_);
v___x_4420_ = v_reuseFailAlloc_4421_;
goto v_reusejp_4419_;
}
v_reusejp_4419_:
{
return v___x_4420_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4427_; lean_object* v___x_4429_; uint8_t v_isShared_4430_; uint8_t v_isSharedCheck_4434_; 
lean_dec(v_a_4202_);
v_a_4427_ = lean_ctor_get(v___x_4393_, 0);
v_isSharedCheck_4434_ = !lean_is_exclusive(v___x_4393_);
if (v_isSharedCheck_4434_ == 0)
{
v___x_4429_ = v___x_4393_;
v_isShared_4430_ = v_isSharedCheck_4434_;
goto v_resetjp_4428_;
}
else
{
lean_inc(v_a_4427_);
lean_dec(v___x_4393_);
v___x_4429_ = lean_box(0);
v_isShared_4430_ = v_isSharedCheck_4434_;
goto v_resetjp_4428_;
}
v_resetjp_4428_:
{
lean_object* v___x_4432_; 
if (v_isShared_4430_ == 0)
{
v___x_4432_ = v___x_4429_;
goto v_reusejp_4431_;
}
else
{
lean_object* v_reuseFailAlloc_4433_; 
v_reuseFailAlloc_4433_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4433_, 0, v_a_4427_);
v___x_4432_ = v_reuseFailAlloc_4433_;
goto v_reusejp_4431_;
}
v_reusejp_4431_:
{
return v___x_4432_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4435_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4435_ = lp_proofEnvironment_Export_Parse_parseExprForallE(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4435_) == 0)
{
lean_object* v_a_4436_; lean_object* v___x_4438_; uint8_t v_isShared_4439_; uint8_t v_isSharedCheck_4468_; 
v_a_4436_ = lean_ctor_get(v___x_4435_, 0);
v_isSharedCheck_4468_ = !lean_is_exclusive(v___x_4435_);
if (v_isSharedCheck_4468_ == 0)
{
v___x_4438_ = v___x_4435_;
v_isShared_4439_ = v_isSharedCheck_4468_;
goto v_resetjp_4437_;
}
else
{
lean_inc(v_a_4436_);
lean_dec(v___x_4435_);
v___x_4438_ = lean_box(0);
v_isShared_4439_ = v_isSharedCheck_4468_;
goto v_resetjp_4437_;
}
v_resetjp_4437_:
{
lean_object* v_snd_4440_; lean_object* v_fst_4441_; lean_object* v___x_4443_; uint8_t v_isShared_4444_; uint8_t v_isSharedCheck_4467_; 
v_snd_4440_ = lean_ctor_get(v_a_4436_, 1);
v_fst_4441_ = lean_ctor_get(v_a_4436_, 0);
v_isSharedCheck_4467_ = !lean_is_exclusive(v_a_4436_);
if (v_isSharedCheck_4467_ == 0)
{
v___x_4443_ = v_a_4436_;
v_isShared_4444_ = v_isSharedCheck_4467_;
goto v_resetjp_4442_;
}
else
{
lean_inc(v_snd_4440_);
lean_inc(v_fst_4441_);
lean_dec(v_a_4436_);
v___x_4443_ = lean_box(0);
v_isShared_4444_ = v_isSharedCheck_4467_;
goto v_resetjp_4442_;
}
v_resetjp_4442_:
{
lean_object* v_stream_4445_; lean_object* v_nameMap_4446_; lean_object* v_levelMap_4447_; lean_object* v_exprMap_4448_; lean_object* v_recursorRuleMap_4449_; lean_object* v_constMap_4450_; lean_object* v_constOrder_4451_; lean_object* v___x_4453_; uint8_t v_isShared_4454_; uint8_t v_isSharedCheck_4466_; 
v_stream_4445_ = lean_ctor_get(v_snd_4440_, 0);
v_nameMap_4446_ = lean_ctor_get(v_snd_4440_, 1);
v_levelMap_4447_ = lean_ctor_get(v_snd_4440_, 2);
v_exprMap_4448_ = lean_ctor_get(v_snd_4440_, 3);
v_recursorRuleMap_4449_ = lean_ctor_get(v_snd_4440_, 4);
v_constMap_4450_ = lean_ctor_get(v_snd_4440_, 5);
v_constOrder_4451_ = lean_ctor_get(v_snd_4440_, 6);
v_isSharedCheck_4466_ = !lean_is_exclusive(v_snd_4440_);
if (v_isSharedCheck_4466_ == 0)
{
v___x_4453_ = v_snd_4440_;
v_isShared_4454_ = v_isSharedCheck_4466_;
goto v_resetjp_4452_;
}
else
{
lean_inc(v_constOrder_4451_);
lean_inc(v_constMap_4450_);
lean_inc(v_recursorRuleMap_4449_);
lean_inc(v_exprMap_4448_);
lean_inc(v_levelMap_4447_);
lean_inc(v_nameMap_4446_);
lean_inc(v_stream_4445_);
lean_dec(v_snd_4440_);
v___x_4453_ = lean_box(0);
v_isShared_4454_ = v_isSharedCheck_4466_;
goto v_resetjp_4452_;
}
v_resetjp_4452_:
{
lean_object* v___x_4455_; lean_object* v___x_4456_; lean_object* v___x_4458_; 
v___x_4455_ = lean_box(0);
v___x_4456_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4448_, v_a_4202_, v_fst_4441_);
if (v_isShared_4454_ == 0)
{
lean_ctor_set(v___x_4453_, 3, v___x_4456_);
v___x_4458_ = v___x_4453_;
goto v_reusejp_4457_;
}
else
{
lean_object* v_reuseFailAlloc_4465_; 
v_reuseFailAlloc_4465_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4465_, 0, v_stream_4445_);
lean_ctor_set(v_reuseFailAlloc_4465_, 1, v_nameMap_4446_);
lean_ctor_set(v_reuseFailAlloc_4465_, 2, v_levelMap_4447_);
lean_ctor_set(v_reuseFailAlloc_4465_, 3, v___x_4456_);
lean_ctor_set(v_reuseFailAlloc_4465_, 4, v_recursorRuleMap_4449_);
lean_ctor_set(v_reuseFailAlloc_4465_, 5, v_constMap_4450_);
lean_ctor_set(v_reuseFailAlloc_4465_, 6, v_constOrder_4451_);
v___x_4458_ = v_reuseFailAlloc_4465_;
goto v_reusejp_4457_;
}
v_reusejp_4457_:
{
lean_object* v___x_4460_; 
if (v_isShared_4444_ == 0)
{
lean_ctor_set(v___x_4443_, 1, v___x_4458_);
lean_ctor_set(v___x_4443_, 0, v___x_4455_);
v___x_4460_ = v___x_4443_;
goto v_reusejp_4459_;
}
else
{
lean_object* v_reuseFailAlloc_4464_; 
v_reuseFailAlloc_4464_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4464_, 0, v___x_4455_);
lean_ctor_set(v_reuseFailAlloc_4464_, 1, v___x_4458_);
v___x_4460_ = v_reuseFailAlloc_4464_;
goto v_reusejp_4459_;
}
v_reusejp_4459_:
{
lean_object* v___x_4462_; 
if (v_isShared_4439_ == 0)
{
lean_ctor_set(v___x_4438_, 0, v___x_4460_);
v___x_4462_ = v___x_4438_;
goto v_reusejp_4461_;
}
else
{
lean_object* v_reuseFailAlloc_4463_; 
v_reuseFailAlloc_4463_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4463_, 0, v___x_4460_);
v___x_4462_ = v_reuseFailAlloc_4463_;
goto v_reusejp_4461_;
}
v_reusejp_4461_:
{
return v___x_4462_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4469_; lean_object* v___x_4471_; uint8_t v_isShared_4472_; uint8_t v_isSharedCheck_4476_; 
lean_dec(v_a_4202_);
v_a_4469_ = lean_ctor_get(v___x_4435_, 0);
v_isSharedCheck_4476_ = !lean_is_exclusive(v___x_4435_);
if (v_isSharedCheck_4476_ == 0)
{
v___x_4471_ = v___x_4435_;
v_isShared_4472_ = v_isSharedCheck_4476_;
goto v_resetjp_4470_;
}
else
{
lean_inc(v_a_4469_);
lean_dec(v___x_4435_);
v___x_4471_ = lean_box(0);
v_isShared_4472_ = v_isSharedCheck_4476_;
goto v_resetjp_4470_;
}
v_resetjp_4470_:
{
lean_object* v___x_4474_; 
if (v_isShared_4472_ == 0)
{
v___x_4474_ = v___x_4471_;
goto v_reusejp_4473_;
}
else
{
lean_object* v_reuseFailAlloc_4475_; 
v_reuseFailAlloc_4475_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4475_, 0, v_a_4469_);
v___x_4474_ = v_reuseFailAlloc_4475_;
goto v_reusejp_4473_;
}
v_reusejp_4473_:
{
return v___x_4474_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4477_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4477_ = lp_proofEnvironment_Export_Parse_parseExprLam(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4477_) == 0)
{
lean_object* v_a_4478_; lean_object* v___x_4480_; uint8_t v_isShared_4481_; uint8_t v_isSharedCheck_4510_; 
v_a_4478_ = lean_ctor_get(v___x_4477_, 0);
v_isSharedCheck_4510_ = !lean_is_exclusive(v___x_4477_);
if (v_isSharedCheck_4510_ == 0)
{
v___x_4480_ = v___x_4477_;
v_isShared_4481_ = v_isSharedCheck_4510_;
goto v_resetjp_4479_;
}
else
{
lean_inc(v_a_4478_);
lean_dec(v___x_4477_);
v___x_4480_ = lean_box(0);
v_isShared_4481_ = v_isSharedCheck_4510_;
goto v_resetjp_4479_;
}
v_resetjp_4479_:
{
lean_object* v_snd_4482_; lean_object* v_fst_4483_; lean_object* v___x_4485_; uint8_t v_isShared_4486_; uint8_t v_isSharedCheck_4509_; 
v_snd_4482_ = lean_ctor_get(v_a_4478_, 1);
v_fst_4483_ = lean_ctor_get(v_a_4478_, 0);
v_isSharedCheck_4509_ = !lean_is_exclusive(v_a_4478_);
if (v_isSharedCheck_4509_ == 0)
{
v___x_4485_ = v_a_4478_;
v_isShared_4486_ = v_isSharedCheck_4509_;
goto v_resetjp_4484_;
}
else
{
lean_inc(v_snd_4482_);
lean_inc(v_fst_4483_);
lean_dec(v_a_4478_);
v___x_4485_ = lean_box(0);
v_isShared_4486_ = v_isSharedCheck_4509_;
goto v_resetjp_4484_;
}
v_resetjp_4484_:
{
lean_object* v_stream_4487_; lean_object* v_nameMap_4488_; lean_object* v_levelMap_4489_; lean_object* v_exprMap_4490_; lean_object* v_recursorRuleMap_4491_; lean_object* v_constMap_4492_; lean_object* v_constOrder_4493_; lean_object* v___x_4495_; uint8_t v_isShared_4496_; uint8_t v_isSharedCheck_4508_; 
v_stream_4487_ = lean_ctor_get(v_snd_4482_, 0);
v_nameMap_4488_ = lean_ctor_get(v_snd_4482_, 1);
v_levelMap_4489_ = lean_ctor_get(v_snd_4482_, 2);
v_exprMap_4490_ = lean_ctor_get(v_snd_4482_, 3);
v_recursorRuleMap_4491_ = lean_ctor_get(v_snd_4482_, 4);
v_constMap_4492_ = lean_ctor_get(v_snd_4482_, 5);
v_constOrder_4493_ = lean_ctor_get(v_snd_4482_, 6);
v_isSharedCheck_4508_ = !lean_is_exclusive(v_snd_4482_);
if (v_isSharedCheck_4508_ == 0)
{
v___x_4495_ = v_snd_4482_;
v_isShared_4496_ = v_isSharedCheck_4508_;
goto v_resetjp_4494_;
}
else
{
lean_inc(v_constOrder_4493_);
lean_inc(v_constMap_4492_);
lean_inc(v_recursorRuleMap_4491_);
lean_inc(v_exprMap_4490_);
lean_inc(v_levelMap_4489_);
lean_inc(v_nameMap_4488_);
lean_inc(v_stream_4487_);
lean_dec(v_snd_4482_);
v___x_4495_ = lean_box(0);
v_isShared_4496_ = v_isSharedCheck_4508_;
goto v_resetjp_4494_;
}
v_resetjp_4494_:
{
lean_object* v___x_4497_; lean_object* v___x_4498_; lean_object* v___x_4500_; 
v___x_4497_ = lean_box(0);
v___x_4498_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4490_, v_a_4202_, v_fst_4483_);
if (v_isShared_4496_ == 0)
{
lean_ctor_set(v___x_4495_, 3, v___x_4498_);
v___x_4500_ = v___x_4495_;
goto v_reusejp_4499_;
}
else
{
lean_object* v_reuseFailAlloc_4507_; 
v_reuseFailAlloc_4507_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4507_, 0, v_stream_4487_);
lean_ctor_set(v_reuseFailAlloc_4507_, 1, v_nameMap_4488_);
lean_ctor_set(v_reuseFailAlloc_4507_, 2, v_levelMap_4489_);
lean_ctor_set(v_reuseFailAlloc_4507_, 3, v___x_4498_);
lean_ctor_set(v_reuseFailAlloc_4507_, 4, v_recursorRuleMap_4491_);
lean_ctor_set(v_reuseFailAlloc_4507_, 5, v_constMap_4492_);
lean_ctor_set(v_reuseFailAlloc_4507_, 6, v_constOrder_4493_);
v___x_4500_ = v_reuseFailAlloc_4507_;
goto v_reusejp_4499_;
}
v_reusejp_4499_:
{
lean_object* v___x_4502_; 
if (v_isShared_4486_ == 0)
{
lean_ctor_set(v___x_4485_, 1, v___x_4500_);
lean_ctor_set(v___x_4485_, 0, v___x_4497_);
v___x_4502_ = v___x_4485_;
goto v_reusejp_4501_;
}
else
{
lean_object* v_reuseFailAlloc_4506_; 
v_reuseFailAlloc_4506_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4506_, 0, v___x_4497_);
lean_ctor_set(v_reuseFailAlloc_4506_, 1, v___x_4500_);
v___x_4502_ = v_reuseFailAlloc_4506_;
goto v_reusejp_4501_;
}
v_reusejp_4501_:
{
lean_object* v___x_4504_; 
if (v_isShared_4481_ == 0)
{
lean_ctor_set(v___x_4480_, 0, v___x_4502_);
v___x_4504_ = v___x_4480_;
goto v_reusejp_4503_;
}
else
{
lean_object* v_reuseFailAlloc_4505_; 
v_reuseFailAlloc_4505_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4505_, 0, v___x_4502_);
v___x_4504_ = v_reuseFailAlloc_4505_;
goto v_reusejp_4503_;
}
v_reusejp_4503_:
{
return v___x_4504_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4511_; lean_object* v___x_4513_; uint8_t v_isShared_4514_; uint8_t v_isSharedCheck_4518_; 
lean_dec(v_a_4202_);
v_a_4511_ = lean_ctor_get(v___x_4477_, 0);
v_isSharedCheck_4518_ = !lean_is_exclusive(v___x_4477_);
if (v_isSharedCheck_4518_ == 0)
{
v___x_4513_ = v___x_4477_;
v_isShared_4514_ = v_isSharedCheck_4518_;
goto v_resetjp_4512_;
}
else
{
lean_inc(v_a_4511_);
lean_dec(v___x_4477_);
v___x_4513_ = lean_box(0);
v_isShared_4514_ = v_isSharedCheck_4518_;
goto v_resetjp_4512_;
}
v_resetjp_4512_:
{
lean_object* v___x_4516_; 
if (v_isShared_4514_ == 0)
{
v___x_4516_ = v___x_4513_;
goto v_reusejp_4515_;
}
else
{
lean_object* v_reuseFailAlloc_4517_; 
v_reuseFailAlloc_4517_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4517_, 0, v_a_4511_);
v___x_4516_ = v_reuseFailAlloc_4517_;
goto v_reusejp_4515_;
}
v_reusejp_4515_:
{
return v___x_4516_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4519_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4519_ = lp_proofEnvironment_Export_Parse_parseExprApp(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4519_) == 0)
{
lean_object* v_a_4520_; lean_object* v___x_4522_; uint8_t v_isShared_4523_; uint8_t v_isSharedCheck_4552_; 
v_a_4520_ = lean_ctor_get(v___x_4519_, 0);
v_isSharedCheck_4552_ = !lean_is_exclusive(v___x_4519_);
if (v_isSharedCheck_4552_ == 0)
{
v___x_4522_ = v___x_4519_;
v_isShared_4523_ = v_isSharedCheck_4552_;
goto v_resetjp_4521_;
}
else
{
lean_inc(v_a_4520_);
lean_dec(v___x_4519_);
v___x_4522_ = lean_box(0);
v_isShared_4523_ = v_isSharedCheck_4552_;
goto v_resetjp_4521_;
}
v_resetjp_4521_:
{
lean_object* v_snd_4524_; lean_object* v_fst_4525_; lean_object* v___x_4527_; uint8_t v_isShared_4528_; uint8_t v_isSharedCheck_4551_; 
v_snd_4524_ = lean_ctor_get(v_a_4520_, 1);
v_fst_4525_ = lean_ctor_get(v_a_4520_, 0);
v_isSharedCheck_4551_ = !lean_is_exclusive(v_a_4520_);
if (v_isSharedCheck_4551_ == 0)
{
v___x_4527_ = v_a_4520_;
v_isShared_4528_ = v_isSharedCheck_4551_;
goto v_resetjp_4526_;
}
else
{
lean_inc(v_snd_4524_);
lean_inc(v_fst_4525_);
lean_dec(v_a_4520_);
v___x_4527_ = lean_box(0);
v_isShared_4528_ = v_isSharedCheck_4551_;
goto v_resetjp_4526_;
}
v_resetjp_4526_:
{
lean_object* v_stream_4529_; lean_object* v_nameMap_4530_; lean_object* v_levelMap_4531_; lean_object* v_exprMap_4532_; lean_object* v_recursorRuleMap_4533_; lean_object* v_constMap_4534_; lean_object* v_constOrder_4535_; lean_object* v___x_4537_; uint8_t v_isShared_4538_; uint8_t v_isSharedCheck_4550_; 
v_stream_4529_ = lean_ctor_get(v_snd_4524_, 0);
v_nameMap_4530_ = lean_ctor_get(v_snd_4524_, 1);
v_levelMap_4531_ = lean_ctor_get(v_snd_4524_, 2);
v_exprMap_4532_ = lean_ctor_get(v_snd_4524_, 3);
v_recursorRuleMap_4533_ = lean_ctor_get(v_snd_4524_, 4);
v_constMap_4534_ = lean_ctor_get(v_snd_4524_, 5);
v_constOrder_4535_ = lean_ctor_get(v_snd_4524_, 6);
v_isSharedCheck_4550_ = !lean_is_exclusive(v_snd_4524_);
if (v_isSharedCheck_4550_ == 0)
{
v___x_4537_ = v_snd_4524_;
v_isShared_4538_ = v_isSharedCheck_4550_;
goto v_resetjp_4536_;
}
else
{
lean_inc(v_constOrder_4535_);
lean_inc(v_constMap_4534_);
lean_inc(v_recursorRuleMap_4533_);
lean_inc(v_exprMap_4532_);
lean_inc(v_levelMap_4531_);
lean_inc(v_nameMap_4530_);
lean_inc(v_stream_4529_);
lean_dec(v_snd_4524_);
v___x_4537_ = lean_box(0);
v_isShared_4538_ = v_isSharedCheck_4550_;
goto v_resetjp_4536_;
}
v_resetjp_4536_:
{
lean_object* v___x_4539_; lean_object* v___x_4540_; lean_object* v___x_4542_; 
v___x_4539_ = lean_box(0);
v___x_4540_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4532_, v_a_4202_, v_fst_4525_);
if (v_isShared_4538_ == 0)
{
lean_ctor_set(v___x_4537_, 3, v___x_4540_);
v___x_4542_ = v___x_4537_;
goto v_reusejp_4541_;
}
else
{
lean_object* v_reuseFailAlloc_4549_; 
v_reuseFailAlloc_4549_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4549_, 0, v_stream_4529_);
lean_ctor_set(v_reuseFailAlloc_4549_, 1, v_nameMap_4530_);
lean_ctor_set(v_reuseFailAlloc_4549_, 2, v_levelMap_4531_);
lean_ctor_set(v_reuseFailAlloc_4549_, 3, v___x_4540_);
lean_ctor_set(v_reuseFailAlloc_4549_, 4, v_recursorRuleMap_4533_);
lean_ctor_set(v_reuseFailAlloc_4549_, 5, v_constMap_4534_);
lean_ctor_set(v_reuseFailAlloc_4549_, 6, v_constOrder_4535_);
v___x_4542_ = v_reuseFailAlloc_4549_;
goto v_reusejp_4541_;
}
v_reusejp_4541_:
{
lean_object* v___x_4544_; 
if (v_isShared_4528_ == 0)
{
lean_ctor_set(v___x_4527_, 1, v___x_4542_);
lean_ctor_set(v___x_4527_, 0, v___x_4539_);
v___x_4544_ = v___x_4527_;
goto v_reusejp_4543_;
}
else
{
lean_object* v_reuseFailAlloc_4548_; 
v_reuseFailAlloc_4548_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4548_, 0, v___x_4539_);
lean_ctor_set(v_reuseFailAlloc_4548_, 1, v___x_4542_);
v___x_4544_ = v_reuseFailAlloc_4548_;
goto v_reusejp_4543_;
}
v_reusejp_4543_:
{
lean_object* v___x_4546_; 
if (v_isShared_4523_ == 0)
{
lean_ctor_set(v___x_4522_, 0, v___x_4544_);
v___x_4546_ = v___x_4522_;
goto v_reusejp_4545_;
}
else
{
lean_object* v_reuseFailAlloc_4547_; 
v_reuseFailAlloc_4547_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4547_, 0, v___x_4544_);
v___x_4546_ = v_reuseFailAlloc_4547_;
goto v_reusejp_4545_;
}
v_reusejp_4545_:
{
return v___x_4546_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4553_; lean_object* v___x_4555_; uint8_t v_isShared_4556_; uint8_t v_isSharedCheck_4560_; 
lean_dec(v_a_4202_);
v_a_4553_ = lean_ctor_get(v___x_4519_, 0);
v_isSharedCheck_4560_ = !lean_is_exclusive(v___x_4519_);
if (v_isSharedCheck_4560_ == 0)
{
v___x_4555_ = v___x_4519_;
v_isShared_4556_ = v_isSharedCheck_4560_;
goto v_resetjp_4554_;
}
else
{
lean_inc(v_a_4553_);
lean_dec(v___x_4519_);
v___x_4555_ = lean_box(0);
v_isShared_4556_ = v_isSharedCheck_4560_;
goto v_resetjp_4554_;
}
v_resetjp_4554_:
{
lean_object* v___x_4558_; 
if (v_isShared_4556_ == 0)
{
v___x_4558_ = v___x_4555_;
goto v_reusejp_4557_;
}
else
{
lean_object* v_reuseFailAlloc_4559_; 
v_reuseFailAlloc_4559_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4559_, 0, v_a_4553_);
v___x_4558_ = v_reuseFailAlloc_4559_;
goto v_reusejp_4557_;
}
v_reusejp_4557_:
{
return v___x_4558_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4561_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4561_ = lp_proofEnvironment_Export_Parse_parseExprConst(v_snd_4201_, v_a_4130_);
lean_dec(v_snd_4201_);
if (lean_obj_tag(v___x_4561_) == 0)
{
lean_object* v_a_4562_; lean_object* v___x_4564_; uint8_t v_isShared_4565_; uint8_t v_isSharedCheck_4594_; 
v_a_4562_ = lean_ctor_get(v___x_4561_, 0);
v_isSharedCheck_4594_ = !lean_is_exclusive(v___x_4561_);
if (v_isSharedCheck_4594_ == 0)
{
v___x_4564_ = v___x_4561_;
v_isShared_4565_ = v_isSharedCheck_4594_;
goto v_resetjp_4563_;
}
else
{
lean_inc(v_a_4562_);
lean_dec(v___x_4561_);
v___x_4564_ = lean_box(0);
v_isShared_4565_ = v_isSharedCheck_4594_;
goto v_resetjp_4563_;
}
v_resetjp_4563_:
{
lean_object* v_snd_4566_; lean_object* v_fst_4567_; lean_object* v___x_4569_; uint8_t v_isShared_4570_; uint8_t v_isSharedCheck_4593_; 
v_snd_4566_ = lean_ctor_get(v_a_4562_, 1);
v_fst_4567_ = lean_ctor_get(v_a_4562_, 0);
v_isSharedCheck_4593_ = !lean_is_exclusive(v_a_4562_);
if (v_isSharedCheck_4593_ == 0)
{
v___x_4569_ = v_a_4562_;
v_isShared_4570_ = v_isSharedCheck_4593_;
goto v_resetjp_4568_;
}
else
{
lean_inc(v_snd_4566_);
lean_inc(v_fst_4567_);
lean_dec(v_a_4562_);
v___x_4569_ = lean_box(0);
v_isShared_4570_ = v_isSharedCheck_4593_;
goto v_resetjp_4568_;
}
v_resetjp_4568_:
{
lean_object* v_stream_4571_; lean_object* v_nameMap_4572_; lean_object* v_levelMap_4573_; lean_object* v_exprMap_4574_; lean_object* v_recursorRuleMap_4575_; lean_object* v_constMap_4576_; lean_object* v_constOrder_4577_; lean_object* v___x_4579_; uint8_t v_isShared_4580_; uint8_t v_isSharedCheck_4592_; 
v_stream_4571_ = lean_ctor_get(v_snd_4566_, 0);
v_nameMap_4572_ = lean_ctor_get(v_snd_4566_, 1);
v_levelMap_4573_ = lean_ctor_get(v_snd_4566_, 2);
v_exprMap_4574_ = lean_ctor_get(v_snd_4566_, 3);
v_recursorRuleMap_4575_ = lean_ctor_get(v_snd_4566_, 4);
v_constMap_4576_ = lean_ctor_get(v_snd_4566_, 5);
v_constOrder_4577_ = lean_ctor_get(v_snd_4566_, 6);
v_isSharedCheck_4592_ = !lean_is_exclusive(v_snd_4566_);
if (v_isSharedCheck_4592_ == 0)
{
v___x_4579_ = v_snd_4566_;
v_isShared_4580_ = v_isSharedCheck_4592_;
goto v_resetjp_4578_;
}
else
{
lean_inc(v_constOrder_4577_);
lean_inc(v_constMap_4576_);
lean_inc(v_recursorRuleMap_4575_);
lean_inc(v_exprMap_4574_);
lean_inc(v_levelMap_4573_);
lean_inc(v_nameMap_4572_);
lean_inc(v_stream_4571_);
lean_dec(v_snd_4566_);
v___x_4579_ = lean_box(0);
v_isShared_4580_ = v_isSharedCheck_4592_;
goto v_resetjp_4578_;
}
v_resetjp_4578_:
{
lean_object* v___x_4581_; lean_object* v___x_4582_; lean_object* v___x_4584_; 
v___x_4581_ = lean_box(0);
v___x_4582_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4574_, v_a_4202_, v_fst_4567_);
if (v_isShared_4580_ == 0)
{
lean_ctor_set(v___x_4579_, 3, v___x_4582_);
v___x_4584_ = v___x_4579_;
goto v_reusejp_4583_;
}
else
{
lean_object* v_reuseFailAlloc_4591_; 
v_reuseFailAlloc_4591_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4591_, 0, v_stream_4571_);
lean_ctor_set(v_reuseFailAlloc_4591_, 1, v_nameMap_4572_);
lean_ctor_set(v_reuseFailAlloc_4591_, 2, v_levelMap_4573_);
lean_ctor_set(v_reuseFailAlloc_4591_, 3, v___x_4582_);
lean_ctor_set(v_reuseFailAlloc_4591_, 4, v_recursorRuleMap_4575_);
lean_ctor_set(v_reuseFailAlloc_4591_, 5, v_constMap_4576_);
lean_ctor_set(v_reuseFailAlloc_4591_, 6, v_constOrder_4577_);
v___x_4584_ = v_reuseFailAlloc_4591_;
goto v_reusejp_4583_;
}
v_reusejp_4583_:
{
lean_object* v___x_4586_; 
if (v_isShared_4570_ == 0)
{
lean_ctor_set(v___x_4569_, 1, v___x_4584_);
lean_ctor_set(v___x_4569_, 0, v___x_4581_);
v___x_4586_ = v___x_4569_;
goto v_reusejp_4585_;
}
else
{
lean_object* v_reuseFailAlloc_4590_; 
v_reuseFailAlloc_4590_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4590_, 0, v___x_4581_);
lean_ctor_set(v_reuseFailAlloc_4590_, 1, v___x_4584_);
v___x_4586_ = v_reuseFailAlloc_4590_;
goto v_reusejp_4585_;
}
v_reusejp_4585_:
{
lean_object* v___x_4588_; 
if (v_isShared_4565_ == 0)
{
lean_ctor_set(v___x_4564_, 0, v___x_4586_);
v___x_4588_ = v___x_4564_;
goto v_reusejp_4587_;
}
else
{
lean_object* v_reuseFailAlloc_4589_; 
v_reuseFailAlloc_4589_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4589_, 0, v___x_4586_);
v___x_4588_ = v_reuseFailAlloc_4589_;
goto v_reusejp_4587_;
}
v_reusejp_4587_:
{
return v___x_4588_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4595_; lean_object* v___x_4597_; uint8_t v_isShared_4598_; uint8_t v_isSharedCheck_4602_; 
lean_dec(v_a_4202_);
v_a_4595_ = lean_ctor_get(v___x_4561_, 0);
v_isSharedCheck_4602_ = !lean_is_exclusive(v___x_4561_);
if (v_isSharedCheck_4602_ == 0)
{
v___x_4597_ = v___x_4561_;
v_isShared_4598_ = v_isSharedCheck_4602_;
goto v_resetjp_4596_;
}
else
{
lean_inc(v_a_4595_);
lean_dec(v___x_4561_);
v___x_4597_ = lean_box(0);
v_isShared_4598_ = v_isSharedCheck_4602_;
goto v_resetjp_4596_;
}
v_resetjp_4596_:
{
lean_object* v___x_4600_; 
if (v_isShared_4598_ == 0)
{
v___x_4600_ = v___x_4597_;
goto v_reusejp_4599_;
}
else
{
lean_object* v_reuseFailAlloc_4601_; 
v_reuseFailAlloc_4601_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4601_, 0, v_a_4595_);
v___x_4600_ = v_reuseFailAlloc_4601_;
goto v_reusejp_4599_;
}
v_reusejp_4599_:
{
return v___x_4600_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4603_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4603_ = lp_proofEnvironment_Export_Parse_parseExprSort(v_snd_4201_, v_a_4130_);
if (lean_obj_tag(v___x_4603_) == 0)
{
lean_object* v_a_4604_; lean_object* v___x_4606_; uint8_t v_isShared_4607_; uint8_t v_isSharedCheck_4636_; 
v_a_4604_ = lean_ctor_get(v___x_4603_, 0);
v_isSharedCheck_4636_ = !lean_is_exclusive(v___x_4603_);
if (v_isSharedCheck_4636_ == 0)
{
v___x_4606_ = v___x_4603_;
v_isShared_4607_ = v_isSharedCheck_4636_;
goto v_resetjp_4605_;
}
else
{
lean_inc(v_a_4604_);
lean_dec(v___x_4603_);
v___x_4606_ = lean_box(0);
v_isShared_4607_ = v_isSharedCheck_4636_;
goto v_resetjp_4605_;
}
v_resetjp_4605_:
{
lean_object* v_snd_4608_; lean_object* v_fst_4609_; lean_object* v___x_4611_; uint8_t v_isShared_4612_; uint8_t v_isSharedCheck_4635_; 
v_snd_4608_ = lean_ctor_get(v_a_4604_, 1);
v_fst_4609_ = lean_ctor_get(v_a_4604_, 0);
v_isSharedCheck_4635_ = !lean_is_exclusive(v_a_4604_);
if (v_isSharedCheck_4635_ == 0)
{
v___x_4611_ = v_a_4604_;
v_isShared_4612_ = v_isSharedCheck_4635_;
goto v_resetjp_4610_;
}
else
{
lean_inc(v_snd_4608_);
lean_inc(v_fst_4609_);
lean_dec(v_a_4604_);
v___x_4611_ = lean_box(0);
v_isShared_4612_ = v_isSharedCheck_4635_;
goto v_resetjp_4610_;
}
v_resetjp_4610_:
{
lean_object* v_stream_4613_; lean_object* v_nameMap_4614_; lean_object* v_levelMap_4615_; lean_object* v_exprMap_4616_; lean_object* v_recursorRuleMap_4617_; lean_object* v_constMap_4618_; lean_object* v_constOrder_4619_; lean_object* v___x_4621_; uint8_t v_isShared_4622_; uint8_t v_isSharedCheck_4634_; 
v_stream_4613_ = lean_ctor_get(v_snd_4608_, 0);
v_nameMap_4614_ = lean_ctor_get(v_snd_4608_, 1);
v_levelMap_4615_ = lean_ctor_get(v_snd_4608_, 2);
v_exprMap_4616_ = lean_ctor_get(v_snd_4608_, 3);
v_recursorRuleMap_4617_ = lean_ctor_get(v_snd_4608_, 4);
v_constMap_4618_ = lean_ctor_get(v_snd_4608_, 5);
v_constOrder_4619_ = lean_ctor_get(v_snd_4608_, 6);
v_isSharedCheck_4634_ = !lean_is_exclusive(v_snd_4608_);
if (v_isSharedCheck_4634_ == 0)
{
v___x_4621_ = v_snd_4608_;
v_isShared_4622_ = v_isSharedCheck_4634_;
goto v_resetjp_4620_;
}
else
{
lean_inc(v_constOrder_4619_);
lean_inc(v_constMap_4618_);
lean_inc(v_recursorRuleMap_4617_);
lean_inc(v_exprMap_4616_);
lean_inc(v_levelMap_4615_);
lean_inc(v_nameMap_4614_);
lean_inc(v_stream_4613_);
lean_dec(v_snd_4608_);
v___x_4621_ = lean_box(0);
v_isShared_4622_ = v_isSharedCheck_4634_;
goto v_resetjp_4620_;
}
v_resetjp_4620_:
{
lean_object* v___x_4623_; lean_object* v___x_4624_; lean_object* v___x_4626_; 
v___x_4623_ = lean_box(0);
v___x_4624_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4616_, v_a_4202_, v_fst_4609_);
if (v_isShared_4622_ == 0)
{
lean_ctor_set(v___x_4621_, 3, v___x_4624_);
v___x_4626_ = v___x_4621_;
goto v_reusejp_4625_;
}
else
{
lean_object* v_reuseFailAlloc_4633_; 
v_reuseFailAlloc_4633_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4633_, 0, v_stream_4613_);
lean_ctor_set(v_reuseFailAlloc_4633_, 1, v_nameMap_4614_);
lean_ctor_set(v_reuseFailAlloc_4633_, 2, v_levelMap_4615_);
lean_ctor_set(v_reuseFailAlloc_4633_, 3, v___x_4624_);
lean_ctor_set(v_reuseFailAlloc_4633_, 4, v_recursorRuleMap_4617_);
lean_ctor_set(v_reuseFailAlloc_4633_, 5, v_constMap_4618_);
lean_ctor_set(v_reuseFailAlloc_4633_, 6, v_constOrder_4619_);
v___x_4626_ = v_reuseFailAlloc_4633_;
goto v_reusejp_4625_;
}
v_reusejp_4625_:
{
lean_object* v___x_4628_; 
if (v_isShared_4612_ == 0)
{
lean_ctor_set(v___x_4611_, 1, v___x_4626_);
lean_ctor_set(v___x_4611_, 0, v___x_4623_);
v___x_4628_ = v___x_4611_;
goto v_reusejp_4627_;
}
else
{
lean_object* v_reuseFailAlloc_4632_; 
v_reuseFailAlloc_4632_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4632_, 0, v___x_4623_);
lean_ctor_set(v_reuseFailAlloc_4632_, 1, v___x_4626_);
v___x_4628_ = v_reuseFailAlloc_4632_;
goto v_reusejp_4627_;
}
v_reusejp_4627_:
{
lean_object* v___x_4630_; 
if (v_isShared_4607_ == 0)
{
lean_ctor_set(v___x_4606_, 0, v___x_4628_);
v___x_4630_ = v___x_4606_;
goto v_reusejp_4629_;
}
else
{
lean_object* v_reuseFailAlloc_4631_; 
v_reuseFailAlloc_4631_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4631_, 0, v___x_4628_);
v___x_4630_ = v_reuseFailAlloc_4631_;
goto v_reusejp_4629_;
}
v_reusejp_4629_:
{
return v___x_4630_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4637_; lean_object* v___x_4639_; uint8_t v_isShared_4640_; uint8_t v_isSharedCheck_4644_; 
lean_dec(v_a_4202_);
v_a_4637_ = lean_ctor_get(v___x_4603_, 0);
v_isSharedCheck_4644_ = !lean_is_exclusive(v___x_4603_);
if (v_isSharedCheck_4644_ == 0)
{
v___x_4639_ = v___x_4603_;
v_isShared_4640_ = v_isSharedCheck_4644_;
goto v_resetjp_4638_;
}
else
{
lean_inc(v_a_4637_);
lean_dec(v___x_4603_);
v___x_4639_ = lean_box(0);
v_isShared_4640_ = v_isSharedCheck_4644_;
goto v_resetjp_4638_;
}
v_resetjp_4638_:
{
lean_object* v___x_4642_; 
if (v_isShared_4640_ == 0)
{
v___x_4642_ = v___x_4639_;
goto v_reusejp_4641_;
}
else
{
lean_object* v_reuseFailAlloc_4643_; 
v_reuseFailAlloc_4643_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4643_, 0, v_a_4637_);
v___x_4642_ = v_reuseFailAlloc_4643_;
goto v_reusejp_4641_;
}
v_reusejp_4641_:
{
return v___x_4642_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4200_);
if (lean_obj_tag(v_tail_4199_) == 0)
{
lean_object* v___x_4645_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4645_ = lp_proofEnvironment_Export_Parse_parseExprBVar(v_snd_4201_, v_a_4130_);
if (lean_obj_tag(v___x_4645_) == 0)
{
lean_object* v_a_4646_; lean_object* v___x_4648_; uint8_t v_isShared_4649_; uint8_t v_isSharedCheck_4678_; 
v_a_4646_ = lean_ctor_get(v___x_4645_, 0);
v_isSharedCheck_4678_ = !lean_is_exclusive(v___x_4645_);
if (v_isSharedCheck_4678_ == 0)
{
v___x_4648_ = v___x_4645_;
v_isShared_4649_ = v_isSharedCheck_4678_;
goto v_resetjp_4647_;
}
else
{
lean_inc(v_a_4646_);
lean_dec(v___x_4645_);
v___x_4648_ = lean_box(0);
v_isShared_4649_ = v_isSharedCheck_4678_;
goto v_resetjp_4647_;
}
v_resetjp_4647_:
{
lean_object* v_snd_4650_; lean_object* v_fst_4651_; lean_object* v___x_4653_; uint8_t v_isShared_4654_; uint8_t v_isSharedCheck_4677_; 
v_snd_4650_ = lean_ctor_get(v_a_4646_, 1);
v_fst_4651_ = lean_ctor_get(v_a_4646_, 0);
v_isSharedCheck_4677_ = !lean_is_exclusive(v_a_4646_);
if (v_isSharedCheck_4677_ == 0)
{
v___x_4653_ = v_a_4646_;
v_isShared_4654_ = v_isSharedCheck_4677_;
goto v_resetjp_4652_;
}
else
{
lean_inc(v_snd_4650_);
lean_inc(v_fst_4651_);
lean_dec(v_a_4646_);
v___x_4653_ = lean_box(0);
v_isShared_4654_ = v_isSharedCheck_4677_;
goto v_resetjp_4652_;
}
v_resetjp_4652_:
{
lean_object* v_stream_4655_; lean_object* v_nameMap_4656_; lean_object* v_levelMap_4657_; lean_object* v_exprMap_4658_; lean_object* v_recursorRuleMap_4659_; lean_object* v_constMap_4660_; lean_object* v_constOrder_4661_; lean_object* v___x_4663_; uint8_t v_isShared_4664_; uint8_t v_isSharedCheck_4676_; 
v_stream_4655_ = lean_ctor_get(v_snd_4650_, 0);
v_nameMap_4656_ = lean_ctor_get(v_snd_4650_, 1);
v_levelMap_4657_ = lean_ctor_get(v_snd_4650_, 2);
v_exprMap_4658_ = lean_ctor_get(v_snd_4650_, 3);
v_recursorRuleMap_4659_ = lean_ctor_get(v_snd_4650_, 4);
v_constMap_4660_ = lean_ctor_get(v_snd_4650_, 5);
v_constOrder_4661_ = lean_ctor_get(v_snd_4650_, 6);
v_isSharedCheck_4676_ = !lean_is_exclusive(v_snd_4650_);
if (v_isSharedCheck_4676_ == 0)
{
v___x_4663_ = v_snd_4650_;
v_isShared_4664_ = v_isSharedCheck_4676_;
goto v_resetjp_4662_;
}
else
{
lean_inc(v_constOrder_4661_);
lean_inc(v_constMap_4660_);
lean_inc(v_recursorRuleMap_4659_);
lean_inc(v_exprMap_4658_);
lean_inc(v_levelMap_4657_);
lean_inc(v_nameMap_4656_);
lean_inc(v_stream_4655_);
lean_dec(v_snd_4650_);
v___x_4663_ = lean_box(0);
v_isShared_4664_ = v_isSharedCheck_4676_;
goto v_resetjp_4662_;
}
v_resetjp_4662_:
{
lean_object* v___x_4665_; lean_object* v___x_4666_; lean_object* v___x_4668_; 
v___x_4665_ = lean_box(0);
v___x_4666_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_exprMap_4658_, v_a_4202_, v_fst_4651_);
if (v_isShared_4664_ == 0)
{
lean_ctor_set(v___x_4663_, 3, v___x_4666_);
v___x_4668_ = v___x_4663_;
goto v_reusejp_4667_;
}
else
{
lean_object* v_reuseFailAlloc_4675_; 
v_reuseFailAlloc_4675_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4675_, 0, v_stream_4655_);
lean_ctor_set(v_reuseFailAlloc_4675_, 1, v_nameMap_4656_);
lean_ctor_set(v_reuseFailAlloc_4675_, 2, v_levelMap_4657_);
lean_ctor_set(v_reuseFailAlloc_4675_, 3, v___x_4666_);
lean_ctor_set(v_reuseFailAlloc_4675_, 4, v_recursorRuleMap_4659_);
lean_ctor_set(v_reuseFailAlloc_4675_, 5, v_constMap_4660_);
lean_ctor_set(v_reuseFailAlloc_4675_, 6, v_constOrder_4661_);
v___x_4668_ = v_reuseFailAlloc_4675_;
goto v_reusejp_4667_;
}
v_reusejp_4667_:
{
lean_object* v___x_4670_; 
if (v_isShared_4654_ == 0)
{
lean_ctor_set(v___x_4653_, 1, v___x_4668_);
lean_ctor_set(v___x_4653_, 0, v___x_4665_);
v___x_4670_ = v___x_4653_;
goto v_reusejp_4669_;
}
else
{
lean_object* v_reuseFailAlloc_4674_; 
v_reuseFailAlloc_4674_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4674_, 0, v___x_4665_);
lean_ctor_set(v_reuseFailAlloc_4674_, 1, v___x_4668_);
v___x_4670_ = v_reuseFailAlloc_4674_;
goto v_reusejp_4669_;
}
v_reusejp_4669_:
{
lean_object* v___x_4672_; 
if (v_isShared_4649_ == 0)
{
lean_ctor_set(v___x_4648_, 0, v___x_4670_);
v___x_4672_ = v___x_4648_;
goto v_reusejp_4671_;
}
else
{
lean_object* v_reuseFailAlloc_4673_; 
v_reuseFailAlloc_4673_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4673_, 0, v___x_4670_);
v___x_4672_ = v_reuseFailAlloc_4673_;
goto v_reusejp_4671_;
}
v_reusejp_4671_:
{
return v___x_4672_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4679_; lean_object* v___x_4681_; uint8_t v_isShared_4682_; uint8_t v_isSharedCheck_4686_; 
lean_dec(v_a_4202_);
v_a_4679_ = lean_ctor_get(v___x_4645_, 0);
v_isSharedCheck_4686_ = !lean_is_exclusive(v___x_4645_);
if (v_isSharedCheck_4686_ == 0)
{
v___x_4681_ = v___x_4645_;
v_isShared_4682_ = v_isSharedCheck_4686_;
goto v_resetjp_4680_;
}
else
{
lean_inc(v_a_4679_);
lean_dec(v___x_4645_);
v___x_4681_ = lean_box(0);
v_isShared_4682_ = v_isSharedCheck_4686_;
goto v_resetjp_4680_;
}
v_resetjp_4680_:
{
lean_object* v___x_4684_; 
if (v_isShared_4682_ == 0)
{
v___x_4684_ = v___x_4681_;
goto v_reusejp_4683_;
}
else
{
lean_object* v_reuseFailAlloc_4685_; 
v_reuseFailAlloc_4685_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4685_, 0, v_a_4679_);
v___x_4684_ = v_reuseFailAlloc_4685_;
goto v_reusejp_4683_;
}
v_reusejp_4683_:
{
return v___x_4684_;
}
}
}
}
else
{
lean_dec(v_a_4202_);
lean_dec(v_snd_4201_);
lean_dec(v_tail_4199_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_mantissa_4192_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_exponent_4193_);
lean_dec(v_mantissa_4192_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 2)
{
lean_object* v_n_4687_; lean_object* v_mantissa_4688_; lean_object* v_exponent_4689_; lean_object* v_natZero_4690_; lean_object* v_intZero_4691_; uint8_t v_isNeg_4692_; 
v_n_4687_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc_ref(v_n_4687_);
lean_dec_ref_known(v_snd_4159_, 1);
v_mantissa_4688_ = lean_ctor_get(v_n_4687_, 0);
lean_inc(v_mantissa_4688_);
v_exponent_4689_ = lean_ctor_get(v_n_4687_, 1);
lean_inc(v_exponent_4689_);
lean_dec_ref(v_n_4687_);
v_natZero_4690_ = lean_unsigned_to_nat(0u);
v_intZero_4691_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_4692_ = lean_int_dec_lt(v_mantissa_4688_, v_intZero_4691_);
if (v_isNeg_4692_ == 0)
{
uint8_t v___x_4693_; 
v___x_4693_ = lean_nat_dec_eq(v_exponent_4689_, v_natZero_4690_);
lean_dec(v_exponent_4689_);
if (v___x_4693_ == 0)
{
lean_dec(v_mantissa_4688_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_tail_4160_) == 1)
{
lean_object* v_head_4694_; lean_object* v_tail_4695_; lean_object* v_fst_4696_; lean_object* v_snd_4697_; lean_object* v_a_4698_; lean_object* v___x_4699_; uint8_t v___x_4700_; 
v_head_4694_ = lean_ctor_get(v_tail_4160_, 0);
lean_inc(v_head_4694_);
v_tail_4695_ = lean_ctor_get(v_tail_4160_, 1);
lean_inc(v_tail_4695_);
lean_dec_ref_known(v_tail_4160_, 2);
v_fst_4696_ = lean_ctor_get(v_head_4694_, 0);
lean_inc(v_fst_4696_);
v_snd_4697_ = lean_ctor_get(v_head_4694_, 1);
lean_inc(v_snd_4697_);
lean_dec(v_head_4694_);
v_a_4698_ = lean_nat_abs(v_mantissa_4688_);
lean_dec(v_mantissa_4688_);
v___x_4699_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__20));
v___x_4700_ = lean_string_dec_eq(v_fst_4696_, v___x_4699_);
if (v___x_4700_ == 0)
{
lean_object* v___x_4701_; uint8_t v___x_4702_; 
v___x_4701_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__21));
v___x_4702_ = lean_string_dec_eq(v_fst_4696_, v___x_4701_);
if (v___x_4702_ == 0)
{
lean_object* v___x_4703_; uint8_t v___x_4704_; 
v___x_4703_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__22));
v___x_4704_ = lean_string_dec_eq(v_fst_4696_, v___x_4703_);
if (v___x_4704_ == 0)
{
lean_object* v___x_4705_; uint8_t v___x_4706_; 
v___x_4705_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__23));
v___x_4706_ = lean_string_dec_eq(v_fst_4696_, v___x_4705_);
lean_dec(v_fst_4696_);
if (v___x_4706_ == 0)
{
lean_dec(v_a_4698_);
lean_dec(v_snd_4697_);
lean_dec(v_tail_4695_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_tail_4695_) == 0)
{
lean_object* v___x_4707_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4707_ = lp_proofEnvironment_Export_Parse_parseLevelParam(v_snd_4697_, v_a_4130_);
if (lean_obj_tag(v___x_4707_) == 0)
{
lean_object* v_a_4708_; lean_object* v___x_4710_; uint8_t v_isShared_4711_; uint8_t v_isSharedCheck_4740_; 
v_a_4708_ = lean_ctor_get(v___x_4707_, 0);
v_isSharedCheck_4740_ = !lean_is_exclusive(v___x_4707_);
if (v_isSharedCheck_4740_ == 0)
{
v___x_4710_ = v___x_4707_;
v_isShared_4711_ = v_isSharedCheck_4740_;
goto v_resetjp_4709_;
}
else
{
lean_inc(v_a_4708_);
lean_dec(v___x_4707_);
v___x_4710_ = lean_box(0);
v_isShared_4711_ = v_isSharedCheck_4740_;
goto v_resetjp_4709_;
}
v_resetjp_4709_:
{
lean_object* v_snd_4712_; lean_object* v_fst_4713_; lean_object* v___x_4715_; uint8_t v_isShared_4716_; uint8_t v_isSharedCheck_4739_; 
v_snd_4712_ = lean_ctor_get(v_a_4708_, 1);
v_fst_4713_ = lean_ctor_get(v_a_4708_, 0);
v_isSharedCheck_4739_ = !lean_is_exclusive(v_a_4708_);
if (v_isSharedCheck_4739_ == 0)
{
v___x_4715_ = v_a_4708_;
v_isShared_4716_ = v_isSharedCheck_4739_;
goto v_resetjp_4714_;
}
else
{
lean_inc(v_snd_4712_);
lean_inc(v_fst_4713_);
lean_dec(v_a_4708_);
v___x_4715_ = lean_box(0);
v_isShared_4716_ = v_isSharedCheck_4739_;
goto v_resetjp_4714_;
}
v_resetjp_4714_:
{
lean_object* v_stream_4717_; lean_object* v_nameMap_4718_; lean_object* v_levelMap_4719_; lean_object* v_exprMap_4720_; lean_object* v_recursorRuleMap_4721_; lean_object* v_constMap_4722_; lean_object* v_constOrder_4723_; lean_object* v___x_4725_; uint8_t v_isShared_4726_; uint8_t v_isSharedCheck_4738_; 
v_stream_4717_ = lean_ctor_get(v_snd_4712_, 0);
v_nameMap_4718_ = lean_ctor_get(v_snd_4712_, 1);
v_levelMap_4719_ = lean_ctor_get(v_snd_4712_, 2);
v_exprMap_4720_ = lean_ctor_get(v_snd_4712_, 3);
v_recursorRuleMap_4721_ = lean_ctor_get(v_snd_4712_, 4);
v_constMap_4722_ = lean_ctor_get(v_snd_4712_, 5);
v_constOrder_4723_ = lean_ctor_get(v_snd_4712_, 6);
v_isSharedCheck_4738_ = !lean_is_exclusive(v_snd_4712_);
if (v_isSharedCheck_4738_ == 0)
{
v___x_4725_ = v_snd_4712_;
v_isShared_4726_ = v_isSharedCheck_4738_;
goto v_resetjp_4724_;
}
else
{
lean_inc(v_constOrder_4723_);
lean_inc(v_constMap_4722_);
lean_inc(v_recursorRuleMap_4721_);
lean_inc(v_exprMap_4720_);
lean_inc(v_levelMap_4719_);
lean_inc(v_nameMap_4718_);
lean_inc(v_stream_4717_);
lean_dec(v_snd_4712_);
v___x_4725_ = lean_box(0);
v_isShared_4726_ = v_isSharedCheck_4738_;
goto v_resetjp_4724_;
}
v_resetjp_4724_:
{
lean_object* v___x_4727_; lean_object* v___x_4728_; lean_object* v___x_4730_; 
v___x_4727_ = lean_box(0);
v___x_4728_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_levelMap_4719_, v_a_4698_, v_fst_4713_);
if (v_isShared_4726_ == 0)
{
lean_ctor_set(v___x_4725_, 2, v___x_4728_);
v___x_4730_ = v___x_4725_;
goto v_reusejp_4729_;
}
else
{
lean_object* v_reuseFailAlloc_4737_; 
v_reuseFailAlloc_4737_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4737_, 0, v_stream_4717_);
lean_ctor_set(v_reuseFailAlloc_4737_, 1, v_nameMap_4718_);
lean_ctor_set(v_reuseFailAlloc_4737_, 2, v___x_4728_);
lean_ctor_set(v_reuseFailAlloc_4737_, 3, v_exprMap_4720_);
lean_ctor_set(v_reuseFailAlloc_4737_, 4, v_recursorRuleMap_4721_);
lean_ctor_set(v_reuseFailAlloc_4737_, 5, v_constMap_4722_);
lean_ctor_set(v_reuseFailAlloc_4737_, 6, v_constOrder_4723_);
v___x_4730_ = v_reuseFailAlloc_4737_;
goto v_reusejp_4729_;
}
v_reusejp_4729_:
{
lean_object* v___x_4732_; 
if (v_isShared_4716_ == 0)
{
lean_ctor_set(v___x_4715_, 1, v___x_4730_);
lean_ctor_set(v___x_4715_, 0, v___x_4727_);
v___x_4732_ = v___x_4715_;
goto v_reusejp_4731_;
}
else
{
lean_object* v_reuseFailAlloc_4736_; 
v_reuseFailAlloc_4736_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4736_, 0, v___x_4727_);
lean_ctor_set(v_reuseFailAlloc_4736_, 1, v___x_4730_);
v___x_4732_ = v_reuseFailAlloc_4736_;
goto v_reusejp_4731_;
}
v_reusejp_4731_:
{
lean_object* v___x_4734_; 
if (v_isShared_4711_ == 0)
{
lean_ctor_set(v___x_4710_, 0, v___x_4732_);
v___x_4734_ = v___x_4710_;
goto v_reusejp_4733_;
}
else
{
lean_object* v_reuseFailAlloc_4735_; 
v_reuseFailAlloc_4735_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4735_, 0, v___x_4732_);
v___x_4734_ = v_reuseFailAlloc_4735_;
goto v_reusejp_4733_;
}
v_reusejp_4733_:
{
return v___x_4734_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4741_; lean_object* v___x_4743_; uint8_t v_isShared_4744_; uint8_t v_isSharedCheck_4748_; 
lean_dec(v_a_4698_);
v_a_4741_ = lean_ctor_get(v___x_4707_, 0);
v_isSharedCheck_4748_ = !lean_is_exclusive(v___x_4707_);
if (v_isSharedCheck_4748_ == 0)
{
v___x_4743_ = v___x_4707_;
v_isShared_4744_ = v_isSharedCheck_4748_;
goto v_resetjp_4742_;
}
else
{
lean_inc(v_a_4741_);
lean_dec(v___x_4707_);
v___x_4743_ = lean_box(0);
v_isShared_4744_ = v_isSharedCheck_4748_;
goto v_resetjp_4742_;
}
v_resetjp_4742_:
{
lean_object* v___x_4746_; 
if (v_isShared_4744_ == 0)
{
v___x_4746_ = v___x_4743_;
goto v_reusejp_4745_;
}
else
{
lean_object* v_reuseFailAlloc_4747_; 
v_reuseFailAlloc_4747_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4747_, 0, v_a_4741_);
v___x_4746_ = v_reuseFailAlloc_4747_;
goto v_reusejp_4745_;
}
v_reusejp_4745_:
{
return v___x_4746_;
}
}
}
}
else
{
lean_dec(v_a_4698_);
lean_dec(v_snd_4697_);
lean_dec(v_tail_4695_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4696_);
if (lean_obj_tag(v_tail_4695_) == 0)
{
lean_object* v___x_4749_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4749_ = lp_proofEnvironment_Export_Parse_parseLevelImax(v_snd_4697_, v_a_4130_);
lean_dec(v_snd_4697_);
if (lean_obj_tag(v___x_4749_) == 0)
{
lean_object* v_a_4750_; lean_object* v___x_4752_; uint8_t v_isShared_4753_; uint8_t v_isSharedCheck_4782_; 
v_a_4750_ = lean_ctor_get(v___x_4749_, 0);
v_isSharedCheck_4782_ = !lean_is_exclusive(v___x_4749_);
if (v_isSharedCheck_4782_ == 0)
{
v___x_4752_ = v___x_4749_;
v_isShared_4753_ = v_isSharedCheck_4782_;
goto v_resetjp_4751_;
}
else
{
lean_inc(v_a_4750_);
lean_dec(v___x_4749_);
v___x_4752_ = lean_box(0);
v_isShared_4753_ = v_isSharedCheck_4782_;
goto v_resetjp_4751_;
}
v_resetjp_4751_:
{
lean_object* v_snd_4754_; lean_object* v_fst_4755_; lean_object* v___x_4757_; uint8_t v_isShared_4758_; uint8_t v_isSharedCheck_4781_; 
v_snd_4754_ = lean_ctor_get(v_a_4750_, 1);
v_fst_4755_ = lean_ctor_get(v_a_4750_, 0);
v_isSharedCheck_4781_ = !lean_is_exclusive(v_a_4750_);
if (v_isSharedCheck_4781_ == 0)
{
v___x_4757_ = v_a_4750_;
v_isShared_4758_ = v_isSharedCheck_4781_;
goto v_resetjp_4756_;
}
else
{
lean_inc(v_snd_4754_);
lean_inc(v_fst_4755_);
lean_dec(v_a_4750_);
v___x_4757_ = lean_box(0);
v_isShared_4758_ = v_isSharedCheck_4781_;
goto v_resetjp_4756_;
}
v_resetjp_4756_:
{
lean_object* v_stream_4759_; lean_object* v_nameMap_4760_; lean_object* v_levelMap_4761_; lean_object* v_exprMap_4762_; lean_object* v_recursorRuleMap_4763_; lean_object* v_constMap_4764_; lean_object* v_constOrder_4765_; lean_object* v___x_4767_; uint8_t v_isShared_4768_; uint8_t v_isSharedCheck_4780_; 
v_stream_4759_ = lean_ctor_get(v_snd_4754_, 0);
v_nameMap_4760_ = lean_ctor_get(v_snd_4754_, 1);
v_levelMap_4761_ = lean_ctor_get(v_snd_4754_, 2);
v_exprMap_4762_ = lean_ctor_get(v_snd_4754_, 3);
v_recursorRuleMap_4763_ = lean_ctor_get(v_snd_4754_, 4);
v_constMap_4764_ = lean_ctor_get(v_snd_4754_, 5);
v_constOrder_4765_ = lean_ctor_get(v_snd_4754_, 6);
v_isSharedCheck_4780_ = !lean_is_exclusive(v_snd_4754_);
if (v_isSharedCheck_4780_ == 0)
{
v___x_4767_ = v_snd_4754_;
v_isShared_4768_ = v_isSharedCheck_4780_;
goto v_resetjp_4766_;
}
else
{
lean_inc(v_constOrder_4765_);
lean_inc(v_constMap_4764_);
lean_inc(v_recursorRuleMap_4763_);
lean_inc(v_exprMap_4762_);
lean_inc(v_levelMap_4761_);
lean_inc(v_nameMap_4760_);
lean_inc(v_stream_4759_);
lean_dec(v_snd_4754_);
v___x_4767_ = lean_box(0);
v_isShared_4768_ = v_isSharedCheck_4780_;
goto v_resetjp_4766_;
}
v_resetjp_4766_:
{
lean_object* v___x_4769_; lean_object* v___x_4770_; lean_object* v___x_4772_; 
v___x_4769_ = lean_box(0);
v___x_4770_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_levelMap_4761_, v_a_4698_, v_fst_4755_);
if (v_isShared_4768_ == 0)
{
lean_ctor_set(v___x_4767_, 2, v___x_4770_);
v___x_4772_ = v___x_4767_;
goto v_reusejp_4771_;
}
else
{
lean_object* v_reuseFailAlloc_4779_; 
v_reuseFailAlloc_4779_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4779_, 0, v_stream_4759_);
lean_ctor_set(v_reuseFailAlloc_4779_, 1, v_nameMap_4760_);
lean_ctor_set(v_reuseFailAlloc_4779_, 2, v___x_4770_);
lean_ctor_set(v_reuseFailAlloc_4779_, 3, v_exprMap_4762_);
lean_ctor_set(v_reuseFailAlloc_4779_, 4, v_recursorRuleMap_4763_);
lean_ctor_set(v_reuseFailAlloc_4779_, 5, v_constMap_4764_);
lean_ctor_set(v_reuseFailAlloc_4779_, 6, v_constOrder_4765_);
v___x_4772_ = v_reuseFailAlloc_4779_;
goto v_reusejp_4771_;
}
v_reusejp_4771_:
{
lean_object* v___x_4774_; 
if (v_isShared_4758_ == 0)
{
lean_ctor_set(v___x_4757_, 1, v___x_4772_);
lean_ctor_set(v___x_4757_, 0, v___x_4769_);
v___x_4774_ = v___x_4757_;
goto v_reusejp_4773_;
}
else
{
lean_object* v_reuseFailAlloc_4778_; 
v_reuseFailAlloc_4778_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4778_, 0, v___x_4769_);
lean_ctor_set(v_reuseFailAlloc_4778_, 1, v___x_4772_);
v___x_4774_ = v_reuseFailAlloc_4778_;
goto v_reusejp_4773_;
}
v_reusejp_4773_:
{
lean_object* v___x_4776_; 
if (v_isShared_4753_ == 0)
{
lean_ctor_set(v___x_4752_, 0, v___x_4774_);
v___x_4776_ = v___x_4752_;
goto v_reusejp_4775_;
}
else
{
lean_object* v_reuseFailAlloc_4777_; 
v_reuseFailAlloc_4777_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4777_, 0, v___x_4774_);
v___x_4776_ = v_reuseFailAlloc_4777_;
goto v_reusejp_4775_;
}
v_reusejp_4775_:
{
return v___x_4776_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4783_; lean_object* v___x_4785_; uint8_t v_isShared_4786_; uint8_t v_isSharedCheck_4790_; 
lean_dec(v_a_4698_);
v_a_4783_ = lean_ctor_get(v___x_4749_, 0);
v_isSharedCheck_4790_ = !lean_is_exclusive(v___x_4749_);
if (v_isSharedCheck_4790_ == 0)
{
v___x_4785_ = v___x_4749_;
v_isShared_4786_ = v_isSharedCheck_4790_;
goto v_resetjp_4784_;
}
else
{
lean_inc(v_a_4783_);
lean_dec(v___x_4749_);
v___x_4785_ = lean_box(0);
v_isShared_4786_ = v_isSharedCheck_4790_;
goto v_resetjp_4784_;
}
v_resetjp_4784_:
{
lean_object* v___x_4788_; 
if (v_isShared_4786_ == 0)
{
v___x_4788_ = v___x_4785_;
goto v_reusejp_4787_;
}
else
{
lean_object* v_reuseFailAlloc_4789_; 
v_reuseFailAlloc_4789_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4789_, 0, v_a_4783_);
v___x_4788_ = v_reuseFailAlloc_4789_;
goto v_reusejp_4787_;
}
v_reusejp_4787_:
{
return v___x_4788_;
}
}
}
}
else
{
lean_dec(v_a_4698_);
lean_dec(v_snd_4697_);
lean_dec(v_tail_4695_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4696_);
if (lean_obj_tag(v_tail_4695_) == 0)
{
lean_object* v___x_4791_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4791_ = lp_proofEnvironment_Export_Parse_parseLevelMax(v_snd_4697_, v_a_4130_);
lean_dec(v_snd_4697_);
if (lean_obj_tag(v___x_4791_) == 0)
{
lean_object* v_a_4792_; lean_object* v___x_4794_; uint8_t v_isShared_4795_; uint8_t v_isSharedCheck_4824_; 
v_a_4792_ = lean_ctor_get(v___x_4791_, 0);
v_isSharedCheck_4824_ = !lean_is_exclusive(v___x_4791_);
if (v_isSharedCheck_4824_ == 0)
{
v___x_4794_ = v___x_4791_;
v_isShared_4795_ = v_isSharedCheck_4824_;
goto v_resetjp_4793_;
}
else
{
lean_inc(v_a_4792_);
lean_dec(v___x_4791_);
v___x_4794_ = lean_box(0);
v_isShared_4795_ = v_isSharedCheck_4824_;
goto v_resetjp_4793_;
}
v_resetjp_4793_:
{
lean_object* v_snd_4796_; lean_object* v_fst_4797_; lean_object* v___x_4799_; uint8_t v_isShared_4800_; uint8_t v_isSharedCheck_4823_; 
v_snd_4796_ = lean_ctor_get(v_a_4792_, 1);
v_fst_4797_ = lean_ctor_get(v_a_4792_, 0);
v_isSharedCheck_4823_ = !lean_is_exclusive(v_a_4792_);
if (v_isSharedCheck_4823_ == 0)
{
v___x_4799_ = v_a_4792_;
v_isShared_4800_ = v_isSharedCheck_4823_;
goto v_resetjp_4798_;
}
else
{
lean_inc(v_snd_4796_);
lean_inc(v_fst_4797_);
lean_dec(v_a_4792_);
v___x_4799_ = lean_box(0);
v_isShared_4800_ = v_isSharedCheck_4823_;
goto v_resetjp_4798_;
}
v_resetjp_4798_:
{
lean_object* v_stream_4801_; lean_object* v_nameMap_4802_; lean_object* v_levelMap_4803_; lean_object* v_exprMap_4804_; lean_object* v_recursorRuleMap_4805_; lean_object* v_constMap_4806_; lean_object* v_constOrder_4807_; lean_object* v___x_4809_; uint8_t v_isShared_4810_; uint8_t v_isSharedCheck_4822_; 
v_stream_4801_ = lean_ctor_get(v_snd_4796_, 0);
v_nameMap_4802_ = lean_ctor_get(v_snd_4796_, 1);
v_levelMap_4803_ = lean_ctor_get(v_snd_4796_, 2);
v_exprMap_4804_ = lean_ctor_get(v_snd_4796_, 3);
v_recursorRuleMap_4805_ = lean_ctor_get(v_snd_4796_, 4);
v_constMap_4806_ = lean_ctor_get(v_snd_4796_, 5);
v_constOrder_4807_ = lean_ctor_get(v_snd_4796_, 6);
v_isSharedCheck_4822_ = !lean_is_exclusive(v_snd_4796_);
if (v_isSharedCheck_4822_ == 0)
{
v___x_4809_ = v_snd_4796_;
v_isShared_4810_ = v_isSharedCheck_4822_;
goto v_resetjp_4808_;
}
else
{
lean_inc(v_constOrder_4807_);
lean_inc(v_constMap_4806_);
lean_inc(v_recursorRuleMap_4805_);
lean_inc(v_exprMap_4804_);
lean_inc(v_levelMap_4803_);
lean_inc(v_nameMap_4802_);
lean_inc(v_stream_4801_);
lean_dec(v_snd_4796_);
v___x_4809_ = lean_box(0);
v_isShared_4810_ = v_isSharedCheck_4822_;
goto v_resetjp_4808_;
}
v_resetjp_4808_:
{
lean_object* v___x_4811_; lean_object* v___x_4812_; lean_object* v___x_4814_; 
v___x_4811_ = lean_box(0);
v___x_4812_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_levelMap_4803_, v_a_4698_, v_fst_4797_);
if (v_isShared_4810_ == 0)
{
lean_ctor_set(v___x_4809_, 2, v___x_4812_);
v___x_4814_ = v___x_4809_;
goto v_reusejp_4813_;
}
else
{
lean_object* v_reuseFailAlloc_4821_; 
v_reuseFailAlloc_4821_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4821_, 0, v_stream_4801_);
lean_ctor_set(v_reuseFailAlloc_4821_, 1, v_nameMap_4802_);
lean_ctor_set(v_reuseFailAlloc_4821_, 2, v___x_4812_);
lean_ctor_set(v_reuseFailAlloc_4821_, 3, v_exprMap_4804_);
lean_ctor_set(v_reuseFailAlloc_4821_, 4, v_recursorRuleMap_4805_);
lean_ctor_set(v_reuseFailAlloc_4821_, 5, v_constMap_4806_);
lean_ctor_set(v_reuseFailAlloc_4821_, 6, v_constOrder_4807_);
v___x_4814_ = v_reuseFailAlloc_4821_;
goto v_reusejp_4813_;
}
v_reusejp_4813_:
{
lean_object* v___x_4816_; 
if (v_isShared_4800_ == 0)
{
lean_ctor_set(v___x_4799_, 1, v___x_4814_);
lean_ctor_set(v___x_4799_, 0, v___x_4811_);
v___x_4816_ = v___x_4799_;
goto v_reusejp_4815_;
}
else
{
lean_object* v_reuseFailAlloc_4820_; 
v_reuseFailAlloc_4820_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4820_, 0, v___x_4811_);
lean_ctor_set(v_reuseFailAlloc_4820_, 1, v___x_4814_);
v___x_4816_ = v_reuseFailAlloc_4820_;
goto v_reusejp_4815_;
}
v_reusejp_4815_:
{
lean_object* v___x_4818_; 
if (v_isShared_4795_ == 0)
{
lean_ctor_set(v___x_4794_, 0, v___x_4816_);
v___x_4818_ = v___x_4794_;
goto v_reusejp_4817_;
}
else
{
lean_object* v_reuseFailAlloc_4819_; 
v_reuseFailAlloc_4819_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4819_, 0, v___x_4816_);
v___x_4818_ = v_reuseFailAlloc_4819_;
goto v_reusejp_4817_;
}
v_reusejp_4817_:
{
return v___x_4818_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4825_; lean_object* v___x_4827_; uint8_t v_isShared_4828_; uint8_t v_isSharedCheck_4832_; 
lean_dec(v_a_4698_);
v_a_4825_ = lean_ctor_get(v___x_4791_, 0);
v_isSharedCheck_4832_ = !lean_is_exclusive(v___x_4791_);
if (v_isSharedCheck_4832_ == 0)
{
v___x_4827_ = v___x_4791_;
v_isShared_4828_ = v_isSharedCheck_4832_;
goto v_resetjp_4826_;
}
else
{
lean_inc(v_a_4825_);
lean_dec(v___x_4791_);
v___x_4827_ = lean_box(0);
v_isShared_4828_ = v_isSharedCheck_4832_;
goto v_resetjp_4826_;
}
v_resetjp_4826_:
{
lean_object* v___x_4830_; 
if (v_isShared_4828_ == 0)
{
v___x_4830_ = v___x_4827_;
goto v_reusejp_4829_;
}
else
{
lean_object* v_reuseFailAlloc_4831_; 
v_reuseFailAlloc_4831_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4831_, 0, v_a_4825_);
v___x_4830_ = v_reuseFailAlloc_4831_;
goto v_reusejp_4829_;
}
v_reusejp_4829_:
{
return v___x_4830_;
}
}
}
}
else
{
lean_dec(v_a_4698_);
lean_dec(v_snd_4697_);
lean_dec(v_tail_4695_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4696_);
if (lean_obj_tag(v_tail_4695_) == 0)
{
lean_object* v___x_4833_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4833_ = lp_proofEnvironment_Export_Parse_parseLevelSucc(v_snd_4697_, v_a_4130_);
if (lean_obj_tag(v___x_4833_) == 0)
{
lean_object* v_a_4834_; lean_object* v___x_4836_; uint8_t v_isShared_4837_; uint8_t v_isSharedCheck_4866_; 
v_a_4834_ = lean_ctor_get(v___x_4833_, 0);
v_isSharedCheck_4866_ = !lean_is_exclusive(v___x_4833_);
if (v_isSharedCheck_4866_ == 0)
{
v___x_4836_ = v___x_4833_;
v_isShared_4837_ = v_isSharedCheck_4866_;
goto v_resetjp_4835_;
}
else
{
lean_inc(v_a_4834_);
lean_dec(v___x_4833_);
v___x_4836_ = lean_box(0);
v_isShared_4837_ = v_isSharedCheck_4866_;
goto v_resetjp_4835_;
}
v_resetjp_4835_:
{
lean_object* v_snd_4838_; lean_object* v_fst_4839_; lean_object* v___x_4841_; uint8_t v_isShared_4842_; uint8_t v_isSharedCheck_4865_; 
v_snd_4838_ = lean_ctor_get(v_a_4834_, 1);
v_fst_4839_ = lean_ctor_get(v_a_4834_, 0);
v_isSharedCheck_4865_ = !lean_is_exclusive(v_a_4834_);
if (v_isSharedCheck_4865_ == 0)
{
v___x_4841_ = v_a_4834_;
v_isShared_4842_ = v_isSharedCheck_4865_;
goto v_resetjp_4840_;
}
else
{
lean_inc(v_snd_4838_);
lean_inc(v_fst_4839_);
lean_dec(v_a_4834_);
v___x_4841_ = lean_box(0);
v_isShared_4842_ = v_isSharedCheck_4865_;
goto v_resetjp_4840_;
}
v_resetjp_4840_:
{
lean_object* v_stream_4843_; lean_object* v_nameMap_4844_; lean_object* v_levelMap_4845_; lean_object* v_exprMap_4846_; lean_object* v_recursorRuleMap_4847_; lean_object* v_constMap_4848_; lean_object* v_constOrder_4849_; lean_object* v___x_4851_; uint8_t v_isShared_4852_; uint8_t v_isSharedCheck_4864_; 
v_stream_4843_ = lean_ctor_get(v_snd_4838_, 0);
v_nameMap_4844_ = lean_ctor_get(v_snd_4838_, 1);
v_levelMap_4845_ = lean_ctor_get(v_snd_4838_, 2);
v_exprMap_4846_ = lean_ctor_get(v_snd_4838_, 3);
v_recursorRuleMap_4847_ = lean_ctor_get(v_snd_4838_, 4);
v_constMap_4848_ = lean_ctor_get(v_snd_4838_, 5);
v_constOrder_4849_ = lean_ctor_get(v_snd_4838_, 6);
v_isSharedCheck_4864_ = !lean_is_exclusive(v_snd_4838_);
if (v_isSharedCheck_4864_ == 0)
{
v___x_4851_ = v_snd_4838_;
v_isShared_4852_ = v_isSharedCheck_4864_;
goto v_resetjp_4850_;
}
else
{
lean_inc(v_constOrder_4849_);
lean_inc(v_constMap_4848_);
lean_inc(v_recursorRuleMap_4847_);
lean_inc(v_exprMap_4846_);
lean_inc(v_levelMap_4845_);
lean_inc(v_nameMap_4844_);
lean_inc(v_stream_4843_);
lean_dec(v_snd_4838_);
v___x_4851_ = lean_box(0);
v_isShared_4852_ = v_isSharedCheck_4864_;
goto v_resetjp_4850_;
}
v_resetjp_4850_:
{
lean_object* v___x_4853_; lean_object* v___x_4854_; lean_object* v___x_4856_; 
v___x_4853_ = lean_box(0);
v___x_4854_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_levelMap_4845_, v_a_4698_, v_fst_4839_);
if (v_isShared_4852_ == 0)
{
lean_ctor_set(v___x_4851_, 2, v___x_4854_);
v___x_4856_ = v___x_4851_;
goto v_reusejp_4855_;
}
else
{
lean_object* v_reuseFailAlloc_4863_; 
v_reuseFailAlloc_4863_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4863_, 0, v_stream_4843_);
lean_ctor_set(v_reuseFailAlloc_4863_, 1, v_nameMap_4844_);
lean_ctor_set(v_reuseFailAlloc_4863_, 2, v___x_4854_);
lean_ctor_set(v_reuseFailAlloc_4863_, 3, v_exprMap_4846_);
lean_ctor_set(v_reuseFailAlloc_4863_, 4, v_recursorRuleMap_4847_);
lean_ctor_set(v_reuseFailAlloc_4863_, 5, v_constMap_4848_);
lean_ctor_set(v_reuseFailAlloc_4863_, 6, v_constOrder_4849_);
v___x_4856_ = v_reuseFailAlloc_4863_;
goto v_reusejp_4855_;
}
v_reusejp_4855_:
{
lean_object* v___x_4858_; 
if (v_isShared_4842_ == 0)
{
lean_ctor_set(v___x_4841_, 1, v___x_4856_);
lean_ctor_set(v___x_4841_, 0, v___x_4853_);
v___x_4858_ = v___x_4841_;
goto v_reusejp_4857_;
}
else
{
lean_object* v_reuseFailAlloc_4862_; 
v_reuseFailAlloc_4862_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4862_, 0, v___x_4853_);
lean_ctor_set(v_reuseFailAlloc_4862_, 1, v___x_4856_);
v___x_4858_ = v_reuseFailAlloc_4862_;
goto v_reusejp_4857_;
}
v_reusejp_4857_:
{
lean_object* v___x_4860_; 
if (v_isShared_4837_ == 0)
{
lean_ctor_set(v___x_4836_, 0, v___x_4858_);
v___x_4860_ = v___x_4836_;
goto v_reusejp_4859_;
}
else
{
lean_object* v_reuseFailAlloc_4861_; 
v_reuseFailAlloc_4861_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4861_, 0, v___x_4858_);
v___x_4860_ = v_reuseFailAlloc_4861_;
goto v_reusejp_4859_;
}
v_reusejp_4859_:
{
return v___x_4860_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4867_; lean_object* v___x_4869_; uint8_t v_isShared_4870_; uint8_t v_isSharedCheck_4874_; 
lean_dec(v_a_4698_);
v_a_4867_ = lean_ctor_get(v___x_4833_, 0);
v_isSharedCheck_4874_ = !lean_is_exclusive(v___x_4833_);
if (v_isSharedCheck_4874_ == 0)
{
v___x_4869_ = v___x_4833_;
v_isShared_4870_ = v_isSharedCheck_4874_;
goto v_resetjp_4868_;
}
else
{
lean_inc(v_a_4867_);
lean_dec(v___x_4833_);
v___x_4869_ = lean_box(0);
v_isShared_4870_ = v_isSharedCheck_4874_;
goto v_resetjp_4868_;
}
v_resetjp_4868_:
{
lean_object* v___x_4872_; 
if (v_isShared_4870_ == 0)
{
v___x_4872_ = v___x_4869_;
goto v_reusejp_4871_;
}
else
{
lean_object* v_reuseFailAlloc_4873_; 
v_reuseFailAlloc_4873_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4873_, 0, v_a_4867_);
v___x_4872_ = v_reuseFailAlloc_4873_;
goto v_reusejp_4871_;
}
v_reusejp_4871_:
{
return v___x_4872_;
}
}
}
}
else
{
lean_dec(v_a_4698_);
lean_dec(v_snd_4697_);
lean_dec(v_tail_4695_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_mantissa_4688_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_exponent_4689_);
lean_dec(v_mantissa_4688_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec_ref(v_fst_4158_);
if (lean_obj_tag(v_snd_4159_) == 2)
{
lean_object* v_n_4875_; lean_object* v_mantissa_4876_; lean_object* v_exponent_4877_; lean_object* v_natZero_4878_; lean_object* v_intZero_4879_; uint8_t v_isNeg_4880_; 
v_n_4875_ = lean_ctor_get(v_snd_4159_, 0);
lean_inc_ref(v_n_4875_);
lean_dec_ref_known(v_snd_4159_, 1);
v_mantissa_4876_ = lean_ctor_get(v_n_4875_, 0);
lean_inc(v_mantissa_4876_);
v_exponent_4877_ = lean_ctor_get(v_n_4875_, 1);
lean_inc(v_exponent_4877_);
lean_dec_ref(v_n_4875_);
v_natZero_4878_ = lean_unsigned_to_nat(0u);
v_intZero_4879_ = lean_obj_once(&lp_proofEnvironment_Export_Parse_parseNameStr___closed__3, &lp_proofEnvironment_Export_Parse_parseNameStr___closed__3_once, _init_lp_proofEnvironment_Export_Parse_parseNameStr___closed__3);
v_isNeg_4880_ = lean_int_dec_lt(v_mantissa_4876_, v_intZero_4879_);
if (v_isNeg_4880_ == 0)
{
uint8_t v___x_4881_; 
v___x_4881_ = lean_nat_dec_eq(v_exponent_4877_, v_natZero_4878_);
lean_dec(v_exponent_4877_);
if (v___x_4881_ == 0)
{
lean_dec(v_mantissa_4876_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_tail_4160_) == 1)
{
lean_object* v_head_4882_; lean_object* v_tail_4883_; lean_object* v_fst_4884_; lean_object* v_snd_4885_; lean_object* v_a_4886_; lean_object* v___x_4887_; uint8_t v___x_4888_; 
v_head_4882_ = lean_ctor_get(v_tail_4160_, 0);
lean_inc(v_head_4882_);
v_tail_4883_ = lean_ctor_get(v_tail_4160_, 1);
lean_inc(v_tail_4883_);
lean_dec_ref_known(v_tail_4160_, 2);
v_fst_4884_ = lean_ctor_get(v_head_4882_, 0);
lean_inc(v_fst_4884_);
v_snd_4885_ = lean_ctor_get(v_head_4882_, 1);
lean_inc(v_snd_4885_);
lean_dec(v_head_4882_);
v_a_4886_ = lean_nat_abs(v_mantissa_4876_);
lean_dec(v_mantissa_4876_);
v___x_4887_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseNameStr___closed__4));
v___x_4888_ = lean_string_dec_eq(v_fst_4884_, v___x_4887_);
if (v___x_4888_ == 0)
{
lean_object* v___x_4889_; uint8_t v___x_4890_; 
v___x_4889_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseItem___closed__24));
v___x_4890_ = lean_string_dec_eq(v_fst_4884_, v___x_4889_);
lean_dec(v_fst_4884_);
if (v___x_4890_ == 0)
{
lean_dec(v_a_4886_);
lean_dec(v_snd_4885_);
lean_dec(v_tail_4883_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
else
{
if (lean_obj_tag(v_tail_4883_) == 0)
{
lean_object* v___x_4891_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4891_ = lp_proofEnvironment_Export_Parse_parseNameNum(v_snd_4885_, v_a_4130_);
lean_dec(v_snd_4885_);
if (lean_obj_tag(v___x_4891_) == 0)
{
lean_object* v_a_4892_; lean_object* v___x_4894_; uint8_t v_isShared_4895_; uint8_t v_isSharedCheck_4924_; 
v_a_4892_ = lean_ctor_get(v___x_4891_, 0);
v_isSharedCheck_4924_ = !lean_is_exclusive(v___x_4891_);
if (v_isSharedCheck_4924_ == 0)
{
v___x_4894_ = v___x_4891_;
v_isShared_4895_ = v_isSharedCheck_4924_;
goto v_resetjp_4893_;
}
else
{
lean_inc(v_a_4892_);
lean_dec(v___x_4891_);
v___x_4894_ = lean_box(0);
v_isShared_4895_ = v_isSharedCheck_4924_;
goto v_resetjp_4893_;
}
v_resetjp_4893_:
{
lean_object* v_snd_4896_; lean_object* v_fst_4897_; lean_object* v___x_4899_; uint8_t v_isShared_4900_; uint8_t v_isSharedCheck_4923_; 
v_snd_4896_ = lean_ctor_get(v_a_4892_, 1);
v_fst_4897_ = lean_ctor_get(v_a_4892_, 0);
v_isSharedCheck_4923_ = !lean_is_exclusive(v_a_4892_);
if (v_isSharedCheck_4923_ == 0)
{
v___x_4899_ = v_a_4892_;
v_isShared_4900_ = v_isSharedCheck_4923_;
goto v_resetjp_4898_;
}
else
{
lean_inc(v_snd_4896_);
lean_inc(v_fst_4897_);
lean_dec(v_a_4892_);
v___x_4899_ = lean_box(0);
v_isShared_4900_ = v_isSharedCheck_4923_;
goto v_resetjp_4898_;
}
v_resetjp_4898_:
{
lean_object* v_stream_4901_; lean_object* v_nameMap_4902_; lean_object* v_levelMap_4903_; lean_object* v_exprMap_4904_; lean_object* v_recursorRuleMap_4905_; lean_object* v_constMap_4906_; lean_object* v_constOrder_4907_; lean_object* v___x_4909_; uint8_t v_isShared_4910_; uint8_t v_isSharedCheck_4922_; 
v_stream_4901_ = lean_ctor_get(v_snd_4896_, 0);
v_nameMap_4902_ = lean_ctor_get(v_snd_4896_, 1);
v_levelMap_4903_ = lean_ctor_get(v_snd_4896_, 2);
v_exprMap_4904_ = lean_ctor_get(v_snd_4896_, 3);
v_recursorRuleMap_4905_ = lean_ctor_get(v_snd_4896_, 4);
v_constMap_4906_ = lean_ctor_get(v_snd_4896_, 5);
v_constOrder_4907_ = lean_ctor_get(v_snd_4896_, 6);
v_isSharedCheck_4922_ = !lean_is_exclusive(v_snd_4896_);
if (v_isSharedCheck_4922_ == 0)
{
v___x_4909_ = v_snd_4896_;
v_isShared_4910_ = v_isSharedCheck_4922_;
goto v_resetjp_4908_;
}
else
{
lean_inc(v_constOrder_4907_);
lean_inc(v_constMap_4906_);
lean_inc(v_recursorRuleMap_4905_);
lean_inc(v_exprMap_4904_);
lean_inc(v_levelMap_4903_);
lean_inc(v_nameMap_4902_);
lean_inc(v_stream_4901_);
lean_dec(v_snd_4896_);
v___x_4909_ = lean_box(0);
v_isShared_4910_ = v_isSharedCheck_4922_;
goto v_resetjp_4908_;
}
v_resetjp_4908_:
{
lean_object* v___x_4911_; lean_object* v___x_4912_; lean_object* v___x_4914_; 
v___x_4911_ = lean_box(0);
v___x_4912_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_nameMap_4902_, v_a_4886_, v_fst_4897_);
if (v_isShared_4910_ == 0)
{
lean_ctor_set(v___x_4909_, 1, v___x_4912_);
v___x_4914_ = v___x_4909_;
goto v_reusejp_4913_;
}
else
{
lean_object* v_reuseFailAlloc_4921_; 
v_reuseFailAlloc_4921_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4921_, 0, v_stream_4901_);
lean_ctor_set(v_reuseFailAlloc_4921_, 1, v___x_4912_);
lean_ctor_set(v_reuseFailAlloc_4921_, 2, v_levelMap_4903_);
lean_ctor_set(v_reuseFailAlloc_4921_, 3, v_exprMap_4904_);
lean_ctor_set(v_reuseFailAlloc_4921_, 4, v_recursorRuleMap_4905_);
lean_ctor_set(v_reuseFailAlloc_4921_, 5, v_constMap_4906_);
lean_ctor_set(v_reuseFailAlloc_4921_, 6, v_constOrder_4907_);
v___x_4914_ = v_reuseFailAlloc_4921_;
goto v_reusejp_4913_;
}
v_reusejp_4913_:
{
lean_object* v___x_4916_; 
if (v_isShared_4900_ == 0)
{
lean_ctor_set(v___x_4899_, 1, v___x_4914_);
lean_ctor_set(v___x_4899_, 0, v___x_4911_);
v___x_4916_ = v___x_4899_;
goto v_reusejp_4915_;
}
else
{
lean_object* v_reuseFailAlloc_4920_; 
v_reuseFailAlloc_4920_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4920_, 0, v___x_4911_);
lean_ctor_set(v_reuseFailAlloc_4920_, 1, v___x_4914_);
v___x_4916_ = v_reuseFailAlloc_4920_;
goto v_reusejp_4915_;
}
v_reusejp_4915_:
{
lean_object* v___x_4918_; 
if (v_isShared_4895_ == 0)
{
lean_ctor_set(v___x_4894_, 0, v___x_4916_);
v___x_4918_ = v___x_4894_;
goto v_reusejp_4917_;
}
else
{
lean_object* v_reuseFailAlloc_4919_; 
v_reuseFailAlloc_4919_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4919_, 0, v___x_4916_);
v___x_4918_ = v_reuseFailAlloc_4919_;
goto v_reusejp_4917_;
}
v_reusejp_4917_:
{
return v___x_4918_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4925_; lean_object* v___x_4927_; uint8_t v_isShared_4928_; uint8_t v_isSharedCheck_4932_; 
lean_dec(v_a_4886_);
v_a_4925_ = lean_ctor_get(v___x_4891_, 0);
v_isSharedCheck_4932_ = !lean_is_exclusive(v___x_4891_);
if (v_isSharedCheck_4932_ == 0)
{
v___x_4927_ = v___x_4891_;
v_isShared_4928_ = v_isSharedCheck_4932_;
goto v_resetjp_4926_;
}
else
{
lean_inc(v_a_4925_);
lean_dec(v___x_4891_);
v___x_4927_ = lean_box(0);
v_isShared_4928_ = v_isSharedCheck_4932_;
goto v_resetjp_4926_;
}
v_resetjp_4926_:
{
lean_object* v___x_4930_; 
if (v_isShared_4928_ == 0)
{
v___x_4930_ = v___x_4927_;
goto v_reusejp_4929_;
}
else
{
lean_object* v_reuseFailAlloc_4931_; 
v_reuseFailAlloc_4931_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4931_, 0, v_a_4925_);
v___x_4930_ = v_reuseFailAlloc_4931_;
goto v_reusejp_4929_;
}
v_reusejp_4929_:
{
return v___x_4930_;
}
}
}
}
else
{
lean_dec(v_a_4886_);
lean_dec(v_snd_4885_);
lean_dec(v_tail_4883_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_fst_4884_);
if (lean_obj_tag(v_tail_4883_) == 0)
{
lean_object* v___x_4933_; 
lean_del_object(v___x_4143_);
lean_dec(v_kvPairs_4141_);
lean_del_object(v___x_4139_);
v___x_4933_ = lp_proofEnvironment_Export_Parse_parseNameStr(v_snd_4885_, v_a_4130_);
lean_dec(v_snd_4885_);
if (lean_obj_tag(v___x_4933_) == 0)
{
lean_object* v_a_4934_; lean_object* v___x_4936_; uint8_t v_isShared_4937_; uint8_t v_isSharedCheck_4966_; 
v_a_4934_ = lean_ctor_get(v___x_4933_, 0);
v_isSharedCheck_4966_ = !lean_is_exclusive(v___x_4933_);
if (v_isSharedCheck_4966_ == 0)
{
v___x_4936_ = v___x_4933_;
v_isShared_4937_ = v_isSharedCheck_4966_;
goto v_resetjp_4935_;
}
else
{
lean_inc(v_a_4934_);
lean_dec(v___x_4933_);
v___x_4936_ = lean_box(0);
v_isShared_4937_ = v_isSharedCheck_4966_;
goto v_resetjp_4935_;
}
v_resetjp_4935_:
{
lean_object* v_snd_4938_; lean_object* v_fst_4939_; lean_object* v___x_4941_; uint8_t v_isShared_4942_; uint8_t v_isSharedCheck_4965_; 
v_snd_4938_ = lean_ctor_get(v_a_4934_, 1);
v_fst_4939_ = lean_ctor_get(v_a_4934_, 0);
v_isSharedCheck_4965_ = !lean_is_exclusive(v_a_4934_);
if (v_isSharedCheck_4965_ == 0)
{
v___x_4941_ = v_a_4934_;
v_isShared_4942_ = v_isSharedCheck_4965_;
goto v_resetjp_4940_;
}
else
{
lean_inc(v_snd_4938_);
lean_inc(v_fst_4939_);
lean_dec(v_a_4934_);
v___x_4941_ = lean_box(0);
v_isShared_4942_ = v_isSharedCheck_4965_;
goto v_resetjp_4940_;
}
v_resetjp_4940_:
{
lean_object* v_stream_4943_; lean_object* v_nameMap_4944_; lean_object* v_levelMap_4945_; lean_object* v_exprMap_4946_; lean_object* v_recursorRuleMap_4947_; lean_object* v_constMap_4948_; lean_object* v_constOrder_4949_; lean_object* v___x_4951_; uint8_t v_isShared_4952_; uint8_t v_isSharedCheck_4964_; 
v_stream_4943_ = lean_ctor_get(v_snd_4938_, 0);
v_nameMap_4944_ = lean_ctor_get(v_snd_4938_, 1);
v_levelMap_4945_ = lean_ctor_get(v_snd_4938_, 2);
v_exprMap_4946_ = lean_ctor_get(v_snd_4938_, 3);
v_recursorRuleMap_4947_ = lean_ctor_get(v_snd_4938_, 4);
v_constMap_4948_ = lean_ctor_get(v_snd_4938_, 5);
v_constOrder_4949_ = lean_ctor_get(v_snd_4938_, 6);
v_isSharedCheck_4964_ = !lean_is_exclusive(v_snd_4938_);
if (v_isSharedCheck_4964_ == 0)
{
v___x_4951_ = v_snd_4938_;
v_isShared_4952_ = v_isSharedCheck_4964_;
goto v_resetjp_4950_;
}
else
{
lean_inc(v_constOrder_4949_);
lean_inc(v_constMap_4948_);
lean_inc(v_recursorRuleMap_4947_);
lean_inc(v_exprMap_4946_);
lean_inc(v_levelMap_4945_);
lean_inc(v_nameMap_4944_);
lean_inc(v_stream_4943_);
lean_dec(v_snd_4938_);
v___x_4951_ = lean_box(0);
v_isShared_4952_ = v_isSharedCheck_4964_;
goto v_resetjp_4950_;
}
v_resetjp_4950_:
{
lean_object* v___x_4953_; lean_object* v___x_4954_; lean_object* v___x_4956_; 
v___x_4953_ = lean_box(0);
v___x_4954_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_insert___at___00Export_Parse_M_run_spec__0___redArg(v_nameMap_4944_, v_a_4886_, v_fst_4939_);
if (v_isShared_4952_ == 0)
{
lean_ctor_set(v___x_4951_, 1, v___x_4954_);
v___x_4956_ = v___x_4951_;
goto v_reusejp_4955_;
}
else
{
lean_object* v_reuseFailAlloc_4963_; 
v_reuseFailAlloc_4963_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_4963_, 0, v_stream_4943_);
lean_ctor_set(v_reuseFailAlloc_4963_, 1, v___x_4954_);
lean_ctor_set(v_reuseFailAlloc_4963_, 2, v_levelMap_4945_);
lean_ctor_set(v_reuseFailAlloc_4963_, 3, v_exprMap_4946_);
lean_ctor_set(v_reuseFailAlloc_4963_, 4, v_recursorRuleMap_4947_);
lean_ctor_set(v_reuseFailAlloc_4963_, 5, v_constMap_4948_);
lean_ctor_set(v_reuseFailAlloc_4963_, 6, v_constOrder_4949_);
v___x_4956_ = v_reuseFailAlloc_4963_;
goto v_reusejp_4955_;
}
v_reusejp_4955_:
{
lean_object* v___x_4958_; 
if (v_isShared_4942_ == 0)
{
lean_ctor_set(v___x_4941_, 1, v___x_4956_);
lean_ctor_set(v___x_4941_, 0, v___x_4953_);
v___x_4958_ = v___x_4941_;
goto v_reusejp_4957_;
}
else
{
lean_object* v_reuseFailAlloc_4962_; 
v_reuseFailAlloc_4962_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4962_, 0, v___x_4953_);
lean_ctor_set(v_reuseFailAlloc_4962_, 1, v___x_4956_);
v___x_4958_ = v_reuseFailAlloc_4962_;
goto v_reusejp_4957_;
}
v_reusejp_4957_:
{
lean_object* v___x_4960_; 
if (v_isShared_4937_ == 0)
{
lean_ctor_set(v___x_4936_, 0, v___x_4958_);
v___x_4960_ = v___x_4936_;
goto v_reusejp_4959_;
}
else
{
lean_object* v_reuseFailAlloc_4961_; 
v_reuseFailAlloc_4961_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4961_, 0, v___x_4958_);
v___x_4960_ = v_reuseFailAlloc_4961_;
goto v_reusejp_4959_;
}
v_reusejp_4959_:
{
return v___x_4960_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4967_; lean_object* v___x_4969_; uint8_t v_isShared_4970_; uint8_t v_isSharedCheck_4974_; 
lean_dec(v_a_4886_);
v_a_4967_ = lean_ctor_get(v___x_4933_, 0);
v_isSharedCheck_4974_ = !lean_is_exclusive(v___x_4933_);
if (v_isSharedCheck_4974_ == 0)
{
v___x_4969_ = v___x_4933_;
v_isShared_4970_ = v_isSharedCheck_4974_;
goto v_resetjp_4968_;
}
else
{
lean_inc(v_a_4967_);
lean_dec(v___x_4933_);
v___x_4969_ = lean_box(0);
v_isShared_4970_ = v_isSharedCheck_4974_;
goto v_resetjp_4968_;
}
v_resetjp_4968_:
{
lean_object* v___x_4972_; 
if (v_isShared_4970_ == 0)
{
v___x_4972_ = v___x_4969_;
goto v_reusejp_4971_;
}
else
{
lean_object* v_reuseFailAlloc_4973_; 
v_reuseFailAlloc_4973_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4973_, 0, v_a_4967_);
v___x_4972_ = v_reuseFailAlloc_4973_;
goto v_reusejp_4971_;
}
v_reusejp_4971_:
{
return v___x_4972_;
}
}
}
}
else
{
lean_dec(v_a_4886_);
lean_dec(v_snd_4885_);
lean_dec(v_tail_4883_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_mantissa_4876_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
else
{
lean_dec(v_exponent_4877_);
lean_dec(v_mantissa_4876_);
lean_dec(v_tail_4160_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
else
{
lean_dec(v_tail_4160_);
lean_dec(v_snd_4159_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
v___jp_4975_:
{
if (lean_obj_tag(v___y_4976_) == 1)
{
lean_object* v_head_4977_; lean_object* v_tail_4978_; lean_object* v_fst_4979_; lean_object* v_snd_4980_; 
v_head_4977_ = lean_ctor_get(v___y_4976_, 0);
lean_inc(v_head_4977_);
v_tail_4978_ = lean_ctor_get(v___y_4976_, 1);
lean_inc(v_tail_4978_);
lean_dec_ref_known(v___y_4976_, 2);
v_fst_4979_ = lean_ctor_get(v_head_4977_, 0);
lean_inc(v_fst_4979_);
v_snd_4980_ = lean_ctor_get(v_head_4977_, 1);
lean_inc(v_snd_4980_);
lean_dec(v_head_4977_);
v_fst_4158_ = v_fst_4979_;
v_snd_4159_ = v_snd_4980_;
v_tail_4160_ = v_tail_4978_;
goto v___jp_4157_;
}
else
{
lean_dec(v___y_4976_);
lean_dec_ref(v_a_4130_);
goto v___jp_4145_;
}
}
}
}
else
{
lean_del_object(v___x_4139_);
lean_dec(v_a_4137_);
lean_dec_ref(v_a_4130_);
goto v___jp_4132_;
}
}
}
else
{
lean_dec_ref(v___x_4136_);
lean_dec_ref(v_a_4130_);
goto v___jp_4132_;
}
v___jp_4132_:
{
lean_object* v___x_4133_; lean_object* v___x_4134_; 
v___x_4133_ = ((lean_object*)(lp_proofEnvironment_Export_Parse_parseJsonObj___closed__1));
v___x_4134_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4134_, 0, v___x_4133_);
return v___x_4134_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItem___boxed(lean_object* v_line_5011_, lean_object* v_a_5012_, lean_object* v_a_5013_){
_start:
{
lean_object* v_res_5014_; 
v_res_5014_ = lp_proofEnvironment_Export_Parse_parseItem(v_line_5011_, v_a_5012_);
return v_res_5014_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems_go(lean_object* v_a_5015_){
_start:
{
lean_object* v_stream_5017_; lean_object* v_getLine_5018_; lean_object* v___x_5019_; 
v_stream_5017_ = lean_ctor_get(v_a_5015_, 0);
v_getLine_5018_ = lean_ctor_get(v_stream_5017_, 3);
lean_inc_ref(v_getLine_5018_);
v___x_5019_ = lean_apply_1(v_getLine_5018_, lean_box(0));
if (lean_obj_tag(v___x_5019_) == 0)
{
lean_object* v_a_5020_; lean_object* v___x_5022_; uint8_t v_isShared_5023_; uint8_t v_isSharedCheck_5036_; 
v_a_5020_ = lean_ctor_get(v___x_5019_, 0);
v_isSharedCheck_5036_ = !lean_is_exclusive(v___x_5019_);
if (v_isSharedCheck_5036_ == 0)
{
v___x_5022_ = v___x_5019_;
v_isShared_5023_ = v_isSharedCheck_5036_;
goto v_resetjp_5021_;
}
else
{
lean_inc(v_a_5020_);
lean_dec(v___x_5019_);
v___x_5022_ = lean_box(0);
v_isShared_5023_ = v_isSharedCheck_5036_;
goto v_resetjp_5021_;
}
v_resetjp_5021_:
{
lean_object* v___x_5024_; lean_object* v___x_5025_; uint8_t v___x_5026_; 
v___x_5024_ = lean_string_utf8_byte_size(v_a_5020_);
v___x_5025_ = lean_unsigned_to_nat(0u);
v___x_5026_ = lean_nat_dec_eq(v___x_5024_, v___x_5025_);
if (v___x_5026_ == 0)
{
lean_object* v___x_5027_; 
lean_del_object(v___x_5022_);
v___x_5027_ = lp_proofEnvironment_Export_Parse_parseItem(v_a_5020_, v_a_5015_);
if (lean_obj_tag(v___x_5027_) == 0)
{
lean_object* v_a_5028_; lean_object* v_snd_5029_; 
v_a_5028_ = lean_ctor_get(v___x_5027_, 0);
lean_inc(v_a_5028_);
lean_dec_ref_known(v___x_5027_, 1);
v_snd_5029_ = lean_ctor_get(v_a_5028_, 1);
lean_inc(v_snd_5029_);
lean_dec(v_a_5028_);
v_a_5015_ = v_snd_5029_;
goto _start;
}
else
{
return v___x_5027_;
}
}
else
{
lean_object* v___x_5031_; lean_object* v___x_5032_; lean_object* v___x_5034_; 
lean_dec(v_a_5020_);
v___x_5031_ = lean_box(0);
v___x_5032_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5032_, 0, v___x_5031_);
lean_ctor_set(v___x_5032_, 1, v_a_5015_);
if (v_isShared_5023_ == 0)
{
lean_ctor_set(v___x_5022_, 0, v___x_5032_);
v___x_5034_ = v___x_5022_;
goto v_reusejp_5033_;
}
else
{
lean_object* v_reuseFailAlloc_5035_; 
v_reuseFailAlloc_5035_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5035_, 0, v___x_5032_);
v___x_5034_ = v_reuseFailAlloc_5035_;
goto v_reusejp_5033_;
}
v_reusejp_5033_:
{
return v___x_5034_;
}
}
}
}
else
{
lean_object* v_a_5037_; lean_object* v___x_5039_; uint8_t v_isShared_5040_; uint8_t v_isSharedCheck_5044_; 
lean_dec_ref(v_a_5015_);
v_a_5037_ = lean_ctor_get(v___x_5019_, 0);
v_isSharedCheck_5044_ = !lean_is_exclusive(v___x_5019_);
if (v_isSharedCheck_5044_ == 0)
{
v___x_5039_ = v___x_5019_;
v_isShared_5040_ = v_isSharedCheck_5044_;
goto v_resetjp_5038_;
}
else
{
lean_inc(v_a_5037_);
lean_dec(v___x_5019_);
v___x_5039_ = lean_box(0);
v_isShared_5040_ = v_isSharedCheck_5044_;
goto v_resetjp_5038_;
}
v_resetjp_5038_:
{
lean_object* v___x_5042_; 
if (v_isShared_5040_ == 0)
{
v___x_5042_ = v___x_5039_;
goto v_reusejp_5041_;
}
else
{
lean_object* v_reuseFailAlloc_5043_; 
v_reuseFailAlloc_5043_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5043_, 0, v_a_5037_);
v___x_5042_ = v_reuseFailAlloc_5043_;
goto v_reusejp_5041_;
}
v_reusejp_5041_:
{
return v___x_5042_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems_go___boxed(lean_object* v_a_5045_, lean_object* v_a_5046_){
_start:
{
lean_object* v_res_5047_; 
v_res_5047_ = lp_proofEnvironment_Export_Parse_parseItems_go(v_a_5045_);
return v_res_5047_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems(lean_object* v_a_5048_){
_start:
{
lean_object* v___x_5050_; 
v___x_5050_ = lp_proofEnvironment_Export_Parse_parseItems_go(v_a_5048_);
return v___x_5050_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseItems___boxed(lean_object* v_a_5051_, lean_object* v_a_5052_){
_start:
{
lean_object* v_res_5053_; 
v_res_5053_ = lp_proofEnvironment_Export_Parse_parseItems(v_a_5051_);
return v_res_5053_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseMdata(lean_object* v_a_5054_){
_start:
{
lean_object* v_stream_5056_; lean_object* v_getLine_5057_; lean_object* v___x_5058_; 
v_stream_5056_ = lean_ctor_get(v_a_5054_, 0);
v_getLine_5057_ = lean_ctor_get(v_stream_5056_, 3);
lean_inc_ref(v_getLine_5057_);
v___x_5058_ = lean_apply_1(v_getLine_5057_, lean_box(0));
if (lean_obj_tag(v___x_5058_) == 0)
{
lean_object* v___x_5060_; uint8_t v_isShared_5061_; uint8_t v_isSharedCheck_5067_; 
v_isSharedCheck_5067_ = !lean_is_exclusive(v___x_5058_);
if (v_isSharedCheck_5067_ == 0)
{
lean_object* v_unused_5068_; 
v_unused_5068_ = lean_ctor_get(v___x_5058_, 0);
lean_dec(v_unused_5068_);
v___x_5060_ = v___x_5058_;
v_isShared_5061_ = v_isSharedCheck_5067_;
goto v_resetjp_5059_;
}
else
{
lean_dec(v___x_5058_);
v___x_5060_ = lean_box(0);
v_isShared_5061_ = v_isSharedCheck_5067_;
goto v_resetjp_5059_;
}
v_resetjp_5059_:
{
lean_object* v___x_5062_; lean_object* v___x_5063_; lean_object* v___x_5065_; 
v___x_5062_ = lean_box(0);
v___x_5063_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5063_, 0, v___x_5062_);
lean_ctor_set(v___x_5063_, 1, v_a_5054_);
if (v_isShared_5061_ == 0)
{
lean_ctor_set(v___x_5060_, 0, v___x_5063_);
v___x_5065_ = v___x_5060_;
goto v_reusejp_5064_;
}
else
{
lean_object* v_reuseFailAlloc_5066_; 
v_reuseFailAlloc_5066_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5066_, 0, v___x_5063_);
v___x_5065_ = v_reuseFailAlloc_5066_;
goto v_reusejp_5064_;
}
v_reusejp_5064_:
{
return v___x_5065_;
}
}
}
else
{
lean_object* v_a_5069_; lean_object* v___x_5071_; uint8_t v_isShared_5072_; uint8_t v_isSharedCheck_5076_; 
lean_dec_ref(v_a_5054_);
v_a_5069_ = lean_ctor_get(v___x_5058_, 0);
v_isSharedCheck_5076_ = !lean_is_exclusive(v___x_5058_);
if (v_isSharedCheck_5076_ == 0)
{
v___x_5071_ = v___x_5058_;
v_isShared_5072_ = v_isSharedCheck_5076_;
goto v_resetjp_5070_;
}
else
{
lean_inc(v_a_5069_);
lean_dec(v___x_5058_);
v___x_5071_ = lean_box(0);
v_isShared_5072_ = v_isSharedCheck_5076_;
goto v_resetjp_5070_;
}
v_resetjp_5070_:
{
lean_object* v___x_5074_; 
if (v_isShared_5072_ == 0)
{
v___x_5074_ = v___x_5071_;
goto v_reusejp_5073_;
}
else
{
lean_object* v_reuseFailAlloc_5075_; 
v_reuseFailAlloc_5075_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5075_, 0, v_a_5069_);
v___x_5074_ = v_reuseFailAlloc_5075_;
goto v_reusejp_5073_;
}
v_reusejp_5073_:
{
return v___x_5074_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseMdata___boxed(lean_object* v_a_5077_, lean_object* v_a_5078_){
_start:
{
lean_object* v_res_5079_; 
v_res_5079_ = lp_proofEnvironment_Export_Parse_parseMdata(v_a_5077_);
return v_res_5079_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseFile(lean_object* v_a_5080_){
_start:
{
lean_object* v___x_5082_; 
v___x_5082_ = lp_proofEnvironment_Export_Parse_parseMdata(v_a_5080_);
if (lean_obj_tag(v___x_5082_) == 0)
{
lean_object* v_a_5083_; lean_object* v_snd_5084_; lean_object* v___x_5085_; 
v_a_5083_ = lean_ctor_get(v___x_5082_, 0);
lean_inc(v_a_5083_);
lean_dec_ref_known(v___x_5082_, 1);
v_snd_5084_ = lean_ctor_get(v_a_5083_, 1);
lean_inc(v_snd_5084_);
lean_dec(v_a_5083_);
v___x_5085_ = lp_proofEnvironment_Export_Parse_parseItems_go(v_snd_5084_);
return v___x_5085_;
}
else
{
return v___x_5082_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_Parse_parseFile___boxed(lean_object* v_a_5086_, lean_object* v_a_5087_){
_start:
{
lean_object* v_res_5088_; 
v_res_5088_ = lp_proofEnvironment_Export_Parse_parseFile(v_a_5086_);
return v_res_5088_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_parseStream(lean_object* v_stream_5089_){
_start:
{
lean_object* v___x_5091_; lean_object* v___x_5092_; 
v___x_5091_ = lean_alloc_closure((void*)(lp_proofEnvironment_Export_Parse_parseFile___boxed), 2, 0);
v___x_5092_ = lp_proofEnvironment_Export_Parse_M_run___redArg(v___x_5091_, v_stream_5089_);
if (lean_obj_tag(v___x_5092_) == 0)
{
lean_object* v_a_5093_; lean_object* v___x_5095_; uint8_t v_isShared_5096_; uint8_t v_isSharedCheck_5111_; 
v_a_5093_ = lean_ctor_get(v___x_5092_, 0);
v_isSharedCheck_5111_ = !lean_is_exclusive(v___x_5092_);
if (v_isSharedCheck_5111_ == 0)
{
v___x_5095_ = v___x_5092_;
v_isShared_5096_ = v_isSharedCheck_5111_;
goto v_resetjp_5094_;
}
else
{
lean_inc(v_a_5093_);
lean_dec(v___x_5092_);
v___x_5095_ = lean_box(0);
v_isShared_5096_ = v_isSharedCheck_5111_;
goto v_resetjp_5094_;
}
v_resetjp_5094_:
{
lean_object* v_snd_5097_; lean_object* v___x_5099_; uint8_t v_isShared_5100_; uint8_t v_isSharedCheck_5109_; 
v_snd_5097_ = lean_ctor_get(v_a_5093_, 1);
v_isSharedCheck_5109_ = !lean_is_exclusive(v_a_5093_);
if (v_isSharedCheck_5109_ == 0)
{
lean_object* v_unused_5110_; 
v_unused_5110_ = lean_ctor_get(v_a_5093_, 0);
lean_dec(v_unused_5110_);
v___x_5099_ = v_a_5093_;
v_isShared_5100_ = v_isSharedCheck_5109_;
goto v_resetjp_5098_;
}
else
{
lean_inc(v_snd_5097_);
lean_dec(v_a_5093_);
v___x_5099_ = lean_box(0);
v_isShared_5100_ = v_isSharedCheck_5109_;
goto v_resetjp_5098_;
}
v_resetjp_5098_:
{
lean_object* v_constMap_5101_; lean_object* v_constOrder_5102_; lean_object* v___x_5104_; 
v_constMap_5101_ = lean_ctor_get(v_snd_5097_, 5);
lean_inc_ref(v_constMap_5101_);
v_constOrder_5102_ = lean_ctor_get(v_snd_5097_, 6);
lean_inc_ref(v_constOrder_5102_);
lean_dec(v_snd_5097_);
if (v_isShared_5100_ == 0)
{
lean_ctor_set(v___x_5099_, 1, v_constOrder_5102_);
lean_ctor_set(v___x_5099_, 0, v_constMap_5101_);
v___x_5104_ = v___x_5099_;
goto v_reusejp_5103_;
}
else
{
lean_object* v_reuseFailAlloc_5108_; 
v_reuseFailAlloc_5108_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5108_, 0, v_constMap_5101_);
lean_ctor_set(v_reuseFailAlloc_5108_, 1, v_constOrder_5102_);
v___x_5104_ = v_reuseFailAlloc_5108_;
goto v_reusejp_5103_;
}
v_reusejp_5103_:
{
lean_object* v___x_5106_; 
if (v_isShared_5096_ == 0)
{
lean_ctor_set(v___x_5095_, 0, v___x_5104_);
v___x_5106_ = v___x_5095_;
goto v_reusejp_5105_;
}
else
{
lean_object* v_reuseFailAlloc_5107_; 
v_reuseFailAlloc_5107_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5107_, 0, v___x_5104_);
v___x_5106_ = v_reuseFailAlloc_5107_;
goto v_reusejp_5105_;
}
v_reusejp_5105_:
{
return v___x_5106_;
}
}
}
}
}
else
{
lean_object* v_a_5112_; lean_object* v___x_5114_; uint8_t v_isShared_5115_; uint8_t v_isSharedCheck_5119_; 
v_a_5112_ = lean_ctor_get(v___x_5092_, 0);
v_isSharedCheck_5119_ = !lean_is_exclusive(v___x_5092_);
if (v_isSharedCheck_5119_ == 0)
{
v___x_5114_ = v___x_5092_;
v_isShared_5115_ = v_isSharedCheck_5119_;
goto v_resetjp_5113_;
}
else
{
lean_inc(v_a_5112_);
lean_dec(v___x_5092_);
v___x_5114_ = lean_box(0);
v_isShared_5115_ = v_isSharedCheck_5119_;
goto v_resetjp_5113_;
}
v_resetjp_5113_:
{
lean_object* v___x_5117_; 
if (v_isShared_5115_ == 0)
{
v___x_5117_ = v___x_5114_;
goto v_reusejp_5116_;
}
else
{
lean_object* v_reuseFailAlloc_5118_; 
v_reuseFailAlloc_5118_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5118_, 0, v_a_5112_);
v___x_5117_ = v_reuseFailAlloc_5118_;
goto v_reusejp_5116_;
}
v_reusejp_5116_:
{
return v___x_5117_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Export_parseStream___boxed(lean_object* v_stream_5120_, lean_object* v_a_5121_){
_start:
{
lean_object* v_res_5122_; 
v_res_5122_ = lp_proofEnvironment_Export_parseStream(v_stream_5120_);
return v_res_5122_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Std_Data_HashMap(uint8_t builtin);
lean_object* initialize_Lean_Declaration(uint8_t builtin);
lean_object* initialize_Std_Internal_Parsec_String(uint8_t builtin);
lean_object* initialize_Lean_Data_Json_Parser(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_Export_Parse(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std_Data_HashMap(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Declaration(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std_Internal_Parsec_String(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Data_Json_Parser(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_proofEnvironment_Export_instInhabitedExportedEnv_default = _init_lp_proofEnvironment_Export_instInhabitedExportedEnv_default();
lean_mark_persistent(lp_proofEnvironment_Export_instInhabitedExportedEnv_default);
lp_proofEnvironment_Export_instInhabitedExportedEnv = _init_lp_proofEnvironment_Export_instInhabitedExportedEnv();
lean_mark_persistent(lp_proofEnvironment_Export_instInhabitedExportedEnv);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
