// Lean compiler output
// Module: CheckedExport
// Imports: public import Init public meta import Init public import Export
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instMonadEIO(lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__9(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_pure(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_bind(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_instInhabited(lean_object*);
lean_object* l_instInhabitedOfMonad___redArg(lean_object*, lean_object*);
lean_object* l_instInhabitedForall___redArg___lam__0___boxed(lean_object*, lean_object*);
lean_object* lean_panic_fn_borrowed(lean_object*, lean_object*);
lean_object* lean_environment_find(lean_object*, lean_object*);
lean_object* l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(lean_object*);
lean_object* l_Lean_NameHashSet_insert(lean_object*, lean_object*);
lean_object* l_Lean_Expr_getUsedConstants(lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Json_setObjVal_x21(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__1___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_List_mapTR_loop___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__12(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_simplifyResultingUniverse_simp_spec__2___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_AccLevelState_push_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__1___redArg(lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedExpr;
lean_object* l_Lean_Expr_app___override(lean_object*, lean_object*);
size_t lean_ptr_addr(lean_object*);
lean_object* l_Lean_Expr_lam___override(lean_object*, lean_object*, lean_object*, uint8_t);
uint8_t l_Lean_instBEqBinderInfo_beq(uint8_t, uint8_t);
lean_object* l_Lean_Expr_forallE___override(lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_letE___override(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_proj___override(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson(uint8_t);
lean_object* l_Lean_Name_mkStr1(lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Lean_KVMap_toJson(lean_object*);
lean_object* l_Lean_List_toJson___at___00Lean_Option_toJson___at___00Lean_Server_instToJsonIlean_toJson_spec__1_spec__1(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(lean_object*);
lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson(lean_object*);
lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson(uint8_t);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Lean_QuotKind_toJson(uint8_t);
uint8_t l_Lean_ConstantInfo_isUnsafe(lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__10___redArg(lean_object*, lean_object*);
lean_object* l___private_Lean_Data_Name_0__Lean_Name_quickCmpImpl___boxed(lean_object*, lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_union___at___00Std_DTreeMap_union_spec__0___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_inductiveVal_x21(lean_object*);
extern lean_object* l_Lean_versionString;
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instToStringString___lam__0___boxed(lean_object*);
lean_object* l_IO_println___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_githash;
lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_proofEnvironment_List_any___at___00initState_spec__0(lean_object*);
uint8_t lp_proofEnvironment_List_any___at___00initState_spec__1(lean_object*);
uint8_t lp_proofEnvironment_List_any___at___00initState_spec__2(lean_object*);
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__0;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__1;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__2;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__3;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__4;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__5;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__6;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__7;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__8;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__9;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__10;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__11;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_M_run___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___closed__12;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_CheckedExport_initState___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_CheckedExport_initState___lam__0___boxed, .m_arity = 6, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_CheckedExport_initState___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_initState___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_CheckedExport_getIdx___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instToStringString___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_CheckedExport_getIdx___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_getIdx___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "in"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__0_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "CheckedExport"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__1_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "CheckedExport.dumpName"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__2 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__2_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "unreachable code has been reached"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__3 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_dumpName___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__4;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "str"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__5 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__5_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "pre"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__6 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__6_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "num"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__7 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__7_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpName___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "i"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpName___closed__8 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpName___closed__8_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpName(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpName___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpLevel___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "il"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpLevel___closed__0_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpLevel___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "succ"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpLevel___closed__1_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpLevel___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "max"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__2 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpLevel___closed__2_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpLevel___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "imax"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__3 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpLevel___closed__3_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpLevel___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "param"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__4 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpLevel___closed__4_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpLevel___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "CheckedExport.dumpLevel"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__5 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpLevel___closed__5_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_dumpLevel___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___closed__6;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpLevel(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpUparams(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpUparams___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpNames(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpNames___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_removeMData___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "CheckedExport.removeMData"};
static const lean_object* lp_proofEnvironment_CheckedExport_removeMData___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_removeMData___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_removeMData___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_removeMData___closed__1;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_removeMData(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_removeMData___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "CheckedExport.dumpConstant"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0_value;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 129, .m_capacity = 129, .m_length = 128, .m_data = "assertion violation: ((!recVal.isUnsafe) || ( __do_lift._@.CheckedExport.2173241011._hygCtx._hyg.2133.0 ).exportUnsafe)\n        "};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__1 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__1_value;
static lean_once_cell_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__2;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "expected a `constantinfo.recinfo`."};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__3 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__4;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "Init.Data.Option.BasicAux"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__5 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__5_value;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "Option.get!"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__6 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__6_value;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "value is none"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__7 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__7_value;
static lean_once_cell_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8;
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 132, .m_capacity = 132, .m_length = 131, .m_data = "assertion violation: ((!ctorVal.isUnsafe) || ( __do_lift._@.CheckedExport.2173241011._hygCtx._hyg.1888.0 ).exportUnsafe)\n          "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__1;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Expected a `ConstantInfo.ctorInfo`."};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__3;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__13(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__14(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_CheckedExport_dumpExpr___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_dumpExpr___closed__0;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_dumpExpr___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_dumpExpr___closed__1;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "ie"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__0_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "bvar"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__1_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "sort"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__2 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__2_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "const"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__3 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "name"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "us"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__4 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__4_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "app"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__5 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__5_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "fn"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__6 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__6_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "arg"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__7 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__7_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lam"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__8 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__8_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "type"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "body"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__9 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__9_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "binderInfo"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__10 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__10_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "forallE"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__11 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__11_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "letE"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__12 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__12_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "value"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "nondep"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__14 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__14_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Nat"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "natVal"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__15 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__15_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "ofList"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__1_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "String"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__2_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__0_value),LEAN_SCALAR_PTR_LITERAL(6, 130, 56, 8, 41, 104, 134, 43)}};
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__2_value_aux_0),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__1_value),LEAN_SCALAR_PTR_LITERAL(118, 246, 177, 142, 179, 9, 199, 233)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__2 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__2_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ofNat"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__4 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__4_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Char"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__3 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__5_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__3_value),LEAN_SCALAR_PTR_LITERAL(18, 67, 155, 167, 151, 71, 146, 196)}};
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__5_value_aux_0),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__4_value),LEAN_SCALAR_PTR_LITERAL(27, 51, 10, 169, 25, 67, 44, 251)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__5 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "strVal"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__16 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__16_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "mdata"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__17 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__17_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "data"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__18 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__18_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "expr"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__19 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__19_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "proj"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__20 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__20_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "typeName"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__21 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__21_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "idx"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__22 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__22_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "struct"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__23 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__23_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 46, .m_capacity = 46, .m_length = 45, .m_data = "cannot export free variables or metavariables"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__25 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__25_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpExprAux___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "CheckedExport.dumpExprAux"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__24 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__24_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_dumpExprAux___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___closed__26;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExpr(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "levelParams"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numParams"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__5_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numIndices"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "all"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ctors"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numNested"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "isRec"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__4_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "isReflexive"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__5_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "isUnsafe"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15(size_t, size_t, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "induct"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "cidx"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__4_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numFields"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__6 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__6_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16(size_t, size_t, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "ctor"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__0_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "nfields"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__1_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "rhs"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__2 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpConstant_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numMotives"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numMinors"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "rules"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "k"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17(size_t, size_t, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inductive"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__0_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "types"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__1 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__1_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "recs"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__2 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__2_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "axiom"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__3 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__3_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "def"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__4 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__4_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "hints"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__5 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__5_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "safety"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__6 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__6_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "thm"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__7 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__7_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "opaque"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__8 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__8_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "Eq"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__9 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__9_value),LEAN_SCALAR_PTR_LITERAL(143, 37, 101, 248, 9, 246, 191, 223)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__10 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__10_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__17 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__17_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Quot"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__11 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__18_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__18_value_aux_0),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__17_value),LEAN_SCALAR_PTR_LITERAL(150, 213, 121, 152, 109, 27, 137, 60)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__18 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__18_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__18_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__19 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__19_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__15 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__16_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__16_value_aux_0),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__15_value),LEAN_SCALAR_PTR_LITERAL(91, 125, 38, 34, 222, 200, 201, 80)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__16 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__16_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__16_value),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__19_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__20 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__20_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "mk"};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__13 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__14_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__14_value_aux_0),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__13_value),LEAN_SCALAR_PTR_LITERAL(255, 113, 137, 82, 82, 132, 58, 248)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__14 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__14_value),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__20_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__21 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__21_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__12 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__12_value),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__21_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__22 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__22_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "Constant "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = " not found in environment."};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__3_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__4_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "quot"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__5 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__5_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "kind"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__6 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__6_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__23 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__23_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__23_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__24 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__24_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_dumpConstant___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__23_value),((lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__24_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___closed__25 = (const lean_object*)&lp_proofEnvironment_CheckedExport_dumpConstant___closed__25_value;
static const lean_closure_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l___private_Lean_Data_Name_0__Lean_Name_quickCmpImpl___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 367, .m_capacity = 367, .m_length = 366, .m_data = "assertion violation: ctorVals.size == 0\n\n    /- We dump the constructor dependencies (which will not include the inductives in this block since we've\n    added the names to `visitedConstants`) before actually outputting anything in this inductive block to\n    ensure e.g. the `LT` in `Fin.mk` is dumped before this inductive block appears in the export file. -/\n    "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__1_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__2;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 124, .m_capacity = 124, .m_length = 123, .m_data = "assertion violation: ((!val.isUnsafe) || ( __do_lift._@.CheckedExport.2173241011._hygCtx._hyg.1812.0 ).exportUnsafe)\n      "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__4;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__11(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpConstant_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__14___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExpr___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "version"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__0 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__1;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__2;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "githash"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__3 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__4;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__5;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__6;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__7;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__8;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "lean4export"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__9 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__9_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__10 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0_value),((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__10_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__11 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__11_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "3.1.0"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__12 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__12_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__13 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__0_value),((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__13_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__14 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__14_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__15 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__11_value),((lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__15_value)}};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__16 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__16_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__17;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__18;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "meta"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__19 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__19_value;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "exporter"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__20 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__20_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__21_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__21;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lean"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__22 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__22_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__23;
static const lean_string_object lp_proofEnvironment_CheckedExport_exportMetadata___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "format"};
static const lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__24 = (const lean_object*)&lp_proofEnvironment_CheckedExport_exportMetadata___closed__24_value;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__25;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__26;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__27;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__28;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__29;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__30;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__31;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_exportMetadata___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_exportMetadata___closed__32;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_exportMetadata;
static lean_once_cell_t lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_1_ = lean_box(0);
v___x_2_ = lean_unsigned_to_nat(524288u);
v___x_3_ = lean_mk_array(v___x_2_, v___x_1_);
return v___x_3_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__1(void){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__0, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__0_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__0);
v___x_5_ = lean_unsigned_to_nat(0u);
v___x_6_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6_, 0, v___x_5_);
lean_ctor_set(v___x_6_, 1, v___x_4_);
return v___x_6_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__2(void){
_start:
{
lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
v___x_7_ = lean_unsigned_to_nat(0u);
v___x_8_ = lean_box(0);
v___x_9_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__1, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__1_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__1);
v___x_10_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__1___redArg(v___x_9_, v___x_8_, v___x_7_);
return v___x_10_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__3(void){
_start:
{
lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; 
v___x_11_ = lean_box(0);
v___x_12_ = lean_unsigned_to_nat(2048u);
v___x_13_ = lean_mk_array(v___x_12_, v___x_11_);
return v___x_13_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__4(void){
_start:
{
lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; 
v___x_14_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__3, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__3_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__3);
v___x_15_ = lean_unsigned_to_nat(0u);
v___x_16_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_16_, 0, v___x_15_);
lean_ctor_set(v___x_16_, 1, v___x_14_);
return v___x_16_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__5(void){
_start:
{
lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; 
v___x_17_ = lean_unsigned_to_nat(0u);
v___x_18_ = lean_box(0);
v___x_19_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__4, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__4_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__4);
v___x_20_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_AccLevelState_push_spec__0___redArg(v___x_19_, v___x_18_, v___x_17_);
return v___x_20_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__6(void){
_start:
{
lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; 
v___x_21_ = lean_box(0);
v___x_22_ = lean_unsigned_to_nat(16777216u);
v___x_23_ = lean_mk_array(v___x_22_, v___x_21_);
return v___x_23_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__7(void){
_start:
{
lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; 
v___x_24_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__6, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__6_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__6);
v___x_25_ = lean_unsigned_to_nat(0u);
v___x_26_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_26_, 0, v___x_25_);
lean_ctor_set(v___x_26_, 1, v___x_24_);
return v___x_26_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__8(void){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_27_ = lean_box(0);
v___x_28_ = lean_unsigned_to_nat(16u);
v___x_29_ = lean_mk_array(v___x_28_, v___x_27_);
return v___x_29_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__9(void){
_start:
{
lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v___x_30_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__8, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__8_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__8);
v___x_31_ = lean_unsigned_to_nat(0u);
v___x_32_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_32_, 0, v___x_31_);
lean_ctor_set(v___x_32_, 1, v___x_30_);
return v___x_32_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__10(void){
_start:
{
lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; 
v___x_33_ = lean_box(0);
v___x_34_ = lean_unsigned_to_nat(262144u);
v___x_35_ = lean_mk_array(v___x_34_, v___x_33_);
return v___x_35_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__11(void){
_start:
{
lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; 
v___x_36_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__10, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__10_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__10);
v___x_37_ = lean_unsigned_to_nat(0u);
v___x_38_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_38_, 0, v___x_37_);
lean_ctor_set(v___x_38_, 1, v___x_36_);
return v___x_38_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__12(void){
_start:
{
lean_object* v___x_39_; uint8_t v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; 
v___x_39_ = lean_box(1);
v___x_40_ = 0;
v___x_41_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__11, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__11_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__11);
v___x_42_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__9, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__9_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__9);
v___x_43_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__7, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__7_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__7);
v___x_44_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__5, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__5_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__5);
v___x_45_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__2, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__2_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__2);
v___x_46_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_46_, 0, v___x_45_);
lean_ctor_set(v___x_46_, 1, v___x_44_);
lean_ctor_set(v___x_46_, 2, v___x_43_);
lean_ctor_set(v___x_46_, 3, v___x_42_);
lean_ctor_set(v___x_46_, 4, v___x_41_);
lean_ctor_set(v___x_46_, 5, v___x_39_);
lean_ctor_set_uint8(v___x_46_, sizeof(void*)*6, v___x_40_);
lean_ctor_set_uint8(v___x_46_, sizeof(void*)*6 + 1, v___x_40_);
lean_ctor_set_uint8(v___x_46_, sizeof(void*)*6 + 2, v___x_40_);
return v___x_46_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg(lean_object* v_env_47_, lean_object* v_act_48_){
_start:
{
lean_object* v___x_50_; lean_object* v___x_51_; 
v___x_50_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_M_run___redArg___closed__12, &lp_proofEnvironment_CheckedExport_M_run___redArg___closed__12_once, _init_lp_proofEnvironment_CheckedExport_M_run___redArg___closed__12);
v___x_51_ = lean_apply_3(v_act_48_, v_env_47_, v___x_50_, lean_box(0));
if (lean_obj_tag(v___x_51_) == 0)
{
lean_object* v_a_52_; lean_object* v___x_54_; uint8_t v_isShared_55_; uint8_t v_isSharedCheck_60_; 
v_a_52_ = lean_ctor_get(v___x_51_, 0);
v_isSharedCheck_60_ = !lean_is_exclusive(v___x_51_);
if (v_isSharedCheck_60_ == 0)
{
v___x_54_ = v___x_51_;
v_isShared_55_ = v_isSharedCheck_60_;
goto v_resetjp_53_;
}
else
{
lean_inc(v_a_52_);
lean_dec(v___x_51_);
v___x_54_ = lean_box(0);
v_isShared_55_ = v_isSharedCheck_60_;
goto v_resetjp_53_;
}
v_resetjp_53_:
{
lean_object* v_fst_56_; lean_object* v___x_58_; 
v_fst_56_ = lean_ctor_get(v_a_52_, 0);
lean_inc(v_fst_56_);
lean_dec(v_a_52_);
if (v_isShared_55_ == 0)
{
lean_ctor_set(v___x_54_, 0, v_fst_56_);
v___x_58_ = v___x_54_;
goto v_reusejp_57_;
}
else
{
lean_object* v_reuseFailAlloc_59_; 
v_reuseFailAlloc_59_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_59_, 0, v_fst_56_);
v___x_58_ = v_reuseFailAlloc_59_;
goto v_reusejp_57_;
}
v_reusejp_57_:
{
return v___x_58_;
}
}
}
else
{
lean_object* v_a_61_; lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_a_61_ = lean_ctor_get(v___x_51_, 0);
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_51_);
if (v_isSharedCheck_68_ == 0)
{
v___x_63_ = v___x_51_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_inc(v_a_61_);
lean_dec(v___x_51_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_61_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg___boxed(lean_object* v_env_69_, lean_object* v_act_70_, lean_object* v_a_71_){
_start:
{
lean_object* v_res_72_; 
v_res_72_ = lp_proofEnvironment_CheckedExport_M_run___redArg(v_env_69_, v_act_70_);
return v_res_72_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run(lean_object* v_00_u03b1_73_, lean_object* v_env_74_, lean_object* v_act_75_){
_start:
{
lean_object* v___x_77_; 
v___x_77_ = lp_proofEnvironment_CheckedExport_M_run___redArg(v_env_74_, v_act_75_);
return v___x_77_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_M_run___boxed(lean_object* v_00_u03b1_78_, lean_object* v_env_79_, lean_object* v_act_80_, lean_object* v_a_81_){
_start:
{
lean_object* v_res_82_; 
v_res_82_ = lp_proofEnvironment_CheckedExport_M_run(v_00_u03b1_78_, v_env_79_, v_act_80_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg(lean_object* v_val_83_, lean_object* v_as_x27_84_, lean_object* v_b_85_, lean_object* v___y_86_){
_start:
{
if (lean_obj_tag(v_as_x27_84_) == 0)
{
lean_object* v___x_88_; lean_object* v___x_89_; 
lean_dec_ref(v_val_83_);
v___x_88_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_88_, 0, v_b_85_);
lean_ctor_set(v___x_88_, 1, v___y_86_);
v___x_89_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_89_, 0, v___x_88_);
return v___x_89_;
}
else
{
lean_object* v_head_90_; lean_object* v_tail_91_; lean_object* v___x_92_; 
v_head_90_ = lean_ctor_get(v_as_x27_84_, 0);
v_tail_91_ = lean_ctor_get(v_as_x27_84_, 1);
lean_inc(v_head_90_);
lean_inc_ref(v_val_83_);
v___x_92_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(v_val_83_, v_head_90_, v_b_85_);
v_as_x27_84_ = v_tail_91_;
v_b_85_ = v___x_92_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg___boxed(lean_object* v_val_94_, lean_object* v_as_x27_95_, lean_object* v_b_96_, lean_object* v___y_97_, lean_object* v___y_98_){
_start:
{
lean_object* v_res_99_; 
v_res_99_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg(v_val_94_, v_as_x27_95_, v_b_96_, v___y_97_);
lean_dec(v_as_x27_95_);
return v_res_99_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState___lam__0(lean_object* v_x_100_, lean_object* v_y_101_, lean_object* v___y_102_, lean_object* v___y_103_, lean_object* v___y_104_){
_start:
{
lean_object* v_a_107_; lean_object* v_snd_108_; 
if (lean_obj_tag(v_y_101_) == 7)
{
lean_object* v_val_114_; lean_object* v_all_115_; lean_object* v___x_116_; lean_object* v_a_117_; lean_object* v_fst_118_; lean_object* v_snd_119_; 
v_val_114_ = lean_ctor_get(v_y_101_, 0);
lean_inc_ref(v_val_114_);
lean_dec_ref_known(v_y_101_, 1);
v_all_115_ = lean_ctor_get(v_val_114_, 1);
lean_inc(v_all_115_);
v___x_116_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg(v_val_114_, v_all_115_, v___y_102_, v___y_104_);
lean_dec(v_all_115_);
v_a_117_ = lean_ctor_get(v___x_116_, 0);
lean_inc(v_a_117_);
lean_dec_ref(v___x_116_);
v_fst_118_ = lean_ctor_get(v_a_117_, 0);
lean_inc(v_fst_118_);
v_snd_119_ = lean_ctor_get(v_a_117_, 1);
lean_inc(v_snd_119_);
lean_dec(v_a_117_);
v_a_107_ = v_fst_118_;
v_snd_108_ = v_snd_119_;
goto v___jp_106_;
}
else
{
lean_dec_ref(v_y_101_);
v_a_107_ = v___y_102_;
v_snd_108_ = v___y_104_;
goto v___jp_106_;
}
v___jp_106_:
{
lean_object* v___x_109_; lean_object* v___x_110_; lean_object* v___x_111_; lean_object* v___x_112_; lean_object* v___x_113_; 
v___x_109_ = lean_box(0);
v___x_110_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_110_, 0, v___x_109_);
lean_ctor_set(v___x_110_, 1, v_a_107_);
v___x_111_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_111_, 0, v___x_110_);
v___x_112_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_112_, 0, v___x_111_);
lean_ctor_set(v___x_112_, 1, v_snd_108_);
v___x_113_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_113_, 0, v___x_112_);
return v___x_113_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState___lam__0___boxed(lean_object* v_x_120_, lean_object* v_y_121_, lean_object* v___y_122_, lean_object* v___y_123_, lean_object* v___y_124_, lean_object* v___y_125_){
_start:
{
lean_object* v_res_126_; 
v_res_126_ = lp_proofEnvironment_CheckedExport_initState___lam__0(v_x_120_, v_y_121_, v___y_122_, v___y_123_, v___y_124_);
lean_dec_ref(v___y_123_);
lean_dec(v_x_120_);
return v_res_126_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___lam__0(lean_object* v_f_127_, lean_object* v_x_128_, lean_object* v___y_129_, lean_object* v___y_130_, lean_object* v___y_131_, lean_object* v___y_132_, lean_object* v___y_133_){
_start:
{
lean_object* v___x_135_; 
lean_inc_ref(v___y_132_);
v___x_135_ = lean_apply_6(v_f_127_, v___y_129_, v___y_130_, v___y_131_, v___y_132_, v___y_133_, lean_box(0));
return v___x_135_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___lam__0___boxed(lean_object* v_f_136_, lean_object* v_x_137_, lean_object* v___y_138_, lean_object* v___y_139_, lean_object* v___y_140_, lean_object* v___y_141_, lean_object* v___y_142_, lean_object* v___y_143_){
_start:
{
lean_object* v_res_144_; 
v_res_144_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___lam__0(v_f_136_, v_x_137_, v___y_138_, v___y_139_, v___y_140_, v___y_141_, v___y_142_);
lean_dec_ref(v___y_141_);
return v_res_144_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg(lean_object* v_f_145_, lean_object* v_keys_146_, lean_object* v_vals_147_, lean_object* v_i_148_, lean_object* v_acc_149_, lean_object* v___y_150_, lean_object* v___y_151_, lean_object* v___y_152_){
_start:
{
lean_object* v___x_154_; uint8_t v___x_155_; 
v___x_154_ = lean_array_get_size(v_keys_146_);
v___x_155_ = lean_nat_dec_lt(v_i_148_, v___x_154_);
if (v___x_155_ == 0)
{
lean_object* v___x_156_; lean_object* v___x_157_; lean_object* v___x_158_; lean_object* v___x_159_; 
lean_dec(v_i_148_);
lean_dec_ref(v_f_145_);
v___x_156_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_156_, 0, v_acc_149_);
lean_ctor_set(v___x_156_, 1, v___y_150_);
v___x_157_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_157_, 0, v___x_156_);
v___x_158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_158_, 0, v___x_157_);
lean_ctor_set(v___x_158_, 1, v___y_152_);
v___x_159_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_159_, 0, v___x_158_);
return v___x_159_;
}
else
{
lean_object* v_k_160_; lean_object* v_v_161_; lean_object* v___x_162_; 
v_k_160_ = lean_array_fget_borrowed(v_keys_146_, v_i_148_);
v_v_161_ = lean_array_fget_borrowed(v_vals_147_, v_i_148_);
lean_inc_ref(v_f_145_);
lean_inc_ref(v___y_151_);
lean_inc(v_v_161_);
lean_inc(v_k_160_);
v___x_162_ = lean_apply_7(v_f_145_, v_acc_149_, v_k_160_, v_v_161_, v___y_150_, v___y_151_, v___y_152_, lean_box(0));
if (lean_obj_tag(v___x_162_) == 0)
{
lean_object* v_a_163_; lean_object* v_fst_164_; 
v_a_163_ = lean_ctor_get(v___x_162_, 0);
lean_inc(v_a_163_);
v_fst_164_ = lean_ctor_get(v_a_163_, 0);
if (lean_obj_tag(v_fst_164_) == 0)
{
lean_dec(v_a_163_);
lean_dec(v_i_148_);
lean_dec_ref(v_f_145_);
return v___x_162_;
}
else
{
lean_object* v_a_165_; lean_object* v_snd_166_; lean_object* v_fst_167_; lean_object* v_snd_168_; lean_object* v___x_169_; lean_object* v___x_170_; 
lean_dec_ref_known(v___x_162_, 1);
v_a_165_ = lean_ctor_get(v_fst_164_, 0);
lean_inc(v_a_165_);
v_snd_166_ = lean_ctor_get(v_a_163_, 1);
lean_inc(v_snd_166_);
lean_dec(v_a_163_);
v_fst_167_ = lean_ctor_get(v_a_165_, 0);
lean_inc(v_fst_167_);
v_snd_168_ = lean_ctor_get(v_a_165_, 1);
lean_inc(v_snd_168_);
lean_dec(v_a_165_);
v___x_169_ = lean_unsigned_to_nat(1u);
v___x_170_ = lean_nat_add(v_i_148_, v___x_169_);
lean_dec(v_i_148_);
v_i_148_ = v___x_170_;
v_acc_149_ = v_fst_167_;
v___y_150_ = v_snd_168_;
v___y_152_ = v_snd_166_;
goto _start;
}
}
else
{
lean_dec(v_i_148_);
lean_dec_ref(v_f_145_);
return v___x_162_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg___boxed(lean_object* v_f_172_, lean_object* v_keys_173_, lean_object* v_vals_174_, lean_object* v_i_175_, lean_object* v_acc_176_, lean_object* v___y_177_, lean_object* v___y_178_, lean_object* v___y_179_, lean_object* v___y_180_){
_start:
{
lean_object* v_res_181_; 
v_res_181_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg(v_f_172_, v_keys_173_, v_vals_174_, v_i_175_, v_acc_176_, v___y_177_, v___y_178_, v___y_179_);
lean_dec_ref(v___y_178_);
lean_dec_ref(v_vals_174_);
lean_dec_ref(v_keys_173_);
return v_res_181_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg(lean_object* v_f_182_, lean_object* v_as_183_, size_t v_i_184_, size_t v_stop_185_, lean_object* v_b_186_, lean_object* v___y_187_, lean_object* v___y_188_, lean_object* v___y_189_){
_start:
{
lean_object* v_fst_192_; lean_object* v_snd_193_; lean_object* v_snd_194_; lean_object* v___y_199_; uint8_t v___x_206_; 
v___x_206_ = lean_usize_dec_eq(v_i_184_, v_stop_185_);
if (v___x_206_ == 0)
{
lean_object* v___x_207_; 
v___x_207_ = lean_array_uget_borrowed(v_as_183_, v_i_184_);
switch(lean_obj_tag(v___x_207_))
{
case 0:
{
lean_object* v_key_208_; lean_object* v_val_209_; lean_object* v___x_210_; 
v_key_208_ = lean_ctor_get(v___x_207_, 0);
v_val_209_ = lean_ctor_get(v___x_207_, 1);
lean_inc_ref(v_f_182_);
lean_inc_ref(v___y_188_);
lean_inc(v_val_209_);
lean_inc(v_key_208_);
v___x_210_ = lean_apply_7(v_f_182_, v_b_186_, v_key_208_, v_val_209_, v___y_187_, v___y_188_, v___y_189_, lean_box(0));
v___y_199_ = v___x_210_;
goto v___jp_198_;
}
case 1:
{
lean_object* v_node_211_; lean_object* v___x_212_; 
v_node_211_ = lean_ctor_get(v___x_207_, 0);
lean_inc(v_node_211_);
lean_inc_ref(v_f_182_);
v___x_212_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(v_f_182_, v_node_211_, v_b_186_, v___y_187_, v___y_188_, v___y_189_);
v___y_199_ = v___x_212_;
goto v___jp_198_;
}
default: 
{
v_fst_192_ = v_b_186_;
v_snd_193_ = v___y_187_;
v_snd_194_ = v___y_189_;
goto v___jp_191_;
}
}
}
else
{
lean_object* v___x_213_; lean_object* v___x_214_; lean_object* v___x_215_; lean_object* v___x_216_; 
lean_dec_ref(v_f_182_);
v___x_213_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_213_, 0, v_b_186_);
lean_ctor_set(v___x_213_, 1, v___y_187_);
v___x_214_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_214_, 0, v___x_213_);
v___x_215_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_215_, 0, v___x_214_);
lean_ctor_set(v___x_215_, 1, v___y_189_);
v___x_216_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_216_, 0, v___x_215_);
return v___x_216_;
}
v___jp_191_:
{
size_t v___x_195_; size_t v___x_196_; 
v___x_195_ = ((size_t)1ULL);
v___x_196_ = lean_usize_add(v_i_184_, v___x_195_);
v_i_184_ = v___x_196_;
v_b_186_ = v_fst_192_;
v___y_187_ = v_snd_193_;
v___y_189_ = v_snd_194_;
goto _start;
}
v___jp_198_:
{
if (lean_obj_tag(v___y_199_) == 0)
{
lean_object* v_a_200_; lean_object* v_fst_201_; 
v_a_200_ = lean_ctor_get(v___y_199_, 0);
v_fst_201_ = lean_ctor_get(v_a_200_, 0);
if (lean_obj_tag(v_fst_201_) == 0)
{
lean_dec_ref(v_f_182_);
return v___y_199_;
}
else
{
lean_object* v_a_202_; lean_object* v_snd_203_; lean_object* v_fst_204_; lean_object* v_snd_205_; 
lean_inc(v_a_200_);
lean_dec_ref_known(v___y_199_, 1);
v_a_202_ = lean_ctor_get(v_fst_201_, 0);
lean_inc(v_a_202_);
v_snd_203_ = lean_ctor_get(v_a_200_, 1);
lean_inc(v_snd_203_);
lean_dec(v_a_200_);
v_fst_204_ = lean_ctor_get(v_a_202_, 0);
lean_inc(v_fst_204_);
v_snd_205_ = lean_ctor_get(v_a_202_, 1);
lean_inc(v_snd_205_);
lean_dec(v_a_202_);
v_fst_192_ = v_fst_204_;
v_snd_193_ = v_snd_205_;
v_snd_194_ = v_snd_203_;
goto v___jp_191_;
}
}
else
{
lean_dec_ref(v_f_182_);
return v___y_199_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(lean_object* v_f_217_, lean_object* v_x_218_, lean_object* v_x_219_, lean_object* v___y_220_, lean_object* v___y_221_, lean_object* v___y_222_){
_start:
{
if (lean_obj_tag(v_x_218_) == 0)
{
lean_object* v_es_224_; lean_object* v___x_226_; uint8_t v_isShared_227_; uint8_t v_isSharedCheck_250_; 
v_es_224_ = lean_ctor_get(v_x_218_, 0);
v_isSharedCheck_250_ = !lean_is_exclusive(v_x_218_);
if (v_isSharedCheck_250_ == 0)
{
v___x_226_ = v_x_218_;
v_isShared_227_ = v_isSharedCheck_250_;
goto v_resetjp_225_;
}
else
{
lean_inc(v_es_224_);
lean_dec(v_x_218_);
v___x_226_ = lean_box(0);
v_isShared_227_ = v_isSharedCheck_250_;
goto v_resetjp_225_;
}
v_resetjp_225_:
{
lean_object* v___x_228_; lean_object* v___x_229_; uint8_t v___x_230_; 
v___x_228_ = lean_unsigned_to_nat(0u);
v___x_229_ = lean_array_get_size(v_es_224_);
v___x_230_ = lean_nat_dec_lt(v___x_228_, v___x_229_);
if (v___x_230_ == 0)
{
lean_object* v___x_231_; lean_object* v___x_233_; 
lean_dec_ref(v_es_224_);
lean_dec_ref(v_f_217_);
v___x_231_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_231_, 0, v_x_219_);
lean_ctor_set(v___x_231_, 1, v___y_220_);
if (v_isShared_227_ == 0)
{
lean_ctor_set_tag(v___x_226_, 1);
lean_ctor_set(v___x_226_, 0, v___x_231_);
v___x_233_ = v___x_226_;
goto v_reusejp_232_;
}
else
{
lean_object* v_reuseFailAlloc_236_; 
v_reuseFailAlloc_236_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_236_, 0, v___x_231_);
v___x_233_ = v_reuseFailAlloc_236_;
goto v_reusejp_232_;
}
v_reusejp_232_:
{
lean_object* v___x_234_; lean_object* v___x_235_; 
v___x_234_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_234_, 0, v___x_233_);
lean_ctor_set(v___x_234_, 1, v___y_222_);
v___x_235_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_235_, 0, v___x_234_);
return v___x_235_;
}
}
else
{
uint8_t v___x_237_; 
v___x_237_ = lean_nat_dec_le(v___x_229_, v___x_229_);
if (v___x_237_ == 0)
{
if (v___x_230_ == 0)
{
lean_object* v___x_238_; lean_object* v___x_240_; 
lean_dec_ref(v_es_224_);
lean_dec_ref(v_f_217_);
v___x_238_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_238_, 0, v_x_219_);
lean_ctor_set(v___x_238_, 1, v___y_220_);
if (v_isShared_227_ == 0)
{
lean_ctor_set_tag(v___x_226_, 1);
lean_ctor_set(v___x_226_, 0, v___x_238_);
v___x_240_ = v___x_226_;
goto v_reusejp_239_;
}
else
{
lean_object* v_reuseFailAlloc_243_; 
v_reuseFailAlloc_243_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_243_, 0, v___x_238_);
v___x_240_ = v_reuseFailAlloc_243_;
goto v_reusejp_239_;
}
v_reusejp_239_:
{
lean_object* v___x_241_; lean_object* v___x_242_; 
v___x_241_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_241_, 0, v___x_240_);
lean_ctor_set(v___x_241_, 1, v___y_222_);
v___x_242_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_242_, 0, v___x_241_);
return v___x_242_;
}
}
else
{
size_t v___x_244_; size_t v___x_245_; lean_object* v___x_246_; 
lean_del_object(v___x_226_);
v___x_244_ = ((size_t)0ULL);
v___x_245_ = lean_usize_of_nat(v___x_229_);
v___x_246_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg(v_f_217_, v_es_224_, v___x_244_, v___x_245_, v_x_219_, v___y_220_, v___y_221_, v___y_222_);
lean_dec_ref(v_es_224_);
return v___x_246_;
}
}
else
{
size_t v___x_247_; size_t v___x_248_; lean_object* v___x_249_; 
lean_del_object(v___x_226_);
v___x_247_ = ((size_t)0ULL);
v___x_248_ = lean_usize_of_nat(v___x_229_);
v___x_249_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg(v_f_217_, v_es_224_, v___x_247_, v___x_248_, v_x_219_, v___y_220_, v___y_221_, v___y_222_);
lean_dec_ref(v_es_224_);
return v___x_249_;
}
}
}
}
else
{
lean_object* v_ks_251_; lean_object* v_vs_252_; lean_object* v___x_253_; lean_object* v___x_254_; 
v_ks_251_ = lean_ctor_get(v_x_218_, 0);
lean_inc_ref(v_ks_251_);
v_vs_252_ = lean_ctor_get(v_x_218_, 1);
lean_inc_ref(v_vs_252_);
lean_dec_ref_known(v_x_218_, 2);
v___x_253_ = lean_unsigned_to_nat(0u);
v___x_254_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg(v_f_217_, v_ks_251_, v_vs_252_, v___x_253_, v_x_219_, v___y_220_, v___y_221_, v___y_222_);
lean_dec_ref(v_vs_252_);
lean_dec_ref(v_ks_251_);
return v___x_254_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg___boxed(lean_object* v_f_255_, lean_object* v_x_256_, lean_object* v_x_257_, lean_object* v___y_258_, lean_object* v___y_259_, lean_object* v___y_260_, lean_object* v___y_261_){
_start:
{
lean_object* v_res_262_; 
v_res_262_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(v_f_255_, v_x_256_, v_x_257_, v___y_258_, v___y_259_, v___y_260_);
lean_dec_ref(v___y_259_);
return v_res_262_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg___boxed(lean_object* v_f_263_, lean_object* v_as_264_, lean_object* v_i_265_, lean_object* v_stop_266_, lean_object* v_b_267_, lean_object* v___y_268_, lean_object* v___y_269_, lean_object* v___y_270_, lean_object* v___y_271_){
_start:
{
size_t v_i_boxed_272_; size_t v_stop_boxed_273_; lean_object* v_res_274_; 
v_i_boxed_272_ = lean_unbox_usize(v_i_265_);
lean_dec(v_i_265_);
v_stop_boxed_273_ = lean_unbox_usize(v_stop_266_);
lean_dec(v_stop_266_);
v_res_274_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg(v_f_263_, v_as_264_, v_i_boxed_272_, v_stop_boxed_273_, v_b_267_, v___y_268_, v___y_269_, v___y_270_);
lean_dec_ref(v___y_269_);
lean_dec_ref(v_as_264_);
return v_res_274_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(lean_object* v_map_275_, lean_object* v_f_276_, lean_object* v___y_277_, lean_object* v___y_278_, lean_object* v___y_279_){
_start:
{
lean_object* v___f_281_; lean_object* v___x_282_; lean_object* v___x_283_; 
v___f_281_ = lean_alloc_closure((void*)(lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___lam__0___boxed), 8, 1);
lean_closure_set(v___f_281_, 0, v_f_276_);
v___x_282_ = lean_box(0);
v___x_283_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(v___f_281_, v_map_275_, v___x_282_, v___y_277_, v___y_278_, v___y_279_);
return v___x_283_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg___boxed(lean_object* v_map_284_, lean_object* v_f_285_, lean_object* v___y_286_, lean_object* v___y_287_, lean_object* v___y_288_, lean_object* v___y_289_){
_start:
{
lean_object* v_res_290_; 
v_res_290_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(v_map_284_, v_f_285_, v___y_286_, v___y_287_, v___y_288_);
lean_dec_ref(v___y_287_);
return v_res_290_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg(lean_object* v_f_291_, lean_object* v_x_292_, lean_object* v_x_293_, lean_object* v___y_294_, lean_object* v___y_295_, lean_object* v___y_296_){
_start:
{
if (lean_obj_tag(v_x_293_) == 0)
{
lean_object* v___x_298_; lean_object* v___x_299_; lean_object* v___x_300_; lean_object* v___x_301_; 
lean_dec_ref(v_f_291_);
v___x_298_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_298_, 0, v_x_292_);
lean_ctor_set(v___x_298_, 1, v___y_294_);
v___x_299_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_299_, 0, v___x_298_);
v___x_300_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_300_, 0, v___x_299_);
lean_ctor_set(v___x_300_, 1, v___y_296_);
v___x_301_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_301_, 0, v___x_300_);
return v___x_301_;
}
else
{
lean_object* v_key_302_; lean_object* v_value_303_; lean_object* v_tail_304_; lean_object* v___x_305_; 
v_key_302_ = lean_ctor_get(v_x_293_, 0);
lean_inc(v_key_302_);
v_value_303_ = lean_ctor_get(v_x_293_, 1);
lean_inc(v_value_303_);
v_tail_304_ = lean_ctor_get(v_x_293_, 2);
lean_inc(v_tail_304_);
lean_dec_ref_known(v_x_293_, 3);
lean_inc_ref(v_f_291_);
lean_inc_ref(v___y_295_);
v___x_305_ = lean_apply_6(v_f_291_, v_key_302_, v_value_303_, v___y_294_, v___y_295_, v___y_296_, lean_box(0));
if (lean_obj_tag(v___x_305_) == 0)
{
lean_object* v_a_306_; lean_object* v_fst_307_; 
v_a_306_ = lean_ctor_get(v___x_305_, 0);
lean_inc(v_a_306_);
v_fst_307_ = lean_ctor_get(v_a_306_, 0);
if (lean_obj_tag(v_fst_307_) == 0)
{
lean_dec(v_a_306_);
lean_dec(v_tail_304_);
lean_dec_ref(v_f_291_);
return v___x_305_;
}
else
{
lean_object* v_a_308_; lean_object* v_snd_309_; lean_object* v_fst_310_; lean_object* v_snd_311_; 
lean_dec_ref_known(v___x_305_, 1);
v_a_308_ = lean_ctor_get(v_fst_307_, 0);
lean_inc(v_a_308_);
v_snd_309_ = lean_ctor_get(v_a_306_, 1);
lean_inc(v_snd_309_);
lean_dec(v_a_306_);
v_fst_310_ = lean_ctor_get(v_a_308_, 0);
lean_inc(v_fst_310_);
v_snd_311_ = lean_ctor_get(v_a_308_, 1);
lean_inc(v_snd_311_);
lean_dec(v_a_308_);
v_x_292_ = v_fst_310_;
v_x_293_ = v_tail_304_;
v___y_294_ = v_snd_311_;
v___y_296_ = v_snd_309_;
goto _start;
}
}
else
{
lean_dec(v_tail_304_);
lean_dec_ref(v_f_291_);
return v___x_305_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg___boxed(lean_object* v_f_313_, lean_object* v_x_314_, lean_object* v_x_315_, lean_object* v___y_316_, lean_object* v___y_317_, lean_object* v___y_318_, lean_object* v___y_319_){
_start:
{
lean_object* v_res_320_; 
v_res_320_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg(v_f_313_, v_x_314_, v_x_315_, v___y_316_, v___y_317_, v___y_318_);
lean_dec_ref(v___y_317_);
return v_res_320_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg(lean_object* v_f_321_, lean_object* v_as_322_, size_t v_i_323_, size_t v_stop_324_, lean_object* v_b_325_, lean_object* v___y_326_, lean_object* v___y_327_, lean_object* v___y_328_){
_start:
{
uint8_t v___x_330_; 
v___x_330_ = lean_usize_dec_eq(v_i_323_, v_stop_324_);
if (v___x_330_ == 0)
{
lean_object* v___x_331_; lean_object* v___x_332_; lean_object* v___x_333_; 
v___x_331_ = lean_array_uget_borrowed(v_as_322_, v_i_323_);
v___x_332_ = lean_box(0);
lean_inc(v___x_331_);
lean_inc_ref(v_f_321_);
v___x_333_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg(v_f_321_, v___x_332_, v___x_331_, v___y_326_, v___y_327_, v___y_328_);
if (lean_obj_tag(v___x_333_) == 0)
{
lean_object* v_a_334_; lean_object* v_fst_335_; 
v_a_334_ = lean_ctor_get(v___x_333_, 0);
lean_inc(v_a_334_);
v_fst_335_ = lean_ctor_get(v_a_334_, 0);
if (lean_obj_tag(v_fst_335_) == 0)
{
lean_dec(v_a_334_);
lean_dec_ref(v_f_321_);
return v___x_333_;
}
else
{
lean_object* v_a_336_; lean_object* v_snd_337_; lean_object* v_fst_338_; lean_object* v_snd_339_; size_t v___x_340_; size_t v___x_341_; 
lean_dec_ref_known(v___x_333_, 1);
v_a_336_ = lean_ctor_get(v_fst_335_, 0);
lean_inc(v_a_336_);
v_snd_337_ = lean_ctor_get(v_a_334_, 1);
lean_inc(v_snd_337_);
lean_dec(v_a_334_);
v_fst_338_ = lean_ctor_get(v_a_336_, 0);
lean_inc(v_fst_338_);
v_snd_339_ = lean_ctor_get(v_a_336_, 1);
lean_inc(v_snd_339_);
lean_dec(v_a_336_);
v___x_340_ = ((size_t)1ULL);
v___x_341_ = lean_usize_add(v_i_323_, v___x_340_);
v_i_323_ = v___x_341_;
v_b_325_ = v_fst_338_;
v___y_326_ = v_snd_339_;
v___y_328_ = v_snd_337_;
goto _start;
}
}
else
{
lean_dec_ref(v_f_321_);
return v___x_333_;
}
}
else
{
lean_object* v___x_343_; lean_object* v___x_344_; lean_object* v___x_345_; lean_object* v___x_346_; 
lean_dec_ref(v_f_321_);
v___x_343_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_343_, 0, v_b_325_);
lean_ctor_set(v___x_343_, 1, v___y_326_);
v___x_344_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_344_, 0, v___x_343_);
v___x_345_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_345_, 0, v___x_344_);
lean_ctor_set(v___x_345_, 1, v___y_328_);
v___x_346_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_346_, 0, v___x_345_);
return v___x_346_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg___boxed(lean_object* v_f_347_, lean_object* v_as_348_, lean_object* v_i_349_, lean_object* v_stop_350_, lean_object* v_b_351_, lean_object* v___y_352_, lean_object* v___y_353_, lean_object* v___y_354_, lean_object* v___y_355_){
_start:
{
size_t v_i_boxed_356_; size_t v_stop_boxed_357_; lean_object* v_res_358_; 
v_i_boxed_356_ = lean_unbox_usize(v_i_349_);
lean_dec(v_i_349_);
v_stop_boxed_357_ = lean_unbox_usize(v_stop_350_);
lean_dec(v_stop_350_);
v_res_358_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg(v_f_347_, v_as_348_, v_i_boxed_356_, v_stop_boxed_357_, v_b_351_, v___y_352_, v___y_353_, v___y_354_);
lean_dec_ref(v___y_353_);
lean_dec_ref(v_as_348_);
return v_res_358_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg(lean_object* v_s_359_, lean_object* v_f_360_, lean_object* v___y_361_, lean_object* v___y_362_, lean_object* v___y_363_){
_start:
{
lean_object* v_map_u2081_365_; lean_object* v_map_u2082_366_; lean_object* v_buckets_367_; lean_object* v___x_368_; lean_object* v___x_369_; uint8_t v___x_370_; 
v_map_u2081_365_ = lean_ctor_get(v_s_359_, 0);
lean_inc_ref(v_map_u2081_365_);
v_map_u2082_366_ = lean_ctor_get(v_s_359_, 1);
lean_inc_ref(v_map_u2082_366_);
lean_dec_ref(v_s_359_);
v_buckets_367_ = lean_ctor_get(v_map_u2081_365_, 1);
lean_inc_ref(v_buckets_367_);
lean_dec_ref(v_map_u2081_365_);
v___x_368_ = lean_unsigned_to_nat(0u);
v___x_369_ = lean_array_get_size(v_buckets_367_);
v___x_370_ = lean_nat_dec_lt(v___x_368_, v___x_369_);
if (v___x_370_ == 0)
{
lean_object* v___x_371_; 
lean_dec_ref(v_buckets_367_);
v___x_371_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(v_map_u2082_366_, v_f_360_, v___y_361_, v___y_362_, v___y_363_);
return v___x_371_;
}
else
{
lean_object* v___x_372_; uint8_t v___x_373_; 
v___x_372_ = lean_box(0);
v___x_373_ = lean_nat_dec_le(v___x_369_, v___x_369_);
if (v___x_373_ == 0)
{
if (v___x_370_ == 0)
{
lean_object* v___x_374_; 
lean_dec_ref(v_buckets_367_);
v___x_374_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(v_map_u2082_366_, v_f_360_, v___y_361_, v___y_362_, v___y_363_);
return v___x_374_;
}
else
{
size_t v___x_375_; size_t v___x_376_; lean_object* v___x_377_; 
v___x_375_ = ((size_t)0ULL);
v___x_376_ = lean_usize_of_nat(v___x_369_);
lean_inc_ref(v_f_360_);
v___x_377_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg(v_f_360_, v_buckets_367_, v___x_375_, v___x_376_, v___x_372_, v___y_361_, v___y_362_, v___y_363_);
lean_dec_ref(v_buckets_367_);
if (lean_obj_tag(v___x_377_) == 0)
{
lean_object* v_a_378_; lean_object* v_fst_379_; 
v_a_378_ = lean_ctor_get(v___x_377_, 0);
lean_inc(v_a_378_);
v_fst_379_ = lean_ctor_get(v_a_378_, 0);
if (lean_obj_tag(v_fst_379_) == 0)
{
lean_dec(v_a_378_);
lean_dec_ref(v_map_u2082_366_);
lean_dec_ref(v_f_360_);
return v___x_377_;
}
else
{
lean_object* v_a_380_; lean_object* v_snd_381_; lean_object* v_snd_382_; lean_object* v___x_383_; 
lean_dec_ref_known(v___x_377_, 1);
v_a_380_ = lean_ctor_get(v_fst_379_, 0);
lean_inc(v_a_380_);
v_snd_381_ = lean_ctor_get(v_a_378_, 1);
lean_inc(v_snd_381_);
lean_dec(v_a_378_);
v_snd_382_ = lean_ctor_get(v_a_380_, 1);
lean_inc(v_snd_382_);
lean_dec(v_a_380_);
v___x_383_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(v_map_u2082_366_, v_f_360_, v_snd_382_, v___y_362_, v_snd_381_);
return v___x_383_;
}
}
else
{
lean_dec_ref(v_map_u2082_366_);
lean_dec_ref(v_f_360_);
return v___x_377_;
}
}
}
else
{
size_t v___x_384_; size_t v___x_385_; lean_object* v___x_386_; 
v___x_384_ = ((size_t)0ULL);
v___x_385_ = lean_usize_of_nat(v___x_369_);
lean_inc_ref(v_f_360_);
v___x_386_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg(v_f_360_, v_buckets_367_, v___x_384_, v___x_385_, v___x_372_, v___y_361_, v___y_362_, v___y_363_);
lean_dec_ref(v_buckets_367_);
if (lean_obj_tag(v___x_386_) == 0)
{
lean_object* v_a_387_; lean_object* v_fst_388_; 
v_a_387_ = lean_ctor_get(v___x_386_, 0);
lean_inc(v_a_387_);
v_fst_388_ = lean_ctor_get(v_a_387_, 0);
if (lean_obj_tag(v_fst_388_) == 0)
{
lean_dec(v_a_387_);
lean_dec_ref(v_map_u2082_366_);
lean_dec_ref(v_f_360_);
return v___x_386_;
}
else
{
lean_object* v_a_389_; lean_object* v_snd_390_; lean_object* v_snd_391_; lean_object* v___x_392_; 
lean_dec_ref_known(v___x_386_, 1);
v_a_389_ = lean_ctor_get(v_fst_388_, 0);
lean_inc(v_a_389_);
v_snd_390_ = lean_ctor_get(v_a_387_, 1);
lean_inc(v_snd_390_);
lean_dec(v_a_387_);
v_snd_391_ = lean_ctor_get(v_a_389_, 1);
lean_inc(v_snd_391_);
lean_dec(v_a_389_);
v___x_392_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(v_map_u2082_366_, v_f_360_, v_snd_391_, v___y_362_, v_snd_390_);
return v___x_392_;
}
}
else
{
lean_dec_ref(v_map_u2082_366_);
lean_dec_ref(v_f_360_);
return v___x_386_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg___boxed(lean_object* v_s_393_, lean_object* v_f_394_, lean_object* v___y_395_, lean_object* v___y_396_, lean_object* v___y_397_, lean_object* v___y_398_){
_start:
{
lean_object* v_res_399_; 
v_res_399_ = lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg(v_s_393_, v_f_394_, v___y_395_, v___y_396_, v___y_397_);
lean_dec_ref(v___y_396_);
return v_res_399_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState(lean_object* v_env_401_, lean_object* v_cliOptions_402_, lean_object* v_a_403_, lean_object* v_a_404_){
_start:
{
lean_object* v_constants_406_; lean_object* v___f_407_; lean_object* v_recursorMap_408_; lean_object* v___x_409_; 
v_constants_406_ = lean_ctor_get(v_env_401_, 0);
lean_inc_ref(v_constants_406_);
lean_dec_ref(v_env_401_);
v___f_407_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_initState___closed__0));
v_recursorMap_408_ = lean_box(1);
v___x_409_ = lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg(v_constants_406_, v___f_407_, v_recursorMap_408_, v_a_403_, v_a_404_);
if (lean_obj_tag(v___x_409_) == 0)
{
lean_object* v_a_410_; lean_object* v___x_412_; uint8_t v_isShared_413_; uint8_t v_isSharedCheck_448_; 
v_a_410_ = lean_ctor_get(v___x_409_, 0);
v_isSharedCheck_448_ = !lean_is_exclusive(v___x_409_);
if (v_isSharedCheck_448_ == 0)
{
v___x_412_ = v___x_409_;
v_isShared_413_ = v_isSharedCheck_448_;
goto v_resetjp_411_;
}
else
{
lean_inc(v_a_410_);
lean_dec(v___x_409_);
v___x_412_ = lean_box(0);
v_isShared_413_ = v_isSharedCheck_448_;
goto v_resetjp_411_;
}
v_resetjp_411_:
{
lean_object* v_fst_414_; lean_object* v_snd_415_; lean_object* v___x_417_; uint8_t v_isShared_418_; uint8_t v_isSharedCheck_447_; 
v_fst_414_ = lean_ctor_get(v_a_410_, 0);
v_snd_415_ = lean_ctor_get(v_a_410_, 1);
v_isSharedCheck_447_ = !lean_is_exclusive(v_a_410_);
if (v_isSharedCheck_447_ == 0)
{
v___x_417_ = v_a_410_;
v_isShared_418_ = v_isSharedCheck_447_;
goto v_resetjp_416_;
}
else
{
lean_inc(v_snd_415_);
lean_inc(v_fst_414_);
lean_dec(v_a_410_);
v___x_417_ = lean_box(0);
v_isShared_418_ = v_isSharedCheck_447_;
goto v_resetjp_416_;
}
v_resetjp_416_:
{
lean_object* v_fst_420_; 
if (lean_obj_tag(v_fst_414_) == 0)
{
lean_object* v_a_444_; 
v_a_444_ = lean_ctor_get(v_fst_414_, 0);
lean_inc(v_a_444_);
lean_dec_ref_known(v_fst_414_, 1);
v_fst_420_ = v_a_444_;
goto v___jp_419_;
}
else
{
lean_object* v_a_445_; lean_object* v_snd_446_; 
v_a_445_ = lean_ctor_get(v_fst_414_, 0);
lean_inc(v_a_445_);
lean_dec_ref_known(v_fst_414_, 1);
v_snd_446_ = lean_ctor_get(v_a_445_, 1);
lean_inc(v_snd_446_);
lean_dec(v_a_445_);
v_fst_420_ = v_snd_446_;
goto v___jp_419_;
}
v___jp_419_:
{
lean_object* v_visitedNames_421_; lean_object* v_visitedLevels_422_; lean_object* v_visitedExprs_423_; lean_object* v_visitedConstants_424_; lean_object* v_noMDataExprs_425_; lean_object* v___x_427_; uint8_t v_isShared_428_; uint8_t v_isSharedCheck_442_; 
v_visitedNames_421_ = lean_ctor_get(v_snd_415_, 0);
v_visitedLevels_422_ = lean_ctor_get(v_snd_415_, 1);
v_visitedExprs_423_ = lean_ctor_get(v_snd_415_, 2);
v_visitedConstants_424_ = lean_ctor_get(v_snd_415_, 3);
v_noMDataExprs_425_ = lean_ctor_get(v_snd_415_, 4);
v_isSharedCheck_442_ = !lean_is_exclusive(v_snd_415_);
if (v_isSharedCheck_442_ == 0)
{
lean_object* v_unused_443_; 
v_unused_443_ = lean_ctor_get(v_snd_415_, 5);
lean_dec(v_unused_443_);
v___x_427_ = v_snd_415_;
v_isShared_428_ = v_isSharedCheck_442_;
goto v_resetjp_426_;
}
else
{
lean_inc(v_noMDataExprs_425_);
lean_inc(v_visitedConstants_424_);
lean_inc(v_visitedExprs_423_);
lean_inc(v_visitedLevels_422_);
lean_inc(v_visitedNames_421_);
lean_dec(v_snd_415_);
v___x_427_ = lean_box(0);
v_isShared_428_ = v_isSharedCheck_442_;
goto v_resetjp_426_;
}
v_resetjp_426_:
{
lean_object* v___x_429_; uint8_t v___x_430_; uint8_t v___x_431_; uint8_t v___x_432_; lean_object* v___x_434_; 
v___x_429_ = lean_box(0);
v___x_430_ = lp_proofEnvironment_List_any___at___00initState_spec__0(v_cliOptions_402_);
v___x_431_ = lp_proofEnvironment_List_any___at___00initState_spec__1(v_cliOptions_402_);
v___x_432_ = lp_proofEnvironment_List_any___at___00initState_spec__2(v_cliOptions_402_);
if (v_isShared_428_ == 0)
{
lean_ctor_set(v___x_427_, 5, v_fst_420_);
v___x_434_ = v___x_427_;
goto v_reusejp_433_;
}
else
{
lean_object* v_reuseFailAlloc_441_; 
v_reuseFailAlloc_441_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_441_, 0, v_visitedNames_421_);
lean_ctor_set(v_reuseFailAlloc_441_, 1, v_visitedLevels_422_);
lean_ctor_set(v_reuseFailAlloc_441_, 2, v_visitedExprs_423_);
lean_ctor_set(v_reuseFailAlloc_441_, 3, v_visitedConstants_424_);
lean_ctor_set(v_reuseFailAlloc_441_, 4, v_noMDataExprs_425_);
lean_ctor_set(v_reuseFailAlloc_441_, 5, v_fst_420_);
v___x_434_ = v_reuseFailAlloc_441_;
goto v_reusejp_433_;
}
v_reusejp_433_:
{
lean_object* v___x_436_; 
lean_ctor_set_uint8(v___x_434_, sizeof(void*)*6, v___x_430_);
lean_ctor_set_uint8(v___x_434_, sizeof(void*)*6 + 1, v___x_431_);
lean_ctor_set_uint8(v___x_434_, sizeof(void*)*6 + 2, v___x_432_);
if (v_isShared_418_ == 0)
{
lean_ctor_set(v___x_417_, 1, v___x_434_);
lean_ctor_set(v___x_417_, 0, v___x_429_);
v___x_436_ = v___x_417_;
goto v_reusejp_435_;
}
else
{
lean_object* v_reuseFailAlloc_440_; 
v_reuseFailAlloc_440_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_440_, 0, v___x_429_);
lean_ctor_set(v_reuseFailAlloc_440_, 1, v___x_434_);
v___x_436_ = v_reuseFailAlloc_440_;
goto v_reusejp_435_;
}
v_reusejp_435_:
{
lean_object* v___x_438_; 
if (v_isShared_413_ == 0)
{
lean_ctor_set(v___x_412_, 0, v___x_436_);
v___x_438_ = v___x_412_;
goto v_reusejp_437_;
}
else
{
lean_object* v_reuseFailAlloc_439_; 
v_reuseFailAlloc_439_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_439_, 0, v___x_436_);
v___x_438_ = v_reuseFailAlloc_439_;
goto v_reusejp_437_;
}
v_reusejp_437_:
{
return v___x_438_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_449_; lean_object* v___x_451_; uint8_t v_isShared_452_; uint8_t v_isSharedCheck_456_; 
v_a_449_ = lean_ctor_get(v___x_409_, 0);
v_isSharedCheck_456_ = !lean_is_exclusive(v___x_409_);
if (v_isSharedCheck_456_ == 0)
{
v___x_451_ = v___x_409_;
v_isShared_452_ = v_isSharedCheck_456_;
goto v_resetjp_450_;
}
else
{
lean_inc(v_a_449_);
lean_dec(v___x_409_);
v___x_451_ = lean_box(0);
v_isShared_452_ = v_isSharedCheck_456_;
goto v_resetjp_450_;
}
v_resetjp_450_:
{
lean_object* v___x_454_; 
if (v_isShared_452_ == 0)
{
v___x_454_ = v___x_451_;
goto v_reusejp_453_;
}
else
{
lean_object* v_reuseFailAlloc_455_; 
v_reuseFailAlloc_455_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_455_, 0, v_a_449_);
v___x_454_ = v_reuseFailAlloc_455_;
goto v_reusejp_453_;
}
v_reusejp_453_:
{
return v___x_454_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_initState___boxed(lean_object* v_env_457_, lean_object* v_cliOptions_458_, lean_object* v_a_459_, lean_object* v_a_460_, lean_object* v_a_461_){
_start:
{
lean_object* v_res_462_; 
v_res_462_ = lp_proofEnvironment_CheckedExport_initState(v_env_457_, v_cliOptions_458_, v_a_459_, v_a_460_);
lean_dec_ref(v_a_459_);
lean_dec(v_cliOptions_458_);
return v_res_462_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0(lean_object* v_val_463_, lean_object* v_as_464_, lean_object* v_as_x27_465_, lean_object* v_b_466_, lean_object* v_a_467_, lean_object* v___y_468_, lean_object* v___y_469_){
_start:
{
lean_object* v___x_471_; 
v___x_471_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___redArg(v_val_463_, v_as_x27_465_, v_b_466_, v___y_469_);
return v___x_471_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0___boxed(lean_object* v_val_472_, lean_object* v_as_473_, lean_object* v_as_x27_474_, lean_object* v_b_475_, lean_object* v_a_476_, lean_object* v___y_477_, lean_object* v___y_478_, lean_object* v___y_479_){
_start:
{
lean_object* v_res_480_; 
v_res_480_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_initState_spec__0(v_val_472_, v_as_473_, v_as_x27_474_, v_b_475_, v_a_476_, v___y_477_, v___y_478_);
lean_dec_ref(v___y_477_);
lean_dec(v_as_x27_474_);
lean_dec(v_as_473_);
return v_res_480_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1(lean_object* v_00_u03b2_481_, lean_object* v_s_482_, lean_object* v_f_483_, lean_object* v___y_484_, lean_object* v___y_485_, lean_object* v___y_486_){
_start:
{
lean_object* v___x_488_; 
v___x_488_ = lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___redArg(v_s_482_, v_f_483_, v___y_484_, v___y_485_, v___y_486_);
return v___x_488_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1___boxed(lean_object* v_00_u03b2_489_, lean_object* v_s_490_, lean_object* v_f_491_, lean_object* v___y_492_, lean_object* v___y_493_, lean_object* v___y_494_, lean_object* v___y_495_){
_start:
{
lean_object* v_res_496_; 
v_res_496_ = lp_proofEnvironment_Lean_SMap_forM___at___00CheckedExport_initState_spec__1(v_00_u03b2_489_, v_s_490_, v_f_491_, v___y_492_, v___y_493_, v___y_494_);
lean_dec_ref(v___y_493_);
return v_res_496_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1(lean_object* v_00_u03b2_497_, lean_object* v_f_498_, lean_object* v_x_499_, lean_object* v_x_500_, lean_object* v___y_501_, lean_object* v___y_502_, lean_object* v___y_503_){
_start:
{
lean_object* v___x_505_; 
v___x_505_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___redArg(v_f_498_, v_x_499_, v_x_500_, v___y_501_, v___y_502_, v___y_503_);
return v___x_505_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1___boxed(lean_object* v_00_u03b2_506_, lean_object* v_f_507_, lean_object* v_x_508_, lean_object* v_x_509_, lean_object* v___y_510_, lean_object* v___y_511_, lean_object* v___y_512_, lean_object* v___y_513_){
_start:
{
lean_object* v_res_514_; 
v_res_514_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__1(v_00_u03b2_506_, v_f_507_, v_x_508_, v_x_509_, v___y_510_, v___y_511_, v___y_512_);
lean_dec_ref(v___y_511_);
return v_res_514_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2(lean_object* v_00_u03b2_515_, lean_object* v_map_516_, lean_object* v_f_517_, lean_object* v___y_518_, lean_object* v___y_519_, lean_object* v___y_520_){
_start:
{
lean_object* v___x_522_; 
v___x_522_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___redArg(v_map_516_, v_f_517_, v___y_518_, v___y_519_, v___y_520_);
return v___x_522_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2___boxed(lean_object* v_00_u03b2_523_, lean_object* v_map_524_, lean_object* v_f_525_, lean_object* v___y_526_, lean_object* v___y_527_, lean_object* v___y_528_, lean_object* v___y_529_){
_start:
{
lean_object* v_res_530_; 
v_res_530_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2(v_00_u03b2_523_, v_map_524_, v_f_525_, v___y_526_, v___y_527_, v___y_528_);
lean_dec_ref(v___y_527_);
return v_res_530_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3(lean_object* v_00_u03b2_531_, lean_object* v_f_532_, lean_object* v_as_533_, size_t v_i_534_, size_t v_stop_535_, lean_object* v_b_536_, lean_object* v___y_537_, lean_object* v___y_538_, lean_object* v___y_539_){
_start:
{
lean_object* v___x_541_; 
v___x_541_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___redArg(v_f_532_, v_as_533_, v_i_534_, v_stop_535_, v_b_536_, v___y_537_, v___y_538_, v___y_539_);
return v___x_541_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3___boxed(lean_object* v_00_u03b2_542_, lean_object* v_f_543_, lean_object* v_as_544_, lean_object* v_i_545_, lean_object* v_stop_546_, lean_object* v_b_547_, lean_object* v___y_548_, lean_object* v___y_549_, lean_object* v___y_550_, lean_object* v___y_551_){
_start:
{
size_t v_i_boxed_552_; size_t v_stop_boxed_553_; lean_object* v_res_554_; 
v_i_boxed_552_ = lean_unbox_usize(v_i_545_);
lean_dec(v_i_545_);
v_stop_boxed_553_ = lean_unbox_usize(v_stop_546_);
lean_dec(v_stop_546_);
v_res_554_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__3(v_00_u03b2_542_, v_f_543_, v_as_544_, v_i_boxed_552_, v_stop_boxed_553_, v_b_547_, v___y_548_, v___y_549_, v___y_550_);
lean_dec_ref(v___y_549_);
lean_dec_ref(v_as_544_);
return v_res_554_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___redArg(lean_object* v_map_555_, lean_object* v_f_556_, lean_object* v_init_557_, lean_object* v___y_558_, lean_object* v___y_559_, lean_object* v___y_560_){
_start:
{
lean_object* v___x_562_; 
v___x_562_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(v_f_556_, v_map_555_, v_init_557_, v___y_558_, v___y_559_, v___y_560_);
return v___x_562_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___redArg___boxed(lean_object* v_map_563_, lean_object* v_f_564_, lean_object* v_init_565_, lean_object* v___y_566_, lean_object* v___y_567_, lean_object* v___y_568_, lean_object* v___y_569_){
_start:
{
lean_object* v_res_570_; 
v_res_570_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___redArg(v_map_563_, v_f_564_, v_init_565_, v___y_566_, v___y_567_, v___y_568_);
lean_dec_ref(v___y_567_);
return v_res_570_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3(lean_object* v_00_u03c3_571_, lean_object* v_00_u03b2_572_, lean_object* v_map_573_, lean_object* v_f_574_, lean_object* v_init_575_, lean_object* v___y_576_, lean_object* v___y_577_, lean_object* v___y_578_){
_start:
{
lean_object* v___x_580_; 
v___x_580_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(v_f_574_, v_map_573_, v_init_575_, v___y_576_, v___y_577_, v___y_578_);
return v___x_580_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3___boxed(lean_object* v_00_u03c3_581_, lean_object* v_00_u03b2_582_, lean_object* v_map_583_, lean_object* v_f_584_, lean_object* v_init_585_, lean_object* v___y_586_, lean_object* v___y_587_, lean_object* v___y_588_, lean_object* v___y_589_){
_start:
{
lean_object* v_res_590_; 
v_res_590_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3(v_00_u03c3_581_, v_00_u03b2_582_, v_map_583_, v_f_584_, v_init_585_, v___y_586_, v___y_587_, v___y_588_);
lean_dec_ref(v___y_587_);
return v_res_590_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4(lean_object* v_00_u03c3_591_, lean_object* v_00_u03b1_592_, lean_object* v_00_u03b2_593_, lean_object* v_f_594_, lean_object* v_x_595_, lean_object* v_x_596_, lean_object* v___y_597_, lean_object* v___y_598_, lean_object* v___y_599_){
_start:
{
lean_object* v___x_601_; 
v___x_601_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___redArg(v_f_594_, v_x_595_, v_x_596_, v___y_597_, v___y_598_, v___y_599_);
return v___x_601_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4___boxed(lean_object* v_00_u03c3_602_, lean_object* v_00_u03b1_603_, lean_object* v_00_u03b2_604_, lean_object* v_f_605_, lean_object* v_x_606_, lean_object* v_x_607_, lean_object* v___y_608_, lean_object* v___y_609_, lean_object* v___y_610_, lean_object* v___y_611_){
_start:
{
lean_object* v_res_612_; 
v_res_612_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4(v_00_u03c3_602_, v_00_u03b1_603_, v_00_u03b2_604_, v_f_605_, v_x_606_, v_x_607_, v___y_608_, v___y_609_, v___y_610_);
lean_dec_ref(v___y_609_);
return v_res_612_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6(lean_object* v_00_u03b1_613_, lean_object* v_00_u03b2_614_, lean_object* v_00_u03c3_615_, lean_object* v_f_616_, lean_object* v_as_617_, size_t v_i_618_, size_t v_stop_619_, lean_object* v_b_620_, lean_object* v___y_621_, lean_object* v___y_622_, lean_object* v___y_623_){
_start:
{
lean_object* v___x_625_; 
v___x_625_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___redArg(v_f_616_, v_as_617_, v_i_618_, v_stop_619_, v_b_620_, v___y_621_, v___y_622_, v___y_623_);
return v___x_625_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6___boxed(lean_object* v_00_u03b1_626_, lean_object* v_00_u03b2_627_, lean_object* v_00_u03c3_628_, lean_object* v_f_629_, lean_object* v_as_630_, lean_object* v_i_631_, lean_object* v_stop_632_, lean_object* v_b_633_, lean_object* v___y_634_, lean_object* v___y_635_, lean_object* v___y_636_, lean_object* v___y_637_){
_start:
{
size_t v_i_boxed_638_; size_t v_stop_boxed_639_; lean_object* v_res_640_; 
v_i_boxed_638_ = lean_unbox_usize(v_i_631_);
lean_dec(v_i_631_);
v_stop_boxed_639_ = lean_unbox_usize(v_stop_632_);
lean_dec(v_stop_632_);
v_res_640_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__6(v_00_u03b1_626_, v_00_u03b2_627_, v_00_u03c3_628_, v_f_629_, v_as_630_, v_i_boxed_638_, v_stop_boxed_639_, v_b_633_, v___y_634_, v___y_635_, v___y_636_);
lean_dec_ref(v___y_635_);
lean_dec_ref(v_as_630_);
return v_res_640_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7(lean_object* v_00_u03c3_641_, lean_object* v_00_u03b1_642_, lean_object* v_00_u03b2_643_, lean_object* v_f_644_, lean_object* v_keys_645_, lean_object* v_vals_646_, lean_object* v_heq_647_, lean_object* v_i_648_, lean_object* v_acc_649_, lean_object* v___y_650_, lean_object* v___y_651_, lean_object* v___y_652_){
_start:
{
lean_object* v___x_654_; 
v___x_654_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___redArg(v_f_644_, v_keys_645_, v_vals_646_, v_i_648_, v_acc_649_, v___y_650_, v___y_651_, v___y_652_);
return v___x_654_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7___boxed(lean_object* v_00_u03c3_655_, lean_object* v_00_u03b1_656_, lean_object* v_00_u03b2_657_, lean_object* v_f_658_, lean_object* v_keys_659_, lean_object* v_vals_660_, lean_object* v_heq_661_, lean_object* v_i_662_, lean_object* v_acc_663_, lean_object* v___y_664_, lean_object* v___y_665_, lean_object* v___y_666_, lean_object* v___y_667_){
_start:
{
lean_object* v_res_668_; 
v_res_668_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00CheckedExport_initState_spec__1_spec__2_spec__3_spec__4_spec__7(v_00_u03c3_655_, v_00_u03b1_656_, v_00_u03b2_657_, v_f_658_, v_keys_659_, v_vals_660_, v_heq_661_, v_i_662_, v_acc_663_, v___y_664_, v___y_665_, v___y_666_);
lean_dec_ref(v___y_665_);
lean_dec_ref(v_vals_660_);
lean_dec_ref(v_keys_659_);
return v_res_668_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx___redArg(lean_object* v_inst_670_, lean_object* v_inst_671_, lean_object* v_x_672_, lean_object* v_namespaced_673_, lean_object* v_getM_674_, lean_object* v_setM_675_, lean_object* v_rec_676_, lean_object* v_a_677_, lean_object* v_a_678_){
_start:
{
lean_object* v___x_680_; lean_object* v___x_681_; 
lean_inc_ref(v_getM_674_);
lean_inc_ref(v_a_678_);
v___x_680_ = lean_apply_1(v_getM_674_, v_a_678_);
lean_inc(v_x_672_);
lean_inc_ref(v_inst_670_);
lean_inc_ref(v_inst_671_);
v___x_681_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v_inst_671_, v_inst_670_, v___x_680_, v_x_672_);
lean_dec_ref(v___x_680_);
if (lean_obj_tag(v___x_681_) == 1)
{
lean_object* v_val_682_; lean_object* v___x_684_; uint8_t v_isShared_685_; uint8_t v_isSharedCheck_690_; 
lean_dec_ref(v_rec_676_);
lean_dec_ref(v_setM_675_);
lean_dec_ref(v_getM_674_);
lean_dec_ref(v_namespaced_673_);
lean_dec(v_x_672_);
lean_dec_ref(v_inst_671_);
lean_dec_ref(v_inst_670_);
v_val_682_ = lean_ctor_get(v___x_681_, 0);
v_isSharedCheck_690_ = !lean_is_exclusive(v___x_681_);
if (v_isSharedCheck_690_ == 0)
{
v___x_684_ = v___x_681_;
v_isShared_685_ = v_isSharedCheck_690_;
goto v_resetjp_683_;
}
else
{
lean_inc(v_val_682_);
lean_dec(v___x_681_);
v___x_684_ = lean_box(0);
v_isShared_685_ = v_isSharedCheck_690_;
goto v_resetjp_683_;
}
v_resetjp_683_:
{
lean_object* v___x_686_; lean_object* v___x_688_; 
v___x_686_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_686_, 0, v_val_682_);
lean_ctor_set(v___x_686_, 1, v_a_678_);
if (v_isShared_685_ == 0)
{
lean_ctor_set_tag(v___x_684_, 0);
lean_ctor_set(v___x_684_, 0, v___x_686_);
v___x_688_ = v___x_684_;
goto v_reusejp_687_;
}
else
{
lean_object* v_reuseFailAlloc_689_; 
v_reuseFailAlloc_689_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_689_, 0, v___x_686_);
v___x_688_ = v_reuseFailAlloc_689_;
goto v_reusejp_687_;
}
v_reusejp_687_:
{
return v___x_688_;
}
}
}
else
{
lean_object* v___x_691_; 
lean_dec(v___x_681_);
lean_inc_ref(v_a_677_);
v___x_691_ = lean_apply_3(v_rec_676_, v_a_677_, v_a_678_, lean_box(0));
if (lean_obj_tag(v___x_691_) == 0)
{
lean_object* v_a_692_; lean_object* v_fst_693_; lean_object* v_snd_694_; lean_object* v___x_696_; uint8_t v_isShared_697_; uint8_t v_isSharedCheck_727_; 
v_a_692_ = lean_ctor_get(v___x_691_, 0);
lean_inc(v_a_692_);
lean_dec_ref_known(v___x_691_, 1);
v_fst_693_ = lean_ctor_get(v_a_692_, 0);
v_snd_694_ = lean_ctor_get(v_a_692_, 1);
v_isSharedCheck_727_ = !lean_is_exclusive(v_a_692_);
if (v_isSharedCheck_727_ == 0)
{
v___x_696_ = v_a_692_;
v_isShared_697_ = v_isSharedCheck_727_;
goto v_resetjp_695_;
}
else
{
lean_inc(v_snd_694_);
lean_inc(v_fst_693_);
lean_dec(v_a_692_);
v___x_696_ = lean_box(0);
v_isShared_697_ = v_isSharedCheck_727_;
goto v_resetjp_695_;
}
v_resetjp_695_:
{
lean_object* v___x_698_; lean_object* v_size_699_; lean_object* v___f_700_; lean_object* v___x_701_; lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; 
lean_inc(v_snd_694_);
v___x_698_ = lean_apply_1(v_getM_674_, v_snd_694_);
v_size_699_ = lean_ctor_get(v___x_698_, 0);
lean_inc_n(v_size_699_, 2);
v___f_700_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_getIdx___redArg___closed__0));
v___x_701_ = l_Lean_JsonNumber_fromNat(v_size_699_);
v___x_702_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_702_, 0, v___x_701_);
v___x_703_ = l_Lean_Json_setObjVal_x21(v_fst_693_, v_namespaced_673_, v___x_702_);
v___x_704_ = l_Lean_Json_compress(v___x_703_);
v___x_705_ = l_IO_println___redArg(v___f_700_, v___x_704_);
if (lean_obj_tag(v___x_705_) == 0)
{
lean_object* v___x_707_; uint8_t v_isShared_708_; uint8_t v_isSharedCheck_717_; 
v_isSharedCheck_717_ = !lean_is_exclusive(v___x_705_);
if (v_isSharedCheck_717_ == 0)
{
lean_object* v_unused_718_; 
v_unused_718_ = lean_ctor_get(v___x_705_, 0);
lean_dec(v_unused_718_);
v___x_707_ = v___x_705_;
v_isShared_708_ = v_isSharedCheck_717_;
goto v_resetjp_706_;
}
else
{
lean_dec(v___x_705_);
v___x_707_ = lean_box(0);
v_isShared_708_ = v_isSharedCheck_717_;
goto v_resetjp_706_;
}
v_resetjp_706_:
{
lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v___x_712_; 
lean_inc(v_size_699_);
v___x_709_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v_inst_671_, v_inst_670_, v___x_698_, v_x_672_, v_size_699_);
v___x_710_ = lean_apply_2(v_setM_675_, v_snd_694_, v___x_709_);
if (v_isShared_697_ == 0)
{
lean_ctor_set(v___x_696_, 1, v___x_710_);
lean_ctor_set(v___x_696_, 0, v_size_699_);
v___x_712_ = v___x_696_;
goto v_reusejp_711_;
}
else
{
lean_object* v_reuseFailAlloc_716_; 
v_reuseFailAlloc_716_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_716_, 0, v_size_699_);
lean_ctor_set(v_reuseFailAlloc_716_, 1, v___x_710_);
v___x_712_ = v_reuseFailAlloc_716_;
goto v_reusejp_711_;
}
v_reusejp_711_:
{
lean_object* v___x_714_; 
if (v_isShared_708_ == 0)
{
lean_ctor_set(v___x_707_, 0, v___x_712_);
v___x_714_ = v___x_707_;
goto v_reusejp_713_;
}
else
{
lean_object* v_reuseFailAlloc_715_; 
v_reuseFailAlloc_715_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_715_, 0, v___x_712_);
v___x_714_ = v_reuseFailAlloc_715_;
goto v_reusejp_713_;
}
v_reusejp_713_:
{
return v___x_714_;
}
}
}
}
else
{
lean_object* v_a_719_; lean_object* v___x_721_; uint8_t v_isShared_722_; uint8_t v_isSharedCheck_726_; 
lean_dec(v_size_699_);
lean_dec_ref(v___x_698_);
lean_del_object(v___x_696_);
lean_dec(v_snd_694_);
lean_dec_ref(v_setM_675_);
lean_dec(v_x_672_);
lean_dec_ref(v_inst_671_);
lean_dec_ref(v_inst_670_);
v_a_719_ = lean_ctor_get(v___x_705_, 0);
v_isSharedCheck_726_ = !lean_is_exclusive(v___x_705_);
if (v_isSharedCheck_726_ == 0)
{
v___x_721_ = v___x_705_;
v_isShared_722_ = v_isSharedCheck_726_;
goto v_resetjp_720_;
}
else
{
lean_inc(v_a_719_);
lean_dec(v___x_705_);
v___x_721_ = lean_box(0);
v_isShared_722_ = v_isSharedCheck_726_;
goto v_resetjp_720_;
}
v_resetjp_720_:
{
lean_object* v___x_724_; 
if (v_isShared_722_ == 0)
{
v___x_724_ = v___x_721_;
goto v_reusejp_723_;
}
else
{
lean_object* v_reuseFailAlloc_725_; 
v_reuseFailAlloc_725_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_725_, 0, v_a_719_);
v___x_724_ = v_reuseFailAlloc_725_;
goto v_reusejp_723_;
}
v_reusejp_723_:
{
return v___x_724_;
}
}
}
}
}
else
{
lean_object* v_a_728_; lean_object* v___x_730_; uint8_t v_isShared_731_; uint8_t v_isSharedCheck_735_; 
lean_dec_ref(v_setM_675_);
lean_dec_ref(v_getM_674_);
lean_dec_ref(v_namespaced_673_);
lean_dec(v_x_672_);
lean_dec_ref(v_inst_671_);
lean_dec_ref(v_inst_670_);
v_a_728_ = lean_ctor_get(v___x_691_, 0);
v_isSharedCheck_735_ = !lean_is_exclusive(v___x_691_);
if (v_isSharedCheck_735_ == 0)
{
v___x_730_ = v___x_691_;
v_isShared_731_ = v_isSharedCheck_735_;
goto v_resetjp_729_;
}
else
{
lean_inc(v_a_728_);
lean_dec(v___x_691_);
v___x_730_ = lean_box(0);
v_isShared_731_ = v_isSharedCheck_735_;
goto v_resetjp_729_;
}
v_resetjp_729_:
{
lean_object* v___x_733_; 
if (v_isShared_731_ == 0)
{
v___x_733_ = v___x_730_;
goto v_reusejp_732_;
}
else
{
lean_object* v_reuseFailAlloc_734_; 
v_reuseFailAlloc_734_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_734_, 0, v_a_728_);
v___x_733_ = v_reuseFailAlloc_734_;
goto v_reusejp_732_;
}
v_reusejp_732_:
{
return v___x_733_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx___redArg___boxed(lean_object* v_inst_736_, lean_object* v_inst_737_, lean_object* v_x_738_, lean_object* v_namespaced_739_, lean_object* v_getM_740_, lean_object* v_setM_741_, lean_object* v_rec_742_, lean_object* v_a_743_, lean_object* v_a_744_, lean_object* v_a_745_){
_start:
{
lean_object* v_res_746_; 
v_res_746_ = lp_proofEnvironment_CheckedExport_getIdx___redArg(v_inst_736_, v_inst_737_, v_x_738_, v_namespaced_739_, v_getM_740_, v_setM_741_, v_rec_742_, v_a_743_, v_a_744_);
lean_dec_ref(v_a_743_);
return v_res_746_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx(lean_object* v_00_u03b1_747_, lean_object* v_inst_748_, lean_object* v_inst_749_, lean_object* v_x_750_, lean_object* v_namespaced_751_, lean_object* v_getM_752_, lean_object* v_setM_753_, lean_object* v_rec_754_, lean_object* v_a_755_, lean_object* v_a_756_){
_start:
{
lean_object* v___x_758_; lean_object* v___x_759_; 
lean_inc_ref(v_getM_752_);
lean_inc_ref(v_a_756_);
v___x_758_ = lean_apply_1(v_getM_752_, v_a_756_);
lean_inc(v_x_750_);
lean_inc_ref(v_inst_748_);
lean_inc_ref(v_inst_749_);
v___x_759_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v_inst_749_, v_inst_748_, v___x_758_, v_x_750_);
lean_dec_ref(v___x_758_);
if (lean_obj_tag(v___x_759_) == 1)
{
lean_object* v_val_760_; lean_object* v___x_762_; uint8_t v_isShared_763_; uint8_t v_isSharedCheck_768_; 
lean_dec_ref(v_rec_754_);
lean_dec_ref(v_setM_753_);
lean_dec_ref(v_getM_752_);
lean_dec_ref(v_namespaced_751_);
lean_dec(v_x_750_);
lean_dec_ref(v_inst_749_);
lean_dec_ref(v_inst_748_);
v_val_760_ = lean_ctor_get(v___x_759_, 0);
v_isSharedCheck_768_ = !lean_is_exclusive(v___x_759_);
if (v_isSharedCheck_768_ == 0)
{
v___x_762_ = v___x_759_;
v_isShared_763_ = v_isSharedCheck_768_;
goto v_resetjp_761_;
}
else
{
lean_inc(v_val_760_);
lean_dec(v___x_759_);
v___x_762_ = lean_box(0);
v_isShared_763_ = v_isSharedCheck_768_;
goto v_resetjp_761_;
}
v_resetjp_761_:
{
lean_object* v___x_764_; lean_object* v___x_766_; 
v___x_764_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_764_, 0, v_val_760_);
lean_ctor_set(v___x_764_, 1, v_a_756_);
if (v_isShared_763_ == 0)
{
lean_ctor_set_tag(v___x_762_, 0);
lean_ctor_set(v___x_762_, 0, v___x_764_);
v___x_766_ = v___x_762_;
goto v_reusejp_765_;
}
else
{
lean_object* v_reuseFailAlloc_767_; 
v_reuseFailAlloc_767_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_767_, 0, v___x_764_);
v___x_766_ = v_reuseFailAlloc_767_;
goto v_reusejp_765_;
}
v_reusejp_765_:
{
return v___x_766_;
}
}
}
else
{
lean_object* v___x_769_; 
lean_dec(v___x_759_);
lean_inc_ref(v_a_755_);
v___x_769_ = lean_apply_3(v_rec_754_, v_a_755_, v_a_756_, lean_box(0));
if (lean_obj_tag(v___x_769_) == 0)
{
lean_object* v_a_770_; lean_object* v_fst_771_; lean_object* v_snd_772_; lean_object* v___x_774_; uint8_t v_isShared_775_; uint8_t v_isSharedCheck_805_; 
v_a_770_ = lean_ctor_get(v___x_769_, 0);
lean_inc(v_a_770_);
lean_dec_ref_known(v___x_769_, 1);
v_fst_771_ = lean_ctor_get(v_a_770_, 0);
v_snd_772_ = lean_ctor_get(v_a_770_, 1);
v_isSharedCheck_805_ = !lean_is_exclusive(v_a_770_);
if (v_isSharedCheck_805_ == 0)
{
v___x_774_ = v_a_770_;
v_isShared_775_ = v_isSharedCheck_805_;
goto v_resetjp_773_;
}
else
{
lean_inc(v_snd_772_);
lean_inc(v_fst_771_);
lean_dec(v_a_770_);
v___x_774_ = lean_box(0);
v_isShared_775_ = v_isSharedCheck_805_;
goto v_resetjp_773_;
}
v_resetjp_773_:
{
lean_object* v___x_776_; lean_object* v_size_777_; lean_object* v___f_778_; lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; lean_object* v___x_782_; lean_object* v___x_783_; 
lean_inc(v_snd_772_);
v___x_776_ = lean_apply_1(v_getM_752_, v_snd_772_);
v_size_777_ = lean_ctor_get(v___x_776_, 0);
lean_inc_n(v_size_777_, 2);
v___f_778_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_getIdx___redArg___closed__0));
v___x_779_ = l_Lean_JsonNumber_fromNat(v_size_777_);
v___x_780_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_780_, 0, v___x_779_);
v___x_781_ = l_Lean_Json_setObjVal_x21(v_fst_771_, v_namespaced_751_, v___x_780_);
v___x_782_ = l_Lean_Json_compress(v___x_781_);
v___x_783_ = l_IO_println___redArg(v___f_778_, v___x_782_);
if (lean_obj_tag(v___x_783_) == 0)
{
lean_object* v___x_785_; uint8_t v_isShared_786_; uint8_t v_isSharedCheck_795_; 
v_isSharedCheck_795_ = !lean_is_exclusive(v___x_783_);
if (v_isSharedCheck_795_ == 0)
{
lean_object* v_unused_796_; 
v_unused_796_ = lean_ctor_get(v___x_783_, 0);
lean_dec(v_unused_796_);
v___x_785_ = v___x_783_;
v_isShared_786_ = v_isSharedCheck_795_;
goto v_resetjp_784_;
}
else
{
lean_dec(v___x_783_);
v___x_785_ = lean_box(0);
v_isShared_786_ = v_isSharedCheck_795_;
goto v_resetjp_784_;
}
v_resetjp_784_:
{
lean_object* v___x_787_; lean_object* v___x_788_; lean_object* v___x_790_; 
lean_inc(v_size_777_);
v___x_787_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v_inst_749_, v_inst_748_, v___x_776_, v_x_750_, v_size_777_);
v___x_788_ = lean_apply_2(v_setM_753_, v_snd_772_, v___x_787_);
if (v_isShared_775_ == 0)
{
lean_ctor_set(v___x_774_, 1, v___x_788_);
lean_ctor_set(v___x_774_, 0, v_size_777_);
v___x_790_ = v___x_774_;
goto v_reusejp_789_;
}
else
{
lean_object* v_reuseFailAlloc_794_; 
v_reuseFailAlloc_794_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_794_, 0, v_size_777_);
lean_ctor_set(v_reuseFailAlloc_794_, 1, v___x_788_);
v___x_790_ = v_reuseFailAlloc_794_;
goto v_reusejp_789_;
}
v_reusejp_789_:
{
lean_object* v___x_792_; 
if (v_isShared_786_ == 0)
{
lean_ctor_set(v___x_785_, 0, v___x_790_);
v___x_792_ = v___x_785_;
goto v_reusejp_791_;
}
else
{
lean_object* v_reuseFailAlloc_793_; 
v_reuseFailAlloc_793_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_793_, 0, v___x_790_);
v___x_792_ = v_reuseFailAlloc_793_;
goto v_reusejp_791_;
}
v_reusejp_791_:
{
return v___x_792_;
}
}
}
}
else
{
lean_object* v_a_797_; lean_object* v___x_799_; uint8_t v_isShared_800_; uint8_t v_isSharedCheck_804_; 
lean_dec(v_size_777_);
lean_dec_ref(v___x_776_);
lean_del_object(v___x_774_);
lean_dec(v_snd_772_);
lean_dec_ref(v_setM_753_);
lean_dec(v_x_750_);
lean_dec_ref(v_inst_749_);
lean_dec_ref(v_inst_748_);
v_a_797_ = lean_ctor_get(v___x_783_, 0);
v_isSharedCheck_804_ = !lean_is_exclusive(v___x_783_);
if (v_isSharedCheck_804_ == 0)
{
v___x_799_ = v___x_783_;
v_isShared_800_ = v_isSharedCheck_804_;
goto v_resetjp_798_;
}
else
{
lean_inc(v_a_797_);
lean_dec(v___x_783_);
v___x_799_ = lean_box(0);
v_isShared_800_ = v_isSharedCheck_804_;
goto v_resetjp_798_;
}
v_resetjp_798_:
{
lean_object* v___x_802_; 
if (v_isShared_800_ == 0)
{
v___x_802_ = v___x_799_;
goto v_reusejp_801_;
}
else
{
lean_object* v_reuseFailAlloc_803_; 
v_reuseFailAlloc_803_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_803_, 0, v_a_797_);
v___x_802_ = v_reuseFailAlloc_803_;
goto v_reusejp_801_;
}
v_reusejp_801_:
{
return v___x_802_;
}
}
}
}
}
else
{
lean_object* v_a_806_; lean_object* v___x_808_; uint8_t v_isShared_809_; uint8_t v_isSharedCheck_813_; 
lean_dec_ref(v_setM_753_);
lean_dec_ref(v_getM_752_);
lean_dec_ref(v_namespaced_751_);
lean_dec(v_x_750_);
lean_dec_ref(v_inst_749_);
lean_dec_ref(v_inst_748_);
v_a_806_ = lean_ctor_get(v___x_769_, 0);
v_isSharedCheck_813_ = !lean_is_exclusive(v___x_769_);
if (v_isSharedCheck_813_ == 0)
{
v___x_808_ = v___x_769_;
v_isShared_809_ = v_isSharedCheck_813_;
goto v_resetjp_807_;
}
else
{
lean_inc(v_a_806_);
lean_dec(v___x_769_);
v___x_808_ = lean_box(0);
v_isShared_809_ = v_isSharedCheck_813_;
goto v_resetjp_807_;
}
v_resetjp_807_:
{
lean_object* v___x_811_; 
if (v_isShared_809_ == 0)
{
v___x_811_ = v___x_808_;
goto v_reusejp_810_;
}
else
{
lean_object* v_reuseFailAlloc_812_; 
v_reuseFailAlloc_812_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_812_, 0, v_a_806_);
v___x_811_ = v_reuseFailAlloc_812_;
goto v_reusejp_810_;
}
v_reusejp_810_:
{
return v___x_811_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_getIdx___boxed(lean_object* v_00_u03b1_814_, lean_object* v_inst_815_, lean_object* v_inst_816_, lean_object* v_x_817_, lean_object* v_namespaced_818_, lean_object* v_getM_819_, lean_object* v_setM_820_, lean_object* v_rec_821_, lean_object* v_a_822_, lean_object* v_a_823_, lean_object* v_a_824_){
_start:
{
lean_object* v_res_825_; 
v_res_825_ = lp_proofEnvironment_CheckedExport_getIdx(v_00_u03b1_814_, v_inst_815_, v_inst_816_, v_x_817_, v_namespaced_818_, v_getM_819_, v_setM_820_, v_rec_821_, v_a_822_, v_a_823_);
lean_dec_ref(v_a_822_);
return v_res_825_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0(void){
_start:
{
lean_object* v___x_826_; 
v___x_826_ = l_instMonadEIO(lean_box(0));
return v___x_826_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0(lean_object* v_msg_827_, lean_object* v___y_828_, lean_object* v___y_829_){
_start:
{
lean_object* v___x_831_; lean_object* v___f_832_; lean_object* v___f_833_; lean_object* v___f_834_; lean_object* v___f_835_; lean_object* v___x_836_; lean_object* v___x_837_; lean_object* v___x_838_; lean_object* v___x_839_; lean_object* v___x_840_; lean_object* v___x_841_; lean_object* v___x_842_; lean_object* v___x_843_; lean_object* v___f_844_; lean_object* v___x_1359__overap_845_; lean_object* v___x_846_; 
v___x_831_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0);
v___f_832_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_832_, 0, v___x_831_);
v___f_833_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_833_, 0, v___x_831_);
v___f_834_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_834_, 0, v___x_831_);
v___f_835_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_835_, 0, v___x_831_);
v___x_836_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_836_, 0, lean_box(0));
lean_closure_set(v___x_836_, 1, lean_box(0));
lean_closure_set(v___x_836_, 2, v___x_831_);
v___x_837_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_837_, 0, v___x_836_);
lean_ctor_set(v___x_837_, 1, v___f_832_);
v___x_838_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_838_, 0, lean_box(0));
lean_closure_set(v___x_838_, 1, lean_box(0));
lean_closure_set(v___x_838_, 2, v___x_831_);
v___x_839_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_839_, 0, v___x_837_);
lean_ctor_set(v___x_839_, 1, v___x_838_);
lean_ctor_set(v___x_839_, 2, v___f_833_);
lean_ctor_set(v___x_839_, 3, v___f_834_);
lean_ctor_set(v___x_839_, 4, v___f_835_);
v___x_840_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_840_, 0, lean_box(0));
lean_closure_set(v___x_840_, 1, lean_box(0));
lean_closure_set(v___x_840_, 2, v___x_831_);
v___x_841_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_841_, 0, v___x_839_);
lean_ctor_set(v___x_841_, 1, v___x_840_);
v___x_842_ = lean_box(0);
v___x_843_ = l_instInhabitedOfMonad___redArg(v___x_841_, v___x_842_);
v___f_844_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_844_, 0, v___x_843_);
v___x_1359__overap_845_ = lean_panic_fn_borrowed(v___f_844_, v_msg_827_);
lean_dec_ref(v___f_844_);
lean_inc_ref(v___y_828_);
v___x_846_ = lean_apply_3(v___x_1359__overap_845_, v___y_828_, v___y_829_, lean_box(0));
return v___x_846_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___boxed(lean_object* v_msg_847_, lean_object* v___y_848_, lean_object* v___y_849_, lean_object* v___y_850_){
_start:
{
lean_object* v_res_851_; 
v_res_851_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0(v_msg_847_, v___y_848_, v___y_849_);
lean_dec_ref(v___y_848_);
return v_res_851_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_dumpName___closed__4(void){
_start:
{
lean_object* v___x_856_; lean_object* v___x_857_; lean_object* v___x_858_; lean_object* v___x_859_; lean_object* v___x_860_; lean_object* v___x_861_; 
v___x_856_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__3));
v___x_857_ = lean_unsigned_to_nat(18u);
v___x_858_ = lean_unsigned_to_nat(70u);
v___x_859_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__2));
v___x_860_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_861_ = l_mkPanicMessageWithDecl(v___x_860_, v___x_859_, v___x_858_, v___x_857_, v___x_856_);
return v___x_861_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpName(lean_object* v_n_866_, lean_object* v_a_867_, lean_object* v_a_868_){
_start:
{
lean_object* v_visitedNames_870_; lean_object* v___x_871_; 
v_visitedNames_870_ = lean_ctor_get(v_a_868_, 0);
v___x_871_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(v_visitedNames_870_, v_n_866_);
if (lean_obj_tag(v___x_871_) == 1)
{
lean_object* v_val_872_; lean_object* v___x_874_; uint8_t v_isShared_875_; uint8_t v_isSharedCheck_880_; 
lean_dec(v_n_866_);
v_val_872_ = lean_ctor_get(v___x_871_, 0);
v_isSharedCheck_880_ = !lean_is_exclusive(v___x_871_);
if (v_isSharedCheck_880_ == 0)
{
v___x_874_ = v___x_871_;
v_isShared_875_ = v_isSharedCheck_880_;
goto v_resetjp_873_;
}
else
{
lean_inc(v_val_872_);
lean_dec(v___x_871_);
v___x_874_ = lean_box(0);
v_isShared_875_ = v_isSharedCheck_880_;
goto v_resetjp_873_;
}
v_resetjp_873_:
{
lean_object* v___x_876_; lean_object* v___x_878_; 
v___x_876_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_876_, 0, v_val_872_);
lean_ctor_set(v___x_876_, 1, v_a_868_);
if (v_isShared_875_ == 0)
{
lean_ctor_set_tag(v___x_874_, 0);
lean_ctor_set(v___x_874_, 0, v___x_876_);
v___x_878_ = v___x_874_;
goto v_reusejp_877_;
}
else
{
lean_object* v_reuseFailAlloc_879_; 
v_reuseFailAlloc_879_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_879_, 0, v___x_876_);
v___x_878_ = v_reuseFailAlloc_879_;
goto v_reusejp_877_;
}
v_reusejp_877_:
{
return v___x_878_;
}
}
}
else
{
lean_object* v___x_881_; lean_object* v_fst_883_; lean_object* v_snd_884_; 
lean_dec(v___x_871_);
v___x_881_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__0));
switch(lean_obj_tag(v_n_866_))
{
case 0:
{
lean_object* v___x_925_; lean_object* v___x_926_; 
v___x_925_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_dumpName___closed__4, &lp_proofEnvironment_CheckedExport_dumpName___closed__4_once, _init_lp_proofEnvironment_CheckedExport_dumpName___closed__4);
v___x_926_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0(v___x_925_, v_a_867_, v_a_868_);
if (lean_obj_tag(v___x_926_) == 0)
{
lean_object* v_a_927_; lean_object* v_fst_928_; lean_object* v_snd_929_; 
v_a_927_ = lean_ctor_get(v___x_926_, 0);
lean_inc(v_a_927_);
lean_dec_ref_known(v___x_926_, 1);
v_fst_928_ = lean_ctor_get(v_a_927_, 0);
lean_inc(v_fst_928_);
v_snd_929_ = lean_ctor_get(v_a_927_, 1);
lean_inc(v_snd_929_);
lean_dec(v_a_927_);
v_fst_883_ = v_fst_928_;
v_snd_884_ = v_snd_929_;
goto v___jp_882_;
}
else
{
lean_object* v_a_930_; lean_object* v___x_932_; uint8_t v_isShared_933_; uint8_t v_isSharedCheck_937_; 
v_a_930_ = lean_ctor_get(v___x_926_, 0);
v_isSharedCheck_937_ = !lean_is_exclusive(v___x_926_);
if (v_isSharedCheck_937_ == 0)
{
v___x_932_ = v___x_926_;
v_isShared_933_ = v_isSharedCheck_937_;
goto v_resetjp_931_;
}
else
{
lean_inc(v_a_930_);
lean_dec(v___x_926_);
v___x_932_ = lean_box(0);
v_isShared_933_ = v_isSharedCheck_937_;
goto v_resetjp_931_;
}
v_resetjp_931_:
{
lean_object* v___x_935_; 
if (v_isShared_933_ == 0)
{
v___x_935_ = v___x_932_;
goto v_reusejp_934_;
}
else
{
lean_object* v_reuseFailAlloc_936_; 
v_reuseFailAlloc_936_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_936_, 0, v_a_930_);
v___x_935_ = v_reuseFailAlloc_936_;
goto v_reusejp_934_;
}
v_reusejp_934_:
{
return v___x_935_;
}
}
}
}
case 1:
{
lean_object* v_pre_938_; lean_object* v_str_939_; lean_object* v___x_940_; 
v_pre_938_ = lean_ctor_get(v_n_866_, 0);
v_str_939_ = lean_ctor_get(v_n_866_, 1);
lean_inc(v_pre_938_);
v___x_940_ = lp_proofEnvironment_CheckedExport_dumpName(v_pre_938_, v_a_867_, v_a_868_);
if (lean_obj_tag(v___x_940_) == 0)
{
lean_object* v_a_941_; lean_object* v___x_943_; uint8_t v_isShared_944_; uint8_t v_isSharedCheck_969_; 
v_a_941_ = lean_ctor_get(v___x_940_, 0);
v_isSharedCheck_969_ = !lean_is_exclusive(v___x_940_);
if (v_isSharedCheck_969_ == 0)
{
v___x_943_ = v___x_940_;
v_isShared_944_ = v_isSharedCheck_969_;
goto v_resetjp_942_;
}
else
{
lean_inc(v_a_941_);
lean_dec(v___x_940_);
v___x_943_ = lean_box(0);
v_isShared_944_ = v_isSharedCheck_969_;
goto v_resetjp_942_;
}
v_resetjp_942_:
{
lean_object* v_fst_945_; lean_object* v_snd_946_; lean_object* v___x_948_; uint8_t v_isShared_949_; uint8_t v_isSharedCheck_968_; 
v_fst_945_ = lean_ctor_get(v_a_941_, 0);
v_snd_946_ = lean_ctor_get(v_a_941_, 1);
v_isSharedCheck_968_ = !lean_is_exclusive(v_a_941_);
if (v_isSharedCheck_968_ == 0)
{
v___x_948_ = v_a_941_;
v_isShared_949_ = v_isSharedCheck_968_;
goto v_resetjp_947_;
}
else
{
lean_inc(v_snd_946_);
lean_inc(v_fst_945_);
lean_dec(v_a_941_);
v___x_948_ = lean_box(0);
v_isShared_949_ = v_isSharedCheck_968_;
goto v_resetjp_947_;
}
v_resetjp_947_:
{
lean_object* v___x_950_; lean_object* v___x_951_; lean_object* v___x_952_; lean_object* v___x_954_; 
v___x_950_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__5));
v___x_951_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__6));
v___x_952_ = l_Lean_JsonNumber_fromNat(v_fst_945_);
if (v_isShared_944_ == 0)
{
lean_ctor_set_tag(v___x_943_, 2);
lean_ctor_set(v___x_943_, 0, v___x_952_);
v___x_954_ = v___x_943_;
goto v_reusejp_953_;
}
else
{
lean_object* v_reuseFailAlloc_967_; 
v_reuseFailAlloc_967_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_967_, 0, v___x_952_);
v___x_954_ = v_reuseFailAlloc_967_;
goto v_reusejp_953_;
}
v_reusejp_953_:
{
lean_object* v___x_956_; 
if (v_isShared_949_ == 0)
{
lean_ctor_set(v___x_948_, 1, v___x_954_);
lean_ctor_set(v___x_948_, 0, v___x_951_);
v___x_956_ = v___x_948_;
goto v_reusejp_955_;
}
else
{
lean_object* v_reuseFailAlloc_966_; 
v_reuseFailAlloc_966_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_966_, 0, v___x_951_);
lean_ctor_set(v_reuseFailAlloc_966_, 1, v___x_954_);
v___x_956_ = v_reuseFailAlloc_966_;
goto v_reusejp_955_;
}
v_reusejp_955_:
{
lean_object* v___x_957_; lean_object* v___x_958_; lean_object* v___x_959_; lean_object* v___x_960_; lean_object* v___x_961_; lean_object* v___x_962_; lean_object* v___x_963_; lean_object* v___x_964_; lean_object* v___x_965_; 
lean_inc_ref(v_str_939_);
v___x_957_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_957_, 0, v_str_939_);
v___x_958_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_958_, 0, v___x_950_);
lean_ctor_set(v___x_958_, 1, v___x_957_);
v___x_959_ = lean_box(0);
v___x_960_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_960_, 0, v___x_958_);
lean_ctor_set(v___x_960_, 1, v___x_959_);
v___x_961_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_961_, 0, v___x_956_);
lean_ctor_set(v___x_961_, 1, v___x_960_);
v___x_962_ = l_Lean_Json_mkObj(v___x_961_);
lean_dec_ref_known(v___x_961_, 2);
v___x_963_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_963_, 0, v___x_950_);
lean_ctor_set(v___x_963_, 1, v___x_962_);
v___x_964_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_964_, 0, v___x_963_);
lean_ctor_set(v___x_964_, 1, v___x_959_);
v___x_965_ = l_Lean_Json_mkObj(v___x_964_);
lean_dec_ref_known(v___x_964_, 2);
v_fst_883_ = v___x_965_;
v_snd_884_ = v_snd_946_;
goto v___jp_882_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_n_866_, 2);
return v___x_940_;
}
}
default: 
{
lean_object* v_pre_970_; lean_object* v_i_971_; lean_object* v___x_972_; 
v_pre_970_ = lean_ctor_get(v_n_866_, 0);
v_i_971_ = lean_ctor_get(v_n_866_, 1);
lean_inc(v_pre_970_);
v___x_972_ = lp_proofEnvironment_CheckedExport_dumpName(v_pre_970_, v_a_867_, v_a_868_);
if (lean_obj_tag(v___x_972_) == 0)
{
lean_object* v_a_973_; lean_object* v___x_975_; uint8_t v_isShared_976_; uint8_t v_isSharedCheck_1003_; 
v_a_973_ = lean_ctor_get(v___x_972_, 0);
v_isSharedCheck_1003_ = !lean_is_exclusive(v___x_972_);
if (v_isSharedCheck_1003_ == 0)
{
v___x_975_ = v___x_972_;
v_isShared_976_ = v_isSharedCheck_1003_;
goto v_resetjp_974_;
}
else
{
lean_inc(v_a_973_);
lean_dec(v___x_972_);
v___x_975_ = lean_box(0);
v_isShared_976_ = v_isSharedCheck_1003_;
goto v_resetjp_974_;
}
v_resetjp_974_:
{
lean_object* v_fst_977_; lean_object* v_snd_978_; lean_object* v___x_980_; uint8_t v_isShared_981_; uint8_t v_isSharedCheck_1002_; 
v_fst_977_ = lean_ctor_get(v_a_973_, 0);
v_snd_978_ = lean_ctor_get(v_a_973_, 1);
v_isSharedCheck_1002_ = !lean_is_exclusive(v_a_973_);
if (v_isSharedCheck_1002_ == 0)
{
v___x_980_ = v_a_973_;
v_isShared_981_ = v_isSharedCheck_1002_;
goto v_resetjp_979_;
}
else
{
lean_inc(v_snd_978_);
lean_inc(v_fst_977_);
lean_dec(v_a_973_);
v___x_980_ = lean_box(0);
v_isShared_981_ = v_isSharedCheck_1002_;
goto v_resetjp_979_;
}
v_resetjp_979_:
{
lean_object* v___x_982_; lean_object* v___x_983_; lean_object* v___x_984_; lean_object* v___x_986_; 
v___x_982_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__7));
v___x_983_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__6));
v___x_984_ = l_Lean_JsonNumber_fromNat(v_fst_977_);
if (v_isShared_976_ == 0)
{
lean_ctor_set_tag(v___x_975_, 2);
lean_ctor_set(v___x_975_, 0, v___x_984_);
v___x_986_ = v___x_975_;
goto v_reusejp_985_;
}
else
{
lean_object* v_reuseFailAlloc_1001_; 
v_reuseFailAlloc_1001_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1001_, 0, v___x_984_);
v___x_986_ = v_reuseFailAlloc_1001_;
goto v_reusejp_985_;
}
v_reusejp_985_:
{
lean_object* v___x_988_; 
if (v_isShared_981_ == 0)
{
lean_ctor_set(v___x_980_, 1, v___x_986_);
lean_ctor_set(v___x_980_, 0, v___x_983_);
v___x_988_ = v___x_980_;
goto v_reusejp_987_;
}
else
{
lean_object* v_reuseFailAlloc_1000_; 
v_reuseFailAlloc_1000_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1000_, 0, v___x_983_);
lean_ctor_set(v_reuseFailAlloc_1000_, 1, v___x_986_);
v___x_988_ = v_reuseFailAlloc_1000_;
goto v_reusejp_987_;
}
v_reusejp_987_:
{
lean_object* v___x_989_; lean_object* v___x_990_; lean_object* v___x_991_; lean_object* v___x_992_; lean_object* v___x_993_; lean_object* v___x_994_; lean_object* v___x_995_; lean_object* v___x_996_; lean_object* v___x_997_; lean_object* v___x_998_; lean_object* v___x_999_; 
v___x_989_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__8));
lean_inc(v_i_971_);
v___x_990_ = l_Lean_JsonNumber_fromNat(v_i_971_);
v___x_991_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_991_, 0, v___x_990_);
v___x_992_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_992_, 0, v___x_989_);
lean_ctor_set(v___x_992_, 1, v___x_991_);
v___x_993_ = lean_box(0);
v___x_994_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_994_, 0, v___x_992_);
lean_ctor_set(v___x_994_, 1, v___x_993_);
v___x_995_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_995_, 0, v___x_988_);
lean_ctor_set(v___x_995_, 1, v___x_994_);
v___x_996_ = l_Lean_Json_mkObj(v___x_995_);
lean_dec_ref_known(v___x_995_, 2);
v___x_997_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_997_, 0, v___x_982_);
lean_ctor_set(v___x_997_, 1, v___x_996_);
v___x_998_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_998_, 0, v___x_997_);
lean_ctor_set(v___x_998_, 1, v___x_993_);
v___x_999_ = l_Lean_Json_mkObj(v___x_998_);
lean_dec_ref_known(v___x_998_, 2);
v_fst_883_ = v___x_999_;
v_snd_884_ = v_snd_978_;
goto v___jp_882_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_n_866_, 2);
return v___x_972_;
}
}
}
v___jp_882_:
{
lean_object* v_visitedNames_885_; lean_object* v_visitedLevels_886_; lean_object* v_visitedExprs_887_; lean_object* v_visitedConstants_888_; lean_object* v_noMDataExprs_889_; uint8_t v_exportMData_890_; uint8_t v_exportUnsafe_891_; uint8_t v_ignoreMissing_892_; lean_object* v_recursorMap_893_; lean_object* v___x_895_; uint8_t v_isShared_896_; uint8_t v_isSharedCheck_924_; 
v_visitedNames_885_ = lean_ctor_get(v_snd_884_, 0);
v_visitedLevels_886_ = lean_ctor_get(v_snd_884_, 1);
v_visitedExprs_887_ = lean_ctor_get(v_snd_884_, 2);
v_visitedConstants_888_ = lean_ctor_get(v_snd_884_, 3);
v_noMDataExprs_889_ = lean_ctor_get(v_snd_884_, 4);
v_exportMData_890_ = lean_ctor_get_uint8(v_snd_884_, sizeof(void*)*6);
v_exportUnsafe_891_ = lean_ctor_get_uint8(v_snd_884_, sizeof(void*)*6 + 1);
v_ignoreMissing_892_ = lean_ctor_get_uint8(v_snd_884_, sizeof(void*)*6 + 2);
v_recursorMap_893_ = lean_ctor_get(v_snd_884_, 5);
v_isSharedCheck_924_ = !lean_is_exclusive(v_snd_884_);
if (v_isSharedCheck_924_ == 0)
{
v___x_895_ = v_snd_884_;
v_isShared_896_ = v_isSharedCheck_924_;
goto v_resetjp_894_;
}
else
{
lean_inc(v_recursorMap_893_);
lean_inc(v_noMDataExprs_889_);
lean_inc(v_visitedConstants_888_);
lean_inc(v_visitedExprs_887_);
lean_inc(v_visitedLevels_886_);
lean_inc(v_visitedNames_885_);
lean_dec(v_snd_884_);
v___x_895_ = lean_box(0);
v_isShared_896_ = v_isSharedCheck_924_;
goto v_resetjp_894_;
}
v_resetjp_894_:
{
lean_object* v_size_897_; lean_object* v___x_898_; lean_object* v___x_899_; lean_object* v___x_900_; lean_object* v___x_901_; lean_object* v___x_902_; 
v_size_897_ = lean_ctor_get(v_visitedNames_885_, 0);
lean_inc_n(v_size_897_, 2);
v___x_898_ = l_Lean_JsonNumber_fromNat(v_size_897_);
v___x_899_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_899_, 0, v___x_898_);
v___x_900_ = l_Lean_Json_setObjVal_x21(v_fst_883_, v___x_881_, v___x_899_);
v___x_901_ = l_Lean_Json_compress(v___x_900_);
v___x_902_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_901_);
if (lean_obj_tag(v___x_902_) == 0)
{
lean_object* v___x_904_; uint8_t v_isShared_905_; uint8_t v_isSharedCheck_914_; 
v_isSharedCheck_914_ = !lean_is_exclusive(v___x_902_);
if (v_isSharedCheck_914_ == 0)
{
lean_object* v_unused_915_; 
v_unused_915_ = lean_ctor_get(v___x_902_, 0);
lean_dec(v_unused_915_);
v___x_904_ = v___x_902_;
v_isShared_905_ = v_isSharedCheck_914_;
goto v_resetjp_903_;
}
else
{
lean_dec(v___x_902_);
v___x_904_ = lean_box(0);
v_isShared_905_ = v_isSharedCheck_914_;
goto v_resetjp_903_;
}
v_resetjp_903_:
{
lean_object* v___x_906_; lean_object* v___x_908_; 
lean_inc(v_size_897_);
v___x_906_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__1___redArg(v_visitedNames_885_, v_n_866_, v_size_897_);
if (v_isShared_896_ == 0)
{
lean_ctor_set(v___x_895_, 0, v___x_906_);
v___x_908_ = v___x_895_;
goto v_reusejp_907_;
}
else
{
lean_object* v_reuseFailAlloc_913_; 
v_reuseFailAlloc_913_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_913_, 0, v___x_906_);
lean_ctor_set(v_reuseFailAlloc_913_, 1, v_visitedLevels_886_);
lean_ctor_set(v_reuseFailAlloc_913_, 2, v_visitedExprs_887_);
lean_ctor_set(v_reuseFailAlloc_913_, 3, v_visitedConstants_888_);
lean_ctor_set(v_reuseFailAlloc_913_, 4, v_noMDataExprs_889_);
lean_ctor_set(v_reuseFailAlloc_913_, 5, v_recursorMap_893_);
lean_ctor_set_uint8(v_reuseFailAlloc_913_, sizeof(void*)*6, v_exportMData_890_);
lean_ctor_set_uint8(v_reuseFailAlloc_913_, sizeof(void*)*6 + 1, v_exportUnsafe_891_);
lean_ctor_set_uint8(v_reuseFailAlloc_913_, sizeof(void*)*6 + 2, v_ignoreMissing_892_);
v___x_908_ = v_reuseFailAlloc_913_;
goto v_reusejp_907_;
}
v_reusejp_907_:
{
lean_object* v___x_909_; lean_object* v___x_911_; 
v___x_909_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_909_, 0, v_size_897_);
lean_ctor_set(v___x_909_, 1, v___x_908_);
if (v_isShared_905_ == 0)
{
lean_ctor_set(v___x_904_, 0, v___x_909_);
v___x_911_ = v___x_904_;
goto v_reusejp_910_;
}
else
{
lean_object* v_reuseFailAlloc_912_; 
v_reuseFailAlloc_912_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_912_, 0, v___x_909_);
v___x_911_ = v_reuseFailAlloc_912_;
goto v_reusejp_910_;
}
v_reusejp_910_:
{
return v___x_911_;
}
}
}
}
else
{
lean_object* v_a_916_; lean_object* v___x_918_; uint8_t v_isShared_919_; uint8_t v_isSharedCheck_923_; 
lean_dec(v_size_897_);
lean_del_object(v___x_895_);
lean_dec(v_recursorMap_893_);
lean_dec_ref(v_noMDataExprs_889_);
lean_dec_ref(v_visitedConstants_888_);
lean_dec_ref(v_visitedExprs_887_);
lean_dec_ref(v_visitedLevels_886_);
lean_dec_ref(v_visitedNames_885_);
lean_dec(v_n_866_);
v_a_916_ = lean_ctor_get(v___x_902_, 0);
v_isSharedCheck_923_ = !lean_is_exclusive(v___x_902_);
if (v_isSharedCheck_923_ == 0)
{
v___x_918_ = v___x_902_;
v_isShared_919_ = v_isSharedCheck_923_;
goto v_resetjp_917_;
}
else
{
lean_inc(v_a_916_);
lean_dec(v___x_902_);
v___x_918_ = lean_box(0);
v_isShared_919_ = v_isSharedCheck_923_;
goto v_resetjp_917_;
}
v_resetjp_917_:
{
lean_object* v___x_921_; 
if (v_isShared_919_ == 0)
{
v___x_921_ = v___x_918_;
goto v_reusejp_920_;
}
else
{
lean_object* v_reuseFailAlloc_922_; 
v_reuseFailAlloc_922_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_922_, 0, v_a_916_);
v___x_921_ = v_reuseFailAlloc_922_;
goto v_reusejp_920_;
}
v_reusejp_920_:
{
return v___x_921_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpName___boxed(lean_object* v_n_1004_, lean_object* v_a_1005_, lean_object* v_a_1006_, lean_object* v_a_1007_){
_start:
{
lean_object* v_res_1008_; 
v_res_1008_ = lp_proofEnvironment_CheckedExport_dumpName(v_n_1004_, v_a_1005_, v_a_1006_);
lean_dec_ref(v_a_1005_);
return v_res_1008_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_dumpLevel___closed__6(void){
_start:
{
lean_object* v___x_1015_; lean_object* v___x_1016_; lean_object* v___x_1017_; lean_object* v___x_1018_; lean_object* v___x_1019_; lean_object* v___x_1020_; 
v___x_1015_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__3));
v___x_1016_ = lean_unsigned_to_nat(23u);
v___x_1017_ = lean_unsigned_to_nat(88u);
v___x_1018_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpLevel___closed__5));
v___x_1019_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_1020_ = l_mkPanicMessageWithDecl(v___x_1019_, v___x_1018_, v___x_1017_, v___x_1016_, v___x_1015_);
return v___x_1020_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpLevel(lean_object* v_l_1021_, lean_object* v_a_1022_, lean_object* v_a_1023_){
_start:
{
lean_object* v_visitedLevels_1025_; lean_object* v___x_1026_; 
v_visitedLevels_1025_ = lean_ctor_get(v_a_1023_, 1);
v___x_1026_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_simplifyResultingUniverse_simp_spec__2___redArg(v_visitedLevels_1025_, v_l_1021_);
if (lean_obj_tag(v___x_1026_) == 1)
{
lean_object* v_val_1027_; lean_object* v___x_1029_; uint8_t v_isShared_1030_; uint8_t v_isSharedCheck_1035_; 
lean_dec(v_l_1021_);
v_val_1027_ = lean_ctor_get(v___x_1026_, 0);
v_isSharedCheck_1035_ = !lean_is_exclusive(v___x_1026_);
if (v_isSharedCheck_1035_ == 0)
{
v___x_1029_ = v___x_1026_;
v_isShared_1030_ = v_isSharedCheck_1035_;
goto v_resetjp_1028_;
}
else
{
lean_inc(v_val_1027_);
lean_dec(v___x_1026_);
v___x_1029_ = lean_box(0);
v_isShared_1030_ = v_isSharedCheck_1035_;
goto v_resetjp_1028_;
}
v_resetjp_1028_:
{
lean_object* v___x_1031_; lean_object* v___x_1033_; 
v___x_1031_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1031_, 0, v_val_1027_);
lean_ctor_set(v___x_1031_, 1, v_a_1023_);
if (v_isShared_1030_ == 0)
{
lean_ctor_set_tag(v___x_1029_, 0);
lean_ctor_set(v___x_1029_, 0, v___x_1031_);
v___x_1033_ = v___x_1029_;
goto v_reusejp_1032_;
}
else
{
lean_object* v_reuseFailAlloc_1034_; 
v_reuseFailAlloc_1034_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1034_, 0, v___x_1031_);
v___x_1033_ = v_reuseFailAlloc_1034_;
goto v_reusejp_1032_;
}
v_reusejp_1032_:
{
return v___x_1033_;
}
}
}
else
{
lean_object* v___x_1036_; lean_object* v_fst_1038_; lean_object* v_snd_1039_; 
lean_dec(v___x_1026_);
v___x_1036_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpLevel___closed__0));
switch(lean_obj_tag(v_l_1021_))
{
case 1:
{
lean_object* v_a_1080_; lean_object* v___x_1081_; 
v_a_1080_ = lean_ctor_get(v_l_1021_, 0);
lean_inc(v_a_1080_);
v___x_1081_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_a_1080_, v_a_1022_, v_a_1023_);
if (lean_obj_tag(v___x_1081_) == 0)
{
lean_object* v_a_1082_; lean_object* v___x_1084_; uint8_t v_isShared_1085_; uint8_t v_isSharedCheck_1103_; 
v_a_1082_ = lean_ctor_get(v___x_1081_, 0);
v_isSharedCheck_1103_ = !lean_is_exclusive(v___x_1081_);
if (v_isSharedCheck_1103_ == 0)
{
v___x_1084_ = v___x_1081_;
v_isShared_1085_ = v_isSharedCheck_1103_;
goto v_resetjp_1083_;
}
else
{
lean_inc(v_a_1082_);
lean_dec(v___x_1081_);
v___x_1084_ = lean_box(0);
v_isShared_1085_ = v_isSharedCheck_1103_;
goto v_resetjp_1083_;
}
v_resetjp_1083_:
{
lean_object* v_fst_1086_; lean_object* v_snd_1087_; lean_object* v___x_1089_; uint8_t v_isShared_1090_; uint8_t v_isSharedCheck_1102_; 
v_fst_1086_ = lean_ctor_get(v_a_1082_, 0);
v_snd_1087_ = lean_ctor_get(v_a_1082_, 1);
v_isSharedCheck_1102_ = !lean_is_exclusive(v_a_1082_);
if (v_isSharedCheck_1102_ == 0)
{
v___x_1089_ = v_a_1082_;
v_isShared_1090_ = v_isSharedCheck_1102_;
goto v_resetjp_1088_;
}
else
{
lean_inc(v_snd_1087_);
lean_inc(v_fst_1086_);
lean_dec(v_a_1082_);
v___x_1089_ = lean_box(0);
v_isShared_1090_ = v_isSharedCheck_1102_;
goto v_resetjp_1088_;
}
v_resetjp_1088_:
{
lean_object* v___x_1091_; lean_object* v___x_1092_; lean_object* v___x_1094_; 
v___x_1091_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpLevel___closed__1));
v___x_1092_ = l_Lean_JsonNumber_fromNat(v_fst_1086_);
if (v_isShared_1085_ == 0)
{
lean_ctor_set_tag(v___x_1084_, 2);
lean_ctor_set(v___x_1084_, 0, v___x_1092_);
v___x_1094_ = v___x_1084_;
goto v_reusejp_1093_;
}
else
{
lean_object* v_reuseFailAlloc_1101_; 
v_reuseFailAlloc_1101_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1101_, 0, v___x_1092_);
v___x_1094_ = v_reuseFailAlloc_1101_;
goto v_reusejp_1093_;
}
v_reusejp_1093_:
{
lean_object* v___x_1096_; 
if (v_isShared_1090_ == 0)
{
lean_ctor_set(v___x_1089_, 1, v___x_1094_);
lean_ctor_set(v___x_1089_, 0, v___x_1091_);
v___x_1096_ = v___x_1089_;
goto v_reusejp_1095_;
}
else
{
lean_object* v_reuseFailAlloc_1100_; 
v_reuseFailAlloc_1100_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1100_, 0, v___x_1091_);
lean_ctor_set(v_reuseFailAlloc_1100_, 1, v___x_1094_);
v___x_1096_ = v_reuseFailAlloc_1100_;
goto v_reusejp_1095_;
}
v_reusejp_1095_:
{
lean_object* v___x_1097_; lean_object* v___x_1098_; lean_object* v___x_1099_; 
v___x_1097_ = lean_box(0);
v___x_1098_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1098_, 0, v___x_1096_);
lean_ctor_set(v___x_1098_, 1, v___x_1097_);
v___x_1099_ = l_Lean_Json_mkObj(v___x_1098_);
lean_dec_ref_known(v___x_1098_, 2);
v_fst_1038_ = v___x_1099_;
v_snd_1039_ = v_snd_1087_;
goto v___jp_1037_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_l_1021_, 1);
return v___x_1081_;
}
}
case 2:
{
lean_object* v_a_1104_; lean_object* v_a_1105_; lean_object* v___x_1106_; 
v_a_1104_ = lean_ctor_get(v_l_1021_, 0);
v_a_1105_ = lean_ctor_get(v_l_1021_, 1);
lean_inc(v_a_1104_);
v___x_1106_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_a_1104_, v_a_1022_, v_a_1023_);
if (lean_obj_tag(v___x_1106_) == 0)
{
lean_object* v_a_1107_; lean_object* v___x_1109_; uint8_t v_isShared_1110_; uint8_t v_isSharedCheck_1151_; 
v_a_1107_ = lean_ctor_get(v___x_1106_, 0);
v_isSharedCheck_1151_ = !lean_is_exclusive(v___x_1106_);
if (v_isSharedCheck_1151_ == 0)
{
v___x_1109_ = v___x_1106_;
v_isShared_1110_ = v_isSharedCheck_1151_;
goto v_resetjp_1108_;
}
else
{
lean_inc(v_a_1107_);
lean_dec(v___x_1106_);
v___x_1109_ = lean_box(0);
v_isShared_1110_ = v_isSharedCheck_1151_;
goto v_resetjp_1108_;
}
v_resetjp_1108_:
{
lean_object* v_fst_1111_; lean_object* v_snd_1112_; lean_object* v___x_1114_; uint8_t v_isShared_1115_; uint8_t v_isSharedCheck_1150_; 
v_fst_1111_ = lean_ctor_get(v_a_1107_, 0);
v_snd_1112_ = lean_ctor_get(v_a_1107_, 1);
v_isSharedCheck_1150_ = !lean_is_exclusive(v_a_1107_);
if (v_isSharedCheck_1150_ == 0)
{
v___x_1114_ = v_a_1107_;
v_isShared_1115_ = v_isSharedCheck_1150_;
goto v_resetjp_1113_;
}
else
{
lean_inc(v_snd_1112_);
lean_inc(v_fst_1111_);
lean_dec(v_a_1107_);
v___x_1114_ = lean_box(0);
v_isShared_1115_ = v_isSharedCheck_1150_;
goto v_resetjp_1113_;
}
v_resetjp_1113_:
{
lean_object* v___x_1116_; 
lean_inc(v_a_1105_);
v___x_1116_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_a_1105_, v_a_1022_, v_snd_1112_);
if (lean_obj_tag(v___x_1116_) == 0)
{
lean_object* v_a_1117_; lean_object* v___x_1119_; uint8_t v_isShared_1120_; uint8_t v_isSharedCheck_1149_; 
v_a_1117_ = lean_ctor_get(v___x_1116_, 0);
v_isSharedCheck_1149_ = !lean_is_exclusive(v___x_1116_);
if (v_isSharedCheck_1149_ == 0)
{
v___x_1119_ = v___x_1116_;
v_isShared_1120_ = v_isSharedCheck_1149_;
goto v_resetjp_1118_;
}
else
{
lean_inc(v_a_1117_);
lean_dec(v___x_1116_);
v___x_1119_ = lean_box(0);
v_isShared_1120_ = v_isSharedCheck_1149_;
goto v_resetjp_1118_;
}
v_resetjp_1118_:
{
lean_object* v_fst_1121_; lean_object* v_snd_1122_; lean_object* v___x_1124_; uint8_t v_isShared_1125_; uint8_t v_isSharedCheck_1148_; 
v_fst_1121_ = lean_ctor_get(v_a_1117_, 0);
v_snd_1122_ = lean_ctor_get(v_a_1117_, 1);
v_isSharedCheck_1148_ = !lean_is_exclusive(v_a_1117_);
if (v_isSharedCheck_1148_ == 0)
{
v___x_1124_ = v_a_1117_;
v_isShared_1125_ = v_isSharedCheck_1148_;
goto v_resetjp_1123_;
}
else
{
lean_inc(v_snd_1122_);
lean_inc(v_fst_1121_);
lean_dec(v_a_1117_);
v___x_1124_ = lean_box(0);
v_isShared_1125_ = v_isSharedCheck_1148_;
goto v_resetjp_1123_;
}
v_resetjp_1123_:
{
lean_object* v___x_1126_; lean_object* v___x_1127_; lean_object* v___x_1129_; 
v___x_1126_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpLevel___closed__2));
v___x_1127_ = l_Lean_JsonNumber_fromNat(v_fst_1111_);
if (v_isShared_1120_ == 0)
{
lean_ctor_set_tag(v___x_1119_, 2);
lean_ctor_set(v___x_1119_, 0, v___x_1127_);
v___x_1129_ = v___x_1119_;
goto v_reusejp_1128_;
}
else
{
lean_object* v_reuseFailAlloc_1147_; 
v_reuseFailAlloc_1147_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1147_, 0, v___x_1127_);
v___x_1129_ = v_reuseFailAlloc_1147_;
goto v_reusejp_1128_;
}
v_reusejp_1128_:
{
lean_object* v___x_1130_; lean_object* v___x_1132_; 
v___x_1130_ = l_Lean_JsonNumber_fromNat(v_fst_1121_);
if (v_isShared_1110_ == 0)
{
lean_ctor_set_tag(v___x_1109_, 2);
lean_ctor_set(v___x_1109_, 0, v___x_1130_);
v___x_1132_ = v___x_1109_;
goto v_reusejp_1131_;
}
else
{
lean_object* v_reuseFailAlloc_1146_; 
v_reuseFailAlloc_1146_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1146_, 0, v___x_1130_);
v___x_1132_ = v_reuseFailAlloc_1146_;
goto v_reusejp_1131_;
}
v_reusejp_1131_:
{
lean_object* v___x_1133_; lean_object* v___x_1134_; lean_object* v___x_1135_; lean_object* v___x_1136_; lean_object* v___x_1137_; lean_object* v___x_1139_; 
v___x_1133_ = lean_unsigned_to_nat(2u);
v___x_1134_ = lean_mk_empty_array_with_capacity(v___x_1133_);
v___x_1135_ = lean_array_push(v___x_1134_, v___x_1129_);
v___x_1136_ = lean_array_push(v___x_1135_, v___x_1132_);
v___x_1137_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_1137_, 0, v___x_1136_);
if (v_isShared_1125_ == 0)
{
lean_ctor_set(v___x_1124_, 1, v___x_1137_);
lean_ctor_set(v___x_1124_, 0, v___x_1126_);
v___x_1139_ = v___x_1124_;
goto v_reusejp_1138_;
}
else
{
lean_object* v_reuseFailAlloc_1145_; 
v_reuseFailAlloc_1145_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1145_, 0, v___x_1126_);
lean_ctor_set(v_reuseFailAlloc_1145_, 1, v___x_1137_);
v___x_1139_ = v_reuseFailAlloc_1145_;
goto v_reusejp_1138_;
}
v_reusejp_1138_:
{
lean_object* v___x_1140_; lean_object* v___x_1142_; 
v___x_1140_ = lean_box(0);
if (v_isShared_1115_ == 0)
{
lean_ctor_set_tag(v___x_1114_, 1);
lean_ctor_set(v___x_1114_, 1, v___x_1140_);
lean_ctor_set(v___x_1114_, 0, v___x_1139_);
v___x_1142_ = v___x_1114_;
goto v_reusejp_1141_;
}
else
{
lean_object* v_reuseFailAlloc_1144_; 
v_reuseFailAlloc_1144_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1144_, 0, v___x_1139_);
lean_ctor_set(v_reuseFailAlloc_1144_, 1, v___x_1140_);
v___x_1142_ = v_reuseFailAlloc_1144_;
goto v_reusejp_1141_;
}
v_reusejp_1141_:
{
lean_object* v___x_1143_; 
v___x_1143_ = l_Lean_Json_mkObj(v___x_1142_);
lean_dec_ref(v___x_1142_);
v_fst_1038_ = v___x_1143_;
v_snd_1039_ = v_snd_1122_;
goto v___jp_1037_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_1114_);
lean_dec(v_fst_1111_);
lean_del_object(v___x_1109_);
lean_dec_ref_known(v_l_1021_, 2);
return v___x_1116_;
}
}
}
}
else
{
lean_dec_ref_known(v_l_1021_, 2);
return v___x_1106_;
}
}
case 3:
{
lean_object* v_a_1152_; lean_object* v_a_1153_; lean_object* v___x_1154_; 
v_a_1152_ = lean_ctor_get(v_l_1021_, 0);
v_a_1153_ = lean_ctor_get(v_l_1021_, 1);
lean_inc(v_a_1152_);
v___x_1154_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_a_1152_, v_a_1022_, v_a_1023_);
if (lean_obj_tag(v___x_1154_) == 0)
{
lean_object* v_a_1155_; lean_object* v___x_1157_; uint8_t v_isShared_1158_; uint8_t v_isSharedCheck_1199_; 
v_a_1155_ = lean_ctor_get(v___x_1154_, 0);
v_isSharedCheck_1199_ = !lean_is_exclusive(v___x_1154_);
if (v_isSharedCheck_1199_ == 0)
{
v___x_1157_ = v___x_1154_;
v_isShared_1158_ = v_isSharedCheck_1199_;
goto v_resetjp_1156_;
}
else
{
lean_inc(v_a_1155_);
lean_dec(v___x_1154_);
v___x_1157_ = lean_box(0);
v_isShared_1158_ = v_isSharedCheck_1199_;
goto v_resetjp_1156_;
}
v_resetjp_1156_:
{
lean_object* v_fst_1159_; lean_object* v_snd_1160_; lean_object* v___x_1162_; uint8_t v_isShared_1163_; uint8_t v_isSharedCheck_1198_; 
v_fst_1159_ = lean_ctor_get(v_a_1155_, 0);
v_snd_1160_ = lean_ctor_get(v_a_1155_, 1);
v_isSharedCheck_1198_ = !lean_is_exclusive(v_a_1155_);
if (v_isSharedCheck_1198_ == 0)
{
v___x_1162_ = v_a_1155_;
v_isShared_1163_ = v_isSharedCheck_1198_;
goto v_resetjp_1161_;
}
else
{
lean_inc(v_snd_1160_);
lean_inc(v_fst_1159_);
lean_dec(v_a_1155_);
v___x_1162_ = lean_box(0);
v_isShared_1163_ = v_isSharedCheck_1198_;
goto v_resetjp_1161_;
}
v_resetjp_1161_:
{
lean_object* v___x_1164_; 
lean_inc(v_a_1153_);
v___x_1164_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_a_1153_, v_a_1022_, v_snd_1160_);
if (lean_obj_tag(v___x_1164_) == 0)
{
lean_object* v_a_1165_; lean_object* v___x_1167_; uint8_t v_isShared_1168_; uint8_t v_isSharedCheck_1197_; 
v_a_1165_ = lean_ctor_get(v___x_1164_, 0);
v_isSharedCheck_1197_ = !lean_is_exclusive(v___x_1164_);
if (v_isSharedCheck_1197_ == 0)
{
v___x_1167_ = v___x_1164_;
v_isShared_1168_ = v_isSharedCheck_1197_;
goto v_resetjp_1166_;
}
else
{
lean_inc(v_a_1165_);
lean_dec(v___x_1164_);
v___x_1167_ = lean_box(0);
v_isShared_1168_ = v_isSharedCheck_1197_;
goto v_resetjp_1166_;
}
v_resetjp_1166_:
{
lean_object* v_fst_1169_; lean_object* v_snd_1170_; lean_object* v___x_1172_; uint8_t v_isShared_1173_; uint8_t v_isSharedCheck_1196_; 
v_fst_1169_ = lean_ctor_get(v_a_1165_, 0);
v_snd_1170_ = lean_ctor_get(v_a_1165_, 1);
v_isSharedCheck_1196_ = !lean_is_exclusive(v_a_1165_);
if (v_isSharedCheck_1196_ == 0)
{
v___x_1172_ = v_a_1165_;
v_isShared_1173_ = v_isSharedCheck_1196_;
goto v_resetjp_1171_;
}
else
{
lean_inc(v_snd_1170_);
lean_inc(v_fst_1169_);
lean_dec(v_a_1165_);
v___x_1172_ = lean_box(0);
v_isShared_1173_ = v_isSharedCheck_1196_;
goto v_resetjp_1171_;
}
v_resetjp_1171_:
{
lean_object* v___x_1174_; lean_object* v___x_1175_; lean_object* v___x_1177_; 
v___x_1174_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpLevel___closed__3));
v___x_1175_ = l_Lean_JsonNumber_fromNat(v_fst_1159_);
if (v_isShared_1168_ == 0)
{
lean_ctor_set_tag(v___x_1167_, 2);
lean_ctor_set(v___x_1167_, 0, v___x_1175_);
v___x_1177_ = v___x_1167_;
goto v_reusejp_1176_;
}
else
{
lean_object* v_reuseFailAlloc_1195_; 
v_reuseFailAlloc_1195_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1195_, 0, v___x_1175_);
v___x_1177_ = v_reuseFailAlloc_1195_;
goto v_reusejp_1176_;
}
v_reusejp_1176_:
{
lean_object* v___x_1178_; lean_object* v___x_1180_; 
v___x_1178_ = l_Lean_JsonNumber_fromNat(v_fst_1169_);
if (v_isShared_1158_ == 0)
{
lean_ctor_set_tag(v___x_1157_, 2);
lean_ctor_set(v___x_1157_, 0, v___x_1178_);
v___x_1180_ = v___x_1157_;
goto v_reusejp_1179_;
}
else
{
lean_object* v_reuseFailAlloc_1194_; 
v_reuseFailAlloc_1194_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1194_, 0, v___x_1178_);
v___x_1180_ = v_reuseFailAlloc_1194_;
goto v_reusejp_1179_;
}
v_reusejp_1179_:
{
lean_object* v___x_1181_; lean_object* v___x_1182_; lean_object* v___x_1183_; lean_object* v___x_1184_; lean_object* v___x_1185_; lean_object* v___x_1187_; 
v___x_1181_ = lean_unsigned_to_nat(2u);
v___x_1182_ = lean_mk_empty_array_with_capacity(v___x_1181_);
v___x_1183_ = lean_array_push(v___x_1182_, v___x_1177_);
v___x_1184_ = lean_array_push(v___x_1183_, v___x_1180_);
v___x_1185_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_1185_, 0, v___x_1184_);
if (v_isShared_1173_ == 0)
{
lean_ctor_set(v___x_1172_, 1, v___x_1185_);
lean_ctor_set(v___x_1172_, 0, v___x_1174_);
v___x_1187_ = v___x_1172_;
goto v_reusejp_1186_;
}
else
{
lean_object* v_reuseFailAlloc_1193_; 
v_reuseFailAlloc_1193_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1193_, 0, v___x_1174_);
lean_ctor_set(v_reuseFailAlloc_1193_, 1, v___x_1185_);
v___x_1187_ = v_reuseFailAlloc_1193_;
goto v_reusejp_1186_;
}
v_reusejp_1186_:
{
lean_object* v___x_1188_; lean_object* v___x_1190_; 
v___x_1188_ = lean_box(0);
if (v_isShared_1163_ == 0)
{
lean_ctor_set_tag(v___x_1162_, 1);
lean_ctor_set(v___x_1162_, 1, v___x_1188_);
lean_ctor_set(v___x_1162_, 0, v___x_1187_);
v___x_1190_ = v___x_1162_;
goto v_reusejp_1189_;
}
else
{
lean_object* v_reuseFailAlloc_1192_; 
v_reuseFailAlloc_1192_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1192_, 0, v___x_1187_);
lean_ctor_set(v_reuseFailAlloc_1192_, 1, v___x_1188_);
v___x_1190_ = v_reuseFailAlloc_1192_;
goto v_reusejp_1189_;
}
v_reusejp_1189_:
{
lean_object* v___x_1191_; 
v___x_1191_ = l_Lean_Json_mkObj(v___x_1190_);
lean_dec_ref(v___x_1190_);
v_fst_1038_ = v___x_1191_;
v_snd_1039_ = v_snd_1170_;
goto v___jp_1037_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_1162_);
lean_dec(v_fst_1159_);
lean_del_object(v___x_1157_);
lean_dec_ref_known(v_l_1021_, 2);
return v___x_1164_;
}
}
}
}
else
{
lean_dec_ref_known(v_l_1021_, 2);
return v___x_1154_;
}
}
case 4:
{
lean_object* v_a_1200_; lean_object* v___x_1201_; 
v_a_1200_ = lean_ctor_get(v_l_1021_, 0);
lean_inc(v_a_1200_);
v___x_1201_ = lp_proofEnvironment_CheckedExport_dumpName(v_a_1200_, v_a_1022_, v_a_1023_);
if (lean_obj_tag(v___x_1201_) == 0)
{
lean_object* v_a_1202_; lean_object* v___x_1204_; uint8_t v_isShared_1205_; uint8_t v_isSharedCheck_1223_; 
v_a_1202_ = lean_ctor_get(v___x_1201_, 0);
v_isSharedCheck_1223_ = !lean_is_exclusive(v___x_1201_);
if (v_isSharedCheck_1223_ == 0)
{
v___x_1204_ = v___x_1201_;
v_isShared_1205_ = v_isSharedCheck_1223_;
goto v_resetjp_1203_;
}
else
{
lean_inc(v_a_1202_);
lean_dec(v___x_1201_);
v___x_1204_ = lean_box(0);
v_isShared_1205_ = v_isSharedCheck_1223_;
goto v_resetjp_1203_;
}
v_resetjp_1203_:
{
lean_object* v_fst_1206_; lean_object* v_snd_1207_; lean_object* v___x_1209_; uint8_t v_isShared_1210_; uint8_t v_isSharedCheck_1222_; 
v_fst_1206_ = lean_ctor_get(v_a_1202_, 0);
v_snd_1207_ = lean_ctor_get(v_a_1202_, 1);
v_isSharedCheck_1222_ = !lean_is_exclusive(v_a_1202_);
if (v_isSharedCheck_1222_ == 0)
{
v___x_1209_ = v_a_1202_;
v_isShared_1210_ = v_isSharedCheck_1222_;
goto v_resetjp_1208_;
}
else
{
lean_inc(v_snd_1207_);
lean_inc(v_fst_1206_);
lean_dec(v_a_1202_);
v___x_1209_ = lean_box(0);
v_isShared_1210_ = v_isSharedCheck_1222_;
goto v_resetjp_1208_;
}
v_resetjp_1208_:
{
lean_object* v___x_1211_; lean_object* v___x_1212_; lean_object* v___x_1214_; 
v___x_1211_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpLevel___closed__4));
v___x_1212_ = l_Lean_JsonNumber_fromNat(v_fst_1206_);
if (v_isShared_1205_ == 0)
{
lean_ctor_set_tag(v___x_1204_, 2);
lean_ctor_set(v___x_1204_, 0, v___x_1212_);
v___x_1214_ = v___x_1204_;
goto v_reusejp_1213_;
}
else
{
lean_object* v_reuseFailAlloc_1221_; 
v_reuseFailAlloc_1221_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1221_, 0, v___x_1212_);
v___x_1214_ = v_reuseFailAlloc_1221_;
goto v_reusejp_1213_;
}
v_reusejp_1213_:
{
lean_object* v___x_1216_; 
if (v_isShared_1210_ == 0)
{
lean_ctor_set(v___x_1209_, 1, v___x_1214_);
lean_ctor_set(v___x_1209_, 0, v___x_1211_);
v___x_1216_ = v___x_1209_;
goto v_reusejp_1215_;
}
else
{
lean_object* v_reuseFailAlloc_1220_; 
v_reuseFailAlloc_1220_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1220_, 0, v___x_1211_);
lean_ctor_set(v_reuseFailAlloc_1220_, 1, v___x_1214_);
v___x_1216_ = v_reuseFailAlloc_1220_;
goto v_reusejp_1215_;
}
v_reusejp_1215_:
{
lean_object* v___x_1217_; lean_object* v___x_1218_; lean_object* v___x_1219_; 
v___x_1217_ = lean_box(0);
v___x_1218_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1218_, 0, v___x_1216_);
lean_ctor_set(v___x_1218_, 1, v___x_1217_);
v___x_1219_ = l_Lean_Json_mkObj(v___x_1218_);
lean_dec_ref_known(v___x_1218_, 2);
v_fst_1038_ = v___x_1219_;
v_snd_1039_ = v_snd_1207_;
goto v___jp_1037_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_l_1021_, 1);
return v___x_1201_;
}
}
default: 
{
lean_object* v___x_1224_; lean_object* v___x_1225_; 
v___x_1224_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_dumpLevel___closed__6, &lp_proofEnvironment_CheckedExport_dumpLevel___closed__6_once, _init_lp_proofEnvironment_CheckedExport_dumpLevel___closed__6);
v___x_1225_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0(v___x_1224_, v_a_1022_, v_a_1023_);
if (lean_obj_tag(v___x_1225_) == 0)
{
lean_object* v_a_1226_; lean_object* v_fst_1227_; lean_object* v_snd_1228_; 
v_a_1226_ = lean_ctor_get(v___x_1225_, 0);
lean_inc(v_a_1226_);
lean_dec_ref_known(v___x_1225_, 1);
v_fst_1227_ = lean_ctor_get(v_a_1226_, 0);
lean_inc(v_fst_1227_);
v_snd_1228_ = lean_ctor_get(v_a_1226_, 1);
lean_inc(v_snd_1228_);
lean_dec(v_a_1226_);
v_fst_1038_ = v_fst_1227_;
v_snd_1039_ = v_snd_1228_;
goto v___jp_1037_;
}
else
{
lean_object* v_a_1229_; lean_object* v___x_1231_; uint8_t v_isShared_1232_; uint8_t v_isSharedCheck_1236_; 
lean_dec(v_l_1021_);
v_a_1229_ = lean_ctor_get(v___x_1225_, 0);
v_isSharedCheck_1236_ = !lean_is_exclusive(v___x_1225_);
if (v_isSharedCheck_1236_ == 0)
{
v___x_1231_ = v___x_1225_;
v_isShared_1232_ = v_isSharedCheck_1236_;
goto v_resetjp_1230_;
}
else
{
lean_inc(v_a_1229_);
lean_dec(v___x_1225_);
v___x_1231_ = lean_box(0);
v_isShared_1232_ = v_isSharedCheck_1236_;
goto v_resetjp_1230_;
}
v_resetjp_1230_:
{
lean_object* v___x_1234_; 
if (v_isShared_1232_ == 0)
{
v___x_1234_ = v___x_1231_;
goto v_reusejp_1233_;
}
else
{
lean_object* v_reuseFailAlloc_1235_; 
v_reuseFailAlloc_1235_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1235_, 0, v_a_1229_);
v___x_1234_ = v_reuseFailAlloc_1235_;
goto v_reusejp_1233_;
}
v_reusejp_1233_:
{
return v___x_1234_;
}
}
}
}
}
v___jp_1037_:
{
lean_object* v_visitedLevels_1040_; lean_object* v_visitedNames_1041_; lean_object* v_visitedExprs_1042_; lean_object* v_visitedConstants_1043_; lean_object* v_noMDataExprs_1044_; uint8_t v_exportMData_1045_; uint8_t v_exportUnsafe_1046_; uint8_t v_ignoreMissing_1047_; lean_object* v_recursorMap_1048_; lean_object* v___x_1050_; uint8_t v_isShared_1051_; uint8_t v_isSharedCheck_1079_; 
v_visitedLevels_1040_ = lean_ctor_get(v_snd_1039_, 1);
v_visitedNames_1041_ = lean_ctor_get(v_snd_1039_, 0);
v_visitedExprs_1042_ = lean_ctor_get(v_snd_1039_, 2);
v_visitedConstants_1043_ = lean_ctor_get(v_snd_1039_, 3);
v_noMDataExprs_1044_ = lean_ctor_get(v_snd_1039_, 4);
v_exportMData_1045_ = lean_ctor_get_uint8(v_snd_1039_, sizeof(void*)*6);
v_exportUnsafe_1046_ = lean_ctor_get_uint8(v_snd_1039_, sizeof(void*)*6 + 1);
v_ignoreMissing_1047_ = lean_ctor_get_uint8(v_snd_1039_, sizeof(void*)*6 + 2);
v_recursorMap_1048_ = lean_ctor_get(v_snd_1039_, 5);
v_isSharedCheck_1079_ = !lean_is_exclusive(v_snd_1039_);
if (v_isSharedCheck_1079_ == 0)
{
v___x_1050_ = v_snd_1039_;
v_isShared_1051_ = v_isSharedCheck_1079_;
goto v_resetjp_1049_;
}
else
{
lean_inc(v_recursorMap_1048_);
lean_inc(v_noMDataExprs_1044_);
lean_inc(v_visitedConstants_1043_);
lean_inc(v_visitedExprs_1042_);
lean_inc(v_visitedLevels_1040_);
lean_inc(v_visitedNames_1041_);
lean_dec(v_snd_1039_);
v___x_1050_ = lean_box(0);
v_isShared_1051_ = v_isSharedCheck_1079_;
goto v_resetjp_1049_;
}
v_resetjp_1049_:
{
lean_object* v_size_1052_; lean_object* v___x_1053_; lean_object* v___x_1054_; lean_object* v___x_1055_; lean_object* v___x_1056_; lean_object* v___x_1057_; 
v_size_1052_ = lean_ctor_get(v_visitedLevels_1040_, 0);
lean_inc_n(v_size_1052_, 2);
v___x_1053_ = l_Lean_JsonNumber_fromNat(v_size_1052_);
v___x_1054_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1054_, 0, v___x_1053_);
v___x_1055_ = l_Lean_Json_setObjVal_x21(v_fst_1038_, v___x_1036_, v___x_1054_);
v___x_1056_ = l_Lean_Json_compress(v___x_1055_);
v___x_1057_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1056_);
if (lean_obj_tag(v___x_1057_) == 0)
{
lean_object* v___x_1059_; uint8_t v_isShared_1060_; uint8_t v_isSharedCheck_1069_; 
v_isSharedCheck_1069_ = !lean_is_exclusive(v___x_1057_);
if (v_isSharedCheck_1069_ == 0)
{
lean_object* v_unused_1070_; 
v_unused_1070_ = lean_ctor_get(v___x_1057_, 0);
lean_dec(v_unused_1070_);
v___x_1059_ = v___x_1057_;
v_isShared_1060_ = v_isSharedCheck_1069_;
goto v_resetjp_1058_;
}
else
{
lean_dec(v___x_1057_);
v___x_1059_ = lean_box(0);
v_isShared_1060_ = v_isSharedCheck_1069_;
goto v_resetjp_1058_;
}
v_resetjp_1058_:
{
lean_object* v___x_1061_; lean_object* v___x_1063_; 
lean_inc(v_size_1052_);
v___x_1061_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_AccLevelState_push_spec__0___redArg(v_visitedLevels_1040_, v_l_1021_, v_size_1052_);
if (v_isShared_1051_ == 0)
{
lean_ctor_set(v___x_1050_, 1, v___x_1061_);
v___x_1063_ = v___x_1050_;
goto v_reusejp_1062_;
}
else
{
lean_object* v_reuseFailAlloc_1068_; 
v_reuseFailAlloc_1068_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_1068_, 0, v_visitedNames_1041_);
lean_ctor_set(v_reuseFailAlloc_1068_, 1, v___x_1061_);
lean_ctor_set(v_reuseFailAlloc_1068_, 2, v_visitedExprs_1042_);
lean_ctor_set(v_reuseFailAlloc_1068_, 3, v_visitedConstants_1043_);
lean_ctor_set(v_reuseFailAlloc_1068_, 4, v_noMDataExprs_1044_);
lean_ctor_set(v_reuseFailAlloc_1068_, 5, v_recursorMap_1048_);
lean_ctor_set_uint8(v_reuseFailAlloc_1068_, sizeof(void*)*6, v_exportMData_1045_);
lean_ctor_set_uint8(v_reuseFailAlloc_1068_, sizeof(void*)*6 + 1, v_exportUnsafe_1046_);
lean_ctor_set_uint8(v_reuseFailAlloc_1068_, sizeof(void*)*6 + 2, v_ignoreMissing_1047_);
v___x_1063_ = v_reuseFailAlloc_1068_;
goto v_reusejp_1062_;
}
v_reusejp_1062_:
{
lean_object* v___x_1064_; lean_object* v___x_1066_; 
v___x_1064_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1064_, 0, v_size_1052_);
lean_ctor_set(v___x_1064_, 1, v___x_1063_);
if (v_isShared_1060_ == 0)
{
lean_ctor_set(v___x_1059_, 0, v___x_1064_);
v___x_1066_ = v___x_1059_;
goto v_reusejp_1065_;
}
else
{
lean_object* v_reuseFailAlloc_1067_; 
v_reuseFailAlloc_1067_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1067_, 0, v___x_1064_);
v___x_1066_ = v_reuseFailAlloc_1067_;
goto v_reusejp_1065_;
}
v_reusejp_1065_:
{
return v___x_1066_;
}
}
}
}
else
{
lean_object* v_a_1071_; lean_object* v___x_1073_; uint8_t v_isShared_1074_; uint8_t v_isSharedCheck_1078_; 
lean_dec(v_size_1052_);
lean_del_object(v___x_1050_);
lean_dec(v_recursorMap_1048_);
lean_dec_ref(v_noMDataExprs_1044_);
lean_dec_ref(v_visitedConstants_1043_);
lean_dec_ref(v_visitedExprs_1042_);
lean_dec_ref(v_visitedNames_1041_);
lean_dec_ref(v_visitedLevels_1040_);
lean_dec(v_l_1021_);
v_a_1071_ = lean_ctor_get(v___x_1057_, 0);
v_isSharedCheck_1078_ = !lean_is_exclusive(v___x_1057_);
if (v_isSharedCheck_1078_ == 0)
{
v___x_1073_ = v___x_1057_;
v_isShared_1074_ = v_isSharedCheck_1078_;
goto v_resetjp_1072_;
}
else
{
lean_inc(v_a_1071_);
lean_dec(v___x_1057_);
v___x_1073_ = lean_box(0);
v_isShared_1074_ = v_isSharedCheck_1078_;
goto v_resetjp_1072_;
}
v_resetjp_1072_:
{
lean_object* v___x_1076_; 
if (v_isShared_1074_ == 0)
{
v___x_1076_ = v___x_1073_;
goto v_reusejp_1075_;
}
else
{
lean_object* v_reuseFailAlloc_1077_; 
v_reuseFailAlloc_1077_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1077_, 0, v_a_1071_);
v___x_1076_ = v_reuseFailAlloc_1077_;
goto v_reusejp_1075_;
}
v_reusejp_1075_:
{
return v___x_1076_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpLevel___boxed(lean_object* v_l_1237_, lean_object* v_a_1238_, lean_object* v_a_1239_, lean_object* v_a_1240_){
_start:
{
lean_object* v_res_1241_; 
v_res_1241_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_l_1237_, v_a_1238_, v_a_1239_);
lean_dec_ref(v_a_1238_);
return v_res_1241_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1(lean_object* v_x_1242_, lean_object* v_x_1243_, lean_object* v___y_1244_, lean_object* v___y_1245_){
_start:
{
if (lean_obj_tag(v_x_1242_) == 0)
{
lean_object* v___x_1247_; lean_object* v___x_1248_; lean_object* v___x_1249_; 
v___x_1247_ = l_List_reverse___redArg(v_x_1243_);
v___x_1248_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1248_, 0, v___x_1247_);
lean_ctor_set(v___x_1248_, 1, v___y_1245_);
v___x_1249_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1249_, 0, v___x_1248_);
return v___x_1249_;
}
else
{
lean_object* v_head_1250_; lean_object* v_tail_1251_; lean_object* v___x_1253_; uint8_t v_isShared_1254_; uint8_t v_isSharedCheck_1271_; 
v_head_1250_ = lean_ctor_get(v_x_1242_, 0);
v_tail_1251_ = lean_ctor_get(v_x_1242_, 1);
v_isSharedCheck_1271_ = !lean_is_exclusive(v_x_1242_);
if (v_isSharedCheck_1271_ == 0)
{
v___x_1253_ = v_x_1242_;
v_isShared_1254_ = v_isSharedCheck_1271_;
goto v_resetjp_1252_;
}
else
{
lean_inc(v_tail_1251_);
lean_inc(v_head_1250_);
lean_dec(v_x_1242_);
v___x_1253_ = lean_box(0);
v_isShared_1254_ = v_isSharedCheck_1271_;
goto v_resetjp_1252_;
}
v_resetjp_1252_:
{
lean_object* v___x_1255_; 
v___x_1255_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_head_1250_, v___y_1244_, v___y_1245_);
if (lean_obj_tag(v___x_1255_) == 0)
{
lean_object* v_a_1256_; lean_object* v_fst_1257_; lean_object* v_snd_1258_; lean_object* v___x_1260_; 
v_a_1256_ = lean_ctor_get(v___x_1255_, 0);
lean_inc(v_a_1256_);
lean_dec_ref_known(v___x_1255_, 1);
v_fst_1257_ = lean_ctor_get(v_a_1256_, 0);
lean_inc(v_fst_1257_);
v_snd_1258_ = lean_ctor_get(v_a_1256_, 1);
lean_inc(v_snd_1258_);
lean_dec(v_a_1256_);
if (v_isShared_1254_ == 0)
{
lean_ctor_set(v___x_1253_, 1, v_x_1243_);
lean_ctor_set(v___x_1253_, 0, v_fst_1257_);
v___x_1260_ = v___x_1253_;
goto v_reusejp_1259_;
}
else
{
lean_object* v_reuseFailAlloc_1262_; 
v_reuseFailAlloc_1262_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1262_, 0, v_fst_1257_);
lean_ctor_set(v_reuseFailAlloc_1262_, 1, v_x_1243_);
v___x_1260_ = v_reuseFailAlloc_1262_;
goto v_reusejp_1259_;
}
v_reusejp_1259_:
{
v_x_1242_ = v_tail_1251_;
v_x_1243_ = v___x_1260_;
v___y_1245_ = v_snd_1258_;
goto _start;
}
}
else
{
lean_object* v_a_1263_; lean_object* v___x_1265_; uint8_t v_isShared_1266_; uint8_t v_isSharedCheck_1270_; 
lean_del_object(v___x_1253_);
lean_dec(v_tail_1251_);
lean_dec(v_x_1243_);
v_a_1263_ = lean_ctor_get(v___x_1255_, 0);
v_isSharedCheck_1270_ = !lean_is_exclusive(v___x_1255_);
if (v_isSharedCheck_1270_ == 0)
{
v___x_1265_ = v___x_1255_;
v_isShared_1266_ = v_isSharedCheck_1270_;
goto v_resetjp_1264_;
}
else
{
lean_inc(v_a_1263_);
lean_dec(v___x_1255_);
v___x_1265_ = lean_box(0);
v_isShared_1266_ = v_isSharedCheck_1270_;
goto v_resetjp_1264_;
}
v_resetjp_1264_:
{
lean_object* v___x_1268_; 
if (v_isShared_1266_ == 0)
{
v___x_1268_ = v___x_1265_;
goto v_reusejp_1267_;
}
else
{
lean_object* v_reuseFailAlloc_1269_; 
v_reuseFailAlloc_1269_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1269_, 0, v_a_1263_);
v___x_1268_ = v_reuseFailAlloc_1269_;
goto v_reusejp_1267_;
}
v_reusejp_1267_:
{
return v___x_1268_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1___boxed(lean_object* v_x_1272_, lean_object* v_x_1273_, lean_object* v___y_1274_, lean_object* v___y_1275_, lean_object* v___y_1276_){
_start:
{
lean_object* v_res_1277_; 
v_res_1277_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1(v_x_1272_, v_x_1273_, v___y_1274_, v___y_1275_);
lean_dec_ref(v___y_1274_);
return v_res_1277_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0(lean_object* v_x_1278_, lean_object* v_x_1279_, lean_object* v___y_1280_, lean_object* v___y_1281_){
_start:
{
if (lean_obj_tag(v_x_1278_) == 0)
{
lean_object* v___x_1283_; lean_object* v___x_1284_; lean_object* v___x_1285_; 
v___x_1283_ = l_List_reverse___redArg(v_x_1279_);
v___x_1284_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1284_, 0, v___x_1283_);
lean_ctor_set(v___x_1284_, 1, v___y_1281_);
v___x_1285_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1285_, 0, v___x_1284_);
return v___x_1285_;
}
else
{
lean_object* v_head_1286_; lean_object* v_tail_1287_; lean_object* v___x_1289_; uint8_t v_isShared_1290_; uint8_t v_isSharedCheck_1307_; 
v_head_1286_ = lean_ctor_get(v_x_1278_, 0);
v_tail_1287_ = lean_ctor_get(v_x_1278_, 1);
v_isSharedCheck_1307_ = !lean_is_exclusive(v_x_1278_);
if (v_isSharedCheck_1307_ == 0)
{
v___x_1289_ = v_x_1278_;
v_isShared_1290_ = v_isSharedCheck_1307_;
goto v_resetjp_1288_;
}
else
{
lean_inc(v_tail_1287_);
lean_inc(v_head_1286_);
lean_dec(v_x_1278_);
v___x_1289_ = lean_box(0);
v_isShared_1290_ = v_isSharedCheck_1307_;
goto v_resetjp_1288_;
}
v_resetjp_1288_:
{
lean_object* v___x_1291_; 
v___x_1291_ = lp_proofEnvironment_CheckedExport_dumpName(v_head_1286_, v___y_1280_, v___y_1281_);
if (lean_obj_tag(v___x_1291_) == 0)
{
lean_object* v_a_1292_; lean_object* v_fst_1293_; lean_object* v_snd_1294_; lean_object* v___x_1296_; 
v_a_1292_ = lean_ctor_get(v___x_1291_, 0);
lean_inc(v_a_1292_);
lean_dec_ref_known(v___x_1291_, 1);
v_fst_1293_ = lean_ctor_get(v_a_1292_, 0);
lean_inc(v_fst_1293_);
v_snd_1294_ = lean_ctor_get(v_a_1292_, 1);
lean_inc(v_snd_1294_);
lean_dec(v_a_1292_);
if (v_isShared_1290_ == 0)
{
lean_ctor_set(v___x_1289_, 1, v_x_1279_);
lean_ctor_set(v___x_1289_, 0, v_fst_1293_);
v___x_1296_ = v___x_1289_;
goto v_reusejp_1295_;
}
else
{
lean_object* v_reuseFailAlloc_1298_; 
v_reuseFailAlloc_1298_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1298_, 0, v_fst_1293_);
lean_ctor_set(v_reuseFailAlloc_1298_, 1, v_x_1279_);
v___x_1296_ = v_reuseFailAlloc_1298_;
goto v_reusejp_1295_;
}
v_reusejp_1295_:
{
v_x_1278_ = v_tail_1287_;
v_x_1279_ = v___x_1296_;
v___y_1281_ = v_snd_1294_;
goto _start;
}
}
else
{
lean_object* v_a_1299_; lean_object* v___x_1301_; uint8_t v_isShared_1302_; uint8_t v_isSharedCheck_1306_; 
lean_del_object(v___x_1289_);
lean_dec(v_tail_1287_);
lean_dec(v_x_1279_);
v_a_1299_ = lean_ctor_get(v___x_1291_, 0);
v_isSharedCheck_1306_ = !lean_is_exclusive(v___x_1291_);
if (v_isSharedCheck_1306_ == 0)
{
v___x_1301_ = v___x_1291_;
v_isShared_1302_ = v_isSharedCheck_1306_;
goto v_resetjp_1300_;
}
else
{
lean_inc(v_a_1299_);
lean_dec(v___x_1291_);
v___x_1301_ = lean_box(0);
v_isShared_1302_ = v_isSharedCheck_1306_;
goto v_resetjp_1300_;
}
v_resetjp_1300_:
{
lean_object* v___x_1304_; 
if (v_isShared_1302_ == 0)
{
v___x_1304_ = v___x_1301_;
goto v_reusejp_1303_;
}
else
{
lean_object* v_reuseFailAlloc_1305_; 
v_reuseFailAlloc_1305_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1305_, 0, v_a_1299_);
v___x_1304_ = v_reuseFailAlloc_1305_;
goto v_reusejp_1303_;
}
v_reusejp_1303_:
{
return v___x_1304_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0___boxed(lean_object* v_x_1308_, lean_object* v_x_1309_, lean_object* v___y_1310_, lean_object* v___y_1311_, lean_object* v___y_1312_){
_start:
{
lean_object* v_res_1313_; 
v_res_1313_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0(v_x_1308_, v_x_1309_, v___y_1310_, v___y_1311_);
lean_dec_ref(v___y_1310_);
return v_res_1313_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpUparams(lean_object* v_uparams_1314_, lean_object* v_a_1315_, lean_object* v_a_1316_){
_start:
{
lean_object* v___x_1318_; lean_object* v___x_1319_; 
v___x_1318_ = lean_box(0);
lean_inc(v_uparams_1314_);
v___x_1319_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0(v_uparams_1314_, v___x_1318_, v_a_1315_, v_a_1316_);
if (lean_obj_tag(v___x_1319_) == 0)
{
lean_object* v_a_1320_; lean_object* v_fst_1321_; lean_object* v_snd_1322_; lean_object* v___x_1323_; lean_object* v___x_1324_; 
v_a_1320_ = lean_ctor_get(v___x_1319_, 0);
lean_inc(v_a_1320_);
lean_dec_ref_known(v___x_1319_, 1);
v_fst_1321_ = lean_ctor_get(v_a_1320_, 0);
lean_inc(v_fst_1321_);
v_snd_1322_ = lean_ctor_get(v_a_1320_, 1);
lean_inc(v_snd_1322_);
lean_dec(v_a_1320_);
v___x_1323_ = l_List_mapTR_loop___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__12(v_uparams_1314_, v___x_1318_);
v___x_1324_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1(v___x_1323_, v___x_1318_, v_a_1315_, v_snd_1322_);
if (lean_obj_tag(v___x_1324_) == 0)
{
lean_object* v_a_1325_; lean_object* v___x_1327_; uint8_t v_isShared_1328_; uint8_t v_isSharedCheck_1342_; 
v_a_1325_ = lean_ctor_get(v___x_1324_, 0);
v_isSharedCheck_1342_ = !lean_is_exclusive(v___x_1324_);
if (v_isSharedCheck_1342_ == 0)
{
v___x_1327_ = v___x_1324_;
v_isShared_1328_ = v_isSharedCheck_1342_;
goto v_resetjp_1326_;
}
else
{
lean_inc(v_a_1325_);
lean_dec(v___x_1324_);
v___x_1327_ = lean_box(0);
v_isShared_1328_ = v_isSharedCheck_1342_;
goto v_resetjp_1326_;
}
v_resetjp_1326_:
{
lean_object* v_snd_1329_; lean_object* v___x_1331_; uint8_t v_isShared_1332_; uint8_t v_isSharedCheck_1340_; 
v_snd_1329_ = lean_ctor_get(v_a_1325_, 1);
v_isSharedCheck_1340_ = !lean_is_exclusive(v_a_1325_);
if (v_isSharedCheck_1340_ == 0)
{
lean_object* v_unused_1341_; 
v_unused_1341_ = lean_ctor_get(v_a_1325_, 0);
lean_dec(v_unused_1341_);
v___x_1331_ = v_a_1325_;
v_isShared_1332_ = v_isSharedCheck_1340_;
goto v_resetjp_1330_;
}
else
{
lean_inc(v_snd_1329_);
lean_dec(v_a_1325_);
v___x_1331_ = lean_box(0);
v_isShared_1332_ = v_isSharedCheck_1340_;
goto v_resetjp_1330_;
}
v_resetjp_1330_:
{
lean_object* v___x_1333_; lean_object* v___x_1335_; 
v___x_1333_ = lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(v_fst_1321_);
if (v_isShared_1332_ == 0)
{
lean_ctor_set(v___x_1331_, 0, v___x_1333_);
v___x_1335_ = v___x_1331_;
goto v_reusejp_1334_;
}
else
{
lean_object* v_reuseFailAlloc_1339_; 
v_reuseFailAlloc_1339_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1339_, 0, v___x_1333_);
lean_ctor_set(v_reuseFailAlloc_1339_, 1, v_snd_1329_);
v___x_1335_ = v_reuseFailAlloc_1339_;
goto v_reusejp_1334_;
}
v_reusejp_1334_:
{
lean_object* v___x_1337_; 
if (v_isShared_1328_ == 0)
{
lean_ctor_set(v___x_1327_, 0, v___x_1335_);
v___x_1337_ = v___x_1327_;
goto v_reusejp_1336_;
}
else
{
lean_object* v_reuseFailAlloc_1338_; 
v_reuseFailAlloc_1338_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1338_, 0, v___x_1335_);
v___x_1337_ = v_reuseFailAlloc_1338_;
goto v_reusejp_1336_;
}
v_reusejp_1336_:
{
return v___x_1337_;
}
}
}
}
}
else
{
lean_object* v_a_1343_; lean_object* v___x_1345_; uint8_t v_isShared_1346_; uint8_t v_isSharedCheck_1350_; 
lean_dec(v_fst_1321_);
v_a_1343_ = lean_ctor_get(v___x_1324_, 0);
v_isSharedCheck_1350_ = !lean_is_exclusive(v___x_1324_);
if (v_isSharedCheck_1350_ == 0)
{
v___x_1345_ = v___x_1324_;
v_isShared_1346_ = v_isSharedCheck_1350_;
goto v_resetjp_1344_;
}
else
{
lean_inc(v_a_1343_);
lean_dec(v___x_1324_);
v___x_1345_ = lean_box(0);
v_isShared_1346_ = v_isSharedCheck_1350_;
goto v_resetjp_1344_;
}
v_resetjp_1344_:
{
lean_object* v___x_1348_; 
if (v_isShared_1346_ == 0)
{
v___x_1348_ = v___x_1345_;
goto v_reusejp_1347_;
}
else
{
lean_object* v_reuseFailAlloc_1349_; 
v_reuseFailAlloc_1349_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1349_, 0, v_a_1343_);
v___x_1348_ = v_reuseFailAlloc_1349_;
goto v_reusejp_1347_;
}
v_reusejp_1347_:
{
return v___x_1348_;
}
}
}
}
else
{
lean_object* v_a_1351_; lean_object* v___x_1353_; uint8_t v_isShared_1354_; uint8_t v_isSharedCheck_1358_; 
lean_dec(v_uparams_1314_);
v_a_1351_ = lean_ctor_get(v___x_1319_, 0);
v_isSharedCheck_1358_ = !lean_is_exclusive(v___x_1319_);
if (v_isSharedCheck_1358_ == 0)
{
v___x_1353_ = v___x_1319_;
v_isShared_1354_ = v_isSharedCheck_1358_;
goto v_resetjp_1352_;
}
else
{
lean_inc(v_a_1351_);
lean_dec(v___x_1319_);
v___x_1353_ = lean_box(0);
v_isShared_1354_ = v_isSharedCheck_1358_;
goto v_resetjp_1352_;
}
v_resetjp_1352_:
{
lean_object* v___x_1356_; 
if (v_isShared_1354_ == 0)
{
v___x_1356_ = v___x_1353_;
goto v_reusejp_1355_;
}
else
{
lean_object* v_reuseFailAlloc_1357_; 
v_reuseFailAlloc_1357_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1357_, 0, v_a_1351_);
v___x_1356_ = v_reuseFailAlloc_1357_;
goto v_reusejp_1355_;
}
v_reusejp_1355_:
{
return v___x_1356_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpUparams___boxed(lean_object* v_uparams_1359_, lean_object* v_a_1360_, lean_object* v_a_1361_, lean_object* v_a_1362_){
_start:
{
lean_object* v_res_1363_; 
v_res_1363_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_uparams_1359_, v_a_1360_, v_a_1361_);
lean_dec_ref(v_a_1360_);
return v_res_1363_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpNames(lean_object* v_uparams_1364_, lean_object* v_a_1365_, lean_object* v_a_1366_){
_start:
{
lean_object* v___x_1368_; lean_object* v___x_1369_; 
v___x_1368_ = lean_box(0);
v___x_1369_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__0(v_uparams_1364_, v___x_1368_, v_a_1365_, v_a_1366_);
if (lean_obj_tag(v___x_1369_) == 0)
{
lean_object* v_a_1370_; lean_object* v___x_1372_; uint8_t v_isShared_1373_; uint8_t v_isSharedCheck_1387_; 
v_a_1370_ = lean_ctor_get(v___x_1369_, 0);
v_isSharedCheck_1387_ = !lean_is_exclusive(v___x_1369_);
if (v_isSharedCheck_1387_ == 0)
{
v___x_1372_ = v___x_1369_;
v_isShared_1373_ = v_isSharedCheck_1387_;
goto v_resetjp_1371_;
}
else
{
lean_inc(v_a_1370_);
lean_dec(v___x_1369_);
v___x_1372_ = lean_box(0);
v_isShared_1373_ = v_isSharedCheck_1387_;
goto v_resetjp_1371_;
}
v_resetjp_1371_:
{
lean_object* v_fst_1374_; lean_object* v_snd_1375_; lean_object* v___x_1377_; uint8_t v_isShared_1378_; uint8_t v_isSharedCheck_1386_; 
v_fst_1374_ = lean_ctor_get(v_a_1370_, 0);
v_snd_1375_ = lean_ctor_get(v_a_1370_, 1);
v_isSharedCheck_1386_ = !lean_is_exclusive(v_a_1370_);
if (v_isSharedCheck_1386_ == 0)
{
v___x_1377_ = v_a_1370_;
v_isShared_1378_ = v_isSharedCheck_1386_;
goto v_resetjp_1376_;
}
else
{
lean_inc(v_snd_1375_);
lean_inc(v_fst_1374_);
lean_dec(v_a_1370_);
v___x_1377_ = lean_box(0);
v_isShared_1378_ = v_isSharedCheck_1386_;
goto v_resetjp_1376_;
}
v_resetjp_1376_:
{
lean_object* v___x_1379_; lean_object* v___x_1381_; 
v___x_1379_ = lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(v_fst_1374_);
if (v_isShared_1378_ == 0)
{
lean_ctor_set(v___x_1377_, 0, v___x_1379_);
v___x_1381_ = v___x_1377_;
goto v_reusejp_1380_;
}
else
{
lean_object* v_reuseFailAlloc_1385_; 
v_reuseFailAlloc_1385_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1385_, 0, v___x_1379_);
lean_ctor_set(v_reuseFailAlloc_1385_, 1, v_snd_1375_);
v___x_1381_ = v_reuseFailAlloc_1385_;
goto v_reusejp_1380_;
}
v_reusejp_1380_:
{
lean_object* v___x_1383_; 
if (v_isShared_1373_ == 0)
{
lean_ctor_set(v___x_1372_, 0, v___x_1381_);
v___x_1383_ = v___x_1372_;
goto v_reusejp_1382_;
}
else
{
lean_object* v_reuseFailAlloc_1384_; 
v_reuseFailAlloc_1384_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1384_, 0, v___x_1381_);
v___x_1383_ = v_reuseFailAlloc_1384_;
goto v_reusejp_1382_;
}
v_reusejp_1382_:
{
return v___x_1383_;
}
}
}
}
}
else
{
lean_object* v_a_1388_; lean_object* v___x_1390_; uint8_t v_isShared_1391_; uint8_t v_isSharedCheck_1395_; 
v_a_1388_ = lean_ctor_get(v___x_1369_, 0);
v_isSharedCheck_1395_ = !lean_is_exclusive(v___x_1369_);
if (v_isSharedCheck_1395_ == 0)
{
v___x_1390_ = v___x_1369_;
v_isShared_1391_ = v_isSharedCheck_1395_;
goto v_resetjp_1389_;
}
else
{
lean_inc(v_a_1388_);
lean_dec(v___x_1369_);
v___x_1390_ = lean_box(0);
v_isShared_1391_ = v_isSharedCheck_1395_;
goto v_resetjp_1389_;
}
v_resetjp_1389_:
{
lean_object* v___x_1393_; 
if (v_isShared_1391_ == 0)
{
v___x_1393_ = v___x_1390_;
goto v_reusejp_1392_;
}
else
{
lean_object* v_reuseFailAlloc_1394_; 
v_reuseFailAlloc_1394_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1394_, 0, v_a_1388_);
v___x_1393_ = v_reuseFailAlloc_1394_;
goto v_reusejp_1392_;
}
v_reusejp_1392_:
{
return v___x_1393_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpNames___boxed(lean_object* v_uparams_1396_, lean_object* v_a_1397_, lean_object* v_a_1398_, lean_object* v_a_1399_){
_start:
{
lean_object* v_res_1400_; 
v_res_1400_ = lp_proofEnvironment_CheckedExport_dumpNames(v_uparams_1396_, v_a_1397_, v_a_1398_);
lean_dec_ref(v_a_1397_);
return v_res_1400_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0(lean_object* v_msg_1401_, lean_object* v___y_1402_, lean_object* v___y_1403_){
_start:
{
lean_object* v___x_1405_; lean_object* v___f_1406_; lean_object* v___f_1407_; lean_object* v___f_1408_; lean_object* v___f_1409_; lean_object* v___x_1410_; lean_object* v___x_1411_; lean_object* v___x_1412_; lean_object* v___x_1413_; lean_object* v___x_1414_; lean_object* v___x_1415_; lean_object* v___x_1416_; lean_object* v___x_1417_; lean_object* v___f_1418_; lean_object* v___x_10892__overap_1419_; lean_object* v___x_1420_; 
v___x_1405_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0);
v___f_1406_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1406_, 0, v___x_1405_);
v___f_1407_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1407_, 0, v___x_1405_);
v___f_1408_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1408_, 0, v___x_1405_);
v___f_1409_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1409_, 0, v___x_1405_);
v___x_1410_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1410_, 0, lean_box(0));
lean_closure_set(v___x_1410_, 1, lean_box(0));
lean_closure_set(v___x_1410_, 2, v___x_1405_);
v___x_1411_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1411_, 0, v___x_1410_);
lean_ctor_set(v___x_1411_, 1, v___f_1406_);
v___x_1412_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1412_, 0, lean_box(0));
lean_closure_set(v___x_1412_, 1, lean_box(0));
lean_closure_set(v___x_1412_, 2, v___x_1405_);
v___x_1413_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1413_, 0, v___x_1411_);
lean_ctor_set(v___x_1413_, 1, v___x_1412_);
lean_ctor_set(v___x_1413_, 2, v___f_1407_);
lean_ctor_set(v___x_1413_, 3, v___f_1408_);
lean_ctor_set(v___x_1413_, 4, v___f_1409_);
v___x_1414_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1414_, 0, lean_box(0));
lean_closure_set(v___x_1414_, 1, lean_box(0));
lean_closure_set(v___x_1414_, 2, v___x_1405_);
v___x_1415_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1415_, 0, v___x_1413_);
lean_ctor_set(v___x_1415_, 1, v___x_1414_);
v___x_1416_ = l_Lean_instInhabitedExpr;
v___x_1417_ = l_instInhabitedOfMonad___redArg(v___x_1415_, v___x_1416_);
v___f_1418_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1418_, 0, v___x_1417_);
v___x_10892__overap_1419_ = lean_panic_fn_borrowed(v___f_1418_, v_msg_1401_);
lean_dec_ref(v___f_1418_);
lean_inc_ref(v___y_1402_);
v___x_1420_ = lean_apply_3(v___x_10892__overap_1419_, v___y_1402_, v___y_1403_, lean_box(0));
return v___x_1420_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0___boxed(lean_object* v_msg_1421_, lean_object* v___y_1422_, lean_object* v___y_1423_, lean_object* v___y_1424_){
_start:
{
lean_object* v_res_1425_; 
v_res_1425_ = lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0(v_msg_1421_, v___y_1422_, v___y_1423_);
lean_dec_ref(v___y_1422_);
return v_res_1425_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_removeMData___closed__1(void){
_start:
{
lean_object* v___x_1427_; lean_object* v___x_1428_; lean_object* v___x_1429_; lean_object* v___x_1430_; lean_object* v___x_1431_; lean_object* v___x_1432_; 
v___x_1427_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__3));
v___x_1428_ = lean_unsigned_to_nat(26u);
v___x_1429_ = lean_unsigned_to_nat(108u);
v___x_1430_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_removeMData___closed__0));
v___x_1431_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_1432_ = l_mkPanicMessageWithDecl(v___x_1431_, v___x_1430_, v___x_1429_, v___x_1428_, v___x_1427_);
return v___x_1432_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_removeMData(lean_object* v_e_1433_, lean_object* v_a_1434_, lean_object* v_a_1435_){
_start:
{
lean_object* v_e_x27_1438_; lean_object* v_visitedNames_1439_; lean_object* v_visitedLevels_1440_; lean_object* v_visitedExprs_1441_; lean_object* v_visitedConstants_1442_; lean_object* v_noMDataExprs_1443_; uint8_t v_exportMData_1444_; uint8_t v_exportUnsafe_1445_; uint8_t v_ignoreMissing_1446_; lean_object* v_recursorMap_1447_; lean_object* v_e_x27_1453_; lean_object* v___y_1454_; lean_object* v_visitedNames_1464_; lean_object* v_visitedLevels_1465_; lean_object* v_visitedExprs_1466_; lean_object* v_visitedConstants_1467_; lean_object* v_noMDataExprs_1468_; uint8_t v_exportMData_1469_; uint8_t v_exportUnsafe_1470_; uint8_t v_ignoreMissing_1471_; lean_object* v_recursorMap_1472_; lean_object* v___x_1473_; 
v_visitedNames_1464_ = lean_ctor_get(v_a_1435_, 0);
v_visitedLevels_1465_ = lean_ctor_get(v_a_1435_, 1);
v_visitedExprs_1466_ = lean_ctor_get(v_a_1435_, 2);
v_visitedConstants_1467_ = lean_ctor_get(v_a_1435_, 3);
v_noMDataExprs_1468_ = lean_ctor_get(v_a_1435_, 4);
v_exportMData_1469_ = lean_ctor_get_uint8(v_a_1435_, sizeof(void*)*6);
v_exportUnsafe_1470_ = lean_ctor_get_uint8(v_a_1435_, sizeof(void*)*6 + 1);
v_ignoreMissing_1471_ = lean_ctor_get_uint8(v_a_1435_, sizeof(void*)*6 + 2);
v_recursorMap_1472_ = lean_ctor_get(v_a_1435_, 5);
v___x_1473_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__1___redArg(v_noMDataExprs_1468_, v_e_1433_);
if (lean_obj_tag(v___x_1473_) == 1)
{
lean_object* v_val_1474_; lean_object* v___x_1476_; uint8_t v_isShared_1477_; uint8_t v_isSharedCheck_1482_; 
lean_dec_ref(v_e_1433_);
v_val_1474_ = lean_ctor_get(v___x_1473_, 0);
v_isSharedCheck_1482_ = !lean_is_exclusive(v___x_1473_);
if (v_isSharedCheck_1482_ == 0)
{
v___x_1476_ = v___x_1473_;
v_isShared_1477_ = v_isSharedCheck_1482_;
goto v_resetjp_1475_;
}
else
{
lean_inc(v_val_1474_);
lean_dec(v___x_1473_);
v___x_1476_ = lean_box(0);
v_isShared_1477_ = v_isSharedCheck_1482_;
goto v_resetjp_1475_;
}
v_resetjp_1475_:
{
lean_object* v___x_1478_; lean_object* v___x_1480_; 
v___x_1478_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1478_, 0, v_val_1474_);
lean_ctor_set(v___x_1478_, 1, v_a_1435_);
if (v_isShared_1477_ == 0)
{
lean_ctor_set_tag(v___x_1476_, 0);
lean_ctor_set(v___x_1476_, 0, v___x_1478_);
v___x_1480_ = v___x_1476_;
goto v_reusejp_1479_;
}
else
{
lean_object* v_reuseFailAlloc_1481_; 
v_reuseFailAlloc_1481_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1481_, 0, v___x_1478_);
v___x_1480_ = v_reuseFailAlloc_1481_;
goto v_reusejp_1479_;
}
v_reusejp_1479_:
{
return v___x_1480_;
}
}
}
else
{
lean_dec(v___x_1473_);
switch(lean_obj_tag(v_e_1433_))
{
case 1:
{
lean_object* v___x_1483_; lean_object* v___x_1484_; 
v___x_1483_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_removeMData___closed__1, &lp_proofEnvironment_CheckedExport_removeMData___closed__1_once, _init_lp_proofEnvironment_CheckedExport_removeMData___closed__1);
v___x_1484_ = lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0(v___x_1483_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1484_) == 0)
{
lean_object* v_a_1485_; lean_object* v_fst_1486_; lean_object* v_snd_1487_; 
v_a_1485_ = lean_ctor_get(v___x_1484_, 0);
lean_inc(v_a_1485_);
lean_dec_ref_known(v___x_1484_, 1);
v_fst_1486_ = lean_ctor_get(v_a_1485_, 0);
lean_inc(v_fst_1486_);
v_snd_1487_ = lean_ctor_get(v_a_1485_, 1);
lean_inc(v_snd_1487_);
lean_dec(v_a_1485_);
v_e_x27_1453_ = v_fst_1486_;
v___y_1454_ = v_snd_1487_;
goto v___jp_1452_;
}
else
{
lean_dec_ref_known(v_e_1433_, 1);
return v___x_1484_;
}
}
case 2:
{
lean_object* v___x_1488_; lean_object* v___x_1489_; 
v___x_1488_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_removeMData___closed__1, &lp_proofEnvironment_CheckedExport_removeMData___closed__1_once, _init_lp_proofEnvironment_CheckedExport_removeMData___closed__1);
v___x_1489_ = lp_proofEnvironment_panic___at___00CheckedExport_removeMData_spec__0(v___x_1488_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1489_) == 0)
{
lean_object* v_a_1490_; lean_object* v_fst_1491_; lean_object* v_snd_1492_; 
v_a_1490_ = lean_ctor_get(v___x_1489_, 0);
lean_inc(v_a_1490_);
lean_dec_ref_known(v___x_1489_, 1);
v_fst_1491_ = lean_ctor_get(v_a_1490_, 0);
lean_inc(v_fst_1491_);
v_snd_1492_ = lean_ctor_get(v_a_1490_, 1);
lean_inc(v_snd_1492_);
lean_dec(v_a_1490_);
v_e_x27_1453_ = v_fst_1491_;
v___y_1454_ = v_snd_1492_;
goto v___jp_1452_;
}
else
{
lean_dec_ref_known(v_e_1433_, 1);
return v___x_1489_;
}
}
case 5:
{
lean_object* v_fn_1493_; lean_object* v_arg_1494_; lean_object* v___x_1495_; 
v_fn_1493_ = lean_ctor_get(v_e_1433_, 0);
v_arg_1494_ = lean_ctor_get(v_e_1433_, 1);
lean_inc_ref(v_fn_1493_);
v___x_1495_ = lp_proofEnvironment_CheckedExport_removeMData(v_fn_1493_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1495_) == 0)
{
lean_object* v_a_1496_; lean_object* v_fst_1497_; lean_object* v_snd_1498_; lean_object* v___x_1499_; 
v_a_1496_ = lean_ctor_get(v___x_1495_, 0);
lean_inc(v_a_1496_);
lean_dec_ref_known(v___x_1495_, 1);
v_fst_1497_ = lean_ctor_get(v_a_1496_, 0);
lean_inc(v_fst_1497_);
v_snd_1498_ = lean_ctor_get(v_a_1496_, 1);
lean_inc(v_snd_1498_);
lean_dec(v_a_1496_);
lean_inc_ref(v_arg_1494_);
v___x_1499_ = lp_proofEnvironment_CheckedExport_removeMData(v_arg_1494_, v_a_1434_, v_snd_1498_);
if (lean_obj_tag(v___x_1499_) == 0)
{
lean_object* v_a_1500_; lean_object* v_fst_1501_; lean_object* v_snd_1502_; uint8_t v___y_1504_; size_t v___x_1506_; size_t v___x_1507_; uint8_t v___x_1508_; 
v_a_1500_ = lean_ctor_get(v___x_1499_, 0);
lean_inc(v_a_1500_);
lean_dec_ref_known(v___x_1499_, 1);
v_fst_1501_ = lean_ctor_get(v_a_1500_, 0);
lean_inc(v_fst_1501_);
v_snd_1502_ = lean_ctor_get(v_a_1500_, 1);
lean_inc(v_snd_1502_);
lean_dec(v_a_1500_);
v___x_1506_ = lean_ptr_addr(v_fn_1493_);
v___x_1507_ = lean_ptr_addr(v_fst_1497_);
v___x_1508_ = lean_usize_dec_eq(v___x_1506_, v___x_1507_);
if (v___x_1508_ == 0)
{
v___y_1504_ = v___x_1508_;
goto v___jp_1503_;
}
else
{
size_t v___x_1509_; size_t v___x_1510_; uint8_t v___x_1511_; 
v___x_1509_ = lean_ptr_addr(v_arg_1494_);
v___x_1510_ = lean_ptr_addr(v_fst_1501_);
v___x_1511_ = lean_usize_dec_eq(v___x_1509_, v___x_1510_);
v___y_1504_ = v___x_1511_;
goto v___jp_1503_;
}
v___jp_1503_:
{
if (v___y_1504_ == 0)
{
lean_object* v___x_1505_; 
v___x_1505_ = l_Lean_Expr_app___override(v_fst_1497_, v_fst_1501_);
v_e_x27_1453_ = v___x_1505_;
v___y_1454_ = v_snd_1502_;
goto v___jp_1452_;
}
else
{
lean_dec(v_fst_1501_);
lean_dec(v_fst_1497_);
lean_inc_ref(v_e_1433_);
v_e_x27_1453_ = v_e_1433_;
v___y_1454_ = v_snd_1502_;
goto v___jp_1452_;
}
}
}
else
{
lean_dec(v_fst_1497_);
lean_dec_ref_known(v_e_1433_, 2);
return v___x_1499_;
}
}
else
{
lean_dec_ref_known(v_e_1433_, 2);
return v___x_1495_;
}
}
case 6:
{
lean_object* v_binderName_1512_; lean_object* v_binderType_1513_; lean_object* v_body_1514_; uint8_t v_binderInfo_1515_; lean_object* v___x_1516_; 
v_binderName_1512_ = lean_ctor_get(v_e_1433_, 0);
v_binderType_1513_ = lean_ctor_get(v_e_1433_, 1);
v_body_1514_ = lean_ctor_get(v_e_1433_, 2);
v_binderInfo_1515_ = lean_ctor_get_uint8(v_e_1433_, sizeof(void*)*3 + 8);
lean_inc_ref(v_binderType_1513_);
v___x_1516_ = lp_proofEnvironment_CheckedExport_removeMData(v_binderType_1513_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1516_) == 0)
{
lean_object* v_a_1517_; lean_object* v_fst_1518_; lean_object* v_snd_1519_; lean_object* v___x_1520_; 
v_a_1517_ = lean_ctor_get(v___x_1516_, 0);
lean_inc(v_a_1517_);
lean_dec_ref_known(v___x_1516_, 1);
v_fst_1518_ = lean_ctor_get(v_a_1517_, 0);
lean_inc(v_fst_1518_);
v_snd_1519_ = lean_ctor_get(v_a_1517_, 1);
lean_inc(v_snd_1519_);
lean_dec(v_a_1517_);
lean_inc_ref(v_body_1514_);
v___x_1520_ = lp_proofEnvironment_CheckedExport_removeMData(v_body_1514_, v_a_1434_, v_snd_1519_);
if (lean_obj_tag(v___x_1520_) == 0)
{
lean_object* v_a_1521_; lean_object* v_fst_1522_; lean_object* v_snd_1523_; uint8_t v___y_1525_; size_t v___x_1529_; size_t v___x_1530_; uint8_t v___x_1531_; 
v_a_1521_ = lean_ctor_get(v___x_1520_, 0);
lean_inc(v_a_1521_);
lean_dec_ref_known(v___x_1520_, 1);
v_fst_1522_ = lean_ctor_get(v_a_1521_, 0);
lean_inc(v_fst_1522_);
v_snd_1523_ = lean_ctor_get(v_a_1521_, 1);
lean_inc(v_snd_1523_);
lean_dec(v_a_1521_);
v___x_1529_ = lean_ptr_addr(v_binderType_1513_);
v___x_1530_ = lean_ptr_addr(v_fst_1518_);
v___x_1531_ = lean_usize_dec_eq(v___x_1529_, v___x_1530_);
if (v___x_1531_ == 0)
{
v___y_1525_ = v___x_1531_;
goto v___jp_1524_;
}
else
{
size_t v___x_1532_; size_t v___x_1533_; uint8_t v___x_1534_; 
v___x_1532_ = lean_ptr_addr(v_body_1514_);
v___x_1533_ = lean_ptr_addr(v_fst_1522_);
v___x_1534_ = lean_usize_dec_eq(v___x_1532_, v___x_1533_);
v___y_1525_ = v___x_1534_;
goto v___jp_1524_;
}
v___jp_1524_:
{
if (v___y_1525_ == 0)
{
lean_object* v___x_1526_; 
lean_inc(v_binderName_1512_);
v___x_1526_ = l_Lean_Expr_lam___override(v_binderName_1512_, v_fst_1518_, v_fst_1522_, v_binderInfo_1515_);
v_e_x27_1453_ = v___x_1526_;
v___y_1454_ = v_snd_1523_;
goto v___jp_1452_;
}
else
{
uint8_t v___x_1527_; 
v___x_1527_ = l_Lean_instBEqBinderInfo_beq(v_binderInfo_1515_, v_binderInfo_1515_);
if (v___x_1527_ == 0)
{
lean_object* v___x_1528_; 
lean_inc(v_binderName_1512_);
v___x_1528_ = l_Lean_Expr_lam___override(v_binderName_1512_, v_fst_1518_, v_fst_1522_, v_binderInfo_1515_);
v_e_x27_1453_ = v___x_1528_;
v___y_1454_ = v_snd_1523_;
goto v___jp_1452_;
}
else
{
lean_dec(v_fst_1522_);
lean_dec(v_fst_1518_);
lean_inc_ref(v_e_1433_);
v_e_x27_1453_ = v_e_1433_;
v___y_1454_ = v_snd_1523_;
goto v___jp_1452_;
}
}
}
}
else
{
lean_dec(v_fst_1518_);
lean_dec_ref_known(v_e_1433_, 3);
return v___x_1520_;
}
}
else
{
lean_dec_ref_known(v_e_1433_, 3);
return v___x_1516_;
}
}
case 7:
{
lean_object* v_binderName_1535_; lean_object* v_binderType_1536_; lean_object* v_body_1537_; uint8_t v_binderInfo_1538_; lean_object* v___x_1539_; 
v_binderName_1535_ = lean_ctor_get(v_e_1433_, 0);
v_binderType_1536_ = lean_ctor_get(v_e_1433_, 1);
v_body_1537_ = lean_ctor_get(v_e_1433_, 2);
v_binderInfo_1538_ = lean_ctor_get_uint8(v_e_1433_, sizeof(void*)*3 + 8);
lean_inc_ref(v_binderType_1536_);
v___x_1539_ = lp_proofEnvironment_CheckedExport_removeMData(v_binderType_1536_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1539_) == 0)
{
lean_object* v_a_1540_; lean_object* v_fst_1541_; lean_object* v_snd_1542_; lean_object* v___x_1543_; 
v_a_1540_ = lean_ctor_get(v___x_1539_, 0);
lean_inc(v_a_1540_);
lean_dec_ref_known(v___x_1539_, 1);
v_fst_1541_ = lean_ctor_get(v_a_1540_, 0);
lean_inc(v_fst_1541_);
v_snd_1542_ = lean_ctor_get(v_a_1540_, 1);
lean_inc(v_snd_1542_);
lean_dec(v_a_1540_);
lean_inc_ref(v_body_1537_);
v___x_1543_ = lp_proofEnvironment_CheckedExport_removeMData(v_body_1537_, v_a_1434_, v_snd_1542_);
if (lean_obj_tag(v___x_1543_) == 0)
{
lean_object* v_a_1544_; lean_object* v_fst_1545_; lean_object* v_snd_1546_; uint8_t v___y_1548_; size_t v___x_1552_; size_t v___x_1553_; uint8_t v___x_1554_; 
v_a_1544_ = lean_ctor_get(v___x_1543_, 0);
lean_inc(v_a_1544_);
lean_dec_ref_known(v___x_1543_, 1);
v_fst_1545_ = lean_ctor_get(v_a_1544_, 0);
lean_inc(v_fst_1545_);
v_snd_1546_ = lean_ctor_get(v_a_1544_, 1);
lean_inc(v_snd_1546_);
lean_dec(v_a_1544_);
v___x_1552_ = lean_ptr_addr(v_binderType_1536_);
v___x_1553_ = lean_ptr_addr(v_fst_1541_);
v___x_1554_ = lean_usize_dec_eq(v___x_1552_, v___x_1553_);
if (v___x_1554_ == 0)
{
v___y_1548_ = v___x_1554_;
goto v___jp_1547_;
}
else
{
size_t v___x_1555_; size_t v___x_1556_; uint8_t v___x_1557_; 
v___x_1555_ = lean_ptr_addr(v_body_1537_);
v___x_1556_ = lean_ptr_addr(v_fst_1545_);
v___x_1557_ = lean_usize_dec_eq(v___x_1555_, v___x_1556_);
v___y_1548_ = v___x_1557_;
goto v___jp_1547_;
}
v___jp_1547_:
{
if (v___y_1548_ == 0)
{
lean_object* v___x_1549_; 
lean_inc(v_binderName_1535_);
v___x_1549_ = l_Lean_Expr_forallE___override(v_binderName_1535_, v_fst_1541_, v_fst_1545_, v_binderInfo_1538_);
v_e_x27_1453_ = v___x_1549_;
v___y_1454_ = v_snd_1546_;
goto v___jp_1452_;
}
else
{
uint8_t v___x_1550_; 
v___x_1550_ = l_Lean_instBEqBinderInfo_beq(v_binderInfo_1538_, v_binderInfo_1538_);
if (v___x_1550_ == 0)
{
lean_object* v___x_1551_; 
lean_inc(v_binderName_1535_);
v___x_1551_ = l_Lean_Expr_forallE___override(v_binderName_1535_, v_fst_1541_, v_fst_1545_, v_binderInfo_1538_);
v_e_x27_1453_ = v___x_1551_;
v___y_1454_ = v_snd_1546_;
goto v___jp_1452_;
}
else
{
lean_dec(v_fst_1545_);
lean_dec(v_fst_1541_);
lean_inc_ref(v_e_1433_);
v_e_x27_1453_ = v_e_1433_;
v___y_1454_ = v_snd_1546_;
goto v___jp_1452_;
}
}
}
}
else
{
lean_dec(v_fst_1541_);
lean_dec_ref_known(v_e_1433_, 3);
return v___x_1543_;
}
}
else
{
lean_dec_ref_known(v_e_1433_, 3);
return v___x_1539_;
}
}
case 8:
{
lean_object* v_declName_1558_; lean_object* v_type_1559_; lean_object* v_value_1560_; lean_object* v_body_1561_; uint8_t v_nondep_1562_; lean_object* v___x_1563_; 
v_declName_1558_ = lean_ctor_get(v_e_1433_, 0);
v_type_1559_ = lean_ctor_get(v_e_1433_, 1);
v_value_1560_ = lean_ctor_get(v_e_1433_, 2);
v_body_1561_ = lean_ctor_get(v_e_1433_, 3);
v_nondep_1562_ = lean_ctor_get_uint8(v_e_1433_, sizeof(void*)*4 + 8);
lean_inc_ref(v_type_1559_);
v___x_1563_ = lp_proofEnvironment_CheckedExport_removeMData(v_type_1559_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1563_) == 0)
{
lean_object* v_a_1564_; lean_object* v_fst_1565_; lean_object* v_snd_1566_; lean_object* v___x_1567_; 
v_a_1564_ = lean_ctor_get(v___x_1563_, 0);
lean_inc(v_a_1564_);
lean_dec_ref_known(v___x_1563_, 1);
v_fst_1565_ = lean_ctor_get(v_a_1564_, 0);
lean_inc(v_fst_1565_);
v_snd_1566_ = lean_ctor_get(v_a_1564_, 1);
lean_inc(v_snd_1566_);
lean_dec(v_a_1564_);
lean_inc_ref(v_value_1560_);
v___x_1567_ = lp_proofEnvironment_CheckedExport_removeMData(v_value_1560_, v_a_1434_, v_snd_1566_);
if (lean_obj_tag(v___x_1567_) == 0)
{
lean_object* v_a_1568_; lean_object* v_fst_1569_; lean_object* v_snd_1570_; lean_object* v___x_1571_; 
v_a_1568_ = lean_ctor_get(v___x_1567_, 0);
lean_inc(v_a_1568_);
lean_dec_ref_known(v___x_1567_, 1);
v_fst_1569_ = lean_ctor_get(v_a_1568_, 0);
lean_inc(v_fst_1569_);
v_snd_1570_ = lean_ctor_get(v_a_1568_, 1);
lean_inc(v_snd_1570_);
lean_dec(v_a_1568_);
lean_inc_ref(v_body_1561_);
v___x_1571_ = lp_proofEnvironment_CheckedExport_removeMData(v_body_1561_, v_a_1434_, v_snd_1570_);
if (lean_obj_tag(v___x_1571_) == 0)
{
lean_object* v_a_1572_; lean_object* v_fst_1573_; lean_object* v_snd_1574_; uint8_t v___x_1575_; uint8_t v___y_1577_; size_t v___x_1584_; size_t v___x_1585_; uint8_t v___x_1586_; 
v_a_1572_ = lean_ctor_get(v___x_1571_, 0);
lean_inc(v_a_1572_);
lean_dec_ref_known(v___x_1571_, 1);
v_fst_1573_ = lean_ctor_get(v_a_1572_, 0);
lean_inc(v_fst_1573_);
v_snd_1574_ = lean_ctor_get(v_a_1572_, 1);
lean_inc(v_snd_1574_);
lean_dec(v_a_1572_);
v___x_1575_ = 0;
v___x_1584_ = lean_ptr_addr(v_type_1559_);
v___x_1585_ = lean_ptr_addr(v_fst_1565_);
v___x_1586_ = lean_usize_dec_eq(v___x_1584_, v___x_1585_);
if (v___x_1586_ == 0)
{
v___y_1577_ = v___x_1586_;
goto v___jp_1576_;
}
else
{
size_t v___x_1587_; size_t v___x_1588_; uint8_t v___x_1589_; 
v___x_1587_ = lean_ptr_addr(v_value_1560_);
v___x_1588_ = lean_ptr_addr(v_fst_1569_);
v___x_1589_ = lean_usize_dec_eq(v___x_1587_, v___x_1588_);
v___y_1577_ = v___x_1589_;
goto v___jp_1576_;
}
v___jp_1576_:
{
if (v___y_1577_ == 0)
{
lean_object* v___x_1578_; 
lean_inc(v_declName_1558_);
v___x_1578_ = l_Lean_Expr_letE___override(v_declName_1558_, v_fst_1565_, v_fst_1569_, v_fst_1573_, v___x_1575_);
v_e_x27_1453_ = v___x_1578_;
v___y_1454_ = v_snd_1574_;
goto v___jp_1452_;
}
else
{
size_t v___x_1579_; size_t v___x_1580_; uint8_t v___x_1581_; 
v___x_1579_ = lean_ptr_addr(v_body_1561_);
v___x_1580_ = lean_ptr_addr(v_fst_1573_);
v___x_1581_ = lean_usize_dec_eq(v___x_1579_, v___x_1580_);
if (v___x_1581_ == 0)
{
lean_object* v___x_1582_; 
lean_inc(v_declName_1558_);
v___x_1582_ = l_Lean_Expr_letE___override(v_declName_1558_, v_fst_1565_, v_fst_1569_, v_fst_1573_, v___x_1575_);
v_e_x27_1453_ = v___x_1582_;
v___y_1454_ = v_snd_1574_;
goto v___jp_1452_;
}
else
{
if (v_nondep_1562_ == 0)
{
lean_dec(v_fst_1573_);
lean_dec(v_fst_1569_);
lean_dec(v_fst_1565_);
lean_inc_ref(v_e_1433_);
v_e_x27_1453_ = v_e_1433_;
v___y_1454_ = v_snd_1574_;
goto v___jp_1452_;
}
else
{
lean_object* v___x_1583_; 
lean_inc(v_declName_1558_);
v___x_1583_ = l_Lean_Expr_letE___override(v_declName_1558_, v_fst_1565_, v_fst_1569_, v_fst_1573_, v___x_1575_);
v_e_x27_1453_ = v___x_1583_;
v___y_1454_ = v_snd_1574_;
goto v___jp_1452_;
}
}
}
}
}
else
{
lean_dec(v_fst_1569_);
lean_dec(v_fst_1565_);
lean_dec_ref_known(v_e_1433_, 4);
return v___x_1571_;
}
}
else
{
lean_dec(v_fst_1565_);
lean_dec_ref_known(v_e_1433_, 4);
return v___x_1567_;
}
}
else
{
lean_dec_ref_known(v_e_1433_, 4);
return v___x_1563_;
}
}
case 10:
{
lean_object* v_expr_1590_; lean_object* v___x_1591_; 
v_expr_1590_ = lean_ctor_get(v_e_1433_, 1);
lean_inc_ref(v_expr_1590_);
v___x_1591_ = lp_proofEnvironment_CheckedExport_removeMData(v_expr_1590_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1591_) == 0)
{
lean_object* v_a_1592_; lean_object* v_fst_1593_; lean_object* v_snd_1594_; 
v_a_1592_ = lean_ctor_get(v___x_1591_, 0);
lean_inc(v_a_1592_);
lean_dec_ref_known(v___x_1591_, 1);
v_fst_1593_ = lean_ctor_get(v_a_1592_, 0);
lean_inc(v_fst_1593_);
v_snd_1594_ = lean_ctor_get(v_a_1592_, 1);
lean_inc(v_snd_1594_);
lean_dec(v_a_1592_);
v_e_x27_1453_ = v_fst_1593_;
v___y_1454_ = v_snd_1594_;
goto v___jp_1452_;
}
else
{
lean_dec_ref_known(v_e_1433_, 2);
return v___x_1591_;
}
}
case 11:
{
lean_object* v_typeName_1595_; lean_object* v_idx_1596_; lean_object* v_struct_1597_; lean_object* v___x_1598_; 
v_typeName_1595_ = lean_ctor_get(v_e_1433_, 0);
v_idx_1596_ = lean_ctor_get(v_e_1433_, 1);
v_struct_1597_ = lean_ctor_get(v_e_1433_, 2);
lean_inc_ref(v_struct_1597_);
v___x_1598_ = lp_proofEnvironment_CheckedExport_removeMData(v_struct_1597_, v_a_1434_, v_a_1435_);
if (lean_obj_tag(v___x_1598_) == 0)
{
lean_object* v_a_1599_; lean_object* v_fst_1600_; lean_object* v_snd_1601_; size_t v___x_1602_; size_t v___x_1603_; uint8_t v___x_1604_; 
v_a_1599_ = lean_ctor_get(v___x_1598_, 0);
lean_inc(v_a_1599_);
lean_dec_ref_known(v___x_1598_, 1);
v_fst_1600_ = lean_ctor_get(v_a_1599_, 0);
lean_inc(v_fst_1600_);
v_snd_1601_ = lean_ctor_get(v_a_1599_, 1);
lean_inc(v_snd_1601_);
lean_dec(v_a_1599_);
v___x_1602_ = lean_ptr_addr(v_struct_1597_);
v___x_1603_ = lean_ptr_addr(v_fst_1600_);
v___x_1604_ = lean_usize_dec_eq(v___x_1602_, v___x_1603_);
if (v___x_1604_ == 0)
{
lean_object* v___x_1605_; 
lean_inc(v_idx_1596_);
lean_inc(v_typeName_1595_);
v___x_1605_ = l_Lean_Expr_proj___override(v_typeName_1595_, v_idx_1596_, v_fst_1600_);
v_e_x27_1453_ = v___x_1605_;
v___y_1454_ = v_snd_1601_;
goto v___jp_1452_;
}
else
{
lean_dec(v_fst_1600_);
lean_inc_ref(v_e_1433_);
v_e_x27_1453_ = v_e_1433_;
v___y_1454_ = v_snd_1601_;
goto v___jp_1452_;
}
}
else
{
lean_dec_ref_known(v_e_1433_, 3);
return v___x_1598_;
}
}
default: 
{
lean_inc(v_recursorMap_1472_);
lean_inc_ref(v_noMDataExprs_1468_);
lean_inc_ref(v_visitedConstants_1467_);
lean_inc_ref(v_visitedExprs_1466_);
lean_inc_ref(v_visitedLevels_1465_);
lean_inc_ref(v_visitedNames_1464_);
lean_dec_ref(v_a_1435_);
lean_inc_ref(v_e_1433_);
v_e_x27_1438_ = v_e_1433_;
v_visitedNames_1439_ = v_visitedNames_1464_;
v_visitedLevels_1440_ = v_visitedLevels_1465_;
v_visitedExprs_1441_ = v_visitedExprs_1466_;
v_visitedConstants_1442_ = v_visitedConstants_1467_;
v_noMDataExprs_1443_ = v_noMDataExprs_1468_;
v_exportMData_1444_ = v_exportMData_1469_;
v_exportUnsafe_1445_ = v_exportUnsafe_1470_;
v_ignoreMissing_1446_ = v_ignoreMissing_1471_;
v_recursorMap_1447_ = v_recursorMap_1472_;
goto v___jp_1437_;
}
}
}
v___jp_1437_:
{
lean_object* v___x_1448_; lean_object* v___x_1449_; lean_object* v___x_1450_; lean_object* v___x_1451_; 
lean_inc_ref(v_e_x27_1438_);
v___x_1448_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__2___redArg(v_noMDataExprs_1443_, v_e_1433_, v_e_x27_1438_);
v___x_1449_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_1449_, 0, v_visitedNames_1439_);
lean_ctor_set(v___x_1449_, 1, v_visitedLevels_1440_);
lean_ctor_set(v___x_1449_, 2, v_visitedExprs_1441_);
lean_ctor_set(v___x_1449_, 3, v_visitedConstants_1442_);
lean_ctor_set(v___x_1449_, 4, v___x_1448_);
lean_ctor_set(v___x_1449_, 5, v_recursorMap_1447_);
lean_ctor_set_uint8(v___x_1449_, sizeof(void*)*6, v_exportMData_1444_);
lean_ctor_set_uint8(v___x_1449_, sizeof(void*)*6 + 1, v_exportUnsafe_1445_);
lean_ctor_set_uint8(v___x_1449_, sizeof(void*)*6 + 2, v_ignoreMissing_1446_);
v___x_1450_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1450_, 0, v_e_x27_1438_);
lean_ctor_set(v___x_1450_, 1, v___x_1449_);
v___x_1451_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1451_, 0, v___x_1450_);
return v___x_1451_;
}
v___jp_1452_:
{
lean_object* v_visitedNames_1455_; lean_object* v_visitedLevels_1456_; lean_object* v_visitedExprs_1457_; lean_object* v_visitedConstants_1458_; lean_object* v_noMDataExprs_1459_; uint8_t v_exportMData_1460_; uint8_t v_exportUnsafe_1461_; uint8_t v_ignoreMissing_1462_; lean_object* v_recursorMap_1463_; 
v_visitedNames_1455_ = lean_ctor_get(v___y_1454_, 0);
lean_inc_ref(v_visitedNames_1455_);
v_visitedLevels_1456_ = lean_ctor_get(v___y_1454_, 1);
lean_inc_ref(v_visitedLevels_1456_);
v_visitedExprs_1457_ = lean_ctor_get(v___y_1454_, 2);
lean_inc_ref(v_visitedExprs_1457_);
v_visitedConstants_1458_ = lean_ctor_get(v___y_1454_, 3);
lean_inc_ref(v_visitedConstants_1458_);
v_noMDataExprs_1459_ = lean_ctor_get(v___y_1454_, 4);
lean_inc_ref(v_noMDataExprs_1459_);
v_exportMData_1460_ = lean_ctor_get_uint8(v___y_1454_, sizeof(void*)*6);
v_exportUnsafe_1461_ = lean_ctor_get_uint8(v___y_1454_, sizeof(void*)*6 + 1);
v_ignoreMissing_1462_ = lean_ctor_get_uint8(v___y_1454_, sizeof(void*)*6 + 2);
v_recursorMap_1463_ = lean_ctor_get(v___y_1454_, 5);
lean_inc(v_recursorMap_1463_);
lean_dec_ref(v___y_1454_);
v_e_x27_1438_ = v_e_x27_1453_;
v_visitedNames_1439_ = v_visitedNames_1455_;
v_visitedLevels_1440_ = v_visitedLevels_1456_;
v_visitedExprs_1441_ = v_visitedExprs_1457_;
v_visitedConstants_1442_ = v_visitedConstants_1458_;
v_noMDataExprs_1443_ = v_noMDataExprs_1459_;
v_exportMData_1444_ = v_exportMData_1460_;
v_exportUnsafe_1445_ = v_exportUnsafe_1461_;
v_ignoreMissing_1446_ = v_ignoreMissing_1462_;
v_recursorMap_1447_ = v_recursorMap_1463_;
goto v___jp_1437_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_removeMData___boxed(lean_object* v_e_1606_, lean_object* v_a_1607_, lean_object* v_a_1608_, lean_object* v_a_1609_){
_start:
{
lean_object* v_res_1610_; 
v_res_1610_ = lp_proofEnvironment_CheckedExport_removeMData(v_e_1606_, v_a_1607_, v_a_1608_);
lean_dec_ref(v_a_1607_);
return v_res_1610_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(lean_object* v_fields_1611_, lean_object* v_a_1612_){
_start:
{
lean_object* v___x_1614_; lean_object* v___x_1615_; lean_object* v___x_1616_; 
v___x_1614_ = l_Lean_Json_mkObj(v_fields_1611_);
v___x_1615_ = l_Lean_Json_compress(v___x_1614_);
v___x_1616_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1615_);
if (lean_obj_tag(v___x_1616_) == 0)
{
lean_object* v_a_1617_; lean_object* v___x_1619_; uint8_t v_isShared_1620_; uint8_t v_isSharedCheck_1625_; 
v_a_1617_ = lean_ctor_get(v___x_1616_, 0);
v_isSharedCheck_1625_ = !lean_is_exclusive(v___x_1616_);
if (v_isSharedCheck_1625_ == 0)
{
v___x_1619_ = v___x_1616_;
v_isShared_1620_ = v_isSharedCheck_1625_;
goto v_resetjp_1618_;
}
else
{
lean_inc(v_a_1617_);
lean_dec(v___x_1616_);
v___x_1619_ = lean_box(0);
v_isShared_1620_ = v_isSharedCheck_1625_;
goto v_resetjp_1618_;
}
v_resetjp_1618_:
{
lean_object* v___x_1621_; lean_object* v___x_1623_; 
v___x_1621_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1621_, 0, v_a_1617_);
lean_ctor_set(v___x_1621_, 1, v_a_1612_);
if (v_isShared_1620_ == 0)
{
lean_ctor_set(v___x_1619_, 0, v___x_1621_);
v___x_1623_ = v___x_1619_;
goto v_reusejp_1622_;
}
else
{
lean_object* v_reuseFailAlloc_1624_; 
v_reuseFailAlloc_1624_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1624_, 0, v___x_1621_);
v___x_1623_ = v_reuseFailAlloc_1624_;
goto v_reusejp_1622_;
}
v_reusejp_1622_:
{
return v___x_1623_;
}
}
}
else
{
lean_object* v_a_1626_; lean_object* v___x_1628_; uint8_t v_isShared_1629_; uint8_t v_isSharedCheck_1633_; 
lean_dec_ref(v_a_1612_);
v_a_1626_ = lean_ctor_get(v___x_1616_, 0);
v_isSharedCheck_1633_ = !lean_is_exclusive(v___x_1616_);
if (v_isSharedCheck_1633_ == 0)
{
v___x_1628_ = v___x_1616_;
v_isShared_1629_ = v_isSharedCheck_1633_;
goto v_resetjp_1627_;
}
else
{
lean_inc(v_a_1626_);
lean_dec(v___x_1616_);
v___x_1628_ = lean_box(0);
v_isShared_1629_ = v_isSharedCheck_1633_;
goto v_resetjp_1627_;
}
v_resetjp_1627_:
{
lean_object* v___x_1631_; 
if (v_isShared_1629_ == 0)
{
v___x_1631_ = v___x_1628_;
goto v_reusejp_1630_;
}
else
{
lean_object* v_reuseFailAlloc_1632_; 
v_reuseFailAlloc_1632_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1632_, 0, v_a_1626_);
v___x_1631_ = v_reuseFailAlloc_1632_;
goto v_reusejp_1630_;
}
v_reusejp_1630_:
{
return v___x_1631_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg___boxed(lean_object* v_fields_1634_, lean_object* v_a_1635_, lean_object* v_a_1636_){
_start:
{
lean_object* v_res_1637_; 
v_res_1637_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v_fields_1634_, v_a_1635_);
lean_dec(v_fields_1634_);
return v_res_1637_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj(lean_object* v_fields_1638_, lean_object* v_a_1639_, lean_object* v_a_1640_){
_start:
{
lean_object* v___x_1642_; 
v___x_1642_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v_fields_1638_, v_a_1640_);
return v___x_1642_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___boxed(lean_object* v_fields_1643_, lean_object* v_a_1644_, lean_object* v_a_1645_, lean_object* v_a_1646_){
_start:
{
lean_object* v_res_1647_; 
v_res_1647_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj(v_fields_1643_, v_a_1644_, v_a_1645_);
lean_dec_ref(v_a_1644_);
lean_dec(v_fields_1643_);
return v_res_1647_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(lean_object* v_msg_1648_, lean_object* v___y_1649_, lean_object* v___y_1650_){
_start:
{
lean_object* v___x_1652_; lean_object* v___f_1653_; lean_object* v___f_1654_; lean_object* v___f_1655_; lean_object* v___f_1656_; lean_object* v___x_1657_; lean_object* v___x_1658_; lean_object* v___x_1659_; lean_object* v___x_1660_; lean_object* v___x_1661_; lean_object* v___x_1662_; lean_object* v___x_1663_; lean_object* v___x_1664_; lean_object* v___f_1665_; lean_object* v___x_172937__overap_1666_; lean_object* v___x_1667_; 
v___x_1652_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0);
v___f_1653_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1653_, 0, v___x_1652_);
v___f_1654_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1654_, 0, v___x_1652_);
v___f_1655_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1655_, 0, v___x_1652_);
v___f_1656_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1656_, 0, v___x_1652_);
v___x_1657_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1657_, 0, lean_box(0));
lean_closure_set(v___x_1657_, 1, lean_box(0));
lean_closure_set(v___x_1657_, 2, v___x_1652_);
v___x_1658_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1658_, 0, v___x_1657_);
lean_ctor_set(v___x_1658_, 1, v___f_1653_);
v___x_1659_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1659_, 0, lean_box(0));
lean_closure_set(v___x_1659_, 1, lean_box(0));
lean_closure_set(v___x_1659_, 2, v___x_1652_);
v___x_1660_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1660_, 0, v___x_1658_);
lean_ctor_set(v___x_1660_, 1, v___x_1659_);
lean_ctor_set(v___x_1660_, 2, v___f_1654_);
lean_ctor_set(v___x_1660_, 3, v___f_1655_);
lean_ctor_set(v___x_1660_, 4, v___f_1656_);
v___x_1661_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1661_, 0, lean_box(0));
lean_closure_set(v___x_1661_, 1, lean_box(0));
lean_closure_set(v___x_1661_, 2, v___x_1652_);
v___x_1662_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1662_, 0, v___x_1660_);
lean_ctor_set(v___x_1662_, 1, v___x_1661_);
v___x_1663_ = lean_box(0);
v___x_1664_ = l_instInhabitedOfMonad___redArg(v___x_1662_, v___x_1663_);
v___f_1665_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1665_, 0, v___x_1664_);
v___x_172937__overap_1666_ = lean_panic_fn_borrowed(v___f_1665_, v_msg_1648_);
lean_dec_ref(v___f_1665_);
lean_inc_ref(v___y_1649_);
v___x_1667_ = lean_apply_3(v___x_172937__overap_1666_, v___y_1649_, v___y_1650_, lean_box(0));
return v___x_1667_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4___boxed(lean_object* v_msg_1668_, lean_object* v___y_1669_, lean_object* v___y_1670_, lean_object* v___y_1671_){
_start:
{
lean_object* v_res_1672_; 
v_res_1672_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(v_msg_1668_, v___y_1669_, v___y_1670_);
lean_dec_ref(v___y_1669_);
return v_res_1672_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___closed__0(void){
_start:
{
lean_object* v___x_1673_; 
v___x_1673_ = l_Array_instInhabited(lean_box(0));
return v___x_1673_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3(lean_object* v_msg_1674_, lean_object* v___y_1675_, lean_object* v___y_1676_){
_start:
{
lean_object* v___x_1678_; lean_object* v___f_1679_; lean_object* v___f_1680_; lean_object* v___f_1681_; lean_object* v___f_1682_; lean_object* v___x_1683_; lean_object* v___x_1684_; lean_object* v___x_1685_; lean_object* v___x_1686_; lean_object* v___x_1687_; lean_object* v___x_1688_; lean_object* v___x_1689_; lean_object* v___x_1690_; lean_object* v___x_1691_; lean_object* v___f_1692_; lean_object* v___x_172925__overap_1693_; lean_object* v___x_1694_; 
v___x_1678_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0);
v___f_1679_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1679_, 0, v___x_1678_);
v___f_1680_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1680_, 0, v___x_1678_);
v___f_1681_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1681_, 0, v___x_1678_);
v___f_1682_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1682_, 0, v___x_1678_);
v___x_1683_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1683_, 0, lean_box(0));
lean_closure_set(v___x_1683_, 1, lean_box(0));
lean_closure_set(v___x_1683_, 2, v___x_1678_);
v___x_1684_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1684_, 0, v___x_1683_);
lean_ctor_set(v___x_1684_, 1, v___f_1679_);
v___x_1685_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1685_, 0, lean_box(0));
lean_closure_set(v___x_1685_, 1, lean_box(0));
lean_closure_set(v___x_1685_, 2, v___x_1678_);
v___x_1686_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1686_, 0, v___x_1684_);
lean_ctor_set(v___x_1686_, 1, v___x_1685_);
lean_ctor_set(v___x_1686_, 2, v___f_1680_);
lean_ctor_set(v___x_1686_, 3, v___f_1681_);
lean_ctor_set(v___x_1686_, 4, v___f_1682_);
v___x_1687_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1687_, 0, lean_box(0));
lean_closure_set(v___x_1687_, 1, lean_box(0));
lean_closure_set(v___x_1687_, 2, v___x_1678_);
v___x_1688_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1688_, 0, v___x_1686_);
lean_ctor_set(v___x_1688_, 1, v___x_1687_);
v___x_1689_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___closed__0);
v___x_1690_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1690_, 0, v___x_1689_);
v___x_1691_ = l_instInhabitedOfMonad___redArg(v___x_1688_, v___x_1690_);
v___f_1692_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1692_, 0, v___x_1691_);
v___x_172925__overap_1693_ = lean_panic_fn_borrowed(v___f_1692_, v_msg_1674_);
lean_dec_ref(v___f_1692_);
lean_inc_ref(v___y_1675_);
v___x_1694_ = lean_apply_3(v___x_172925__overap_1693_, v___y_1675_, v___y_1676_, lean_box(0));
return v___x_1694_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3___boxed(lean_object* v_msg_1695_, lean_object* v___y_1696_, lean_object* v___y_1697_, lean_object* v___y_1698_){
_start:
{
lean_object* v_res_1699_; 
v_res_1699_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3(v_msg_1695_, v___y_1696_, v___y_1697_);
lean_dec_ref(v___y_1696_);
return v_res_1699_;
}
}
static lean_object* _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__2(void){
_start:
{
lean_object* v___x_1702_; lean_object* v___x_1703_; lean_object* v___x_1704_; lean_object* v___x_1705_; lean_object* v___x_1706_; lean_object* v___x_1707_; 
v___x_1702_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__1));
v___x_1703_ = lean_unsigned_to_nat(8u);
v___x_1704_ = lean_unsigned_to_nat(310u);
v___x_1705_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_1706_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_1707_ = l_mkPanicMessageWithDecl(v___x_1706_, v___x_1705_, v___x_1704_, v___x_1703_, v___x_1702_);
return v___x_1707_;
}
}
static lean_object* _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__4(void){
_start:
{
lean_object* v___x_1709_; lean_object* v___x_1710_; lean_object* v___x_1711_; lean_object* v___x_1712_; lean_object* v___x_1713_; lean_object* v___x_1714_; 
v___x_1709_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__3));
v___x_1710_ = lean_unsigned_to_nat(13u);
v___x_1711_ = lean_unsigned_to_nat(312u);
v___x_1712_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_1713_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_1714_ = l_mkPanicMessageWithDecl(v___x_1713_, v___x_1712_, v___x_1711_, v___x_1710_, v___x_1709_);
return v___x_1714_;
}
}
static lean_object* _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8(void){
_start:
{
lean_object* v___x_1718_; lean_object* v___x_1719_; lean_object* v___x_1720_; lean_object* v___x_1721_; lean_object* v___x_1722_; lean_object* v___x_1723_; 
v___x_1718_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__7));
v___x_1719_ = lean_unsigned_to_nat(14u);
v___x_1720_ = lean_unsigned_to_nat(22u);
v___x_1721_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__6));
v___x_1722_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__5));
v___x_1723_ = l_mkPanicMessageWithDecl(v___x_1722_, v___x_1721_, v___x_1720_, v___x_1719_, v___x_1718_);
return v___x_1723_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12(uint8_t v___x_1724_, lean_object* v_init_1725_, lean_object* v_x_1726_, lean_object* v___y_1727_, lean_object* v___y_1728_){
_start:
{
lean_object* v_d_1731_; lean_object* v___y_1732_; 
if (lean_obj_tag(v_x_1726_) == 0)
{
lean_object* v_k_1736_; lean_object* v_l_1737_; lean_object* v_r_1738_; lean_object* v___x_1739_; 
v_k_1736_ = lean_ctor_get(v_x_1726_, 1);
lean_inc(v_k_1736_);
v_l_1737_ = lean_ctor_get(v_x_1726_, 3);
lean_inc(v_l_1737_);
v_r_1738_ = lean_ctor_get(v_x_1726_, 4);
lean_inc(v_r_1738_);
lean_dec_ref_known(v_x_1726_, 5);
v___x_1739_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12(v___x_1724_, v_init_1725_, v_l_1737_, v___y_1727_, v___y_1728_);
if (lean_obj_tag(v___x_1739_) == 0)
{
lean_object* v_a_1740_; lean_object* v_fst_1741_; 
v_a_1740_ = lean_ctor_get(v___x_1739_, 0);
lean_inc(v_a_1740_);
lean_dec_ref_known(v___x_1739_, 1);
v_fst_1741_ = lean_ctor_get(v_a_1740_, 0);
lean_inc(v_fst_1741_);
if (lean_obj_tag(v_fst_1741_) == 0)
{
lean_object* v_snd_1742_; lean_object* v_a_1743_; 
lean_dec(v_r_1738_);
lean_dec(v_k_1736_);
v_snd_1742_ = lean_ctor_get(v_a_1740_, 1);
lean_inc(v_snd_1742_);
lean_dec(v_a_1740_);
v_a_1743_ = lean_ctor_get(v_fst_1741_, 0);
lean_inc(v_a_1743_);
lean_dec_ref_known(v_fst_1741_, 1);
v_d_1731_ = v_a_1743_;
v___y_1732_ = v_snd_1742_;
goto v___jp_1730_;
}
else
{
lean_object* v_snd_1744_; lean_object* v_a_1745_; lean_object* v___y_1747_; lean_object* v___y_1751_; lean_object* v___x_1777_; 
v_snd_1744_ = lean_ctor_get(v_a_1740_, 1);
lean_inc(v_snd_1744_);
lean_dec(v_a_1740_);
v_a_1745_ = lean_ctor_get(v_fst_1741_, 0);
lean_inc(v_a_1745_);
lean_dec_ref_known(v_fst_1741_, 1);
lean_inc_ref(v___y_1727_);
v___x_1777_ = lean_environment_find(v___y_1727_, v_k_1736_);
if (lean_obj_tag(v___x_1777_) == 0)
{
lean_object* v___x_1778_; lean_object* v___x_1779_; 
v___x_1778_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8);
v___x_1779_ = l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(v___x_1778_);
v___y_1751_ = v___x_1779_;
goto v___jp_1750_;
}
else
{
lean_object* v_val_1780_; 
v_val_1780_ = lean_ctor_get(v___x_1777_, 0);
lean_inc(v_val_1780_);
lean_dec_ref_known(v___x_1777_, 1);
v___y_1751_ = v_val_1780_;
goto v___jp_1750_;
}
v___jp_1746_:
{
lean_object* v___x_1748_; 
v___x_1748_ = lean_array_push(v_a_1745_, v___y_1747_);
v_init_1725_ = v___x_1748_;
v_x_1726_ = v_r_1738_;
v___y_1728_ = v_snd_1744_;
goto _start;
}
v___jp_1750_:
{
if (lean_obj_tag(v___y_1751_) == 7)
{
lean_object* v_val_1752_; uint8_t v_isUnsafe_1753_; 
v_val_1752_ = lean_ctor_get(v___y_1751_, 0);
lean_inc_ref(v_val_1752_);
lean_dec_ref_known(v___y_1751_, 1);
v_isUnsafe_1753_ = lean_ctor_get_uint8(v_val_1752_, sizeof(void*)*7 + 1);
if (v_isUnsafe_1753_ == 0)
{
v___y_1747_ = v_val_1752_;
goto v___jp_1746_;
}
else
{
if (v___x_1724_ == 0)
{
uint8_t v_exportUnsafe_1754_; 
v_exportUnsafe_1754_ = lean_ctor_get_uint8(v_snd_1744_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_1754_ == 0)
{
lean_object* v___x_1755_; lean_object* v___x_1756_; 
lean_dec_ref(v_val_1752_);
lean_dec(v_a_1745_);
v___x_1755_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__2, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__2_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__2);
v___x_1756_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__3(v___x_1755_, v___y_1727_, v_snd_1744_);
if (lean_obj_tag(v___x_1756_) == 0)
{
lean_object* v_a_1757_; lean_object* v_fst_1758_; 
v_a_1757_ = lean_ctor_get(v___x_1756_, 0);
lean_inc(v_a_1757_);
lean_dec_ref_known(v___x_1756_, 1);
v_fst_1758_ = lean_ctor_get(v_a_1757_, 0);
lean_inc(v_fst_1758_);
if (lean_obj_tag(v_fst_1758_) == 0)
{
lean_object* v_snd_1759_; lean_object* v_a_1760_; 
lean_dec(v_r_1738_);
v_snd_1759_ = lean_ctor_get(v_a_1757_, 1);
lean_inc(v_snd_1759_);
lean_dec(v_a_1757_);
v_a_1760_ = lean_ctor_get(v_fst_1758_, 0);
lean_inc(v_a_1760_);
lean_dec_ref_known(v_fst_1758_, 1);
v_d_1731_ = v_a_1760_;
v___y_1732_ = v_snd_1759_;
goto v___jp_1730_;
}
else
{
lean_object* v_snd_1761_; lean_object* v_a_1762_; 
v_snd_1761_ = lean_ctor_get(v_a_1757_, 1);
lean_inc(v_snd_1761_);
lean_dec(v_a_1757_);
v_a_1762_ = lean_ctor_get(v_fst_1758_, 0);
lean_inc(v_a_1762_);
lean_dec_ref_known(v_fst_1758_, 1);
v_init_1725_ = v_a_1762_;
v_x_1726_ = v_r_1738_;
v___y_1728_ = v_snd_1761_;
goto _start;
}
}
else
{
lean_dec(v_r_1738_);
return v___x_1756_;
}
}
else
{
v___y_1747_ = v_val_1752_;
goto v___jp_1746_;
}
}
else
{
v___y_1747_ = v_val_1752_;
goto v___jp_1746_;
}
}
}
else
{
lean_object* v___x_1764_; lean_object* v___x_1765_; 
lean_dec_ref(v___y_1751_);
v___x_1764_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__4, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__4_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__4);
v___x_1765_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(v___x_1764_, v___y_1727_, v_snd_1744_);
if (lean_obj_tag(v___x_1765_) == 0)
{
lean_object* v_a_1766_; lean_object* v_snd_1767_; 
v_a_1766_ = lean_ctor_get(v___x_1765_, 0);
lean_inc(v_a_1766_);
lean_dec_ref_known(v___x_1765_, 1);
v_snd_1767_ = lean_ctor_get(v_a_1766_, 1);
lean_inc(v_snd_1767_);
lean_dec(v_a_1766_);
v_init_1725_ = v_a_1745_;
v_x_1726_ = v_r_1738_;
v___y_1728_ = v_snd_1767_;
goto _start;
}
else
{
lean_object* v_a_1769_; lean_object* v___x_1771_; uint8_t v_isShared_1772_; uint8_t v_isSharedCheck_1776_; 
lean_dec(v_a_1745_);
lean_dec(v_r_1738_);
v_a_1769_ = lean_ctor_get(v___x_1765_, 0);
v_isSharedCheck_1776_ = !lean_is_exclusive(v___x_1765_);
if (v_isSharedCheck_1776_ == 0)
{
v___x_1771_ = v___x_1765_;
v_isShared_1772_ = v_isSharedCheck_1776_;
goto v_resetjp_1770_;
}
else
{
lean_inc(v_a_1769_);
lean_dec(v___x_1765_);
v___x_1771_ = lean_box(0);
v_isShared_1772_ = v_isSharedCheck_1776_;
goto v_resetjp_1770_;
}
v_resetjp_1770_:
{
lean_object* v___x_1774_; 
if (v_isShared_1772_ == 0)
{
v___x_1774_ = v___x_1771_;
goto v_reusejp_1773_;
}
else
{
lean_object* v_reuseFailAlloc_1775_; 
v_reuseFailAlloc_1775_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1775_, 0, v_a_1769_);
v___x_1774_ = v_reuseFailAlloc_1775_;
goto v_reusejp_1773_;
}
v_reusejp_1773_:
{
return v___x_1774_;
}
}
}
}
}
}
}
else
{
lean_dec(v_r_1738_);
lean_dec(v_k_1736_);
return v___x_1739_;
}
}
else
{
lean_object* v___x_1781_; lean_object* v___x_1782_; lean_object* v___x_1783_; 
v___x_1781_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1781_, 0, v_init_1725_);
v___x_1782_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1782_, 0, v___x_1781_);
lean_ctor_set(v___x_1782_, 1, v___y_1728_);
v___x_1783_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1783_, 0, v___x_1782_);
return v___x_1783_;
}
v___jp_1730_:
{
lean_object* v___x_1733_; lean_object* v___x_1734_; lean_object* v___x_1735_; 
v___x_1733_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1733_, 0, v_d_1731_);
v___x_1734_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1734_, 0, v___x_1733_);
lean_ctor_set(v___x_1734_, 1, v___y_1732_);
v___x_1735_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1735_, 0, v___x_1734_);
return v___x_1735_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___boxed(lean_object* v___x_1784_, lean_object* v_init_1785_, lean_object* v_x_1786_, lean_object* v___y_1787_, lean_object* v___y_1788_, lean_object* v___y_1789_){
_start:
{
uint8_t v___x_182110__boxed_1790_; lean_object* v_res_1791_; 
v___x_182110__boxed_1790_ = lean_unbox(v___x_1784_);
v_res_1791_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12(v___x_182110__boxed_1790_, v_init_1785_, v_x_1786_, v___y_1787_, v___y_1788_);
lean_dec_ref(v___y_1787_);
return v_res_1791_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___closed__0(void){
_start:
{
lean_object* v___x_1792_; 
v___x_1792_ = l_Array_instInhabited(lean_box(0));
return v___x_1792_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6(lean_object* v_msg_1793_, lean_object* v___y_1794_, lean_object* v___y_1795_){
_start:
{
lean_object* v___x_1797_; lean_object* v___f_1798_; lean_object* v___f_1799_; lean_object* v___f_1800_; lean_object* v___f_1801_; lean_object* v___x_1802_; lean_object* v___x_1803_; lean_object* v___x_1804_; lean_object* v___x_1805_; lean_object* v___x_1806_; lean_object* v___x_1807_; lean_object* v___x_1808_; lean_object* v___x_1809_; lean_object* v___x_1810_; lean_object* v___f_1811_; lean_object* v___x_173657__overap_1812_; lean_object* v___x_1813_; 
v___x_1797_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0);
v___f_1798_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1798_, 0, v___x_1797_);
v___f_1799_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1799_, 0, v___x_1797_);
v___f_1800_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1800_, 0, v___x_1797_);
v___f_1801_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1801_, 0, v___x_1797_);
v___x_1802_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1802_, 0, lean_box(0));
lean_closure_set(v___x_1802_, 1, lean_box(0));
lean_closure_set(v___x_1802_, 2, v___x_1797_);
v___x_1803_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1803_, 0, v___x_1802_);
lean_ctor_set(v___x_1803_, 1, v___f_1798_);
v___x_1804_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1804_, 0, lean_box(0));
lean_closure_set(v___x_1804_, 1, lean_box(0));
lean_closure_set(v___x_1804_, 2, v___x_1797_);
v___x_1805_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1805_, 0, v___x_1803_);
lean_ctor_set(v___x_1805_, 1, v___x_1804_);
lean_ctor_set(v___x_1805_, 2, v___f_1799_);
lean_ctor_set(v___x_1805_, 3, v___f_1800_);
lean_ctor_set(v___x_1805_, 4, v___f_1801_);
v___x_1806_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1806_, 0, lean_box(0));
lean_closure_set(v___x_1806_, 1, lean_box(0));
lean_closure_set(v___x_1806_, 2, v___x_1797_);
v___x_1807_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1807_, 0, v___x_1805_);
lean_ctor_set(v___x_1807_, 1, v___x_1806_);
v___x_1808_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___closed__0);
v___x_1809_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1809_, 0, v___x_1808_);
v___x_1810_ = l_instInhabitedOfMonad___redArg(v___x_1807_, v___x_1809_);
v___f_1811_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1811_, 0, v___x_1810_);
v___x_173657__overap_1812_ = lean_panic_fn_borrowed(v___f_1811_, v_msg_1793_);
lean_dec_ref(v___f_1811_);
lean_inc_ref(v___y_1794_);
v___x_1813_ = lean_apply_3(v___x_173657__overap_1812_, v___y_1794_, v___y_1795_, lean_box(0));
return v___x_1813_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6___boxed(lean_object* v_msg_1814_, lean_object* v___y_1815_, lean_object* v___y_1816_, lean_object* v___y_1817_){
_start:
{
lean_object* v_res_1818_; 
v_res_1818_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6(v_msg_1814_, v___y_1815_, v___y_1816_);
lean_dec_ref(v___y_1815_);
return v_res_1818_;
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__1(void){
_start:
{
lean_object* v___x_1820_; lean_object* v___x_1821_; lean_object* v___x_1822_; lean_object* v___x_1823_; lean_object* v___x_1824_; lean_object* v___x_1825_; 
v___x_1820_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__0));
v___x_1821_ = lean_unsigned_to_nat(10u);
v___x_1822_ = lean_unsigned_to_nat(290u);
v___x_1823_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_1824_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_1825_ = l_mkPanicMessageWithDecl(v___x_1824_, v___x_1823_, v___x_1822_, v___x_1821_, v___x_1820_);
return v___x_1825_;
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__3(void){
_start:
{
lean_object* v___x_1827_; lean_object* v___x_1828_; lean_object* v___x_1829_; lean_object* v___x_1830_; lean_object* v___x_1831_; lean_object* v___x_1832_; 
v___x_1827_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__2));
v___x_1828_ = lean_unsigned_to_nat(15u);
v___x_1829_ = lean_unsigned_to_nat(292u);
v___x_1830_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_1831_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_1832_ = l_mkPanicMessageWithDecl(v___x_1831_, v___x_1830_, v___x_1829_, v___x_1828_, v___x_1827_);
return v___x_1832_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg(uint8_t v___y_1833_, uint8_t v___x_1834_, lean_object* v_as_x27_1835_, lean_object* v_b_1836_, lean_object* v___y_1837_, lean_object* v___y_1838_){
_start:
{
if (lean_obj_tag(v_as_x27_1835_) == 0)
{
lean_object* v___x_1840_; lean_object* v___x_1841_; 
v___x_1840_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1840_, 0, v_b_1836_);
lean_ctor_set(v___x_1840_, 1, v___y_1838_);
v___x_1841_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1841_, 0, v___x_1840_);
return v___x_1841_;
}
else
{
lean_object* v_head_1842_; lean_object* v_tail_1843_; lean_object* v___y_1845_; lean_object* v___y_1849_; uint8_t v___y_1850_; lean_object* v___y_1885_; lean_object* v___x_1901_; 
v_head_1842_ = lean_ctor_get(v_as_x27_1835_, 0);
v_tail_1843_ = lean_ctor_get(v_as_x27_1835_, 1);
lean_inc(v_head_1842_);
lean_inc_ref(v___y_1837_);
v___x_1901_ = lean_environment_find(v___y_1837_, v_head_1842_);
if (lean_obj_tag(v___x_1901_) == 0)
{
lean_object* v___x_1902_; lean_object* v___x_1903_; 
v___x_1902_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8);
v___x_1903_ = l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(v___x_1902_);
v___y_1885_ = v___x_1903_;
goto v___jp_1884_;
}
else
{
lean_object* v_val_1904_; 
v_val_1904_ = lean_ctor_get(v___x_1901_, 0);
lean_inc(v_val_1904_);
lean_dec_ref_known(v___x_1901_, 1);
v___y_1885_ = v_val_1904_;
goto v___jp_1884_;
}
v___jp_1844_:
{
lean_object* v___x_1846_; 
v___x_1846_ = lean_array_push(v_b_1836_, v___y_1845_);
v_as_x27_1835_ = v_tail_1843_;
v_b_1836_ = v___x_1846_;
goto _start;
}
v___jp_1848_:
{
if (v___y_1850_ == 0)
{
uint8_t v_exportUnsafe_1851_; 
v_exportUnsafe_1851_ = lean_ctor_get_uint8(v___y_1838_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_1851_ == 0)
{
lean_object* v___x_1852_; lean_object* v___x_1853_; 
lean_dec_ref(v___y_1849_);
lean_dec_ref(v_b_1836_);
v___x_1852_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__1, &lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__1_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__1);
v___x_1853_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__6(v___x_1852_, v___y_1837_, v___y_1838_);
if (lean_obj_tag(v___x_1853_) == 0)
{
lean_object* v_a_1854_; lean_object* v___x_1856_; uint8_t v_isShared_1857_; uint8_t v_isSharedCheck_1875_; 
v_a_1854_ = lean_ctor_get(v___x_1853_, 0);
v_isSharedCheck_1875_ = !lean_is_exclusive(v___x_1853_);
if (v_isSharedCheck_1875_ == 0)
{
v___x_1856_ = v___x_1853_;
v_isShared_1857_ = v_isSharedCheck_1875_;
goto v_resetjp_1855_;
}
else
{
lean_inc(v_a_1854_);
lean_dec(v___x_1853_);
v___x_1856_ = lean_box(0);
v_isShared_1857_ = v_isSharedCheck_1875_;
goto v_resetjp_1855_;
}
v_resetjp_1855_:
{
lean_object* v_fst_1858_; 
v_fst_1858_ = lean_ctor_get(v_a_1854_, 0);
lean_inc(v_fst_1858_);
if (lean_obj_tag(v_fst_1858_) == 0)
{
lean_object* v_snd_1859_; lean_object* v___x_1861_; uint8_t v_isShared_1862_; uint8_t v_isSharedCheck_1870_; 
v_snd_1859_ = lean_ctor_get(v_a_1854_, 1);
v_isSharedCheck_1870_ = !lean_is_exclusive(v_a_1854_);
if (v_isSharedCheck_1870_ == 0)
{
lean_object* v_unused_1871_; 
v_unused_1871_ = lean_ctor_get(v_a_1854_, 0);
lean_dec(v_unused_1871_);
v___x_1861_ = v_a_1854_;
v_isShared_1862_ = v_isSharedCheck_1870_;
goto v_resetjp_1860_;
}
else
{
lean_inc(v_snd_1859_);
lean_dec(v_a_1854_);
v___x_1861_ = lean_box(0);
v_isShared_1862_ = v_isSharedCheck_1870_;
goto v_resetjp_1860_;
}
v_resetjp_1860_:
{
lean_object* v_a_1863_; lean_object* v___x_1865_; 
v_a_1863_ = lean_ctor_get(v_fst_1858_, 0);
lean_inc(v_a_1863_);
lean_dec_ref_known(v_fst_1858_, 1);
if (v_isShared_1862_ == 0)
{
lean_ctor_set(v___x_1861_, 0, v_a_1863_);
v___x_1865_ = v___x_1861_;
goto v_reusejp_1864_;
}
else
{
lean_object* v_reuseFailAlloc_1869_; 
v_reuseFailAlloc_1869_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1869_, 0, v_a_1863_);
lean_ctor_set(v_reuseFailAlloc_1869_, 1, v_snd_1859_);
v___x_1865_ = v_reuseFailAlloc_1869_;
goto v_reusejp_1864_;
}
v_reusejp_1864_:
{
lean_object* v___x_1867_; 
if (v_isShared_1857_ == 0)
{
lean_ctor_set(v___x_1856_, 0, v___x_1865_);
v___x_1867_ = v___x_1856_;
goto v_reusejp_1866_;
}
else
{
lean_object* v_reuseFailAlloc_1868_; 
v_reuseFailAlloc_1868_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1868_, 0, v___x_1865_);
v___x_1867_ = v_reuseFailAlloc_1868_;
goto v_reusejp_1866_;
}
v_reusejp_1866_:
{
return v___x_1867_;
}
}
}
}
else
{
lean_object* v_snd_1872_; lean_object* v_a_1873_; 
lean_del_object(v___x_1856_);
v_snd_1872_ = lean_ctor_get(v_a_1854_, 1);
lean_inc(v_snd_1872_);
lean_dec(v_a_1854_);
v_a_1873_ = lean_ctor_get(v_fst_1858_, 0);
lean_inc(v_a_1873_);
lean_dec_ref_known(v_fst_1858_, 1);
v_as_x27_1835_ = v_tail_1843_;
v_b_1836_ = v_a_1873_;
v___y_1838_ = v_snd_1872_;
goto _start;
}
}
}
else
{
lean_object* v_a_1876_; lean_object* v___x_1878_; uint8_t v_isShared_1879_; uint8_t v_isSharedCheck_1883_; 
v_a_1876_ = lean_ctor_get(v___x_1853_, 0);
v_isSharedCheck_1883_ = !lean_is_exclusive(v___x_1853_);
if (v_isSharedCheck_1883_ == 0)
{
v___x_1878_ = v___x_1853_;
v_isShared_1879_ = v_isSharedCheck_1883_;
goto v_resetjp_1877_;
}
else
{
lean_inc(v_a_1876_);
lean_dec(v___x_1853_);
v___x_1878_ = lean_box(0);
v_isShared_1879_ = v_isSharedCheck_1883_;
goto v_resetjp_1877_;
}
v_resetjp_1877_:
{
lean_object* v___x_1881_; 
if (v_isShared_1879_ == 0)
{
v___x_1881_ = v___x_1878_;
goto v_reusejp_1880_;
}
else
{
lean_object* v_reuseFailAlloc_1882_; 
v_reuseFailAlloc_1882_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1882_, 0, v_a_1876_);
v___x_1881_ = v_reuseFailAlloc_1882_;
goto v_reusejp_1880_;
}
v_reusejp_1880_:
{
return v___x_1881_;
}
}
}
}
else
{
v___y_1845_ = v___y_1849_;
goto v___jp_1844_;
}
}
else
{
v___y_1845_ = v___y_1849_;
goto v___jp_1844_;
}
}
v___jp_1884_:
{
if (lean_obj_tag(v___y_1885_) == 6)
{
lean_object* v_val_1886_; uint8_t v_isUnsafe_1887_; 
v_val_1886_ = lean_ctor_get(v___y_1885_, 0);
lean_inc_ref(v_val_1886_);
lean_dec_ref_known(v___y_1885_, 1);
v_isUnsafe_1887_ = lean_ctor_get_uint8(v_val_1886_, sizeof(void*)*5);
if (v_isUnsafe_1887_ == 0)
{
v___y_1849_ = v_val_1886_;
v___y_1850_ = v___y_1833_;
goto v___jp_1848_;
}
else
{
v___y_1849_ = v_val_1886_;
v___y_1850_ = v___x_1834_;
goto v___jp_1848_;
}
}
else
{
lean_object* v___x_1888_; lean_object* v___x_1889_; 
lean_dec_ref(v___y_1885_);
v___x_1888_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__3, &lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__3_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___closed__3);
v___x_1889_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(v___x_1888_, v___y_1837_, v___y_1838_);
if (lean_obj_tag(v___x_1889_) == 0)
{
lean_object* v_a_1890_; lean_object* v_snd_1891_; 
v_a_1890_ = lean_ctor_get(v___x_1889_, 0);
lean_inc(v_a_1890_);
lean_dec_ref_known(v___x_1889_, 1);
v_snd_1891_ = lean_ctor_get(v_a_1890_, 1);
lean_inc(v_snd_1891_);
lean_dec(v_a_1890_);
v_as_x27_1835_ = v_tail_1843_;
v___y_1838_ = v_snd_1891_;
goto _start;
}
else
{
lean_object* v_a_1893_; lean_object* v___x_1895_; uint8_t v_isShared_1896_; uint8_t v_isSharedCheck_1900_; 
lean_dec_ref(v_b_1836_);
v_a_1893_ = lean_ctor_get(v___x_1889_, 0);
v_isSharedCheck_1900_ = !lean_is_exclusive(v___x_1889_);
if (v_isSharedCheck_1900_ == 0)
{
v___x_1895_ = v___x_1889_;
v_isShared_1896_ = v_isSharedCheck_1900_;
goto v_resetjp_1894_;
}
else
{
lean_inc(v_a_1893_);
lean_dec(v___x_1889_);
v___x_1895_ = lean_box(0);
v_isShared_1896_ = v_isSharedCheck_1900_;
goto v_resetjp_1894_;
}
v_resetjp_1894_:
{
lean_object* v___x_1898_; 
if (v_isShared_1896_ == 0)
{
v___x_1898_ = v___x_1895_;
goto v_reusejp_1897_;
}
else
{
lean_object* v_reuseFailAlloc_1899_; 
v_reuseFailAlloc_1899_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1899_, 0, v_a_1893_);
v___x_1898_ = v_reuseFailAlloc_1899_;
goto v_reusejp_1897_;
}
v_reusejp_1897_:
{
return v___x_1898_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg___boxed(lean_object* v___y_1905_, lean_object* v___x_1906_, lean_object* v_as_x27_1907_, lean_object* v_b_1908_, lean_object* v___y_1909_, lean_object* v___y_1910_, lean_object* v___y_1911_){
_start:
{
uint8_t v___y_182342__boxed_1912_; uint8_t v___x_182343__boxed_1913_; lean_object* v_res_1914_; 
v___y_182342__boxed_1912_ = lean_unbox(v___y_1905_);
v___x_182343__boxed_1913_ = lean_unbox(v___x_1906_);
v_res_1914_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg(v___y_182342__boxed_1912_, v___x_182343__boxed_1913_, v_as_x27_1907_, v_b_1908_, v___y_1909_, v___y_1910_);
lean_dec_ref(v___y_1909_);
lean_dec(v_as_x27_1907_);
return v_res_1914_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___closed__0(void){
_start:
{
lean_object* v___x_1915_; 
v___x_1915_ = l_Array_instInhabited(lean_box(0));
return v___x_1915_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8(lean_object* v_msg_1916_, lean_object* v___y_1917_, lean_object* v___y_1918_){
_start:
{
lean_object* v___x_1920_; lean_object* v___f_1921_; lean_object* v___f_1922_; lean_object* v___f_1923_; lean_object* v___f_1924_; lean_object* v___x_1925_; lean_object* v___x_1926_; lean_object* v___x_1927_; lean_object* v___x_1928_; lean_object* v___x_1929_; lean_object* v___x_1930_; lean_object* v___x_1931_; lean_object* v___x_1932_; lean_object* v___x_1933_; lean_object* v___x_1934_; lean_object* v___x_1935_; lean_object* v___x_1936_; lean_object* v___f_1937_; lean_object* v___x_174321__overap_1938_; lean_object* v___x_1939_; 
v___x_1920_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0___closed__0);
v___f_1921_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1921_, 0, v___x_1920_);
v___f_1922_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1922_, 0, v___x_1920_);
v___f_1923_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1923_, 0, v___x_1920_);
v___f_1924_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1924_, 0, v___x_1920_);
v___x_1925_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1925_, 0, lean_box(0));
lean_closure_set(v___x_1925_, 1, lean_box(0));
lean_closure_set(v___x_1925_, 2, v___x_1920_);
v___x_1926_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1926_, 0, v___x_1925_);
lean_ctor_set(v___x_1926_, 1, v___f_1921_);
v___x_1927_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1927_, 0, lean_box(0));
lean_closure_set(v___x_1927_, 1, lean_box(0));
lean_closure_set(v___x_1927_, 2, v___x_1920_);
v___x_1928_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1928_, 0, v___x_1926_);
lean_ctor_set(v___x_1928_, 1, v___x_1927_);
lean_ctor_set(v___x_1928_, 2, v___f_1922_);
lean_ctor_set(v___x_1928_, 3, v___f_1923_);
lean_ctor_set(v___x_1928_, 4, v___f_1924_);
v___x_1929_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1929_, 0, lean_box(0));
lean_closure_set(v___x_1929_, 1, lean_box(0));
lean_closure_set(v___x_1929_, 2, v___x_1920_);
v___x_1930_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1930_, 0, v___x_1928_);
lean_ctor_set(v___x_1930_, 1, v___x_1929_);
v___x_1931_ = lean_obj_once(&lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___closed__0, &lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___closed__0_once, _init_lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___closed__0);
v___x_1932_ = lean_box(1);
v___x_1933_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1933_, 0, v___x_1931_);
lean_ctor_set(v___x_1933_, 1, v___x_1932_);
v___x_1934_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1934_, 0, v___x_1931_);
lean_ctor_set(v___x_1934_, 1, v___x_1933_);
v___x_1935_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1935_, 0, v___x_1934_);
v___x_1936_ = l_instInhabitedOfMonad___redArg(v___x_1930_, v___x_1935_);
v___f_1937_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1937_, 0, v___x_1936_);
v___x_174321__overap_1938_ = lean_panic_fn_borrowed(v___f_1937_, v_msg_1916_);
lean_dec_ref(v___f_1937_);
lean_inc_ref(v___y_1917_);
v___x_1939_ = lean_apply_3(v___x_174321__overap_1938_, v___y_1917_, v___y_1918_, lean_box(0));
return v___x_1939_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8___boxed(lean_object* v_msg_1940_, lean_object* v___y_1941_, lean_object* v___y_1942_, lean_object* v___y_1943_){
_start:
{
lean_object* v_res_1944_; 
v_res_1944_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8(v_msg_1940_, v___y_1941_, v___y_1942_);
lean_dec_ref(v___y_1941_);
return v_res_1944_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__13(lean_object* v_as_1945_, size_t v_sz_1946_, size_t v_i_1947_, lean_object* v_b_1948_, lean_object* v___y_1949_, lean_object* v___y_1950_){
_start:
{
uint8_t v___x_1952_; 
v___x_1952_ = lean_usize_dec_lt(v_i_1947_, v_sz_1946_);
if (v___x_1952_ == 0)
{
lean_object* v___x_1953_; lean_object* v___x_1954_; 
v___x_1953_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1953_, 0, v_b_1948_);
lean_ctor_set(v___x_1953_, 1, v___y_1950_);
v___x_1954_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1954_, 0, v___x_1953_);
return v___x_1954_;
}
else
{
lean_object* v_visitedNames_1955_; lean_object* v_visitedLevels_1956_; lean_object* v_visitedExprs_1957_; lean_object* v_visitedConstants_1958_; lean_object* v_noMDataExprs_1959_; uint8_t v_exportMData_1960_; uint8_t v_exportUnsafe_1961_; uint8_t v_ignoreMissing_1962_; lean_object* v_recursorMap_1963_; lean_object* v___x_1965_; uint8_t v_isShared_1966_; uint8_t v_isSharedCheck_1982_; 
v_visitedNames_1955_ = lean_ctor_get(v___y_1950_, 0);
v_visitedLevels_1956_ = lean_ctor_get(v___y_1950_, 1);
v_visitedExprs_1957_ = lean_ctor_get(v___y_1950_, 2);
v_visitedConstants_1958_ = lean_ctor_get(v___y_1950_, 3);
v_noMDataExprs_1959_ = lean_ctor_get(v___y_1950_, 4);
v_exportMData_1960_ = lean_ctor_get_uint8(v___y_1950_, sizeof(void*)*6);
v_exportUnsafe_1961_ = lean_ctor_get_uint8(v___y_1950_, sizeof(void*)*6 + 1);
v_ignoreMissing_1962_ = lean_ctor_get_uint8(v___y_1950_, sizeof(void*)*6 + 2);
v_recursorMap_1963_ = lean_ctor_get(v___y_1950_, 5);
v_isSharedCheck_1982_ = !lean_is_exclusive(v___y_1950_);
if (v_isSharedCheck_1982_ == 0)
{
v___x_1965_ = v___y_1950_;
v_isShared_1966_ = v_isSharedCheck_1982_;
goto v_resetjp_1964_;
}
else
{
lean_inc(v_recursorMap_1963_);
lean_inc(v_noMDataExprs_1959_);
lean_inc(v_visitedConstants_1958_);
lean_inc(v_visitedExprs_1957_);
lean_inc(v_visitedLevels_1956_);
lean_inc(v_visitedNames_1955_);
lean_dec(v___y_1950_);
v___x_1965_ = lean_box(0);
v_isShared_1966_ = v_isSharedCheck_1982_;
goto v_resetjp_1964_;
}
v_resetjp_1964_:
{
lean_object* v_a_1967_; lean_object* v_toConstantVal_1968_; lean_object* v_name_1969_; lean_object* v_type_1970_; lean_object* v___x_1971_; lean_object* v___x_1973_; 
v_a_1967_ = lean_array_uget_borrowed(v_as_1945_, v_i_1947_);
v_toConstantVal_1968_ = lean_ctor_get(v_a_1967_, 0);
v_name_1969_ = lean_ctor_get(v_toConstantVal_1968_, 0);
v_type_1970_ = lean_ctor_get(v_toConstantVal_1968_, 2);
lean_inc(v_name_1969_);
v___x_1971_ = l_Lean_NameHashSet_insert(v_visitedConstants_1958_, v_name_1969_);
if (v_isShared_1966_ == 0)
{
lean_ctor_set(v___x_1965_, 3, v___x_1971_);
v___x_1973_ = v___x_1965_;
goto v_reusejp_1972_;
}
else
{
lean_object* v_reuseFailAlloc_1981_; 
v_reuseFailAlloc_1981_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_1981_, 0, v_visitedNames_1955_);
lean_ctor_set(v_reuseFailAlloc_1981_, 1, v_visitedLevels_1956_);
lean_ctor_set(v_reuseFailAlloc_1981_, 2, v_visitedExprs_1957_);
lean_ctor_set(v_reuseFailAlloc_1981_, 3, v___x_1971_);
lean_ctor_set(v_reuseFailAlloc_1981_, 4, v_noMDataExprs_1959_);
lean_ctor_set(v_reuseFailAlloc_1981_, 5, v_recursorMap_1963_);
lean_ctor_set_uint8(v_reuseFailAlloc_1981_, sizeof(void*)*6, v_exportMData_1960_);
lean_ctor_set_uint8(v_reuseFailAlloc_1981_, sizeof(void*)*6 + 1, v_exportUnsafe_1961_);
lean_ctor_set_uint8(v_reuseFailAlloc_1981_, sizeof(void*)*6 + 2, v_ignoreMissing_1962_);
v___x_1973_ = v_reuseFailAlloc_1981_;
goto v_reusejp_1972_;
}
v_reusejp_1972_:
{
lean_object* v___x_1974_; 
lean_inc_ref(v_type_1970_);
v___x_1974_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_1970_, v___y_1949_, v___x_1973_);
if (lean_obj_tag(v___x_1974_) == 0)
{
lean_object* v_a_1975_; lean_object* v_snd_1976_; lean_object* v___x_1977_; size_t v___x_1978_; size_t v___x_1979_; 
v_a_1975_ = lean_ctor_get(v___x_1974_, 0);
lean_inc(v_a_1975_);
lean_dec_ref_known(v___x_1974_, 1);
v_snd_1976_ = lean_ctor_get(v_a_1975_, 1);
lean_inc(v_snd_1976_);
lean_dec(v_a_1975_);
v___x_1977_ = lean_box(0);
v___x_1978_ = ((size_t)1ULL);
v___x_1979_ = lean_usize_add(v_i_1947_, v___x_1978_);
v_i_1947_ = v___x_1979_;
v_b_1948_ = v___x_1977_;
v___y_1950_ = v_snd_1976_;
goto _start;
}
else
{
return v___x_1974_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg(lean_object* v_as_x27_1983_, lean_object* v_b_1984_, lean_object* v___y_1985_, lean_object* v___y_1986_){
_start:
{
if (lean_obj_tag(v_as_x27_1983_) == 0)
{
lean_object* v___x_1988_; lean_object* v___x_1989_; 
v___x_1988_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1988_, 0, v_b_1984_);
lean_ctor_set(v___x_1988_, 1, v___y_1986_);
v___x_1989_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1989_, 0, v___x_1988_);
return v___x_1989_;
}
else
{
lean_object* v_head_1990_; lean_object* v_tail_1991_; lean_object* v_rhs_1992_; lean_object* v___x_1993_; 
v_head_1990_ = lean_ctor_get(v_as_x27_1983_, 0);
v_tail_1991_ = lean_ctor_get(v_as_x27_1983_, 1);
v_rhs_1992_ = lean_ctor_get(v_head_1990_, 2);
lean_inc_ref(v_rhs_1992_);
v___x_1993_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_rhs_1992_, v___y_1985_, v___y_1986_);
if (lean_obj_tag(v___x_1993_) == 0)
{
lean_object* v_a_1994_; lean_object* v_snd_1995_; lean_object* v___x_1996_; 
v_a_1994_ = lean_ctor_get(v___x_1993_, 0);
lean_inc(v_a_1994_);
lean_dec_ref_known(v___x_1993_, 1);
v_snd_1995_ = lean_ctor_get(v_a_1994_, 1);
lean_inc(v_snd_1995_);
lean_dec(v_a_1994_);
v___x_1996_ = lean_box(0);
v_as_x27_1983_ = v_tail_1991_;
v_b_1984_ = v___x_1996_;
v___y_1986_ = v_snd_1995_;
goto _start;
}
else
{
return v___x_1993_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__14(lean_object* v_as_1998_, size_t v_sz_1999_, size_t v_i_2000_, lean_object* v_b_2001_, lean_object* v___y_2002_, lean_object* v___y_2003_){
_start:
{
uint8_t v___x_2005_; 
v___x_2005_ = lean_usize_dec_lt(v_i_2000_, v_sz_1999_);
if (v___x_2005_ == 0)
{
lean_object* v___x_2006_; lean_object* v___x_2007_; 
v___x_2006_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2006_, 0, v_b_2001_);
lean_ctor_set(v___x_2006_, 1, v___y_2003_);
v___x_2007_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2007_, 0, v___x_2006_);
return v___x_2007_;
}
else
{
lean_object* v_a_2008_; lean_object* v_rules_2009_; lean_object* v___x_2010_; lean_object* v___x_2011_; 
v_a_2008_ = lean_array_uget_borrowed(v_as_1998_, v_i_2000_);
v_rules_2009_ = lean_ctor_get(v_a_2008_, 6);
v___x_2010_ = lean_box(0);
v___x_2011_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg(v_rules_2009_, v___x_2010_, v___y_2002_, v___y_2003_);
if (lean_obj_tag(v___x_2011_) == 0)
{
lean_object* v_a_2012_; lean_object* v_snd_2013_; size_t v___x_2014_; size_t v___x_2015_; 
v_a_2012_ = lean_ctor_get(v___x_2011_, 0);
lean_inc(v_a_2012_);
lean_dec_ref_known(v___x_2011_, 1);
v_snd_2013_ = lean_ctor_get(v_a_2012_, 1);
lean_inc(v_snd_2013_);
lean_dec(v_a_2012_);
v___x_2014_ = ((size_t)1ULL);
v___x_2015_ = lean_usize_add(v_i_2000_, v___x_2014_);
v_i_2000_ = v___x_2015_;
v_b_2001_ = v___x_2010_;
v___y_2003_ = v_snd_2013_;
goto _start;
}
else
{
return v___x_2011_;
}
}
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_dumpExpr___closed__0(void){
_start:
{
lean_object* v___x_2017_; lean_object* v___x_2018_; lean_object* v___x_2019_; 
v___x_2017_ = lean_box(0);
v___x_2018_ = lean_unsigned_to_nat(16u);
v___x_2019_ = lean_mk_array(v___x_2018_, v___x_2017_);
return v___x_2019_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_dumpExpr___closed__1(void){
_start:
{
lean_object* v___x_2020_; lean_object* v___x_2021_; lean_object* v___x_2022_; 
v___x_2020_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_dumpExpr___closed__0, &lp_proofEnvironment_CheckedExport_dumpExpr___closed__0_once, _init_lp_proofEnvironment_CheckedExport_dumpExpr___closed__0);
v___x_2021_ = lean_unsigned_to_nat(0u);
v___x_2022_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2022_, 0, v___x_2021_);
lean_ctor_set(v___x_2022_, 1, v___x_2020_);
return v___x_2022_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps(lean_object* v_a_2043_, lean_object* v_a_2044_){
_start:
{
lean_object* v_visitedConstants_2050_; lean_object* v_nat_2051_; uint8_t v___x_2052_; 
v_visitedConstants_2050_ = lean_ctor_get(v_a_2044_, 3);
v_nat_2051_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___closed__1));
v___x_2052_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_2050_, v_nat_2051_);
if (v___x_2052_ == 0)
{
lean_object* v___x_2053_; 
lean_inc_ref(v_a_2043_);
v___x_2053_ = lean_environment_find(v_a_2043_, v_nat_2051_);
if (lean_obj_tag(v___x_2053_) == 0)
{
goto v___jp_2046_;
}
else
{
lean_object* v___x_2054_; 
lean_dec_ref_known(v___x_2053_, 1);
v___x_2054_ = lp_proofEnvironment_CheckedExport_dumpConstant(v_nat_2051_, v_a_2043_, v_a_2044_);
return v___x_2054_;
}
}
else
{
goto v___jp_2046_;
}
v___jp_2046_:
{
lean_object* v___x_2047_; lean_object* v___x_2048_; lean_object* v___x_2049_; 
v___x_2047_ = lean_box(0);
v___x_2048_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2048_, 0, v___x_2047_);
lean_ctor_set(v___x_2048_, 1, v_a_2044_);
v___x_2049_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2049_, 0, v___x_2048_);
return v___x_2049_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps(lean_object* v_a_2066_, lean_object* v_a_2067_){
_start:
{
lean_object* v___y_2070_; lean_object* v___y_2075_; lean_object* v___y_2076_; lean_object* v_visitedConstants_2077_; lean_object* v_visitedConstants_2082_; lean_object* v_charOfNat_2083_; uint8_t v___x_2084_; 
v_visitedConstants_2082_ = lean_ctor_get(v_a_2067_, 3);
v_charOfNat_2083_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__5));
v___x_2084_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_2082_, v_charOfNat_2083_);
if (v___x_2084_ == 0)
{
lean_object* v___x_2085_; 
lean_inc_ref(v_a_2066_);
v___x_2085_ = lean_environment_find(v_a_2066_, v_charOfNat_2083_);
if (lean_obj_tag(v___x_2085_) == 0)
{
lean_inc_ref(v_visitedConstants_2082_);
v___y_2075_ = v_a_2066_;
v___y_2076_ = v_a_2067_;
v_visitedConstants_2077_ = v_visitedConstants_2082_;
goto v___jp_2074_;
}
else
{
lean_object* v___x_2086_; 
lean_dec_ref_known(v___x_2085_, 1);
v___x_2086_ = lp_proofEnvironment_CheckedExport_dumpConstant(v_charOfNat_2083_, v_a_2066_, v_a_2067_);
if (lean_obj_tag(v___x_2086_) == 0)
{
lean_object* v_a_2087_; lean_object* v_snd_2088_; lean_object* v_visitedConstants_2089_; 
v_a_2087_ = lean_ctor_get(v___x_2086_, 0);
lean_inc(v_a_2087_);
lean_dec_ref_known(v___x_2086_, 1);
v_snd_2088_ = lean_ctor_get(v_a_2087_, 1);
lean_inc(v_snd_2088_);
lean_dec(v_a_2087_);
v_visitedConstants_2089_ = lean_ctor_get(v_snd_2088_, 3);
lean_inc_ref(v_visitedConstants_2089_);
v___y_2075_ = v_a_2066_;
v___y_2076_ = v_snd_2088_;
v_visitedConstants_2077_ = v_visitedConstants_2089_;
goto v___jp_2074_;
}
else
{
return v___x_2086_;
}
}
}
else
{
lean_inc_ref(v_visitedConstants_2082_);
v___y_2075_ = v_a_2066_;
v___y_2076_ = v_a_2067_;
v_visitedConstants_2077_ = v_visitedConstants_2082_;
goto v___jp_2074_;
}
v___jp_2069_:
{
lean_object* v___x_2071_; lean_object* v___x_2072_; lean_object* v___x_2073_; 
v___x_2071_ = lean_box(0);
v___x_2072_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2072_, 0, v___x_2071_);
lean_ctor_set(v___x_2072_, 1, v___y_2070_);
v___x_2073_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2073_, 0, v___x_2072_);
return v___x_2073_;
}
v___jp_2074_:
{
lean_object* v___x_2078_; uint8_t v___x_2079_; 
v___x_2078_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___closed__2));
v___x_2079_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_2077_, v___x_2078_);
lean_dec_ref(v_visitedConstants_2077_);
if (v___x_2079_ == 0)
{
lean_object* v___x_2080_; 
lean_inc_ref(v___y_2075_);
v___x_2080_ = lean_environment_find(v___y_2075_, v___x_2078_);
if (lean_obj_tag(v___x_2080_) == 0)
{
v___y_2070_ = v___y_2076_;
goto v___jp_2069_;
}
else
{
lean_object* v___x_2081_; 
lean_dec_ref_known(v___x_2080_, 1);
v___x_2081_ = lp_proofEnvironment_CheckedExport_dumpConstant(v___x_2078_, v___y_2075_, v___y_2076_);
return v___x_2081_;
}
}
else
{
v___y_2070_ = v___y_2076_;
goto v___jp_2069_;
}
}
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_dumpExprAux___closed__26(void){
_start:
{
lean_object* v___x_2100_; lean_object* v___x_2101_; lean_object* v___x_2102_; lean_object* v___x_2103_; lean_object* v___x_2104_; lean_object* v___x_2105_; 
v___x_2100_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__25));
v___x_2101_ = lean_unsigned_to_nat(29u);
v___x_2102_ = lean_unsigned_to_nat(133u);
v___x_2103_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__24));
v___x_2104_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_2105_ = l_mkPanicMessageWithDecl(v___x_2104_, v___x_2103_, v___x_2102_, v___x_2101_, v___x_2100_);
return v___x_2105_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux(lean_object* v_e_2106_, lean_object* v_a_2107_, lean_object* v_a_2108_){
_start:
{
lean_object* v_visitedNames_2110_; lean_object* v_visitedLevels_2111_; lean_object* v_visitedExprs_2112_; lean_object* v_visitedConstants_2113_; lean_object* v_noMDataExprs_2114_; uint8_t v_exportMData_2115_; uint8_t v_exportUnsafe_2116_; uint8_t v_ignoreMissing_2117_; lean_object* v_recursorMap_2118_; lean_object* v___x_2119_; 
v_visitedNames_2110_ = lean_ctor_get(v_a_2108_, 0);
v_visitedLevels_2111_ = lean_ctor_get(v_a_2108_, 1);
v_visitedExprs_2112_ = lean_ctor_get(v_a_2108_, 2);
v_visitedConstants_2113_ = lean_ctor_get(v_a_2108_, 3);
v_noMDataExprs_2114_ = lean_ctor_get(v_a_2108_, 4);
v_exportMData_2115_ = lean_ctor_get_uint8(v_a_2108_, sizeof(void*)*6);
v_exportUnsafe_2116_ = lean_ctor_get_uint8(v_a_2108_, sizeof(void*)*6 + 1);
v_ignoreMissing_2117_ = lean_ctor_get_uint8(v_a_2108_, sizeof(void*)*6 + 2);
v_recursorMap_2118_ = lean_ctor_get(v_a_2108_, 5);
v___x_2119_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__1___redArg(v_visitedExprs_2112_, v_e_2106_);
if (lean_obj_tag(v___x_2119_) == 1)
{
lean_object* v_val_2120_; lean_object* v___x_2122_; uint8_t v_isShared_2123_; uint8_t v_isSharedCheck_2128_; 
lean_dec_ref(v_e_2106_);
v_val_2120_ = lean_ctor_get(v___x_2119_, 0);
v_isSharedCheck_2128_ = !lean_is_exclusive(v___x_2119_);
if (v_isSharedCheck_2128_ == 0)
{
v___x_2122_ = v___x_2119_;
v_isShared_2123_ = v_isSharedCheck_2128_;
goto v_resetjp_2121_;
}
else
{
lean_inc(v_val_2120_);
lean_dec(v___x_2119_);
v___x_2122_ = lean_box(0);
v_isShared_2123_ = v_isSharedCheck_2128_;
goto v_resetjp_2121_;
}
v_resetjp_2121_:
{
lean_object* v___x_2124_; lean_object* v___x_2126_; 
v___x_2124_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2124_, 0, v_val_2120_);
lean_ctor_set(v___x_2124_, 1, v_a_2108_);
if (v_isShared_2123_ == 0)
{
lean_ctor_set_tag(v___x_2122_, 0);
lean_ctor_set(v___x_2122_, 0, v___x_2124_);
v___x_2126_ = v___x_2122_;
goto v_reusejp_2125_;
}
else
{
lean_object* v_reuseFailAlloc_2127_; 
v_reuseFailAlloc_2127_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2127_, 0, v___x_2124_);
v___x_2126_ = v_reuseFailAlloc_2127_;
goto v_reusejp_2125_;
}
v_reusejp_2125_:
{
return v___x_2126_;
}
}
}
else
{
lean_object* v___x_2129_; lean_object* v_fst_2131_; lean_object* v_visitedNames_2132_; lean_object* v_visitedLevels_2133_; lean_object* v_visitedExprs_2134_; lean_object* v_visitedConstants_2135_; lean_object* v_noMDataExprs_2136_; uint8_t v_exportMData_2137_; uint8_t v_exportUnsafe_2138_; uint8_t v_ignoreMissing_2139_; lean_object* v_recursorMap_2140_; lean_object* v_fst_2167_; lean_object* v_snd_2168_; 
lean_dec(v___x_2119_);
v___x_2129_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__0));
switch(lean_obj_tag(v_e_2106_))
{
case 0:
{
lean_object* v_deBruijnIndex_2178_; lean_object* v___x_2179_; lean_object* v___x_2180_; lean_object* v___x_2181_; lean_object* v___x_2182_; lean_object* v___x_2183_; lean_object* v___x_2184_; lean_object* v___x_2185_; 
lean_inc(v_recursorMap_2118_);
lean_inc_ref(v_noMDataExprs_2114_);
lean_inc_ref(v_visitedConstants_2113_);
lean_inc_ref(v_visitedExprs_2112_);
lean_inc_ref(v_visitedLevels_2111_);
lean_inc_ref(v_visitedNames_2110_);
lean_dec_ref(v_a_2108_);
v_deBruijnIndex_2178_ = lean_ctor_get(v_e_2106_, 0);
v___x_2179_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__1));
lean_inc(v_deBruijnIndex_2178_);
v___x_2180_ = l_Lean_JsonNumber_fromNat(v_deBruijnIndex_2178_);
v___x_2181_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2181_, 0, v___x_2180_);
v___x_2182_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2182_, 0, v___x_2179_);
lean_ctor_set(v___x_2182_, 1, v___x_2181_);
v___x_2183_ = lean_box(0);
v___x_2184_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2184_, 0, v___x_2182_);
lean_ctor_set(v___x_2184_, 1, v___x_2183_);
v___x_2185_ = l_Lean_Json_mkObj(v___x_2184_);
lean_dec_ref_known(v___x_2184_, 2);
v_fst_2131_ = v___x_2185_;
v_visitedNames_2132_ = v_visitedNames_2110_;
v_visitedLevels_2133_ = v_visitedLevels_2111_;
v_visitedExprs_2134_ = v_visitedExprs_2112_;
v_visitedConstants_2135_ = v_visitedConstants_2113_;
v_noMDataExprs_2136_ = v_noMDataExprs_2114_;
v_exportMData_2137_ = v_exportMData_2115_;
v_exportUnsafe_2138_ = v_exportUnsafe_2116_;
v_ignoreMissing_2139_ = v_ignoreMissing_2117_;
v_recursorMap_2140_ = v_recursorMap_2118_;
goto v___jp_2130_;
}
case 3:
{
lean_object* v_u_2186_; lean_object* v___x_2187_; 
v_u_2186_ = lean_ctor_get(v_e_2106_, 0);
lean_inc(v_u_2186_);
v___x_2187_ = lp_proofEnvironment_CheckedExport_dumpLevel(v_u_2186_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2187_) == 0)
{
lean_object* v_a_2188_; lean_object* v___x_2190_; uint8_t v_isShared_2191_; uint8_t v_isSharedCheck_2209_; 
v_a_2188_ = lean_ctor_get(v___x_2187_, 0);
v_isSharedCheck_2209_ = !lean_is_exclusive(v___x_2187_);
if (v_isSharedCheck_2209_ == 0)
{
v___x_2190_ = v___x_2187_;
v_isShared_2191_ = v_isSharedCheck_2209_;
goto v_resetjp_2189_;
}
else
{
lean_inc(v_a_2188_);
lean_dec(v___x_2187_);
v___x_2190_ = lean_box(0);
v_isShared_2191_ = v_isSharedCheck_2209_;
goto v_resetjp_2189_;
}
v_resetjp_2189_:
{
lean_object* v_fst_2192_; lean_object* v_snd_2193_; lean_object* v___x_2195_; uint8_t v_isShared_2196_; uint8_t v_isSharedCheck_2208_; 
v_fst_2192_ = lean_ctor_get(v_a_2188_, 0);
v_snd_2193_ = lean_ctor_get(v_a_2188_, 1);
v_isSharedCheck_2208_ = !lean_is_exclusive(v_a_2188_);
if (v_isSharedCheck_2208_ == 0)
{
v___x_2195_ = v_a_2188_;
v_isShared_2196_ = v_isSharedCheck_2208_;
goto v_resetjp_2194_;
}
else
{
lean_inc(v_snd_2193_);
lean_inc(v_fst_2192_);
lean_dec(v_a_2188_);
v___x_2195_ = lean_box(0);
v_isShared_2196_ = v_isSharedCheck_2208_;
goto v_resetjp_2194_;
}
v_resetjp_2194_:
{
lean_object* v___x_2197_; lean_object* v___x_2198_; lean_object* v___x_2200_; 
v___x_2197_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__2));
v___x_2198_ = l_Lean_JsonNumber_fromNat(v_fst_2192_);
if (v_isShared_2191_ == 0)
{
lean_ctor_set_tag(v___x_2190_, 2);
lean_ctor_set(v___x_2190_, 0, v___x_2198_);
v___x_2200_ = v___x_2190_;
goto v_reusejp_2199_;
}
else
{
lean_object* v_reuseFailAlloc_2207_; 
v_reuseFailAlloc_2207_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2207_, 0, v___x_2198_);
v___x_2200_ = v_reuseFailAlloc_2207_;
goto v_reusejp_2199_;
}
v_reusejp_2199_:
{
lean_object* v___x_2202_; 
if (v_isShared_2196_ == 0)
{
lean_ctor_set(v___x_2195_, 1, v___x_2200_);
lean_ctor_set(v___x_2195_, 0, v___x_2197_);
v___x_2202_ = v___x_2195_;
goto v_reusejp_2201_;
}
else
{
lean_object* v_reuseFailAlloc_2206_; 
v_reuseFailAlloc_2206_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2206_, 0, v___x_2197_);
lean_ctor_set(v_reuseFailAlloc_2206_, 1, v___x_2200_);
v___x_2202_ = v_reuseFailAlloc_2206_;
goto v_reusejp_2201_;
}
v_reusejp_2201_:
{
lean_object* v___x_2203_; lean_object* v___x_2204_; lean_object* v___x_2205_; 
v___x_2203_ = lean_box(0);
v___x_2204_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2204_, 0, v___x_2202_);
lean_ctor_set(v___x_2204_, 1, v___x_2203_);
v___x_2205_ = l_Lean_Json_mkObj(v___x_2204_);
lean_dec_ref_known(v___x_2204_, 2);
v_fst_2167_ = v___x_2205_;
v_snd_2168_ = v_snd_2193_;
goto v___jp_2166_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 1);
return v___x_2187_;
}
}
case 4:
{
lean_object* v_declName_2210_; lean_object* v_us_2211_; lean_object* v___x_2212_; 
v_declName_2210_ = lean_ctor_get(v_e_2106_, 0);
v_us_2211_ = lean_ctor_get(v_e_2106_, 1);
lean_inc(v_declName_2210_);
v___x_2212_ = lp_proofEnvironment_CheckedExport_dumpName(v_declName_2210_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2212_) == 0)
{
lean_object* v_a_2213_; lean_object* v___x_2215_; uint8_t v_isShared_2216_; uint8_t v_isSharedCheck_2260_; 
v_a_2213_ = lean_ctor_get(v___x_2212_, 0);
v_isSharedCheck_2260_ = !lean_is_exclusive(v___x_2212_);
if (v_isSharedCheck_2260_ == 0)
{
v___x_2215_ = v___x_2212_;
v_isShared_2216_ = v_isSharedCheck_2260_;
goto v_resetjp_2214_;
}
else
{
lean_inc(v_a_2213_);
lean_dec(v___x_2212_);
v___x_2215_ = lean_box(0);
v_isShared_2216_ = v_isSharedCheck_2260_;
goto v_resetjp_2214_;
}
v_resetjp_2214_:
{
lean_object* v_fst_2217_; lean_object* v_snd_2218_; lean_object* v___x_2220_; uint8_t v_isShared_2221_; uint8_t v_isSharedCheck_2259_; 
v_fst_2217_ = lean_ctor_get(v_a_2213_, 0);
v_snd_2218_ = lean_ctor_get(v_a_2213_, 1);
v_isSharedCheck_2259_ = !lean_is_exclusive(v_a_2213_);
if (v_isSharedCheck_2259_ == 0)
{
v___x_2220_ = v_a_2213_;
v_isShared_2221_ = v_isSharedCheck_2259_;
goto v_resetjp_2219_;
}
else
{
lean_inc(v_snd_2218_);
lean_inc(v_fst_2217_);
lean_dec(v_a_2213_);
v___x_2220_ = lean_box(0);
v_isShared_2221_ = v_isSharedCheck_2259_;
goto v_resetjp_2219_;
}
v_resetjp_2219_:
{
lean_object* v___x_2222_; lean_object* v___x_2223_; 
v___x_2222_ = lean_box(0);
lean_inc(v_us_2211_);
v___x_2223_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpUparams_spec__1(v_us_2211_, v___x_2222_, v_a_2107_, v_snd_2218_);
if (lean_obj_tag(v___x_2223_) == 0)
{
lean_object* v_a_2224_; lean_object* v_fst_2225_; lean_object* v_snd_2226_; lean_object* v___x_2228_; uint8_t v_isShared_2229_; uint8_t v_isSharedCheck_2250_; 
v_a_2224_ = lean_ctor_get(v___x_2223_, 0);
lean_inc(v_a_2224_);
lean_dec_ref_known(v___x_2223_, 1);
v_fst_2225_ = lean_ctor_get(v_a_2224_, 0);
v_snd_2226_ = lean_ctor_get(v_a_2224_, 1);
v_isSharedCheck_2250_ = !lean_is_exclusive(v_a_2224_);
if (v_isSharedCheck_2250_ == 0)
{
v___x_2228_ = v_a_2224_;
v_isShared_2229_ = v_isSharedCheck_2250_;
goto v_resetjp_2227_;
}
else
{
lean_inc(v_snd_2226_);
lean_inc(v_fst_2225_);
lean_dec(v_a_2224_);
v___x_2228_ = lean_box(0);
v_isShared_2229_ = v_isSharedCheck_2250_;
goto v_resetjp_2227_;
}
v_resetjp_2227_:
{
lean_object* v___x_2230_; lean_object* v___x_2231_; lean_object* v___x_2232_; lean_object* v___x_2234_; 
v___x_2230_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__3));
v___x_2231_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_2232_ = l_Lean_JsonNumber_fromNat(v_fst_2217_);
if (v_isShared_2216_ == 0)
{
lean_ctor_set_tag(v___x_2215_, 2);
lean_ctor_set(v___x_2215_, 0, v___x_2232_);
v___x_2234_ = v___x_2215_;
goto v_reusejp_2233_;
}
else
{
lean_object* v_reuseFailAlloc_2249_; 
v_reuseFailAlloc_2249_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2249_, 0, v___x_2232_);
v___x_2234_ = v_reuseFailAlloc_2249_;
goto v_reusejp_2233_;
}
v_reusejp_2233_:
{
lean_object* v___x_2236_; 
if (v_isShared_2229_ == 0)
{
lean_ctor_set(v___x_2228_, 1, v___x_2234_);
lean_ctor_set(v___x_2228_, 0, v___x_2231_);
v___x_2236_ = v___x_2228_;
goto v_reusejp_2235_;
}
else
{
lean_object* v_reuseFailAlloc_2248_; 
v_reuseFailAlloc_2248_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2248_, 0, v___x_2231_);
lean_ctor_set(v_reuseFailAlloc_2248_, 1, v___x_2234_);
v___x_2236_ = v_reuseFailAlloc_2248_;
goto v_reusejp_2235_;
}
v_reusejp_2235_:
{
lean_object* v___x_2237_; lean_object* v___x_2238_; lean_object* v___x_2240_; 
v___x_2237_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__4));
v___x_2238_ = lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(v_fst_2225_);
if (v_isShared_2221_ == 0)
{
lean_ctor_set(v___x_2220_, 1, v___x_2238_);
lean_ctor_set(v___x_2220_, 0, v___x_2237_);
v___x_2240_ = v___x_2220_;
goto v_reusejp_2239_;
}
else
{
lean_object* v_reuseFailAlloc_2247_; 
v_reuseFailAlloc_2247_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2247_, 0, v___x_2237_);
lean_ctor_set(v_reuseFailAlloc_2247_, 1, v___x_2238_);
v___x_2240_ = v_reuseFailAlloc_2247_;
goto v_reusejp_2239_;
}
v_reusejp_2239_:
{
lean_object* v___x_2241_; lean_object* v___x_2242_; lean_object* v___x_2243_; lean_object* v___x_2244_; lean_object* v___x_2245_; lean_object* v___x_2246_; 
v___x_2241_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2241_, 0, v___x_2240_);
lean_ctor_set(v___x_2241_, 1, v___x_2222_);
v___x_2242_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2242_, 0, v___x_2236_);
lean_ctor_set(v___x_2242_, 1, v___x_2241_);
v___x_2243_ = l_Lean_Json_mkObj(v___x_2242_);
lean_dec_ref_known(v___x_2242_, 2);
v___x_2244_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2244_, 0, v___x_2230_);
lean_ctor_set(v___x_2244_, 1, v___x_2243_);
v___x_2245_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2245_, 0, v___x_2244_);
lean_ctor_set(v___x_2245_, 1, v___x_2222_);
v___x_2246_ = l_Lean_Json_mkObj(v___x_2245_);
lean_dec_ref_known(v___x_2245_, 2);
v_fst_2167_ = v___x_2246_;
v_snd_2168_ = v_snd_2226_;
goto v___jp_2166_;
}
}
}
}
}
else
{
lean_object* v_a_2251_; lean_object* v___x_2253_; uint8_t v_isShared_2254_; uint8_t v_isSharedCheck_2258_; 
lean_del_object(v___x_2220_);
lean_dec(v_fst_2217_);
lean_del_object(v___x_2215_);
lean_dec_ref_known(v_e_2106_, 2);
v_a_2251_ = lean_ctor_get(v___x_2223_, 0);
v_isSharedCheck_2258_ = !lean_is_exclusive(v___x_2223_);
if (v_isSharedCheck_2258_ == 0)
{
v___x_2253_ = v___x_2223_;
v_isShared_2254_ = v_isSharedCheck_2258_;
goto v_resetjp_2252_;
}
else
{
lean_inc(v_a_2251_);
lean_dec(v___x_2223_);
v___x_2253_ = lean_box(0);
v_isShared_2254_ = v_isSharedCheck_2258_;
goto v_resetjp_2252_;
}
v_resetjp_2252_:
{
lean_object* v___x_2256_; 
if (v_isShared_2254_ == 0)
{
v___x_2256_ = v___x_2253_;
goto v_reusejp_2255_;
}
else
{
lean_object* v_reuseFailAlloc_2257_; 
v_reuseFailAlloc_2257_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2257_, 0, v_a_2251_);
v___x_2256_ = v_reuseFailAlloc_2257_;
goto v_reusejp_2255_;
}
v_reusejp_2255_:
{
return v___x_2256_;
}
}
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 2);
return v___x_2212_;
}
}
case 5:
{
lean_object* v_fn_2261_; lean_object* v_arg_2262_; lean_object* v___x_2263_; 
v_fn_2261_ = lean_ctor_get(v_e_2106_, 0);
v_arg_2262_ = lean_ctor_get(v_e_2106_, 1);
lean_inc_ref(v_fn_2261_);
v___x_2263_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_fn_2261_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2263_) == 0)
{
lean_object* v_a_2264_; lean_object* v___x_2266_; uint8_t v_isShared_2267_; uint8_t v_isSharedCheck_2310_; 
v_a_2264_ = lean_ctor_get(v___x_2263_, 0);
v_isSharedCheck_2310_ = !lean_is_exclusive(v___x_2263_);
if (v_isSharedCheck_2310_ == 0)
{
v___x_2266_ = v___x_2263_;
v_isShared_2267_ = v_isSharedCheck_2310_;
goto v_resetjp_2265_;
}
else
{
lean_inc(v_a_2264_);
lean_dec(v___x_2263_);
v___x_2266_ = lean_box(0);
v_isShared_2267_ = v_isSharedCheck_2310_;
goto v_resetjp_2265_;
}
v_resetjp_2265_:
{
lean_object* v_fst_2268_; lean_object* v_snd_2269_; lean_object* v___x_2271_; uint8_t v_isShared_2272_; uint8_t v_isSharedCheck_2309_; 
v_fst_2268_ = lean_ctor_get(v_a_2264_, 0);
v_snd_2269_ = lean_ctor_get(v_a_2264_, 1);
v_isSharedCheck_2309_ = !lean_is_exclusive(v_a_2264_);
if (v_isSharedCheck_2309_ == 0)
{
v___x_2271_ = v_a_2264_;
v_isShared_2272_ = v_isSharedCheck_2309_;
goto v_resetjp_2270_;
}
else
{
lean_inc(v_snd_2269_);
lean_inc(v_fst_2268_);
lean_dec(v_a_2264_);
v___x_2271_ = lean_box(0);
v_isShared_2272_ = v_isSharedCheck_2309_;
goto v_resetjp_2270_;
}
v_resetjp_2270_:
{
lean_object* v___x_2273_; 
lean_inc_ref(v_arg_2262_);
v___x_2273_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_arg_2262_, v_a_2107_, v_snd_2269_);
if (lean_obj_tag(v___x_2273_) == 0)
{
lean_object* v_a_2274_; lean_object* v___x_2276_; uint8_t v_isShared_2277_; uint8_t v_isSharedCheck_2308_; 
v_a_2274_ = lean_ctor_get(v___x_2273_, 0);
v_isSharedCheck_2308_ = !lean_is_exclusive(v___x_2273_);
if (v_isSharedCheck_2308_ == 0)
{
v___x_2276_ = v___x_2273_;
v_isShared_2277_ = v_isSharedCheck_2308_;
goto v_resetjp_2275_;
}
else
{
lean_inc(v_a_2274_);
lean_dec(v___x_2273_);
v___x_2276_ = lean_box(0);
v_isShared_2277_ = v_isSharedCheck_2308_;
goto v_resetjp_2275_;
}
v_resetjp_2275_:
{
lean_object* v_fst_2278_; lean_object* v_snd_2279_; lean_object* v___x_2281_; uint8_t v_isShared_2282_; uint8_t v_isSharedCheck_2307_; 
v_fst_2278_ = lean_ctor_get(v_a_2274_, 0);
v_snd_2279_ = lean_ctor_get(v_a_2274_, 1);
v_isSharedCheck_2307_ = !lean_is_exclusive(v_a_2274_);
if (v_isSharedCheck_2307_ == 0)
{
v___x_2281_ = v_a_2274_;
v_isShared_2282_ = v_isSharedCheck_2307_;
goto v_resetjp_2280_;
}
else
{
lean_inc(v_snd_2279_);
lean_inc(v_fst_2278_);
lean_dec(v_a_2274_);
v___x_2281_ = lean_box(0);
v_isShared_2282_ = v_isSharedCheck_2307_;
goto v_resetjp_2280_;
}
v_resetjp_2280_:
{
lean_object* v___x_2283_; lean_object* v___x_2284_; lean_object* v___x_2285_; lean_object* v___x_2287_; 
v___x_2283_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__5));
v___x_2284_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__6));
v___x_2285_ = l_Lean_JsonNumber_fromNat(v_fst_2268_);
if (v_isShared_2277_ == 0)
{
lean_ctor_set_tag(v___x_2276_, 2);
lean_ctor_set(v___x_2276_, 0, v___x_2285_);
v___x_2287_ = v___x_2276_;
goto v_reusejp_2286_;
}
else
{
lean_object* v_reuseFailAlloc_2306_; 
v_reuseFailAlloc_2306_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2306_, 0, v___x_2285_);
v___x_2287_ = v_reuseFailAlloc_2306_;
goto v_reusejp_2286_;
}
v_reusejp_2286_:
{
lean_object* v___x_2289_; 
if (v_isShared_2282_ == 0)
{
lean_ctor_set(v___x_2281_, 1, v___x_2287_);
lean_ctor_set(v___x_2281_, 0, v___x_2284_);
v___x_2289_ = v___x_2281_;
goto v_reusejp_2288_;
}
else
{
lean_object* v_reuseFailAlloc_2305_; 
v_reuseFailAlloc_2305_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2305_, 0, v___x_2284_);
lean_ctor_set(v_reuseFailAlloc_2305_, 1, v___x_2287_);
v___x_2289_ = v_reuseFailAlloc_2305_;
goto v_reusejp_2288_;
}
v_reusejp_2288_:
{
lean_object* v___x_2290_; lean_object* v___x_2291_; lean_object* v___x_2293_; 
v___x_2290_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__7));
v___x_2291_ = l_Lean_JsonNumber_fromNat(v_fst_2278_);
if (v_isShared_2267_ == 0)
{
lean_ctor_set_tag(v___x_2266_, 2);
lean_ctor_set(v___x_2266_, 0, v___x_2291_);
v___x_2293_ = v___x_2266_;
goto v_reusejp_2292_;
}
else
{
lean_object* v_reuseFailAlloc_2304_; 
v_reuseFailAlloc_2304_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2304_, 0, v___x_2291_);
v___x_2293_ = v_reuseFailAlloc_2304_;
goto v_reusejp_2292_;
}
v_reusejp_2292_:
{
lean_object* v___x_2295_; 
if (v_isShared_2272_ == 0)
{
lean_ctor_set(v___x_2271_, 1, v___x_2293_);
lean_ctor_set(v___x_2271_, 0, v___x_2290_);
v___x_2295_ = v___x_2271_;
goto v_reusejp_2294_;
}
else
{
lean_object* v_reuseFailAlloc_2303_; 
v_reuseFailAlloc_2303_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2303_, 0, v___x_2290_);
lean_ctor_set(v_reuseFailAlloc_2303_, 1, v___x_2293_);
v___x_2295_ = v_reuseFailAlloc_2303_;
goto v_reusejp_2294_;
}
v_reusejp_2294_:
{
lean_object* v___x_2296_; lean_object* v___x_2297_; lean_object* v___x_2298_; lean_object* v___x_2299_; lean_object* v___x_2300_; lean_object* v___x_2301_; lean_object* v___x_2302_; 
v___x_2296_ = lean_box(0);
v___x_2297_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2297_, 0, v___x_2295_);
lean_ctor_set(v___x_2297_, 1, v___x_2296_);
v___x_2298_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2298_, 0, v___x_2289_);
lean_ctor_set(v___x_2298_, 1, v___x_2297_);
v___x_2299_ = l_Lean_Json_mkObj(v___x_2298_);
lean_dec_ref_known(v___x_2298_, 2);
v___x_2300_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2300_, 0, v___x_2283_);
lean_ctor_set(v___x_2300_, 1, v___x_2299_);
v___x_2301_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2301_, 0, v___x_2300_);
lean_ctor_set(v___x_2301_, 1, v___x_2296_);
v___x_2302_ = l_Lean_Json_mkObj(v___x_2301_);
lean_dec_ref_known(v___x_2301_, 2);
v_fst_2167_ = v___x_2302_;
v_snd_2168_ = v_snd_2279_;
goto v___jp_2166_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2271_);
lean_dec(v_fst_2268_);
lean_del_object(v___x_2266_);
lean_dec_ref_known(v_e_2106_, 2);
return v___x_2273_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 2);
return v___x_2263_;
}
}
case 6:
{
lean_object* v_binderName_2311_; lean_object* v_binderType_2312_; lean_object* v_body_2313_; uint8_t v_binderInfo_2314_; lean_object* v___x_2315_; 
v_binderName_2311_ = lean_ctor_get(v_e_2106_, 0);
v_binderType_2312_ = lean_ctor_get(v_e_2106_, 1);
v_body_2313_ = lean_ctor_get(v_e_2106_, 2);
v_binderInfo_2314_ = lean_ctor_get_uint8(v_e_2106_, sizeof(void*)*3 + 8);
lean_inc(v_binderName_2311_);
v___x_2315_ = lp_proofEnvironment_CheckedExport_dumpName(v_binderName_2311_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2315_) == 0)
{
lean_object* v_a_2316_; lean_object* v___x_2318_; uint8_t v_isShared_2319_; uint8_t v_isSharedCheck_2387_; 
v_a_2316_ = lean_ctor_get(v___x_2315_, 0);
v_isSharedCheck_2387_ = !lean_is_exclusive(v___x_2315_);
if (v_isSharedCheck_2387_ == 0)
{
v___x_2318_ = v___x_2315_;
v_isShared_2319_ = v_isSharedCheck_2387_;
goto v_resetjp_2317_;
}
else
{
lean_inc(v_a_2316_);
lean_dec(v___x_2315_);
v___x_2318_ = lean_box(0);
v_isShared_2319_ = v_isSharedCheck_2387_;
goto v_resetjp_2317_;
}
v_resetjp_2317_:
{
lean_object* v_fst_2320_; lean_object* v_snd_2321_; lean_object* v___x_2323_; uint8_t v_isShared_2324_; uint8_t v_isSharedCheck_2386_; 
v_fst_2320_ = lean_ctor_get(v_a_2316_, 0);
v_snd_2321_ = lean_ctor_get(v_a_2316_, 1);
v_isSharedCheck_2386_ = !lean_is_exclusive(v_a_2316_);
if (v_isSharedCheck_2386_ == 0)
{
v___x_2323_ = v_a_2316_;
v_isShared_2324_ = v_isSharedCheck_2386_;
goto v_resetjp_2322_;
}
else
{
lean_inc(v_snd_2321_);
lean_inc(v_fst_2320_);
lean_dec(v_a_2316_);
v___x_2323_ = lean_box(0);
v_isShared_2324_ = v_isSharedCheck_2386_;
goto v_resetjp_2322_;
}
v_resetjp_2322_:
{
lean_object* v___x_2325_; 
lean_inc_ref(v_binderType_2312_);
v___x_2325_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_binderType_2312_, v_a_2107_, v_snd_2321_);
if (lean_obj_tag(v___x_2325_) == 0)
{
lean_object* v_a_2326_; lean_object* v___x_2328_; uint8_t v_isShared_2329_; uint8_t v_isSharedCheck_2385_; 
v_a_2326_ = lean_ctor_get(v___x_2325_, 0);
v_isSharedCheck_2385_ = !lean_is_exclusive(v___x_2325_);
if (v_isSharedCheck_2385_ == 0)
{
v___x_2328_ = v___x_2325_;
v_isShared_2329_ = v_isSharedCheck_2385_;
goto v_resetjp_2327_;
}
else
{
lean_inc(v_a_2326_);
lean_dec(v___x_2325_);
v___x_2328_ = lean_box(0);
v_isShared_2329_ = v_isSharedCheck_2385_;
goto v_resetjp_2327_;
}
v_resetjp_2327_:
{
lean_object* v_fst_2330_; lean_object* v_snd_2331_; lean_object* v___x_2333_; uint8_t v_isShared_2334_; uint8_t v_isSharedCheck_2384_; 
v_fst_2330_ = lean_ctor_get(v_a_2326_, 0);
v_snd_2331_ = lean_ctor_get(v_a_2326_, 1);
v_isSharedCheck_2384_ = !lean_is_exclusive(v_a_2326_);
if (v_isSharedCheck_2384_ == 0)
{
v___x_2333_ = v_a_2326_;
v_isShared_2334_ = v_isSharedCheck_2384_;
goto v_resetjp_2332_;
}
else
{
lean_inc(v_snd_2331_);
lean_inc(v_fst_2330_);
lean_dec(v_a_2326_);
v___x_2333_ = lean_box(0);
v_isShared_2334_ = v_isSharedCheck_2384_;
goto v_resetjp_2332_;
}
v_resetjp_2332_:
{
lean_object* v___x_2335_; 
lean_inc_ref(v_body_2313_);
v___x_2335_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_body_2313_, v_a_2107_, v_snd_2331_);
if (lean_obj_tag(v___x_2335_) == 0)
{
lean_object* v_a_2336_; lean_object* v___x_2338_; uint8_t v_isShared_2339_; uint8_t v_isSharedCheck_2383_; 
v_a_2336_ = lean_ctor_get(v___x_2335_, 0);
v_isSharedCheck_2383_ = !lean_is_exclusive(v___x_2335_);
if (v_isSharedCheck_2383_ == 0)
{
v___x_2338_ = v___x_2335_;
v_isShared_2339_ = v_isSharedCheck_2383_;
goto v_resetjp_2337_;
}
else
{
lean_inc(v_a_2336_);
lean_dec(v___x_2335_);
v___x_2338_ = lean_box(0);
v_isShared_2339_ = v_isSharedCheck_2383_;
goto v_resetjp_2337_;
}
v_resetjp_2337_:
{
lean_object* v_fst_2340_; lean_object* v_snd_2341_; lean_object* v___x_2343_; uint8_t v_isShared_2344_; uint8_t v_isSharedCheck_2382_; 
v_fst_2340_ = lean_ctor_get(v_a_2336_, 0);
v_snd_2341_ = lean_ctor_get(v_a_2336_, 1);
v_isSharedCheck_2382_ = !lean_is_exclusive(v_a_2336_);
if (v_isSharedCheck_2382_ == 0)
{
v___x_2343_ = v_a_2336_;
v_isShared_2344_ = v_isSharedCheck_2382_;
goto v_resetjp_2342_;
}
else
{
lean_inc(v_snd_2341_);
lean_inc(v_fst_2340_);
lean_dec(v_a_2336_);
v___x_2343_ = lean_box(0);
v_isShared_2344_ = v_isSharedCheck_2382_;
goto v_resetjp_2342_;
}
v_resetjp_2342_:
{
lean_object* v___x_2345_; lean_object* v___x_2346_; lean_object* v___x_2347_; lean_object* v___x_2349_; 
v___x_2345_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__8));
v___x_2346_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_2347_ = l_Lean_JsonNumber_fromNat(v_fst_2320_);
if (v_isShared_2339_ == 0)
{
lean_ctor_set_tag(v___x_2338_, 2);
lean_ctor_set(v___x_2338_, 0, v___x_2347_);
v___x_2349_ = v___x_2338_;
goto v_reusejp_2348_;
}
else
{
lean_object* v_reuseFailAlloc_2381_; 
v_reuseFailAlloc_2381_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2381_, 0, v___x_2347_);
v___x_2349_ = v_reuseFailAlloc_2381_;
goto v_reusejp_2348_;
}
v_reusejp_2348_:
{
lean_object* v___x_2351_; 
if (v_isShared_2344_ == 0)
{
lean_ctor_set(v___x_2343_, 1, v___x_2349_);
lean_ctor_set(v___x_2343_, 0, v___x_2346_);
v___x_2351_ = v___x_2343_;
goto v_reusejp_2350_;
}
else
{
lean_object* v_reuseFailAlloc_2380_; 
v_reuseFailAlloc_2380_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2380_, 0, v___x_2346_);
lean_ctor_set(v_reuseFailAlloc_2380_, 1, v___x_2349_);
v___x_2351_ = v_reuseFailAlloc_2380_;
goto v_reusejp_2350_;
}
v_reusejp_2350_:
{
lean_object* v___x_2352_; lean_object* v___x_2353_; lean_object* v___x_2355_; 
v___x_2352_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_2353_ = l_Lean_JsonNumber_fromNat(v_fst_2330_);
if (v_isShared_2329_ == 0)
{
lean_ctor_set_tag(v___x_2328_, 2);
lean_ctor_set(v___x_2328_, 0, v___x_2353_);
v___x_2355_ = v___x_2328_;
goto v_reusejp_2354_;
}
else
{
lean_object* v_reuseFailAlloc_2379_; 
v_reuseFailAlloc_2379_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2379_, 0, v___x_2353_);
v___x_2355_ = v_reuseFailAlloc_2379_;
goto v_reusejp_2354_;
}
v_reusejp_2354_:
{
lean_object* v___x_2357_; 
if (v_isShared_2334_ == 0)
{
lean_ctor_set(v___x_2333_, 1, v___x_2355_);
lean_ctor_set(v___x_2333_, 0, v___x_2352_);
v___x_2357_ = v___x_2333_;
goto v_reusejp_2356_;
}
else
{
lean_object* v_reuseFailAlloc_2378_; 
v_reuseFailAlloc_2378_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2378_, 0, v___x_2352_);
lean_ctor_set(v_reuseFailAlloc_2378_, 1, v___x_2355_);
v___x_2357_ = v_reuseFailAlloc_2378_;
goto v_reusejp_2356_;
}
v_reusejp_2356_:
{
lean_object* v___x_2358_; lean_object* v___x_2359_; lean_object* v___x_2361_; 
v___x_2358_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__9));
v___x_2359_ = l_Lean_JsonNumber_fromNat(v_fst_2340_);
if (v_isShared_2319_ == 0)
{
lean_ctor_set_tag(v___x_2318_, 2);
lean_ctor_set(v___x_2318_, 0, v___x_2359_);
v___x_2361_ = v___x_2318_;
goto v_reusejp_2360_;
}
else
{
lean_object* v_reuseFailAlloc_2377_; 
v_reuseFailAlloc_2377_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2377_, 0, v___x_2359_);
v___x_2361_ = v_reuseFailAlloc_2377_;
goto v_reusejp_2360_;
}
v_reusejp_2360_:
{
lean_object* v___x_2363_; 
if (v_isShared_2324_ == 0)
{
lean_ctor_set(v___x_2323_, 1, v___x_2361_);
lean_ctor_set(v___x_2323_, 0, v___x_2358_);
v___x_2363_ = v___x_2323_;
goto v_reusejp_2362_;
}
else
{
lean_object* v_reuseFailAlloc_2376_; 
v_reuseFailAlloc_2376_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2376_, 0, v___x_2358_);
lean_ctor_set(v_reuseFailAlloc_2376_, 1, v___x_2361_);
v___x_2363_ = v_reuseFailAlloc_2376_;
goto v_reusejp_2362_;
}
v_reusejp_2362_:
{
lean_object* v___x_2364_; lean_object* v___x_2365_; lean_object* v___x_2366_; lean_object* v___x_2367_; lean_object* v___x_2368_; lean_object* v___x_2369_; lean_object* v___x_2370_; lean_object* v___x_2371_; lean_object* v___x_2372_; lean_object* v___x_2373_; lean_object* v___x_2374_; lean_object* v___x_2375_; 
v___x_2364_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__10));
v___x_2365_ = lp_proofEnvironment_Lean_BinderInfo_toJson(v_binderInfo_2314_);
v___x_2366_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2366_, 0, v___x_2364_);
lean_ctor_set(v___x_2366_, 1, v___x_2365_);
v___x_2367_ = lean_box(0);
v___x_2368_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2368_, 0, v___x_2366_);
lean_ctor_set(v___x_2368_, 1, v___x_2367_);
v___x_2369_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2369_, 0, v___x_2363_);
lean_ctor_set(v___x_2369_, 1, v___x_2368_);
v___x_2370_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2370_, 0, v___x_2357_);
lean_ctor_set(v___x_2370_, 1, v___x_2369_);
v___x_2371_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2371_, 0, v___x_2351_);
lean_ctor_set(v___x_2371_, 1, v___x_2370_);
v___x_2372_ = l_Lean_Json_mkObj(v___x_2371_);
lean_dec_ref_known(v___x_2371_, 2);
v___x_2373_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2373_, 0, v___x_2345_);
lean_ctor_set(v___x_2373_, 1, v___x_2372_);
v___x_2374_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2374_, 0, v___x_2373_);
lean_ctor_set(v___x_2374_, 1, v___x_2367_);
v___x_2375_ = l_Lean_Json_mkObj(v___x_2374_);
lean_dec_ref_known(v___x_2374_, 2);
v_fst_2167_ = v___x_2375_;
v_snd_2168_ = v_snd_2341_;
goto v___jp_2166_;
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2333_);
lean_dec(v_fst_2330_);
lean_del_object(v___x_2328_);
lean_del_object(v___x_2323_);
lean_dec(v_fst_2320_);
lean_del_object(v___x_2318_);
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2335_;
}
}
}
}
else
{
lean_del_object(v___x_2323_);
lean_dec(v_fst_2320_);
lean_del_object(v___x_2318_);
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2325_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2315_;
}
}
case 7:
{
lean_object* v_binderName_2388_; lean_object* v_binderType_2389_; lean_object* v_body_2390_; uint8_t v_binderInfo_2391_; lean_object* v___x_2392_; 
v_binderName_2388_ = lean_ctor_get(v_e_2106_, 0);
v_binderType_2389_ = lean_ctor_get(v_e_2106_, 1);
v_body_2390_ = lean_ctor_get(v_e_2106_, 2);
v_binderInfo_2391_ = lean_ctor_get_uint8(v_e_2106_, sizeof(void*)*3 + 8);
lean_inc(v_binderName_2388_);
v___x_2392_ = lp_proofEnvironment_CheckedExport_dumpName(v_binderName_2388_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2392_) == 0)
{
lean_object* v_a_2393_; lean_object* v___x_2395_; uint8_t v_isShared_2396_; uint8_t v_isSharedCheck_2464_; 
v_a_2393_ = lean_ctor_get(v___x_2392_, 0);
v_isSharedCheck_2464_ = !lean_is_exclusive(v___x_2392_);
if (v_isSharedCheck_2464_ == 0)
{
v___x_2395_ = v___x_2392_;
v_isShared_2396_ = v_isSharedCheck_2464_;
goto v_resetjp_2394_;
}
else
{
lean_inc(v_a_2393_);
lean_dec(v___x_2392_);
v___x_2395_ = lean_box(0);
v_isShared_2396_ = v_isSharedCheck_2464_;
goto v_resetjp_2394_;
}
v_resetjp_2394_:
{
lean_object* v_fst_2397_; lean_object* v_snd_2398_; lean_object* v___x_2400_; uint8_t v_isShared_2401_; uint8_t v_isSharedCheck_2463_; 
v_fst_2397_ = lean_ctor_get(v_a_2393_, 0);
v_snd_2398_ = lean_ctor_get(v_a_2393_, 1);
v_isSharedCheck_2463_ = !lean_is_exclusive(v_a_2393_);
if (v_isSharedCheck_2463_ == 0)
{
v___x_2400_ = v_a_2393_;
v_isShared_2401_ = v_isSharedCheck_2463_;
goto v_resetjp_2399_;
}
else
{
lean_inc(v_snd_2398_);
lean_inc(v_fst_2397_);
lean_dec(v_a_2393_);
v___x_2400_ = lean_box(0);
v_isShared_2401_ = v_isSharedCheck_2463_;
goto v_resetjp_2399_;
}
v_resetjp_2399_:
{
lean_object* v___x_2402_; 
lean_inc_ref(v_binderType_2389_);
v___x_2402_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_binderType_2389_, v_a_2107_, v_snd_2398_);
if (lean_obj_tag(v___x_2402_) == 0)
{
lean_object* v_a_2403_; lean_object* v___x_2405_; uint8_t v_isShared_2406_; uint8_t v_isSharedCheck_2462_; 
v_a_2403_ = lean_ctor_get(v___x_2402_, 0);
v_isSharedCheck_2462_ = !lean_is_exclusive(v___x_2402_);
if (v_isSharedCheck_2462_ == 0)
{
v___x_2405_ = v___x_2402_;
v_isShared_2406_ = v_isSharedCheck_2462_;
goto v_resetjp_2404_;
}
else
{
lean_inc(v_a_2403_);
lean_dec(v___x_2402_);
v___x_2405_ = lean_box(0);
v_isShared_2406_ = v_isSharedCheck_2462_;
goto v_resetjp_2404_;
}
v_resetjp_2404_:
{
lean_object* v_fst_2407_; lean_object* v_snd_2408_; lean_object* v___x_2410_; uint8_t v_isShared_2411_; uint8_t v_isSharedCheck_2461_; 
v_fst_2407_ = lean_ctor_get(v_a_2403_, 0);
v_snd_2408_ = lean_ctor_get(v_a_2403_, 1);
v_isSharedCheck_2461_ = !lean_is_exclusive(v_a_2403_);
if (v_isSharedCheck_2461_ == 0)
{
v___x_2410_ = v_a_2403_;
v_isShared_2411_ = v_isSharedCheck_2461_;
goto v_resetjp_2409_;
}
else
{
lean_inc(v_snd_2408_);
lean_inc(v_fst_2407_);
lean_dec(v_a_2403_);
v___x_2410_ = lean_box(0);
v_isShared_2411_ = v_isSharedCheck_2461_;
goto v_resetjp_2409_;
}
v_resetjp_2409_:
{
lean_object* v___x_2412_; 
lean_inc_ref(v_body_2390_);
v___x_2412_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_body_2390_, v_a_2107_, v_snd_2408_);
if (lean_obj_tag(v___x_2412_) == 0)
{
lean_object* v_a_2413_; lean_object* v___x_2415_; uint8_t v_isShared_2416_; uint8_t v_isSharedCheck_2460_; 
v_a_2413_ = lean_ctor_get(v___x_2412_, 0);
v_isSharedCheck_2460_ = !lean_is_exclusive(v___x_2412_);
if (v_isSharedCheck_2460_ == 0)
{
v___x_2415_ = v___x_2412_;
v_isShared_2416_ = v_isSharedCheck_2460_;
goto v_resetjp_2414_;
}
else
{
lean_inc(v_a_2413_);
lean_dec(v___x_2412_);
v___x_2415_ = lean_box(0);
v_isShared_2416_ = v_isSharedCheck_2460_;
goto v_resetjp_2414_;
}
v_resetjp_2414_:
{
lean_object* v_fst_2417_; lean_object* v_snd_2418_; lean_object* v___x_2420_; uint8_t v_isShared_2421_; uint8_t v_isSharedCheck_2459_; 
v_fst_2417_ = lean_ctor_get(v_a_2413_, 0);
v_snd_2418_ = lean_ctor_get(v_a_2413_, 1);
v_isSharedCheck_2459_ = !lean_is_exclusive(v_a_2413_);
if (v_isSharedCheck_2459_ == 0)
{
v___x_2420_ = v_a_2413_;
v_isShared_2421_ = v_isSharedCheck_2459_;
goto v_resetjp_2419_;
}
else
{
lean_inc(v_snd_2418_);
lean_inc(v_fst_2417_);
lean_dec(v_a_2413_);
v___x_2420_ = lean_box(0);
v_isShared_2421_ = v_isSharedCheck_2459_;
goto v_resetjp_2419_;
}
v_resetjp_2419_:
{
lean_object* v___x_2422_; lean_object* v___x_2423_; lean_object* v___x_2424_; lean_object* v___x_2426_; 
v___x_2422_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__11));
v___x_2423_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_2424_ = l_Lean_JsonNumber_fromNat(v_fst_2397_);
if (v_isShared_2416_ == 0)
{
lean_ctor_set_tag(v___x_2415_, 2);
lean_ctor_set(v___x_2415_, 0, v___x_2424_);
v___x_2426_ = v___x_2415_;
goto v_reusejp_2425_;
}
else
{
lean_object* v_reuseFailAlloc_2458_; 
v_reuseFailAlloc_2458_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2458_, 0, v___x_2424_);
v___x_2426_ = v_reuseFailAlloc_2458_;
goto v_reusejp_2425_;
}
v_reusejp_2425_:
{
lean_object* v___x_2428_; 
if (v_isShared_2421_ == 0)
{
lean_ctor_set(v___x_2420_, 1, v___x_2426_);
lean_ctor_set(v___x_2420_, 0, v___x_2423_);
v___x_2428_ = v___x_2420_;
goto v_reusejp_2427_;
}
else
{
lean_object* v_reuseFailAlloc_2457_; 
v_reuseFailAlloc_2457_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2457_, 0, v___x_2423_);
lean_ctor_set(v_reuseFailAlloc_2457_, 1, v___x_2426_);
v___x_2428_ = v_reuseFailAlloc_2457_;
goto v_reusejp_2427_;
}
v_reusejp_2427_:
{
lean_object* v___x_2429_; lean_object* v___x_2430_; lean_object* v___x_2432_; 
v___x_2429_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_2430_ = l_Lean_JsonNumber_fromNat(v_fst_2407_);
if (v_isShared_2406_ == 0)
{
lean_ctor_set_tag(v___x_2405_, 2);
lean_ctor_set(v___x_2405_, 0, v___x_2430_);
v___x_2432_ = v___x_2405_;
goto v_reusejp_2431_;
}
else
{
lean_object* v_reuseFailAlloc_2456_; 
v_reuseFailAlloc_2456_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2456_, 0, v___x_2430_);
v___x_2432_ = v_reuseFailAlloc_2456_;
goto v_reusejp_2431_;
}
v_reusejp_2431_:
{
lean_object* v___x_2434_; 
if (v_isShared_2411_ == 0)
{
lean_ctor_set(v___x_2410_, 1, v___x_2432_);
lean_ctor_set(v___x_2410_, 0, v___x_2429_);
v___x_2434_ = v___x_2410_;
goto v_reusejp_2433_;
}
else
{
lean_object* v_reuseFailAlloc_2455_; 
v_reuseFailAlloc_2455_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2455_, 0, v___x_2429_);
lean_ctor_set(v_reuseFailAlloc_2455_, 1, v___x_2432_);
v___x_2434_ = v_reuseFailAlloc_2455_;
goto v_reusejp_2433_;
}
v_reusejp_2433_:
{
lean_object* v___x_2435_; lean_object* v___x_2436_; lean_object* v___x_2438_; 
v___x_2435_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__9));
v___x_2436_ = l_Lean_JsonNumber_fromNat(v_fst_2417_);
if (v_isShared_2396_ == 0)
{
lean_ctor_set_tag(v___x_2395_, 2);
lean_ctor_set(v___x_2395_, 0, v___x_2436_);
v___x_2438_ = v___x_2395_;
goto v_reusejp_2437_;
}
else
{
lean_object* v_reuseFailAlloc_2454_; 
v_reuseFailAlloc_2454_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2454_, 0, v___x_2436_);
v___x_2438_ = v_reuseFailAlloc_2454_;
goto v_reusejp_2437_;
}
v_reusejp_2437_:
{
lean_object* v___x_2440_; 
if (v_isShared_2401_ == 0)
{
lean_ctor_set(v___x_2400_, 1, v___x_2438_);
lean_ctor_set(v___x_2400_, 0, v___x_2435_);
v___x_2440_ = v___x_2400_;
goto v_reusejp_2439_;
}
else
{
lean_object* v_reuseFailAlloc_2453_; 
v_reuseFailAlloc_2453_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2453_, 0, v___x_2435_);
lean_ctor_set(v_reuseFailAlloc_2453_, 1, v___x_2438_);
v___x_2440_ = v_reuseFailAlloc_2453_;
goto v_reusejp_2439_;
}
v_reusejp_2439_:
{
lean_object* v___x_2441_; lean_object* v___x_2442_; lean_object* v___x_2443_; lean_object* v___x_2444_; lean_object* v___x_2445_; lean_object* v___x_2446_; lean_object* v___x_2447_; lean_object* v___x_2448_; lean_object* v___x_2449_; lean_object* v___x_2450_; lean_object* v___x_2451_; lean_object* v___x_2452_; 
v___x_2441_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__10));
v___x_2442_ = lp_proofEnvironment_Lean_BinderInfo_toJson(v_binderInfo_2391_);
v___x_2443_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2443_, 0, v___x_2441_);
lean_ctor_set(v___x_2443_, 1, v___x_2442_);
v___x_2444_ = lean_box(0);
v___x_2445_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2445_, 0, v___x_2443_);
lean_ctor_set(v___x_2445_, 1, v___x_2444_);
v___x_2446_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2446_, 0, v___x_2440_);
lean_ctor_set(v___x_2446_, 1, v___x_2445_);
v___x_2447_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2447_, 0, v___x_2434_);
lean_ctor_set(v___x_2447_, 1, v___x_2446_);
v___x_2448_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2448_, 0, v___x_2428_);
lean_ctor_set(v___x_2448_, 1, v___x_2447_);
v___x_2449_ = l_Lean_Json_mkObj(v___x_2448_);
lean_dec_ref_known(v___x_2448_, 2);
v___x_2450_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2450_, 0, v___x_2422_);
lean_ctor_set(v___x_2450_, 1, v___x_2449_);
v___x_2451_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2451_, 0, v___x_2450_);
lean_ctor_set(v___x_2451_, 1, v___x_2444_);
v___x_2452_ = l_Lean_Json_mkObj(v___x_2451_);
lean_dec_ref_known(v___x_2451_, 2);
v_fst_2167_ = v___x_2452_;
v_snd_2168_ = v_snd_2418_;
goto v___jp_2166_;
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2410_);
lean_dec(v_fst_2407_);
lean_del_object(v___x_2405_);
lean_del_object(v___x_2400_);
lean_dec(v_fst_2397_);
lean_del_object(v___x_2395_);
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2412_;
}
}
}
}
else
{
lean_del_object(v___x_2400_);
lean_dec(v_fst_2397_);
lean_del_object(v___x_2395_);
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2402_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2392_;
}
}
case 8:
{
lean_object* v_declName_2465_; lean_object* v_type_2466_; lean_object* v_value_2467_; lean_object* v_body_2468_; uint8_t v_nondep_2469_; lean_object* v___x_2470_; 
v_declName_2465_ = lean_ctor_get(v_e_2106_, 0);
v_type_2466_ = lean_ctor_get(v_e_2106_, 1);
v_value_2467_ = lean_ctor_get(v_e_2106_, 2);
v_body_2468_ = lean_ctor_get(v_e_2106_, 3);
v_nondep_2469_ = lean_ctor_get_uint8(v_e_2106_, sizeof(void*)*4 + 8);
lean_inc(v_declName_2465_);
v___x_2470_ = lp_proofEnvironment_CheckedExport_dumpName(v_declName_2465_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2470_) == 0)
{
lean_object* v_a_2471_; lean_object* v___x_2473_; uint8_t v_isShared_2474_; uint8_t v_isSharedCheck_2563_; 
v_a_2471_ = lean_ctor_get(v___x_2470_, 0);
v_isSharedCheck_2563_ = !lean_is_exclusive(v___x_2470_);
if (v_isSharedCheck_2563_ == 0)
{
v___x_2473_ = v___x_2470_;
v_isShared_2474_ = v_isSharedCheck_2563_;
goto v_resetjp_2472_;
}
else
{
lean_inc(v_a_2471_);
lean_dec(v___x_2470_);
v___x_2473_ = lean_box(0);
v_isShared_2474_ = v_isSharedCheck_2563_;
goto v_resetjp_2472_;
}
v_resetjp_2472_:
{
lean_object* v_fst_2475_; lean_object* v_snd_2476_; lean_object* v___x_2478_; uint8_t v_isShared_2479_; uint8_t v_isSharedCheck_2562_; 
v_fst_2475_ = lean_ctor_get(v_a_2471_, 0);
v_snd_2476_ = lean_ctor_get(v_a_2471_, 1);
v_isSharedCheck_2562_ = !lean_is_exclusive(v_a_2471_);
if (v_isSharedCheck_2562_ == 0)
{
v___x_2478_ = v_a_2471_;
v_isShared_2479_ = v_isSharedCheck_2562_;
goto v_resetjp_2477_;
}
else
{
lean_inc(v_snd_2476_);
lean_inc(v_fst_2475_);
lean_dec(v_a_2471_);
v___x_2478_ = lean_box(0);
v_isShared_2479_ = v_isSharedCheck_2562_;
goto v_resetjp_2477_;
}
v_resetjp_2477_:
{
lean_object* v___x_2480_; 
lean_inc_ref(v_type_2466_);
v___x_2480_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_type_2466_, v_a_2107_, v_snd_2476_);
if (lean_obj_tag(v___x_2480_) == 0)
{
lean_object* v_a_2481_; lean_object* v___x_2483_; uint8_t v_isShared_2484_; uint8_t v_isSharedCheck_2561_; 
v_a_2481_ = lean_ctor_get(v___x_2480_, 0);
v_isSharedCheck_2561_ = !lean_is_exclusive(v___x_2480_);
if (v_isSharedCheck_2561_ == 0)
{
v___x_2483_ = v___x_2480_;
v_isShared_2484_ = v_isSharedCheck_2561_;
goto v_resetjp_2482_;
}
else
{
lean_inc(v_a_2481_);
lean_dec(v___x_2480_);
v___x_2483_ = lean_box(0);
v_isShared_2484_ = v_isSharedCheck_2561_;
goto v_resetjp_2482_;
}
v_resetjp_2482_:
{
lean_object* v_fst_2485_; lean_object* v_snd_2486_; lean_object* v___x_2488_; uint8_t v_isShared_2489_; uint8_t v_isSharedCheck_2560_; 
v_fst_2485_ = lean_ctor_get(v_a_2481_, 0);
v_snd_2486_ = lean_ctor_get(v_a_2481_, 1);
v_isSharedCheck_2560_ = !lean_is_exclusive(v_a_2481_);
if (v_isSharedCheck_2560_ == 0)
{
v___x_2488_ = v_a_2481_;
v_isShared_2489_ = v_isSharedCheck_2560_;
goto v_resetjp_2487_;
}
else
{
lean_inc(v_snd_2486_);
lean_inc(v_fst_2485_);
lean_dec(v_a_2481_);
v___x_2488_ = lean_box(0);
v_isShared_2489_ = v_isSharedCheck_2560_;
goto v_resetjp_2487_;
}
v_resetjp_2487_:
{
lean_object* v___x_2490_; 
lean_inc_ref(v_value_2467_);
v___x_2490_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_value_2467_, v_a_2107_, v_snd_2486_);
if (lean_obj_tag(v___x_2490_) == 0)
{
lean_object* v_a_2491_; lean_object* v___x_2493_; uint8_t v_isShared_2494_; uint8_t v_isSharedCheck_2559_; 
v_a_2491_ = lean_ctor_get(v___x_2490_, 0);
v_isSharedCheck_2559_ = !lean_is_exclusive(v___x_2490_);
if (v_isSharedCheck_2559_ == 0)
{
v___x_2493_ = v___x_2490_;
v_isShared_2494_ = v_isSharedCheck_2559_;
goto v_resetjp_2492_;
}
else
{
lean_inc(v_a_2491_);
lean_dec(v___x_2490_);
v___x_2493_ = lean_box(0);
v_isShared_2494_ = v_isSharedCheck_2559_;
goto v_resetjp_2492_;
}
v_resetjp_2492_:
{
lean_object* v_fst_2495_; lean_object* v_snd_2496_; lean_object* v___x_2498_; uint8_t v_isShared_2499_; uint8_t v_isSharedCheck_2558_; 
v_fst_2495_ = lean_ctor_get(v_a_2491_, 0);
v_snd_2496_ = lean_ctor_get(v_a_2491_, 1);
v_isSharedCheck_2558_ = !lean_is_exclusive(v_a_2491_);
if (v_isSharedCheck_2558_ == 0)
{
v___x_2498_ = v_a_2491_;
v_isShared_2499_ = v_isSharedCheck_2558_;
goto v_resetjp_2497_;
}
else
{
lean_inc(v_snd_2496_);
lean_inc(v_fst_2495_);
lean_dec(v_a_2491_);
v___x_2498_ = lean_box(0);
v_isShared_2499_ = v_isSharedCheck_2558_;
goto v_resetjp_2497_;
}
v_resetjp_2497_:
{
lean_object* v___x_2500_; 
lean_inc_ref(v_body_2468_);
v___x_2500_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_body_2468_, v_a_2107_, v_snd_2496_);
if (lean_obj_tag(v___x_2500_) == 0)
{
lean_object* v_a_2501_; lean_object* v___x_2503_; uint8_t v_isShared_2504_; uint8_t v_isSharedCheck_2557_; 
v_a_2501_ = lean_ctor_get(v___x_2500_, 0);
v_isSharedCheck_2557_ = !lean_is_exclusive(v___x_2500_);
if (v_isSharedCheck_2557_ == 0)
{
v___x_2503_ = v___x_2500_;
v_isShared_2504_ = v_isSharedCheck_2557_;
goto v_resetjp_2502_;
}
else
{
lean_inc(v_a_2501_);
lean_dec(v___x_2500_);
v___x_2503_ = lean_box(0);
v_isShared_2504_ = v_isSharedCheck_2557_;
goto v_resetjp_2502_;
}
v_resetjp_2502_:
{
lean_object* v_fst_2505_; lean_object* v_snd_2506_; lean_object* v___x_2508_; uint8_t v_isShared_2509_; uint8_t v_isSharedCheck_2556_; 
v_fst_2505_ = lean_ctor_get(v_a_2501_, 0);
v_snd_2506_ = lean_ctor_get(v_a_2501_, 1);
v_isSharedCheck_2556_ = !lean_is_exclusive(v_a_2501_);
if (v_isSharedCheck_2556_ == 0)
{
v___x_2508_ = v_a_2501_;
v_isShared_2509_ = v_isSharedCheck_2556_;
goto v_resetjp_2507_;
}
else
{
lean_inc(v_snd_2506_);
lean_inc(v_fst_2505_);
lean_dec(v_a_2501_);
v___x_2508_ = lean_box(0);
v_isShared_2509_ = v_isSharedCheck_2556_;
goto v_resetjp_2507_;
}
v_resetjp_2507_:
{
lean_object* v___x_2510_; lean_object* v___x_2511_; lean_object* v___x_2512_; lean_object* v___x_2514_; 
v___x_2510_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__12));
v___x_2511_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_2512_ = l_Lean_JsonNumber_fromNat(v_fst_2475_);
if (v_isShared_2504_ == 0)
{
lean_ctor_set_tag(v___x_2503_, 2);
lean_ctor_set(v___x_2503_, 0, v___x_2512_);
v___x_2514_ = v___x_2503_;
goto v_reusejp_2513_;
}
else
{
lean_object* v_reuseFailAlloc_2555_; 
v_reuseFailAlloc_2555_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2555_, 0, v___x_2512_);
v___x_2514_ = v_reuseFailAlloc_2555_;
goto v_reusejp_2513_;
}
v_reusejp_2513_:
{
lean_object* v___x_2516_; 
if (v_isShared_2509_ == 0)
{
lean_ctor_set(v___x_2508_, 1, v___x_2514_);
lean_ctor_set(v___x_2508_, 0, v___x_2511_);
v___x_2516_ = v___x_2508_;
goto v_reusejp_2515_;
}
else
{
lean_object* v_reuseFailAlloc_2554_; 
v_reuseFailAlloc_2554_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2554_, 0, v___x_2511_);
lean_ctor_set(v_reuseFailAlloc_2554_, 1, v___x_2514_);
v___x_2516_ = v_reuseFailAlloc_2554_;
goto v_reusejp_2515_;
}
v_reusejp_2515_:
{
lean_object* v___x_2517_; lean_object* v___x_2518_; lean_object* v___x_2520_; 
v___x_2517_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_2518_ = l_Lean_JsonNumber_fromNat(v_fst_2485_);
if (v_isShared_2494_ == 0)
{
lean_ctor_set_tag(v___x_2493_, 2);
lean_ctor_set(v___x_2493_, 0, v___x_2518_);
v___x_2520_ = v___x_2493_;
goto v_reusejp_2519_;
}
else
{
lean_object* v_reuseFailAlloc_2553_; 
v_reuseFailAlloc_2553_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2553_, 0, v___x_2518_);
v___x_2520_ = v_reuseFailAlloc_2553_;
goto v_reusejp_2519_;
}
v_reusejp_2519_:
{
lean_object* v___x_2522_; 
if (v_isShared_2499_ == 0)
{
lean_ctor_set(v___x_2498_, 1, v___x_2520_);
lean_ctor_set(v___x_2498_, 0, v___x_2517_);
v___x_2522_ = v___x_2498_;
goto v_reusejp_2521_;
}
else
{
lean_object* v_reuseFailAlloc_2552_; 
v_reuseFailAlloc_2552_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2552_, 0, v___x_2517_);
lean_ctor_set(v_reuseFailAlloc_2552_, 1, v___x_2520_);
v___x_2522_ = v_reuseFailAlloc_2552_;
goto v_reusejp_2521_;
}
v_reusejp_2521_:
{
lean_object* v___x_2523_; lean_object* v___x_2524_; lean_object* v___x_2526_; 
v___x_2523_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13));
v___x_2524_ = l_Lean_JsonNumber_fromNat(v_fst_2495_);
if (v_isShared_2484_ == 0)
{
lean_ctor_set_tag(v___x_2483_, 2);
lean_ctor_set(v___x_2483_, 0, v___x_2524_);
v___x_2526_ = v___x_2483_;
goto v_reusejp_2525_;
}
else
{
lean_object* v_reuseFailAlloc_2551_; 
v_reuseFailAlloc_2551_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2551_, 0, v___x_2524_);
v___x_2526_ = v_reuseFailAlloc_2551_;
goto v_reusejp_2525_;
}
v_reusejp_2525_:
{
lean_object* v___x_2528_; 
if (v_isShared_2489_ == 0)
{
lean_ctor_set(v___x_2488_, 1, v___x_2526_);
lean_ctor_set(v___x_2488_, 0, v___x_2523_);
v___x_2528_ = v___x_2488_;
goto v_reusejp_2527_;
}
else
{
lean_object* v_reuseFailAlloc_2550_; 
v_reuseFailAlloc_2550_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2550_, 0, v___x_2523_);
lean_ctor_set(v_reuseFailAlloc_2550_, 1, v___x_2526_);
v___x_2528_ = v_reuseFailAlloc_2550_;
goto v_reusejp_2527_;
}
v_reusejp_2527_:
{
lean_object* v___x_2529_; lean_object* v___x_2530_; lean_object* v___x_2532_; 
v___x_2529_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__9));
v___x_2530_ = l_Lean_JsonNumber_fromNat(v_fst_2505_);
if (v_isShared_2474_ == 0)
{
lean_ctor_set_tag(v___x_2473_, 2);
lean_ctor_set(v___x_2473_, 0, v___x_2530_);
v___x_2532_ = v___x_2473_;
goto v_reusejp_2531_;
}
else
{
lean_object* v_reuseFailAlloc_2549_; 
v_reuseFailAlloc_2549_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2549_, 0, v___x_2530_);
v___x_2532_ = v_reuseFailAlloc_2549_;
goto v_reusejp_2531_;
}
v_reusejp_2531_:
{
lean_object* v___x_2534_; 
if (v_isShared_2479_ == 0)
{
lean_ctor_set(v___x_2478_, 1, v___x_2532_);
lean_ctor_set(v___x_2478_, 0, v___x_2529_);
v___x_2534_ = v___x_2478_;
goto v_reusejp_2533_;
}
else
{
lean_object* v_reuseFailAlloc_2548_; 
v_reuseFailAlloc_2548_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2548_, 0, v___x_2529_);
lean_ctor_set(v_reuseFailAlloc_2548_, 1, v___x_2532_);
v___x_2534_ = v_reuseFailAlloc_2548_;
goto v_reusejp_2533_;
}
v_reusejp_2533_:
{
lean_object* v___x_2535_; lean_object* v___x_2536_; lean_object* v___x_2537_; lean_object* v___x_2538_; lean_object* v___x_2539_; lean_object* v___x_2540_; lean_object* v___x_2541_; lean_object* v___x_2542_; lean_object* v___x_2543_; lean_object* v___x_2544_; lean_object* v___x_2545_; lean_object* v___x_2546_; lean_object* v___x_2547_; 
v___x_2535_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__14));
v___x_2536_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_2536_, 0, v_nondep_2469_);
v___x_2537_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2537_, 0, v___x_2535_);
lean_ctor_set(v___x_2537_, 1, v___x_2536_);
v___x_2538_ = lean_box(0);
v___x_2539_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2539_, 0, v___x_2537_);
lean_ctor_set(v___x_2539_, 1, v___x_2538_);
v___x_2540_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2540_, 0, v___x_2534_);
lean_ctor_set(v___x_2540_, 1, v___x_2539_);
v___x_2541_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2541_, 0, v___x_2528_);
lean_ctor_set(v___x_2541_, 1, v___x_2540_);
v___x_2542_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2542_, 0, v___x_2522_);
lean_ctor_set(v___x_2542_, 1, v___x_2541_);
v___x_2543_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2543_, 0, v___x_2516_);
lean_ctor_set(v___x_2543_, 1, v___x_2542_);
v___x_2544_ = l_Lean_Json_mkObj(v___x_2543_);
lean_dec_ref_known(v___x_2543_, 2);
v___x_2545_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2545_, 0, v___x_2510_);
lean_ctor_set(v___x_2545_, 1, v___x_2544_);
v___x_2546_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2546_, 0, v___x_2545_);
lean_ctor_set(v___x_2546_, 1, v___x_2538_);
v___x_2547_ = l_Lean_Json_mkObj(v___x_2546_);
lean_dec_ref_known(v___x_2546_, 2);
v_fst_2167_ = v___x_2547_;
v_snd_2168_ = v_snd_2506_;
goto v___jp_2166_;
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2498_);
lean_dec(v_fst_2495_);
lean_del_object(v___x_2493_);
lean_del_object(v___x_2488_);
lean_dec(v_fst_2485_);
lean_del_object(v___x_2483_);
lean_del_object(v___x_2478_);
lean_dec(v_fst_2475_);
lean_del_object(v___x_2473_);
lean_dec_ref_known(v_e_2106_, 4);
return v___x_2500_;
}
}
}
}
else
{
lean_del_object(v___x_2488_);
lean_dec(v_fst_2485_);
lean_del_object(v___x_2483_);
lean_del_object(v___x_2478_);
lean_dec(v_fst_2475_);
lean_del_object(v___x_2473_);
lean_dec_ref_known(v_e_2106_, 4);
return v___x_2490_;
}
}
}
}
else
{
lean_del_object(v___x_2478_);
lean_dec(v_fst_2475_);
lean_del_object(v___x_2473_);
lean_dec_ref_known(v_e_2106_, 4);
return v___x_2480_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 4);
return v___x_2470_;
}
}
case 9:
{
lean_object* v_a_2564_; 
v_a_2564_ = lean_ctor_get(v_e_2106_, 0);
lean_inc_ref(v_a_2564_);
if (lean_obj_tag(v_a_2564_) == 0)
{
lean_object* v_val_2565_; lean_object* v___x_2567_; uint8_t v_isShared_2568_; uint8_t v_isSharedCheck_2596_; 
v_val_2565_ = lean_ctor_get(v_a_2564_, 0);
v_isSharedCheck_2596_ = !lean_is_exclusive(v_a_2564_);
if (v_isSharedCheck_2596_ == 0)
{
v___x_2567_ = v_a_2564_;
v_isShared_2568_ = v_isSharedCheck_2596_;
goto v_resetjp_2566_;
}
else
{
lean_inc(v_val_2565_);
lean_dec(v_a_2564_);
v___x_2567_ = lean_box(0);
v_isShared_2568_ = v_isSharedCheck_2596_;
goto v_resetjp_2566_;
}
v_resetjp_2566_:
{
lean_object* v___x_2569_; 
v___x_2569_ = lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps(v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2569_) == 0)
{
lean_object* v_a_2570_; lean_object* v_snd_2571_; lean_object* v___x_2573_; uint8_t v_isShared_2574_; uint8_t v_isSharedCheck_2586_; 
v_a_2570_ = lean_ctor_get(v___x_2569_, 0);
lean_inc(v_a_2570_);
lean_dec_ref_known(v___x_2569_, 1);
v_snd_2571_ = lean_ctor_get(v_a_2570_, 1);
v_isSharedCheck_2586_ = !lean_is_exclusive(v_a_2570_);
if (v_isSharedCheck_2586_ == 0)
{
lean_object* v_unused_2587_; 
v_unused_2587_ = lean_ctor_get(v_a_2570_, 0);
lean_dec(v_unused_2587_);
v___x_2573_ = v_a_2570_;
v_isShared_2574_ = v_isSharedCheck_2586_;
goto v_resetjp_2572_;
}
else
{
lean_inc(v_snd_2571_);
lean_dec(v_a_2570_);
v___x_2573_ = lean_box(0);
v_isShared_2574_ = v_isSharedCheck_2586_;
goto v_resetjp_2572_;
}
v_resetjp_2572_:
{
lean_object* v___x_2575_; lean_object* v___x_2576_; lean_object* v___x_2578_; 
v___x_2575_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__15));
v___x_2576_ = l_Nat_reprFast(v_val_2565_);
if (v_isShared_2568_ == 0)
{
lean_ctor_set_tag(v___x_2567_, 3);
lean_ctor_set(v___x_2567_, 0, v___x_2576_);
v___x_2578_ = v___x_2567_;
goto v_reusejp_2577_;
}
else
{
lean_object* v_reuseFailAlloc_2585_; 
v_reuseFailAlloc_2585_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2585_, 0, v___x_2576_);
v___x_2578_ = v_reuseFailAlloc_2585_;
goto v_reusejp_2577_;
}
v_reusejp_2577_:
{
lean_object* v___x_2580_; 
if (v_isShared_2574_ == 0)
{
lean_ctor_set(v___x_2573_, 1, v___x_2578_);
lean_ctor_set(v___x_2573_, 0, v___x_2575_);
v___x_2580_ = v___x_2573_;
goto v_reusejp_2579_;
}
else
{
lean_object* v_reuseFailAlloc_2584_; 
v_reuseFailAlloc_2584_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2584_, 0, v___x_2575_);
lean_ctor_set(v_reuseFailAlloc_2584_, 1, v___x_2578_);
v___x_2580_ = v_reuseFailAlloc_2584_;
goto v_reusejp_2579_;
}
v_reusejp_2579_:
{
lean_object* v___x_2581_; lean_object* v___x_2582_; lean_object* v___x_2583_; 
v___x_2581_ = lean_box(0);
v___x_2582_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2582_, 0, v___x_2580_);
lean_ctor_set(v___x_2582_, 1, v___x_2581_);
v___x_2583_ = l_Lean_Json_mkObj(v___x_2582_);
lean_dec_ref_known(v___x_2582_, 2);
v_fst_2167_ = v___x_2583_;
v_snd_2168_ = v_snd_2571_;
goto v___jp_2166_;
}
}
}
}
else
{
lean_object* v_a_2588_; lean_object* v___x_2590_; uint8_t v_isShared_2591_; uint8_t v_isSharedCheck_2595_; 
lean_del_object(v___x_2567_);
lean_dec(v_val_2565_);
lean_dec_ref_known(v_e_2106_, 1);
v_a_2588_ = lean_ctor_get(v___x_2569_, 0);
v_isSharedCheck_2595_ = !lean_is_exclusive(v___x_2569_);
if (v_isSharedCheck_2595_ == 0)
{
v___x_2590_ = v___x_2569_;
v_isShared_2591_ = v_isSharedCheck_2595_;
goto v_resetjp_2589_;
}
else
{
lean_inc(v_a_2588_);
lean_dec(v___x_2569_);
v___x_2590_ = lean_box(0);
v_isShared_2591_ = v_isSharedCheck_2595_;
goto v_resetjp_2589_;
}
v_resetjp_2589_:
{
lean_object* v___x_2593_; 
if (v_isShared_2591_ == 0)
{
v___x_2593_ = v___x_2590_;
goto v_reusejp_2592_;
}
else
{
lean_object* v_reuseFailAlloc_2594_; 
v_reuseFailAlloc_2594_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2594_, 0, v_a_2588_);
v___x_2593_ = v_reuseFailAlloc_2594_;
goto v_reusejp_2592_;
}
v_reusejp_2592_:
{
return v___x_2593_;
}
}
}
}
}
else
{
lean_object* v_val_2597_; lean_object* v___x_2599_; uint8_t v_isShared_2600_; uint8_t v_isSharedCheck_2627_; 
v_val_2597_ = lean_ctor_get(v_a_2564_, 0);
v_isSharedCheck_2627_ = !lean_is_exclusive(v_a_2564_);
if (v_isSharedCheck_2627_ == 0)
{
v___x_2599_ = v_a_2564_;
v_isShared_2600_ = v_isSharedCheck_2627_;
goto v_resetjp_2598_;
}
else
{
lean_inc(v_val_2597_);
lean_dec(v_a_2564_);
v___x_2599_ = lean_box(0);
v_isShared_2600_ = v_isSharedCheck_2627_;
goto v_resetjp_2598_;
}
v_resetjp_2598_:
{
lean_object* v___x_2601_; 
v___x_2601_ = lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps(v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2601_) == 0)
{
lean_object* v_a_2602_; lean_object* v_snd_2603_; lean_object* v___x_2605_; uint8_t v_isShared_2606_; uint8_t v_isSharedCheck_2617_; 
v_a_2602_ = lean_ctor_get(v___x_2601_, 0);
lean_inc(v_a_2602_);
lean_dec_ref_known(v___x_2601_, 1);
v_snd_2603_ = lean_ctor_get(v_a_2602_, 1);
v_isSharedCheck_2617_ = !lean_is_exclusive(v_a_2602_);
if (v_isSharedCheck_2617_ == 0)
{
lean_object* v_unused_2618_; 
v_unused_2618_ = lean_ctor_get(v_a_2602_, 0);
lean_dec(v_unused_2618_);
v___x_2605_ = v_a_2602_;
v_isShared_2606_ = v_isSharedCheck_2617_;
goto v_resetjp_2604_;
}
else
{
lean_inc(v_snd_2603_);
lean_dec(v_a_2602_);
v___x_2605_ = lean_box(0);
v_isShared_2606_ = v_isSharedCheck_2617_;
goto v_resetjp_2604_;
}
v_resetjp_2604_:
{
lean_object* v___x_2607_; lean_object* v___x_2609_; 
v___x_2607_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__16));
if (v_isShared_2600_ == 0)
{
lean_ctor_set_tag(v___x_2599_, 3);
v___x_2609_ = v___x_2599_;
goto v_reusejp_2608_;
}
else
{
lean_object* v_reuseFailAlloc_2616_; 
v_reuseFailAlloc_2616_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2616_, 0, v_val_2597_);
v___x_2609_ = v_reuseFailAlloc_2616_;
goto v_reusejp_2608_;
}
v_reusejp_2608_:
{
lean_object* v___x_2611_; 
if (v_isShared_2606_ == 0)
{
lean_ctor_set(v___x_2605_, 1, v___x_2609_);
lean_ctor_set(v___x_2605_, 0, v___x_2607_);
v___x_2611_ = v___x_2605_;
goto v_reusejp_2610_;
}
else
{
lean_object* v_reuseFailAlloc_2615_; 
v_reuseFailAlloc_2615_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2615_, 0, v___x_2607_);
lean_ctor_set(v_reuseFailAlloc_2615_, 1, v___x_2609_);
v___x_2611_ = v_reuseFailAlloc_2615_;
goto v_reusejp_2610_;
}
v_reusejp_2610_:
{
lean_object* v___x_2612_; lean_object* v___x_2613_; lean_object* v___x_2614_; 
v___x_2612_ = lean_box(0);
v___x_2613_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2613_, 0, v___x_2611_);
lean_ctor_set(v___x_2613_, 1, v___x_2612_);
v___x_2614_ = l_Lean_Json_mkObj(v___x_2613_);
lean_dec_ref_known(v___x_2613_, 2);
v_fst_2167_ = v___x_2614_;
v_snd_2168_ = v_snd_2603_;
goto v___jp_2166_;
}
}
}
}
else
{
lean_object* v_a_2619_; lean_object* v___x_2621_; uint8_t v_isShared_2622_; uint8_t v_isSharedCheck_2626_; 
lean_del_object(v___x_2599_);
lean_dec_ref(v_val_2597_);
lean_dec_ref_known(v_e_2106_, 1);
v_a_2619_ = lean_ctor_get(v___x_2601_, 0);
v_isSharedCheck_2626_ = !lean_is_exclusive(v___x_2601_);
if (v_isSharedCheck_2626_ == 0)
{
v___x_2621_ = v___x_2601_;
v_isShared_2622_ = v_isSharedCheck_2626_;
goto v_resetjp_2620_;
}
else
{
lean_inc(v_a_2619_);
lean_dec(v___x_2601_);
v___x_2621_ = lean_box(0);
v_isShared_2622_ = v_isSharedCheck_2626_;
goto v_resetjp_2620_;
}
v_resetjp_2620_:
{
lean_object* v___x_2624_; 
if (v_isShared_2622_ == 0)
{
v___x_2624_ = v___x_2621_;
goto v_reusejp_2623_;
}
else
{
lean_object* v_reuseFailAlloc_2625_; 
v_reuseFailAlloc_2625_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2625_, 0, v_a_2619_);
v___x_2624_ = v_reuseFailAlloc_2625_;
goto v_reusejp_2623_;
}
v_reusejp_2623_:
{
return v___x_2624_;
}
}
}
}
}
}
case 10:
{
lean_object* v_data_2628_; lean_object* v_expr_2629_; lean_object* v___x_2630_; 
v_data_2628_ = lean_ctor_get(v_e_2106_, 0);
v_expr_2629_ = lean_ctor_get(v_e_2106_, 1);
lean_inc_ref(v_expr_2629_);
v___x_2630_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_expr_2629_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2630_) == 0)
{
lean_object* v_a_2631_; lean_object* v___x_2633_; uint8_t v_isShared_2634_; uint8_t v_isSharedCheck_2660_; 
v_a_2631_ = lean_ctor_get(v___x_2630_, 0);
v_isSharedCheck_2660_ = !lean_is_exclusive(v___x_2630_);
if (v_isSharedCheck_2660_ == 0)
{
v___x_2633_ = v___x_2630_;
v_isShared_2634_ = v_isSharedCheck_2660_;
goto v_resetjp_2632_;
}
else
{
lean_inc(v_a_2631_);
lean_dec(v___x_2630_);
v___x_2633_ = lean_box(0);
v_isShared_2634_ = v_isSharedCheck_2660_;
goto v_resetjp_2632_;
}
v_resetjp_2632_:
{
lean_object* v_fst_2635_; lean_object* v_snd_2636_; lean_object* v___x_2638_; uint8_t v_isShared_2639_; uint8_t v_isSharedCheck_2659_; 
v_fst_2635_ = lean_ctor_get(v_a_2631_, 0);
v_snd_2636_ = lean_ctor_get(v_a_2631_, 1);
v_isSharedCheck_2659_ = !lean_is_exclusive(v_a_2631_);
if (v_isSharedCheck_2659_ == 0)
{
v___x_2638_ = v_a_2631_;
v_isShared_2639_ = v_isSharedCheck_2659_;
goto v_resetjp_2637_;
}
else
{
lean_inc(v_snd_2636_);
lean_inc(v_fst_2635_);
lean_dec(v_a_2631_);
v___x_2638_ = lean_box(0);
v_isShared_2639_ = v_isSharedCheck_2659_;
goto v_resetjp_2637_;
}
v_resetjp_2637_:
{
lean_object* v___x_2640_; lean_object* v___x_2641_; lean_object* v___x_2642_; lean_object* v___x_2644_; 
v___x_2640_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__17));
v___x_2641_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__18));
lean_inc(v_data_2628_);
v___x_2642_ = lp_proofEnvironment_Lean_KVMap_toJson(v_data_2628_);
if (v_isShared_2639_ == 0)
{
lean_ctor_set(v___x_2638_, 1, v___x_2642_);
lean_ctor_set(v___x_2638_, 0, v___x_2641_);
v___x_2644_ = v___x_2638_;
goto v_reusejp_2643_;
}
else
{
lean_object* v_reuseFailAlloc_2658_; 
v_reuseFailAlloc_2658_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2658_, 0, v___x_2641_);
lean_ctor_set(v_reuseFailAlloc_2658_, 1, v___x_2642_);
v___x_2644_ = v_reuseFailAlloc_2658_;
goto v_reusejp_2643_;
}
v_reusejp_2643_:
{
lean_object* v___x_2645_; lean_object* v___x_2646_; lean_object* v___x_2648_; 
v___x_2645_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__19));
v___x_2646_ = l_Lean_JsonNumber_fromNat(v_fst_2635_);
if (v_isShared_2634_ == 0)
{
lean_ctor_set_tag(v___x_2633_, 2);
lean_ctor_set(v___x_2633_, 0, v___x_2646_);
v___x_2648_ = v___x_2633_;
goto v_reusejp_2647_;
}
else
{
lean_object* v_reuseFailAlloc_2657_; 
v_reuseFailAlloc_2657_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2657_, 0, v___x_2646_);
v___x_2648_ = v_reuseFailAlloc_2657_;
goto v_reusejp_2647_;
}
v_reusejp_2647_:
{
lean_object* v___x_2649_; lean_object* v___x_2650_; lean_object* v___x_2651_; lean_object* v___x_2652_; lean_object* v___x_2653_; lean_object* v___x_2654_; lean_object* v___x_2655_; lean_object* v___x_2656_; 
v___x_2649_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2649_, 0, v___x_2645_);
lean_ctor_set(v___x_2649_, 1, v___x_2648_);
v___x_2650_ = lean_box(0);
v___x_2651_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2651_, 0, v___x_2649_);
lean_ctor_set(v___x_2651_, 1, v___x_2650_);
v___x_2652_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2652_, 0, v___x_2644_);
lean_ctor_set(v___x_2652_, 1, v___x_2651_);
v___x_2653_ = l_Lean_Json_mkObj(v___x_2652_);
lean_dec_ref_known(v___x_2652_, 2);
v___x_2654_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2654_, 0, v___x_2640_);
lean_ctor_set(v___x_2654_, 1, v___x_2653_);
v___x_2655_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2655_, 0, v___x_2654_);
lean_ctor_set(v___x_2655_, 1, v___x_2650_);
v___x_2656_ = l_Lean_Json_mkObj(v___x_2655_);
lean_dec_ref_known(v___x_2655_, 2);
v_fst_2167_ = v___x_2656_;
v_snd_2168_ = v_snd_2636_;
goto v___jp_2166_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 2);
return v___x_2630_;
}
}
case 11:
{
lean_object* v_typeName_2661_; lean_object* v_idx_2662_; lean_object* v_struct_2663_; lean_object* v___x_2664_; 
v_typeName_2661_ = lean_ctor_get(v_e_2106_, 0);
v_idx_2662_ = lean_ctor_get(v_e_2106_, 1);
v_struct_2663_ = lean_ctor_get(v_e_2106_, 2);
lean_inc(v_typeName_2661_);
v___x_2664_ = lp_proofEnvironment_CheckedExport_dumpName(v_typeName_2661_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2664_) == 0)
{
lean_object* v_a_2665_; lean_object* v___x_2667_; uint8_t v_isShared_2668_; uint8_t v_isSharedCheck_2716_; 
v_a_2665_ = lean_ctor_get(v___x_2664_, 0);
v_isSharedCheck_2716_ = !lean_is_exclusive(v___x_2664_);
if (v_isSharedCheck_2716_ == 0)
{
v___x_2667_ = v___x_2664_;
v_isShared_2668_ = v_isSharedCheck_2716_;
goto v_resetjp_2666_;
}
else
{
lean_inc(v_a_2665_);
lean_dec(v___x_2664_);
v___x_2667_ = lean_box(0);
v_isShared_2668_ = v_isSharedCheck_2716_;
goto v_resetjp_2666_;
}
v_resetjp_2666_:
{
lean_object* v_fst_2669_; lean_object* v_snd_2670_; lean_object* v___x_2672_; uint8_t v_isShared_2673_; uint8_t v_isSharedCheck_2715_; 
v_fst_2669_ = lean_ctor_get(v_a_2665_, 0);
v_snd_2670_ = lean_ctor_get(v_a_2665_, 1);
v_isSharedCheck_2715_ = !lean_is_exclusive(v_a_2665_);
if (v_isSharedCheck_2715_ == 0)
{
v___x_2672_ = v_a_2665_;
v_isShared_2673_ = v_isSharedCheck_2715_;
goto v_resetjp_2671_;
}
else
{
lean_inc(v_snd_2670_);
lean_inc(v_fst_2669_);
lean_dec(v_a_2665_);
v___x_2672_ = lean_box(0);
v_isShared_2673_ = v_isSharedCheck_2715_;
goto v_resetjp_2671_;
}
v_resetjp_2671_:
{
lean_object* v___x_2674_; 
lean_inc_ref(v_struct_2663_);
v___x_2674_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_struct_2663_, v_a_2107_, v_snd_2670_);
if (lean_obj_tag(v___x_2674_) == 0)
{
lean_object* v_a_2675_; lean_object* v___x_2677_; uint8_t v_isShared_2678_; uint8_t v_isSharedCheck_2714_; 
v_a_2675_ = lean_ctor_get(v___x_2674_, 0);
v_isSharedCheck_2714_ = !lean_is_exclusive(v___x_2674_);
if (v_isSharedCheck_2714_ == 0)
{
v___x_2677_ = v___x_2674_;
v_isShared_2678_ = v_isSharedCheck_2714_;
goto v_resetjp_2676_;
}
else
{
lean_inc(v_a_2675_);
lean_dec(v___x_2674_);
v___x_2677_ = lean_box(0);
v_isShared_2678_ = v_isSharedCheck_2714_;
goto v_resetjp_2676_;
}
v_resetjp_2676_:
{
lean_object* v_fst_2679_; lean_object* v_snd_2680_; lean_object* v___x_2682_; uint8_t v_isShared_2683_; uint8_t v_isSharedCheck_2713_; 
v_fst_2679_ = lean_ctor_get(v_a_2675_, 0);
v_snd_2680_ = lean_ctor_get(v_a_2675_, 1);
v_isSharedCheck_2713_ = !lean_is_exclusive(v_a_2675_);
if (v_isSharedCheck_2713_ == 0)
{
v___x_2682_ = v_a_2675_;
v_isShared_2683_ = v_isSharedCheck_2713_;
goto v_resetjp_2681_;
}
else
{
lean_inc(v_snd_2680_);
lean_inc(v_fst_2679_);
lean_dec(v_a_2675_);
v___x_2682_ = lean_box(0);
v_isShared_2683_ = v_isSharedCheck_2713_;
goto v_resetjp_2681_;
}
v_resetjp_2681_:
{
lean_object* v___x_2684_; lean_object* v___x_2685_; lean_object* v___x_2686_; lean_object* v___x_2688_; 
v___x_2684_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__20));
v___x_2685_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__21));
v___x_2686_ = l_Lean_JsonNumber_fromNat(v_fst_2669_);
if (v_isShared_2678_ == 0)
{
lean_ctor_set_tag(v___x_2677_, 2);
lean_ctor_set(v___x_2677_, 0, v___x_2686_);
v___x_2688_ = v___x_2677_;
goto v_reusejp_2687_;
}
else
{
lean_object* v_reuseFailAlloc_2712_; 
v_reuseFailAlloc_2712_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2712_, 0, v___x_2686_);
v___x_2688_ = v_reuseFailAlloc_2712_;
goto v_reusejp_2687_;
}
v_reusejp_2687_:
{
lean_object* v___x_2690_; 
if (v_isShared_2683_ == 0)
{
lean_ctor_set(v___x_2682_, 1, v___x_2688_);
lean_ctor_set(v___x_2682_, 0, v___x_2685_);
v___x_2690_ = v___x_2682_;
goto v_reusejp_2689_;
}
else
{
lean_object* v_reuseFailAlloc_2711_; 
v_reuseFailAlloc_2711_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2711_, 0, v___x_2685_);
lean_ctor_set(v_reuseFailAlloc_2711_, 1, v___x_2688_);
v___x_2690_ = v_reuseFailAlloc_2711_;
goto v_reusejp_2689_;
}
v_reusejp_2689_:
{
lean_object* v___x_2691_; lean_object* v___x_2692_; lean_object* v___x_2694_; 
v___x_2691_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__22));
lean_inc(v_idx_2662_);
v___x_2692_ = l_Lean_JsonNumber_fromNat(v_idx_2662_);
if (v_isShared_2668_ == 0)
{
lean_ctor_set_tag(v___x_2667_, 2);
lean_ctor_set(v___x_2667_, 0, v___x_2692_);
v___x_2694_ = v___x_2667_;
goto v_reusejp_2693_;
}
else
{
lean_object* v_reuseFailAlloc_2710_; 
v_reuseFailAlloc_2710_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2710_, 0, v___x_2692_);
v___x_2694_ = v_reuseFailAlloc_2710_;
goto v_reusejp_2693_;
}
v_reusejp_2693_:
{
lean_object* v___x_2696_; 
if (v_isShared_2673_ == 0)
{
lean_ctor_set(v___x_2672_, 1, v___x_2694_);
lean_ctor_set(v___x_2672_, 0, v___x_2691_);
v___x_2696_ = v___x_2672_;
goto v_reusejp_2695_;
}
else
{
lean_object* v_reuseFailAlloc_2709_; 
v_reuseFailAlloc_2709_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2709_, 0, v___x_2691_);
lean_ctor_set(v_reuseFailAlloc_2709_, 1, v___x_2694_);
v___x_2696_ = v_reuseFailAlloc_2709_;
goto v_reusejp_2695_;
}
v_reusejp_2695_:
{
lean_object* v___x_2697_; lean_object* v___x_2698_; lean_object* v___x_2699_; lean_object* v___x_2700_; lean_object* v___x_2701_; lean_object* v___x_2702_; lean_object* v___x_2703_; lean_object* v___x_2704_; lean_object* v___x_2705_; lean_object* v___x_2706_; lean_object* v___x_2707_; lean_object* v___x_2708_; 
v___x_2697_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__23));
v___x_2698_ = l_Lean_JsonNumber_fromNat(v_fst_2679_);
v___x_2699_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2699_, 0, v___x_2698_);
v___x_2700_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2700_, 0, v___x_2697_);
lean_ctor_set(v___x_2700_, 1, v___x_2699_);
v___x_2701_ = lean_box(0);
v___x_2702_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2702_, 0, v___x_2700_);
lean_ctor_set(v___x_2702_, 1, v___x_2701_);
v___x_2703_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2703_, 0, v___x_2696_);
lean_ctor_set(v___x_2703_, 1, v___x_2702_);
v___x_2704_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2704_, 0, v___x_2690_);
lean_ctor_set(v___x_2704_, 1, v___x_2703_);
v___x_2705_ = l_Lean_Json_mkObj(v___x_2704_);
lean_dec_ref_known(v___x_2704_, 2);
v___x_2706_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2706_, 0, v___x_2684_);
lean_ctor_set(v___x_2706_, 1, v___x_2705_);
v___x_2707_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2707_, 0, v___x_2706_);
lean_ctor_set(v___x_2707_, 1, v___x_2701_);
v___x_2708_ = l_Lean_Json_mkObj(v___x_2707_);
lean_dec_ref_known(v___x_2707_, 2);
v_fst_2167_ = v___x_2708_;
v_snd_2168_ = v_snd_2680_;
goto v___jp_2166_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2672_);
lean_dec(v_fst_2669_);
lean_del_object(v___x_2667_);
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2674_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2106_, 3);
return v___x_2664_;
}
}
default: 
{
lean_object* v___x_2717_; lean_object* v___x_2718_; 
v___x_2717_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_dumpExprAux___closed__26, &lp_proofEnvironment_CheckedExport_dumpExprAux___closed__26_once, _init_lp_proofEnvironment_CheckedExport_dumpExprAux___closed__26);
v___x_2718_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpName_spec__0(v___x_2717_, v_a_2107_, v_a_2108_);
if (lean_obj_tag(v___x_2718_) == 0)
{
lean_object* v_a_2719_; lean_object* v_fst_2720_; lean_object* v_snd_2721_; 
v_a_2719_ = lean_ctor_get(v___x_2718_, 0);
lean_inc(v_a_2719_);
lean_dec_ref_known(v___x_2718_, 1);
v_fst_2720_ = lean_ctor_get(v_a_2719_, 0);
lean_inc(v_fst_2720_);
v_snd_2721_ = lean_ctor_get(v_a_2719_, 1);
lean_inc(v_snd_2721_);
lean_dec(v_a_2719_);
v_fst_2167_ = v_fst_2720_;
v_snd_2168_ = v_snd_2721_;
goto v___jp_2166_;
}
else
{
lean_object* v_a_2722_; lean_object* v___x_2724_; uint8_t v_isShared_2725_; uint8_t v_isSharedCheck_2729_; 
lean_dec_ref(v_e_2106_);
v_a_2722_ = lean_ctor_get(v___x_2718_, 0);
v_isSharedCheck_2729_ = !lean_is_exclusive(v___x_2718_);
if (v_isSharedCheck_2729_ == 0)
{
v___x_2724_ = v___x_2718_;
v_isShared_2725_ = v_isSharedCheck_2729_;
goto v_resetjp_2723_;
}
else
{
lean_inc(v_a_2722_);
lean_dec(v___x_2718_);
v___x_2724_ = lean_box(0);
v_isShared_2725_ = v_isSharedCheck_2729_;
goto v_resetjp_2723_;
}
v_resetjp_2723_:
{
lean_object* v___x_2727_; 
if (v_isShared_2725_ == 0)
{
v___x_2727_ = v___x_2724_;
goto v_reusejp_2726_;
}
else
{
lean_object* v_reuseFailAlloc_2728_; 
v_reuseFailAlloc_2728_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2728_, 0, v_a_2722_);
v___x_2727_ = v_reuseFailAlloc_2728_;
goto v_reusejp_2726_;
}
v_reusejp_2726_:
{
return v___x_2727_;
}
}
}
}
}
v___jp_2130_:
{
lean_object* v_size_2141_; lean_object* v___x_2142_; lean_object* v___x_2143_; lean_object* v___x_2144_; lean_object* v___x_2145_; lean_object* v___x_2146_; 
v_size_2141_ = lean_ctor_get(v_visitedExprs_2134_, 0);
lean_inc_n(v_size_2141_, 2);
v___x_2142_ = l_Lean_JsonNumber_fromNat(v_size_2141_);
v___x_2143_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2143_, 0, v___x_2142_);
v___x_2144_ = l_Lean_Json_setObjVal_x21(v_fst_2131_, v___x_2129_, v___x_2143_);
v___x_2145_ = l_Lean_Json_compress(v___x_2144_);
v___x_2146_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_2145_);
if (lean_obj_tag(v___x_2146_) == 0)
{
lean_object* v___x_2148_; uint8_t v_isShared_2149_; uint8_t v_isSharedCheck_2156_; 
v_isSharedCheck_2156_ = !lean_is_exclusive(v___x_2146_);
if (v_isSharedCheck_2156_ == 0)
{
lean_object* v_unused_2157_; 
v_unused_2157_ = lean_ctor_get(v___x_2146_, 0);
lean_dec(v_unused_2157_);
v___x_2148_ = v___x_2146_;
v_isShared_2149_ = v_isSharedCheck_2156_;
goto v_resetjp_2147_;
}
else
{
lean_dec(v___x_2146_);
v___x_2148_ = lean_box(0);
v_isShared_2149_ = v_isSharedCheck_2156_;
goto v_resetjp_2147_;
}
v_resetjp_2147_:
{
lean_object* v___x_2150_; lean_object* v___x_2151_; lean_object* v___x_2152_; lean_object* v___x_2154_; 
lean_inc(v_size_2141_);
v___x_2150_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__2___redArg(v_visitedExprs_2134_, v_e_2106_, v_size_2141_);
v___x_2151_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_2151_, 0, v_visitedNames_2132_);
lean_ctor_set(v___x_2151_, 1, v_visitedLevels_2133_);
lean_ctor_set(v___x_2151_, 2, v___x_2150_);
lean_ctor_set(v___x_2151_, 3, v_visitedConstants_2135_);
lean_ctor_set(v___x_2151_, 4, v_noMDataExprs_2136_);
lean_ctor_set(v___x_2151_, 5, v_recursorMap_2140_);
lean_ctor_set_uint8(v___x_2151_, sizeof(void*)*6, v_exportMData_2137_);
lean_ctor_set_uint8(v___x_2151_, sizeof(void*)*6 + 1, v_exportUnsafe_2138_);
lean_ctor_set_uint8(v___x_2151_, sizeof(void*)*6 + 2, v_ignoreMissing_2139_);
v___x_2152_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2152_, 0, v_size_2141_);
lean_ctor_set(v___x_2152_, 1, v___x_2151_);
if (v_isShared_2149_ == 0)
{
lean_ctor_set(v___x_2148_, 0, v___x_2152_);
v___x_2154_ = v___x_2148_;
goto v_reusejp_2153_;
}
else
{
lean_object* v_reuseFailAlloc_2155_; 
v_reuseFailAlloc_2155_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2155_, 0, v___x_2152_);
v___x_2154_ = v_reuseFailAlloc_2155_;
goto v_reusejp_2153_;
}
v_reusejp_2153_:
{
return v___x_2154_;
}
}
}
else
{
lean_object* v_a_2158_; lean_object* v___x_2160_; uint8_t v_isShared_2161_; uint8_t v_isSharedCheck_2165_; 
lean_dec(v_size_2141_);
lean_dec(v_recursorMap_2140_);
lean_dec_ref(v_noMDataExprs_2136_);
lean_dec_ref(v_visitedConstants_2135_);
lean_dec_ref(v_visitedExprs_2134_);
lean_dec_ref(v_visitedLevels_2133_);
lean_dec_ref(v_visitedNames_2132_);
lean_dec_ref(v_e_2106_);
v_a_2158_ = lean_ctor_get(v___x_2146_, 0);
v_isSharedCheck_2165_ = !lean_is_exclusive(v___x_2146_);
if (v_isSharedCheck_2165_ == 0)
{
v___x_2160_ = v___x_2146_;
v_isShared_2161_ = v_isSharedCheck_2165_;
goto v_resetjp_2159_;
}
else
{
lean_inc(v_a_2158_);
lean_dec(v___x_2146_);
v___x_2160_ = lean_box(0);
v_isShared_2161_ = v_isSharedCheck_2165_;
goto v_resetjp_2159_;
}
v_resetjp_2159_:
{
lean_object* v___x_2163_; 
if (v_isShared_2161_ == 0)
{
v___x_2163_ = v___x_2160_;
goto v_reusejp_2162_;
}
else
{
lean_object* v_reuseFailAlloc_2164_; 
v_reuseFailAlloc_2164_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2164_, 0, v_a_2158_);
v___x_2163_ = v_reuseFailAlloc_2164_;
goto v_reusejp_2162_;
}
v_reusejp_2162_:
{
return v___x_2163_;
}
}
}
}
v___jp_2166_:
{
lean_object* v_visitedNames_2169_; lean_object* v_visitedLevels_2170_; lean_object* v_visitedExprs_2171_; lean_object* v_visitedConstants_2172_; lean_object* v_noMDataExprs_2173_; uint8_t v_exportMData_2174_; uint8_t v_exportUnsafe_2175_; uint8_t v_ignoreMissing_2176_; lean_object* v_recursorMap_2177_; 
v_visitedNames_2169_ = lean_ctor_get(v_snd_2168_, 0);
lean_inc_ref(v_visitedNames_2169_);
v_visitedLevels_2170_ = lean_ctor_get(v_snd_2168_, 1);
lean_inc_ref(v_visitedLevels_2170_);
v_visitedExprs_2171_ = lean_ctor_get(v_snd_2168_, 2);
lean_inc_ref(v_visitedExprs_2171_);
v_visitedConstants_2172_ = lean_ctor_get(v_snd_2168_, 3);
lean_inc_ref(v_visitedConstants_2172_);
v_noMDataExprs_2173_ = lean_ctor_get(v_snd_2168_, 4);
lean_inc_ref(v_noMDataExprs_2173_);
v_exportMData_2174_ = lean_ctor_get_uint8(v_snd_2168_, sizeof(void*)*6);
v_exportUnsafe_2175_ = lean_ctor_get_uint8(v_snd_2168_, sizeof(void*)*6 + 1);
v_ignoreMissing_2176_ = lean_ctor_get_uint8(v_snd_2168_, sizeof(void*)*6 + 2);
v_recursorMap_2177_ = lean_ctor_get(v_snd_2168_, 5);
lean_inc(v_recursorMap_2177_);
lean_dec_ref(v_snd_2168_);
v_fst_2131_ = v_fst_2167_;
v_visitedNames_2132_ = v_visitedNames_2169_;
v_visitedLevels_2133_ = v_visitedLevels_2170_;
v_visitedExprs_2134_ = v_visitedExprs_2171_;
v_visitedConstants_2135_ = v_visitedConstants_2172_;
v_noMDataExprs_2136_ = v_noMDataExprs_2173_;
v_exportMData_2137_ = v_exportMData_2174_;
v_exportUnsafe_2138_ = v_exportUnsafe_2175_;
v_ignoreMissing_2139_ = v_ignoreMissing_2176_;
v_recursorMap_2140_ = v_recursorMap_2177_;
goto v___jp_2130_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExpr(lean_object* v_e_2730_, lean_object* v_a_2731_, lean_object* v_a_2732_){
_start:
{
uint8_t v_exportMData_2734_; 
v_exportMData_2734_ = lean_ctor_get_uint8(v_a_2732_, sizeof(void*)*6);
if (v_exportMData_2734_ == 0)
{
lean_object* v_visitedNames_2735_; lean_object* v_visitedLevels_2736_; lean_object* v_visitedExprs_2737_; lean_object* v_visitedConstants_2738_; uint8_t v_exportUnsafe_2739_; uint8_t v_ignoreMissing_2740_; lean_object* v_recursorMap_2741_; lean_object* v___x_2743_; uint8_t v_isShared_2744_; uint8_t v_isSharedCheck_2762_; 
v_visitedNames_2735_ = lean_ctor_get(v_a_2732_, 0);
v_visitedLevels_2736_ = lean_ctor_get(v_a_2732_, 1);
v_visitedExprs_2737_ = lean_ctor_get(v_a_2732_, 2);
v_visitedConstants_2738_ = lean_ctor_get(v_a_2732_, 3);
v_exportUnsafe_2739_ = lean_ctor_get_uint8(v_a_2732_, sizeof(void*)*6 + 1);
v_ignoreMissing_2740_ = lean_ctor_get_uint8(v_a_2732_, sizeof(void*)*6 + 2);
v_recursorMap_2741_ = lean_ctor_get(v_a_2732_, 5);
v_isSharedCheck_2762_ = !lean_is_exclusive(v_a_2732_);
if (v_isSharedCheck_2762_ == 0)
{
lean_object* v_unused_2763_; 
v_unused_2763_ = lean_ctor_get(v_a_2732_, 4);
lean_dec(v_unused_2763_);
v___x_2743_ = v_a_2732_;
v_isShared_2744_ = v_isSharedCheck_2762_;
goto v_resetjp_2742_;
}
else
{
lean_inc(v_recursorMap_2741_);
lean_inc(v_visitedConstants_2738_);
lean_inc(v_visitedExprs_2737_);
lean_inc(v_visitedLevels_2736_);
lean_inc(v_visitedNames_2735_);
lean_dec(v_a_2732_);
v___x_2743_ = lean_box(0);
v_isShared_2744_ = v_isSharedCheck_2762_;
goto v_resetjp_2742_;
}
v_resetjp_2742_:
{
lean_object* v___x_2745_; lean_object* v___x_2747_; 
v___x_2745_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_dumpExpr___closed__1, &lp_proofEnvironment_CheckedExport_dumpExpr___closed__1_once, _init_lp_proofEnvironment_CheckedExport_dumpExpr___closed__1);
if (v_isShared_2744_ == 0)
{
lean_ctor_set(v___x_2743_, 4, v___x_2745_);
v___x_2747_ = v___x_2743_;
goto v_reusejp_2746_;
}
else
{
lean_object* v_reuseFailAlloc_2761_; 
v_reuseFailAlloc_2761_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_2761_, 0, v_visitedNames_2735_);
lean_ctor_set(v_reuseFailAlloc_2761_, 1, v_visitedLevels_2736_);
lean_ctor_set(v_reuseFailAlloc_2761_, 2, v_visitedExprs_2737_);
lean_ctor_set(v_reuseFailAlloc_2761_, 3, v_visitedConstants_2738_);
lean_ctor_set(v_reuseFailAlloc_2761_, 4, v___x_2745_);
lean_ctor_set(v_reuseFailAlloc_2761_, 5, v_recursorMap_2741_);
lean_ctor_set_uint8(v_reuseFailAlloc_2761_, sizeof(void*)*6, v_exportMData_2734_);
lean_ctor_set_uint8(v_reuseFailAlloc_2761_, sizeof(void*)*6 + 1, v_exportUnsafe_2739_);
lean_ctor_set_uint8(v_reuseFailAlloc_2761_, sizeof(void*)*6 + 2, v_ignoreMissing_2740_);
v___x_2747_ = v_reuseFailAlloc_2761_;
goto v_reusejp_2746_;
}
v_reusejp_2746_:
{
lean_object* v___x_2748_; 
v___x_2748_ = lp_proofEnvironment_CheckedExport_removeMData(v_e_2730_, v_a_2731_, v___x_2747_);
if (lean_obj_tag(v___x_2748_) == 0)
{
lean_object* v_a_2749_; lean_object* v_fst_2750_; lean_object* v_snd_2751_; lean_object* v___x_2752_; 
v_a_2749_ = lean_ctor_get(v___x_2748_, 0);
lean_inc(v_a_2749_);
lean_dec_ref_known(v___x_2748_, 1);
v_fst_2750_ = lean_ctor_get(v_a_2749_, 0);
lean_inc(v_fst_2750_);
v_snd_2751_ = lean_ctor_get(v_a_2749_, 1);
lean_inc(v_snd_2751_);
lean_dec(v_a_2749_);
v___x_2752_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_fst_2750_, v_a_2731_, v_snd_2751_);
return v___x_2752_;
}
else
{
lean_object* v_a_2753_; lean_object* v___x_2755_; uint8_t v_isShared_2756_; uint8_t v_isSharedCheck_2760_; 
v_a_2753_ = lean_ctor_get(v___x_2748_, 0);
v_isSharedCheck_2760_ = !lean_is_exclusive(v___x_2748_);
if (v_isSharedCheck_2760_ == 0)
{
v___x_2755_ = v___x_2748_;
v_isShared_2756_ = v_isSharedCheck_2760_;
goto v_resetjp_2754_;
}
else
{
lean_inc(v_a_2753_);
lean_dec(v___x_2748_);
v___x_2755_ = lean_box(0);
v_isShared_2756_ = v_isSharedCheck_2760_;
goto v_resetjp_2754_;
}
v_resetjp_2754_:
{
lean_object* v___x_2758_; 
if (v_isShared_2756_ == 0)
{
v___x_2758_ = v___x_2755_;
goto v_reusejp_2757_;
}
else
{
lean_object* v_reuseFailAlloc_2759_; 
v_reuseFailAlloc_2759_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2759_, 0, v_a_2753_);
v___x_2758_ = v_reuseFailAlloc_2759_;
goto v_reusejp_2757_;
}
v_reusejp_2757_:
{
return v___x_2758_;
}
}
}
}
}
}
else
{
lean_object* v___x_2764_; 
v___x_2764_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_e_2730_, v_a_2731_, v_a_2732_);
return v___x_2764_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15(size_t v_sz_2774_, size_t v_i_2775_, lean_object* v_bs_2776_, lean_object* v___y_2777_, lean_object* v___y_2778_){
_start:
{
uint8_t v___x_2780_; 
v___x_2780_ = lean_usize_dec_lt(v_i_2775_, v_sz_2774_);
if (v___x_2780_ == 0)
{
lean_object* v___x_2781_; lean_object* v___x_2782_; 
v___x_2781_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2781_, 0, v_bs_2776_);
lean_ctor_set(v___x_2781_, 1, v___y_2778_);
v___x_2782_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2782_, 0, v___x_2781_);
return v___x_2782_;
}
else
{
lean_object* v_v_2783_; lean_object* v_toConstantVal_2784_; lean_object* v_numParams_2785_; lean_object* v_numIndices_2786_; lean_object* v_all_2787_; lean_object* v_ctors_2788_; lean_object* v_numNested_2789_; uint8_t v_isRec_2790_; uint8_t v_isUnsafe_2791_; uint8_t v_isReflexive_2792_; lean_object* v_name_2793_; lean_object* v_levelParams_2794_; lean_object* v_type_2795_; lean_object* v___x_2796_; 
v_v_2783_ = lean_array_uget_borrowed(v_bs_2776_, v_i_2775_);
v_toConstantVal_2784_ = lean_ctor_get(v_v_2783_, 0);
v_numParams_2785_ = lean_ctor_get(v_v_2783_, 1);
lean_inc(v_numParams_2785_);
v_numIndices_2786_ = lean_ctor_get(v_v_2783_, 2);
lean_inc(v_numIndices_2786_);
v_all_2787_ = lean_ctor_get(v_v_2783_, 3);
lean_inc(v_all_2787_);
v_ctors_2788_ = lean_ctor_get(v_v_2783_, 4);
lean_inc(v_ctors_2788_);
v_numNested_2789_ = lean_ctor_get(v_v_2783_, 5);
lean_inc(v_numNested_2789_);
v_isRec_2790_ = lean_ctor_get_uint8(v_v_2783_, sizeof(void*)*6);
v_isUnsafe_2791_ = lean_ctor_get_uint8(v_v_2783_, sizeof(void*)*6 + 1);
v_isReflexive_2792_ = lean_ctor_get_uint8(v_v_2783_, sizeof(void*)*6 + 2);
v_name_2793_ = lean_ctor_get(v_toConstantVal_2784_, 0);
v_levelParams_2794_ = lean_ctor_get(v_toConstantVal_2784_, 1);
lean_inc(v_levelParams_2794_);
v_type_2795_ = lean_ctor_get(v_toConstantVal_2784_, 2);
lean_inc_ref(v_type_2795_);
lean_inc(v_name_2793_);
v___x_2796_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_2793_, v___y_2777_, v___y_2778_);
if (lean_obj_tag(v___x_2796_) == 0)
{
lean_object* v_a_2797_; lean_object* v_fst_2798_; lean_object* v_snd_2799_; lean_object* v___x_2801_; uint8_t v_isShared_2802_; uint8_t v_isSharedCheck_2941_; 
v_a_2797_ = lean_ctor_get(v___x_2796_, 0);
lean_inc(v_a_2797_);
lean_dec_ref_known(v___x_2796_, 1);
v_fst_2798_ = lean_ctor_get(v_a_2797_, 0);
v_snd_2799_ = lean_ctor_get(v_a_2797_, 1);
v_isSharedCheck_2941_ = !lean_is_exclusive(v_a_2797_);
if (v_isSharedCheck_2941_ == 0)
{
v___x_2801_ = v_a_2797_;
v_isShared_2802_ = v_isSharedCheck_2941_;
goto v_resetjp_2800_;
}
else
{
lean_inc(v_snd_2799_);
lean_inc(v_fst_2798_);
lean_dec(v_a_2797_);
v___x_2801_ = lean_box(0);
v_isShared_2802_ = v_isSharedCheck_2941_;
goto v_resetjp_2800_;
}
v_resetjp_2800_:
{
lean_object* v___x_2803_; lean_object* v_bs_x27_2804_; lean_object* v_fst_2806_; lean_object* v_snd_2807_; lean_object* v___y_2813_; lean_object* v___x_2825_; 
v___x_2803_ = lean_unsigned_to_nat(0u);
v_bs_x27_2804_ = lean_array_uset(v_bs_2776_, v_i_2775_, v___x_2803_);
v___x_2825_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_2794_, v___y_2777_, v_snd_2799_);
if (lean_obj_tag(v___x_2825_) == 0)
{
lean_object* v_a_2826_; lean_object* v___x_2828_; uint8_t v_isShared_2829_; uint8_t v_isSharedCheck_2940_; 
v_a_2826_ = lean_ctor_get(v___x_2825_, 0);
v_isSharedCheck_2940_ = !lean_is_exclusive(v___x_2825_);
if (v_isSharedCheck_2940_ == 0)
{
v___x_2828_ = v___x_2825_;
v_isShared_2829_ = v_isSharedCheck_2940_;
goto v_resetjp_2827_;
}
else
{
lean_inc(v_a_2826_);
lean_dec(v___x_2825_);
v___x_2828_ = lean_box(0);
v_isShared_2829_ = v_isSharedCheck_2940_;
goto v_resetjp_2827_;
}
v_resetjp_2827_:
{
lean_object* v_fst_2830_; lean_object* v_snd_2831_; lean_object* v___x_2833_; uint8_t v_isShared_2834_; uint8_t v_isSharedCheck_2939_; 
v_fst_2830_ = lean_ctor_get(v_a_2826_, 0);
v_snd_2831_ = lean_ctor_get(v_a_2826_, 1);
v_isSharedCheck_2939_ = !lean_is_exclusive(v_a_2826_);
if (v_isSharedCheck_2939_ == 0)
{
v___x_2833_ = v_a_2826_;
v_isShared_2834_ = v_isSharedCheck_2939_;
goto v_resetjp_2832_;
}
else
{
lean_inc(v_snd_2831_);
lean_inc(v_fst_2830_);
lean_dec(v_a_2826_);
v___x_2833_ = lean_box(0);
v_isShared_2834_ = v_isSharedCheck_2939_;
goto v_resetjp_2832_;
}
v_resetjp_2832_:
{
lean_object* v___x_2835_; 
v___x_2835_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_2795_, v___y_2777_, v_snd_2831_);
if (lean_obj_tag(v___x_2835_) == 0)
{
lean_object* v_a_2836_; lean_object* v_fst_2837_; lean_object* v_snd_2838_; lean_object* v___x_2840_; uint8_t v_isShared_2841_; uint8_t v_isSharedCheck_2930_; 
v_a_2836_ = lean_ctor_get(v___x_2835_, 0);
lean_inc(v_a_2836_);
lean_dec_ref_known(v___x_2835_, 1);
v_fst_2837_ = lean_ctor_get(v_a_2836_, 0);
v_snd_2838_ = lean_ctor_get(v_a_2836_, 1);
v_isSharedCheck_2930_ = !lean_is_exclusive(v_a_2836_);
if (v_isSharedCheck_2930_ == 0)
{
v___x_2840_ = v_a_2836_;
v_isShared_2841_ = v_isSharedCheck_2930_;
goto v_resetjp_2839_;
}
else
{
lean_inc(v_snd_2838_);
lean_inc(v_fst_2837_);
lean_dec(v_a_2836_);
v___x_2840_ = lean_box(0);
v_isShared_2841_ = v_isSharedCheck_2930_;
goto v_resetjp_2839_;
}
v_resetjp_2839_:
{
lean_object* v___x_2842_; 
v___x_2842_ = lp_proofEnvironment_CheckedExport_dumpNames(v_all_2787_, v___y_2777_, v_snd_2838_);
if (lean_obj_tag(v___x_2842_) == 0)
{
lean_object* v_a_2843_; lean_object* v___x_2845_; uint8_t v_isShared_2846_; uint8_t v_isSharedCheck_2929_; 
v_a_2843_ = lean_ctor_get(v___x_2842_, 0);
v_isSharedCheck_2929_ = !lean_is_exclusive(v___x_2842_);
if (v_isSharedCheck_2929_ == 0)
{
v___x_2845_ = v___x_2842_;
v_isShared_2846_ = v_isSharedCheck_2929_;
goto v_resetjp_2844_;
}
else
{
lean_inc(v_a_2843_);
lean_dec(v___x_2842_);
v___x_2845_ = lean_box(0);
v_isShared_2846_ = v_isSharedCheck_2929_;
goto v_resetjp_2844_;
}
v_resetjp_2844_:
{
lean_object* v_fst_2847_; lean_object* v_snd_2848_; lean_object* v___x_2850_; uint8_t v_isShared_2851_; uint8_t v_isSharedCheck_2928_; 
v_fst_2847_ = lean_ctor_get(v_a_2843_, 0);
v_snd_2848_ = lean_ctor_get(v_a_2843_, 1);
v_isSharedCheck_2928_ = !lean_is_exclusive(v_a_2843_);
if (v_isSharedCheck_2928_ == 0)
{
v___x_2850_ = v_a_2843_;
v_isShared_2851_ = v_isSharedCheck_2928_;
goto v_resetjp_2849_;
}
else
{
lean_inc(v_snd_2848_);
lean_inc(v_fst_2847_);
lean_dec(v_a_2843_);
v___x_2850_ = lean_box(0);
v_isShared_2851_ = v_isSharedCheck_2928_;
goto v_resetjp_2849_;
}
v_resetjp_2849_:
{
lean_object* v___x_2852_; 
v___x_2852_ = lp_proofEnvironment_CheckedExport_dumpNames(v_ctors_2788_, v___y_2777_, v_snd_2848_);
if (lean_obj_tag(v___x_2852_) == 0)
{
lean_object* v_a_2853_; lean_object* v___x_2855_; uint8_t v_isShared_2856_; uint8_t v_isSharedCheck_2927_; 
v_a_2853_ = lean_ctor_get(v___x_2852_, 0);
v_isSharedCheck_2927_ = !lean_is_exclusive(v___x_2852_);
if (v_isSharedCheck_2927_ == 0)
{
v___x_2855_ = v___x_2852_;
v_isShared_2856_ = v_isSharedCheck_2927_;
goto v_resetjp_2854_;
}
else
{
lean_inc(v_a_2853_);
lean_dec(v___x_2852_);
v___x_2855_ = lean_box(0);
v_isShared_2856_ = v_isSharedCheck_2927_;
goto v_resetjp_2854_;
}
v_resetjp_2854_:
{
lean_object* v_fst_2857_; lean_object* v_snd_2858_; lean_object* v___x_2860_; uint8_t v_isShared_2861_; uint8_t v_isSharedCheck_2926_; 
v_fst_2857_ = lean_ctor_get(v_a_2853_, 0);
v_snd_2858_ = lean_ctor_get(v_a_2853_, 1);
v_isSharedCheck_2926_ = !lean_is_exclusive(v_a_2853_);
if (v_isSharedCheck_2926_ == 0)
{
v___x_2860_ = v_a_2853_;
v_isShared_2861_ = v_isSharedCheck_2926_;
goto v_resetjp_2859_;
}
else
{
lean_inc(v_snd_2858_);
lean_inc(v_fst_2857_);
lean_dec(v_a_2853_);
v___x_2860_ = lean_box(0);
v_isShared_2861_ = v_isSharedCheck_2926_;
goto v_resetjp_2859_;
}
v_resetjp_2859_:
{
lean_object* v___x_2862_; lean_object* v___x_2863_; lean_object* v___x_2865_; 
v___x_2862_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_2863_ = l_Lean_JsonNumber_fromNat(v_fst_2798_);
if (v_isShared_2856_ == 0)
{
lean_ctor_set_tag(v___x_2855_, 2);
lean_ctor_set(v___x_2855_, 0, v___x_2863_);
v___x_2865_ = v___x_2855_;
goto v_reusejp_2864_;
}
else
{
lean_object* v_reuseFailAlloc_2925_; 
v_reuseFailAlloc_2925_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2925_, 0, v___x_2863_);
v___x_2865_ = v_reuseFailAlloc_2925_;
goto v_reusejp_2864_;
}
v_reusejp_2864_:
{
lean_object* v___x_2867_; 
if (v_isShared_2861_ == 0)
{
lean_ctor_set(v___x_2860_, 1, v___x_2865_);
lean_ctor_set(v___x_2860_, 0, v___x_2862_);
v___x_2867_ = v___x_2860_;
goto v_reusejp_2866_;
}
else
{
lean_object* v_reuseFailAlloc_2924_; 
v_reuseFailAlloc_2924_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2924_, 0, v___x_2862_);
lean_ctor_set(v_reuseFailAlloc_2924_, 1, v___x_2865_);
v___x_2867_ = v_reuseFailAlloc_2924_;
goto v_reusejp_2866_;
}
v_reusejp_2866_:
{
lean_object* v___x_2868_; lean_object* v___x_2870_; 
v___x_2868_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_2851_ == 0)
{
lean_ctor_set(v___x_2850_, 1, v_fst_2830_);
lean_ctor_set(v___x_2850_, 0, v___x_2868_);
v___x_2870_ = v___x_2850_;
goto v_reusejp_2869_;
}
else
{
lean_object* v_reuseFailAlloc_2923_; 
v_reuseFailAlloc_2923_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2923_, 0, v___x_2868_);
lean_ctor_set(v_reuseFailAlloc_2923_, 1, v_fst_2830_);
v___x_2870_ = v_reuseFailAlloc_2923_;
goto v_reusejp_2869_;
}
v_reusejp_2869_:
{
lean_object* v___x_2871_; lean_object* v___x_2872_; lean_object* v___x_2874_; 
v___x_2871_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_2872_ = l_Lean_JsonNumber_fromNat(v_fst_2837_);
if (v_isShared_2846_ == 0)
{
lean_ctor_set_tag(v___x_2845_, 2);
lean_ctor_set(v___x_2845_, 0, v___x_2872_);
v___x_2874_ = v___x_2845_;
goto v_reusejp_2873_;
}
else
{
lean_object* v_reuseFailAlloc_2922_; 
v_reuseFailAlloc_2922_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2922_, 0, v___x_2872_);
v___x_2874_ = v_reuseFailAlloc_2922_;
goto v_reusejp_2873_;
}
v_reusejp_2873_:
{
lean_object* v___x_2876_; 
if (v_isShared_2841_ == 0)
{
lean_ctor_set(v___x_2840_, 1, v___x_2874_);
lean_ctor_set(v___x_2840_, 0, v___x_2871_);
v___x_2876_ = v___x_2840_;
goto v_reusejp_2875_;
}
else
{
lean_object* v_reuseFailAlloc_2921_; 
v_reuseFailAlloc_2921_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2921_, 0, v___x_2871_);
lean_ctor_set(v_reuseFailAlloc_2921_, 1, v___x_2874_);
v___x_2876_ = v_reuseFailAlloc_2921_;
goto v_reusejp_2875_;
}
v_reusejp_2875_:
{
lean_object* v___x_2877_; lean_object* v___x_2878_; lean_object* v___x_2880_; 
v___x_2877_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__5));
v___x_2878_ = l_Lean_JsonNumber_fromNat(v_numParams_2785_);
if (v_isShared_2829_ == 0)
{
lean_ctor_set_tag(v___x_2828_, 2);
lean_ctor_set(v___x_2828_, 0, v___x_2878_);
v___x_2880_ = v___x_2828_;
goto v_reusejp_2879_;
}
else
{
lean_object* v_reuseFailAlloc_2920_; 
v_reuseFailAlloc_2920_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2920_, 0, v___x_2878_);
v___x_2880_ = v_reuseFailAlloc_2920_;
goto v_reusejp_2879_;
}
v_reusejp_2879_:
{
lean_object* v___x_2882_; 
if (v_isShared_2834_ == 0)
{
lean_ctor_set(v___x_2833_, 1, v___x_2880_);
lean_ctor_set(v___x_2833_, 0, v___x_2877_);
v___x_2882_ = v___x_2833_;
goto v_reusejp_2881_;
}
else
{
lean_object* v_reuseFailAlloc_2919_; 
v_reuseFailAlloc_2919_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2919_, 0, v___x_2877_);
lean_ctor_set(v_reuseFailAlloc_2919_, 1, v___x_2880_);
v___x_2882_ = v_reuseFailAlloc_2919_;
goto v_reusejp_2881_;
}
v_reusejp_2881_:
{
lean_object* v___x_2883_; lean_object* v___x_2884_; lean_object* v___x_2885_; lean_object* v___x_2887_; 
v___x_2883_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__0));
v___x_2884_ = l_Lean_JsonNumber_fromNat(v_numIndices_2786_);
v___x_2885_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2885_, 0, v___x_2884_);
if (v_isShared_2802_ == 0)
{
lean_ctor_set(v___x_2801_, 1, v___x_2885_);
lean_ctor_set(v___x_2801_, 0, v___x_2883_);
v___x_2887_ = v___x_2801_;
goto v_reusejp_2886_;
}
else
{
lean_object* v_reuseFailAlloc_2918_; 
v_reuseFailAlloc_2918_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2918_, 0, v___x_2883_);
lean_ctor_set(v_reuseFailAlloc_2918_, 1, v___x_2885_);
v___x_2887_ = v_reuseFailAlloc_2918_;
goto v_reusejp_2886_;
}
v_reusejp_2886_:
{
lean_object* v___x_2888_; lean_object* v___x_2889_; lean_object* v___x_2890_; lean_object* v___x_2891_; lean_object* v___x_2892_; lean_object* v___x_2893_; lean_object* v___x_2894_; lean_object* v___x_2895_; lean_object* v___x_2896_; lean_object* v___x_2897_; lean_object* v___x_2898_; lean_object* v___x_2899_; lean_object* v___x_2900_; lean_object* v___x_2901_; lean_object* v___x_2902_; lean_object* v___x_2903_; lean_object* v___x_2904_; lean_object* v___x_2905_; lean_object* v___x_2906_; lean_object* v___x_2907_; lean_object* v___x_2908_; lean_object* v___x_2909_; lean_object* v___x_2910_; lean_object* v___x_2911_; lean_object* v___x_2912_; lean_object* v___x_2913_; lean_object* v___x_2914_; lean_object* v___x_2915_; lean_object* v___x_2916_; lean_object* v___x_2917_; 
v___x_2888_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1));
v___x_2889_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2889_, 0, v___x_2888_);
lean_ctor_set(v___x_2889_, 1, v_fst_2847_);
v___x_2890_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__2));
v___x_2891_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2891_, 0, v___x_2890_);
lean_ctor_set(v___x_2891_, 1, v_fst_2857_);
v___x_2892_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__3));
v___x_2893_ = l_Lean_JsonNumber_fromNat(v_numNested_2789_);
v___x_2894_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2894_, 0, v___x_2893_);
v___x_2895_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2895_, 0, v___x_2892_);
lean_ctor_set(v___x_2895_, 1, v___x_2894_);
v___x_2896_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__4));
v___x_2897_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_2897_, 0, v_isRec_2790_);
v___x_2898_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2898_, 0, v___x_2896_);
lean_ctor_set(v___x_2898_, 1, v___x_2897_);
v___x_2899_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__5));
v___x_2900_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_2900_, 0, v_isReflexive_2792_);
v___x_2901_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2901_, 0, v___x_2899_);
lean_ctor_set(v___x_2901_, 1, v___x_2900_);
v___x_2902_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7));
v___x_2903_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_2903_, 0, v_isUnsafe_2791_);
v___x_2904_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2904_, 0, v___x_2902_);
lean_ctor_set(v___x_2904_, 1, v___x_2903_);
v___x_2905_ = lean_box(0);
v___x_2906_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2906_, 0, v___x_2904_);
lean_ctor_set(v___x_2906_, 1, v___x_2905_);
v___x_2907_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2907_, 0, v___x_2901_);
lean_ctor_set(v___x_2907_, 1, v___x_2906_);
v___x_2908_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2908_, 0, v___x_2898_);
lean_ctor_set(v___x_2908_, 1, v___x_2907_);
v___x_2909_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2909_, 0, v___x_2895_);
lean_ctor_set(v___x_2909_, 1, v___x_2908_);
v___x_2910_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2910_, 0, v___x_2891_);
lean_ctor_set(v___x_2910_, 1, v___x_2909_);
v___x_2911_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2911_, 0, v___x_2889_);
lean_ctor_set(v___x_2911_, 1, v___x_2910_);
v___x_2912_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2912_, 0, v___x_2887_);
lean_ctor_set(v___x_2912_, 1, v___x_2911_);
v___x_2913_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2913_, 0, v___x_2882_);
lean_ctor_set(v___x_2913_, 1, v___x_2912_);
v___x_2914_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2914_, 0, v___x_2876_);
lean_ctor_set(v___x_2914_, 1, v___x_2913_);
v___x_2915_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2915_, 0, v___x_2870_);
lean_ctor_set(v___x_2915_, 1, v___x_2914_);
v___x_2916_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2916_, 0, v___x_2867_);
lean_ctor_set(v___x_2916_, 1, v___x_2915_);
v___x_2917_ = l_Lean_Json_mkObj(v___x_2916_);
lean_dec_ref_known(v___x_2916_, 2);
v_fst_2806_ = v___x_2917_;
v_snd_2807_ = v_snd_2858_;
goto v___jp_2805_;
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2850_);
lean_dec(v_fst_2847_);
lean_del_object(v___x_2845_);
lean_del_object(v___x_2840_);
lean_dec(v_fst_2837_);
lean_del_object(v___x_2833_);
lean_dec(v_fst_2830_);
lean_del_object(v___x_2828_);
lean_del_object(v___x_2801_);
lean_dec(v_fst_2798_);
lean_dec(v_numNested_2789_);
lean_dec(v_numIndices_2786_);
lean_dec(v_numParams_2785_);
v___y_2813_ = v___x_2852_;
goto v___jp_2812_;
}
}
}
}
else
{
lean_del_object(v___x_2840_);
lean_dec(v_fst_2837_);
lean_del_object(v___x_2833_);
lean_dec(v_fst_2830_);
lean_del_object(v___x_2828_);
lean_del_object(v___x_2801_);
lean_dec(v_fst_2798_);
lean_dec(v_numNested_2789_);
lean_dec(v_ctors_2788_);
lean_dec(v_numIndices_2786_);
lean_dec(v_numParams_2785_);
v___y_2813_ = v___x_2842_;
goto v___jp_2812_;
}
}
}
else
{
lean_object* v_a_2931_; lean_object* v___x_2933_; uint8_t v_isShared_2934_; uint8_t v_isSharedCheck_2938_; 
lean_del_object(v___x_2833_);
lean_dec(v_fst_2830_);
lean_del_object(v___x_2828_);
lean_dec_ref(v_bs_x27_2804_);
lean_del_object(v___x_2801_);
lean_dec(v_fst_2798_);
lean_dec(v_numNested_2789_);
lean_dec(v_ctors_2788_);
lean_dec(v_all_2787_);
lean_dec(v_numIndices_2786_);
lean_dec(v_numParams_2785_);
v_a_2931_ = lean_ctor_get(v___x_2835_, 0);
v_isSharedCheck_2938_ = !lean_is_exclusive(v___x_2835_);
if (v_isSharedCheck_2938_ == 0)
{
v___x_2933_ = v___x_2835_;
v_isShared_2934_ = v_isSharedCheck_2938_;
goto v_resetjp_2932_;
}
else
{
lean_inc(v_a_2931_);
lean_dec(v___x_2835_);
v___x_2933_ = lean_box(0);
v_isShared_2934_ = v_isSharedCheck_2938_;
goto v_resetjp_2932_;
}
v_resetjp_2932_:
{
lean_object* v___x_2936_; 
if (v_isShared_2934_ == 0)
{
v___x_2936_ = v___x_2933_;
goto v_reusejp_2935_;
}
else
{
lean_object* v_reuseFailAlloc_2937_; 
v_reuseFailAlloc_2937_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2937_, 0, v_a_2931_);
v___x_2936_ = v_reuseFailAlloc_2937_;
goto v_reusejp_2935_;
}
v_reusejp_2935_:
{
return v___x_2936_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_2801_);
lean_dec(v_fst_2798_);
lean_dec_ref(v_type_2795_);
lean_dec(v_numNested_2789_);
lean_dec(v_ctors_2788_);
lean_dec(v_all_2787_);
lean_dec(v_numIndices_2786_);
lean_dec(v_numParams_2785_);
v___y_2813_ = v___x_2825_;
goto v___jp_2812_;
}
v___jp_2805_:
{
size_t v___x_2808_; size_t v___x_2809_; lean_object* v___x_2810_; 
v___x_2808_ = ((size_t)1ULL);
v___x_2809_ = lean_usize_add(v_i_2775_, v___x_2808_);
v___x_2810_ = lean_array_uset(v_bs_x27_2804_, v_i_2775_, v_fst_2806_);
v_i_2775_ = v___x_2809_;
v_bs_2776_ = v___x_2810_;
v___y_2778_ = v_snd_2807_;
goto _start;
}
v___jp_2812_:
{
if (lean_obj_tag(v___y_2813_) == 0)
{
lean_object* v_a_2814_; lean_object* v_fst_2815_; lean_object* v_snd_2816_; 
v_a_2814_ = lean_ctor_get(v___y_2813_, 0);
lean_inc(v_a_2814_);
lean_dec_ref_known(v___y_2813_, 1);
v_fst_2815_ = lean_ctor_get(v_a_2814_, 0);
lean_inc(v_fst_2815_);
v_snd_2816_ = lean_ctor_get(v_a_2814_, 1);
lean_inc(v_snd_2816_);
lean_dec(v_a_2814_);
v_fst_2806_ = v_fst_2815_;
v_snd_2807_ = v_snd_2816_;
goto v___jp_2805_;
}
else
{
lean_object* v_a_2817_; lean_object* v___x_2819_; uint8_t v_isShared_2820_; uint8_t v_isSharedCheck_2824_; 
lean_dec_ref(v_bs_x27_2804_);
v_a_2817_ = lean_ctor_get(v___y_2813_, 0);
v_isSharedCheck_2824_ = !lean_is_exclusive(v___y_2813_);
if (v_isSharedCheck_2824_ == 0)
{
v___x_2819_ = v___y_2813_;
v_isShared_2820_ = v_isSharedCheck_2824_;
goto v_resetjp_2818_;
}
else
{
lean_inc(v_a_2817_);
lean_dec(v___y_2813_);
v___x_2819_ = lean_box(0);
v_isShared_2820_ = v_isSharedCheck_2824_;
goto v_resetjp_2818_;
}
v_resetjp_2818_:
{
lean_object* v___x_2822_; 
if (v_isShared_2820_ == 0)
{
v___x_2822_ = v___x_2819_;
goto v_reusejp_2821_;
}
else
{
lean_object* v_reuseFailAlloc_2823_; 
v_reuseFailAlloc_2823_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2823_, 0, v_a_2817_);
v___x_2822_ = v_reuseFailAlloc_2823_;
goto v_reusejp_2821_;
}
v_reusejp_2821_:
{
return v___x_2822_;
}
}
}
}
}
}
else
{
lean_object* v_a_2942_; lean_object* v___x_2944_; uint8_t v_isShared_2945_; uint8_t v_isSharedCheck_2949_; 
lean_dec_ref(v_type_2795_);
lean_dec(v_levelParams_2794_);
lean_dec(v_numNested_2789_);
lean_dec(v_ctors_2788_);
lean_dec(v_all_2787_);
lean_dec(v_numIndices_2786_);
lean_dec(v_numParams_2785_);
lean_dec_ref(v_bs_2776_);
v_a_2942_ = lean_ctor_get(v___x_2796_, 0);
v_isSharedCheck_2949_ = !lean_is_exclusive(v___x_2796_);
if (v_isSharedCheck_2949_ == 0)
{
v___x_2944_ = v___x_2796_;
v_isShared_2945_ = v_isSharedCheck_2949_;
goto v_resetjp_2943_;
}
else
{
lean_inc(v_a_2942_);
lean_dec(v___x_2796_);
v___x_2944_ = lean_box(0);
v_isShared_2945_ = v_isSharedCheck_2949_;
goto v_resetjp_2943_;
}
v_resetjp_2943_:
{
lean_object* v___x_2947_; 
if (v_isShared_2945_ == 0)
{
v___x_2947_ = v___x_2944_;
goto v_reusejp_2946_;
}
else
{
lean_object* v_reuseFailAlloc_2948_; 
v_reuseFailAlloc_2948_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2948_, 0, v_a_2942_);
v___x_2947_ = v_reuseFailAlloc_2948_;
goto v_reusejp_2946_;
}
v_reusejp_2946_:
{
return v___x_2947_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16(size_t v_sz_2953_, size_t v_i_2954_, lean_object* v_bs_2955_, lean_object* v___y_2956_, lean_object* v___y_2957_){
_start:
{
uint8_t v___x_2959_; 
v___x_2959_ = lean_usize_dec_lt(v_i_2954_, v_sz_2953_);
if (v___x_2959_ == 0)
{
lean_object* v___x_2960_; lean_object* v___x_2961_; 
v___x_2960_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2960_, 0, v_bs_2955_);
lean_ctor_set(v___x_2960_, 1, v___y_2957_);
v___x_2961_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2961_, 0, v___x_2960_);
return v___x_2961_;
}
else
{
lean_object* v_v_2962_; lean_object* v_toConstantVal_2963_; lean_object* v_induct_2964_; lean_object* v_cidx_2965_; lean_object* v_numParams_2966_; lean_object* v_numFields_2967_; uint8_t v_isUnsafe_2968_; lean_object* v_name_2969_; lean_object* v_levelParams_2970_; lean_object* v_type_2971_; lean_object* v___x_2972_; 
v_v_2962_ = lean_array_uget_borrowed(v_bs_2955_, v_i_2954_);
v_toConstantVal_2963_ = lean_ctor_get(v_v_2962_, 0);
v_induct_2964_ = lean_ctor_get(v_v_2962_, 1);
lean_inc(v_induct_2964_);
v_cidx_2965_ = lean_ctor_get(v_v_2962_, 2);
lean_inc(v_cidx_2965_);
v_numParams_2966_ = lean_ctor_get(v_v_2962_, 3);
lean_inc(v_numParams_2966_);
v_numFields_2967_ = lean_ctor_get(v_v_2962_, 4);
lean_inc(v_numFields_2967_);
v_isUnsafe_2968_ = lean_ctor_get_uint8(v_v_2962_, sizeof(void*)*5);
v_name_2969_ = lean_ctor_get(v_toConstantVal_2963_, 0);
v_levelParams_2970_ = lean_ctor_get(v_toConstantVal_2963_, 1);
lean_inc(v_levelParams_2970_);
v_type_2971_ = lean_ctor_get(v_toConstantVal_2963_, 2);
lean_inc_ref(v_type_2971_);
lean_inc(v_name_2969_);
v___x_2972_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_2969_, v___y_2956_, v___y_2957_);
if (lean_obj_tag(v___x_2972_) == 0)
{
lean_object* v_a_2973_; lean_object* v_fst_2974_; lean_object* v_snd_2975_; lean_object* v___x_2977_; uint8_t v_isShared_2978_; uint8_t v_isSharedCheck_3086_; 
v_a_2973_ = lean_ctor_get(v___x_2972_, 0);
lean_inc(v_a_2973_);
lean_dec_ref_known(v___x_2972_, 1);
v_fst_2974_ = lean_ctor_get(v_a_2973_, 0);
v_snd_2975_ = lean_ctor_get(v_a_2973_, 1);
v_isSharedCheck_3086_ = !lean_is_exclusive(v_a_2973_);
if (v_isSharedCheck_3086_ == 0)
{
v___x_2977_ = v_a_2973_;
v_isShared_2978_ = v_isSharedCheck_3086_;
goto v_resetjp_2976_;
}
else
{
lean_inc(v_snd_2975_);
lean_inc(v_fst_2974_);
lean_dec(v_a_2973_);
v___x_2977_ = lean_box(0);
v_isShared_2978_ = v_isSharedCheck_3086_;
goto v_resetjp_2976_;
}
v_resetjp_2976_:
{
lean_object* v___x_2979_; lean_object* v_bs_x27_2980_; lean_object* v_fst_2982_; lean_object* v_snd_2983_; lean_object* v___x_2988_; 
v___x_2979_ = lean_unsigned_to_nat(0u);
v_bs_x27_2980_ = lean_array_uset(v_bs_2955_, v_i_2954_, v___x_2979_);
v___x_2988_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_2970_, v___y_2956_, v_snd_2975_);
if (lean_obj_tag(v___x_2988_) == 0)
{
lean_object* v_a_2989_; lean_object* v_fst_2990_; lean_object* v_snd_2991_; lean_object* v___x_2993_; uint8_t v_isShared_2994_; uint8_t v_isSharedCheck_3074_; 
v_a_2989_ = lean_ctor_get(v___x_2988_, 0);
lean_inc(v_a_2989_);
lean_dec_ref_known(v___x_2988_, 1);
v_fst_2990_ = lean_ctor_get(v_a_2989_, 0);
v_snd_2991_ = lean_ctor_get(v_a_2989_, 1);
v_isSharedCheck_3074_ = !lean_is_exclusive(v_a_2989_);
if (v_isSharedCheck_3074_ == 0)
{
v___x_2993_ = v_a_2989_;
v_isShared_2994_ = v_isSharedCheck_3074_;
goto v_resetjp_2992_;
}
else
{
lean_inc(v_snd_2991_);
lean_inc(v_fst_2990_);
lean_dec(v_a_2989_);
v___x_2993_ = lean_box(0);
v_isShared_2994_ = v_isSharedCheck_3074_;
goto v_resetjp_2992_;
}
v_resetjp_2992_:
{
lean_object* v___x_2995_; 
v___x_2995_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_2971_, v___y_2956_, v_snd_2991_);
if (lean_obj_tag(v___x_2995_) == 0)
{
lean_object* v_a_2996_; lean_object* v_fst_2997_; lean_object* v_snd_2998_; lean_object* v___x_3000_; uint8_t v_isShared_3001_; uint8_t v_isSharedCheck_3065_; 
v_a_2996_ = lean_ctor_get(v___x_2995_, 0);
lean_inc(v_a_2996_);
lean_dec_ref_known(v___x_2995_, 1);
v_fst_2997_ = lean_ctor_get(v_a_2996_, 0);
v_snd_2998_ = lean_ctor_get(v_a_2996_, 1);
v_isSharedCheck_3065_ = !lean_is_exclusive(v_a_2996_);
if (v_isSharedCheck_3065_ == 0)
{
v___x_3000_ = v_a_2996_;
v_isShared_3001_ = v_isSharedCheck_3065_;
goto v_resetjp_2999_;
}
else
{
lean_inc(v_snd_2998_);
lean_inc(v_fst_2997_);
lean_dec(v_a_2996_);
v___x_3000_ = lean_box(0);
v_isShared_3001_ = v_isSharedCheck_3065_;
goto v_resetjp_2999_;
}
v_resetjp_2999_:
{
lean_object* v___x_3002_; 
v___x_3002_ = lp_proofEnvironment_CheckedExport_dumpName(v_induct_2964_, v___y_2956_, v_snd_2998_);
if (lean_obj_tag(v___x_3002_) == 0)
{
lean_object* v_a_3003_; lean_object* v_fst_3004_; lean_object* v_snd_3005_; lean_object* v___x_3007_; uint8_t v_isShared_3008_; uint8_t v_isSharedCheck_3056_; 
v_a_3003_ = lean_ctor_get(v___x_3002_, 0);
lean_inc(v_a_3003_);
lean_dec_ref_known(v___x_3002_, 1);
v_fst_3004_ = lean_ctor_get(v_a_3003_, 0);
v_snd_3005_ = lean_ctor_get(v_a_3003_, 1);
v_isSharedCheck_3056_ = !lean_is_exclusive(v_a_3003_);
if (v_isSharedCheck_3056_ == 0)
{
v___x_3007_ = v_a_3003_;
v_isShared_3008_ = v_isSharedCheck_3056_;
goto v_resetjp_3006_;
}
else
{
lean_inc(v_snd_3005_);
lean_inc(v_fst_3004_);
lean_dec(v_a_3003_);
v___x_3007_ = lean_box(0);
v_isShared_3008_ = v_isSharedCheck_3056_;
goto v_resetjp_3006_;
}
v_resetjp_3006_:
{
lean_object* v___x_3009_; lean_object* v___x_3010_; lean_object* v___x_3011_; lean_object* v___x_3013_; 
v___x_3009_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_3010_ = l_Lean_JsonNumber_fromNat(v_fst_2974_);
v___x_3011_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3011_, 0, v___x_3010_);
if (v_isShared_3008_ == 0)
{
lean_ctor_set(v___x_3007_, 1, v___x_3011_);
lean_ctor_set(v___x_3007_, 0, v___x_3009_);
v___x_3013_ = v___x_3007_;
goto v_reusejp_3012_;
}
else
{
lean_object* v_reuseFailAlloc_3055_; 
v_reuseFailAlloc_3055_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3055_, 0, v___x_3009_);
lean_ctor_set(v_reuseFailAlloc_3055_, 1, v___x_3011_);
v___x_3013_ = v_reuseFailAlloc_3055_;
goto v_reusejp_3012_;
}
v_reusejp_3012_:
{
lean_object* v___x_3014_; lean_object* v___x_3016_; 
v___x_3014_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_3001_ == 0)
{
lean_ctor_set(v___x_3000_, 1, v_fst_2990_);
lean_ctor_set(v___x_3000_, 0, v___x_3014_);
v___x_3016_ = v___x_3000_;
goto v_reusejp_3015_;
}
else
{
lean_object* v_reuseFailAlloc_3054_; 
v_reuseFailAlloc_3054_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3054_, 0, v___x_3014_);
lean_ctor_set(v_reuseFailAlloc_3054_, 1, v_fst_2990_);
v___x_3016_ = v_reuseFailAlloc_3054_;
goto v_reusejp_3015_;
}
v_reusejp_3015_:
{
lean_object* v___x_3017_; lean_object* v___x_3018_; lean_object* v___x_3019_; lean_object* v___x_3021_; 
v___x_3017_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_3018_ = l_Lean_JsonNumber_fromNat(v_fst_2997_);
v___x_3019_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3019_, 0, v___x_3018_);
if (v_isShared_2994_ == 0)
{
lean_ctor_set(v___x_2993_, 1, v___x_3019_);
lean_ctor_set(v___x_2993_, 0, v___x_3017_);
v___x_3021_ = v___x_2993_;
goto v_reusejp_3020_;
}
else
{
lean_object* v_reuseFailAlloc_3053_; 
v_reuseFailAlloc_3053_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3053_, 0, v___x_3017_);
lean_ctor_set(v_reuseFailAlloc_3053_, 1, v___x_3019_);
v___x_3021_ = v_reuseFailAlloc_3053_;
goto v_reusejp_3020_;
}
v_reusejp_3020_:
{
lean_object* v___x_3022_; lean_object* v___x_3023_; lean_object* v___x_3024_; lean_object* v___x_3026_; 
v___x_3022_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__3));
v___x_3023_ = l_Lean_JsonNumber_fromNat(v_fst_3004_);
v___x_3024_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3024_, 0, v___x_3023_);
if (v_isShared_2978_ == 0)
{
lean_ctor_set(v___x_2977_, 1, v___x_3024_);
lean_ctor_set(v___x_2977_, 0, v___x_3022_);
v___x_3026_ = v___x_2977_;
goto v_reusejp_3025_;
}
else
{
lean_object* v_reuseFailAlloc_3052_; 
v_reuseFailAlloc_3052_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3052_, 0, v___x_3022_);
lean_ctor_set(v_reuseFailAlloc_3052_, 1, v___x_3024_);
v___x_3026_ = v_reuseFailAlloc_3052_;
goto v_reusejp_3025_;
}
v_reusejp_3025_:
{
lean_object* v___x_3027_; lean_object* v___x_3028_; lean_object* v___x_3029_; lean_object* v___x_3030_; lean_object* v___x_3031_; lean_object* v___x_3032_; lean_object* v___x_3033_; lean_object* v___x_3034_; lean_object* v___x_3035_; lean_object* v___x_3036_; lean_object* v___x_3037_; lean_object* v___x_3038_; lean_object* v___x_3039_; lean_object* v___x_3040_; lean_object* v___x_3041_; lean_object* v___x_3042_; lean_object* v___x_3043_; lean_object* v___x_3044_; lean_object* v___x_3045_; lean_object* v___x_3046_; lean_object* v___x_3047_; lean_object* v___x_3048_; lean_object* v___x_3049_; lean_object* v___x_3050_; lean_object* v___x_3051_; 
v___x_3027_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__4));
v___x_3028_ = l_Lean_JsonNumber_fromNat(v_cidx_2965_);
v___x_3029_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3029_, 0, v___x_3028_);
v___x_3030_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3030_, 0, v___x_3027_);
lean_ctor_set(v___x_3030_, 1, v___x_3029_);
v___x_3031_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__5));
v___x_3032_ = l_Lean_JsonNumber_fromNat(v_numParams_2966_);
v___x_3033_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3033_, 0, v___x_3032_);
v___x_3034_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3034_, 0, v___x_3031_);
lean_ctor_set(v___x_3034_, 1, v___x_3033_);
v___x_3035_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__6));
v___x_3036_ = l_Lean_JsonNumber_fromNat(v_numFields_2967_);
v___x_3037_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3037_, 0, v___x_3036_);
v___x_3038_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3038_, 0, v___x_3035_);
lean_ctor_set(v___x_3038_, 1, v___x_3037_);
v___x_3039_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7));
v___x_3040_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3040_, 0, v_isUnsafe_2968_);
v___x_3041_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3041_, 0, v___x_3039_);
lean_ctor_set(v___x_3041_, 1, v___x_3040_);
v___x_3042_ = lean_box(0);
v___x_3043_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3043_, 0, v___x_3041_);
lean_ctor_set(v___x_3043_, 1, v___x_3042_);
v___x_3044_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3044_, 0, v___x_3038_);
lean_ctor_set(v___x_3044_, 1, v___x_3043_);
v___x_3045_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3045_, 0, v___x_3034_);
lean_ctor_set(v___x_3045_, 1, v___x_3044_);
v___x_3046_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3046_, 0, v___x_3030_);
lean_ctor_set(v___x_3046_, 1, v___x_3045_);
v___x_3047_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3047_, 0, v___x_3026_);
lean_ctor_set(v___x_3047_, 1, v___x_3046_);
v___x_3048_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3048_, 0, v___x_3021_);
lean_ctor_set(v___x_3048_, 1, v___x_3047_);
v___x_3049_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3049_, 0, v___x_3016_);
lean_ctor_set(v___x_3049_, 1, v___x_3048_);
v___x_3050_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3050_, 0, v___x_3013_);
lean_ctor_set(v___x_3050_, 1, v___x_3049_);
v___x_3051_ = l_Lean_Json_mkObj(v___x_3050_);
lean_dec_ref_known(v___x_3050_, 2);
v_fst_2982_ = v___x_3051_;
v_snd_2983_ = v_snd_3005_;
goto v___jp_2981_;
}
}
}
}
}
}
else
{
lean_object* v_a_3057_; lean_object* v___x_3059_; uint8_t v_isShared_3060_; uint8_t v_isSharedCheck_3064_; 
lean_del_object(v___x_3000_);
lean_dec(v_fst_2997_);
lean_del_object(v___x_2993_);
lean_dec(v_fst_2990_);
lean_dec_ref(v_bs_x27_2980_);
lean_del_object(v___x_2977_);
lean_dec(v_fst_2974_);
lean_dec(v_numFields_2967_);
lean_dec(v_numParams_2966_);
lean_dec(v_cidx_2965_);
v_a_3057_ = lean_ctor_get(v___x_3002_, 0);
v_isSharedCheck_3064_ = !lean_is_exclusive(v___x_3002_);
if (v_isSharedCheck_3064_ == 0)
{
v___x_3059_ = v___x_3002_;
v_isShared_3060_ = v_isSharedCheck_3064_;
goto v_resetjp_3058_;
}
else
{
lean_inc(v_a_3057_);
lean_dec(v___x_3002_);
v___x_3059_ = lean_box(0);
v_isShared_3060_ = v_isSharedCheck_3064_;
goto v_resetjp_3058_;
}
v_resetjp_3058_:
{
lean_object* v___x_3062_; 
if (v_isShared_3060_ == 0)
{
v___x_3062_ = v___x_3059_;
goto v_reusejp_3061_;
}
else
{
lean_object* v_reuseFailAlloc_3063_; 
v_reuseFailAlloc_3063_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3063_, 0, v_a_3057_);
v___x_3062_ = v_reuseFailAlloc_3063_;
goto v_reusejp_3061_;
}
v_reusejp_3061_:
{
return v___x_3062_;
}
}
}
}
}
else
{
lean_object* v_a_3066_; lean_object* v___x_3068_; uint8_t v_isShared_3069_; uint8_t v_isSharedCheck_3073_; 
lean_del_object(v___x_2993_);
lean_dec(v_fst_2990_);
lean_dec_ref(v_bs_x27_2980_);
lean_del_object(v___x_2977_);
lean_dec(v_fst_2974_);
lean_dec(v_numFields_2967_);
lean_dec(v_numParams_2966_);
lean_dec(v_cidx_2965_);
lean_dec(v_induct_2964_);
v_a_3066_ = lean_ctor_get(v___x_2995_, 0);
v_isSharedCheck_3073_ = !lean_is_exclusive(v___x_2995_);
if (v_isSharedCheck_3073_ == 0)
{
v___x_3068_ = v___x_2995_;
v_isShared_3069_ = v_isSharedCheck_3073_;
goto v_resetjp_3067_;
}
else
{
lean_inc(v_a_3066_);
lean_dec(v___x_2995_);
v___x_3068_ = lean_box(0);
v_isShared_3069_ = v_isSharedCheck_3073_;
goto v_resetjp_3067_;
}
v_resetjp_3067_:
{
lean_object* v___x_3071_; 
if (v_isShared_3069_ == 0)
{
v___x_3071_ = v___x_3068_;
goto v_reusejp_3070_;
}
else
{
lean_object* v_reuseFailAlloc_3072_; 
v_reuseFailAlloc_3072_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3072_, 0, v_a_3066_);
v___x_3071_ = v_reuseFailAlloc_3072_;
goto v_reusejp_3070_;
}
v_reusejp_3070_:
{
return v___x_3071_;
}
}
}
}
}
else
{
lean_del_object(v___x_2977_);
lean_dec(v_fst_2974_);
lean_dec_ref(v_type_2971_);
lean_dec(v_numFields_2967_);
lean_dec(v_numParams_2966_);
lean_dec(v_cidx_2965_);
lean_dec(v_induct_2964_);
if (lean_obj_tag(v___x_2988_) == 0)
{
lean_object* v_a_3075_; lean_object* v_fst_3076_; lean_object* v_snd_3077_; 
v_a_3075_ = lean_ctor_get(v___x_2988_, 0);
lean_inc(v_a_3075_);
lean_dec_ref_known(v___x_2988_, 1);
v_fst_3076_ = lean_ctor_get(v_a_3075_, 0);
lean_inc(v_fst_3076_);
v_snd_3077_ = lean_ctor_get(v_a_3075_, 1);
lean_inc(v_snd_3077_);
lean_dec(v_a_3075_);
v_fst_2982_ = v_fst_3076_;
v_snd_2983_ = v_snd_3077_;
goto v___jp_2981_;
}
else
{
lean_object* v_a_3078_; lean_object* v___x_3080_; uint8_t v_isShared_3081_; uint8_t v_isSharedCheck_3085_; 
lean_dec_ref(v_bs_x27_2980_);
v_a_3078_ = lean_ctor_get(v___x_2988_, 0);
v_isSharedCheck_3085_ = !lean_is_exclusive(v___x_2988_);
if (v_isSharedCheck_3085_ == 0)
{
v___x_3080_ = v___x_2988_;
v_isShared_3081_ = v_isSharedCheck_3085_;
goto v_resetjp_3079_;
}
else
{
lean_inc(v_a_3078_);
lean_dec(v___x_2988_);
v___x_3080_ = lean_box(0);
v_isShared_3081_ = v_isSharedCheck_3085_;
goto v_resetjp_3079_;
}
v_resetjp_3079_:
{
lean_object* v___x_3083_; 
if (v_isShared_3081_ == 0)
{
v___x_3083_ = v___x_3080_;
goto v_reusejp_3082_;
}
else
{
lean_object* v_reuseFailAlloc_3084_; 
v_reuseFailAlloc_3084_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3084_, 0, v_a_3078_);
v___x_3083_ = v_reuseFailAlloc_3084_;
goto v_reusejp_3082_;
}
v_reusejp_3082_:
{
return v___x_3083_;
}
}
}
}
v___jp_2981_:
{
size_t v___x_2984_; size_t v___x_2985_; lean_object* v___x_2986_; 
v___x_2984_ = ((size_t)1ULL);
v___x_2985_ = lean_usize_add(v_i_2954_, v___x_2984_);
v___x_2986_ = lean_array_uset(v_bs_x27_2980_, v_i_2954_, v_fst_2982_);
v_i_2954_ = v___x_2985_;
v_bs_2955_ = v___x_2986_;
v___y_2957_ = v_snd_2983_;
goto _start;
}
}
}
else
{
lean_object* v_a_3087_; lean_object* v___x_3089_; uint8_t v_isShared_3090_; uint8_t v_isSharedCheck_3094_; 
lean_dec_ref(v_type_2971_);
lean_dec(v_levelParams_2970_);
lean_dec(v_numFields_2967_);
lean_dec(v_numParams_2966_);
lean_dec(v_cidx_2965_);
lean_dec(v_induct_2964_);
lean_dec_ref(v_bs_2955_);
v_a_3087_ = lean_ctor_get(v___x_2972_, 0);
v_isSharedCheck_3094_ = !lean_is_exclusive(v___x_2972_);
if (v_isSharedCheck_3094_ == 0)
{
v___x_3089_ = v___x_2972_;
v_isShared_3090_ = v_isSharedCheck_3094_;
goto v_resetjp_3088_;
}
else
{
lean_inc(v_a_3087_);
lean_dec(v___x_2972_);
v___x_3089_ = lean_box(0);
v_isShared_3090_ = v_isSharedCheck_3094_;
goto v_resetjp_3088_;
}
v_resetjp_3088_:
{
lean_object* v___x_3092_; 
if (v_isShared_3090_ == 0)
{
v___x_3092_ = v___x_3089_;
goto v_reusejp_3091_;
}
else
{
lean_object* v_reuseFailAlloc_3093_; 
v_reuseFailAlloc_3093_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3093_, 0, v_a_3087_);
v___x_3092_ = v_reuseFailAlloc_3093_;
goto v_reusejp_3091_;
}
v_reusejp_3091_:
{
return v___x_3092_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule(lean_object* v_rule_3098_, lean_object* v_a_3099_, lean_object* v_a_3100_){
_start:
{
lean_object* v_ctor_3102_; lean_object* v_nfields_3103_; lean_object* v_rhs_3104_; lean_object* v___x_3105_; 
v_ctor_3102_ = lean_ctor_get(v_rule_3098_, 0);
lean_inc(v_ctor_3102_);
v_nfields_3103_ = lean_ctor_get(v_rule_3098_, 1);
lean_inc(v_nfields_3103_);
v_rhs_3104_ = lean_ctor_get(v_rule_3098_, 2);
lean_inc_ref(v_rhs_3104_);
lean_dec_ref(v_rule_3098_);
v___x_3105_ = lp_proofEnvironment_CheckedExport_dumpName(v_ctor_3102_, v_a_3099_, v_a_3100_);
if (lean_obj_tag(v___x_3105_) == 0)
{
lean_object* v_a_3106_; lean_object* v_fst_3107_; lean_object* v_snd_3108_; lean_object* v___x_3110_; uint8_t v_isShared_3111_; uint8_t v_isSharedCheck_3157_; 
v_a_3106_ = lean_ctor_get(v___x_3105_, 0);
lean_inc(v_a_3106_);
lean_dec_ref_known(v___x_3105_, 1);
v_fst_3107_ = lean_ctor_get(v_a_3106_, 0);
v_snd_3108_ = lean_ctor_get(v_a_3106_, 1);
v_isSharedCheck_3157_ = !lean_is_exclusive(v_a_3106_);
if (v_isSharedCheck_3157_ == 0)
{
v___x_3110_ = v_a_3106_;
v_isShared_3111_ = v_isSharedCheck_3157_;
goto v_resetjp_3109_;
}
else
{
lean_inc(v_snd_3108_);
lean_inc(v_fst_3107_);
lean_dec(v_a_3106_);
v___x_3110_ = lean_box(0);
v_isShared_3111_ = v_isSharedCheck_3157_;
goto v_resetjp_3109_;
}
v_resetjp_3109_:
{
lean_object* v___x_3112_; 
v___x_3112_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_rhs_3104_, v_a_3099_, v_snd_3108_);
if (lean_obj_tag(v___x_3112_) == 0)
{
lean_object* v_a_3113_; lean_object* v___x_3115_; uint8_t v_isShared_3116_; uint8_t v_isSharedCheck_3148_; 
v_a_3113_ = lean_ctor_get(v___x_3112_, 0);
v_isSharedCheck_3148_ = !lean_is_exclusive(v___x_3112_);
if (v_isSharedCheck_3148_ == 0)
{
v___x_3115_ = v___x_3112_;
v_isShared_3116_ = v_isSharedCheck_3148_;
goto v_resetjp_3114_;
}
else
{
lean_inc(v_a_3113_);
lean_dec(v___x_3112_);
v___x_3115_ = lean_box(0);
v_isShared_3116_ = v_isSharedCheck_3148_;
goto v_resetjp_3114_;
}
v_resetjp_3114_:
{
lean_object* v_fst_3117_; lean_object* v_snd_3118_; lean_object* v___x_3120_; uint8_t v_isShared_3121_; uint8_t v_isSharedCheck_3147_; 
v_fst_3117_ = lean_ctor_get(v_a_3113_, 0);
v_snd_3118_ = lean_ctor_get(v_a_3113_, 1);
v_isSharedCheck_3147_ = !lean_is_exclusive(v_a_3113_);
if (v_isSharedCheck_3147_ == 0)
{
v___x_3120_ = v_a_3113_;
v_isShared_3121_ = v_isSharedCheck_3147_;
goto v_resetjp_3119_;
}
else
{
lean_inc(v_snd_3118_);
lean_inc(v_fst_3117_);
lean_dec(v_a_3113_);
v___x_3120_ = lean_box(0);
v_isShared_3121_ = v_isSharedCheck_3147_;
goto v_resetjp_3119_;
}
v_resetjp_3119_:
{
lean_object* v___x_3122_; lean_object* v___x_3123_; lean_object* v___x_3124_; lean_object* v___x_3126_; 
v___x_3122_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__0));
v___x_3123_ = l_Lean_JsonNumber_fromNat(v_fst_3107_);
v___x_3124_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3124_, 0, v___x_3123_);
if (v_isShared_3121_ == 0)
{
lean_ctor_set(v___x_3120_, 1, v___x_3124_);
lean_ctor_set(v___x_3120_, 0, v___x_3122_);
v___x_3126_ = v___x_3120_;
goto v_reusejp_3125_;
}
else
{
lean_object* v_reuseFailAlloc_3146_; 
v_reuseFailAlloc_3146_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3146_, 0, v___x_3122_);
lean_ctor_set(v_reuseFailAlloc_3146_, 1, v___x_3124_);
v___x_3126_ = v_reuseFailAlloc_3146_;
goto v_reusejp_3125_;
}
v_reusejp_3125_:
{
lean_object* v___x_3127_; lean_object* v___x_3128_; lean_object* v___x_3129_; lean_object* v___x_3131_; 
v___x_3127_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__1));
v___x_3128_ = l_Lean_JsonNumber_fromNat(v_nfields_3103_);
v___x_3129_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3129_, 0, v___x_3128_);
if (v_isShared_3111_ == 0)
{
lean_ctor_set(v___x_3110_, 1, v___x_3129_);
lean_ctor_set(v___x_3110_, 0, v___x_3127_);
v___x_3131_ = v___x_3110_;
goto v_reusejp_3130_;
}
else
{
lean_object* v_reuseFailAlloc_3145_; 
v_reuseFailAlloc_3145_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3145_, 0, v___x_3127_);
lean_ctor_set(v_reuseFailAlloc_3145_, 1, v___x_3129_);
v___x_3131_ = v_reuseFailAlloc_3145_;
goto v_reusejp_3130_;
}
v_reusejp_3130_:
{
lean_object* v___x_3132_; lean_object* v___x_3133_; lean_object* v___x_3134_; lean_object* v___x_3135_; lean_object* v___x_3136_; lean_object* v___x_3137_; lean_object* v___x_3138_; lean_object* v___x_3139_; lean_object* v___x_3140_; lean_object* v___x_3141_; lean_object* v___x_3143_; 
v___x_3132_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___closed__2));
v___x_3133_ = l_Lean_JsonNumber_fromNat(v_fst_3117_);
v___x_3134_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3134_, 0, v___x_3133_);
v___x_3135_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3135_, 0, v___x_3132_);
lean_ctor_set(v___x_3135_, 1, v___x_3134_);
v___x_3136_ = lean_box(0);
v___x_3137_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3137_, 0, v___x_3135_);
lean_ctor_set(v___x_3137_, 1, v___x_3136_);
v___x_3138_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3138_, 0, v___x_3131_);
lean_ctor_set(v___x_3138_, 1, v___x_3137_);
v___x_3139_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3139_, 0, v___x_3126_);
lean_ctor_set(v___x_3139_, 1, v___x_3138_);
v___x_3140_ = l_Lean_Json_mkObj(v___x_3139_);
lean_dec_ref_known(v___x_3139_, 2);
v___x_3141_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3141_, 0, v___x_3140_);
lean_ctor_set(v___x_3141_, 1, v_snd_3118_);
if (v_isShared_3116_ == 0)
{
lean_ctor_set(v___x_3115_, 0, v___x_3141_);
v___x_3143_ = v___x_3115_;
goto v_reusejp_3142_;
}
else
{
lean_object* v_reuseFailAlloc_3144_; 
v_reuseFailAlloc_3144_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3144_, 0, v___x_3141_);
v___x_3143_ = v_reuseFailAlloc_3144_;
goto v_reusejp_3142_;
}
v_reusejp_3142_:
{
return v___x_3143_;
}
}
}
}
}
}
else
{
lean_object* v_a_3149_; lean_object* v___x_3151_; uint8_t v_isShared_3152_; uint8_t v_isSharedCheck_3156_; 
lean_del_object(v___x_3110_);
lean_dec(v_fst_3107_);
lean_dec(v_nfields_3103_);
v_a_3149_ = lean_ctor_get(v___x_3112_, 0);
v_isSharedCheck_3156_ = !lean_is_exclusive(v___x_3112_);
if (v_isSharedCheck_3156_ == 0)
{
v___x_3151_ = v___x_3112_;
v_isShared_3152_ = v_isSharedCheck_3156_;
goto v_resetjp_3150_;
}
else
{
lean_inc(v_a_3149_);
lean_dec(v___x_3112_);
v___x_3151_ = lean_box(0);
v_isShared_3152_ = v_isSharedCheck_3156_;
goto v_resetjp_3150_;
}
v_resetjp_3150_:
{
lean_object* v___x_3154_; 
if (v_isShared_3152_ == 0)
{
v___x_3154_ = v___x_3151_;
goto v_reusejp_3153_;
}
else
{
lean_object* v_reuseFailAlloc_3155_; 
v_reuseFailAlloc_3155_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3155_, 0, v_a_3149_);
v___x_3154_ = v_reuseFailAlloc_3155_;
goto v_reusejp_3153_;
}
v_reusejp_3153_:
{
return v___x_3154_;
}
}
}
}
}
else
{
lean_object* v_a_3158_; lean_object* v___x_3160_; uint8_t v_isShared_3161_; uint8_t v_isSharedCheck_3165_; 
lean_dec_ref(v_rhs_3104_);
lean_dec(v_nfields_3103_);
v_a_3158_ = lean_ctor_get(v___x_3105_, 0);
v_isSharedCheck_3165_ = !lean_is_exclusive(v___x_3105_);
if (v_isSharedCheck_3165_ == 0)
{
v___x_3160_ = v___x_3105_;
v_isShared_3161_ = v_isSharedCheck_3165_;
goto v_resetjp_3159_;
}
else
{
lean_inc(v_a_3158_);
lean_dec(v___x_3105_);
v___x_3160_ = lean_box(0);
v_isShared_3161_ = v_isSharedCheck_3165_;
goto v_resetjp_3159_;
}
v_resetjp_3159_:
{
lean_object* v___x_3163_; 
if (v_isShared_3161_ == 0)
{
v___x_3163_ = v___x_3160_;
goto v_reusejp_3162_;
}
else
{
lean_object* v_reuseFailAlloc_3164_; 
v_reuseFailAlloc_3164_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3164_, 0, v_a_3158_);
v___x_3163_ = v_reuseFailAlloc_3164_;
goto v_reusejp_3162_;
}
v_reusejp_3162_:
{
return v___x_3163_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpConstant_spec__2(lean_object* v_x_3166_, lean_object* v_x_3167_, lean_object* v___y_3168_, lean_object* v___y_3169_){
_start:
{
if (lean_obj_tag(v_x_3166_) == 0)
{
lean_object* v___x_3171_; lean_object* v___x_3172_; lean_object* v___x_3173_; 
v___x_3171_ = l_List_reverse___redArg(v_x_3167_);
v___x_3172_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3172_, 0, v___x_3171_);
lean_ctor_set(v___x_3172_, 1, v___y_3169_);
v___x_3173_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3173_, 0, v___x_3172_);
return v___x_3173_;
}
else
{
lean_object* v_head_3174_; lean_object* v_tail_3175_; lean_object* v___x_3177_; uint8_t v_isShared_3178_; uint8_t v_isSharedCheck_3195_; 
v_head_3174_ = lean_ctor_get(v_x_3166_, 0);
v_tail_3175_ = lean_ctor_get(v_x_3166_, 1);
v_isSharedCheck_3195_ = !lean_is_exclusive(v_x_3166_);
if (v_isSharedCheck_3195_ == 0)
{
v___x_3177_ = v_x_3166_;
v_isShared_3178_ = v_isSharedCheck_3195_;
goto v_resetjp_3176_;
}
else
{
lean_inc(v_tail_3175_);
lean_inc(v_head_3174_);
lean_dec(v_x_3166_);
v___x_3177_ = lean_box(0);
v_isShared_3178_ = v_isSharedCheck_3195_;
goto v_resetjp_3176_;
}
v_resetjp_3176_:
{
lean_object* v___x_3179_; 
v___x_3179_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule(v_head_3174_, v___y_3168_, v___y_3169_);
if (lean_obj_tag(v___x_3179_) == 0)
{
lean_object* v_a_3180_; lean_object* v_fst_3181_; lean_object* v_snd_3182_; lean_object* v___x_3184_; 
v_a_3180_ = lean_ctor_get(v___x_3179_, 0);
lean_inc(v_a_3180_);
lean_dec_ref_known(v___x_3179_, 1);
v_fst_3181_ = lean_ctor_get(v_a_3180_, 0);
lean_inc(v_fst_3181_);
v_snd_3182_ = lean_ctor_get(v_a_3180_, 1);
lean_inc(v_snd_3182_);
lean_dec(v_a_3180_);
if (v_isShared_3178_ == 0)
{
lean_ctor_set(v___x_3177_, 1, v_x_3167_);
lean_ctor_set(v___x_3177_, 0, v_fst_3181_);
v___x_3184_ = v___x_3177_;
goto v_reusejp_3183_;
}
else
{
lean_object* v_reuseFailAlloc_3186_; 
v_reuseFailAlloc_3186_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3186_, 0, v_fst_3181_);
lean_ctor_set(v_reuseFailAlloc_3186_, 1, v_x_3167_);
v___x_3184_ = v_reuseFailAlloc_3186_;
goto v_reusejp_3183_;
}
v_reusejp_3183_:
{
v_x_3166_ = v_tail_3175_;
v_x_3167_ = v___x_3184_;
v___y_3169_ = v_snd_3182_;
goto _start;
}
}
else
{
lean_object* v_a_3187_; lean_object* v___x_3189_; uint8_t v_isShared_3190_; uint8_t v_isSharedCheck_3194_; 
lean_del_object(v___x_3177_);
lean_dec(v_tail_3175_);
lean_dec(v_x_3167_);
v_a_3187_ = lean_ctor_get(v___x_3179_, 0);
v_isSharedCheck_3194_ = !lean_is_exclusive(v___x_3179_);
if (v_isSharedCheck_3194_ == 0)
{
v___x_3189_ = v___x_3179_;
v_isShared_3190_ = v_isSharedCheck_3194_;
goto v_resetjp_3188_;
}
else
{
lean_inc(v_a_3187_);
lean_dec(v___x_3179_);
v___x_3189_ = lean_box(0);
v_isShared_3190_ = v_isSharedCheck_3194_;
goto v_resetjp_3188_;
}
v_resetjp_3188_:
{
lean_object* v___x_3192_; 
if (v_isShared_3190_ == 0)
{
v___x_3192_ = v___x_3189_;
goto v_reusejp_3191_;
}
else
{
lean_object* v_reuseFailAlloc_3193_; 
v_reuseFailAlloc_3193_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3193_, 0, v_a_3187_);
v___x_3192_ = v_reuseFailAlloc_3193_;
goto v_reusejp_3191_;
}
v_reusejp_3191_:
{
return v___x_3192_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17(size_t v_sz_3200_, size_t v_i_3201_, lean_object* v_bs_3202_, lean_object* v___y_3203_, lean_object* v___y_3204_){
_start:
{
uint8_t v___x_3206_; 
v___x_3206_ = lean_usize_dec_lt(v_i_3201_, v_sz_3200_);
if (v___x_3206_ == 0)
{
lean_object* v___x_3207_; lean_object* v___x_3208_; 
v___x_3207_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3207_, 0, v_bs_3202_);
lean_ctor_set(v___x_3207_, 1, v___y_3204_);
v___x_3208_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3208_, 0, v___x_3207_);
return v___x_3208_;
}
else
{
lean_object* v_v_3209_; lean_object* v_toConstantVal_3210_; lean_object* v_all_3211_; lean_object* v_numParams_3212_; lean_object* v_numIndices_3213_; lean_object* v_numMotives_3214_; lean_object* v_numMinors_3215_; lean_object* v_rules_3216_; uint8_t v_k_3217_; uint8_t v_isUnsafe_3218_; lean_object* v_name_3219_; lean_object* v_levelParams_3220_; lean_object* v_type_3221_; lean_object* v___x_3222_; 
v_v_3209_ = lean_array_uget_borrowed(v_bs_3202_, v_i_3201_);
v_toConstantVal_3210_ = lean_ctor_get(v_v_3209_, 0);
v_all_3211_ = lean_ctor_get(v_v_3209_, 1);
lean_inc(v_all_3211_);
v_numParams_3212_ = lean_ctor_get(v_v_3209_, 2);
lean_inc(v_numParams_3212_);
v_numIndices_3213_ = lean_ctor_get(v_v_3209_, 3);
lean_inc(v_numIndices_3213_);
v_numMotives_3214_ = lean_ctor_get(v_v_3209_, 4);
lean_inc(v_numMotives_3214_);
v_numMinors_3215_ = lean_ctor_get(v_v_3209_, 5);
lean_inc(v_numMinors_3215_);
v_rules_3216_ = lean_ctor_get(v_v_3209_, 6);
lean_inc(v_rules_3216_);
v_k_3217_ = lean_ctor_get_uint8(v_v_3209_, sizeof(void*)*7);
v_isUnsafe_3218_ = lean_ctor_get_uint8(v_v_3209_, sizeof(void*)*7 + 1);
v_name_3219_ = lean_ctor_get(v_toConstantVal_3210_, 0);
v_levelParams_3220_ = lean_ctor_get(v_toConstantVal_3210_, 1);
lean_inc(v_levelParams_3220_);
v_type_3221_ = lean_ctor_get(v_toConstantVal_3210_, 2);
lean_inc_ref(v_type_3221_);
lean_inc(v_name_3219_);
v___x_3222_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_3219_, v___y_3203_, v___y_3204_);
if (lean_obj_tag(v___x_3222_) == 0)
{
lean_object* v_a_3223_; lean_object* v_fst_3224_; lean_object* v_snd_3225_; lean_object* v___x_3227_; uint8_t v_isShared_3228_; uint8_t v_isSharedCheck_3371_; 
v_a_3223_ = lean_ctor_get(v___x_3222_, 0);
lean_inc(v_a_3223_);
lean_dec_ref_known(v___x_3222_, 1);
v_fst_3224_ = lean_ctor_get(v_a_3223_, 0);
v_snd_3225_ = lean_ctor_get(v_a_3223_, 1);
v_isSharedCheck_3371_ = !lean_is_exclusive(v_a_3223_);
if (v_isSharedCheck_3371_ == 0)
{
v___x_3227_ = v_a_3223_;
v_isShared_3228_ = v_isSharedCheck_3371_;
goto v_resetjp_3226_;
}
else
{
lean_inc(v_snd_3225_);
lean_inc(v_fst_3224_);
lean_dec(v_a_3223_);
v___x_3227_ = lean_box(0);
v_isShared_3228_ = v_isSharedCheck_3371_;
goto v_resetjp_3226_;
}
v_resetjp_3226_:
{
lean_object* v___x_3229_; lean_object* v_bs_x27_3230_; lean_object* v_fst_3232_; lean_object* v_snd_3233_; lean_object* v___y_3239_; lean_object* v___x_3251_; 
v___x_3229_ = lean_unsigned_to_nat(0u);
v_bs_x27_3230_ = lean_array_uset(v_bs_3202_, v_i_3201_, v___x_3229_);
v___x_3251_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_3220_, v___y_3203_, v_snd_3225_);
if (lean_obj_tag(v___x_3251_) == 0)
{
lean_object* v_a_3252_; lean_object* v___x_3254_; uint8_t v_isShared_3255_; uint8_t v_isSharedCheck_3370_; 
v_a_3252_ = lean_ctor_get(v___x_3251_, 0);
v_isSharedCheck_3370_ = !lean_is_exclusive(v___x_3251_);
if (v_isSharedCheck_3370_ == 0)
{
v___x_3254_ = v___x_3251_;
v_isShared_3255_ = v_isSharedCheck_3370_;
goto v_resetjp_3253_;
}
else
{
lean_inc(v_a_3252_);
lean_dec(v___x_3251_);
v___x_3254_ = lean_box(0);
v_isShared_3255_ = v_isSharedCheck_3370_;
goto v_resetjp_3253_;
}
v_resetjp_3253_:
{
lean_object* v_fst_3256_; lean_object* v_snd_3257_; lean_object* v___x_3259_; uint8_t v_isShared_3260_; uint8_t v_isSharedCheck_3369_; 
v_fst_3256_ = lean_ctor_get(v_a_3252_, 0);
v_snd_3257_ = lean_ctor_get(v_a_3252_, 1);
v_isSharedCheck_3369_ = !lean_is_exclusive(v_a_3252_);
if (v_isSharedCheck_3369_ == 0)
{
v___x_3259_ = v_a_3252_;
v_isShared_3260_ = v_isSharedCheck_3369_;
goto v_resetjp_3258_;
}
else
{
lean_inc(v_snd_3257_);
lean_inc(v_fst_3256_);
lean_dec(v_a_3252_);
v___x_3259_ = lean_box(0);
v_isShared_3260_ = v_isSharedCheck_3369_;
goto v_resetjp_3258_;
}
v_resetjp_3258_:
{
lean_object* v___x_3261_; 
v___x_3261_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_3221_, v___y_3203_, v_snd_3257_);
if (lean_obj_tag(v___x_3261_) == 0)
{
lean_object* v_a_3262_; lean_object* v_fst_3263_; lean_object* v_snd_3264_; lean_object* v___x_3266_; uint8_t v_isShared_3267_; uint8_t v_isSharedCheck_3360_; 
v_a_3262_ = lean_ctor_get(v___x_3261_, 0);
lean_inc(v_a_3262_);
lean_dec_ref_known(v___x_3261_, 1);
v_fst_3263_ = lean_ctor_get(v_a_3262_, 0);
v_snd_3264_ = lean_ctor_get(v_a_3262_, 1);
v_isSharedCheck_3360_ = !lean_is_exclusive(v_a_3262_);
if (v_isSharedCheck_3360_ == 0)
{
v___x_3266_ = v_a_3262_;
v_isShared_3267_ = v_isSharedCheck_3360_;
goto v_resetjp_3265_;
}
else
{
lean_inc(v_snd_3264_);
lean_inc(v_fst_3263_);
lean_dec(v_a_3262_);
v___x_3266_ = lean_box(0);
v_isShared_3267_ = v_isSharedCheck_3360_;
goto v_resetjp_3265_;
}
v_resetjp_3265_:
{
lean_object* v___x_3268_; 
v___x_3268_ = lp_proofEnvironment_CheckedExport_dumpNames(v_all_3211_, v___y_3203_, v_snd_3264_);
if (lean_obj_tag(v___x_3268_) == 0)
{
lean_object* v_a_3269_; lean_object* v___x_3271_; uint8_t v_isShared_3272_; uint8_t v_isSharedCheck_3359_; 
v_a_3269_ = lean_ctor_get(v___x_3268_, 0);
v_isSharedCheck_3359_ = !lean_is_exclusive(v___x_3268_);
if (v_isSharedCheck_3359_ == 0)
{
v___x_3271_ = v___x_3268_;
v_isShared_3272_ = v_isSharedCheck_3359_;
goto v_resetjp_3270_;
}
else
{
lean_inc(v_a_3269_);
lean_dec(v___x_3268_);
v___x_3271_ = lean_box(0);
v_isShared_3272_ = v_isSharedCheck_3359_;
goto v_resetjp_3270_;
}
v_resetjp_3270_:
{
lean_object* v_fst_3273_; lean_object* v_snd_3274_; lean_object* v___x_3276_; uint8_t v_isShared_3277_; uint8_t v_isSharedCheck_3358_; 
v_fst_3273_ = lean_ctor_get(v_a_3269_, 0);
v_snd_3274_ = lean_ctor_get(v_a_3269_, 1);
v_isSharedCheck_3358_ = !lean_is_exclusive(v_a_3269_);
if (v_isSharedCheck_3358_ == 0)
{
v___x_3276_ = v_a_3269_;
v_isShared_3277_ = v_isSharedCheck_3358_;
goto v_resetjp_3275_;
}
else
{
lean_inc(v_snd_3274_);
lean_inc(v_fst_3273_);
lean_dec(v_a_3269_);
v___x_3276_ = lean_box(0);
v_isShared_3277_ = v_isSharedCheck_3358_;
goto v_resetjp_3275_;
}
v_resetjp_3275_:
{
lean_object* v___x_3278_; lean_object* v___x_3279_; 
v___x_3278_ = lean_box(0);
v___x_3279_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpConstant_spec__2(v_rules_3216_, v___x_3278_, v___y_3203_, v_snd_3274_);
if (lean_obj_tag(v___x_3279_) == 0)
{
lean_object* v_a_3280_; lean_object* v_fst_3281_; lean_object* v_snd_3282_; lean_object* v___x_3284_; uint8_t v_isShared_3285_; uint8_t v_isSharedCheck_3349_; 
v_a_3280_ = lean_ctor_get(v___x_3279_, 0);
lean_inc(v_a_3280_);
lean_dec_ref_known(v___x_3279_, 1);
v_fst_3281_ = lean_ctor_get(v_a_3280_, 0);
v_snd_3282_ = lean_ctor_get(v_a_3280_, 1);
v_isSharedCheck_3349_ = !lean_is_exclusive(v_a_3280_);
if (v_isSharedCheck_3349_ == 0)
{
v___x_3284_ = v_a_3280_;
v_isShared_3285_ = v_isSharedCheck_3349_;
goto v_resetjp_3283_;
}
else
{
lean_inc(v_snd_3282_);
lean_inc(v_fst_3281_);
lean_dec(v_a_3280_);
v___x_3284_ = lean_box(0);
v_isShared_3285_ = v_isSharedCheck_3349_;
goto v_resetjp_3283_;
}
v_resetjp_3283_:
{
lean_object* v___x_3286_; lean_object* v___x_3287_; lean_object* v___x_3289_; 
v___x_3286_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_3287_ = l_Lean_JsonNumber_fromNat(v_fst_3224_);
if (v_isShared_3272_ == 0)
{
lean_ctor_set_tag(v___x_3271_, 2);
lean_ctor_set(v___x_3271_, 0, v___x_3287_);
v___x_3289_ = v___x_3271_;
goto v_reusejp_3288_;
}
else
{
lean_object* v_reuseFailAlloc_3348_; 
v_reuseFailAlloc_3348_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3348_, 0, v___x_3287_);
v___x_3289_ = v_reuseFailAlloc_3348_;
goto v_reusejp_3288_;
}
v_reusejp_3288_:
{
lean_object* v___x_3291_; 
if (v_isShared_3285_ == 0)
{
lean_ctor_set(v___x_3284_, 1, v___x_3289_);
lean_ctor_set(v___x_3284_, 0, v___x_3286_);
v___x_3291_ = v___x_3284_;
goto v_reusejp_3290_;
}
else
{
lean_object* v_reuseFailAlloc_3347_; 
v_reuseFailAlloc_3347_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3347_, 0, v___x_3286_);
lean_ctor_set(v_reuseFailAlloc_3347_, 1, v___x_3289_);
v___x_3291_ = v_reuseFailAlloc_3347_;
goto v_reusejp_3290_;
}
v_reusejp_3290_:
{
lean_object* v___x_3292_; lean_object* v___x_3294_; 
v___x_3292_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_3277_ == 0)
{
lean_ctor_set(v___x_3276_, 1, v_fst_3256_);
lean_ctor_set(v___x_3276_, 0, v___x_3292_);
v___x_3294_ = v___x_3276_;
goto v_reusejp_3293_;
}
else
{
lean_object* v_reuseFailAlloc_3346_; 
v_reuseFailAlloc_3346_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3346_, 0, v___x_3292_);
lean_ctor_set(v_reuseFailAlloc_3346_, 1, v_fst_3256_);
v___x_3294_ = v_reuseFailAlloc_3346_;
goto v_reusejp_3293_;
}
v_reusejp_3293_:
{
lean_object* v___x_3295_; lean_object* v___x_3296_; lean_object* v___x_3298_; 
v___x_3295_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_3296_ = l_Lean_JsonNumber_fromNat(v_fst_3263_);
if (v_isShared_3255_ == 0)
{
lean_ctor_set_tag(v___x_3254_, 2);
lean_ctor_set(v___x_3254_, 0, v___x_3296_);
v___x_3298_ = v___x_3254_;
goto v_reusejp_3297_;
}
else
{
lean_object* v_reuseFailAlloc_3345_; 
v_reuseFailAlloc_3345_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3345_, 0, v___x_3296_);
v___x_3298_ = v_reuseFailAlloc_3345_;
goto v_reusejp_3297_;
}
v_reusejp_3297_:
{
lean_object* v___x_3300_; 
if (v_isShared_3267_ == 0)
{
lean_ctor_set(v___x_3266_, 1, v___x_3298_);
lean_ctor_set(v___x_3266_, 0, v___x_3295_);
v___x_3300_ = v___x_3266_;
goto v_reusejp_3299_;
}
else
{
lean_object* v_reuseFailAlloc_3344_; 
v_reuseFailAlloc_3344_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3344_, 0, v___x_3295_);
lean_ctor_set(v_reuseFailAlloc_3344_, 1, v___x_3298_);
v___x_3300_ = v_reuseFailAlloc_3344_;
goto v_reusejp_3299_;
}
v_reusejp_3299_:
{
lean_object* v___x_3301_; lean_object* v___x_3303_; 
v___x_3301_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1));
if (v_isShared_3260_ == 0)
{
lean_ctor_set(v___x_3259_, 1, v_fst_3273_);
lean_ctor_set(v___x_3259_, 0, v___x_3301_);
v___x_3303_ = v___x_3259_;
goto v_reusejp_3302_;
}
else
{
lean_object* v_reuseFailAlloc_3343_; 
v_reuseFailAlloc_3343_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3343_, 0, v___x_3301_);
lean_ctor_set(v_reuseFailAlloc_3343_, 1, v_fst_3273_);
v___x_3303_ = v_reuseFailAlloc_3343_;
goto v_reusejp_3302_;
}
v_reusejp_3302_:
{
lean_object* v___x_3304_; lean_object* v___x_3305_; lean_object* v___x_3306_; lean_object* v___x_3308_; 
v___x_3304_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__5));
v___x_3305_ = l_Lean_JsonNumber_fromNat(v_numParams_3212_);
v___x_3306_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3306_, 0, v___x_3305_);
if (v_isShared_3228_ == 0)
{
lean_ctor_set(v___x_3227_, 1, v___x_3306_);
lean_ctor_set(v___x_3227_, 0, v___x_3304_);
v___x_3308_ = v___x_3227_;
goto v_reusejp_3307_;
}
else
{
lean_object* v_reuseFailAlloc_3342_; 
v_reuseFailAlloc_3342_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3342_, 0, v___x_3304_);
lean_ctor_set(v_reuseFailAlloc_3342_, 1, v___x_3306_);
v___x_3308_ = v_reuseFailAlloc_3342_;
goto v_reusejp_3307_;
}
v_reusejp_3307_:
{
lean_object* v___x_3309_; lean_object* v___x_3310_; lean_object* v___x_3311_; lean_object* v___x_3312_; lean_object* v___x_3313_; lean_object* v___x_3314_; lean_object* v___x_3315_; lean_object* v___x_3316_; lean_object* v___x_3317_; lean_object* v___x_3318_; lean_object* v___x_3319_; lean_object* v___x_3320_; lean_object* v___x_3321_; lean_object* v___x_3322_; lean_object* v___x_3323_; lean_object* v___x_3324_; lean_object* v___x_3325_; lean_object* v___x_3326_; lean_object* v___x_3327_; lean_object* v___x_3328_; lean_object* v___x_3329_; lean_object* v___x_3330_; lean_object* v___x_3331_; lean_object* v___x_3332_; lean_object* v___x_3333_; lean_object* v___x_3334_; lean_object* v___x_3335_; lean_object* v___x_3336_; lean_object* v___x_3337_; lean_object* v___x_3338_; lean_object* v___x_3339_; lean_object* v___x_3340_; lean_object* v___x_3341_; 
v___x_3309_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__0));
v___x_3310_ = l_Lean_JsonNumber_fromNat(v_numIndices_3213_);
v___x_3311_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3311_, 0, v___x_3310_);
v___x_3312_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3312_, 0, v___x_3309_);
lean_ctor_set(v___x_3312_, 1, v___x_3311_);
v___x_3313_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__0));
v___x_3314_ = l_Lean_JsonNumber_fromNat(v_numMotives_3214_);
v___x_3315_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3315_, 0, v___x_3314_);
v___x_3316_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3316_, 0, v___x_3313_);
lean_ctor_set(v___x_3316_, 1, v___x_3315_);
v___x_3317_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__1));
v___x_3318_ = l_Lean_JsonNumber_fromNat(v_numMinors_3215_);
v___x_3319_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3319_, 0, v___x_3318_);
v___x_3320_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3320_, 0, v___x_3317_);
lean_ctor_set(v___x_3320_, 1, v___x_3319_);
v___x_3321_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__2));
v___x_3322_ = l_Lean_List_toJson___at___00Lean_Option_toJson___at___00Lean_Server_instToJsonIlean_toJson_spec__1_spec__1(v_fst_3281_);
v___x_3323_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3323_, 0, v___x_3321_);
lean_ctor_set(v___x_3323_, 1, v___x_3322_);
v___x_3324_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___closed__3));
v___x_3325_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3325_, 0, v_k_3217_);
v___x_3326_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3326_, 0, v___x_3324_);
lean_ctor_set(v___x_3326_, 1, v___x_3325_);
v___x_3327_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7));
v___x_3328_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3328_, 0, v_isUnsafe_3218_);
v___x_3329_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3329_, 0, v___x_3327_);
lean_ctor_set(v___x_3329_, 1, v___x_3328_);
v___x_3330_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3330_, 0, v___x_3329_);
lean_ctor_set(v___x_3330_, 1, v___x_3278_);
v___x_3331_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3331_, 0, v___x_3326_);
lean_ctor_set(v___x_3331_, 1, v___x_3330_);
v___x_3332_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3332_, 0, v___x_3323_);
lean_ctor_set(v___x_3332_, 1, v___x_3331_);
v___x_3333_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3333_, 0, v___x_3320_);
lean_ctor_set(v___x_3333_, 1, v___x_3332_);
v___x_3334_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3334_, 0, v___x_3316_);
lean_ctor_set(v___x_3334_, 1, v___x_3333_);
v___x_3335_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3335_, 0, v___x_3312_);
lean_ctor_set(v___x_3335_, 1, v___x_3334_);
v___x_3336_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3336_, 0, v___x_3308_);
lean_ctor_set(v___x_3336_, 1, v___x_3335_);
v___x_3337_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3337_, 0, v___x_3303_);
lean_ctor_set(v___x_3337_, 1, v___x_3336_);
v___x_3338_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3338_, 0, v___x_3300_);
lean_ctor_set(v___x_3338_, 1, v___x_3337_);
v___x_3339_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3339_, 0, v___x_3294_);
lean_ctor_set(v___x_3339_, 1, v___x_3338_);
v___x_3340_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3340_, 0, v___x_3291_);
lean_ctor_set(v___x_3340_, 1, v___x_3339_);
v___x_3341_ = l_Lean_Json_mkObj(v___x_3340_);
lean_dec_ref_known(v___x_3340_, 2);
v_fst_3232_ = v___x_3341_;
v_snd_3233_ = v_snd_3282_;
goto v___jp_3231_;
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_3350_; lean_object* v___x_3352_; uint8_t v_isShared_3353_; uint8_t v_isSharedCheck_3357_; 
lean_del_object(v___x_3276_);
lean_dec(v_fst_3273_);
lean_del_object(v___x_3271_);
lean_del_object(v___x_3266_);
lean_dec(v_fst_3263_);
lean_del_object(v___x_3259_);
lean_dec(v_fst_3256_);
lean_del_object(v___x_3254_);
lean_dec_ref(v_bs_x27_3230_);
lean_del_object(v___x_3227_);
lean_dec(v_fst_3224_);
lean_dec(v_numMinors_3215_);
lean_dec(v_numMotives_3214_);
lean_dec(v_numIndices_3213_);
lean_dec(v_numParams_3212_);
v_a_3350_ = lean_ctor_get(v___x_3279_, 0);
v_isSharedCheck_3357_ = !lean_is_exclusive(v___x_3279_);
if (v_isSharedCheck_3357_ == 0)
{
v___x_3352_ = v___x_3279_;
v_isShared_3353_ = v_isSharedCheck_3357_;
goto v_resetjp_3351_;
}
else
{
lean_inc(v_a_3350_);
lean_dec(v___x_3279_);
v___x_3352_ = lean_box(0);
v_isShared_3353_ = v_isSharedCheck_3357_;
goto v_resetjp_3351_;
}
v_resetjp_3351_:
{
lean_object* v___x_3355_; 
if (v_isShared_3353_ == 0)
{
v___x_3355_ = v___x_3352_;
goto v_reusejp_3354_;
}
else
{
lean_object* v_reuseFailAlloc_3356_; 
v_reuseFailAlloc_3356_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3356_, 0, v_a_3350_);
v___x_3355_ = v_reuseFailAlloc_3356_;
goto v_reusejp_3354_;
}
v_reusejp_3354_:
{
return v___x_3355_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_3266_);
lean_dec(v_fst_3263_);
lean_del_object(v___x_3259_);
lean_dec(v_fst_3256_);
lean_del_object(v___x_3254_);
lean_del_object(v___x_3227_);
lean_dec(v_fst_3224_);
lean_dec(v_rules_3216_);
lean_dec(v_numMinors_3215_);
lean_dec(v_numMotives_3214_);
lean_dec(v_numIndices_3213_);
lean_dec(v_numParams_3212_);
v___y_3239_ = v___x_3268_;
goto v___jp_3238_;
}
}
}
else
{
lean_object* v_a_3361_; lean_object* v___x_3363_; uint8_t v_isShared_3364_; uint8_t v_isSharedCheck_3368_; 
lean_del_object(v___x_3259_);
lean_dec(v_fst_3256_);
lean_del_object(v___x_3254_);
lean_dec_ref(v_bs_x27_3230_);
lean_del_object(v___x_3227_);
lean_dec(v_fst_3224_);
lean_dec(v_rules_3216_);
lean_dec(v_numMinors_3215_);
lean_dec(v_numMotives_3214_);
lean_dec(v_numIndices_3213_);
lean_dec(v_numParams_3212_);
lean_dec(v_all_3211_);
v_a_3361_ = lean_ctor_get(v___x_3261_, 0);
v_isSharedCheck_3368_ = !lean_is_exclusive(v___x_3261_);
if (v_isSharedCheck_3368_ == 0)
{
v___x_3363_ = v___x_3261_;
v_isShared_3364_ = v_isSharedCheck_3368_;
goto v_resetjp_3362_;
}
else
{
lean_inc(v_a_3361_);
lean_dec(v___x_3261_);
v___x_3363_ = lean_box(0);
v_isShared_3364_ = v_isSharedCheck_3368_;
goto v_resetjp_3362_;
}
v_resetjp_3362_:
{
lean_object* v___x_3366_; 
if (v_isShared_3364_ == 0)
{
v___x_3366_ = v___x_3363_;
goto v_reusejp_3365_;
}
else
{
lean_object* v_reuseFailAlloc_3367_; 
v_reuseFailAlloc_3367_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3367_, 0, v_a_3361_);
v___x_3366_ = v_reuseFailAlloc_3367_;
goto v_reusejp_3365_;
}
v_reusejp_3365_:
{
return v___x_3366_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_3227_);
lean_dec(v_fst_3224_);
lean_dec_ref(v_type_3221_);
lean_dec(v_rules_3216_);
lean_dec(v_numMinors_3215_);
lean_dec(v_numMotives_3214_);
lean_dec(v_numIndices_3213_);
lean_dec(v_numParams_3212_);
lean_dec(v_all_3211_);
v___y_3239_ = v___x_3251_;
goto v___jp_3238_;
}
v___jp_3231_:
{
size_t v___x_3234_; size_t v___x_3235_; lean_object* v___x_3236_; 
v___x_3234_ = ((size_t)1ULL);
v___x_3235_ = lean_usize_add(v_i_3201_, v___x_3234_);
v___x_3236_ = lean_array_uset(v_bs_x27_3230_, v_i_3201_, v_fst_3232_);
v_i_3201_ = v___x_3235_;
v_bs_3202_ = v___x_3236_;
v___y_3204_ = v_snd_3233_;
goto _start;
}
v___jp_3238_:
{
if (lean_obj_tag(v___y_3239_) == 0)
{
lean_object* v_a_3240_; lean_object* v_fst_3241_; lean_object* v_snd_3242_; 
v_a_3240_ = lean_ctor_get(v___y_3239_, 0);
lean_inc(v_a_3240_);
lean_dec_ref_known(v___y_3239_, 1);
v_fst_3241_ = lean_ctor_get(v_a_3240_, 0);
lean_inc(v_fst_3241_);
v_snd_3242_ = lean_ctor_get(v_a_3240_, 1);
lean_inc(v_snd_3242_);
lean_dec(v_a_3240_);
v_fst_3232_ = v_fst_3241_;
v_snd_3233_ = v_snd_3242_;
goto v___jp_3231_;
}
else
{
lean_object* v_a_3243_; lean_object* v___x_3245_; uint8_t v_isShared_3246_; uint8_t v_isSharedCheck_3250_; 
lean_dec_ref(v_bs_x27_3230_);
v_a_3243_ = lean_ctor_get(v___y_3239_, 0);
v_isSharedCheck_3250_ = !lean_is_exclusive(v___y_3239_);
if (v_isSharedCheck_3250_ == 0)
{
v___x_3245_ = v___y_3239_;
v_isShared_3246_ = v_isSharedCheck_3250_;
goto v_resetjp_3244_;
}
else
{
lean_inc(v_a_3243_);
lean_dec(v___y_3239_);
v___x_3245_ = lean_box(0);
v_isShared_3246_ = v_isSharedCheck_3250_;
goto v_resetjp_3244_;
}
v_resetjp_3244_:
{
lean_object* v___x_3248_; 
if (v_isShared_3246_ == 0)
{
v___x_3248_ = v___x_3245_;
goto v_reusejp_3247_;
}
else
{
lean_object* v_reuseFailAlloc_3249_; 
v_reuseFailAlloc_3249_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3249_, 0, v_a_3243_);
v___x_3248_ = v_reuseFailAlloc_3249_;
goto v_reusejp_3247_;
}
v_reusejp_3247_:
{
return v___x_3248_;
}
}
}
}
}
}
else
{
lean_object* v_a_3372_; lean_object* v___x_3374_; uint8_t v_isShared_3375_; uint8_t v_isSharedCheck_3379_; 
lean_dec_ref(v_type_3221_);
lean_dec(v_levelParams_3220_);
lean_dec(v_rules_3216_);
lean_dec(v_numMinors_3215_);
lean_dec(v_numMotives_3214_);
lean_dec(v_numIndices_3213_);
lean_dec(v_numParams_3212_);
lean_dec(v_all_3211_);
lean_dec_ref(v_bs_3202_);
v_a_3372_ = lean_ctor_get(v___x_3222_, 0);
v_isSharedCheck_3379_ = !lean_is_exclusive(v___x_3222_);
if (v_isSharedCheck_3379_ == 0)
{
v___x_3374_ = v___x_3222_;
v_isShared_3375_ = v_isSharedCheck_3379_;
goto v_resetjp_3373_;
}
else
{
lean_inc(v_a_3372_);
lean_dec(v___x_3222_);
v___x_3374_ = lean_box(0);
v_isShared_3375_ = v_isSharedCheck_3379_;
goto v_resetjp_3373_;
}
v_resetjp_3373_:
{
lean_object* v___x_3377_; 
if (v_isShared_3375_ == 0)
{
v___x_3377_ = v___x_3374_;
goto v_reusejp_3376_;
}
else
{
lean_object* v_reuseFailAlloc_3378_; 
v_reuseFailAlloc_3378_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3378_, 0, v_a_3372_);
v___x_3377_ = v_reuseFailAlloc_3378_;
goto v_reusejp_3376_;
}
v_reusejp_3376_:
{
return v___x_3377_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg(lean_object* v_as_x27_3431_, lean_object* v_b_3432_, lean_object* v___y_3433_, lean_object* v___y_3434_){
_start:
{
if (lean_obj_tag(v_as_x27_3431_) == 0)
{
lean_object* v___x_3436_; lean_object* v___x_3437_; 
v___x_3436_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3436_, 0, v_b_3432_);
lean_ctor_set(v___x_3436_, 1, v___y_3434_);
v___x_3437_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3437_, 0, v___x_3436_);
return v___x_3437_;
}
else
{
lean_object* v_head_3438_; lean_object* v_tail_3439_; lean_object* v___x_3440_; lean_object* v___y_3442_; lean_object* v___y_3443_; lean_object* v___x_3471_; 
lean_dec_ref(v_b_3432_);
v_head_3438_ = lean_ctor_get(v_as_x27_3431_, 0);
v_tail_3439_ = lean_ctor_get(v_as_x27_3431_, 1);
v___x_3440_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__0));
lean_inc(v_head_3438_);
lean_inc_ref(v___y_3433_);
v___x_3471_ = lean_environment_find(v___y_3433_, v_head_3438_);
if (lean_obj_tag(v___x_3471_) == 1)
{
lean_object* v_val_3472_; lean_object* v___x_3474_; uint8_t v_isShared_3475_; uint8_t v_isSharedCheck_3595_; 
v_val_3472_ = lean_ctor_get(v___x_3471_, 0);
v_isSharedCheck_3595_ = !lean_is_exclusive(v___x_3471_);
if (v_isSharedCheck_3595_ == 0)
{
v___x_3474_ = v___x_3471_;
v_isShared_3475_ = v_isSharedCheck_3595_;
goto v_resetjp_3473_;
}
else
{
lean_inc(v_val_3472_);
lean_dec(v___x_3471_);
v___x_3474_ = lean_box(0);
v_isShared_3475_ = v_isSharedCheck_3595_;
goto v_resetjp_3473_;
}
v_resetjp_3473_:
{
if (lean_obj_tag(v_val_3472_) == 4)
{
lean_object* v_val_3476_; lean_object* v___x_3478_; uint8_t v_isShared_3479_; uint8_t v_isSharedCheck_3594_; 
v_val_3476_ = lean_ctor_get(v_val_3472_, 0);
v_isSharedCheck_3594_ = !lean_is_exclusive(v_val_3472_);
if (v_isSharedCheck_3594_ == 0)
{
v___x_3478_ = v_val_3472_;
v_isShared_3479_ = v_isSharedCheck_3594_;
goto v_resetjp_3477_;
}
else
{
lean_inc(v_val_3476_);
lean_dec(v_val_3472_);
v___x_3478_ = lean_box(0);
v_isShared_3479_ = v_isSharedCheck_3594_;
goto v_resetjp_3477_;
}
v_resetjp_3477_:
{
lean_object* v_toConstantVal_3480_; lean_object* v_visitedNames_3481_; lean_object* v_visitedLevels_3482_; lean_object* v_visitedExprs_3483_; lean_object* v_visitedConstants_3484_; lean_object* v_noMDataExprs_3485_; uint8_t v_exportMData_3486_; uint8_t v_exportUnsafe_3487_; uint8_t v_ignoreMissing_3488_; lean_object* v_recursorMap_3489_; lean_object* v___x_3491_; uint8_t v_isShared_3492_; uint8_t v_isSharedCheck_3593_; 
v_toConstantVal_3480_ = lean_ctor_get(v_val_3476_, 0);
lean_inc_ref(v_toConstantVal_3480_);
v_visitedNames_3481_ = lean_ctor_get(v___y_3434_, 0);
v_visitedLevels_3482_ = lean_ctor_get(v___y_3434_, 1);
v_visitedExprs_3483_ = lean_ctor_get(v___y_3434_, 2);
v_visitedConstants_3484_ = lean_ctor_get(v___y_3434_, 3);
v_noMDataExprs_3485_ = lean_ctor_get(v___y_3434_, 4);
v_exportMData_3486_ = lean_ctor_get_uint8(v___y_3434_, sizeof(void*)*6);
v_exportUnsafe_3487_ = lean_ctor_get_uint8(v___y_3434_, sizeof(void*)*6 + 1);
v_ignoreMissing_3488_ = lean_ctor_get_uint8(v___y_3434_, sizeof(void*)*6 + 2);
v_recursorMap_3489_ = lean_ctor_get(v___y_3434_, 5);
v_isSharedCheck_3593_ = !lean_is_exclusive(v___y_3434_);
if (v_isSharedCheck_3593_ == 0)
{
v___x_3491_ = v___y_3434_;
v_isShared_3492_ = v_isSharedCheck_3593_;
goto v_resetjp_3490_;
}
else
{
lean_inc(v_recursorMap_3489_);
lean_inc(v_noMDataExprs_3485_);
lean_inc(v_visitedConstants_3484_);
lean_inc(v_visitedExprs_3483_);
lean_inc(v_visitedLevels_3482_);
lean_inc(v_visitedNames_3481_);
lean_dec(v___y_3434_);
v___x_3491_ = lean_box(0);
v_isShared_3492_ = v_isSharedCheck_3593_;
goto v_resetjp_3490_;
}
v_resetjp_3490_:
{
uint8_t v_kind_3493_; lean_object* v_name_3494_; lean_object* v_levelParams_3495_; lean_object* v_type_3496_; lean_object* v___x_3497_; lean_object* v___x_3499_; 
v_kind_3493_ = lean_ctor_get_uint8(v_val_3476_, sizeof(void*)*1);
lean_dec_ref(v_val_3476_);
v_name_3494_ = lean_ctor_get(v_toConstantVal_3480_, 0);
lean_inc(v_name_3494_);
v_levelParams_3495_ = lean_ctor_get(v_toConstantVal_3480_, 1);
lean_inc(v_levelParams_3495_);
v_type_3496_ = lean_ctor_get(v_toConstantVal_3480_, 2);
lean_inc_ref(v_type_3496_);
lean_dec_ref(v_toConstantVal_3480_);
lean_inc(v_head_3438_);
v___x_3497_ = l_Lean_NameHashSet_insert(v_visitedConstants_3484_, v_head_3438_);
if (v_isShared_3492_ == 0)
{
lean_ctor_set(v___x_3491_, 3, v___x_3497_);
v___x_3499_ = v___x_3491_;
goto v_reusejp_3498_;
}
else
{
lean_object* v_reuseFailAlloc_3592_; 
v_reuseFailAlloc_3592_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_3592_, 0, v_visitedNames_3481_);
lean_ctor_set(v_reuseFailAlloc_3592_, 1, v_visitedLevels_3482_);
lean_ctor_set(v_reuseFailAlloc_3592_, 2, v_visitedExprs_3483_);
lean_ctor_set(v_reuseFailAlloc_3592_, 3, v___x_3497_);
lean_ctor_set(v_reuseFailAlloc_3592_, 4, v_noMDataExprs_3485_);
lean_ctor_set(v_reuseFailAlloc_3592_, 5, v_recursorMap_3489_);
lean_ctor_set_uint8(v_reuseFailAlloc_3592_, sizeof(void*)*6, v_exportMData_3486_);
lean_ctor_set_uint8(v_reuseFailAlloc_3592_, sizeof(void*)*6 + 1, v_exportUnsafe_3487_);
lean_ctor_set_uint8(v_reuseFailAlloc_3592_, sizeof(void*)*6 + 2, v_ignoreMissing_3488_);
v___x_3499_ = v_reuseFailAlloc_3592_;
goto v_reusejp_3498_;
}
v_reusejp_3498_:
{
lean_object* v___x_3500_; 
v___x_3500_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_3494_, v___y_3433_, v___x_3499_);
if (lean_obj_tag(v___x_3500_) == 0)
{
lean_object* v_a_3501_; lean_object* v_fst_3502_; lean_object* v_snd_3503_; lean_object* v___x_3505_; uint8_t v_isShared_3506_; uint8_t v_isSharedCheck_3583_; 
v_a_3501_ = lean_ctor_get(v___x_3500_, 0);
lean_inc(v_a_3501_);
lean_dec_ref_known(v___x_3500_, 1);
v_fst_3502_ = lean_ctor_get(v_a_3501_, 0);
v_snd_3503_ = lean_ctor_get(v_a_3501_, 1);
v_isSharedCheck_3583_ = !lean_is_exclusive(v_a_3501_);
if (v_isSharedCheck_3583_ == 0)
{
v___x_3505_ = v_a_3501_;
v_isShared_3506_ = v_isSharedCheck_3583_;
goto v_resetjp_3504_;
}
else
{
lean_inc(v_snd_3503_);
lean_inc(v_fst_3502_);
lean_dec(v_a_3501_);
v___x_3505_ = lean_box(0);
v_isShared_3506_ = v_isSharedCheck_3583_;
goto v_resetjp_3504_;
}
v_resetjp_3504_:
{
lean_object* v___x_3507_; 
v___x_3507_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_3495_, v___y_3433_, v_snd_3503_);
if (lean_obj_tag(v___x_3507_) == 0)
{
lean_object* v_a_3508_; lean_object* v_fst_3509_; lean_object* v_snd_3510_; lean_object* v___x_3512_; uint8_t v_isShared_3513_; uint8_t v_isSharedCheck_3574_; 
v_a_3508_ = lean_ctor_get(v___x_3507_, 0);
lean_inc(v_a_3508_);
lean_dec_ref_known(v___x_3507_, 1);
v_fst_3509_ = lean_ctor_get(v_a_3508_, 0);
v_snd_3510_ = lean_ctor_get(v_a_3508_, 1);
v_isSharedCheck_3574_ = !lean_is_exclusive(v_a_3508_);
if (v_isSharedCheck_3574_ == 0)
{
v___x_3512_ = v_a_3508_;
v_isShared_3513_ = v_isSharedCheck_3574_;
goto v_resetjp_3511_;
}
else
{
lean_inc(v_snd_3510_);
lean_inc(v_fst_3509_);
lean_dec(v_a_3508_);
v___x_3512_ = lean_box(0);
v_isShared_3513_ = v_isSharedCheck_3574_;
goto v_resetjp_3511_;
}
v_resetjp_3511_:
{
lean_object* v___x_3514_; 
v___x_3514_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_3496_, v___y_3433_, v_snd_3510_);
if (lean_obj_tag(v___x_3514_) == 0)
{
lean_object* v_a_3515_; lean_object* v_fst_3516_; lean_object* v_snd_3517_; lean_object* v___x_3519_; uint8_t v_isShared_3520_; uint8_t v_isSharedCheck_3565_; 
v_a_3515_ = lean_ctor_get(v___x_3514_, 0);
lean_inc(v_a_3515_);
lean_dec_ref_known(v___x_3514_, 1);
v_fst_3516_ = lean_ctor_get(v_a_3515_, 0);
v_snd_3517_ = lean_ctor_get(v_a_3515_, 1);
v_isSharedCheck_3565_ = !lean_is_exclusive(v_a_3515_);
if (v_isSharedCheck_3565_ == 0)
{
v___x_3519_ = v_a_3515_;
v_isShared_3520_ = v_isSharedCheck_3565_;
goto v_resetjp_3518_;
}
else
{
lean_inc(v_snd_3517_);
lean_inc(v_fst_3516_);
lean_dec(v_a_3515_);
v___x_3519_ = lean_box(0);
v_isShared_3520_ = v_isSharedCheck_3565_;
goto v_resetjp_3518_;
}
v_resetjp_3518_:
{
lean_object* v___x_3521_; lean_object* v___x_3522_; lean_object* v___x_3523_; lean_object* v___x_3525_; 
v___x_3521_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__5));
v___x_3522_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_3523_ = l_Lean_JsonNumber_fromNat(v_fst_3502_);
if (v_isShared_3479_ == 0)
{
lean_ctor_set_tag(v___x_3478_, 2);
lean_ctor_set(v___x_3478_, 0, v___x_3523_);
v___x_3525_ = v___x_3478_;
goto v_reusejp_3524_;
}
else
{
lean_object* v_reuseFailAlloc_3564_; 
v_reuseFailAlloc_3564_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3564_, 0, v___x_3523_);
v___x_3525_ = v_reuseFailAlloc_3564_;
goto v_reusejp_3524_;
}
v_reusejp_3524_:
{
lean_object* v___x_3527_; 
if (v_isShared_3520_ == 0)
{
lean_ctor_set(v___x_3519_, 1, v___x_3525_);
lean_ctor_set(v___x_3519_, 0, v___x_3522_);
v___x_3527_ = v___x_3519_;
goto v_reusejp_3526_;
}
else
{
lean_object* v_reuseFailAlloc_3563_; 
v_reuseFailAlloc_3563_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3563_, 0, v___x_3522_);
lean_ctor_set(v_reuseFailAlloc_3563_, 1, v___x_3525_);
v___x_3527_ = v_reuseFailAlloc_3563_;
goto v_reusejp_3526_;
}
v_reusejp_3526_:
{
lean_object* v___x_3528_; lean_object* v___x_3530_; 
v___x_3528_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_3513_ == 0)
{
lean_ctor_set(v___x_3512_, 1, v_fst_3509_);
lean_ctor_set(v___x_3512_, 0, v___x_3528_);
v___x_3530_ = v___x_3512_;
goto v_reusejp_3529_;
}
else
{
lean_object* v_reuseFailAlloc_3562_; 
v_reuseFailAlloc_3562_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3562_, 0, v___x_3528_);
lean_ctor_set(v_reuseFailAlloc_3562_, 1, v_fst_3509_);
v___x_3530_ = v_reuseFailAlloc_3562_;
goto v_reusejp_3529_;
}
v_reusejp_3529_:
{
lean_object* v___x_3531_; lean_object* v___x_3532_; lean_object* v___x_3534_; 
v___x_3531_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_3532_ = l_Lean_JsonNumber_fromNat(v_fst_3516_);
if (v_isShared_3475_ == 0)
{
lean_ctor_set_tag(v___x_3474_, 2);
lean_ctor_set(v___x_3474_, 0, v___x_3532_);
v___x_3534_ = v___x_3474_;
goto v_reusejp_3533_;
}
else
{
lean_object* v_reuseFailAlloc_3561_; 
v_reuseFailAlloc_3561_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3561_, 0, v___x_3532_);
v___x_3534_ = v_reuseFailAlloc_3561_;
goto v_reusejp_3533_;
}
v_reusejp_3533_:
{
lean_object* v___x_3536_; 
if (v_isShared_3506_ == 0)
{
lean_ctor_set(v___x_3505_, 1, v___x_3534_);
lean_ctor_set(v___x_3505_, 0, v___x_3531_);
v___x_3536_ = v___x_3505_;
goto v_reusejp_3535_;
}
else
{
lean_object* v_reuseFailAlloc_3560_; 
v_reuseFailAlloc_3560_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3560_, 0, v___x_3531_);
lean_ctor_set(v_reuseFailAlloc_3560_, 1, v___x_3534_);
v___x_3536_ = v_reuseFailAlloc_3560_;
goto v_reusejp_3535_;
}
v_reusejp_3535_:
{
lean_object* v___x_3537_; lean_object* v___x_3538_; lean_object* v___x_3539_; lean_object* v___x_3540_; lean_object* v___x_3541_; lean_object* v___x_3542_; lean_object* v___x_3543_; lean_object* v___x_3544_; lean_object* v___x_3545_; lean_object* v___x_3546_; lean_object* v___x_3547_; lean_object* v___x_3548_; 
v___x_3537_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__6));
v___x_3538_ = lp_proofEnvironment_Lean_QuotKind_toJson(v_kind_3493_);
v___x_3539_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3539_, 0, v___x_3537_);
lean_ctor_set(v___x_3539_, 1, v___x_3538_);
v___x_3540_ = lean_box(0);
v___x_3541_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3541_, 0, v___x_3539_);
lean_ctor_set(v___x_3541_, 1, v___x_3540_);
v___x_3542_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3542_, 0, v___x_3536_);
lean_ctor_set(v___x_3542_, 1, v___x_3541_);
v___x_3543_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3543_, 0, v___x_3530_);
lean_ctor_set(v___x_3543_, 1, v___x_3542_);
v___x_3544_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3544_, 0, v___x_3527_);
lean_ctor_set(v___x_3544_, 1, v___x_3543_);
v___x_3545_ = l_Lean_Json_mkObj(v___x_3544_);
lean_dec_ref_known(v___x_3544_, 2);
v___x_3546_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3546_, 0, v___x_3521_);
lean_ctor_set(v___x_3546_, 1, v___x_3545_);
v___x_3547_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3547_, 0, v___x_3546_);
lean_ctor_set(v___x_3547_, 1, v___x_3540_);
v___x_3548_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v___x_3547_, v_snd_3517_);
lean_dec_ref_known(v___x_3547_, 2);
if (lean_obj_tag(v___x_3548_) == 0)
{
lean_object* v_a_3549_; lean_object* v_snd_3550_; 
v_a_3549_ = lean_ctor_get(v___x_3548_, 0);
lean_inc(v_a_3549_);
lean_dec_ref_known(v___x_3548_, 1);
v_snd_3550_ = lean_ctor_get(v_a_3549_, 1);
lean_inc(v_snd_3550_);
lean_dec(v_a_3549_);
v_as_x27_3431_ = v_tail_3439_;
v_b_3432_ = v___x_3440_;
v___y_3434_ = v_snd_3550_;
goto _start;
}
else
{
lean_object* v_a_3552_; lean_object* v___x_3554_; uint8_t v_isShared_3555_; uint8_t v_isSharedCheck_3559_; 
v_a_3552_ = lean_ctor_get(v___x_3548_, 0);
v_isSharedCheck_3559_ = !lean_is_exclusive(v___x_3548_);
if (v_isSharedCheck_3559_ == 0)
{
v___x_3554_ = v___x_3548_;
v_isShared_3555_ = v_isSharedCheck_3559_;
goto v_resetjp_3553_;
}
else
{
lean_inc(v_a_3552_);
lean_dec(v___x_3548_);
v___x_3554_ = lean_box(0);
v_isShared_3555_ = v_isSharedCheck_3559_;
goto v_resetjp_3553_;
}
v_resetjp_3553_:
{
lean_object* v___x_3557_; 
if (v_isShared_3555_ == 0)
{
v___x_3557_ = v___x_3554_;
goto v_reusejp_3556_;
}
else
{
lean_object* v_reuseFailAlloc_3558_; 
v_reuseFailAlloc_3558_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3558_, 0, v_a_3552_);
v___x_3557_ = v_reuseFailAlloc_3558_;
goto v_reusejp_3556_;
}
v_reusejp_3556_:
{
return v___x_3557_;
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_3566_; lean_object* v___x_3568_; uint8_t v_isShared_3569_; uint8_t v_isSharedCheck_3573_; 
lean_del_object(v___x_3512_);
lean_dec(v_fst_3509_);
lean_del_object(v___x_3505_);
lean_dec(v_fst_3502_);
lean_del_object(v___x_3478_);
lean_del_object(v___x_3474_);
v_a_3566_ = lean_ctor_get(v___x_3514_, 0);
v_isSharedCheck_3573_ = !lean_is_exclusive(v___x_3514_);
if (v_isSharedCheck_3573_ == 0)
{
v___x_3568_ = v___x_3514_;
v_isShared_3569_ = v_isSharedCheck_3573_;
goto v_resetjp_3567_;
}
else
{
lean_inc(v_a_3566_);
lean_dec(v___x_3514_);
v___x_3568_ = lean_box(0);
v_isShared_3569_ = v_isSharedCheck_3573_;
goto v_resetjp_3567_;
}
v_resetjp_3567_:
{
lean_object* v___x_3571_; 
if (v_isShared_3569_ == 0)
{
v___x_3571_ = v___x_3568_;
goto v_reusejp_3570_;
}
else
{
lean_object* v_reuseFailAlloc_3572_; 
v_reuseFailAlloc_3572_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3572_, 0, v_a_3566_);
v___x_3571_ = v_reuseFailAlloc_3572_;
goto v_reusejp_3570_;
}
v_reusejp_3570_:
{
return v___x_3571_;
}
}
}
}
}
else
{
lean_object* v_a_3575_; lean_object* v___x_3577_; uint8_t v_isShared_3578_; uint8_t v_isSharedCheck_3582_; 
lean_del_object(v___x_3505_);
lean_dec(v_fst_3502_);
lean_dec_ref(v_type_3496_);
lean_del_object(v___x_3478_);
lean_del_object(v___x_3474_);
v_a_3575_ = lean_ctor_get(v___x_3507_, 0);
v_isSharedCheck_3582_ = !lean_is_exclusive(v___x_3507_);
if (v_isSharedCheck_3582_ == 0)
{
v___x_3577_ = v___x_3507_;
v_isShared_3578_ = v_isSharedCheck_3582_;
goto v_resetjp_3576_;
}
else
{
lean_inc(v_a_3575_);
lean_dec(v___x_3507_);
v___x_3577_ = lean_box(0);
v_isShared_3578_ = v_isSharedCheck_3582_;
goto v_resetjp_3576_;
}
v_resetjp_3576_:
{
lean_object* v___x_3580_; 
if (v_isShared_3578_ == 0)
{
v___x_3580_ = v___x_3577_;
goto v_reusejp_3579_;
}
else
{
lean_object* v_reuseFailAlloc_3581_; 
v_reuseFailAlloc_3581_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3581_, 0, v_a_3575_);
v___x_3580_ = v_reuseFailAlloc_3581_;
goto v_reusejp_3579_;
}
v_reusejp_3579_:
{
return v___x_3580_;
}
}
}
}
}
else
{
lean_object* v_a_3584_; lean_object* v___x_3586_; uint8_t v_isShared_3587_; uint8_t v_isSharedCheck_3591_; 
lean_dec_ref(v_type_3496_);
lean_dec(v_levelParams_3495_);
lean_del_object(v___x_3478_);
lean_del_object(v___x_3474_);
v_a_3584_ = lean_ctor_get(v___x_3500_, 0);
v_isSharedCheck_3591_ = !lean_is_exclusive(v___x_3500_);
if (v_isSharedCheck_3591_ == 0)
{
v___x_3586_ = v___x_3500_;
v_isShared_3587_ = v_isSharedCheck_3591_;
goto v_resetjp_3585_;
}
else
{
lean_inc(v_a_3584_);
lean_dec(v___x_3500_);
v___x_3586_ = lean_box(0);
v_isShared_3587_ = v_isSharedCheck_3591_;
goto v_resetjp_3585_;
}
v_resetjp_3585_:
{
lean_object* v___x_3589_; 
if (v_isShared_3587_ == 0)
{
v___x_3589_ = v___x_3586_;
goto v_reusejp_3588_;
}
else
{
lean_object* v_reuseFailAlloc_3590_; 
v_reuseFailAlloc_3590_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3590_, 0, v_a_3584_);
v___x_3589_ = v_reuseFailAlloc_3590_;
goto v_reusejp_3588_;
}
v_reusejp_3588_:
{
return v___x_3589_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_3474_);
lean_dec(v_val_3472_);
v___y_3442_ = v___y_3433_;
v___y_3443_ = v___y_3434_;
goto v___jp_3441_;
}
}
}
else
{
lean_dec(v___x_3471_);
v___y_3442_ = v___y_3433_;
v___y_3443_ = v___y_3434_;
goto v___jp_3441_;
}
v___jp_3441_:
{
uint8_t v_ignoreMissing_3444_; 
v_ignoreMissing_3444_ = lean_ctor_get_uint8(v___y_3443_, sizeof(void*)*6 + 2);
if (v_ignoreMissing_3444_ == 0)
{
lean_object* v___x_3445_; lean_object* v___x_3446_; lean_object* v___x_3447_; lean_object* v___x_3448_; lean_object* v___x_3449_; uint8_t v___x_3450_; lean_object* v___x_3451_; lean_object* v___x_3452_; lean_object* v___x_3453_; lean_object* v___x_3454_; lean_object* v___x_3455_; lean_object* v___x_3456_; 
v___x_3445_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_3446_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_3447_ = lean_unsigned_to_nat(269u);
v___x_3448_ = lean_unsigned_to_nat(52u);
v___x_3449_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__1));
v___x_3450_ = 1;
lean_inc(v_head_3438_);
v___x_3451_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_3438_, v___x_3450_);
v___x_3452_ = lean_string_append(v___x_3449_, v___x_3451_);
lean_dec_ref(v___x_3451_);
v___x_3453_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__2));
v___x_3454_ = lean_string_append(v___x_3452_, v___x_3453_);
v___x_3455_ = l_mkPanicMessageWithDecl(v___x_3445_, v___x_3446_, v___x_3447_, v___x_3448_, v___x_3454_);
lean_dec_ref(v___x_3454_);
v___x_3456_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(v___x_3455_, v___y_3442_, v___y_3443_);
if (lean_obj_tag(v___x_3456_) == 0)
{
lean_object* v_a_3457_; lean_object* v_snd_3458_; 
v_a_3457_ = lean_ctor_get(v___x_3456_, 0);
lean_inc(v_a_3457_);
lean_dec_ref_known(v___x_3456_, 1);
v_snd_3458_ = lean_ctor_get(v_a_3457_, 1);
lean_inc(v_snd_3458_);
lean_dec(v_a_3457_);
v_as_x27_3431_ = v_tail_3439_;
v_b_3432_ = v___x_3440_;
v___y_3434_ = v_snd_3458_;
goto _start;
}
else
{
lean_object* v_a_3460_; lean_object* v___x_3462_; uint8_t v_isShared_3463_; uint8_t v_isSharedCheck_3467_; 
v_a_3460_ = lean_ctor_get(v___x_3456_, 0);
v_isSharedCheck_3467_ = !lean_is_exclusive(v___x_3456_);
if (v_isSharedCheck_3467_ == 0)
{
v___x_3462_ = v___x_3456_;
v_isShared_3463_ = v_isSharedCheck_3467_;
goto v_resetjp_3461_;
}
else
{
lean_inc(v_a_3460_);
lean_dec(v___x_3456_);
v___x_3462_ = lean_box(0);
v_isShared_3463_ = v_isSharedCheck_3467_;
goto v_resetjp_3461_;
}
v_resetjp_3461_:
{
lean_object* v___x_3465_; 
if (v_isShared_3463_ == 0)
{
v___x_3465_ = v___x_3462_;
goto v_reusejp_3464_;
}
else
{
lean_object* v_reuseFailAlloc_3466_; 
v_reuseFailAlloc_3466_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3466_, 0, v_a_3460_);
v___x_3465_ = v_reuseFailAlloc_3466_;
goto v_reusejp_3464_;
}
v_reusejp_3464_:
{
return v___x_3465_;
}
}
}
}
else
{
lean_object* v___x_3468_; lean_object* v___x_3469_; lean_object* v___x_3470_; 
v___x_3468_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__4));
v___x_3469_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3469_, 0, v___x_3468_);
lean_ctor_set(v___x_3469_, 1, v___y_3443_);
v___x_3470_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3470_, 0, v___x_3469_);
return v___x_3470_;
}
}
}
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__2(void){
_start:
{
lean_object* v___x_3606_; lean_object* v___x_3607_; lean_object* v___x_3608_; lean_object* v___x_3609_; lean_object* v___x_3610_; lean_object* v___x_3611_; 
v___x_3606_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__1));
v___x_3607_ = lean_unsigned_to_nat(11u);
v___x_3608_ = lean_unsigned_to_nat(297u);
v___x_3609_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_3610_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_3611_ = l_mkPanicMessageWithDecl(v___x_3610_, v___x_3609_, v___x_3608_, v___x_3607_, v___x_3606_);
return v___x_3611_;
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__4(void){
_start:
{
lean_object* v___x_3613_; lean_object* v___x_3614_; lean_object* v___x_3615_; lean_object* v___x_3616_; lean_object* v___x_3617_; lean_object* v___x_3618_; 
v___x_3613_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__3));
v___x_3614_ = lean_unsigned_to_nat(6u);
v___x_3615_ = lean_unsigned_to_nat(285u);
v___x_3616_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_3617_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_3618_ = l_mkPanicMessageWithDecl(v___x_3617_, v___x_3616_, v___x_3615_, v___x_3614_, v___x_3613_);
return v___x_3618_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg(uint8_t v___x_3619_, lean_object* v_val_3620_, lean_object* v_as_x27_3621_, lean_object* v_b_3622_, lean_object* v___y_3623_, lean_object* v___y_3624_){
_start:
{
if (lean_obj_tag(v_as_x27_3621_) == 0)
{
lean_object* v___x_3626_; lean_object* v___x_3627_; 
v___x_3626_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3626_, 0, v_b_3622_);
lean_ctor_set(v___x_3626_, 1, v___y_3624_);
v___x_3627_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3627_, 0, v___x_3626_);
return v___x_3627_;
}
else
{
lean_object* v_head_3628_; lean_object* v_tail_3629_; lean_object* v___y_3631_; lean_object* v_snd_3662_; lean_object* v_fst_3663_; lean_object* v_fst_3664_; lean_object* v_snd_3665_; lean_object* v___y_3667_; uint8_t v___y_3668_; lean_object* v___y_3749_; lean_object* v___x_3756_; 
v_head_3628_ = lean_ctor_get(v_as_x27_3621_, 0);
v_tail_3629_ = lean_ctor_get(v_as_x27_3621_, 1);
v_snd_3662_ = lean_ctor_get(v_b_3622_, 1);
lean_inc(v_snd_3662_);
v_fst_3663_ = lean_ctor_get(v_b_3622_, 0);
lean_inc(v_fst_3663_);
lean_dec_ref(v_b_3622_);
v_fst_3664_ = lean_ctor_get(v_snd_3662_, 0);
lean_inc(v_fst_3664_);
v_snd_3665_ = lean_ctor_get(v_snd_3662_, 1);
lean_inc(v_snd_3665_);
lean_dec(v_snd_3662_);
lean_inc(v_head_3628_);
lean_inc_ref(v___y_3623_);
v___x_3756_ = lean_environment_find(v___y_3623_, v_head_3628_);
if (lean_obj_tag(v___x_3756_) == 0)
{
lean_object* v___x_3757_; lean_object* v___x_3758_; 
v___x_3757_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__8);
v___x_3758_ = l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(v___x_3757_);
v___y_3749_ = v___x_3758_;
goto v___jp_3748_;
}
else
{
lean_object* v_val_3759_; 
v_val_3759_ = lean_ctor_get(v___x_3756_, 0);
lean_inc(v_val_3759_);
lean_dec_ref_known(v___x_3756_, 1);
v___y_3749_ = v_val_3759_;
goto v___jp_3748_;
}
v___jp_3630_:
{
if (lean_obj_tag(v___y_3631_) == 0)
{
lean_object* v_a_3632_; lean_object* v___x_3634_; uint8_t v_isShared_3635_; uint8_t v_isSharedCheck_3653_; 
v_a_3632_ = lean_ctor_get(v___y_3631_, 0);
v_isSharedCheck_3653_ = !lean_is_exclusive(v___y_3631_);
if (v_isSharedCheck_3653_ == 0)
{
v___x_3634_ = v___y_3631_;
v_isShared_3635_ = v_isSharedCheck_3653_;
goto v_resetjp_3633_;
}
else
{
lean_inc(v_a_3632_);
lean_dec(v___y_3631_);
v___x_3634_ = lean_box(0);
v_isShared_3635_ = v_isSharedCheck_3653_;
goto v_resetjp_3633_;
}
v_resetjp_3633_:
{
lean_object* v_fst_3636_; 
v_fst_3636_ = lean_ctor_get(v_a_3632_, 0);
lean_inc(v_fst_3636_);
if (lean_obj_tag(v_fst_3636_) == 0)
{
lean_object* v_snd_3637_; lean_object* v___x_3639_; uint8_t v_isShared_3640_; uint8_t v_isSharedCheck_3648_; 
v_snd_3637_ = lean_ctor_get(v_a_3632_, 1);
v_isSharedCheck_3648_ = !lean_is_exclusive(v_a_3632_);
if (v_isSharedCheck_3648_ == 0)
{
lean_object* v_unused_3649_; 
v_unused_3649_ = lean_ctor_get(v_a_3632_, 0);
lean_dec(v_unused_3649_);
v___x_3639_ = v_a_3632_;
v_isShared_3640_ = v_isSharedCheck_3648_;
goto v_resetjp_3638_;
}
else
{
lean_inc(v_snd_3637_);
lean_dec(v_a_3632_);
v___x_3639_ = lean_box(0);
v_isShared_3640_ = v_isSharedCheck_3648_;
goto v_resetjp_3638_;
}
v_resetjp_3638_:
{
lean_object* v_a_3641_; lean_object* v___x_3643_; 
v_a_3641_ = lean_ctor_get(v_fst_3636_, 0);
lean_inc(v_a_3641_);
lean_dec_ref_known(v_fst_3636_, 1);
if (v_isShared_3640_ == 0)
{
lean_ctor_set(v___x_3639_, 0, v_a_3641_);
v___x_3643_ = v___x_3639_;
goto v_reusejp_3642_;
}
else
{
lean_object* v_reuseFailAlloc_3647_; 
v_reuseFailAlloc_3647_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3647_, 0, v_a_3641_);
lean_ctor_set(v_reuseFailAlloc_3647_, 1, v_snd_3637_);
v___x_3643_ = v_reuseFailAlloc_3647_;
goto v_reusejp_3642_;
}
v_reusejp_3642_:
{
lean_object* v___x_3645_; 
if (v_isShared_3635_ == 0)
{
lean_ctor_set(v___x_3634_, 0, v___x_3643_);
v___x_3645_ = v___x_3634_;
goto v_reusejp_3644_;
}
else
{
lean_object* v_reuseFailAlloc_3646_; 
v_reuseFailAlloc_3646_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3646_, 0, v___x_3643_);
v___x_3645_ = v_reuseFailAlloc_3646_;
goto v_reusejp_3644_;
}
v_reusejp_3644_:
{
return v___x_3645_;
}
}
}
}
else
{
lean_object* v_snd_3650_; lean_object* v_a_3651_; 
lean_del_object(v___x_3634_);
v_snd_3650_ = lean_ctor_get(v_a_3632_, 1);
lean_inc(v_snd_3650_);
lean_dec(v_a_3632_);
v_a_3651_ = lean_ctor_get(v_fst_3636_, 0);
lean_inc(v_a_3651_);
lean_dec_ref_known(v_fst_3636_, 1);
v_as_x27_3621_ = v_tail_3629_;
v_b_3622_ = v_a_3651_;
v___y_3624_ = v_snd_3650_;
goto _start;
}
}
}
else
{
lean_object* v_a_3654_; lean_object* v___x_3656_; uint8_t v_isShared_3657_; uint8_t v_isSharedCheck_3661_; 
v_a_3654_ = lean_ctor_get(v___y_3631_, 0);
v_isSharedCheck_3661_ = !lean_is_exclusive(v___y_3631_);
if (v_isSharedCheck_3661_ == 0)
{
v___x_3656_ = v___y_3631_;
v_isShared_3657_ = v_isSharedCheck_3661_;
goto v_resetjp_3655_;
}
else
{
lean_inc(v_a_3654_);
lean_dec(v___y_3631_);
v___x_3656_ = lean_box(0);
v_isShared_3657_ = v_isSharedCheck_3661_;
goto v_resetjp_3655_;
}
v_resetjp_3655_:
{
lean_object* v___x_3659_; 
if (v_isShared_3657_ == 0)
{
v___x_3659_ = v___x_3656_;
goto v_reusejp_3658_;
}
else
{
lean_object* v_reuseFailAlloc_3660_; 
v_reuseFailAlloc_3660_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3660_, 0, v_a_3654_);
v___x_3659_ = v_reuseFailAlloc_3660_;
goto v_reusejp_3658_;
}
v_reusejp_3658_:
{
return v___x_3659_;
}
}
}
}
v___jp_3666_:
{
lean_object* v_toConstantVal_3669_; lean_object* v_ctors_3670_; lean_object* v___x_3671_; 
v_toConstantVal_3669_ = lean_ctor_get(v___y_3667_, 0);
v_ctors_3670_ = lean_ctor_get(v___y_3667_, 4);
v___x_3671_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg(v___y_3668_, v___x_3619_, v_ctors_3670_, v_fst_3664_, v___y_3623_, v___y_3624_);
if (lean_obj_tag(v___x_3671_) == 0)
{
lean_object* v_a_3672_; lean_object* v_snd_3673_; lean_object* v_fst_3674_; lean_object* v___x_3676_; uint8_t v_isShared_3677_; uint8_t v_isSharedCheck_3739_; 
v_a_3672_ = lean_ctor_get(v___x_3671_, 0);
lean_inc(v_a_3672_);
lean_dec_ref_known(v___x_3671_, 1);
v_snd_3673_ = lean_ctor_get(v_a_3672_, 1);
v_fst_3674_ = lean_ctor_get(v_a_3672_, 0);
v_isSharedCheck_3739_ = !lean_is_exclusive(v_a_3672_);
if (v_isSharedCheck_3739_ == 0)
{
v___x_3676_ = v_a_3672_;
v_isShared_3677_ = v_isSharedCheck_3739_;
goto v_resetjp_3675_;
}
else
{
lean_inc(v_snd_3673_);
lean_inc(v_fst_3674_);
lean_dec(v_a_3672_);
v___x_3676_ = lean_box(0);
v_isShared_3677_ = v_isSharedCheck_3739_;
goto v_resetjp_3675_;
}
v_resetjp_3675_:
{
lean_object* v_visitedNames_3678_; lean_object* v_visitedLevels_3679_; lean_object* v_visitedExprs_3680_; lean_object* v_visitedConstants_3681_; lean_object* v_noMDataExprs_3682_; uint8_t v_exportMData_3683_; uint8_t v_exportUnsafe_3684_; uint8_t v_ignoreMissing_3685_; lean_object* v_recursorMap_3686_; lean_object* v___x_3688_; uint8_t v_isShared_3689_; uint8_t v_isSharedCheck_3738_; 
v_visitedNames_3678_ = lean_ctor_get(v_snd_3673_, 0);
v_visitedLevels_3679_ = lean_ctor_get(v_snd_3673_, 1);
v_visitedExprs_3680_ = lean_ctor_get(v_snd_3673_, 2);
v_visitedConstants_3681_ = lean_ctor_get(v_snd_3673_, 3);
v_noMDataExprs_3682_ = lean_ctor_get(v_snd_3673_, 4);
v_exportMData_3683_ = lean_ctor_get_uint8(v_snd_3673_, sizeof(void*)*6);
v_exportUnsafe_3684_ = lean_ctor_get_uint8(v_snd_3673_, sizeof(void*)*6 + 1);
v_ignoreMissing_3685_ = lean_ctor_get_uint8(v_snd_3673_, sizeof(void*)*6 + 2);
v_recursorMap_3686_ = lean_ctor_get(v_snd_3673_, 5);
v_isSharedCheck_3738_ = !lean_is_exclusive(v_snd_3673_);
if (v_isSharedCheck_3738_ == 0)
{
v___x_3688_ = v_snd_3673_;
v_isShared_3689_ = v_isSharedCheck_3738_;
goto v_resetjp_3687_;
}
else
{
lean_inc(v_recursorMap_3686_);
lean_inc(v_noMDataExprs_3682_);
lean_inc(v_visitedConstants_3681_);
lean_inc(v_visitedExprs_3680_);
lean_inc(v_visitedLevels_3679_);
lean_inc(v_visitedNames_3678_);
lean_dec(v_snd_3673_);
v___x_3688_ = lean_box(0);
v_isShared_3689_ = v_isSharedCheck_3738_;
goto v_resetjp_3687_;
}
v_resetjp_3687_:
{
lean_object* v_type_3690_; lean_object* v___x_3691_; lean_object* v___x_3693_; 
v_type_3690_ = lean_ctor_get(v_toConstantVal_3669_, 2);
lean_inc(v_head_3628_);
v___x_3691_ = l_Lean_NameHashSet_insert(v_visitedConstants_3681_, v_head_3628_);
if (v_isShared_3689_ == 0)
{
lean_ctor_set(v___x_3688_, 3, v___x_3691_);
v___x_3693_ = v___x_3688_;
goto v_reusejp_3692_;
}
else
{
lean_object* v_reuseFailAlloc_3737_; 
v_reuseFailAlloc_3737_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_3737_, 0, v_visitedNames_3678_);
lean_ctor_set(v_reuseFailAlloc_3737_, 1, v_visitedLevels_3679_);
lean_ctor_set(v_reuseFailAlloc_3737_, 2, v_visitedExprs_3680_);
lean_ctor_set(v_reuseFailAlloc_3737_, 3, v___x_3691_);
lean_ctor_set(v_reuseFailAlloc_3737_, 4, v_noMDataExprs_3682_);
lean_ctor_set(v_reuseFailAlloc_3737_, 5, v_recursorMap_3686_);
lean_ctor_set_uint8(v_reuseFailAlloc_3737_, sizeof(void*)*6, v_exportMData_3683_);
lean_ctor_set_uint8(v_reuseFailAlloc_3737_, sizeof(void*)*6 + 1, v_exportUnsafe_3684_);
lean_ctor_set_uint8(v_reuseFailAlloc_3737_, sizeof(void*)*6 + 2, v_ignoreMissing_3685_);
v___x_3693_ = v_reuseFailAlloc_3737_;
goto v_reusejp_3692_;
}
v_reusejp_3692_:
{
lean_object* v___x_3694_; 
lean_inc_ref(v_type_3690_);
v___x_3694_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_3690_, v___y_3623_, v___x_3693_);
if (lean_obj_tag(v___x_3694_) == 0)
{
lean_object* v_a_3695_; lean_object* v_snd_3696_; lean_object* v___x_3698_; uint8_t v_isShared_3699_; uint8_t v_isSharedCheck_3727_; 
v_a_3695_ = lean_ctor_get(v___x_3694_, 0);
lean_inc(v_a_3695_);
lean_dec_ref_known(v___x_3694_, 1);
v_snd_3696_ = lean_ctor_get(v_a_3695_, 1);
v_isSharedCheck_3727_ = !lean_is_exclusive(v_a_3695_);
if (v_isSharedCheck_3727_ == 0)
{
lean_object* v_unused_3728_; 
v_unused_3728_ = lean_ctor_get(v_a_3695_, 0);
lean_dec(v_unused_3728_);
v___x_3698_ = v_a_3695_;
v_isShared_3699_ = v_isSharedCheck_3727_;
goto v_resetjp_3697_;
}
else
{
lean_inc(v_snd_3696_);
lean_dec(v_a_3695_);
v___x_3698_ = lean_box(0);
v_isShared_3699_ = v_isSharedCheck_3727_;
goto v_resetjp_3697_;
}
v_resetjp_3697_:
{
lean_object* v_toConstantVal_3700_; lean_object* v_recursorMap_3701_; lean_object* v_name_3702_; lean_object* v___x_3703_; lean_object* v___x_3704_; 
v_toConstantVal_3700_ = lean_ctor_get(v_val_3620_, 0);
v_recursorMap_3701_ = lean_ctor_get(v_snd_3696_, 5);
v_name_3702_ = lean_ctor_get(v_toConstantVal_3700_, 0);
v___x_3703_ = lean_array_push(v_fst_3663_, v___y_3667_);
v___x_3704_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__10___redArg(v_recursorMap_3701_, v_name_3702_);
if (lean_obj_tag(v___x_3704_) == 1)
{
lean_object* v_val_3705_; lean_object* v___x_3706_; lean_object* v___x_3707_; lean_object* v___x_3709_; 
v_val_3705_ = lean_ctor_get(v___x_3704_, 0);
lean_inc(v_val_3705_);
lean_dec_ref_known(v___x_3704_, 1);
v___x_3706_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__0));
v___x_3707_ = l_Std_DTreeMap_Internal_Impl_union___at___00Std_DTreeMap_union_spec__0___redArg(v___x_3706_, v_snd_3665_, v_val_3705_);
if (v_isShared_3699_ == 0)
{
lean_ctor_set(v___x_3698_, 1, v___x_3707_);
lean_ctor_set(v___x_3698_, 0, v_fst_3674_);
v___x_3709_ = v___x_3698_;
goto v_reusejp_3708_;
}
else
{
lean_object* v_reuseFailAlloc_3714_; 
v_reuseFailAlloc_3714_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3714_, 0, v_fst_3674_);
lean_ctor_set(v_reuseFailAlloc_3714_, 1, v___x_3707_);
v___x_3709_ = v_reuseFailAlloc_3714_;
goto v_reusejp_3708_;
}
v_reusejp_3708_:
{
lean_object* v___x_3711_; 
if (v_isShared_3677_ == 0)
{
lean_ctor_set(v___x_3676_, 1, v___x_3709_);
lean_ctor_set(v___x_3676_, 0, v___x_3703_);
v___x_3711_ = v___x_3676_;
goto v_reusejp_3710_;
}
else
{
lean_object* v_reuseFailAlloc_3713_; 
v_reuseFailAlloc_3713_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3713_, 0, v___x_3703_);
lean_ctor_set(v_reuseFailAlloc_3713_, 1, v___x_3709_);
v___x_3711_ = v_reuseFailAlloc_3713_;
goto v_reusejp_3710_;
}
v_reusejp_3710_:
{
v_as_x27_3621_ = v_tail_3629_;
v_b_3622_ = v___x_3711_;
v___y_3624_ = v_snd_3696_;
goto _start;
}
}
}
else
{
lean_object* v___x_3715_; lean_object* v___x_3716_; uint8_t v___x_3717_; 
lean_dec(v___x_3704_);
v___x_3715_ = lean_array_get_size(v_fst_3674_);
v___x_3716_ = lean_unsigned_to_nat(0u);
v___x_3717_ = lean_nat_dec_eq(v___x_3715_, v___x_3716_);
if (v___x_3717_ == 0)
{
lean_object* v___x_3718_; lean_object* v___x_3719_; 
lean_dec_ref(v___x_3703_);
lean_del_object(v___x_3698_);
lean_del_object(v___x_3676_);
lean_dec(v_fst_3674_);
lean_dec(v_snd_3665_);
v___x_3718_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__2, &lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__2_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__2);
v___x_3719_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8(v___x_3718_, v___y_3623_, v_snd_3696_);
v___y_3631_ = v___x_3719_;
goto v___jp_3630_;
}
else
{
lean_object* v___x_3721_; 
if (v_isShared_3699_ == 0)
{
lean_ctor_set(v___x_3698_, 1, v_snd_3665_);
lean_ctor_set(v___x_3698_, 0, v_fst_3674_);
v___x_3721_ = v___x_3698_;
goto v_reusejp_3720_;
}
else
{
lean_object* v_reuseFailAlloc_3726_; 
v_reuseFailAlloc_3726_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3726_, 0, v_fst_3674_);
lean_ctor_set(v_reuseFailAlloc_3726_, 1, v_snd_3665_);
v___x_3721_ = v_reuseFailAlloc_3726_;
goto v_reusejp_3720_;
}
v_reusejp_3720_:
{
lean_object* v___x_3723_; 
if (v_isShared_3677_ == 0)
{
lean_ctor_set(v___x_3676_, 1, v___x_3721_);
lean_ctor_set(v___x_3676_, 0, v___x_3703_);
v___x_3723_ = v___x_3676_;
goto v_reusejp_3722_;
}
else
{
lean_object* v_reuseFailAlloc_3725_; 
v_reuseFailAlloc_3725_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3725_, 0, v___x_3703_);
lean_ctor_set(v_reuseFailAlloc_3725_, 1, v___x_3721_);
v___x_3723_ = v_reuseFailAlloc_3725_;
goto v_reusejp_3722_;
}
v_reusejp_3722_:
{
v_as_x27_3621_ = v_tail_3629_;
v_b_3622_ = v___x_3723_;
v___y_3624_ = v_snd_3696_;
goto _start;
}
}
}
}
}
}
else
{
lean_object* v_a_3729_; lean_object* v___x_3731_; uint8_t v_isShared_3732_; uint8_t v_isSharedCheck_3736_; 
lean_del_object(v___x_3676_);
lean_dec(v_fst_3674_);
lean_dec_ref(v___y_3667_);
lean_dec(v_snd_3665_);
lean_dec(v_fst_3663_);
v_a_3729_ = lean_ctor_get(v___x_3694_, 0);
v_isSharedCheck_3736_ = !lean_is_exclusive(v___x_3694_);
if (v_isSharedCheck_3736_ == 0)
{
v___x_3731_ = v___x_3694_;
v_isShared_3732_ = v_isSharedCheck_3736_;
goto v_resetjp_3730_;
}
else
{
lean_inc(v_a_3729_);
lean_dec(v___x_3694_);
v___x_3731_ = lean_box(0);
v_isShared_3732_ = v_isSharedCheck_3736_;
goto v_resetjp_3730_;
}
v_resetjp_3730_:
{
lean_object* v___x_3734_; 
if (v_isShared_3732_ == 0)
{
v___x_3734_ = v___x_3731_;
goto v_reusejp_3733_;
}
else
{
lean_object* v_reuseFailAlloc_3735_; 
v_reuseFailAlloc_3735_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3735_, 0, v_a_3729_);
v___x_3734_ = v_reuseFailAlloc_3735_;
goto v_reusejp_3733_;
}
v_reusejp_3733_:
{
return v___x_3734_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3740_; lean_object* v___x_3742_; uint8_t v_isShared_3743_; uint8_t v_isSharedCheck_3747_; 
lean_dec_ref(v___y_3667_);
lean_dec(v_snd_3665_);
lean_dec(v_fst_3663_);
v_a_3740_ = lean_ctor_get(v___x_3671_, 0);
v_isSharedCheck_3747_ = !lean_is_exclusive(v___x_3671_);
if (v_isSharedCheck_3747_ == 0)
{
v___x_3742_ = v___x_3671_;
v_isShared_3743_ = v_isSharedCheck_3747_;
goto v_resetjp_3741_;
}
else
{
lean_inc(v_a_3740_);
lean_dec(v___x_3671_);
v___x_3742_ = lean_box(0);
v_isShared_3743_ = v_isSharedCheck_3747_;
goto v_resetjp_3741_;
}
v_resetjp_3741_:
{
lean_object* v___x_3745_; 
if (v_isShared_3743_ == 0)
{
v___x_3745_ = v___x_3742_;
goto v_reusejp_3744_;
}
else
{
lean_object* v_reuseFailAlloc_3746_; 
v_reuseFailAlloc_3746_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3746_, 0, v_a_3740_);
v___x_3745_ = v_reuseFailAlloc_3746_;
goto v_reusejp_3744_;
}
v_reusejp_3744_:
{
return v___x_3745_;
}
}
}
}
v___jp_3748_:
{
lean_object* v___x_3750_; uint8_t v_isUnsafe_3751_; 
v___x_3750_ = l_Lean_ConstantInfo_inductiveVal_x21(v___y_3749_);
lean_dec_ref(v___y_3749_);
v_isUnsafe_3751_ = lean_ctor_get_uint8(v___x_3750_, sizeof(void*)*6 + 1);
if (v_isUnsafe_3751_ == 0)
{
uint8_t v___x_3752_; 
v___x_3752_ = 1;
v___y_3667_ = v___x_3750_;
v___y_3668_ = v___x_3752_;
goto v___jp_3666_;
}
else
{
if (v___x_3619_ == 0)
{
uint8_t v_exportUnsafe_3753_; 
v_exportUnsafe_3753_ = lean_ctor_get_uint8(v___y_3624_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_3753_ == 0)
{
lean_object* v___x_3754_; lean_object* v___x_3755_; 
lean_dec_ref(v___x_3750_);
lean_dec(v_snd_3665_);
lean_dec(v_fst_3664_);
lean_dec(v_fst_3663_);
v___x_3754_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__4, &lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__4_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___closed__4);
v___x_3755_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__8(v___x_3754_, v___y_3623_, v___y_3624_);
v___y_3631_ = v___x_3755_;
goto v___jp_3630_;
}
else
{
v___y_3667_ = v___x_3750_;
v___y_3668_ = v_exportUnsafe_3753_;
goto v___jp_3666_;
}
}
else
{
v___y_3667_ = v___x_3750_;
v___y_3668_ = v___x_3619_;
goto v___jp_3666_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__11(lean_object* v_as_3760_, size_t v_sz_3761_, size_t v_i_3762_, lean_object* v_b_3763_, lean_object* v___y_3764_, lean_object* v___y_3765_){
_start:
{
uint8_t v___x_3767_; 
v___x_3767_ = lean_usize_dec_lt(v_i_3762_, v_sz_3761_);
if (v___x_3767_ == 0)
{
lean_object* v___x_3768_; lean_object* v___x_3769_; 
v___x_3768_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3768_, 0, v_b_3763_);
lean_ctor_set(v___x_3768_, 1, v___y_3765_);
v___x_3769_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3769_, 0, v___x_3768_);
return v___x_3769_;
}
else
{
lean_object* v_visitedNames_3770_; lean_object* v_visitedLevels_3771_; lean_object* v_visitedExprs_3772_; lean_object* v_visitedConstants_3773_; lean_object* v_noMDataExprs_3774_; uint8_t v_exportMData_3775_; uint8_t v_exportUnsafe_3776_; uint8_t v_ignoreMissing_3777_; lean_object* v_recursorMap_3778_; lean_object* v___x_3780_; uint8_t v_isShared_3781_; uint8_t v_isSharedCheck_3797_; 
v_visitedNames_3770_ = lean_ctor_get(v___y_3765_, 0);
v_visitedLevels_3771_ = lean_ctor_get(v___y_3765_, 1);
v_visitedExprs_3772_ = lean_ctor_get(v___y_3765_, 2);
v_visitedConstants_3773_ = lean_ctor_get(v___y_3765_, 3);
v_noMDataExprs_3774_ = lean_ctor_get(v___y_3765_, 4);
v_exportMData_3775_ = lean_ctor_get_uint8(v___y_3765_, sizeof(void*)*6);
v_exportUnsafe_3776_ = lean_ctor_get_uint8(v___y_3765_, sizeof(void*)*6 + 1);
v_ignoreMissing_3777_ = lean_ctor_get_uint8(v___y_3765_, sizeof(void*)*6 + 2);
v_recursorMap_3778_ = lean_ctor_get(v___y_3765_, 5);
v_isSharedCheck_3797_ = !lean_is_exclusive(v___y_3765_);
if (v_isSharedCheck_3797_ == 0)
{
v___x_3780_ = v___y_3765_;
v_isShared_3781_ = v_isSharedCheck_3797_;
goto v_resetjp_3779_;
}
else
{
lean_inc(v_recursorMap_3778_);
lean_inc(v_noMDataExprs_3774_);
lean_inc(v_visitedConstants_3773_);
lean_inc(v_visitedExprs_3772_);
lean_inc(v_visitedLevels_3771_);
lean_inc(v_visitedNames_3770_);
lean_dec(v___y_3765_);
v___x_3780_ = lean_box(0);
v_isShared_3781_ = v_isSharedCheck_3797_;
goto v_resetjp_3779_;
}
v_resetjp_3779_:
{
lean_object* v_a_3782_; lean_object* v_toConstantVal_3783_; lean_object* v_name_3784_; lean_object* v_type_3785_; lean_object* v___x_3786_; lean_object* v___x_3788_; 
v_a_3782_ = lean_array_uget_borrowed(v_as_3760_, v_i_3762_);
v_toConstantVal_3783_ = lean_ctor_get(v_a_3782_, 0);
v_name_3784_ = lean_ctor_get(v_toConstantVal_3783_, 0);
v_type_3785_ = lean_ctor_get(v_toConstantVal_3783_, 2);
lean_inc(v_name_3784_);
v___x_3786_ = l_Lean_NameHashSet_insert(v_visitedConstants_3773_, v_name_3784_);
if (v_isShared_3781_ == 0)
{
lean_ctor_set(v___x_3780_, 3, v___x_3786_);
v___x_3788_ = v___x_3780_;
goto v_reusejp_3787_;
}
else
{
lean_object* v_reuseFailAlloc_3796_; 
v_reuseFailAlloc_3796_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_3796_, 0, v_visitedNames_3770_);
lean_ctor_set(v_reuseFailAlloc_3796_, 1, v_visitedLevels_3771_);
lean_ctor_set(v_reuseFailAlloc_3796_, 2, v_visitedExprs_3772_);
lean_ctor_set(v_reuseFailAlloc_3796_, 3, v___x_3786_);
lean_ctor_set(v_reuseFailAlloc_3796_, 4, v_noMDataExprs_3774_);
lean_ctor_set(v_reuseFailAlloc_3796_, 5, v_recursorMap_3778_);
lean_ctor_set_uint8(v_reuseFailAlloc_3796_, sizeof(void*)*6, v_exportMData_3775_);
lean_ctor_set_uint8(v_reuseFailAlloc_3796_, sizeof(void*)*6 + 1, v_exportUnsafe_3776_);
lean_ctor_set_uint8(v_reuseFailAlloc_3796_, sizeof(void*)*6 + 2, v_ignoreMissing_3777_);
v___x_3788_ = v_reuseFailAlloc_3796_;
goto v_reusejp_3787_;
}
v_reusejp_3787_:
{
lean_object* v___x_3789_; 
lean_inc_ref(v_type_3785_);
v___x_3789_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_3785_, v___y_3764_, v___x_3788_);
if (lean_obj_tag(v___x_3789_) == 0)
{
lean_object* v_a_3790_; lean_object* v_snd_3791_; lean_object* v___x_3792_; size_t v___x_3793_; size_t v___x_3794_; 
v_a_3790_ = lean_ctor_get(v___x_3789_, 0);
lean_inc(v_a_3790_);
lean_dec_ref_known(v___x_3789_, 1);
v_snd_3791_ = lean_ctor_get(v_a_3790_, 1);
lean_inc(v_snd_3791_);
lean_dec(v_a_3790_);
v___x_3792_ = lean_box(0);
v___x_3793_ = ((size_t)1ULL);
v___x_3794_ = lean_usize_add(v_i_3762_, v___x_3793_);
v_i_3762_ = v___x_3794_;
v_b_3763_ = v___x_3792_;
v___y_3765_ = v_snd_3791_;
goto _start;
}
else
{
return v___x_3789_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg(lean_object* v_as_x27_3798_, lean_object* v_b_3799_, lean_object* v___y_3800_, lean_object* v___y_3801_){
_start:
{
if (lean_obj_tag(v_as_x27_3798_) == 0)
{
lean_object* v___x_3803_; lean_object* v___x_3804_; 
v___x_3803_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3803_, 0, v_b_3799_);
lean_ctor_set(v___x_3803_, 1, v___y_3801_);
v___x_3804_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3804_, 0, v___x_3803_);
return v___x_3804_;
}
else
{
lean_object* v_head_3805_; lean_object* v_tail_3806_; lean_object* v___x_3807_; 
v_head_3805_ = lean_ctor_get(v_as_x27_3798_, 0);
v_tail_3806_ = lean_ctor_get(v_as_x27_3798_, 1);
lean_inc(v_head_3805_);
v___x_3807_ = lp_proofEnvironment_CheckedExport_dumpConstant(v_head_3805_, v___y_3800_, v___y_3801_);
if (lean_obj_tag(v___x_3807_) == 0)
{
lean_object* v_a_3808_; lean_object* v_snd_3809_; lean_object* v___x_3810_; 
v_a_3808_ = lean_ctor_get(v___x_3807_, 0);
lean_inc(v_a_3808_);
lean_dec_ref_known(v___x_3807_, 1);
v_snd_3809_ = lean_ctor_get(v_a_3808_, 1);
lean_inc(v_snd_3809_);
lean_dec(v_a_3808_);
v___x_3810_ = lean_box(0);
v_as_x27_3798_ = v_tail_3806_;
v_b_3799_ = v___x_3810_;
v___y_3801_ = v_snd_3809_;
goto _start;
}
else
{
return v___x_3807_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant(lean_object* v_c_3812_, lean_object* v_a_3813_, lean_object* v_a_3814_){
_start:
{
size_t v___y_3821_; lean_object* v___y_3822_; size_t v___y_3823_; lean_object* v___y_3824_; lean_object* v___y_3825_; lean_object* v_fst_3826_; lean_object* v_snd_3827_; lean_object* v___x_3922_; 
lean_inc(v_c_3812_);
lean_inc_ref(v_a_3813_);
v___x_3922_ = lean_environment_find(v_a_3813_, v_c_3812_);
if (lean_obj_tag(v___x_3922_) == 1)
{
lean_object* v_val_3923_; uint8_t v___y_4662_; uint8_t v___x_4663_; 
v_val_3923_ = lean_ctor_get(v___x_3922_, 0);
lean_inc(v_val_3923_);
lean_dec_ref_known(v___x_3922_, 1);
v___x_4663_ = l_Lean_ConstantInfo_isUnsafe(v_val_3923_);
if (v___x_4663_ == 0)
{
v___y_4662_ = v___x_4663_;
goto v___jp_4661_;
}
else
{
uint8_t v_exportUnsafe_4664_; 
v_exportUnsafe_4664_ = lean_ctor_get_uint8(v_a_3814_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_4664_ == 0)
{
v___y_4662_ = v___x_4663_;
goto v___jp_4661_;
}
else
{
goto v___jp_3924_;
}
}
v___jp_3924_:
{
lean_object* v_visitedNames_3925_; lean_object* v_visitedLevels_3926_; lean_object* v_visitedExprs_3927_; lean_object* v_visitedConstants_3928_; lean_object* v_noMDataExprs_3929_; uint8_t v_exportMData_3930_; uint8_t v_exportUnsafe_3931_; uint8_t v_ignoreMissing_3932_; lean_object* v_recursorMap_3933_; uint8_t v___x_3934_; 
v_visitedNames_3925_ = lean_ctor_get(v_a_3814_, 0);
v_visitedLevels_3926_ = lean_ctor_get(v_a_3814_, 1);
v_visitedExprs_3927_ = lean_ctor_get(v_a_3814_, 2);
v_visitedConstants_3928_ = lean_ctor_get(v_a_3814_, 3);
v_noMDataExprs_3929_ = lean_ctor_get(v_a_3814_, 4);
v_exportMData_3930_ = lean_ctor_get_uint8(v_a_3814_, sizeof(void*)*6);
v_exportUnsafe_3931_ = lean_ctor_get_uint8(v_a_3814_, sizeof(void*)*6 + 1);
v_ignoreMissing_3932_ = lean_ctor_get_uint8(v_a_3814_, sizeof(void*)*6 + 2);
v_recursorMap_3933_ = lean_ctor_get(v_a_3814_, 5);
v___x_3934_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_3928_, v_c_3812_);
if (v___x_3934_ == 0)
{
lean_object* v___x_3936_; uint8_t v_isShared_3937_; uint8_t v_isSharedCheck_4654_; 
lean_inc(v_recursorMap_3933_);
lean_inc_ref(v_noMDataExprs_3929_);
lean_inc_ref(v_visitedConstants_3928_);
lean_inc_ref(v_visitedExprs_3927_);
lean_inc_ref(v_visitedLevels_3926_);
lean_inc_ref(v_visitedNames_3925_);
v_isSharedCheck_4654_ = !lean_is_exclusive(v_a_3814_);
if (v_isSharedCheck_4654_ == 0)
{
lean_object* v_unused_4655_; lean_object* v_unused_4656_; lean_object* v_unused_4657_; lean_object* v_unused_4658_; lean_object* v_unused_4659_; lean_object* v_unused_4660_; 
v_unused_4655_ = lean_ctor_get(v_a_3814_, 5);
lean_dec(v_unused_4655_);
v_unused_4656_ = lean_ctor_get(v_a_3814_, 4);
lean_dec(v_unused_4656_);
v_unused_4657_ = lean_ctor_get(v_a_3814_, 3);
lean_dec(v_unused_4657_);
v_unused_4658_ = lean_ctor_get(v_a_3814_, 2);
lean_dec(v_unused_4658_);
v_unused_4659_ = lean_ctor_get(v_a_3814_, 1);
lean_dec(v_unused_4659_);
v_unused_4660_ = lean_ctor_get(v_a_3814_, 0);
lean_dec(v_unused_4660_);
v___x_3936_ = v_a_3814_;
v_isShared_3937_ = v_isSharedCheck_4654_;
goto v_resetjp_3935_;
}
else
{
lean_dec(v_a_3814_);
v___x_3936_ = lean_box(0);
v_isShared_3937_ = v_isSharedCheck_4654_;
goto v_resetjp_3935_;
}
v_resetjp_3935_:
{
lean_object* v___x_3938_; lean_object* v___x_3940_; 
v___x_3938_ = l_Lean_NameHashSet_insert(v_visitedConstants_3928_, v_c_3812_);
if (v_isShared_3937_ == 0)
{
lean_ctor_set(v___x_3936_, 3, v___x_3938_);
v___x_3940_ = v___x_3936_;
goto v_reusejp_3939_;
}
else
{
lean_object* v_reuseFailAlloc_4653_; 
v_reuseFailAlloc_4653_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_4653_, 0, v_visitedNames_3925_);
lean_ctor_set(v_reuseFailAlloc_4653_, 1, v_visitedLevels_3926_);
lean_ctor_set(v_reuseFailAlloc_4653_, 2, v_visitedExprs_3927_);
lean_ctor_set(v_reuseFailAlloc_4653_, 3, v___x_3938_);
lean_ctor_set(v_reuseFailAlloc_4653_, 4, v_noMDataExprs_3929_);
lean_ctor_set(v_reuseFailAlloc_4653_, 5, v_recursorMap_3933_);
lean_ctor_set_uint8(v_reuseFailAlloc_4653_, sizeof(void*)*6, v_exportMData_3930_);
lean_ctor_set_uint8(v_reuseFailAlloc_4653_, sizeof(void*)*6 + 1, v_exportUnsafe_3931_);
lean_ctor_set_uint8(v_reuseFailAlloc_4653_, sizeof(void*)*6 + 2, v_ignoreMissing_3932_);
v___x_3940_ = v_reuseFailAlloc_4653_;
goto v_reusejp_3939_;
}
v_reusejp_3939_:
{
switch(lean_obj_tag(v_val_3923_))
{
case 0:
{
lean_object* v_val_3941_; lean_object* v___x_3943_; uint8_t v_isShared_3944_; uint8_t v_isSharedCheck_4045_; 
v_val_3941_ = lean_ctor_get(v_val_3923_, 0);
v_isSharedCheck_4045_ = !lean_is_exclusive(v_val_3923_);
if (v_isSharedCheck_4045_ == 0)
{
v___x_3943_ = v_val_3923_;
v_isShared_3944_ = v_isSharedCheck_4045_;
goto v_resetjp_3942_;
}
else
{
lean_inc(v_val_3941_);
lean_dec(v_val_3923_);
v___x_3943_ = lean_box(0);
v_isShared_3944_ = v_isSharedCheck_4045_;
goto v_resetjp_3942_;
}
v_resetjp_3942_:
{
lean_object* v_toConstantVal_3945_; uint8_t v_isUnsafe_3946_; lean_object* v_name_3947_; lean_object* v_levelParams_3948_; lean_object* v_type_3949_; lean_object* v___x_3950_; 
v_toConstantVal_3945_ = lean_ctor_get(v_val_3941_, 0);
lean_inc_ref(v_toConstantVal_3945_);
v_isUnsafe_3946_ = lean_ctor_get_uint8(v_val_3941_, sizeof(void*)*1);
lean_dec_ref(v_val_3941_);
v_name_3947_ = lean_ctor_get(v_toConstantVal_3945_, 0);
lean_inc(v_name_3947_);
v_levelParams_3948_ = lean_ctor_get(v_toConstantVal_3945_, 1);
lean_inc(v_levelParams_3948_);
v_type_3949_ = lean_ctor_get(v_toConstantVal_3945_, 2);
lean_inc_ref_n(v_type_3949_, 2);
lean_dec_ref(v_toConstantVal_3945_);
v___x_3950_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_3949_, v_a_3813_, v___x_3940_);
if (lean_obj_tag(v___x_3950_) == 0)
{
lean_object* v_a_3951_; lean_object* v___x_3953_; uint8_t v_isShared_3954_; uint8_t v_isSharedCheck_4044_; 
v_a_3951_ = lean_ctor_get(v___x_3950_, 0);
v_isSharedCheck_4044_ = !lean_is_exclusive(v___x_3950_);
if (v_isSharedCheck_4044_ == 0)
{
v___x_3953_ = v___x_3950_;
v_isShared_3954_ = v_isSharedCheck_4044_;
goto v_resetjp_3952_;
}
else
{
lean_inc(v_a_3951_);
lean_dec(v___x_3950_);
v___x_3953_ = lean_box(0);
v_isShared_3954_ = v_isSharedCheck_4044_;
goto v_resetjp_3952_;
}
v_resetjp_3952_:
{
lean_object* v_snd_3955_; lean_object* v___x_3957_; uint8_t v_isShared_3958_; uint8_t v_isSharedCheck_4042_; 
v_snd_3955_ = lean_ctor_get(v_a_3951_, 1);
v_isSharedCheck_4042_ = !lean_is_exclusive(v_a_3951_);
if (v_isSharedCheck_4042_ == 0)
{
lean_object* v_unused_4043_; 
v_unused_4043_ = lean_ctor_get(v_a_3951_, 0);
lean_dec(v_unused_4043_);
v___x_3957_ = v_a_3951_;
v_isShared_3958_ = v_isSharedCheck_4042_;
goto v_resetjp_3956_;
}
else
{
lean_inc(v_snd_3955_);
lean_dec(v_a_3951_);
v___x_3957_ = lean_box(0);
v_isShared_3958_ = v_isSharedCheck_4042_;
goto v_resetjp_3956_;
}
v_resetjp_3956_:
{
lean_object* v___x_3959_; 
v___x_3959_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_3947_, v_a_3813_, v_snd_3955_);
if (lean_obj_tag(v___x_3959_) == 0)
{
lean_object* v_a_3960_; lean_object* v_fst_3961_; lean_object* v_snd_3962_; lean_object* v___x_3964_; uint8_t v_isShared_3965_; uint8_t v_isSharedCheck_4033_; 
v_a_3960_ = lean_ctor_get(v___x_3959_, 0);
lean_inc(v_a_3960_);
lean_dec_ref_known(v___x_3959_, 1);
v_fst_3961_ = lean_ctor_get(v_a_3960_, 0);
v_snd_3962_ = lean_ctor_get(v_a_3960_, 1);
v_isSharedCheck_4033_ = !lean_is_exclusive(v_a_3960_);
if (v_isSharedCheck_4033_ == 0)
{
v___x_3964_ = v_a_3960_;
v_isShared_3965_ = v_isSharedCheck_4033_;
goto v_resetjp_3963_;
}
else
{
lean_inc(v_snd_3962_);
lean_inc(v_fst_3961_);
lean_dec(v_a_3960_);
v___x_3964_ = lean_box(0);
v_isShared_3965_ = v_isSharedCheck_4033_;
goto v_resetjp_3963_;
}
v_resetjp_3963_:
{
lean_object* v___x_3966_; 
v___x_3966_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_3948_, v_a_3813_, v_snd_3962_);
if (lean_obj_tag(v___x_3966_) == 0)
{
lean_object* v_a_3967_; lean_object* v_fst_3968_; lean_object* v_snd_3969_; lean_object* v___x_3971_; uint8_t v_isShared_3972_; uint8_t v_isSharedCheck_4024_; 
v_a_3967_ = lean_ctor_get(v___x_3966_, 0);
lean_inc(v_a_3967_);
lean_dec_ref_known(v___x_3966_, 1);
v_fst_3968_ = lean_ctor_get(v_a_3967_, 0);
v_snd_3969_ = lean_ctor_get(v_a_3967_, 1);
v_isSharedCheck_4024_ = !lean_is_exclusive(v_a_3967_);
if (v_isSharedCheck_4024_ == 0)
{
v___x_3971_ = v_a_3967_;
v_isShared_3972_ = v_isSharedCheck_4024_;
goto v_resetjp_3970_;
}
else
{
lean_inc(v_snd_3969_);
lean_inc(v_fst_3968_);
lean_dec(v_a_3967_);
v___x_3971_ = lean_box(0);
v_isShared_3972_ = v_isSharedCheck_4024_;
goto v_resetjp_3970_;
}
v_resetjp_3970_:
{
lean_object* v___x_3973_; 
v___x_3973_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_3949_, v_a_3813_, v_snd_3969_);
if (lean_obj_tag(v___x_3973_) == 0)
{
lean_object* v_a_3974_; lean_object* v_fst_3975_; lean_object* v_snd_3976_; lean_object* v___x_3978_; uint8_t v_isShared_3979_; uint8_t v_isSharedCheck_4015_; 
v_a_3974_ = lean_ctor_get(v___x_3973_, 0);
lean_inc(v_a_3974_);
lean_dec_ref_known(v___x_3973_, 1);
v_fst_3975_ = lean_ctor_get(v_a_3974_, 0);
v_snd_3976_ = lean_ctor_get(v_a_3974_, 1);
v_isSharedCheck_4015_ = !lean_is_exclusive(v_a_3974_);
if (v_isSharedCheck_4015_ == 0)
{
v___x_3978_ = v_a_3974_;
v_isShared_3979_ = v_isSharedCheck_4015_;
goto v_resetjp_3977_;
}
else
{
lean_inc(v_snd_3976_);
lean_inc(v_fst_3975_);
lean_dec(v_a_3974_);
v___x_3978_ = lean_box(0);
v_isShared_3979_ = v_isSharedCheck_4015_;
goto v_resetjp_3977_;
}
v_resetjp_3977_:
{
lean_object* v___x_3980_; lean_object* v___x_3981_; lean_object* v___x_3982_; lean_object* v___x_3984_; 
v___x_3980_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__3));
v___x_3981_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_3982_ = l_Lean_JsonNumber_fromNat(v_fst_3961_);
if (v_isShared_3954_ == 0)
{
lean_ctor_set_tag(v___x_3953_, 2);
lean_ctor_set(v___x_3953_, 0, v___x_3982_);
v___x_3984_ = v___x_3953_;
goto v_reusejp_3983_;
}
else
{
lean_object* v_reuseFailAlloc_4014_; 
v_reuseFailAlloc_4014_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4014_, 0, v___x_3982_);
v___x_3984_ = v_reuseFailAlloc_4014_;
goto v_reusejp_3983_;
}
v_reusejp_3983_:
{
lean_object* v___x_3986_; 
if (v_isShared_3979_ == 0)
{
lean_ctor_set(v___x_3978_, 1, v___x_3984_);
lean_ctor_set(v___x_3978_, 0, v___x_3981_);
v___x_3986_ = v___x_3978_;
goto v_reusejp_3985_;
}
else
{
lean_object* v_reuseFailAlloc_4013_; 
v_reuseFailAlloc_4013_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4013_, 0, v___x_3981_);
lean_ctor_set(v_reuseFailAlloc_4013_, 1, v___x_3984_);
v___x_3986_ = v_reuseFailAlloc_4013_;
goto v_reusejp_3985_;
}
v_reusejp_3985_:
{
lean_object* v___x_3987_; lean_object* v___x_3989_; 
v___x_3987_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_3972_ == 0)
{
lean_ctor_set(v___x_3971_, 1, v_fst_3968_);
lean_ctor_set(v___x_3971_, 0, v___x_3987_);
v___x_3989_ = v___x_3971_;
goto v_reusejp_3988_;
}
else
{
lean_object* v_reuseFailAlloc_4012_; 
v_reuseFailAlloc_4012_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4012_, 0, v___x_3987_);
lean_ctor_set(v_reuseFailAlloc_4012_, 1, v_fst_3968_);
v___x_3989_ = v_reuseFailAlloc_4012_;
goto v_reusejp_3988_;
}
v_reusejp_3988_:
{
lean_object* v___x_3990_; lean_object* v___x_3991_; lean_object* v___x_3993_; 
v___x_3990_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_3991_ = l_Lean_JsonNumber_fromNat(v_fst_3975_);
if (v_isShared_3944_ == 0)
{
lean_ctor_set_tag(v___x_3943_, 2);
lean_ctor_set(v___x_3943_, 0, v___x_3991_);
v___x_3993_ = v___x_3943_;
goto v_reusejp_3992_;
}
else
{
lean_object* v_reuseFailAlloc_4011_; 
v_reuseFailAlloc_4011_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4011_, 0, v___x_3991_);
v___x_3993_ = v_reuseFailAlloc_4011_;
goto v_reusejp_3992_;
}
v_reusejp_3992_:
{
lean_object* v___x_3995_; 
if (v_isShared_3965_ == 0)
{
lean_ctor_set(v___x_3964_, 1, v___x_3993_);
lean_ctor_set(v___x_3964_, 0, v___x_3990_);
v___x_3995_ = v___x_3964_;
goto v_reusejp_3994_;
}
else
{
lean_object* v_reuseFailAlloc_4010_; 
v_reuseFailAlloc_4010_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4010_, 0, v___x_3990_);
lean_ctor_set(v_reuseFailAlloc_4010_, 1, v___x_3993_);
v___x_3995_ = v_reuseFailAlloc_4010_;
goto v_reusejp_3994_;
}
v_reusejp_3994_:
{
lean_object* v___x_3996_; lean_object* v___x_3997_; lean_object* v___x_3999_; 
v___x_3996_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7));
v___x_3997_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3997_, 0, v_isUnsafe_3946_);
if (v_isShared_3958_ == 0)
{
lean_ctor_set(v___x_3957_, 1, v___x_3997_);
lean_ctor_set(v___x_3957_, 0, v___x_3996_);
v___x_3999_ = v___x_3957_;
goto v_reusejp_3998_;
}
else
{
lean_object* v_reuseFailAlloc_4009_; 
v_reuseFailAlloc_4009_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4009_, 0, v___x_3996_);
lean_ctor_set(v_reuseFailAlloc_4009_, 1, v___x_3997_);
v___x_3999_ = v_reuseFailAlloc_4009_;
goto v_reusejp_3998_;
}
v_reusejp_3998_:
{
lean_object* v___x_4000_; lean_object* v___x_4001_; lean_object* v___x_4002_; lean_object* v___x_4003_; lean_object* v___x_4004_; lean_object* v___x_4005_; lean_object* v___x_4006_; lean_object* v___x_4007_; lean_object* v___x_4008_; 
v___x_4000_ = lean_box(0);
v___x_4001_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4001_, 0, v___x_3999_);
lean_ctor_set(v___x_4001_, 1, v___x_4000_);
v___x_4002_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4002_, 0, v___x_3995_);
lean_ctor_set(v___x_4002_, 1, v___x_4001_);
v___x_4003_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4003_, 0, v___x_3989_);
lean_ctor_set(v___x_4003_, 1, v___x_4002_);
v___x_4004_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4004_, 0, v___x_3986_);
lean_ctor_set(v___x_4004_, 1, v___x_4003_);
v___x_4005_ = l_Lean_Json_mkObj(v___x_4004_);
lean_dec_ref_known(v___x_4004_, 2);
v___x_4006_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4006_, 0, v___x_3980_);
lean_ctor_set(v___x_4006_, 1, v___x_4005_);
v___x_4007_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4007_, 0, v___x_4006_);
lean_ctor_set(v___x_4007_, 1, v___x_4000_);
v___x_4008_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v___x_4007_, v_snd_3976_);
lean_dec_ref_known(v___x_4007_, 2);
return v___x_4008_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4016_; lean_object* v___x_4018_; uint8_t v_isShared_4019_; uint8_t v_isSharedCheck_4023_; 
lean_del_object(v___x_3971_);
lean_dec(v_fst_3968_);
lean_del_object(v___x_3964_);
lean_dec(v_fst_3961_);
lean_del_object(v___x_3957_);
lean_del_object(v___x_3953_);
lean_del_object(v___x_3943_);
v_a_4016_ = lean_ctor_get(v___x_3973_, 0);
v_isSharedCheck_4023_ = !lean_is_exclusive(v___x_3973_);
if (v_isSharedCheck_4023_ == 0)
{
v___x_4018_ = v___x_3973_;
v_isShared_4019_ = v_isSharedCheck_4023_;
goto v_resetjp_4017_;
}
else
{
lean_inc(v_a_4016_);
lean_dec(v___x_3973_);
v___x_4018_ = lean_box(0);
v_isShared_4019_ = v_isSharedCheck_4023_;
goto v_resetjp_4017_;
}
v_resetjp_4017_:
{
lean_object* v___x_4021_; 
if (v_isShared_4019_ == 0)
{
v___x_4021_ = v___x_4018_;
goto v_reusejp_4020_;
}
else
{
lean_object* v_reuseFailAlloc_4022_; 
v_reuseFailAlloc_4022_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4022_, 0, v_a_4016_);
v___x_4021_ = v_reuseFailAlloc_4022_;
goto v_reusejp_4020_;
}
v_reusejp_4020_:
{
return v___x_4021_;
}
}
}
}
}
else
{
lean_object* v_a_4025_; lean_object* v___x_4027_; uint8_t v_isShared_4028_; uint8_t v_isSharedCheck_4032_; 
lean_del_object(v___x_3964_);
lean_dec(v_fst_3961_);
lean_del_object(v___x_3957_);
lean_del_object(v___x_3953_);
lean_dec_ref(v_type_3949_);
lean_del_object(v___x_3943_);
v_a_4025_ = lean_ctor_get(v___x_3966_, 0);
v_isSharedCheck_4032_ = !lean_is_exclusive(v___x_3966_);
if (v_isSharedCheck_4032_ == 0)
{
v___x_4027_ = v___x_3966_;
v_isShared_4028_ = v_isSharedCheck_4032_;
goto v_resetjp_4026_;
}
else
{
lean_inc(v_a_4025_);
lean_dec(v___x_3966_);
v___x_4027_ = lean_box(0);
v_isShared_4028_ = v_isSharedCheck_4032_;
goto v_resetjp_4026_;
}
v_resetjp_4026_:
{
lean_object* v___x_4030_; 
if (v_isShared_4028_ == 0)
{
v___x_4030_ = v___x_4027_;
goto v_reusejp_4029_;
}
else
{
lean_object* v_reuseFailAlloc_4031_; 
v_reuseFailAlloc_4031_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4031_, 0, v_a_4025_);
v___x_4030_ = v_reuseFailAlloc_4031_;
goto v_reusejp_4029_;
}
v_reusejp_4029_:
{
return v___x_4030_;
}
}
}
}
}
else
{
lean_object* v_a_4034_; lean_object* v___x_4036_; uint8_t v_isShared_4037_; uint8_t v_isSharedCheck_4041_; 
lean_del_object(v___x_3957_);
lean_del_object(v___x_3953_);
lean_dec_ref(v_type_3949_);
lean_dec(v_levelParams_3948_);
lean_del_object(v___x_3943_);
v_a_4034_ = lean_ctor_get(v___x_3959_, 0);
v_isSharedCheck_4041_ = !lean_is_exclusive(v___x_3959_);
if (v_isSharedCheck_4041_ == 0)
{
v___x_4036_ = v___x_3959_;
v_isShared_4037_ = v_isSharedCheck_4041_;
goto v_resetjp_4035_;
}
else
{
lean_inc(v_a_4034_);
lean_dec(v___x_3959_);
v___x_4036_ = lean_box(0);
v_isShared_4037_ = v_isSharedCheck_4041_;
goto v_resetjp_4035_;
}
v_resetjp_4035_:
{
lean_object* v___x_4039_; 
if (v_isShared_4037_ == 0)
{
v___x_4039_ = v___x_4036_;
goto v_reusejp_4038_;
}
else
{
lean_object* v_reuseFailAlloc_4040_; 
v_reuseFailAlloc_4040_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4040_, 0, v_a_4034_);
v___x_4039_ = v_reuseFailAlloc_4040_;
goto v_reusejp_4038_;
}
v_reusejp_4038_:
{
return v___x_4039_;
}
}
}
}
}
}
else
{
lean_dec_ref(v_type_3949_);
lean_dec(v_levelParams_3948_);
lean_dec(v_name_3947_);
lean_del_object(v___x_3943_);
return v___x_3950_;
}
}
}
case 1:
{
lean_object* v_val_4046_; lean_object* v___x_4048_; uint8_t v_isShared_4049_; uint8_t v_isSharedCheck_4217_; 
v_val_4046_ = lean_ctor_get(v_val_3923_, 0);
v_isSharedCheck_4217_ = !lean_is_exclusive(v_val_3923_);
if (v_isSharedCheck_4217_ == 0)
{
v___x_4048_ = v_val_3923_;
v_isShared_4049_ = v_isSharedCheck_4217_;
goto v_resetjp_4047_;
}
else
{
lean_inc(v_val_4046_);
lean_dec(v_val_3923_);
v___x_4048_ = lean_box(0);
v_isShared_4049_ = v_isSharedCheck_4217_;
goto v_resetjp_4047_;
}
v_resetjp_4047_:
{
lean_object* v_toConstantVal_4050_; lean_object* v_value_4051_; lean_object* v_hints_4052_; uint8_t v_safety_4053_; lean_object* v_all_4054_; lean_object* v_name_4055_; lean_object* v_levelParams_4056_; lean_object* v_type_4057_; lean_object* v___x_4058_; 
v_toConstantVal_4050_ = lean_ctor_get(v_val_4046_, 0);
lean_inc_ref(v_toConstantVal_4050_);
v_value_4051_ = lean_ctor_get(v_val_4046_, 1);
lean_inc_ref(v_value_4051_);
v_hints_4052_ = lean_ctor_get(v_val_4046_, 2);
lean_inc(v_hints_4052_);
v_safety_4053_ = lean_ctor_get_uint8(v_val_4046_, sizeof(void*)*4);
v_all_4054_ = lean_ctor_get(v_val_4046_, 3);
lean_inc(v_all_4054_);
lean_dec_ref(v_val_4046_);
v_name_4055_ = lean_ctor_get(v_toConstantVal_4050_, 0);
lean_inc(v_name_4055_);
v_levelParams_4056_ = lean_ctor_get(v_toConstantVal_4050_, 1);
lean_inc(v_levelParams_4056_);
v_type_4057_ = lean_ctor_get(v_toConstantVal_4050_, 2);
lean_inc_ref_n(v_type_4057_, 2);
lean_dec_ref(v_toConstantVal_4050_);
v___x_4058_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_4057_, v_a_3813_, v___x_3940_);
if (lean_obj_tag(v___x_4058_) == 0)
{
lean_object* v_a_4059_; lean_object* v___x_4061_; uint8_t v_isShared_4062_; uint8_t v_isSharedCheck_4216_; 
v_a_4059_ = lean_ctor_get(v___x_4058_, 0);
v_isSharedCheck_4216_ = !lean_is_exclusive(v___x_4058_);
if (v_isSharedCheck_4216_ == 0)
{
v___x_4061_ = v___x_4058_;
v_isShared_4062_ = v_isSharedCheck_4216_;
goto v_resetjp_4060_;
}
else
{
lean_inc(v_a_4059_);
lean_dec(v___x_4058_);
v___x_4061_ = lean_box(0);
v_isShared_4062_ = v_isSharedCheck_4216_;
goto v_resetjp_4060_;
}
v_resetjp_4060_:
{
lean_object* v_snd_4063_; lean_object* v___x_4065_; uint8_t v_isShared_4066_; uint8_t v_isSharedCheck_4214_; 
v_snd_4063_ = lean_ctor_get(v_a_4059_, 1);
v_isSharedCheck_4214_ = !lean_is_exclusive(v_a_4059_);
if (v_isSharedCheck_4214_ == 0)
{
lean_object* v_unused_4215_; 
v_unused_4215_ = lean_ctor_get(v_a_4059_, 0);
lean_dec(v_unused_4215_);
v___x_4065_ = v_a_4059_;
v_isShared_4066_ = v_isSharedCheck_4214_;
goto v_resetjp_4064_;
}
else
{
lean_inc(v_snd_4063_);
lean_dec(v_a_4059_);
v___x_4065_ = lean_box(0);
v_isShared_4066_ = v_isSharedCheck_4214_;
goto v_resetjp_4064_;
}
v_resetjp_4064_:
{
lean_object* v___x_4067_; 
lean_inc_ref(v_value_4051_);
v___x_4067_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_value_4051_, v_a_3813_, v_snd_4063_);
if (lean_obj_tag(v___x_4067_) == 0)
{
lean_object* v_a_4068_; lean_object* v___x_4070_; uint8_t v_isShared_4071_; uint8_t v_isSharedCheck_4213_; 
v_a_4068_ = lean_ctor_get(v___x_4067_, 0);
v_isSharedCheck_4213_ = !lean_is_exclusive(v___x_4067_);
if (v_isSharedCheck_4213_ == 0)
{
v___x_4070_ = v___x_4067_;
v_isShared_4071_ = v_isSharedCheck_4213_;
goto v_resetjp_4069_;
}
else
{
lean_inc(v_a_4068_);
lean_dec(v___x_4067_);
v___x_4070_ = lean_box(0);
v_isShared_4071_ = v_isSharedCheck_4213_;
goto v_resetjp_4069_;
}
v_resetjp_4069_:
{
lean_object* v_snd_4072_; lean_object* v___x_4074_; uint8_t v_isShared_4075_; uint8_t v_isSharedCheck_4211_; 
v_snd_4072_ = lean_ctor_get(v_a_4068_, 1);
v_isSharedCheck_4211_ = !lean_is_exclusive(v_a_4068_);
if (v_isSharedCheck_4211_ == 0)
{
lean_object* v_unused_4212_; 
v_unused_4212_ = lean_ctor_get(v_a_4068_, 0);
lean_dec(v_unused_4212_);
v___x_4074_ = v_a_4068_;
v_isShared_4075_ = v_isSharedCheck_4211_;
goto v_resetjp_4073_;
}
else
{
lean_inc(v_snd_4072_);
lean_dec(v_a_4068_);
v___x_4074_ = lean_box(0);
v_isShared_4075_ = v_isSharedCheck_4211_;
goto v_resetjp_4073_;
}
v_resetjp_4073_:
{
lean_object* v___x_4076_; 
v___x_4076_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_4055_, v_a_3813_, v_snd_4072_);
if (lean_obj_tag(v___x_4076_) == 0)
{
lean_object* v_a_4077_; lean_object* v_fst_4078_; lean_object* v_snd_4079_; lean_object* v___x_4081_; uint8_t v_isShared_4082_; uint8_t v_isSharedCheck_4202_; 
v_a_4077_ = lean_ctor_get(v___x_4076_, 0);
lean_inc(v_a_4077_);
lean_dec_ref_known(v___x_4076_, 1);
v_fst_4078_ = lean_ctor_get(v_a_4077_, 0);
v_snd_4079_ = lean_ctor_get(v_a_4077_, 1);
v_isSharedCheck_4202_ = !lean_is_exclusive(v_a_4077_);
if (v_isSharedCheck_4202_ == 0)
{
v___x_4081_ = v_a_4077_;
v_isShared_4082_ = v_isSharedCheck_4202_;
goto v_resetjp_4080_;
}
else
{
lean_inc(v_snd_4079_);
lean_inc(v_fst_4078_);
lean_dec(v_a_4077_);
v___x_4081_ = lean_box(0);
v_isShared_4082_ = v_isSharedCheck_4202_;
goto v_resetjp_4080_;
}
v_resetjp_4080_:
{
lean_object* v___x_4083_; 
v___x_4083_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_4056_, v_a_3813_, v_snd_4079_);
if (lean_obj_tag(v___x_4083_) == 0)
{
lean_object* v_a_4084_; lean_object* v_fst_4085_; lean_object* v_snd_4086_; lean_object* v___x_4088_; uint8_t v_isShared_4089_; uint8_t v_isSharedCheck_4193_; 
v_a_4084_ = lean_ctor_get(v___x_4083_, 0);
lean_inc(v_a_4084_);
lean_dec_ref_known(v___x_4083_, 1);
v_fst_4085_ = lean_ctor_get(v_a_4084_, 0);
v_snd_4086_ = lean_ctor_get(v_a_4084_, 1);
v_isSharedCheck_4193_ = !lean_is_exclusive(v_a_4084_);
if (v_isSharedCheck_4193_ == 0)
{
v___x_4088_ = v_a_4084_;
v_isShared_4089_ = v_isSharedCheck_4193_;
goto v_resetjp_4087_;
}
else
{
lean_inc(v_snd_4086_);
lean_inc(v_fst_4085_);
lean_dec(v_a_4084_);
v___x_4088_ = lean_box(0);
v_isShared_4089_ = v_isSharedCheck_4193_;
goto v_resetjp_4087_;
}
v_resetjp_4087_:
{
lean_object* v___x_4090_; 
v___x_4090_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_4057_, v_a_3813_, v_snd_4086_);
if (lean_obj_tag(v___x_4090_) == 0)
{
lean_object* v_a_4091_; lean_object* v_fst_4092_; lean_object* v_snd_4093_; lean_object* v___x_4095_; uint8_t v_isShared_4096_; uint8_t v_isSharedCheck_4184_; 
v_a_4091_ = lean_ctor_get(v___x_4090_, 0);
lean_inc(v_a_4091_);
lean_dec_ref_known(v___x_4090_, 1);
v_fst_4092_ = lean_ctor_get(v_a_4091_, 0);
v_snd_4093_ = lean_ctor_get(v_a_4091_, 1);
v_isSharedCheck_4184_ = !lean_is_exclusive(v_a_4091_);
if (v_isSharedCheck_4184_ == 0)
{
v___x_4095_ = v_a_4091_;
v_isShared_4096_ = v_isSharedCheck_4184_;
goto v_resetjp_4094_;
}
else
{
lean_inc(v_snd_4093_);
lean_inc(v_fst_4092_);
lean_dec(v_a_4091_);
v___x_4095_ = lean_box(0);
v_isShared_4096_ = v_isSharedCheck_4184_;
goto v_resetjp_4094_;
}
v_resetjp_4094_:
{
lean_object* v___x_4097_; 
v___x_4097_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_value_4051_, v_a_3813_, v_snd_4093_);
if (lean_obj_tag(v___x_4097_) == 0)
{
lean_object* v_a_4098_; lean_object* v_fst_4099_; lean_object* v_snd_4100_; lean_object* v___x_4102_; uint8_t v_isShared_4103_; uint8_t v_isSharedCheck_4175_; 
v_a_4098_ = lean_ctor_get(v___x_4097_, 0);
lean_inc(v_a_4098_);
lean_dec_ref_known(v___x_4097_, 1);
v_fst_4099_ = lean_ctor_get(v_a_4098_, 0);
v_snd_4100_ = lean_ctor_get(v_a_4098_, 1);
v_isSharedCheck_4175_ = !lean_is_exclusive(v_a_4098_);
if (v_isSharedCheck_4175_ == 0)
{
v___x_4102_ = v_a_4098_;
v_isShared_4103_ = v_isSharedCheck_4175_;
goto v_resetjp_4101_;
}
else
{
lean_inc(v_snd_4100_);
lean_inc(v_fst_4099_);
lean_dec(v_a_4098_);
v___x_4102_ = lean_box(0);
v_isShared_4103_ = v_isSharedCheck_4175_;
goto v_resetjp_4101_;
}
v_resetjp_4101_:
{
lean_object* v___x_4104_; 
v___x_4104_ = lp_proofEnvironment_CheckedExport_dumpNames(v_all_4054_, v_a_3813_, v_snd_4100_);
if (lean_obj_tag(v___x_4104_) == 0)
{
lean_object* v_a_4105_; lean_object* v_fst_4106_; lean_object* v_snd_4107_; lean_object* v___x_4109_; uint8_t v_isShared_4110_; uint8_t v_isSharedCheck_4166_; 
v_a_4105_ = lean_ctor_get(v___x_4104_, 0);
lean_inc(v_a_4105_);
lean_dec_ref_known(v___x_4104_, 1);
v_fst_4106_ = lean_ctor_get(v_a_4105_, 0);
v_snd_4107_ = lean_ctor_get(v_a_4105_, 1);
v_isSharedCheck_4166_ = !lean_is_exclusive(v_a_4105_);
if (v_isSharedCheck_4166_ == 0)
{
v___x_4109_ = v_a_4105_;
v_isShared_4110_ = v_isSharedCheck_4166_;
goto v_resetjp_4108_;
}
else
{
lean_inc(v_snd_4107_);
lean_inc(v_fst_4106_);
lean_dec(v_a_4105_);
v___x_4109_ = lean_box(0);
v_isShared_4110_ = v_isSharedCheck_4166_;
goto v_resetjp_4108_;
}
v_resetjp_4108_:
{
lean_object* v___x_4111_; lean_object* v___x_4112_; lean_object* v___x_4113_; lean_object* v___x_4115_; 
v___x_4111_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__4));
v___x_4112_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_4113_ = l_Lean_JsonNumber_fromNat(v_fst_4078_);
if (v_isShared_4071_ == 0)
{
lean_ctor_set_tag(v___x_4070_, 2);
lean_ctor_set(v___x_4070_, 0, v___x_4113_);
v___x_4115_ = v___x_4070_;
goto v_reusejp_4114_;
}
else
{
lean_object* v_reuseFailAlloc_4165_; 
v_reuseFailAlloc_4165_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4165_, 0, v___x_4113_);
v___x_4115_ = v_reuseFailAlloc_4165_;
goto v_reusejp_4114_;
}
v_reusejp_4114_:
{
lean_object* v___x_4117_; 
if (v_isShared_4110_ == 0)
{
lean_ctor_set(v___x_4109_, 1, v___x_4115_);
lean_ctor_set(v___x_4109_, 0, v___x_4112_);
v___x_4117_ = v___x_4109_;
goto v_reusejp_4116_;
}
else
{
lean_object* v_reuseFailAlloc_4164_; 
v_reuseFailAlloc_4164_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4164_, 0, v___x_4112_);
lean_ctor_set(v_reuseFailAlloc_4164_, 1, v___x_4115_);
v___x_4117_ = v_reuseFailAlloc_4164_;
goto v_reusejp_4116_;
}
v_reusejp_4116_:
{
lean_object* v___x_4118_; lean_object* v___x_4120_; 
v___x_4118_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_4103_ == 0)
{
lean_ctor_set(v___x_4102_, 1, v_fst_4085_);
lean_ctor_set(v___x_4102_, 0, v___x_4118_);
v___x_4120_ = v___x_4102_;
goto v_reusejp_4119_;
}
else
{
lean_object* v_reuseFailAlloc_4163_; 
v_reuseFailAlloc_4163_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4163_, 0, v___x_4118_);
lean_ctor_set(v_reuseFailAlloc_4163_, 1, v_fst_4085_);
v___x_4120_ = v_reuseFailAlloc_4163_;
goto v_reusejp_4119_;
}
v_reusejp_4119_:
{
lean_object* v___x_4121_; lean_object* v___x_4122_; lean_object* v___x_4124_; 
v___x_4121_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_4122_ = l_Lean_JsonNumber_fromNat(v_fst_4092_);
if (v_isShared_4062_ == 0)
{
lean_ctor_set_tag(v___x_4061_, 2);
lean_ctor_set(v___x_4061_, 0, v___x_4122_);
v___x_4124_ = v___x_4061_;
goto v_reusejp_4123_;
}
else
{
lean_object* v_reuseFailAlloc_4162_; 
v_reuseFailAlloc_4162_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4162_, 0, v___x_4122_);
v___x_4124_ = v_reuseFailAlloc_4162_;
goto v_reusejp_4123_;
}
v_reusejp_4123_:
{
lean_object* v___x_4126_; 
if (v_isShared_4096_ == 0)
{
lean_ctor_set(v___x_4095_, 1, v___x_4124_);
lean_ctor_set(v___x_4095_, 0, v___x_4121_);
v___x_4126_ = v___x_4095_;
goto v_reusejp_4125_;
}
else
{
lean_object* v_reuseFailAlloc_4161_; 
v_reuseFailAlloc_4161_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4161_, 0, v___x_4121_);
lean_ctor_set(v_reuseFailAlloc_4161_, 1, v___x_4124_);
v___x_4126_ = v_reuseFailAlloc_4161_;
goto v_reusejp_4125_;
}
v_reusejp_4125_:
{
lean_object* v___x_4127_; lean_object* v___x_4128_; lean_object* v___x_4130_; 
v___x_4127_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13));
v___x_4128_ = l_Lean_JsonNumber_fromNat(v_fst_4099_);
if (v_isShared_4049_ == 0)
{
lean_ctor_set_tag(v___x_4048_, 2);
lean_ctor_set(v___x_4048_, 0, v___x_4128_);
v___x_4130_ = v___x_4048_;
goto v_reusejp_4129_;
}
else
{
lean_object* v_reuseFailAlloc_4160_; 
v_reuseFailAlloc_4160_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4160_, 0, v___x_4128_);
v___x_4130_ = v_reuseFailAlloc_4160_;
goto v_reusejp_4129_;
}
v_reusejp_4129_:
{
lean_object* v___x_4132_; 
if (v_isShared_4089_ == 0)
{
lean_ctor_set(v___x_4088_, 1, v___x_4130_);
lean_ctor_set(v___x_4088_, 0, v___x_4127_);
v___x_4132_ = v___x_4088_;
goto v_reusejp_4131_;
}
else
{
lean_object* v_reuseFailAlloc_4159_; 
v_reuseFailAlloc_4159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4159_, 0, v___x_4127_);
lean_ctor_set(v_reuseFailAlloc_4159_, 1, v___x_4130_);
v___x_4132_ = v_reuseFailAlloc_4159_;
goto v_reusejp_4131_;
}
v_reusejp_4131_:
{
lean_object* v___x_4133_; lean_object* v___x_4134_; lean_object* v___x_4136_; 
v___x_4133_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__5));
v___x_4134_ = lp_proofEnvironment_Lean_ReducibilityHints_toJson(v_hints_4052_);
lean_dec(v_hints_4052_);
if (v_isShared_4082_ == 0)
{
lean_ctor_set(v___x_4081_, 1, v___x_4134_);
lean_ctor_set(v___x_4081_, 0, v___x_4133_);
v___x_4136_ = v___x_4081_;
goto v_reusejp_4135_;
}
else
{
lean_object* v_reuseFailAlloc_4158_; 
v_reuseFailAlloc_4158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4158_, 0, v___x_4133_);
lean_ctor_set(v_reuseFailAlloc_4158_, 1, v___x_4134_);
v___x_4136_ = v_reuseFailAlloc_4158_;
goto v_reusejp_4135_;
}
v_reusejp_4135_:
{
lean_object* v___x_4137_; lean_object* v___x_4138_; lean_object* v___x_4140_; 
v___x_4137_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__6));
v___x_4138_ = lp_proofEnvironment_Lean_DefinitionSafety_toJson(v_safety_4053_);
if (v_isShared_4075_ == 0)
{
lean_ctor_set(v___x_4074_, 1, v___x_4138_);
lean_ctor_set(v___x_4074_, 0, v___x_4137_);
v___x_4140_ = v___x_4074_;
goto v_reusejp_4139_;
}
else
{
lean_object* v_reuseFailAlloc_4157_; 
v_reuseFailAlloc_4157_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4157_, 0, v___x_4137_);
lean_ctor_set(v_reuseFailAlloc_4157_, 1, v___x_4138_);
v___x_4140_ = v_reuseFailAlloc_4157_;
goto v_reusejp_4139_;
}
v_reusejp_4139_:
{
lean_object* v___x_4141_; lean_object* v___x_4143_; 
v___x_4141_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1));
if (v_isShared_4066_ == 0)
{
lean_ctor_set(v___x_4065_, 1, v_fst_4106_);
lean_ctor_set(v___x_4065_, 0, v___x_4141_);
v___x_4143_ = v___x_4065_;
goto v_reusejp_4142_;
}
else
{
lean_object* v_reuseFailAlloc_4156_; 
v_reuseFailAlloc_4156_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4156_, 0, v___x_4141_);
lean_ctor_set(v_reuseFailAlloc_4156_, 1, v_fst_4106_);
v___x_4143_ = v_reuseFailAlloc_4156_;
goto v_reusejp_4142_;
}
v_reusejp_4142_:
{
lean_object* v___x_4144_; lean_object* v___x_4145_; lean_object* v___x_4146_; lean_object* v___x_4147_; lean_object* v___x_4148_; lean_object* v___x_4149_; lean_object* v___x_4150_; lean_object* v___x_4151_; lean_object* v___x_4152_; lean_object* v___x_4153_; lean_object* v___x_4154_; lean_object* v___x_4155_; 
v___x_4144_ = lean_box(0);
v___x_4145_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4145_, 0, v___x_4143_);
lean_ctor_set(v___x_4145_, 1, v___x_4144_);
v___x_4146_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4146_, 0, v___x_4140_);
lean_ctor_set(v___x_4146_, 1, v___x_4145_);
v___x_4147_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4147_, 0, v___x_4136_);
lean_ctor_set(v___x_4147_, 1, v___x_4146_);
v___x_4148_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4148_, 0, v___x_4132_);
lean_ctor_set(v___x_4148_, 1, v___x_4147_);
v___x_4149_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4149_, 0, v___x_4126_);
lean_ctor_set(v___x_4149_, 1, v___x_4148_);
v___x_4150_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4150_, 0, v___x_4120_);
lean_ctor_set(v___x_4150_, 1, v___x_4149_);
v___x_4151_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4151_, 0, v___x_4117_);
lean_ctor_set(v___x_4151_, 1, v___x_4150_);
v___x_4152_ = l_Lean_Json_mkObj(v___x_4151_);
lean_dec_ref_known(v___x_4151_, 2);
v___x_4153_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4153_, 0, v___x_4111_);
lean_ctor_set(v___x_4153_, 1, v___x_4152_);
v___x_4154_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4154_, 0, v___x_4153_);
lean_ctor_set(v___x_4154_, 1, v___x_4144_);
v___x_4155_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v___x_4154_, v_snd_4107_);
lean_dec_ref_known(v___x_4154_, 2);
return v___x_4155_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4167_; lean_object* v___x_4169_; uint8_t v_isShared_4170_; uint8_t v_isSharedCheck_4174_; 
lean_del_object(v___x_4102_);
lean_dec(v_fst_4099_);
lean_del_object(v___x_4095_);
lean_dec(v_fst_4092_);
lean_del_object(v___x_4088_);
lean_dec(v_fst_4085_);
lean_del_object(v___x_4081_);
lean_dec(v_fst_4078_);
lean_del_object(v___x_4074_);
lean_del_object(v___x_4070_);
lean_del_object(v___x_4065_);
lean_del_object(v___x_4061_);
lean_dec(v_hints_4052_);
lean_del_object(v___x_4048_);
v_a_4167_ = lean_ctor_get(v___x_4104_, 0);
v_isSharedCheck_4174_ = !lean_is_exclusive(v___x_4104_);
if (v_isSharedCheck_4174_ == 0)
{
v___x_4169_ = v___x_4104_;
v_isShared_4170_ = v_isSharedCheck_4174_;
goto v_resetjp_4168_;
}
else
{
lean_inc(v_a_4167_);
lean_dec(v___x_4104_);
v___x_4169_ = lean_box(0);
v_isShared_4170_ = v_isSharedCheck_4174_;
goto v_resetjp_4168_;
}
v_resetjp_4168_:
{
lean_object* v___x_4172_; 
if (v_isShared_4170_ == 0)
{
v___x_4172_ = v___x_4169_;
goto v_reusejp_4171_;
}
else
{
lean_object* v_reuseFailAlloc_4173_; 
v_reuseFailAlloc_4173_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4173_, 0, v_a_4167_);
v___x_4172_ = v_reuseFailAlloc_4173_;
goto v_reusejp_4171_;
}
v_reusejp_4171_:
{
return v___x_4172_;
}
}
}
}
}
else
{
lean_object* v_a_4176_; lean_object* v___x_4178_; uint8_t v_isShared_4179_; uint8_t v_isSharedCheck_4183_; 
lean_del_object(v___x_4095_);
lean_dec(v_fst_4092_);
lean_del_object(v___x_4088_);
lean_dec(v_fst_4085_);
lean_del_object(v___x_4081_);
lean_dec(v_fst_4078_);
lean_del_object(v___x_4074_);
lean_del_object(v___x_4070_);
lean_del_object(v___x_4065_);
lean_del_object(v___x_4061_);
lean_dec(v_all_4054_);
lean_dec(v_hints_4052_);
lean_del_object(v___x_4048_);
v_a_4176_ = lean_ctor_get(v___x_4097_, 0);
v_isSharedCheck_4183_ = !lean_is_exclusive(v___x_4097_);
if (v_isSharedCheck_4183_ == 0)
{
v___x_4178_ = v___x_4097_;
v_isShared_4179_ = v_isSharedCheck_4183_;
goto v_resetjp_4177_;
}
else
{
lean_inc(v_a_4176_);
lean_dec(v___x_4097_);
v___x_4178_ = lean_box(0);
v_isShared_4179_ = v_isSharedCheck_4183_;
goto v_resetjp_4177_;
}
v_resetjp_4177_:
{
lean_object* v___x_4181_; 
if (v_isShared_4179_ == 0)
{
v___x_4181_ = v___x_4178_;
goto v_reusejp_4180_;
}
else
{
lean_object* v_reuseFailAlloc_4182_; 
v_reuseFailAlloc_4182_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4182_, 0, v_a_4176_);
v___x_4181_ = v_reuseFailAlloc_4182_;
goto v_reusejp_4180_;
}
v_reusejp_4180_:
{
return v___x_4181_;
}
}
}
}
}
else
{
lean_object* v_a_4185_; lean_object* v___x_4187_; uint8_t v_isShared_4188_; uint8_t v_isSharedCheck_4192_; 
lean_del_object(v___x_4088_);
lean_dec(v_fst_4085_);
lean_del_object(v___x_4081_);
lean_dec(v_fst_4078_);
lean_del_object(v___x_4074_);
lean_del_object(v___x_4070_);
lean_del_object(v___x_4065_);
lean_del_object(v___x_4061_);
lean_dec(v_all_4054_);
lean_dec(v_hints_4052_);
lean_dec_ref(v_value_4051_);
lean_del_object(v___x_4048_);
v_a_4185_ = lean_ctor_get(v___x_4090_, 0);
v_isSharedCheck_4192_ = !lean_is_exclusive(v___x_4090_);
if (v_isSharedCheck_4192_ == 0)
{
v___x_4187_ = v___x_4090_;
v_isShared_4188_ = v_isSharedCheck_4192_;
goto v_resetjp_4186_;
}
else
{
lean_inc(v_a_4185_);
lean_dec(v___x_4090_);
v___x_4187_ = lean_box(0);
v_isShared_4188_ = v_isSharedCheck_4192_;
goto v_resetjp_4186_;
}
v_resetjp_4186_:
{
lean_object* v___x_4190_; 
if (v_isShared_4188_ == 0)
{
v___x_4190_ = v___x_4187_;
goto v_reusejp_4189_;
}
else
{
lean_object* v_reuseFailAlloc_4191_; 
v_reuseFailAlloc_4191_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4191_, 0, v_a_4185_);
v___x_4190_ = v_reuseFailAlloc_4191_;
goto v_reusejp_4189_;
}
v_reusejp_4189_:
{
return v___x_4190_;
}
}
}
}
}
else
{
lean_object* v_a_4194_; lean_object* v___x_4196_; uint8_t v_isShared_4197_; uint8_t v_isSharedCheck_4201_; 
lean_del_object(v___x_4081_);
lean_dec(v_fst_4078_);
lean_del_object(v___x_4074_);
lean_del_object(v___x_4070_);
lean_del_object(v___x_4065_);
lean_del_object(v___x_4061_);
lean_dec_ref(v_type_4057_);
lean_dec(v_all_4054_);
lean_dec(v_hints_4052_);
lean_dec_ref(v_value_4051_);
lean_del_object(v___x_4048_);
v_a_4194_ = lean_ctor_get(v___x_4083_, 0);
v_isSharedCheck_4201_ = !lean_is_exclusive(v___x_4083_);
if (v_isSharedCheck_4201_ == 0)
{
v___x_4196_ = v___x_4083_;
v_isShared_4197_ = v_isSharedCheck_4201_;
goto v_resetjp_4195_;
}
else
{
lean_inc(v_a_4194_);
lean_dec(v___x_4083_);
v___x_4196_ = lean_box(0);
v_isShared_4197_ = v_isSharedCheck_4201_;
goto v_resetjp_4195_;
}
v_resetjp_4195_:
{
lean_object* v___x_4199_; 
if (v_isShared_4197_ == 0)
{
v___x_4199_ = v___x_4196_;
goto v_reusejp_4198_;
}
else
{
lean_object* v_reuseFailAlloc_4200_; 
v_reuseFailAlloc_4200_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4200_, 0, v_a_4194_);
v___x_4199_ = v_reuseFailAlloc_4200_;
goto v_reusejp_4198_;
}
v_reusejp_4198_:
{
return v___x_4199_;
}
}
}
}
}
else
{
lean_object* v_a_4203_; lean_object* v___x_4205_; uint8_t v_isShared_4206_; uint8_t v_isSharedCheck_4210_; 
lean_del_object(v___x_4074_);
lean_del_object(v___x_4070_);
lean_del_object(v___x_4065_);
lean_del_object(v___x_4061_);
lean_dec_ref(v_type_4057_);
lean_dec(v_levelParams_4056_);
lean_dec(v_all_4054_);
lean_dec(v_hints_4052_);
lean_dec_ref(v_value_4051_);
lean_del_object(v___x_4048_);
v_a_4203_ = lean_ctor_get(v___x_4076_, 0);
v_isSharedCheck_4210_ = !lean_is_exclusive(v___x_4076_);
if (v_isSharedCheck_4210_ == 0)
{
v___x_4205_ = v___x_4076_;
v_isShared_4206_ = v_isSharedCheck_4210_;
goto v_resetjp_4204_;
}
else
{
lean_inc(v_a_4203_);
lean_dec(v___x_4076_);
v___x_4205_ = lean_box(0);
v_isShared_4206_ = v_isSharedCheck_4210_;
goto v_resetjp_4204_;
}
v_resetjp_4204_:
{
lean_object* v___x_4208_; 
if (v_isShared_4206_ == 0)
{
v___x_4208_ = v___x_4205_;
goto v_reusejp_4207_;
}
else
{
lean_object* v_reuseFailAlloc_4209_; 
v_reuseFailAlloc_4209_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4209_, 0, v_a_4203_);
v___x_4208_ = v_reuseFailAlloc_4209_;
goto v_reusejp_4207_;
}
v_reusejp_4207_:
{
return v___x_4208_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_4065_);
lean_del_object(v___x_4061_);
lean_dec_ref(v_type_4057_);
lean_dec(v_levelParams_4056_);
lean_dec(v_name_4055_);
lean_dec(v_all_4054_);
lean_dec(v_hints_4052_);
lean_dec_ref(v_value_4051_);
lean_del_object(v___x_4048_);
return v___x_4067_;
}
}
}
}
else
{
lean_dec_ref(v_type_4057_);
lean_dec(v_levelParams_4056_);
lean_dec(v_name_4055_);
lean_dec(v_all_4054_);
lean_dec(v_hints_4052_);
lean_dec_ref(v_value_4051_);
lean_del_object(v___x_4048_);
return v___x_4058_;
}
}
}
case 2:
{
lean_object* v_val_4218_; lean_object* v___x_4220_; uint8_t v_isShared_4221_; uint8_t v_isSharedCheck_4379_; 
v_val_4218_ = lean_ctor_get(v_val_3923_, 0);
v_isSharedCheck_4379_ = !lean_is_exclusive(v_val_3923_);
if (v_isSharedCheck_4379_ == 0)
{
v___x_4220_ = v_val_3923_;
v_isShared_4221_ = v_isSharedCheck_4379_;
goto v_resetjp_4219_;
}
else
{
lean_inc(v_val_4218_);
lean_dec(v_val_3923_);
v___x_4220_ = lean_box(0);
v_isShared_4221_ = v_isSharedCheck_4379_;
goto v_resetjp_4219_;
}
v_resetjp_4219_:
{
lean_object* v_toConstantVal_4222_; lean_object* v_value_4223_; lean_object* v_all_4224_; lean_object* v_name_4225_; lean_object* v_levelParams_4226_; lean_object* v_type_4227_; lean_object* v___x_4228_; 
v_toConstantVal_4222_ = lean_ctor_get(v_val_4218_, 0);
lean_inc_ref(v_toConstantVal_4222_);
v_value_4223_ = lean_ctor_get(v_val_4218_, 1);
lean_inc_ref(v_value_4223_);
v_all_4224_ = lean_ctor_get(v_val_4218_, 2);
lean_inc(v_all_4224_);
lean_dec_ref(v_val_4218_);
v_name_4225_ = lean_ctor_get(v_toConstantVal_4222_, 0);
lean_inc(v_name_4225_);
v_levelParams_4226_ = lean_ctor_get(v_toConstantVal_4222_, 1);
lean_inc(v_levelParams_4226_);
v_type_4227_ = lean_ctor_get(v_toConstantVal_4222_, 2);
lean_inc_ref_n(v_type_4227_, 2);
lean_dec_ref(v_toConstantVal_4222_);
v___x_4228_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_4227_, v_a_3813_, v___x_3940_);
if (lean_obj_tag(v___x_4228_) == 0)
{
lean_object* v_a_4229_; lean_object* v___x_4231_; uint8_t v_isShared_4232_; uint8_t v_isSharedCheck_4378_; 
v_a_4229_ = lean_ctor_get(v___x_4228_, 0);
v_isSharedCheck_4378_ = !lean_is_exclusive(v___x_4228_);
if (v_isSharedCheck_4378_ == 0)
{
v___x_4231_ = v___x_4228_;
v_isShared_4232_ = v_isSharedCheck_4378_;
goto v_resetjp_4230_;
}
else
{
lean_inc(v_a_4229_);
lean_dec(v___x_4228_);
v___x_4231_ = lean_box(0);
v_isShared_4232_ = v_isSharedCheck_4378_;
goto v_resetjp_4230_;
}
v_resetjp_4230_:
{
lean_object* v_snd_4233_; lean_object* v___x_4235_; uint8_t v_isShared_4236_; uint8_t v_isSharedCheck_4376_; 
v_snd_4233_ = lean_ctor_get(v_a_4229_, 1);
v_isSharedCheck_4376_ = !lean_is_exclusive(v_a_4229_);
if (v_isSharedCheck_4376_ == 0)
{
lean_object* v_unused_4377_; 
v_unused_4377_ = lean_ctor_get(v_a_4229_, 0);
lean_dec(v_unused_4377_);
v___x_4235_ = v_a_4229_;
v_isShared_4236_ = v_isSharedCheck_4376_;
goto v_resetjp_4234_;
}
else
{
lean_inc(v_snd_4233_);
lean_dec(v_a_4229_);
v___x_4235_ = lean_box(0);
v_isShared_4236_ = v_isSharedCheck_4376_;
goto v_resetjp_4234_;
}
v_resetjp_4234_:
{
lean_object* v___x_4237_; 
lean_inc_ref(v_value_4223_);
v___x_4237_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_value_4223_, v_a_3813_, v_snd_4233_);
if (lean_obj_tag(v___x_4237_) == 0)
{
lean_object* v_a_4238_; lean_object* v___x_4240_; uint8_t v_isShared_4241_; uint8_t v_isSharedCheck_4375_; 
v_a_4238_ = lean_ctor_get(v___x_4237_, 0);
v_isSharedCheck_4375_ = !lean_is_exclusive(v___x_4237_);
if (v_isSharedCheck_4375_ == 0)
{
v___x_4240_ = v___x_4237_;
v_isShared_4241_ = v_isSharedCheck_4375_;
goto v_resetjp_4239_;
}
else
{
lean_inc(v_a_4238_);
lean_dec(v___x_4237_);
v___x_4240_ = lean_box(0);
v_isShared_4241_ = v_isSharedCheck_4375_;
goto v_resetjp_4239_;
}
v_resetjp_4239_:
{
lean_object* v_snd_4242_; lean_object* v___x_4244_; uint8_t v_isShared_4245_; uint8_t v_isSharedCheck_4373_; 
v_snd_4242_ = lean_ctor_get(v_a_4238_, 1);
v_isSharedCheck_4373_ = !lean_is_exclusive(v_a_4238_);
if (v_isSharedCheck_4373_ == 0)
{
lean_object* v_unused_4374_; 
v_unused_4374_ = lean_ctor_get(v_a_4238_, 0);
lean_dec(v_unused_4374_);
v___x_4244_ = v_a_4238_;
v_isShared_4245_ = v_isSharedCheck_4373_;
goto v_resetjp_4243_;
}
else
{
lean_inc(v_snd_4242_);
lean_dec(v_a_4238_);
v___x_4244_ = lean_box(0);
v_isShared_4245_ = v_isSharedCheck_4373_;
goto v_resetjp_4243_;
}
v_resetjp_4243_:
{
lean_object* v___x_4246_; 
v___x_4246_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_4225_, v_a_3813_, v_snd_4242_);
if (lean_obj_tag(v___x_4246_) == 0)
{
lean_object* v_a_4247_; lean_object* v_fst_4248_; lean_object* v_snd_4249_; lean_object* v___x_4251_; uint8_t v_isShared_4252_; uint8_t v_isSharedCheck_4364_; 
v_a_4247_ = lean_ctor_get(v___x_4246_, 0);
lean_inc(v_a_4247_);
lean_dec_ref_known(v___x_4246_, 1);
v_fst_4248_ = lean_ctor_get(v_a_4247_, 0);
v_snd_4249_ = lean_ctor_get(v_a_4247_, 1);
v_isSharedCheck_4364_ = !lean_is_exclusive(v_a_4247_);
if (v_isSharedCheck_4364_ == 0)
{
v___x_4251_ = v_a_4247_;
v_isShared_4252_ = v_isSharedCheck_4364_;
goto v_resetjp_4250_;
}
else
{
lean_inc(v_snd_4249_);
lean_inc(v_fst_4248_);
lean_dec(v_a_4247_);
v___x_4251_ = lean_box(0);
v_isShared_4252_ = v_isSharedCheck_4364_;
goto v_resetjp_4250_;
}
v_resetjp_4250_:
{
lean_object* v___x_4253_; 
v___x_4253_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_4226_, v_a_3813_, v_snd_4249_);
if (lean_obj_tag(v___x_4253_) == 0)
{
lean_object* v_a_4254_; lean_object* v_fst_4255_; lean_object* v_snd_4256_; lean_object* v___x_4258_; uint8_t v_isShared_4259_; uint8_t v_isSharedCheck_4355_; 
v_a_4254_ = lean_ctor_get(v___x_4253_, 0);
lean_inc(v_a_4254_);
lean_dec_ref_known(v___x_4253_, 1);
v_fst_4255_ = lean_ctor_get(v_a_4254_, 0);
v_snd_4256_ = lean_ctor_get(v_a_4254_, 1);
v_isSharedCheck_4355_ = !lean_is_exclusive(v_a_4254_);
if (v_isSharedCheck_4355_ == 0)
{
v___x_4258_ = v_a_4254_;
v_isShared_4259_ = v_isSharedCheck_4355_;
goto v_resetjp_4257_;
}
else
{
lean_inc(v_snd_4256_);
lean_inc(v_fst_4255_);
lean_dec(v_a_4254_);
v___x_4258_ = lean_box(0);
v_isShared_4259_ = v_isSharedCheck_4355_;
goto v_resetjp_4257_;
}
v_resetjp_4257_:
{
lean_object* v___x_4260_; 
v___x_4260_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_4227_, v_a_3813_, v_snd_4256_);
if (lean_obj_tag(v___x_4260_) == 0)
{
lean_object* v_a_4261_; lean_object* v_fst_4262_; lean_object* v_snd_4263_; lean_object* v___x_4265_; uint8_t v_isShared_4266_; uint8_t v_isSharedCheck_4346_; 
v_a_4261_ = lean_ctor_get(v___x_4260_, 0);
lean_inc(v_a_4261_);
lean_dec_ref_known(v___x_4260_, 1);
v_fst_4262_ = lean_ctor_get(v_a_4261_, 0);
v_snd_4263_ = lean_ctor_get(v_a_4261_, 1);
v_isSharedCheck_4346_ = !lean_is_exclusive(v_a_4261_);
if (v_isSharedCheck_4346_ == 0)
{
v___x_4265_ = v_a_4261_;
v_isShared_4266_ = v_isSharedCheck_4346_;
goto v_resetjp_4264_;
}
else
{
lean_inc(v_snd_4263_);
lean_inc(v_fst_4262_);
lean_dec(v_a_4261_);
v___x_4265_ = lean_box(0);
v_isShared_4266_ = v_isSharedCheck_4346_;
goto v_resetjp_4264_;
}
v_resetjp_4264_:
{
lean_object* v___x_4267_; 
v___x_4267_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_value_4223_, v_a_3813_, v_snd_4263_);
if (lean_obj_tag(v___x_4267_) == 0)
{
lean_object* v_a_4268_; lean_object* v_fst_4269_; lean_object* v_snd_4270_; lean_object* v___x_4272_; uint8_t v_isShared_4273_; uint8_t v_isSharedCheck_4337_; 
v_a_4268_ = lean_ctor_get(v___x_4267_, 0);
lean_inc(v_a_4268_);
lean_dec_ref_known(v___x_4267_, 1);
v_fst_4269_ = lean_ctor_get(v_a_4268_, 0);
v_snd_4270_ = lean_ctor_get(v_a_4268_, 1);
v_isSharedCheck_4337_ = !lean_is_exclusive(v_a_4268_);
if (v_isSharedCheck_4337_ == 0)
{
v___x_4272_ = v_a_4268_;
v_isShared_4273_ = v_isSharedCheck_4337_;
goto v_resetjp_4271_;
}
else
{
lean_inc(v_snd_4270_);
lean_inc(v_fst_4269_);
lean_dec(v_a_4268_);
v___x_4272_ = lean_box(0);
v_isShared_4273_ = v_isSharedCheck_4337_;
goto v_resetjp_4271_;
}
v_resetjp_4271_:
{
lean_object* v___x_4274_; 
v___x_4274_ = lp_proofEnvironment_CheckedExport_dumpNames(v_all_4224_, v_a_3813_, v_snd_4270_);
if (lean_obj_tag(v___x_4274_) == 0)
{
lean_object* v_a_4275_; lean_object* v_fst_4276_; lean_object* v_snd_4277_; lean_object* v___x_4279_; uint8_t v_isShared_4280_; uint8_t v_isSharedCheck_4328_; 
v_a_4275_ = lean_ctor_get(v___x_4274_, 0);
lean_inc(v_a_4275_);
lean_dec_ref_known(v___x_4274_, 1);
v_fst_4276_ = lean_ctor_get(v_a_4275_, 0);
v_snd_4277_ = lean_ctor_get(v_a_4275_, 1);
v_isSharedCheck_4328_ = !lean_is_exclusive(v_a_4275_);
if (v_isSharedCheck_4328_ == 0)
{
v___x_4279_ = v_a_4275_;
v_isShared_4280_ = v_isSharedCheck_4328_;
goto v_resetjp_4278_;
}
else
{
lean_inc(v_snd_4277_);
lean_inc(v_fst_4276_);
lean_dec(v_a_4275_);
v___x_4279_ = lean_box(0);
v_isShared_4280_ = v_isSharedCheck_4328_;
goto v_resetjp_4278_;
}
v_resetjp_4278_:
{
lean_object* v___x_4281_; lean_object* v___x_4282_; lean_object* v___x_4283_; lean_object* v___x_4285_; 
v___x_4281_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__7));
v___x_4282_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_4283_ = l_Lean_JsonNumber_fromNat(v_fst_4248_);
if (v_isShared_4241_ == 0)
{
lean_ctor_set_tag(v___x_4240_, 2);
lean_ctor_set(v___x_4240_, 0, v___x_4283_);
v___x_4285_ = v___x_4240_;
goto v_reusejp_4284_;
}
else
{
lean_object* v_reuseFailAlloc_4327_; 
v_reuseFailAlloc_4327_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4327_, 0, v___x_4283_);
v___x_4285_ = v_reuseFailAlloc_4327_;
goto v_reusejp_4284_;
}
v_reusejp_4284_:
{
lean_object* v___x_4287_; 
if (v_isShared_4280_ == 0)
{
lean_ctor_set(v___x_4279_, 1, v___x_4285_);
lean_ctor_set(v___x_4279_, 0, v___x_4282_);
v___x_4287_ = v___x_4279_;
goto v_reusejp_4286_;
}
else
{
lean_object* v_reuseFailAlloc_4326_; 
v_reuseFailAlloc_4326_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4326_, 0, v___x_4282_);
lean_ctor_set(v_reuseFailAlloc_4326_, 1, v___x_4285_);
v___x_4287_ = v_reuseFailAlloc_4326_;
goto v_reusejp_4286_;
}
v_reusejp_4286_:
{
lean_object* v___x_4288_; lean_object* v___x_4290_; 
v___x_4288_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_4273_ == 0)
{
lean_ctor_set(v___x_4272_, 1, v_fst_4255_);
lean_ctor_set(v___x_4272_, 0, v___x_4288_);
v___x_4290_ = v___x_4272_;
goto v_reusejp_4289_;
}
else
{
lean_object* v_reuseFailAlloc_4325_; 
v_reuseFailAlloc_4325_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4325_, 0, v___x_4288_);
lean_ctor_set(v_reuseFailAlloc_4325_, 1, v_fst_4255_);
v___x_4290_ = v_reuseFailAlloc_4325_;
goto v_reusejp_4289_;
}
v_reusejp_4289_:
{
lean_object* v___x_4291_; lean_object* v___x_4292_; lean_object* v___x_4294_; 
v___x_4291_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_4292_ = l_Lean_JsonNumber_fromNat(v_fst_4262_);
if (v_isShared_4232_ == 0)
{
lean_ctor_set_tag(v___x_4231_, 2);
lean_ctor_set(v___x_4231_, 0, v___x_4292_);
v___x_4294_ = v___x_4231_;
goto v_reusejp_4293_;
}
else
{
lean_object* v_reuseFailAlloc_4324_; 
v_reuseFailAlloc_4324_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4324_, 0, v___x_4292_);
v___x_4294_ = v_reuseFailAlloc_4324_;
goto v_reusejp_4293_;
}
v_reusejp_4293_:
{
lean_object* v___x_4296_; 
if (v_isShared_4266_ == 0)
{
lean_ctor_set(v___x_4265_, 1, v___x_4294_);
lean_ctor_set(v___x_4265_, 0, v___x_4291_);
v___x_4296_ = v___x_4265_;
goto v_reusejp_4295_;
}
else
{
lean_object* v_reuseFailAlloc_4323_; 
v_reuseFailAlloc_4323_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4323_, 0, v___x_4291_);
lean_ctor_set(v_reuseFailAlloc_4323_, 1, v___x_4294_);
v___x_4296_ = v_reuseFailAlloc_4323_;
goto v_reusejp_4295_;
}
v_reusejp_4295_:
{
lean_object* v___x_4297_; lean_object* v___x_4298_; lean_object* v___x_4300_; 
v___x_4297_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13));
v___x_4298_ = l_Lean_JsonNumber_fromNat(v_fst_4269_);
if (v_isShared_4221_ == 0)
{
lean_ctor_set(v___x_4220_, 0, v___x_4298_);
v___x_4300_ = v___x_4220_;
goto v_reusejp_4299_;
}
else
{
lean_object* v_reuseFailAlloc_4322_; 
v_reuseFailAlloc_4322_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4322_, 0, v___x_4298_);
v___x_4300_ = v_reuseFailAlloc_4322_;
goto v_reusejp_4299_;
}
v_reusejp_4299_:
{
lean_object* v___x_4302_; 
if (v_isShared_4259_ == 0)
{
lean_ctor_set(v___x_4258_, 1, v___x_4300_);
lean_ctor_set(v___x_4258_, 0, v___x_4297_);
v___x_4302_ = v___x_4258_;
goto v_reusejp_4301_;
}
else
{
lean_object* v_reuseFailAlloc_4321_; 
v_reuseFailAlloc_4321_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4321_, 0, v___x_4297_);
lean_ctor_set(v_reuseFailAlloc_4321_, 1, v___x_4300_);
v___x_4302_ = v_reuseFailAlloc_4321_;
goto v_reusejp_4301_;
}
v_reusejp_4301_:
{
lean_object* v___x_4303_; lean_object* v___x_4305_; 
v___x_4303_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1));
if (v_isShared_4252_ == 0)
{
lean_ctor_set(v___x_4251_, 1, v_fst_4276_);
lean_ctor_set(v___x_4251_, 0, v___x_4303_);
v___x_4305_ = v___x_4251_;
goto v_reusejp_4304_;
}
else
{
lean_object* v_reuseFailAlloc_4320_; 
v_reuseFailAlloc_4320_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4320_, 0, v___x_4303_);
lean_ctor_set(v_reuseFailAlloc_4320_, 1, v_fst_4276_);
v___x_4305_ = v_reuseFailAlloc_4320_;
goto v_reusejp_4304_;
}
v_reusejp_4304_:
{
lean_object* v___x_4306_; lean_object* v___x_4308_; 
v___x_4306_ = lean_box(0);
if (v_isShared_4236_ == 0)
{
lean_ctor_set_tag(v___x_4235_, 1);
lean_ctor_set(v___x_4235_, 1, v___x_4306_);
lean_ctor_set(v___x_4235_, 0, v___x_4305_);
v___x_4308_ = v___x_4235_;
goto v_reusejp_4307_;
}
else
{
lean_object* v_reuseFailAlloc_4319_; 
v_reuseFailAlloc_4319_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4319_, 0, v___x_4305_);
lean_ctor_set(v_reuseFailAlloc_4319_, 1, v___x_4306_);
v___x_4308_ = v_reuseFailAlloc_4319_;
goto v_reusejp_4307_;
}
v_reusejp_4307_:
{
lean_object* v___x_4309_; lean_object* v___x_4310_; lean_object* v___x_4311_; lean_object* v___x_4312_; lean_object* v___x_4313_; lean_object* v___x_4315_; 
v___x_4309_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4309_, 0, v___x_4302_);
lean_ctor_set(v___x_4309_, 1, v___x_4308_);
v___x_4310_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4310_, 0, v___x_4296_);
lean_ctor_set(v___x_4310_, 1, v___x_4309_);
v___x_4311_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4311_, 0, v___x_4290_);
lean_ctor_set(v___x_4311_, 1, v___x_4310_);
v___x_4312_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4312_, 0, v___x_4287_);
lean_ctor_set(v___x_4312_, 1, v___x_4311_);
v___x_4313_ = l_Lean_Json_mkObj(v___x_4312_);
lean_dec_ref_known(v___x_4312_, 2);
if (v_isShared_4245_ == 0)
{
lean_ctor_set(v___x_4244_, 1, v___x_4313_);
lean_ctor_set(v___x_4244_, 0, v___x_4281_);
v___x_4315_ = v___x_4244_;
goto v_reusejp_4314_;
}
else
{
lean_object* v_reuseFailAlloc_4318_; 
v_reuseFailAlloc_4318_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4318_, 0, v___x_4281_);
lean_ctor_set(v_reuseFailAlloc_4318_, 1, v___x_4313_);
v___x_4315_ = v_reuseFailAlloc_4318_;
goto v_reusejp_4314_;
}
v_reusejp_4314_:
{
lean_object* v___x_4316_; lean_object* v___x_4317_; 
v___x_4316_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4316_, 0, v___x_4315_);
lean_ctor_set(v___x_4316_, 1, v___x_4306_);
v___x_4317_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v___x_4316_, v_snd_4277_);
lean_dec_ref_known(v___x_4316_, 2);
return v___x_4317_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4329_; lean_object* v___x_4331_; uint8_t v_isShared_4332_; uint8_t v_isSharedCheck_4336_; 
lean_del_object(v___x_4272_);
lean_dec(v_fst_4269_);
lean_del_object(v___x_4265_);
lean_dec(v_fst_4262_);
lean_del_object(v___x_4258_);
lean_dec(v_fst_4255_);
lean_del_object(v___x_4251_);
lean_dec(v_fst_4248_);
lean_del_object(v___x_4244_);
lean_del_object(v___x_4240_);
lean_del_object(v___x_4235_);
lean_del_object(v___x_4231_);
lean_del_object(v___x_4220_);
v_a_4329_ = lean_ctor_get(v___x_4274_, 0);
v_isSharedCheck_4336_ = !lean_is_exclusive(v___x_4274_);
if (v_isSharedCheck_4336_ == 0)
{
v___x_4331_ = v___x_4274_;
v_isShared_4332_ = v_isSharedCheck_4336_;
goto v_resetjp_4330_;
}
else
{
lean_inc(v_a_4329_);
lean_dec(v___x_4274_);
v___x_4331_ = lean_box(0);
v_isShared_4332_ = v_isSharedCheck_4336_;
goto v_resetjp_4330_;
}
v_resetjp_4330_:
{
lean_object* v___x_4334_; 
if (v_isShared_4332_ == 0)
{
v___x_4334_ = v___x_4331_;
goto v_reusejp_4333_;
}
else
{
lean_object* v_reuseFailAlloc_4335_; 
v_reuseFailAlloc_4335_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4335_, 0, v_a_4329_);
v___x_4334_ = v_reuseFailAlloc_4335_;
goto v_reusejp_4333_;
}
v_reusejp_4333_:
{
return v___x_4334_;
}
}
}
}
}
else
{
lean_object* v_a_4338_; lean_object* v___x_4340_; uint8_t v_isShared_4341_; uint8_t v_isSharedCheck_4345_; 
lean_del_object(v___x_4265_);
lean_dec(v_fst_4262_);
lean_del_object(v___x_4258_);
lean_dec(v_fst_4255_);
lean_del_object(v___x_4251_);
lean_dec(v_fst_4248_);
lean_del_object(v___x_4244_);
lean_del_object(v___x_4240_);
lean_del_object(v___x_4235_);
lean_del_object(v___x_4231_);
lean_dec(v_all_4224_);
lean_del_object(v___x_4220_);
v_a_4338_ = lean_ctor_get(v___x_4267_, 0);
v_isSharedCheck_4345_ = !lean_is_exclusive(v___x_4267_);
if (v_isSharedCheck_4345_ == 0)
{
v___x_4340_ = v___x_4267_;
v_isShared_4341_ = v_isSharedCheck_4345_;
goto v_resetjp_4339_;
}
else
{
lean_inc(v_a_4338_);
lean_dec(v___x_4267_);
v___x_4340_ = lean_box(0);
v_isShared_4341_ = v_isSharedCheck_4345_;
goto v_resetjp_4339_;
}
v_resetjp_4339_:
{
lean_object* v___x_4343_; 
if (v_isShared_4341_ == 0)
{
v___x_4343_ = v___x_4340_;
goto v_reusejp_4342_;
}
else
{
lean_object* v_reuseFailAlloc_4344_; 
v_reuseFailAlloc_4344_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4344_, 0, v_a_4338_);
v___x_4343_ = v_reuseFailAlloc_4344_;
goto v_reusejp_4342_;
}
v_reusejp_4342_:
{
return v___x_4343_;
}
}
}
}
}
else
{
lean_object* v_a_4347_; lean_object* v___x_4349_; uint8_t v_isShared_4350_; uint8_t v_isSharedCheck_4354_; 
lean_del_object(v___x_4258_);
lean_dec(v_fst_4255_);
lean_del_object(v___x_4251_);
lean_dec(v_fst_4248_);
lean_del_object(v___x_4244_);
lean_del_object(v___x_4240_);
lean_del_object(v___x_4235_);
lean_del_object(v___x_4231_);
lean_dec(v_all_4224_);
lean_dec_ref(v_value_4223_);
lean_del_object(v___x_4220_);
v_a_4347_ = lean_ctor_get(v___x_4260_, 0);
v_isSharedCheck_4354_ = !lean_is_exclusive(v___x_4260_);
if (v_isSharedCheck_4354_ == 0)
{
v___x_4349_ = v___x_4260_;
v_isShared_4350_ = v_isSharedCheck_4354_;
goto v_resetjp_4348_;
}
else
{
lean_inc(v_a_4347_);
lean_dec(v___x_4260_);
v___x_4349_ = lean_box(0);
v_isShared_4350_ = v_isSharedCheck_4354_;
goto v_resetjp_4348_;
}
v_resetjp_4348_:
{
lean_object* v___x_4352_; 
if (v_isShared_4350_ == 0)
{
v___x_4352_ = v___x_4349_;
goto v_reusejp_4351_;
}
else
{
lean_object* v_reuseFailAlloc_4353_; 
v_reuseFailAlloc_4353_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4353_, 0, v_a_4347_);
v___x_4352_ = v_reuseFailAlloc_4353_;
goto v_reusejp_4351_;
}
v_reusejp_4351_:
{
return v___x_4352_;
}
}
}
}
}
else
{
lean_object* v_a_4356_; lean_object* v___x_4358_; uint8_t v_isShared_4359_; uint8_t v_isSharedCheck_4363_; 
lean_del_object(v___x_4251_);
lean_dec(v_fst_4248_);
lean_del_object(v___x_4244_);
lean_del_object(v___x_4240_);
lean_del_object(v___x_4235_);
lean_del_object(v___x_4231_);
lean_dec_ref(v_type_4227_);
lean_dec(v_all_4224_);
lean_dec_ref(v_value_4223_);
lean_del_object(v___x_4220_);
v_a_4356_ = lean_ctor_get(v___x_4253_, 0);
v_isSharedCheck_4363_ = !lean_is_exclusive(v___x_4253_);
if (v_isSharedCheck_4363_ == 0)
{
v___x_4358_ = v___x_4253_;
v_isShared_4359_ = v_isSharedCheck_4363_;
goto v_resetjp_4357_;
}
else
{
lean_inc(v_a_4356_);
lean_dec(v___x_4253_);
v___x_4358_ = lean_box(0);
v_isShared_4359_ = v_isSharedCheck_4363_;
goto v_resetjp_4357_;
}
v_resetjp_4357_:
{
lean_object* v___x_4361_; 
if (v_isShared_4359_ == 0)
{
v___x_4361_ = v___x_4358_;
goto v_reusejp_4360_;
}
else
{
lean_object* v_reuseFailAlloc_4362_; 
v_reuseFailAlloc_4362_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4362_, 0, v_a_4356_);
v___x_4361_ = v_reuseFailAlloc_4362_;
goto v_reusejp_4360_;
}
v_reusejp_4360_:
{
return v___x_4361_;
}
}
}
}
}
else
{
lean_object* v_a_4365_; lean_object* v___x_4367_; uint8_t v_isShared_4368_; uint8_t v_isSharedCheck_4372_; 
lean_del_object(v___x_4244_);
lean_del_object(v___x_4240_);
lean_del_object(v___x_4235_);
lean_del_object(v___x_4231_);
lean_dec_ref(v_type_4227_);
lean_dec(v_levelParams_4226_);
lean_dec(v_all_4224_);
lean_dec_ref(v_value_4223_);
lean_del_object(v___x_4220_);
v_a_4365_ = lean_ctor_get(v___x_4246_, 0);
v_isSharedCheck_4372_ = !lean_is_exclusive(v___x_4246_);
if (v_isSharedCheck_4372_ == 0)
{
v___x_4367_ = v___x_4246_;
v_isShared_4368_ = v_isSharedCheck_4372_;
goto v_resetjp_4366_;
}
else
{
lean_inc(v_a_4365_);
lean_dec(v___x_4246_);
v___x_4367_ = lean_box(0);
v_isShared_4368_ = v_isSharedCheck_4372_;
goto v_resetjp_4366_;
}
v_resetjp_4366_:
{
lean_object* v___x_4370_; 
if (v_isShared_4368_ == 0)
{
v___x_4370_ = v___x_4367_;
goto v_reusejp_4369_;
}
else
{
lean_object* v_reuseFailAlloc_4371_; 
v_reuseFailAlloc_4371_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4371_, 0, v_a_4365_);
v___x_4370_ = v_reuseFailAlloc_4371_;
goto v_reusejp_4369_;
}
v_reusejp_4369_:
{
return v___x_4370_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_4235_);
lean_del_object(v___x_4231_);
lean_dec_ref(v_type_4227_);
lean_dec(v_levelParams_4226_);
lean_dec(v_name_4225_);
lean_dec(v_all_4224_);
lean_dec_ref(v_value_4223_);
lean_del_object(v___x_4220_);
return v___x_4237_;
}
}
}
}
else
{
lean_dec_ref(v_type_4227_);
lean_dec(v_levelParams_4226_);
lean_dec(v_name_4225_);
lean_dec(v_all_4224_);
lean_dec_ref(v_value_4223_);
lean_del_object(v___x_4220_);
return v___x_4228_;
}
}
}
case 3:
{
lean_object* v_val_4380_; lean_object* v___x_4382_; uint8_t v_isShared_4383_; uint8_t v_isSharedCheck_4546_; 
v_val_4380_ = lean_ctor_get(v_val_3923_, 0);
v_isSharedCheck_4546_ = !lean_is_exclusive(v_val_3923_);
if (v_isSharedCheck_4546_ == 0)
{
v___x_4382_ = v_val_3923_;
v_isShared_4383_ = v_isSharedCheck_4546_;
goto v_resetjp_4381_;
}
else
{
lean_inc(v_val_4380_);
lean_dec(v_val_3923_);
v___x_4382_ = lean_box(0);
v_isShared_4383_ = v_isSharedCheck_4546_;
goto v_resetjp_4381_;
}
v_resetjp_4381_:
{
lean_object* v_toConstantVal_4384_; lean_object* v_value_4385_; uint8_t v_isUnsafe_4386_; lean_object* v_all_4387_; lean_object* v_name_4388_; lean_object* v_levelParams_4389_; lean_object* v_type_4390_; lean_object* v___x_4391_; 
v_toConstantVal_4384_ = lean_ctor_get(v_val_4380_, 0);
lean_inc_ref(v_toConstantVal_4384_);
v_value_4385_ = lean_ctor_get(v_val_4380_, 1);
lean_inc_ref(v_value_4385_);
v_isUnsafe_4386_ = lean_ctor_get_uint8(v_val_4380_, sizeof(void*)*3);
v_all_4387_ = lean_ctor_get(v_val_4380_, 2);
lean_inc(v_all_4387_);
lean_dec_ref(v_val_4380_);
v_name_4388_ = lean_ctor_get(v_toConstantVal_4384_, 0);
lean_inc(v_name_4388_);
v_levelParams_4389_ = lean_ctor_get(v_toConstantVal_4384_, 1);
lean_inc(v_levelParams_4389_);
v_type_4390_ = lean_ctor_get(v_toConstantVal_4384_, 2);
lean_inc_ref_n(v_type_4390_, 2);
lean_dec_ref(v_toConstantVal_4384_);
v___x_4391_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_type_4390_, v_a_3813_, v___x_3940_);
if (lean_obj_tag(v___x_4391_) == 0)
{
lean_object* v_a_4392_; lean_object* v___x_4394_; uint8_t v_isShared_4395_; uint8_t v_isSharedCheck_4545_; 
v_a_4392_ = lean_ctor_get(v___x_4391_, 0);
v_isSharedCheck_4545_ = !lean_is_exclusive(v___x_4391_);
if (v_isSharedCheck_4545_ == 0)
{
v___x_4394_ = v___x_4391_;
v_isShared_4395_ = v_isSharedCheck_4545_;
goto v_resetjp_4393_;
}
else
{
lean_inc(v_a_4392_);
lean_dec(v___x_4391_);
v___x_4394_ = lean_box(0);
v_isShared_4395_ = v_isSharedCheck_4545_;
goto v_resetjp_4393_;
}
v_resetjp_4393_:
{
lean_object* v_snd_4396_; lean_object* v___x_4398_; uint8_t v_isShared_4399_; uint8_t v_isSharedCheck_4543_; 
v_snd_4396_ = lean_ctor_get(v_a_4392_, 1);
v_isSharedCheck_4543_ = !lean_is_exclusive(v_a_4392_);
if (v_isSharedCheck_4543_ == 0)
{
lean_object* v_unused_4544_; 
v_unused_4544_ = lean_ctor_get(v_a_4392_, 0);
lean_dec(v_unused_4544_);
v___x_4398_ = v_a_4392_;
v_isShared_4399_ = v_isSharedCheck_4543_;
goto v_resetjp_4397_;
}
else
{
lean_inc(v_snd_4396_);
lean_dec(v_a_4392_);
v___x_4398_ = lean_box(0);
v_isShared_4399_ = v_isSharedCheck_4543_;
goto v_resetjp_4397_;
}
v_resetjp_4397_:
{
lean_object* v___x_4400_; 
lean_inc_ref(v_value_4385_);
v___x_4400_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_value_4385_, v_a_3813_, v_snd_4396_);
if (lean_obj_tag(v___x_4400_) == 0)
{
lean_object* v_a_4401_; lean_object* v___x_4403_; uint8_t v_isShared_4404_; uint8_t v_isSharedCheck_4542_; 
v_a_4401_ = lean_ctor_get(v___x_4400_, 0);
v_isSharedCheck_4542_ = !lean_is_exclusive(v___x_4400_);
if (v_isSharedCheck_4542_ == 0)
{
v___x_4403_ = v___x_4400_;
v_isShared_4404_ = v_isSharedCheck_4542_;
goto v_resetjp_4402_;
}
else
{
lean_inc(v_a_4401_);
lean_dec(v___x_4400_);
v___x_4403_ = lean_box(0);
v_isShared_4404_ = v_isSharedCheck_4542_;
goto v_resetjp_4402_;
}
v_resetjp_4402_:
{
lean_object* v_snd_4405_; lean_object* v___x_4407_; uint8_t v_isShared_4408_; uint8_t v_isSharedCheck_4540_; 
v_snd_4405_ = lean_ctor_get(v_a_4401_, 1);
v_isSharedCheck_4540_ = !lean_is_exclusive(v_a_4401_);
if (v_isSharedCheck_4540_ == 0)
{
lean_object* v_unused_4541_; 
v_unused_4541_ = lean_ctor_get(v_a_4401_, 0);
lean_dec(v_unused_4541_);
v___x_4407_ = v_a_4401_;
v_isShared_4408_ = v_isSharedCheck_4540_;
goto v_resetjp_4406_;
}
else
{
lean_inc(v_snd_4405_);
lean_dec(v_a_4401_);
v___x_4407_ = lean_box(0);
v_isShared_4408_ = v_isSharedCheck_4540_;
goto v_resetjp_4406_;
}
v_resetjp_4406_:
{
lean_object* v___x_4409_; 
v___x_4409_ = lp_proofEnvironment_CheckedExport_dumpName(v_name_4388_, v_a_3813_, v_snd_4405_);
if (lean_obj_tag(v___x_4409_) == 0)
{
lean_object* v_a_4410_; lean_object* v_fst_4411_; lean_object* v_snd_4412_; lean_object* v___x_4414_; uint8_t v_isShared_4415_; uint8_t v_isSharedCheck_4531_; 
v_a_4410_ = lean_ctor_get(v___x_4409_, 0);
lean_inc(v_a_4410_);
lean_dec_ref_known(v___x_4409_, 1);
v_fst_4411_ = lean_ctor_get(v_a_4410_, 0);
v_snd_4412_ = lean_ctor_get(v_a_4410_, 1);
v_isSharedCheck_4531_ = !lean_is_exclusive(v_a_4410_);
if (v_isSharedCheck_4531_ == 0)
{
v___x_4414_ = v_a_4410_;
v_isShared_4415_ = v_isSharedCheck_4531_;
goto v_resetjp_4413_;
}
else
{
lean_inc(v_snd_4412_);
lean_inc(v_fst_4411_);
lean_dec(v_a_4410_);
v___x_4414_ = lean_box(0);
v_isShared_4415_ = v_isSharedCheck_4531_;
goto v_resetjp_4413_;
}
v_resetjp_4413_:
{
lean_object* v___x_4416_; 
v___x_4416_ = lp_proofEnvironment_CheckedExport_dumpUparams(v_levelParams_4389_, v_a_3813_, v_snd_4412_);
if (lean_obj_tag(v___x_4416_) == 0)
{
lean_object* v_a_4417_; lean_object* v_fst_4418_; lean_object* v_snd_4419_; lean_object* v___x_4421_; uint8_t v_isShared_4422_; uint8_t v_isSharedCheck_4522_; 
v_a_4417_ = lean_ctor_get(v___x_4416_, 0);
lean_inc(v_a_4417_);
lean_dec_ref_known(v___x_4416_, 1);
v_fst_4418_ = lean_ctor_get(v_a_4417_, 0);
v_snd_4419_ = lean_ctor_get(v_a_4417_, 1);
v_isSharedCheck_4522_ = !lean_is_exclusive(v_a_4417_);
if (v_isSharedCheck_4522_ == 0)
{
v___x_4421_ = v_a_4417_;
v_isShared_4422_ = v_isSharedCheck_4522_;
goto v_resetjp_4420_;
}
else
{
lean_inc(v_snd_4419_);
lean_inc(v_fst_4418_);
lean_dec(v_a_4417_);
v___x_4421_ = lean_box(0);
v_isShared_4422_ = v_isSharedCheck_4522_;
goto v_resetjp_4420_;
}
v_resetjp_4420_:
{
lean_object* v___x_4423_; 
v___x_4423_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_type_4390_, v_a_3813_, v_snd_4419_);
if (lean_obj_tag(v___x_4423_) == 0)
{
lean_object* v_a_4424_; lean_object* v_fst_4425_; lean_object* v_snd_4426_; lean_object* v___x_4428_; uint8_t v_isShared_4429_; uint8_t v_isSharedCheck_4513_; 
v_a_4424_ = lean_ctor_get(v___x_4423_, 0);
lean_inc(v_a_4424_);
lean_dec_ref_known(v___x_4423_, 1);
v_fst_4425_ = lean_ctor_get(v_a_4424_, 0);
v_snd_4426_ = lean_ctor_get(v_a_4424_, 1);
v_isSharedCheck_4513_ = !lean_is_exclusive(v_a_4424_);
if (v_isSharedCheck_4513_ == 0)
{
v___x_4428_ = v_a_4424_;
v_isShared_4429_ = v_isSharedCheck_4513_;
goto v_resetjp_4427_;
}
else
{
lean_inc(v_snd_4426_);
lean_inc(v_fst_4425_);
lean_dec(v_a_4424_);
v___x_4428_ = lean_box(0);
v_isShared_4429_ = v_isSharedCheck_4513_;
goto v_resetjp_4427_;
}
v_resetjp_4427_:
{
lean_object* v___x_4430_; 
v___x_4430_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_value_4385_, v_a_3813_, v_snd_4426_);
if (lean_obj_tag(v___x_4430_) == 0)
{
lean_object* v_a_4431_; lean_object* v_fst_4432_; lean_object* v_snd_4433_; lean_object* v___x_4435_; uint8_t v_isShared_4436_; uint8_t v_isSharedCheck_4504_; 
v_a_4431_ = lean_ctor_get(v___x_4430_, 0);
lean_inc(v_a_4431_);
lean_dec_ref_known(v___x_4430_, 1);
v_fst_4432_ = lean_ctor_get(v_a_4431_, 0);
v_snd_4433_ = lean_ctor_get(v_a_4431_, 1);
v_isSharedCheck_4504_ = !lean_is_exclusive(v_a_4431_);
if (v_isSharedCheck_4504_ == 0)
{
v___x_4435_ = v_a_4431_;
v_isShared_4436_ = v_isSharedCheck_4504_;
goto v_resetjp_4434_;
}
else
{
lean_inc(v_snd_4433_);
lean_inc(v_fst_4432_);
lean_dec(v_a_4431_);
v___x_4435_ = lean_box(0);
v_isShared_4436_ = v_isSharedCheck_4504_;
goto v_resetjp_4434_;
}
v_resetjp_4434_:
{
lean_object* v___x_4437_; 
v___x_4437_ = lp_proofEnvironment_CheckedExport_dumpNames(v_all_4387_, v_a_3813_, v_snd_4433_);
if (lean_obj_tag(v___x_4437_) == 0)
{
lean_object* v_a_4438_; lean_object* v_fst_4439_; lean_object* v_snd_4440_; lean_object* v___x_4442_; uint8_t v_isShared_4443_; uint8_t v_isSharedCheck_4495_; 
v_a_4438_ = lean_ctor_get(v___x_4437_, 0);
lean_inc(v_a_4438_);
lean_dec_ref_known(v___x_4437_, 1);
v_fst_4439_ = lean_ctor_get(v_a_4438_, 0);
v_snd_4440_ = lean_ctor_get(v_a_4438_, 1);
v_isSharedCheck_4495_ = !lean_is_exclusive(v_a_4438_);
if (v_isSharedCheck_4495_ == 0)
{
v___x_4442_ = v_a_4438_;
v_isShared_4443_ = v_isSharedCheck_4495_;
goto v_resetjp_4441_;
}
else
{
lean_inc(v_snd_4440_);
lean_inc(v_fst_4439_);
lean_dec(v_a_4438_);
v___x_4442_ = lean_box(0);
v_isShared_4443_ = v_isSharedCheck_4495_;
goto v_resetjp_4441_;
}
v_resetjp_4441_:
{
lean_object* v___x_4444_; lean_object* v___x_4445_; lean_object* v___x_4446_; lean_object* v___x_4448_; 
v___x_4444_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__8));
v___x_4445_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__0));
v___x_4446_ = l_Lean_JsonNumber_fromNat(v_fst_4411_);
if (v_isShared_4404_ == 0)
{
lean_ctor_set_tag(v___x_4403_, 2);
lean_ctor_set(v___x_4403_, 0, v___x_4446_);
v___x_4448_ = v___x_4403_;
goto v_reusejp_4447_;
}
else
{
lean_object* v_reuseFailAlloc_4494_; 
v_reuseFailAlloc_4494_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4494_, 0, v___x_4446_);
v___x_4448_ = v_reuseFailAlloc_4494_;
goto v_reusejp_4447_;
}
v_reusejp_4447_:
{
lean_object* v___x_4450_; 
if (v_isShared_4443_ == 0)
{
lean_ctor_set(v___x_4442_, 1, v___x_4448_);
lean_ctor_set(v___x_4442_, 0, v___x_4445_);
v___x_4450_ = v___x_4442_;
goto v_reusejp_4449_;
}
else
{
lean_object* v_reuseFailAlloc_4493_; 
v_reuseFailAlloc_4493_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4493_, 0, v___x_4445_);
lean_ctor_set(v_reuseFailAlloc_4493_, 1, v___x_4448_);
v___x_4450_ = v_reuseFailAlloc_4493_;
goto v_reusejp_4449_;
}
v_reusejp_4449_:
{
lean_object* v___x_4451_; lean_object* v___x_4453_; 
v___x_4451_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__1));
if (v_isShared_4436_ == 0)
{
lean_ctor_set(v___x_4435_, 1, v_fst_4418_);
lean_ctor_set(v___x_4435_, 0, v___x_4451_);
v___x_4453_ = v___x_4435_;
goto v_reusejp_4452_;
}
else
{
lean_object* v_reuseFailAlloc_4492_; 
v_reuseFailAlloc_4492_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4492_, 0, v___x_4451_);
lean_ctor_set(v_reuseFailAlloc_4492_, 1, v_fst_4418_);
v___x_4453_ = v_reuseFailAlloc_4492_;
goto v_reusejp_4452_;
}
v_reusejp_4452_:
{
lean_object* v___x_4454_; lean_object* v___x_4455_; lean_object* v___x_4457_; 
v___x_4454_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__2));
v___x_4455_ = l_Lean_JsonNumber_fromNat(v_fst_4425_);
if (v_isShared_4395_ == 0)
{
lean_ctor_set_tag(v___x_4394_, 2);
lean_ctor_set(v___x_4394_, 0, v___x_4455_);
v___x_4457_ = v___x_4394_;
goto v_reusejp_4456_;
}
else
{
lean_object* v_reuseFailAlloc_4491_; 
v_reuseFailAlloc_4491_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4491_, 0, v___x_4455_);
v___x_4457_ = v_reuseFailAlloc_4491_;
goto v_reusejp_4456_;
}
v_reusejp_4456_:
{
lean_object* v___x_4459_; 
if (v_isShared_4429_ == 0)
{
lean_ctor_set(v___x_4428_, 1, v___x_4457_);
lean_ctor_set(v___x_4428_, 0, v___x_4454_);
v___x_4459_ = v___x_4428_;
goto v_reusejp_4458_;
}
else
{
lean_object* v_reuseFailAlloc_4490_; 
v_reuseFailAlloc_4490_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4490_, 0, v___x_4454_);
lean_ctor_set(v_reuseFailAlloc_4490_, 1, v___x_4457_);
v___x_4459_ = v_reuseFailAlloc_4490_;
goto v_reusejp_4458_;
}
v_reusejp_4458_:
{
lean_object* v___x_4460_; lean_object* v___x_4461_; lean_object* v___x_4463_; 
v___x_4460_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpExprAux___closed__13));
v___x_4461_ = l_Lean_JsonNumber_fromNat(v_fst_4432_);
if (v_isShared_4383_ == 0)
{
lean_ctor_set_tag(v___x_4382_, 2);
lean_ctor_set(v___x_4382_, 0, v___x_4461_);
v___x_4463_ = v___x_4382_;
goto v_reusejp_4462_;
}
else
{
lean_object* v_reuseFailAlloc_4489_; 
v_reuseFailAlloc_4489_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4489_, 0, v___x_4461_);
v___x_4463_ = v_reuseFailAlloc_4489_;
goto v_reusejp_4462_;
}
v_reusejp_4462_:
{
lean_object* v___x_4465_; 
if (v_isShared_4422_ == 0)
{
lean_ctor_set(v___x_4421_, 1, v___x_4463_);
lean_ctor_set(v___x_4421_, 0, v___x_4460_);
v___x_4465_ = v___x_4421_;
goto v_reusejp_4464_;
}
else
{
lean_object* v_reuseFailAlloc_4488_; 
v_reuseFailAlloc_4488_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4488_, 0, v___x_4460_);
lean_ctor_set(v_reuseFailAlloc_4488_, 1, v___x_4463_);
v___x_4465_ = v_reuseFailAlloc_4488_;
goto v_reusejp_4464_;
}
v_reusejp_4464_:
{
lean_object* v___x_4466_; lean_object* v___x_4468_; 
v___x_4466_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__1));
if (v_isShared_4415_ == 0)
{
lean_ctor_set(v___x_4414_, 1, v_fst_4439_);
lean_ctor_set(v___x_4414_, 0, v___x_4466_);
v___x_4468_ = v___x_4414_;
goto v_reusejp_4467_;
}
else
{
lean_object* v_reuseFailAlloc_4487_; 
v_reuseFailAlloc_4487_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4487_, 0, v___x_4466_);
lean_ctor_set(v_reuseFailAlloc_4487_, 1, v_fst_4439_);
v___x_4468_ = v_reuseFailAlloc_4487_;
goto v_reusejp_4467_;
}
v_reusejp_4467_:
{
lean_object* v___x_4469_; lean_object* v___x_4470_; lean_object* v___x_4472_; 
v___x_4469_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___closed__7));
v___x_4470_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_4470_, 0, v_isUnsafe_4386_);
if (v_isShared_4408_ == 0)
{
lean_ctor_set(v___x_4407_, 1, v___x_4470_);
lean_ctor_set(v___x_4407_, 0, v___x_4469_);
v___x_4472_ = v___x_4407_;
goto v_reusejp_4471_;
}
else
{
lean_object* v_reuseFailAlloc_4486_; 
v_reuseFailAlloc_4486_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4486_, 0, v___x_4469_);
lean_ctor_set(v_reuseFailAlloc_4486_, 1, v___x_4470_);
v___x_4472_ = v_reuseFailAlloc_4486_;
goto v_reusejp_4471_;
}
v_reusejp_4471_:
{
lean_object* v___x_4473_; lean_object* v___x_4474_; lean_object* v___x_4475_; lean_object* v___x_4476_; lean_object* v___x_4477_; lean_object* v___x_4478_; lean_object* v___x_4479_; lean_object* v___x_4480_; lean_object* v___x_4482_; 
v___x_4473_ = lean_box(0);
v___x_4474_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4474_, 0, v___x_4472_);
lean_ctor_set(v___x_4474_, 1, v___x_4473_);
v___x_4475_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4475_, 0, v___x_4468_);
lean_ctor_set(v___x_4475_, 1, v___x_4474_);
v___x_4476_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4476_, 0, v___x_4465_);
lean_ctor_set(v___x_4476_, 1, v___x_4475_);
v___x_4477_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4477_, 0, v___x_4459_);
lean_ctor_set(v___x_4477_, 1, v___x_4476_);
v___x_4478_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4478_, 0, v___x_4453_);
lean_ctor_set(v___x_4478_, 1, v___x_4477_);
v___x_4479_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4479_, 0, v___x_4450_);
lean_ctor_set(v___x_4479_, 1, v___x_4478_);
v___x_4480_ = l_Lean_Json_mkObj(v___x_4479_);
lean_dec_ref_known(v___x_4479_, 2);
if (v_isShared_4399_ == 0)
{
lean_ctor_set(v___x_4398_, 1, v___x_4480_);
lean_ctor_set(v___x_4398_, 0, v___x_4444_);
v___x_4482_ = v___x_4398_;
goto v_reusejp_4481_;
}
else
{
lean_object* v_reuseFailAlloc_4485_; 
v_reuseFailAlloc_4485_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4485_, 0, v___x_4444_);
lean_ctor_set(v_reuseFailAlloc_4485_, 1, v___x_4480_);
v___x_4482_ = v_reuseFailAlloc_4485_;
goto v_reusejp_4481_;
}
v_reusejp_4481_:
{
lean_object* v___x_4483_; lean_object* v___x_4484_; 
v___x_4483_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4483_, 0, v___x_4482_);
lean_ctor_set(v___x_4483_, 1, v___x_4473_);
v___x_4484_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v___x_4483_, v_snd_4440_);
lean_dec_ref_known(v___x_4483_, 2);
return v___x_4484_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4496_; lean_object* v___x_4498_; uint8_t v_isShared_4499_; uint8_t v_isSharedCheck_4503_; 
lean_del_object(v___x_4435_);
lean_dec(v_fst_4432_);
lean_del_object(v___x_4428_);
lean_dec(v_fst_4425_);
lean_del_object(v___x_4421_);
lean_dec(v_fst_4418_);
lean_del_object(v___x_4414_);
lean_dec(v_fst_4411_);
lean_del_object(v___x_4407_);
lean_del_object(v___x_4403_);
lean_del_object(v___x_4398_);
lean_del_object(v___x_4394_);
lean_del_object(v___x_4382_);
v_a_4496_ = lean_ctor_get(v___x_4437_, 0);
v_isSharedCheck_4503_ = !lean_is_exclusive(v___x_4437_);
if (v_isSharedCheck_4503_ == 0)
{
v___x_4498_ = v___x_4437_;
v_isShared_4499_ = v_isSharedCheck_4503_;
goto v_resetjp_4497_;
}
else
{
lean_inc(v_a_4496_);
lean_dec(v___x_4437_);
v___x_4498_ = lean_box(0);
v_isShared_4499_ = v_isSharedCheck_4503_;
goto v_resetjp_4497_;
}
v_resetjp_4497_:
{
lean_object* v___x_4501_; 
if (v_isShared_4499_ == 0)
{
v___x_4501_ = v___x_4498_;
goto v_reusejp_4500_;
}
else
{
lean_object* v_reuseFailAlloc_4502_; 
v_reuseFailAlloc_4502_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4502_, 0, v_a_4496_);
v___x_4501_ = v_reuseFailAlloc_4502_;
goto v_reusejp_4500_;
}
v_reusejp_4500_:
{
return v___x_4501_;
}
}
}
}
}
else
{
lean_object* v_a_4505_; lean_object* v___x_4507_; uint8_t v_isShared_4508_; uint8_t v_isSharedCheck_4512_; 
lean_del_object(v___x_4428_);
lean_dec(v_fst_4425_);
lean_del_object(v___x_4421_);
lean_dec(v_fst_4418_);
lean_del_object(v___x_4414_);
lean_dec(v_fst_4411_);
lean_del_object(v___x_4407_);
lean_del_object(v___x_4403_);
lean_del_object(v___x_4398_);
lean_del_object(v___x_4394_);
lean_dec(v_all_4387_);
lean_del_object(v___x_4382_);
v_a_4505_ = lean_ctor_get(v___x_4430_, 0);
v_isSharedCheck_4512_ = !lean_is_exclusive(v___x_4430_);
if (v_isSharedCheck_4512_ == 0)
{
v___x_4507_ = v___x_4430_;
v_isShared_4508_ = v_isSharedCheck_4512_;
goto v_resetjp_4506_;
}
else
{
lean_inc(v_a_4505_);
lean_dec(v___x_4430_);
v___x_4507_ = lean_box(0);
v_isShared_4508_ = v_isSharedCheck_4512_;
goto v_resetjp_4506_;
}
v_resetjp_4506_:
{
lean_object* v___x_4510_; 
if (v_isShared_4508_ == 0)
{
v___x_4510_ = v___x_4507_;
goto v_reusejp_4509_;
}
else
{
lean_object* v_reuseFailAlloc_4511_; 
v_reuseFailAlloc_4511_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4511_, 0, v_a_4505_);
v___x_4510_ = v_reuseFailAlloc_4511_;
goto v_reusejp_4509_;
}
v_reusejp_4509_:
{
return v___x_4510_;
}
}
}
}
}
else
{
lean_object* v_a_4514_; lean_object* v___x_4516_; uint8_t v_isShared_4517_; uint8_t v_isSharedCheck_4521_; 
lean_del_object(v___x_4421_);
lean_dec(v_fst_4418_);
lean_del_object(v___x_4414_);
lean_dec(v_fst_4411_);
lean_del_object(v___x_4407_);
lean_del_object(v___x_4403_);
lean_del_object(v___x_4398_);
lean_del_object(v___x_4394_);
lean_dec(v_all_4387_);
lean_dec_ref(v_value_4385_);
lean_del_object(v___x_4382_);
v_a_4514_ = lean_ctor_get(v___x_4423_, 0);
v_isSharedCheck_4521_ = !lean_is_exclusive(v___x_4423_);
if (v_isSharedCheck_4521_ == 0)
{
v___x_4516_ = v___x_4423_;
v_isShared_4517_ = v_isSharedCheck_4521_;
goto v_resetjp_4515_;
}
else
{
lean_inc(v_a_4514_);
lean_dec(v___x_4423_);
v___x_4516_ = lean_box(0);
v_isShared_4517_ = v_isSharedCheck_4521_;
goto v_resetjp_4515_;
}
v_resetjp_4515_:
{
lean_object* v___x_4519_; 
if (v_isShared_4517_ == 0)
{
v___x_4519_ = v___x_4516_;
goto v_reusejp_4518_;
}
else
{
lean_object* v_reuseFailAlloc_4520_; 
v_reuseFailAlloc_4520_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4520_, 0, v_a_4514_);
v___x_4519_ = v_reuseFailAlloc_4520_;
goto v_reusejp_4518_;
}
v_reusejp_4518_:
{
return v___x_4519_;
}
}
}
}
}
else
{
lean_object* v_a_4523_; lean_object* v___x_4525_; uint8_t v_isShared_4526_; uint8_t v_isSharedCheck_4530_; 
lean_del_object(v___x_4414_);
lean_dec(v_fst_4411_);
lean_del_object(v___x_4407_);
lean_del_object(v___x_4403_);
lean_del_object(v___x_4398_);
lean_del_object(v___x_4394_);
lean_dec_ref(v_type_4390_);
lean_dec(v_all_4387_);
lean_dec_ref(v_value_4385_);
lean_del_object(v___x_4382_);
v_a_4523_ = lean_ctor_get(v___x_4416_, 0);
v_isSharedCheck_4530_ = !lean_is_exclusive(v___x_4416_);
if (v_isSharedCheck_4530_ == 0)
{
v___x_4525_ = v___x_4416_;
v_isShared_4526_ = v_isSharedCheck_4530_;
goto v_resetjp_4524_;
}
else
{
lean_inc(v_a_4523_);
lean_dec(v___x_4416_);
v___x_4525_ = lean_box(0);
v_isShared_4526_ = v_isSharedCheck_4530_;
goto v_resetjp_4524_;
}
v_resetjp_4524_:
{
lean_object* v___x_4528_; 
if (v_isShared_4526_ == 0)
{
v___x_4528_ = v___x_4525_;
goto v_reusejp_4527_;
}
else
{
lean_object* v_reuseFailAlloc_4529_; 
v_reuseFailAlloc_4529_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4529_, 0, v_a_4523_);
v___x_4528_ = v_reuseFailAlloc_4529_;
goto v_reusejp_4527_;
}
v_reusejp_4527_:
{
return v___x_4528_;
}
}
}
}
}
else
{
lean_object* v_a_4532_; lean_object* v___x_4534_; uint8_t v_isShared_4535_; uint8_t v_isSharedCheck_4539_; 
lean_del_object(v___x_4407_);
lean_del_object(v___x_4403_);
lean_del_object(v___x_4398_);
lean_del_object(v___x_4394_);
lean_dec_ref(v_type_4390_);
lean_dec(v_levelParams_4389_);
lean_dec(v_all_4387_);
lean_dec_ref(v_value_4385_);
lean_del_object(v___x_4382_);
v_a_4532_ = lean_ctor_get(v___x_4409_, 0);
v_isSharedCheck_4539_ = !lean_is_exclusive(v___x_4409_);
if (v_isSharedCheck_4539_ == 0)
{
v___x_4534_ = v___x_4409_;
v_isShared_4535_ = v_isSharedCheck_4539_;
goto v_resetjp_4533_;
}
else
{
lean_inc(v_a_4532_);
lean_dec(v___x_4409_);
v___x_4534_ = lean_box(0);
v_isShared_4535_ = v_isSharedCheck_4539_;
goto v_resetjp_4533_;
}
v_resetjp_4533_:
{
lean_object* v___x_4537_; 
if (v_isShared_4535_ == 0)
{
v___x_4537_ = v___x_4534_;
goto v_reusejp_4536_;
}
else
{
lean_object* v_reuseFailAlloc_4538_; 
v_reuseFailAlloc_4538_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4538_, 0, v_a_4532_);
v___x_4537_ = v_reuseFailAlloc_4538_;
goto v_reusejp_4536_;
}
v_reusejp_4536_:
{
return v___x_4537_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_4398_);
lean_del_object(v___x_4394_);
lean_dec_ref(v_type_4390_);
lean_dec(v_levelParams_4389_);
lean_dec(v_name_4388_);
lean_dec(v_all_4387_);
lean_dec_ref(v_value_4385_);
lean_del_object(v___x_4382_);
return v___x_4400_;
}
}
}
}
else
{
lean_dec_ref(v_type_4390_);
lean_dec(v_levelParams_4389_);
lean_dec(v_name_4388_);
lean_dec(v_all_4387_);
lean_dec_ref(v_value_4385_);
lean_del_object(v___x_4382_);
return v___x_4391_;
}
}
}
case 4:
{
lean_object* v___x_4547_; lean_object* v___x_4548_; 
lean_dec_ref_known(v_val_3923_, 1);
v___x_4547_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__10));
v___x_4548_ = lp_proofEnvironment_CheckedExport_dumpConstant(v___x_4547_, v_a_3813_, v___x_3940_);
if (lean_obj_tag(v___x_4548_) == 0)
{
lean_object* v_a_4549_; lean_object* v_snd_4550_; lean_object* v___x_4551_; lean_object* v___x_4552_; lean_object* v___x_4553_; lean_object* v___x_4554_; 
v_a_4549_ = lean_ctor_get(v___x_4548_, 0);
lean_inc(v_a_4549_);
lean_dec_ref_known(v___x_4548_, 1);
v_snd_4550_ = lean_ctor_get(v_a_4549_, 1);
lean_inc(v_snd_4550_);
lean_dec(v_a_4549_);
v___x_4551_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__22));
v___x_4552_ = lean_box(0);
v___x_4553_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__0));
v___x_4554_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg(v___x_4551_, v___x_4553_, v_a_3813_, v_snd_4550_);
if (lean_obj_tag(v___x_4554_) == 0)
{
lean_object* v_a_4555_; lean_object* v___x_4557_; uint8_t v_isShared_4558_; uint8_t v_isSharedCheck_4581_; 
v_a_4555_ = lean_ctor_get(v___x_4554_, 0);
v_isSharedCheck_4581_ = !lean_is_exclusive(v___x_4554_);
if (v_isSharedCheck_4581_ == 0)
{
v___x_4557_ = v___x_4554_;
v_isShared_4558_ = v_isSharedCheck_4581_;
goto v_resetjp_4556_;
}
else
{
lean_inc(v_a_4555_);
lean_dec(v___x_4554_);
v___x_4557_ = lean_box(0);
v_isShared_4558_ = v_isSharedCheck_4581_;
goto v_resetjp_4556_;
}
v_resetjp_4556_:
{
lean_object* v_fst_4559_; lean_object* v_fst_4560_; lean_object* v___x_4562_; uint8_t v_isShared_4563_; uint8_t v_isSharedCheck_4579_; 
v_fst_4559_ = lean_ctor_get(v_a_4555_, 0);
lean_inc(v_fst_4559_);
v_fst_4560_ = lean_ctor_get(v_fst_4559_, 0);
v_isSharedCheck_4579_ = !lean_is_exclusive(v_fst_4559_);
if (v_isSharedCheck_4579_ == 0)
{
lean_object* v_unused_4580_; 
v_unused_4580_ = lean_ctor_get(v_fst_4559_, 1);
lean_dec(v_unused_4580_);
v___x_4562_ = v_fst_4559_;
v_isShared_4563_ = v_isSharedCheck_4579_;
goto v_resetjp_4561_;
}
else
{
lean_inc(v_fst_4560_);
lean_dec(v_fst_4559_);
v___x_4562_ = lean_box(0);
v_isShared_4563_ = v_isSharedCheck_4579_;
goto v_resetjp_4561_;
}
v_resetjp_4561_:
{
if (lean_obj_tag(v_fst_4560_) == 0)
{
lean_object* v_snd_4564_; lean_object* v___x_4566_; 
v_snd_4564_ = lean_ctor_get(v_a_4555_, 1);
lean_inc(v_snd_4564_);
lean_dec(v_a_4555_);
if (v_isShared_4563_ == 0)
{
lean_ctor_set(v___x_4562_, 1, v_snd_4564_);
lean_ctor_set(v___x_4562_, 0, v___x_4552_);
v___x_4566_ = v___x_4562_;
goto v_reusejp_4565_;
}
else
{
lean_object* v_reuseFailAlloc_4570_; 
v_reuseFailAlloc_4570_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4570_, 0, v___x_4552_);
lean_ctor_set(v_reuseFailAlloc_4570_, 1, v_snd_4564_);
v___x_4566_ = v_reuseFailAlloc_4570_;
goto v_reusejp_4565_;
}
v_reusejp_4565_:
{
lean_object* v___x_4568_; 
if (v_isShared_4558_ == 0)
{
lean_ctor_set(v___x_4557_, 0, v___x_4566_);
v___x_4568_ = v___x_4557_;
goto v_reusejp_4567_;
}
else
{
lean_object* v_reuseFailAlloc_4569_; 
v_reuseFailAlloc_4569_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4569_, 0, v___x_4566_);
v___x_4568_ = v_reuseFailAlloc_4569_;
goto v_reusejp_4567_;
}
v_reusejp_4567_:
{
return v___x_4568_;
}
}
}
else
{
lean_object* v_snd_4571_; lean_object* v_val_4572_; lean_object* v___x_4574_; 
v_snd_4571_ = lean_ctor_get(v_a_4555_, 1);
lean_inc(v_snd_4571_);
lean_dec(v_a_4555_);
v_val_4572_ = lean_ctor_get(v_fst_4560_, 0);
lean_inc(v_val_4572_);
lean_dec_ref_known(v_fst_4560_, 1);
if (v_isShared_4563_ == 0)
{
lean_ctor_set(v___x_4562_, 1, v_snd_4571_);
lean_ctor_set(v___x_4562_, 0, v_val_4572_);
v___x_4574_ = v___x_4562_;
goto v_reusejp_4573_;
}
else
{
lean_object* v_reuseFailAlloc_4578_; 
v_reuseFailAlloc_4578_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4578_, 0, v_val_4572_);
lean_ctor_set(v_reuseFailAlloc_4578_, 1, v_snd_4571_);
v___x_4574_ = v_reuseFailAlloc_4578_;
goto v_reusejp_4573_;
}
v_reusejp_4573_:
{
lean_object* v___x_4576_; 
if (v_isShared_4558_ == 0)
{
lean_ctor_set(v___x_4557_, 0, v___x_4574_);
v___x_4576_ = v___x_4557_;
goto v_reusejp_4575_;
}
else
{
lean_object* v_reuseFailAlloc_4577_; 
v_reuseFailAlloc_4577_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4577_, 0, v___x_4574_);
v___x_4576_ = v_reuseFailAlloc_4577_;
goto v_reusejp_4575_;
}
v_reusejp_4575_:
{
return v___x_4576_;
}
}
}
}
}
}
else
{
lean_object* v_a_4582_; lean_object* v___x_4584_; uint8_t v_isShared_4585_; uint8_t v_isSharedCheck_4589_; 
v_a_4582_ = lean_ctor_get(v___x_4554_, 0);
v_isSharedCheck_4589_ = !lean_is_exclusive(v___x_4554_);
if (v_isSharedCheck_4589_ == 0)
{
v___x_4584_ = v___x_4554_;
v_isShared_4585_ = v_isSharedCheck_4589_;
goto v_resetjp_4583_;
}
else
{
lean_inc(v_a_4582_);
lean_dec(v___x_4554_);
v___x_4584_ = lean_box(0);
v_isShared_4585_ = v_isSharedCheck_4589_;
goto v_resetjp_4583_;
}
v_resetjp_4583_:
{
lean_object* v___x_4587_; 
if (v_isShared_4585_ == 0)
{
v___x_4587_ = v___x_4584_;
goto v_reusejp_4586_;
}
else
{
lean_object* v_reuseFailAlloc_4588_; 
v_reuseFailAlloc_4588_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4588_, 0, v_a_4582_);
v___x_4587_ = v_reuseFailAlloc_4588_;
goto v_reusejp_4586_;
}
v_reusejp_4586_:
{
return v___x_4587_;
}
}
}
}
else
{
return v___x_4548_;
}
}
case 5:
{
lean_object* v_val_4590_; lean_object* v_all_4591_; lean_object* v___x_4592_; lean_object* v___x_4593_; lean_object* v___x_4594_; 
v_val_4590_ = lean_ctor_get(v_val_3923_, 0);
lean_inc_ref(v_val_4590_);
lean_dec_ref_known(v_val_3923_, 1);
v_all_4591_ = lean_ctor_get(v_val_4590_, 3);
lean_inc(v_all_4591_);
v___x_4592_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__23));
v___x_4593_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__25));
v___x_4594_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg(v___x_3934_, v_val_4590_, v_all_4591_, v___x_4593_, v_a_3813_, v___x_3940_);
lean_dec(v_all_4591_);
lean_dec_ref(v_val_4590_);
if (lean_obj_tag(v___x_4594_) == 0)
{
lean_object* v_a_4595_; lean_object* v_fst_4596_; lean_object* v_snd_4597_; lean_object* v_snd_4598_; lean_object* v_fst_4599_; lean_object* v_fst_4600_; lean_object* v_snd_4601_; lean_object* v___x_4602_; size_t v_sz_4603_; size_t v___x_4604_; lean_object* v___x_4605_; 
v_a_4595_ = lean_ctor_get(v___x_4594_, 0);
lean_inc(v_a_4595_);
lean_dec_ref_known(v___x_4594_, 1);
v_fst_4596_ = lean_ctor_get(v_a_4595_, 0);
lean_inc(v_fst_4596_);
v_snd_4597_ = lean_ctor_get(v_fst_4596_, 1);
lean_inc(v_snd_4597_);
v_snd_4598_ = lean_ctor_get(v_a_4595_, 1);
lean_inc(v_snd_4598_);
lean_dec(v_a_4595_);
v_fst_4599_ = lean_ctor_get(v_fst_4596_, 0);
lean_inc(v_fst_4599_);
lean_dec(v_fst_4596_);
v_fst_4600_ = lean_ctor_get(v_snd_4597_, 0);
lean_inc(v_fst_4600_);
v_snd_4601_ = lean_ctor_get(v_snd_4597_, 1);
lean_inc(v_snd_4601_);
lean_dec(v_snd_4597_);
v___x_4602_ = lean_box(0);
v_sz_4603_ = lean_array_size(v_fst_4600_);
v___x_4604_ = ((size_t)0ULL);
v___x_4605_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__11(v_fst_4600_, v_sz_4603_, v___x_4604_, v___x_4602_, v_a_3813_, v_snd_4598_);
if (lean_obj_tag(v___x_4605_) == 0)
{
lean_object* v_a_4606_; lean_object* v_snd_4607_; lean_object* v___x_4608_; 
v_a_4606_ = lean_ctor_get(v___x_4605_, 0);
lean_inc(v_a_4606_);
lean_dec_ref_known(v___x_4605_, 1);
v_snd_4607_ = lean_ctor_get(v_a_4606_, 1);
lean_inc(v_snd_4607_);
lean_dec(v_a_4606_);
v___x_4608_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12(v___x_3934_, v___x_4592_, v_snd_4601_, v_a_3813_, v_snd_4607_);
if (lean_obj_tag(v___x_4608_) == 0)
{
lean_object* v_a_4609_; lean_object* v_fst_4610_; lean_object* v_snd_4611_; lean_object* v_a_4612_; 
v_a_4609_ = lean_ctor_get(v___x_4608_, 0);
lean_inc(v_a_4609_);
lean_dec_ref_known(v___x_4608_, 1);
v_fst_4610_ = lean_ctor_get(v_a_4609_, 0);
lean_inc(v_fst_4610_);
v_snd_4611_ = lean_ctor_get(v_a_4609_, 1);
lean_inc(v_snd_4611_);
lean_dec(v_a_4609_);
v_a_4612_ = lean_ctor_get(v_fst_4610_, 0);
lean_inc(v_a_4612_);
lean_dec(v_fst_4610_);
v___y_3821_ = v_sz_4603_;
v___y_3822_ = v_fst_4599_;
v___y_3823_ = v___x_4604_;
v___y_3824_ = v___x_4602_;
v___y_3825_ = v_fst_4600_;
v_fst_3826_ = v_a_4612_;
v_snd_3827_ = v_snd_4611_;
goto v___jp_3820_;
}
else
{
lean_object* v_a_4613_; lean_object* v___x_4615_; uint8_t v_isShared_4616_; uint8_t v_isSharedCheck_4620_; 
lean_dec(v_fst_4600_);
lean_dec(v_fst_4599_);
v_a_4613_ = lean_ctor_get(v___x_4608_, 0);
v_isSharedCheck_4620_ = !lean_is_exclusive(v___x_4608_);
if (v_isSharedCheck_4620_ == 0)
{
v___x_4615_ = v___x_4608_;
v_isShared_4616_ = v_isSharedCheck_4620_;
goto v_resetjp_4614_;
}
else
{
lean_inc(v_a_4613_);
lean_dec(v___x_4608_);
v___x_4615_ = lean_box(0);
v_isShared_4616_ = v_isSharedCheck_4620_;
goto v_resetjp_4614_;
}
v_resetjp_4614_:
{
lean_object* v___x_4618_; 
if (v_isShared_4616_ == 0)
{
v___x_4618_ = v___x_4615_;
goto v_reusejp_4617_;
}
else
{
lean_object* v_reuseFailAlloc_4619_; 
v_reuseFailAlloc_4619_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4619_, 0, v_a_4613_);
v___x_4618_ = v_reuseFailAlloc_4619_;
goto v_reusejp_4617_;
}
v_reusejp_4617_:
{
return v___x_4618_;
}
}
}
}
else
{
lean_dec(v_snd_4601_);
lean_dec(v_fst_4600_);
lean_dec(v_fst_4599_);
return v___x_4605_;
}
}
else
{
lean_object* v_a_4621_; lean_object* v___x_4623_; uint8_t v_isShared_4624_; uint8_t v_isSharedCheck_4628_; 
v_a_4621_ = lean_ctor_get(v___x_4594_, 0);
v_isSharedCheck_4628_ = !lean_is_exclusive(v___x_4594_);
if (v_isSharedCheck_4628_ == 0)
{
v___x_4623_ = v___x_4594_;
v_isShared_4624_ = v_isSharedCheck_4628_;
goto v_resetjp_4622_;
}
else
{
lean_inc(v_a_4621_);
lean_dec(v___x_4594_);
v___x_4623_ = lean_box(0);
v_isShared_4624_ = v_isSharedCheck_4628_;
goto v_resetjp_4622_;
}
v_resetjp_4622_:
{
lean_object* v___x_4626_; 
if (v_isShared_4624_ == 0)
{
v___x_4626_ = v___x_4623_;
goto v_reusejp_4625_;
}
else
{
lean_object* v_reuseFailAlloc_4627_; 
v_reuseFailAlloc_4627_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4627_, 0, v_a_4621_);
v___x_4626_ = v_reuseFailAlloc_4627_;
goto v_reusejp_4625_;
}
v_reusejp_4625_:
{
return v___x_4626_;
}
}
}
}
case 6:
{
lean_object* v_val_4629_; lean_object* v_induct_4630_; 
v_val_4629_ = lean_ctor_get(v_val_3923_, 0);
lean_inc_ref(v_val_4629_);
lean_dec_ref_known(v_val_3923_, 1);
v_induct_4630_ = lean_ctor_get(v_val_4629_, 1);
lean_inc(v_induct_4630_);
lean_dec_ref(v_val_4629_);
v_c_3812_ = v_induct_4630_;
v_a_3814_ = v___x_3940_;
goto _start;
}
default: 
{
lean_object* v_val_4632_; lean_object* v_all_4633_; lean_object* v___x_4634_; lean_object* v___x_4635_; 
v_val_4632_ = lean_ctor_get(v_val_3923_, 0);
lean_inc_ref(v_val_4632_);
lean_dec_ref_known(v_val_3923_, 1);
v_all_4633_ = lean_ctor_get(v_val_4632_, 1);
lean_inc(v_all_4633_);
lean_dec_ref(v_val_4632_);
v___x_4634_ = lean_box(0);
v___x_4635_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg(v_all_4633_, v___x_4634_, v_a_3813_, v___x_3940_);
lean_dec(v_all_4633_);
if (lean_obj_tag(v___x_4635_) == 0)
{
lean_object* v_a_4636_; lean_object* v___x_4638_; uint8_t v_isShared_4639_; uint8_t v_isSharedCheck_4652_; 
v_a_4636_ = lean_ctor_get(v___x_4635_, 0);
v_isSharedCheck_4652_ = !lean_is_exclusive(v___x_4635_);
if (v_isSharedCheck_4652_ == 0)
{
v___x_4638_ = v___x_4635_;
v_isShared_4639_ = v_isSharedCheck_4652_;
goto v_resetjp_4637_;
}
else
{
lean_inc(v_a_4636_);
lean_dec(v___x_4635_);
v___x_4638_ = lean_box(0);
v_isShared_4639_ = v_isSharedCheck_4652_;
goto v_resetjp_4637_;
}
v_resetjp_4637_:
{
lean_object* v_snd_4640_; lean_object* v___x_4642_; uint8_t v_isShared_4643_; uint8_t v_isSharedCheck_4650_; 
v_snd_4640_ = lean_ctor_get(v_a_4636_, 1);
v_isSharedCheck_4650_ = !lean_is_exclusive(v_a_4636_);
if (v_isSharedCheck_4650_ == 0)
{
lean_object* v_unused_4651_; 
v_unused_4651_ = lean_ctor_get(v_a_4636_, 0);
lean_dec(v_unused_4651_);
v___x_4642_ = v_a_4636_;
v_isShared_4643_ = v_isSharedCheck_4650_;
goto v_resetjp_4641_;
}
else
{
lean_inc(v_snd_4640_);
lean_dec(v_a_4636_);
v___x_4642_ = lean_box(0);
v_isShared_4643_ = v_isSharedCheck_4650_;
goto v_resetjp_4641_;
}
v_resetjp_4641_:
{
lean_object* v___x_4645_; 
if (v_isShared_4643_ == 0)
{
lean_ctor_set(v___x_4642_, 0, v___x_4634_);
v___x_4645_ = v___x_4642_;
goto v_reusejp_4644_;
}
else
{
lean_object* v_reuseFailAlloc_4649_; 
v_reuseFailAlloc_4649_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4649_, 0, v___x_4634_);
lean_ctor_set(v_reuseFailAlloc_4649_, 1, v_snd_4640_);
v___x_4645_ = v_reuseFailAlloc_4649_;
goto v_reusejp_4644_;
}
v_reusejp_4644_:
{
lean_object* v___x_4647_; 
if (v_isShared_4639_ == 0)
{
lean_ctor_set(v___x_4638_, 0, v___x_4645_);
v___x_4647_ = v___x_4638_;
goto v_reusejp_4646_;
}
else
{
lean_object* v_reuseFailAlloc_4648_; 
v_reuseFailAlloc_4648_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4648_, 0, v___x_4645_);
v___x_4647_ = v_reuseFailAlloc_4648_;
goto v_reusejp_4646_;
}
v_reusejp_4646_:
{
return v___x_4647_;
}
}
}
}
}
else
{
return v___x_4635_;
}
}
}
}
}
}
else
{
lean_dec(v_val_3923_);
lean_dec(v_c_3812_);
goto v___jp_3816_;
}
}
v___jp_4661_:
{
if (v___y_4662_ == 0)
{
goto v___jp_3924_;
}
else
{
lean_dec(v_val_3923_);
lean_dec(v_c_3812_);
goto v___jp_3816_;
}
}
}
else
{
uint8_t v_ignoreMissing_4665_; 
lean_dec(v___x_3922_);
v_ignoreMissing_4665_ = lean_ctor_get_uint8(v_a_3814_, sizeof(void*)*6 + 2);
if (v_ignoreMissing_4665_ == 0)
{
lean_object* v___x_4666_; lean_object* v___x_4667_; lean_object* v___x_4668_; lean_object* v___x_4669_; lean_object* v___x_4670_; uint8_t v___x_4671_; lean_object* v___x_4672_; lean_object* v___x_4673_; lean_object* v___x_4674_; lean_object* v___x_4675_; lean_object* v___x_4676_; lean_object* v___x_4677_; 
v___x_4666_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpName___closed__1));
v___x_4667_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00CheckedExport_dumpConstant_spec__12___closed__0));
v___x_4668_ = lean_unsigned_to_nat(210u);
v___x_4669_ = lean_unsigned_to_nat(48u);
v___x_4670_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__1));
v___x_4671_ = 1;
v___x_4672_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_c_3812_, v___x_4671_);
v___x_4673_ = lean_string_append(v___x_4670_, v___x_4672_);
lean_dec_ref(v___x_4672_);
v___x_4674_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___closed__2));
v___x_4675_ = lean_string_append(v___x_4673_, v___x_4674_);
v___x_4676_ = l_mkPanicMessageWithDecl(v___x_4666_, v___x_4667_, v___x_4668_, v___x_4669_, v___x_4675_);
lean_dec_ref(v___x_4675_);
v___x_4677_ = lp_proofEnvironment_panic___at___00CheckedExport_dumpConstant_spec__4(v___x_4676_, v_a_3813_, v_a_3814_);
return v___x_4677_;
}
else
{
lean_object* v___x_4678_; lean_object* v___x_4679_; lean_object* v___x_4680_; 
lean_dec(v_c_3812_);
v___x_4678_ = lean_box(0);
v___x_4679_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4679_, 0, v___x_4678_);
lean_ctor_set(v___x_4679_, 1, v_a_3814_);
v___x_4680_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4680_, 0, v___x_4679_);
return v___x_4680_;
}
}
v___jp_3816_:
{
lean_object* v___x_3817_; lean_object* v___x_3818_; lean_object* v___x_3819_; 
v___x_3817_ = lean_box(0);
v___x_3818_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3818_, 0, v___x_3817_);
lean_ctor_set(v___x_3818_, 1, v_a_3814_);
v___x_3819_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3819_, 0, v___x_3818_);
return v___x_3819_;
}
v___jp_3820_:
{
size_t v_sz_3828_; lean_object* v___x_3829_; 
v_sz_3828_ = lean_array_size(v_fst_3826_);
v___x_3829_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__13(v_fst_3826_, v_sz_3828_, v___y_3823_, v___y_3824_, v_a_3813_, v_snd_3827_);
if (lean_obj_tag(v___x_3829_) == 0)
{
lean_object* v_a_3830_; lean_object* v_snd_3831_; lean_object* v___x_3833_; uint8_t v_isShared_3834_; uint8_t v_isSharedCheck_3920_; 
v_a_3830_ = lean_ctor_get(v___x_3829_, 0);
lean_inc(v_a_3830_);
lean_dec_ref_known(v___x_3829_, 1);
v_snd_3831_ = lean_ctor_get(v_a_3830_, 1);
v_isSharedCheck_3920_ = !lean_is_exclusive(v_a_3830_);
if (v_isSharedCheck_3920_ == 0)
{
lean_object* v_unused_3921_; 
v_unused_3921_ = lean_ctor_get(v_a_3830_, 0);
lean_dec(v_unused_3921_);
v___x_3833_ = v_a_3830_;
v_isShared_3834_ = v_isSharedCheck_3920_;
goto v_resetjp_3832_;
}
else
{
lean_inc(v_snd_3831_);
lean_dec(v_a_3830_);
v___x_3833_ = lean_box(0);
v_isShared_3834_ = v_isSharedCheck_3920_;
goto v_resetjp_3832_;
}
v_resetjp_3832_:
{
lean_object* v___x_3835_; 
v___x_3835_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__14(v_fst_3826_, v_sz_3828_, v___y_3823_, v___y_3824_, v_a_3813_, v_snd_3831_);
if (lean_obj_tag(v___x_3835_) == 0)
{
lean_object* v_a_3836_; lean_object* v_snd_3837_; lean_object* v___x_3839_; uint8_t v_isShared_3840_; uint8_t v_isSharedCheck_3918_; 
v_a_3836_ = lean_ctor_get(v___x_3835_, 0);
lean_inc(v_a_3836_);
lean_dec_ref_known(v___x_3835_, 1);
v_snd_3837_ = lean_ctor_get(v_a_3836_, 1);
v_isSharedCheck_3918_ = !lean_is_exclusive(v_a_3836_);
if (v_isSharedCheck_3918_ == 0)
{
lean_object* v_unused_3919_; 
v_unused_3919_ = lean_ctor_get(v_a_3836_, 0);
lean_dec(v_unused_3919_);
v___x_3839_ = v_a_3836_;
v_isShared_3840_ = v_isSharedCheck_3918_;
goto v_resetjp_3838_;
}
else
{
lean_inc(v_snd_3837_);
lean_dec(v_a_3836_);
v___x_3839_ = lean_box(0);
v_isShared_3840_ = v_isSharedCheck_3918_;
goto v_resetjp_3838_;
}
v_resetjp_3838_:
{
size_t v_sz_3841_; lean_object* v___x_3842_; 
v_sz_3841_ = lean_array_size(v___y_3822_);
v___x_3842_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15(v_sz_3841_, v___y_3823_, v___y_3822_, v_a_3813_, v_snd_3837_);
if (lean_obj_tag(v___x_3842_) == 0)
{
lean_object* v_a_3843_; lean_object* v_fst_3844_; lean_object* v_snd_3845_; lean_object* v___x_3847_; uint8_t v_isShared_3848_; uint8_t v_isSharedCheck_3909_; 
v_a_3843_ = lean_ctor_get(v___x_3842_, 0);
lean_inc(v_a_3843_);
lean_dec_ref_known(v___x_3842_, 1);
v_fst_3844_ = lean_ctor_get(v_a_3843_, 0);
v_snd_3845_ = lean_ctor_get(v_a_3843_, 1);
v_isSharedCheck_3909_ = !lean_is_exclusive(v_a_3843_);
if (v_isSharedCheck_3909_ == 0)
{
v___x_3847_ = v_a_3843_;
v_isShared_3848_ = v_isSharedCheck_3909_;
goto v_resetjp_3846_;
}
else
{
lean_inc(v_snd_3845_);
lean_inc(v_fst_3844_);
lean_dec(v_a_3843_);
v___x_3847_ = lean_box(0);
v_isShared_3848_ = v_isSharedCheck_3909_;
goto v_resetjp_3846_;
}
v_resetjp_3846_:
{
lean_object* v___x_3849_; 
v___x_3849_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16(v___y_3821_, v___y_3823_, v___y_3825_, v_a_3813_, v_snd_3845_);
if (lean_obj_tag(v___x_3849_) == 0)
{
lean_object* v_a_3850_; lean_object* v_fst_3851_; lean_object* v_snd_3852_; lean_object* v___x_3854_; uint8_t v_isShared_3855_; uint8_t v_isSharedCheck_3900_; 
v_a_3850_ = lean_ctor_get(v___x_3849_, 0);
lean_inc(v_a_3850_);
lean_dec_ref_known(v___x_3849_, 1);
v_fst_3851_ = lean_ctor_get(v_a_3850_, 0);
v_snd_3852_ = lean_ctor_get(v_a_3850_, 1);
v_isSharedCheck_3900_ = !lean_is_exclusive(v_a_3850_);
if (v_isSharedCheck_3900_ == 0)
{
v___x_3854_ = v_a_3850_;
v_isShared_3855_ = v_isSharedCheck_3900_;
goto v_resetjp_3853_;
}
else
{
lean_inc(v_snd_3852_);
lean_inc(v_fst_3851_);
lean_dec(v_a_3850_);
v___x_3854_ = lean_box(0);
v_isShared_3855_ = v_isSharedCheck_3900_;
goto v_resetjp_3853_;
}
v_resetjp_3853_:
{
lean_object* v___x_3856_; 
v___x_3856_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17(v_sz_3828_, v___y_3823_, v_fst_3826_, v_a_3813_, v_snd_3852_);
if (lean_obj_tag(v___x_3856_) == 0)
{
lean_object* v_a_3857_; lean_object* v_fst_3858_; lean_object* v_snd_3859_; lean_object* v___x_3861_; uint8_t v_isShared_3862_; uint8_t v_isSharedCheck_3891_; 
v_a_3857_ = lean_ctor_get(v___x_3856_, 0);
lean_inc(v_a_3857_);
lean_dec_ref_known(v___x_3856_, 1);
v_fst_3858_ = lean_ctor_get(v_a_3857_, 0);
v_snd_3859_ = lean_ctor_get(v_a_3857_, 1);
v_isSharedCheck_3891_ = !lean_is_exclusive(v_a_3857_);
if (v_isSharedCheck_3891_ == 0)
{
v___x_3861_ = v_a_3857_;
v_isShared_3862_ = v_isSharedCheck_3891_;
goto v_resetjp_3860_;
}
else
{
lean_inc(v_snd_3859_);
lean_inc(v_fst_3858_);
lean_dec(v_a_3857_);
v___x_3861_ = lean_box(0);
v_isShared_3862_ = v_isSharedCheck_3891_;
goto v_resetjp_3860_;
}
v_resetjp_3860_:
{
lean_object* v___x_3863_; lean_object* v___x_3864_; lean_object* v___x_3865_; lean_object* v___x_3867_; 
v___x_3863_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__0));
v___x_3864_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__1));
v___x_3865_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_3844_);
if (v_isShared_3862_ == 0)
{
lean_ctor_set(v___x_3861_, 1, v___x_3865_);
lean_ctor_set(v___x_3861_, 0, v___x_3864_);
v___x_3867_ = v___x_3861_;
goto v_reusejp_3866_;
}
else
{
lean_object* v_reuseFailAlloc_3890_; 
v_reuseFailAlloc_3890_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3890_, 0, v___x_3864_);
lean_ctor_set(v_reuseFailAlloc_3890_, 1, v___x_3865_);
v___x_3867_ = v_reuseFailAlloc_3890_;
goto v_reusejp_3866_;
}
v_reusejp_3866_:
{
lean_object* v___x_3868_; lean_object* v___x_3869_; lean_object* v___x_3871_; 
v___x_3868_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___closed__2));
v___x_3869_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_3851_);
if (v_isShared_3855_ == 0)
{
lean_ctor_set(v___x_3854_, 1, v___x_3869_);
lean_ctor_set(v___x_3854_, 0, v___x_3868_);
v___x_3871_ = v___x_3854_;
goto v_reusejp_3870_;
}
else
{
lean_object* v_reuseFailAlloc_3889_; 
v_reuseFailAlloc_3889_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3889_, 0, v___x_3868_);
lean_ctor_set(v_reuseFailAlloc_3889_, 1, v___x_3869_);
v___x_3871_ = v_reuseFailAlloc_3889_;
goto v_reusejp_3870_;
}
v_reusejp_3870_:
{
lean_object* v___x_3872_; lean_object* v___x_3873_; lean_object* v___x_3875_; 
v___x_3872_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_dumpConstant___closed__2));
v___x_3873_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_3858_);
if (v_isShared_3848_ == 0)
{
lean_ctor_set(v___x_3847_, 1, v___x_3873_);
lean_ctor_set(v___x_3847_, 0, v___x_3872_);
v___x_3875_ = v___x_3847_;
goto v_reusejp_3874_;
}
else
{
lean_object* v_reuseFailAlloc_3888_; 
v_reuseFailAlloc_3888_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3888_, 0, v___x_3872_);
lean_ctor_set(v_reuseFailAlloc_3888_, 1, v___x_3873_);
v___x_3875_ = v_reuseFailAlloc_3888_;
goto v_reusejp_3874_;
}
v_reusejp_3874_:
{
lean_object* v___x_3876_; lean_object* v___x_3878_; 
v___x_3876_ = lean_box(0);
if (v_isShared_3834_ == 0)
{
lean_ctor_set_tag(v___x_3833_, 1);
lean_ctor_set(v___x_3833_, 1, v___x_3876_);
lean_ctor_set(v___x_3833_, 0, v___x_3875_);
v___x_3878_ = v___x_3833_;
goto v_reusejp_3877_;
}
else
{
lean_object* v_reuseFailAlloc_3887_; 
v_reuseFailAlloc_3887_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3887_, 0, v___x_3875_);
lean_ctor_set(v_reuseFailAlloc_3887_, 1, v___x_3876_);
v___x_3878_ = v_reuseFailAlloc_3887_;
goto v_reusejp_3877_;
}
v_reusejp_3877_:
{
lean_object* v___x_3879_; lean_object* v___x_3880_; lean_object* v___x_3881_; lean_object* v___x_3883_; 
v___x_3879_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3879_, 0, v___x_3871_);
lean_ctor_set(v___x_3879_, 1, v___x_3878_);
v___x_3880_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3880_, 0, v___x_3867_);
lean_ctor_set(v___x_3880_, 1, v___x_3879_);
v___x_3881_ = l_Lean_Json_mkObj(v___x_3880_);
lean_dec_ref_known(v___x_3880_, 2);
if (v_isShared_3840_ == 0)
{
lean_ctor_set(v___x_3839_, 1, v___x_3881_);
lean_ctor_set(v___x_3839_, 0, v___x_3863_);
v___x_3883_ = v___x_3839_;
goto v_reusejp_3882_;
}
else
{
lean_object* v_reuseFailAlloc_3886_; 
v_reuseFailAlloc_3886_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3886_, 0, v___x_3863_);
lean_ctor_set(v_reuseFailAlloc_3886_, 1, v___x_3881_);
v___x_3883_ = v_reuseFailAlloc_3886_;
goto v_reusejp_3882_;
}
v_reusejp_3882_:
{
lean_object* v___x_3884_; lean_object* v___x_3885_; 
v___x_3884_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3884_, 0, v___x_3883_);
lean_ctor_set(v___x_3884_, 1, v___x_3876_);
v___x_3885_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpObj___redArg(v___x_3884_, v_snd_3859_);
lean_dec_ref_known(v___x_3884_, 2);
return v___x_3885_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3892_; lean_object* v___x_3894_; uint8_t v_isShared_3895_; uint8_t v_isSharedCheck_3899_; 
lean_del_object(v___x_3854_);
lean_dec(v_fst_3851_);
lean_del_object(v___x_3847_);
lean_dec(v_fst_3844_);
lean_del_object(v___x_3839_);
lean_del_object(v___x_3833_);
v_a_3892_ = lean_ctor_get(v___x_3856_, 0);
v_isSharedCheck_3899_ = !lean_is_exclusive(v___x_3856_);
if (v_isSharedCheck_3899_ == 0)
{
v___x_3894_ = v___x_3856_;
v_isShared_3895_ = v_isSharedCheck_3899_;
goto v_resetjp_3893_;
}
else
{
lean_inc(v_a_3892_);
lean_dec(v___x_3856_);
v___x_3894_ = lean_box(0);
v_isShared_3895_ = v_isSharedCheck_3899_;
goto v_resetjp_3893_;
}
v_resetjp_3893_:
{
lean_object* v___x_3897_; 
if (v_isShared_3895_ == 0)
{
v___x_3897_ = v___x_3894_;
goto v_reusejp_3896_;
}
else
{
lean_object* v_reuseFailAlloc_3898_; 
v_reuseFailAlloc_3898_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3898_, 0, v_a_3892_);
v___x_3897_ = v_reuseFailAlloc_3898_;
goto v_reusejp_3896_;
}
v_reusejp_3896_:
{
return v___x_3897_;
}
}
}
}
}
else
{
lean_object* v_a_3901_; lean_object* v___x_3903_; uint8_t v_isShared_3904_; uint8_t v_isSharedCheck_3908_; 
lean_del_object(v___x_3847_);
lean_dec(v_fst_3844_);
lean_del_object(v___x_3839_);
lean_del_object(v___x_3833_);
lean_dec_ref(v_fst_3826_);
v_a_3901_ = lean_ctor_get(v___x_3849_, 0);
v_isSharedCheck_3908_ = !lean_is_exclusive(v___x_3849_);
if (v_isSharedCheck_3908_ == 0)
{
v___x_3903_ = v___x_3849_;
v_isShared_3904_ = v_isSharedCheck_3908_;
goto v_resetjp_3902_;
}
else
{
lean_inc(v_a_3901_);
lean_dec(v___x_3849_);
v___x_3903_ = lean_box(0);
v_isShared_3904_ = v_isSharedCheck_3908_;
goto v_resetjp_3902_;
}
v_resetjp_3902_:
{
lean_object* v___x_3906_; 
if (v_isShared_3904_ == 0)
{
v___x_3906_ = v___x_3903_;
goto v_reusejp_3905_;
}
else
{
lean_object* v_reuseFailAlloc_3907_; 
v_reuseFailAlloc_3907_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3907_, 0, v_a_3901_);
v___x_3906_ = v_reuseFailAlloc_3907_;
goto v_reusejp_3905_;
}
v_reusejp_3905_:
{
return v___x_3906_;
}
}
}
}
}
else
{
lean_object* v_a_3910_; lean_object* v___x_3912_; uint8_t v_isShared_3913_; uint8_t v_isSharedCheck_3917_; 
lean_del_object(v___x_3839_);
lean_del_object(v___x_3833_);
lean_dec_ref(v_fst_3826_);
lean_dec(v___y_3825_);
v_a_3910_ = lean_ctor_get(v___x_3842_, 0);
v_isSharedCheck_3917_ = !lean_is_exclusive(v___x_3842_);
if (v_isSharedCheck_3917_ == 0)
{
v___x_3912_ = v___x_3842_;
v_isShared_3913_ = v_isSharedCheck_3917_;
goto v_resetjp_3911_;
}
else
{
lean_inc(v_a_3910_);
lean_dec(v___x_3842_);
v___x_3912_ = lean_box(0);
v_isShared_3913_ = v_isSharedCheck_3917_;
goto v_resetjp_3911_;
}
v_resetjp_3911_:
{
lean_object* v___x_3915_; 
if (v_isShared_3913_ == 0)
{
v___x_3915_ = v___x_3912_;
goto v_reusejp_3914_;
}
else
{
lean_object* v_reuseFailAlloc_3916_; 
v_reuseFailAlloc_3916_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3916_, 0, v_a_3910_);
v___x_3915_ = v_reuseFailAlloc_3916_;
goto v_reusejp_3914_;
}
v_reusejp_3914_:
{
return v___x_3915_;
}
}
}
}
}
else
{
lean_del_object(v___x_3833_);
lean_dec_ref(v_fst_3826_);
lean_dec(v___y_3825_);
lean_dec(v___y_3822_);
return v___x_3835_;
}
}
}
else
{
lean_dec_ref(v_fst_3826_);
lean_dec(v___y_3825_);
lean_dec(v___y_3822_);
return v___x_3829_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0(lean_object* v_as_4681_, size_t v_sz_4682_, size_t v_i_4683_, lean_object* v_b_4684_, lean_object* v___y_4685_, lean_object* v___y_4686_){
_start:
{
uint8_t v___x_4688_; 
v___x_4688_ = lean_usize_dec_lt(v_i_4683_, v_sz_4682_);
if (v___x_4688_ == 0)
{
lean_object* v___x_4689_; lean_object* v___x_4690_; 
v___x_4689_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4689_, 0, v_b_4684_);
lean_ctor_set(v___x_4689_, 1, v___y_4686_);
v___x_4690_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4690_, 0, v___x_4689_);
return v___x_4690_;
}
else
{
lean_object* v_a_4691_; lean_object* v___x_4692_; 
v_a_4691_ = lean_array_uget_borrowed(v_as_4681_, v_i_4683_);
lean_inc(v_a_4691_);
v___x_4692_ = lp_proofEnvironment_CheckedExport_dumpConstant(v_a_4691_, v___y_4685_, v___y_4686_);
if (lean_obj_tag(v___x_4692_) == 0)
{
lean_object* v_a_4693_; lean_object* v_snd_4694_; lean_object* v___x_4695_; size_t v___x_4696_; size_t v___x_4697_; 
v_a_4693_ = lean_ctor_get(v___x_4692_, 0);
lean_inc(v_a_4693_);
lean_dec_ref_known(v___x_4692_, 1);
v_snd_4694_ = lean_ctor_get(v_a_4693_, 1);
lean_inc(v_snd_4694_);
lean_dec(v_a_4693_);
v___x_4695_ = lean_box(0);
v___x_4696_ = ((size_t)1ULL);
v___x_4697_ = lean_usize_add(v_i_4683_, v___x_4696_);
v_i_4683_ = v___x_4697_;
v_b_4684_ = v___x_4695_;
v___y_4686_ = v_snd_4694_;
goto _start;
}
else
{
return v___x_4692_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(lean_object* v_e_4699_, lean_object* v_a_4700_, lean_object* v_a_4701_){
_start:
{
lean_object* v___x_4703_; lean_object* v___x_4704_; size_t v_sz_4705_; size_t v___x_4706_; lean_object* v___x_4707_; 
v___x_4703_ = l_Lean_Expr_getUsedConstants(v_e_4699_);
v___x_4704_ = lean_box(0);
v_sz_4705_ = lean_array_size(v___x_4703_);
v___x_4706_ = ((size_t)0ULL);
v___x_4707_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0(v___x_4703_, v_sz_4705_, v___x_4706_, v___x_4704_, v_a_4700_, v_a_4701_);
lean_dec_ref(v___x_4703_);
if (lean_obj_tag(v___x_4707_) == 0)
{
lean_object* v_a_4708_; lean_object* v___x_4710_; uint8_t v_isShared_4711_; uint8_t v_isSharedCheck_4724_; 
v_a_4708_ = lean_ctor_get(v___x_4707_, 0);
v_isSharedCheck_4724_ = !lean_is_exclusive(v___x_4707_);
if (v_isSharedCheck_4724_ == 0)
{
v___x_4710_ = v___x_4707_;
v_isShared_4711_ = v_isSharedCheck_4724_;
goto v_resetjp_4709_;
}
else
{
lean_inc(v_a_4708_);
lean_dec(v___x_4707_);
v___x_4710_ = lean_box(0);
v_isShared_4711_ = v_isSharedCheck_4724_;
goto v_resetjp_4709_;
}
v_resetjp_4709_:
{
lean_object* v_snd_4712_; lean_object* v___x_4714_; uint8_t v_isShared_4715_; uint8_t v_isSharedCheck_4722_; 
v_snd_4712_ = lean_ctor_get(v_a_4708_, 1);
v_isSharedCheck_4722_ = !lean_is_exclusive(v_a_4708_);
if (v_isSharedCheck_4722_ == 0)
{
lean_object* v_unused_4723_; 
v_unused_4723_ = lean_ctor_get(v_a_4708_, 0);
lean_dec(v_unused_4723_);
v___x_4714_ = v_a_4708_;
v_isShared_4715_ = v_isSharedCheck_4722_;
goto v_resetjp_4713_;
}
else
{
lean_inc(v_snd_4712_);
lean_dec(v_a_4708_);
v___x_4714_ = lean_box(0);
v_isShared_4715_ = v_isSharedCheck_4722_;
goto v_resetjp_4713_;
}
v_resetjp_4713_:
{
lean_object* v___x_4717_; 
if (v_isShared_4715_ == 0)
{
lean_ctor_set(v___x_4714_, 0, v___x_4704_);
v___x_4717_ = v___x_4714_;
goto v_reusejp_4716_;
}
else
{
lean_object* v_reuseFailAlloc_4721_; 
v_reuseFailAlloc_4721_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4721_, 0, v___x_4704_);
lean_ctor_set(v_reuseFailAlloc_4721_, 1, v_snd_4712_);
v___x_4717_ = v_reuseFailAlloc_4721_;
goto v_reusejp_4716_;
}
v_reusejp_4716_:
{
lean_object* v___x_4719_; 
if (v_isShared_4711_ == 0)
{
lean_ctor_set(v___x_4710_, 0, v___x_4717_);
v___x_4719_ = v___x_4710_;
goto v_reusejp_4718_;
}
else
{
lean_object* v_reuseFailAlloc_4720_; 
v_reuseFailAlloc_4720_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4720_, 0, v___x_4717_);
v___x_4719_ = v_reuseFailAlloc_4720_;
goto v_reusejp_4718_;
}
v_reusejp_4718_:
{
return v___x_4719_;
}
}
}
}
}
else
{
return v___x_4707_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps___boxed(lean_object* v_e_4725_, lean_object* v_a_4726_, lean_object* v_a_4727_, lean_object* v_a_4728_){
_start:
{
lean_object* v_res_4729_; 
v_res_4729_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpDeps(v_e_4725_, v_a_4726_, v_a_4727_);
lean_dec_ref(v_a_4726_);
return v_res_4729_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg___boxed(lean_object* v_as_x27_4730_, lean_object* v_b_4731_, lean_object* v___y_4732_, lean_object* v___y_4733_, lean_object* v___y_4734_){
_start:
{
lean_object* v_res_4735_; 
v_res_4735_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg(v_as_x27_4730_, v_b_4731_, v___y_4732_, v___y_4733_);
lean_dec_ref(v___y_4732_);
lean_dec(v_as_x27_4730_);
return v_res_4735_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg___boxed(lean_object* v_as_x27_4736_, lean_object* v_b_4737_, lean_object* v___y_4738_, lean_object* v___y_4739_, lean_object* v___y_4740_){
_start:
{
lean_object* v_res_4741_; 
v_res_4741_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg(v_as_x27_4736_, v_b_4737_, v___y_4738_, v___y_4739_);
lean_dec_ref(v___y_4738_);
lean_dec(v_as_x27_4736_);
return v_res_4741_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpConstant_spec__2___boxed(lean_object* v_x_4742_, lean_object* v_x_4743_, lean_object* v___y_4744_, lean_object* v___y_4745_, lean_object* v___y_4746_){
_start:
{
lean_object* v_res_4747_; 
v_res_4747_ = lp_proofEnvironment_List_mapM_loop___at___00CheckedExport_dumpConstant_spec__2(v_x_4742_, v_x_4743_, v___y_4744_, v___y_4745_);
lean_dec_ref(v___y_4744_);
return v_res_4747_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0___boxed(lean_object* v_as_4748_, lean_object* v_sz_4749_, lean_object* v_i_4750_, lean_object* v_b_4751_, lean_object* v___y_4752_, lean_object* v___y_4753_, lean_object* v___y_4754_){
_start:
{
size_t v_sz_boxed_4755_; size_t v_i_boxed_4756_; lean_object* v_res_4757_; 
v_sz_boxed_4755_ = lean_unbox_usize(v_sz_4749_);
lean_dec(v_sz_4749_);
v_i_boxed_4756_ = lean_unbox_usize(v_i_4750_);
lean_dec(v_i_4750_);
v_res_4757_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0(v_as_4748_, v_sz_boxed_4755_, v_i_boxed_4756_, v_b_4751_, v___y_4752_, v___y_4753_);
lean_dec_ref(v___y_4752_);
lean_dec_ref(v_as_4748_);
return v_res_4757_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps___boxed(lean_object* v_a_4758_, lean_object* v_a_4759_, lean_object* v_a_4760_){
_start:
{
lean_object* v_res_4761_; 
v_res_4761_ = lp_proofEnvironment_CheckedExport_dumpExprAux_dumpNatDeps(v_a_4758_, v_a_4759_);
lean_dec_ref(v_a_4758_);
return v_res_4761_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__14___boxed(lean_object* v_as_4762_, lean_object* v_sz_4763_, lean_object* v_i_4764_, lean_object* v_b_4765_, lean_object* v___y_4766_, lean_object* v___y_4767_, lean_object* v___y_4768_){
_start:
{
size_t v_sz_boxed_4769_; size_t v_i_boxed_4770_; lean_object* v_res_4771_; 
v_sz_boxed_4769_ = lean_unbox_usize(v_sz_4763_);
lean_dec(v_sz_4763_);
v_i_boxed_4770_ = lean_unbox_usize(v_i_4764_);
lean_dec(v_i_4764_);
v_res_4771_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__14(v_as_4762_, v_sz_boxed_4769_, v_i_boxed_4770_, v_b_4765_, v___y_4766_, v___y_4767_);
lean_dec_ref(v___y_4766_);
lean_dec_ref(v_as_4762_);
return v_res_4771_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExpr___boxed(lean_object* v_e_4772_, lean_object* v_a_4773_, lean_object* v_a_4774_, lean_object* v_a_4775_){
_start:
{
lean_object* v_res_4776_; 
v_res_4776_ = lp_proofEnvironment_CheckedExport_dumpExpr(v_e_4772_, v_a_4773_, v_a_4774_);
lean_dec_ref(v_a_4773_);
return v_res_4776_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__11___boxed(lean_object* v_as_4777_, lean_object* v_sz_4778_, lean_object* v_i_4779_, lean_object* v_b_4780_, lean_object* v___y_4781_, lean_object* v___y_4782_, lean_object* v___y_4783_){
_start:
{
size_t v_sz_boxed_4784_; size_t v_i_boxed_4785_; lean_object* v_res_4786_; 
v_sz_boxed_4784_ = lean_unbox_usize(v_sz_4778_);
lean_dec(v_sz_4778_);
v_i_boxed_4785_ = lean_unbox_usize(v_i_4779_);
lean_dec(v_i_4779_);
v_res_4786_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__11(v_as_4777_, v_sz_boxed_4784_, v_i_boxed_4785_, v_b_4780_, v___y_4781_, v___y_4782_);
lean_dec_ref(v___y_4781_);
lean_dec_ref(v_as_4777_);
return v_res_4786_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__13___boxed(lean_object* v_as_4787_, lean_object* v_sz_4788_, lean_object* v_i_4789_, lean_object* v_b_4790_, lean_object* v___y_4791_, lean_object* v___y_4792_, lean_object* v___y_4793_){
_start:
{
size_t v_sz_boxed_4794_; size_t v_i_boxed_4795_; lean_object* v_res_4796_; 
v_sz_boxed_4794_ = lean_unbox_usize(v_sz_4788_);
lean_dec(v_sz_4788_);
v_i_boxed_4795_ = lean_unbox_usize(v_i_4789_);
lean_dec(v_i_4789_);
v_res_4796_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_spec__13(v_as_4787_, v_sz_boxed_4794_, v_i_boxed_4795_, v_b_4790_, v___y_4791_, v___y_4792_);
lean_dec_ref(v___y_4791_);
lean_dec_ref(v_as_4787_);
return v_res_4796_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule___boxed(lean_object* v_rule_4797_, lean_object* v_a_4798_, lean_object* v_a_4799_, lean_object* v_a_4800_){
_start:
{
lean_object* v_res_4801_; 
v_res_4801_ = lp_proofEnvironment_CheckedExport_dumpConstant_dumpRecRule(v_rule_4797_, v_a_4798_, v_a_4799_);
lean_dec_ref(v_a_4798_);
return v_res_4801_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps___boxed(lean_object* v_a_4802_, lean_object* v_a_4803_, lean_object* v_a_4804_){
_start:
{
lean_object* v_res_4805_; 
v_res_4805_ = lp_proofEnvironment_CheckedExport_dumpExprAux_dumpStrDeps(v_a_4802_, v_a_4803_);
lean_dec_ref(v_a_4802_);
return v_res_4805_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16___boxed(lean_object* v_sz_4806_, lean_object* v_i_4807_, lean_object* v_bs_4808_, lean_object* v___y_4809_, lean_object* v___y_4810_, lean_object* v___y_4811_){
_start:
{
size_t v_sz_boxed_4812_; size_t v_i_boxed_4813_; lean_object* v_res_4814_; 
v_sz_boxed_4812_ = lean_unbox_usize(v_sz_4806_);
lean_dec(v_sz_4806_);
v_i_boxed_4813_ = lean_unbox_usize(v_i_4807_);
lean_dec(v_i_4807_);
v_res_4814_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__16(v_sz_boxed_4812_, v_i_boxed_4813_, v_bs_4808_, v___y_4809_, v___y_4810_);
lean_dec_ref(v___y_4809_);
return v_res_4814_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg___boxed(lean_object* v_as_x27_4815_, lean_object* v_b_4816_, lean_object* v___y_4817_, lean_object* v___y_4818_, lean_object* v___y_4819_){
_start:
{
lean_object* v_res_4820_; 
v_res_4820_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg(v_as_x27_4815_, v_b_4816_, v___y_4817_, v___y_4818_);
lean_dec_ref(v___y_4817_);
lean_dec(v_as_x27_4815_);
return v_res_4820_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15___boxed(lean_object* v_sz_4821_, lean_object* v_i_4822_, lean_object* v_bs_4823_, lean_object* v___y_4824_, lean_object* v___y_4825_, lean_object* v___y_4826_){
_start:
{
size_t v_sz_boxed_4827_; size_t v_i_boxed_4828_; lean_object* v_res_4829_; 
v_sz_boxed_4827_ = lean_unbox_usize(v_sz_4821_);
lean_dec(v_sz_4821_);
v_i_boxed_4828_ = lean_unbox_usize(v_i_4822_);
lean_dec(v_i_4822_);
v_res_4829_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__15(v_sz_boxed_4827_, v_i_boxed_4828_, v_bs_4823_, v___y_4824_, v___y_4825_);
lean_dec_ref(v___y_4824_);
return v_res_4829_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17___boxed(lean_object* v_sz_4830_, lean_object* v_i_4831_, lean_object* v_bs_4832_, lean_object* v___y_4833_, lean_object* v___y_4834_, lean_object* v___y_4835_){
_start:
{
size_t v_sz_boxed_4836_; size_t v_i_boxed_4837_; lean_object* v_res_4838_; 
v_sz_boxed_4836_ = lean_unbox_usize(v_sz_4830_);
lean_dec(v_sz_4830_);
v_i_boxed_4837_ = lean_unbox_usize(v_i_4831_);
lean_dec(v_i_4831_);
v_res_4838_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00CheckedExport_dumpConstant_spec__17(v_sz_boxed_4836_, v_i_boxed_4837_, v_bs_4832_, v___y_4833_, v___y_4834_);
lean_dec_ref(v___y_4833_);
return v_res_4838_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg___boxed(lean_object* v___x_4839_, lean_object* v_val_4840_, lean_object* v_as_x27_4841_, lean_object* v_b_4842_, lean_object* v___y_4843_, lean_object* v___y_4844_, lean_object* v___y_4845_){
_start:
{
uint8_t v___x_183385__boxed_4846_; lean_object* v_res_4847_; 
v___x_183385__boxed_4846_ = lean_unbox(v___x_4839_);
v_res_4847_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg(v___x_183385__boxed_4846_, v_val_4840_, v_as_x27_4841_, v_b_4842_, v___y_4843_, v___y_4844_);
lean_dec_ref(v___y_4843_);
lean_dec(v_as_x27_4841_);
lean_dec_ref(v_val_4840_);
return v_res_4847_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpExprAux___boxed(lean_object* v_e_4848_, lean_object* v_a_4849_, lean_object* v_a_4850_, lean_object* v_a_4851_){
_start:
{
lean_object* v_res_4852_; 
v_res_4852_ = lp_proofEnvironment_CheckedExport_dumpExprAux(v_e_4848_, v_a_4849_, v_a_4850_);
lean_dec_ref(v_a_4849_);
return v_res_4852_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpConstant___boxed(lean_object* v_c_4853_, lean_object* v_a_4854_, lean_object* v_a_4855_, lean_object* v_a_4856_){
_start:
{
lean_object* v_res_4857_; 
v_res_4857_ = lp_proofEnvironment_CheckedExport_dumpConstant(v_c_4853_, v_a_4854_, v_a_4855_);
lean_dec_ref(v_a_4854_);
return v_res_4857_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5(lean_object* v_as_4858_, lean_object* v_as_x27_4859_, lean_object* v_b_4860_, lean_object* v_a_4861_, lean_object* v___y_4862_, lean_object* v___y_4863_){
_start:
{
lean_object* v___x_4865_; 
v___x_4865_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___redArg(v_as_x27_4859_, v_b_4860_, v___y_4862_, v___y_4863_);
return v___x_4865_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5___boxed(lean_object* v_as_4866_, lean_object* v_as_x27_4867_, lean_object* v_b_4868_, lean_object* v_a_4869_, lean_object* v___y_4870_, lean_object* v___y_4871_, lean_object* v___y_4872_){
_start:
{
lean_object* v_res_4873_; 
v_res_4873_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__5(v_as_4866_, v_as_x27_4867_, v_b_4868_, v_a_4869_, v___y_4870_, v___y_4871_);
lean_dec_ref(v___y_4870_);
lean_dec(v_as_x27_4867_);
lean_dec(v_as_4866_);
return v_res_4873_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7(uint8_t v___y_4874_, uint8_t v___x_4875_, lean_object* v_as_4876_, lean_object* v_as_x27_4877_, lean_object* v_b_4878_, lean_object* v_a_4879_, lean_object* v___y_4880_, lean_object* v___y_4881_){
_start:
{
lean_object* v___x_4883_; 
v___x_4883_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___redArg(v___y_4874_, v___x_4875_, v_as_x27_4877_, v_b_4878_, v___y_4880_, v___y_4881_);
return v___x_4883_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7___boxed(lean_object* v___y_4884_, lean_object* v___x_4885_, lean_object* v_as_4886_, lean_object* v_as_x27_4887_, lean_object* v_b_4888_, lean_object* v_a_4889_, lean_object* v___y_4890_, lean_object* v___y_4891_, lean_object* v___y_4892_){
_start:
{
uint8_t v___y_187970__boxed_4893_; uint8_t v___x_187971__boxed_4894_; lean_object* v_res_4895_; 
v___y_187970__boxed_4893_ = lean_unbox(v___y_4884_);
v___x_187971__boxed_4894_ = lean_unbox(v___x_4885_);
v_res_4895_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__7(v___y_187970__boxed_4893_, v___x_187971__boxed_4894_, v_as_4886_, v_as_x27_4887_, v_b_4888_, v_a_4889_, v___y_4890_, v___y_4891_);
lean_dec_ref(v___y_4890_);
lean_dec(v_as_x27_4887_);
lean_dec(v_as_4886_);
return v_res_4895_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9(uint8_t v___x_4896_, lean_object* v_val_4897_, lean_object* v_as_4898_, lean_object* v_as_x27_4899_, lean_object* v_b_4900_, lean_object* v_a_4901_, lean_object* v___y_4902_, lean_object* v___y_4903_){
_start:
{
lean_object* v___x_4905_; 
v___x_4905_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___redArg(v___x_4896_, v_val_4897_, v_as_x27_4899_, v_b_4900_, v___y_4902_, v___y_4903_);
return v___x_4905_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9___boxed(lean_object* v___x_4906_, lean_object* v_val_4907_, lean_object* v_as_4908_, lean_object* v_as_x27_4909_, lean_object* v_b_4910_, lean_object* v_a_4911_, lean_object* v___y_4912_, lean_object* v___y_4913_, lean_object* v___y_4914_){
_start:
{
uint8_t v___x_187990__boxed_4915_; lean_object* v_res_4916_; 
v___x_187990__boxed_4915_ = lean_unbox(v___x_4906_);
v_res_4916_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__9(v___x_187990__boxed_4915_, v_val_4907_, v_as_4908_, v_as_x27_4909_, v_b_4910_, v_a_4911_, v___y_4912_, v___y_4913_);
lean_dec_ref(v___y_4912_);
lean_dec(v_as_x27_4909_);
lean_dec(v_as_4908_);
lean_dec_ref(v_val_4907_);
return v_res_4916_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10(lean_object* v_as_4917_, lean_object* v_as_x27_4918_, lean_object* v_b_4919_, lean_object* v_a_4920_, lean_object* v___y_4921_, lean_object* v___y_4922_){
_start:
{
lean_object* v___x_4924_; 
v___x_4924_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___redArg(v_as_x27_4918_, v_b_4919_, v___y_4921_, v___y_4922_);
return v___x_4924_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10___boxed(lean_object* v_as_4925_, lean_object* v_as_x27_4926_, lean_object* v_b_4927_, lean_object* v_a_4928_, lean_object* v___y_4929_, lean_object* v___y_4930_, lean_object* v___y_4931_){
_start:
{
lean_object* v_res_4932_; 
v_res_4932_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__10(v_as_4925_, v_as_x27_4926_, v_b_4927_, v_a_4928_, v___y_4929_, v___y_4930_);
lean_dec_ref(v___y_4929_);
lean_dec(v_as_x27_4926_);
lean_dec(v_as_4925_);
return v_res_4932_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18(lean_object* v_as_4933_, lean_object* v_as_x27_4934_, lean_object* v_b_4935_, lean_object* v_a_4936_, lean_object* v___y_4937_, lean_object* v___y_4938_){
_start:
{
lean_object* v___x_4940_; 
v___x_4940_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___redArg(v_as_x27_4934_, v_b_4935_, v___y_4937_, v___y_4938_);
return v___x_4940_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18___boxed(lean_object* v_as_4941_, lean_object* v_as_x27_4942_, lean_object* v_b_4943_, lean_object* v_a_4944_, lean_object* v___y_4945_, lean_object* v___y_4946_, lean_object* v___y_4947_){
_start:
{
lean_object* v_res_4948_; 
v_res_4948_ = lp_proofEnvironment_List_forIn_x27_loop___at___00CheckedExport_dumpConstant_spec__18(v_as_4941_, v_as_x27_4942_, v_b_4943_, v_a_4944_, v___y_4945_, v___y_4946_);
lean_dec_ref(v___y_4945_);
lean_dec(v_as_x27_4942_);
lean_dec(v_as_4941_);
return v_res_4948_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__1(void){
_start:
{
lean_object* v___x_4950_; lean_object* v___x_4951_; 
v___x_4950_ = l_Lean_versionString;
v___x_4951_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_4951_, 0, v___x_4950_);
return v___x_4951_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__2(void){
_start:
{
lean_object* v___x_4952_; lean_object* v___x_4953_; lean_object* v___x_4954_; 
v___x_4952_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__1, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__1_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__1);
v___x_4953_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__0));
v___x_4954_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4954_, 0, v___x_4953_);
lean_ctor_set(v___x_4954_, 1, v___x_4952_);
return v___x_4954_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__4(void){
_start:
{
lean_object* v___x_4956_; lean_object* v___x_4957_; 
v___x_4956_ = l_Lean_githash;
v___x_4957_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_4957_, 0, v___x_4956_);
return v___x_4957_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__5(void){
_start:
{
lean_object* v___x_4958_; lean_object* v___x_4959_; lean_object* v___x_4960_; 
v___x_4958_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__4, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__4_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__4);
v___x_4959_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__3));
v___x_4960_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4960_, 0, v___x_4959_);
lean_ctor_set(v___x_4960_, 1, v___x_4958_);
return v___x_4960_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__6(void){
_start:
{
lean_object* v___x_4961_; lean_object* v___x_4962_; lean_object* v___x_4963_; 
v___x_4961_ = lean_box(0);
v___x_4962_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__5, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__5_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__5);
v___x_4963_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4963_, 0, v___x_4962_);
lean_ctor_set(v___x_4963_, 1, v___x_4961_);
return v___x_4963_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__7(void){
_start:
{
lean_object* v___x_4964_; lean_object* v___x_4965_; lean_object* v___x_4966_; 
v___x_4964_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__6, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__6_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__6);
v___x_4965_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__2, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__2_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__2);
v___x_4966_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4966_, 0, v___x_4965_);
lean_ctor_set(v___x_4966_, 1, v___x_4964_);
return v___x_4966_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__8(void){
_start:
{
lean_object* v___x_4967_; lean_object* v_leanMeta_4968_; 
v___x_4967_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__7, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__7_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__7);
v_leanMeta_4968_ = l_Lean_Json_mkObj(v___x_4967_);
return v_leanMeta_4968_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__17(void){
_start:
{
lean_object* v___x_4987_; lean_object* v_exporterMeta_4988_; 
v___x_4987_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__16));
v_exporterMeta_4988_ = l_Lean_Json_mkObj(v___x_4987_);
return v_exporterMeta_4988_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__18(void){
_start:
{
lean_object* v___x_4989_; lean_object* v_formatMeta_4990_; 
v___x_4989_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__15));
v_formatMeta_4990_ = l_Lean_Json_mkObj(v___x_4989_);
return v_formatMeta_4990_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__21(void){
_start:
{
lean_object* v_exporterMeta_4993_; lean_object* v___x_4994_; lean_object* v___x_4995_; 
v_exporterMeta_4993_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__17, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__17_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__17);
v___x_4994_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__20));
v___x_4995_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4995_, 0, v___x_4994_);
lean_ctor_set(v___x_4995_, 1, v_exporterMeta_4993_);
return v___x_4995_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__23(void){
_start:
{
lean_object* v_leanMeta_4997_; lean_object* v___x_4998_; lean_object* v___x_4999_; 
v_leanMeta_4997_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__8, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__8_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__8);
v___x_4998_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__22));
v___x_4999_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4999_, 0, v___x_4998_);
lean_ctor_set(v___x_4999_, 1, v_leanMeta_4997_);
return v___x_4999_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__25(void){
_start:
{
lean_object* v_formatMeta_5001_; lean_object* v___x_5002_; lean_object* v___x_5003_; 
v_formatMeta_5001_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__18, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__18_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__18);
v___x_5002_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__24));
v___x_5003_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5003_, 0, v___x_5002_);
lean_ctor_set(v___x_5003_, 1, v_formatMeta_5001_);
return v___x_5003_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__26(void){
_start:
{
lean_object* v___x_5004_; lean_object* v___x_5005_; lean_object* v___x_5006_; 
v___x_5004_ = lean_box(0);
v___x_5005_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__25, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__25_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__25);
v___x_5006_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5006_, 0, v___x_5005_);
lean_ctor_set(v___x_5006_, 1, v___x_5004_);
return v___x_5006_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__27(void){
_start:
{
lean_object* v___x_5007_; lean_object* v___x_5008_; lean_object* v___x_5009_; 
v___x_5007_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__26, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__26_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__26);
v___x_5008_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__23, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__23_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__23);
v___x_5009_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5009_, 0, v___x_5008_);
lean_ctor_set(v___x_5009_, 1, v___x_5007_);
return v___x_5009_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__28(void){
_start:
{
lean_object* v___x_5010_; lean_object* v___x_5011_; lean_object* v___x_5012_; 
v___x_5010_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__27, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__27_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__27);
v___x_5011_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__21, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__21_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__21);
v___x_5012_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5012_, 0, v___x_5011_);
lean_ctor_set(v___x_5012_, 1, v___x_5010_);
return v___x_5012_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__29(void){
_start:
{
lean_object* v___x_5013_; lean_object* v___x_5014_; 
v___x_5013_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__28, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__28_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__28);
v___x_5014_ = l_Lean_Json_mkObj(v___x_5013_);
return v___x_5014_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__30(void){
_start:
{
lean_object* v___x_5015_; lean_object* v___x_5016_; lean_object* v___x_5017_; 
v___x_5015_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__29, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__29_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__29);
v___x_5016_ = ((lean_object*)(lp_proofEnvironment_CheckedExport_exportMetadata___closed__19));
v___x_5017_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5017_, 0, v___x_5016_);
lean_ctor_set(v___x_5017_, 1, v___x_5015_);
return v___x_5017_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__31(void){
_start:
{
lean_object* v___x_5018_; lean_object* v___x_5019_; lean_object* v___x_5020_; 
v___x_5018_ = lean_box(0);
v___x_5019_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__30, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__30_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__30);
v___x_5020_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5020_, 0, v___x_5019_);
lean_ctor_set(v___x_5020_, 1, v___x_5018_);
return v___x_5020_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__32(void){
_start:
{
lean_object* v___x_5021_; lean_object* v___x_5022_; 
v___x_5021_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__31, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__31_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__31);
v___x_5022_ = l_Lean_Json_mkObj(v___x_5021_);
return v___x_5022_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_exportMetadata(void){
_start:
{
lean_object* v___x_5023_; 
v___x_5023_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_exportMetadata___closed__32, &lp_proofEnvironment_CheckedExport_exportMetadata___closed__32_once, _init_lp_proofEnvironment_CheckedExport_exportMetadata___closed__32);
return v___x_5023_;
}
}
static lean_object* _init_lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___closed__0(void){
_start:
{
lean_object* v___x_5024_; lean_object* v___x_5025_; 
v___x_5024_ = lp_proofEnvironment_CheckedExport_exportMetadata;
v___x_5025_ = l_Lean_Json_compress(v___x_5024_);
return v___x_5025_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___redArg(lean_object* v_a_5026_){
_start:
{
lean_object* v___x_5028_; lean_object* v___x_5029_; 
v___x_5028_ = lean_obj_once(&lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___closed__0, &lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___closed__0_once, _init_lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___closed__0);
v___x_5029_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_5028_);
if (lean_obj_tag(v___x_5029_) == 0)
{
lean_object* v_a_5030_; lean_object* v___x_5032_; uint8_t v_isShared_5033_; uint8_t v_isSharedCheck_5038_; 
v_a_5030_ = lean_ctor_get(v___x_5029_, 0);
v_isSharedCheck_5038_ = !lean_is_exclusive(v___x_5029_);
if (v_isSharedCheck_5038_ == 0)
{
v___x_5032_ = v___x_5029_;
v_isShared_5033_ = v_isSharedCheck_5038_;
goto v_resetjp_5031_;
}
else
{
lean_inc(v_a_5030_);
lean_dec(v___x_5029_);
v___x_5032_ = lean_box(0);
v_isShared_5033_ = v_isSharedCheck_5038_;
goto v_resetjp_5031_;
}
v_resetjp_5031_:
{
lean_object* v___x_5034_; lean_object* v___x_5036_; 
v___x_5034_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5034_, 0, v_a_5030_);
lean_ctor_set(v___x_5034_, 1, v_a_5026_);
if (v_isShared_5033_ == 0)
{
lean_ctor_set(v___x_5032_, 0, v___x_5034_);
v___x_5036_ = v___x_5032_;
goto v_reusejp_5035_;
}
else
{
lean_object* v_reuseFailAlloc_5037_; 
v_reuseFailAlloc_5037_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5037_, 0, v___x_5034_);
v___x_5036_ = v_reuseFailAlloc_5037_;
goto v_reusejp_5035_;
}
v_reusejp_5035_:
{
return v___x_5036_;
}
}
}
else
{
lean_object* v_a_5039_; lean_object* v___x_5041_; uint8_t v_isShared_5042_; uint8_t v_isSharedCheck_5046_; 
lean_dec_ref(v_a_5026_);
v_a_5039_ = lean_ctor_get(v___x_5029_, 0);
v_isSharedCheck_5046_ = !lean_is_exclusive(v___x_5029_);
if (v_isSharedCheck_5046_ == 0)
{
v___x_5041_ = v___x_5029_;
v_isShared_5042_ = v_isSharedCheck_5046_;
goto v_resetjp_5040_;
}
else
{
lean_inc(v_a_5039_);
lean_dec(v___x_5029_);
v___x_5041_ = lean_box(0);
v_isShared_5042_ = v_isSharedCheck_5046_;
goto v_resetjp_5040_;
}
v_resetjp_5040_:
{
lean_object* v___x_5044_; 
if (v_isShared_5042_ == 0)
{
v___x_5044_ = v___x_5041_;
goto v_reusejp_5043_;
}
else
{
lean_object* v_reuseFailAlloc_5045_; 
v_reuseFailAlloc_5045_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5045_, 0, v_a_5039_);
v___x_5044_ = v_reuseFailAlloc_5045_;
goto v_reusejp_5043_;
}
v_reusejp_5043_:
{
return v___x_5044_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___redArg___boxed(lean_object* v_a_5047_, lean_object* v_a_5048_){
_start:
{
lean_object* v_res_5049_; 
v_res_5049_ = lp_proofEnvironment_CheckedExport_dumpMetadata___redArg(v_a_5047_);
return v_res_5049_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata(lean_object* v_a_5050_, lean_object* v_a_5051_){
_start:
{
lean_object* v___x_5053_; 
v___x_5053_ = lp_proofEnvironment_CheckedExport_dumpMetadata___redArg(v_a_5051_);
return v___x_5053_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___boxed(lean_object* v_a_5054_, lean_object* v_a_5055_, lean_object* v_a_5056_){
_start:
{
lean_object* v_res_5057_; 
v_res_5057_ = lp_proofEnvironment_CheckedExport_dumpMetadata(v_a_5054_, v_a_5055_);
lean_dec_ref(v_a_5054_);
return v_res_5057_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_Export(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_CheckedExport(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Export(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_proofEnvironment_CheckedExport_exportMetadata = _init_lp_proofEnvironment_CheckedExport_exportMetadata();
lean_mark_persistent(lp_proofEnvironment_CheckedExport_exportMetadata);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
