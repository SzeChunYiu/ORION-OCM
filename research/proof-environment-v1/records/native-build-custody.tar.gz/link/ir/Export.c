// Lean compiler output
// Module: Export
// Imports: public import Init public meta import Init public import Lean public import Std.Data.HashMap.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Json_mkObj(lean_object*);
extern lean_object* l_Lean_githash;
extern lean_object* l_Lean_versionString;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
uint8_t l___private_Lean_Data_Name_0__Lean_Name_quickCmpImpl(lean_object*, lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_balance___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_NameSet_insert(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__1___redArg(lean_object*, lean_object*);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instMonadEIO(lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_instMonad___redArg___lam__9(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_pure(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_bind(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedExpr;
lean_object* l_instInhabitedOfMonad___redArg(lean_object*, lean_object*);
lean_object* l_instInhabitedForall___redArg___lam__0___boxed(lean_object*, lean_object*);
lean_object* lean_panic_fn_borrowed(lean_object*, lean_object*);
lean_object* l_Lean_Expr_app___override(lean_object*, lean_object*);
size_t lean_ptr_addr(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* l_Lean_Expr_lam___override(lean_object*, lean_object*, lean_object*, uint8_t);
uint8_t l_Lean_instBEqBinderInfo_beq(uint8_t, uint8_t);
lean_object* l_Lean_Expr_forallE___override(lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_letE___override(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Expr_proj___override(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Json_setObjVal_x21(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_simplifyResultingUniverse_simp_spec__2___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_AccLevelState_push_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__1___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Firefox_instToJsonStackTable_toJson_spec__0(lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Environment_find_x3f(lean_object*, lean_object*, uint8_t);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_Lean_NameHashSet_insert(lean_object*, lean_object*);
lean_object* l_Lean_Expr_getUsedConstants(lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* l_List_mapTR_loop___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__12(lean_object*, lean_object*);
lean_object* l_Lean_List_toJson___at___00Lean_Option_toJson___at___00Lean_Server_instToJsonIlean_toJson_spec__1_spec__1(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(lean_object*);
lean_object* lean_uint32_to_nat(uint32_t);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Array_instInhabited(lean_object*);
lean_object* l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__10___redArg(lean_object*, lean_object*);
lean_object* l___private_Lean_Data_Name_0__Lean_Name_quickCmpImpl___boxed(lean_object*, lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_union___at___00Std_DTreeMap_union_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_inductiveVal_x21(lean_object*);
uint8_t l_Lean_ConstantInfo_isUnsafe(lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* l_Lean_instReprDataValue_repr(lean_object*, lean_object*);
lean_object* l_Std_Format_pretty(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_Lean_Environment_constants(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_instToStringString___lam__0___boxed(lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_IO_println___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "default"};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__0 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__1 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__1_value;
static const lean_string_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "implicit"};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__2 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__2_value)}};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__3 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__3_value;
static const lean_string_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "strictImplicit"};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__4 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__4_value)}};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__5 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__5_value;
static const lean_string_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "instImplicit"};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__6 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_Lean_BinderInfo_toJson___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__6_value)}};
static const lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___closed__7 = (const lean_object*)&lp_proofEnvironment_Lean_BinderInfo_toJson___closed__7_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson(uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___boxed(lean_object*);
static const lean_string_object lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "opaque"};
static const lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__0 = (const lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__1 = (const lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__1_value;
static const lean_string_object lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "abbrev"};
static const lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__2 = (const lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__2_value)}};
static const lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__3 = (const lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__3_value;
static const lean_string_object lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "regular"};
static const lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__4 = (const lean_object*)&lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___boxed(lean_object*);
static const lean_string_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "type"};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__0 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__1 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__1_value;
static const lean_string_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "ctor"};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__2 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__2_value)}};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__3 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__3_value;
static const lean_string_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__4 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__4_value)}};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__5 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__5_value;
static const lean_string_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__6 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_Lean_QuotKind_toJson___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__6_value)}};
static const lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___closed__7 = (const lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__7_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_QuotKind_toJson(uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___boxed(lean_object*);
static const lean_string_object lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "unsafe"};
static const lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__0 = (const lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__0_value)}};
static const lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__1 = (const lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__1_value;
static const lean_string_object lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "safe"};
static const lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__2 = (const lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__2_value)}};
static const lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__3 = (const lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__3_value;
static const lean_string_object lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "partial"};
static const lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__4 = (const lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__4_value)}};
static const lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__5 = (const lean_object*)&lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson(uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00Lean_KVMap_toJson_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_KVMap_toJson(lean_object*);
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__0;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__1;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__2;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__3;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__4;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__5;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__6;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__7;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__8;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__9;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__10;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__11;
static lean_once_cell_t lp_proofEnvironment_M_run___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_M_run___redArg___closed__12;
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_initState___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_initState___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_any___at___00initState_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "--export-mdata"};
static const lean_object* lp_proofEnvironment_List_any___at___00initState_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment_List_any___at___00initState_spec__0___closed__0_value;
LEAN_EXPORT uint8_t lp_proofEnvironment_List_any___at___00initState_spec__0(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_any___at___00initState_spec__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_any___at___00initState_spec__2___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "--ignore-missing"};
static const lean_object* lp_proofEnvironment_List_any___at___00initState_spec__2___closed__0 = (const lean_object*)&lp_proofEnvironment_List_any___at___00initState_spec__2___closed__0_value;
LEAN_EXPORT uint8_t lp_proofEnvironment_List_any___at___00initState_spec__2(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_any___at___00initState_spec__2___boxed(lean_object*);
static const lean_string_object lp_proofEnvironment_List_any___at___00initState_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "--export-unsafe"};
static const lean_object* lp_proofEnvironment_List_any___at___00initState_spec__1___closed__0 = (const lean_object*)&lp_proofEnvironment_List_any___at___00initState_spec__1___closed__0_value;
LEAN_EXPORT uint8_t lp_proofEnvironment_List_any___at___00initState_spec__1(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_any___at___00initState_spec__1___boxed(lean_object*);
static const lean_closure_object lp_proofEnvironment_initState___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_initState___lam__0___boxed, .m_arity = 6, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_initState___closed__0 = (const lean_object*)&lp_proofEnvironment_initState___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_initState(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_initState___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_getIdx___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instToStringString___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_getIdx___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_getIdx___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpName_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpName_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_dumpName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "in"};
static const lean_object* lp_proofEnvironment_dumpName___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__0_value;
static const lean_string_object lp_proofEnvironment_dumpName___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "Export"};
static const lean_object* lp_proofEnvironment_dumpName___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__1_value;
static const lean_string_object lp_proofEnvironment_dumpName___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "dumpName"};
static const lean_object* lp_proofEnvironment_dumpName___closed__2 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__2_value;
static const lean_string_object lp_proofEnvironment_dumpName___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "unreachable code has been reached"};
static const lean_object* lp_proofEnvironment_dumpName___closed__3 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_dumpName___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_dumpName___closed__4;
static const lean_string_object lp_proofEnvironment_dumpName___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "str"};
static const lean_object* lp_proofEnvironment_dumpName___closed__5 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__5_value;
static const lean_string_object lp_proofEnvironment_dumpName___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "pre"};
static const lean_object* lp_proofEnvironment_dumpName___closed__6 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__6_value;
static const lean_string_object lp_proofEnvironment_dumpName___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "num"};
static const lean_object* lp_proofEnvironment_dumpName___closed__7 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__7_value;
static const lean_string_object lp_proofEnvironment_dumpName___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "i"};
static const lean_object* lp_proofEnvironment_dumpName___closed__8 = (const lean_object*)&lp_proofEnvironment_dumpName___closed__8_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpName(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpName___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_dumpLevel___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "il"};
static const lean_object* lp_proofEnvironment_dumpLevel___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpLevel___closed__0_value;
static const lean_string_object lp_proofEnvironment_dumpLevel___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "succ"};
static const lean_object* lp_proofEnvironment_dumpLevel___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpLevel___closed__1_value;
static const lean_string_object lp_proofEnvironment_dumpLevel___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "max"};
static const lean_object* lp_proofEnvironment_dumpLevel___closed__2 = (const lean_object*)&lp_proofEnvironment_dumpLevel___closed__2_value;
static const lean_string_object lp_proofEnvironment_dumpLevel___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "imax"};
static const lean_object* lp_proofEnvironment_dumpLevel___closed__3 = (const lean_object*)&lp_proofEnvironment_dumpLevel___closed__3_value;
static const lean_string_object lp_proofEnvironment_dumpLevel___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "param"};
static const lean_object* lp_proofEnvironment_dumpLevel___closed__4 = (const lean_object*)&lp_proofEnvironment_dumpLevel___closed__4_value;
static const lean_string_object lp_proofEnvironment_dumpLevel___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "dumpLevel"};
static const lean_object* lp_proofEnvironment_dumpLevel___closed__5 = (const lean_object*)&lp_proofEnvironment_dumpLevel___closed__5_value;
static lean_once_cell_t lp_proofEnvironment_dumpLevel___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_dumpLevel___closed__6;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpLevel(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpLevel___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpUparams(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpUparams___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpNames(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpNames___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00removeMData_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00removeMData_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_removeMData___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "removeMData"};
static const lean_object* lp_proofEnvironment_removeMData___closed__0 = (const lean_object*)&lp_proofEnvironment_removeMData___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_removeMData___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_removeMData___closed__1;
LEAN_EXPORT lean_object* lp_proofEnvironment_removeMData(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_removeMData___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__4(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00dumpConstant_spec__3___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__3___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "dumpConstant"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0_value;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 122, .m_capacity = 122, .m_length = 121, .m_data = "assertion violation: ((!recVal.isUnsafe) || ( __do_lift._@.Export.2173241011._hygCtx._hyg.2133.0 ).exportUnsafe)\n        "};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__1 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__1_value;
static lean_once_cell_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__2;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "expected a `constantinfo.recinfo`."};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__3 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__4;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "Init.Data.Option.BasicAux"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__5 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__5_value;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "Option.get!"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__6 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__6_value;
static const lean_string_object lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "value is none"};
static const lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__7 = (const lean_object*)&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__7_value;
static lean_once_cell_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8;
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00dumpConstant_spec__6___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__6___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__6(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 125, .m_capacity = 125, .m_length = 124, .m_data = "assertion violation: ((!ctorVal.isUnsafe) || ( __do_lift._@.Export.2173241011._hygCtx._hyg.1888.0 ).exportUnsafe)\n          "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__1;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Expected a `ConstantInfo.ctorInfo`."};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__3;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_panic___at___00dumpConstant_spec__8___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__8___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__8(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__13(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__14(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_dumpExpr___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_dumpExpr___closed__0;
static lean_once_cell_t lp_proofEnvironment_dumpExpr___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_dumpExpr___closed__1;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "ie"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__0_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "bvar"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__1_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "sort"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__2 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__2_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "const"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__3 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "name"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "us"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__4 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__4_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "app"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__5 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__5_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "fn"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__6 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__6_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "arg"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__7 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__7_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lam"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__8 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__8_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "body"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__9 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__9_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "binderInfo"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__10 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__10_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "forallE"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__11 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__11_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "letE"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__12 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__12_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "value"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__13 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__13_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "nondep"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__14 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__14_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Nat"};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpNatDeps(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "natVal"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__15 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__15_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "ofList"};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__1_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "String"};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__2_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__0_value),LEAN_SCALAR_PTR_LITERAL(6, 130, 56, 8, 41, 104, 134, 43)}};
static const lean_ctor_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__2_value_aux_0),((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__1_value),LEAN_SCALAR_PTR_LITERAL(118, 246, 177, 142, 179, 9, 199, 233)}};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__2 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__2_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ofNat"};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__4 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__4_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Char"};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__3 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__5_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__3_value),LEAN_SCALAR_PTR_LITERAL(18, 67, 155, 167, 151, 71, 146, 196)}};
static const lean_ctor_object lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__5_value_aux_0),((lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__4_value),LEAN_SCALAR_PTR_LITERAL(27, 51, 10, 169, 25, 67, 44, 251)}};
static const lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__5 = (const lean_object*)&lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "strVal"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__16 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__16_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "mdata"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__17 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__17_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "data"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__18 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__18_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "expr"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__19 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__19_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "proj"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__20 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__20_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "typeName"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__21 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__21_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "idx"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__22 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__22_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "struct"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__23 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__23_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 46, .m_capacity = 46, .m_length = 45, .m_data = "cannot export free variables or metavariables"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__25 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__25_value;
static const lean_string_object lp_proofEnvironment_dumpExprAux___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "dumpExprAux"};
static const lean_object* lp_proofEnvironment_dumpExprAux___closed__24 = (const lean_object*)&lp_proofEnvironment_dumpExprAux___closed__24_value;
static lean_once_cell_t lp_proofEnvironment_dumpExprAux___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_dumpExprAux___closed__26;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExpr(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "levelParams"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numParams"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__4_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numIndices"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "all"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ctors"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numNested"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "isRec"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__4_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "isReflexive"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__5_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "isUnsafe"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15(size_t, size_t, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "induct"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "cidx"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numFields"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16(size_t, size_t, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_dumpConstant_dumpRecRule___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "nfields"};
static const lean_object* lp_proofEnvironment_dumpConstant_dumpRecRule___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpConstant_dumpRecRule___closed__0_value;
static const lean_string_object lp_proofEnvironment_dumpConstant_dumpRecRule___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "rhs"};
static const lean_object* lp_proofEnvironment_dumpConstant_dumpRecRule___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpConstant_dumpRecRule___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpRecRule(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpConstant_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numMotives"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numMinors"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "rules"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "k"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__3_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17(size_t, size_t, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inductive"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__0 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__0_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "types"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__1 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__1_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "recs"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__2 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__2_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "axiom"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__3 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__3_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "def"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__4 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__4_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "hints"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__5 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__5_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "safety"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__6 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__6_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "thm"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__7 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__7_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "Eq"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__8 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__8_value),LEAN_SCALAR_PTR_LITERAL(143, 37, 101, 248, 9, 246, 191, 223)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__9 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__9_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Quot"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__10 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__15_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__10_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__15_value_aux_0),((lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__6_value),LEAN_SCALAR_PTR_LITERAL(150, 213, 121, 152, 109, 27, 137, 60)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__15 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__16 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__16_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__14_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__10_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__14_value_aux_0),((lean_object*)&lp_proofEnvironment_Lean_QuotKind_toJson___closed__4_value),LEAN_SCALAR_PTR_LITERAL(91, 125, 38, 34, 222, 200, 201, 80)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__14 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__14_value),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__16_value)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__17 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__17_value;
static const lean_string_object lp_proofEnvironment_dumpConstant___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "mk"};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__12 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__13_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__10_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__13_value_aux_0),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__12_value),LEAN_SCALAR_PTR_LITERAL(255, 113, 137, 82, 82, 132, 58, 248)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__13 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__13_value),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__17_value)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__18 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__18_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__10_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__11 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__11_value),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__18_value)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__19 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__19_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "Constant "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = " not found in environment."};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__3_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__4_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "quot"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__5 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__5_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "kind"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__6 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__6_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_proofEnvironment_dumpConstant___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__20 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__20_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__20_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__21 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__21_value;
static const lean_ctor_object lp_proofEnvironment_dumpConstant___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_dumpConstant___closed__20_value),((lean_object*)&lp_proofEnvironment_dumpConstant___closed__21_value)}};
static const lean_object* lp_proofEnvironment_dumpConstant___closed__22 = (const lean_object*)&lp_proofEnvironment_dumpConstant___closed__22_value;
static const lean_closure_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l___private_Lean_Data_Name_0__Lean_Name_quickCmpImpl___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 367, .m_capacity = 367, .m_length = 366, .m_data = "assertion violation: ctorVals.size == 0\n\n    /- We dump the constructor dependencies (which will not include the inductives in this block since we've\n    added the names to `visitedConstants`) before actually outputting anything in this inductive block to\n    ensure e.g. the `LT` in `Fin.mk` is dumped before this inductive block appears in the export file. -/\n    "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__1_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__2;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 117, .m_capacity = 117, .m_length = 116, .m_data = "assertion violation: ((!val.isUnsafe) || ( __do_lift._@.Export.2173241011._hygCtx._hyg.1812.0 ).exportUnsafe)\n      "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__4;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__11(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_dumpDeps_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpDeps(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpDeps___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpConstant_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_dumpDeps_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpNatDeps___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__14___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExpr___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpRecRule___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "version"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__0 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__1;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__2;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "githash"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__3 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__4;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__5;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__6;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__7;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__8;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "lean4export"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__9 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_exportMetadata___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_exportMetadata___closed__9_value)}};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__10 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_exportMetadata___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0_value),((lean_object*)&lp_proofEnvironment_exportMetadata___closed__10_value)}};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__11 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__11_value;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "3.1.0"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__12 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_exportMetadata___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_exportMetadata___closed__12_value)}};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__13 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_exportMetadata___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_exportMetadata___closed__0_value),((lean_object*)&lp_proofEnvironment_exportMetadata___closed__13_value)}};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__14 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_exportMetadata___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_exportMetadata___closed__14_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__15 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_exportMetadata___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_exportMetadata___closed__11_value),((lean_object*)&lp_proofEnvironment_exportMetadata___closed__15_value)}};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__16 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__16_value;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__17;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__18;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "meta"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__19 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__19_value;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "exporter"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__20 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__20_value;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__21_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__21;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lean"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__22 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__22_value;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__23;
static const lean_string_object lp_proofEnvironment_exportMetadata___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "format"};
static const lean_object* lp_proofEnvironment_exportMetadata___closed__24 = (const lean_object*)&lp_proofEnvironment_exportMetadata___closed__24_value;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__25;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__26;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__27;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__28;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__29;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__30;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__31;
static lean_once_cell_t lp_proofEnvironment_exportMetadata___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_exportMetadata___closed__32;
LEAN_EXPORT lean_object* lp_proofEnvironment_exportMetadata;
static lean_once_cell_t lp_proofEnvironment_dumpMetadata___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_dumpMetadata___redArg___closed__0;
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson(uint8_t v_x_13_){
_start:
{
switch(v_x_13_)
{
case 0:
{
lean_object* v___x_14_; 
v___x_14_ = ((lean_object*)(lp_proofEnvironment_Lean_BinderInfo_toJson___closed__1));
return v___x_14_;
}
case 1:
{
lean_object* v___x_15_; 
v___x_15_ = ((lean_object*)(lp_proofEnvironment_Lean_BinderInfo_toJson___closed__3));
return v___x_15_;
}
case 2:
{
lean_object* v___x_16_; 
v___x_16_ = ((lean_object*)(lp_proofEnvironment_Lean_BinderInfo_toJson___closed__5));
return v___x_16_;
}
default: 
{
lean_object* v___x_17_; 
v___x_17_ = ((lean_object*)(lp_proofEnvironment_Lean_BinderInfo_toJson___closed__7));
return v___x_17_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_BinderInfo_toJson___boxed(lean_object* v_x_18_){
_start:
{
uint8_t v_x_64__boxed_19_; lean_object* v_res_20_; 
v_x_64__boxed_19_ = lean_unbox(v_x_18_);
v_res_20_ = lp_proofEnvironment_Lean_BinderInfo_toJson(v_x_64__boxed_19_);
return v_res_20_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson(lean_object* v_x_28_){
_start:
{
switch(lean_obj_tag(v_x_28_))
{
case 0:
{
lean_object* v___x_29_; 
v___x_29_ = ((lean_object*)(lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__1));
return v___x_29_;
}
case 1:
{
lean_object* v___x_30_; 
v___x_30_ = ((lean_object*)(lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__3));
return v___x_30_;
}
default: 
{
uint32_t v_a_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; 
v_a_31_ = lean_ctor_get_uint32(v_x_28_, 0);
v___x_32_ = ((lean_object*)(lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__4));
v___x_33_ = lean_uint32_to_nat(v_a_31_);
v___x_34_ = l_Lean_JsonNumber_fromNat(v___x_33_);
v___x_35_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_35_, 0, v___x_34_);
v___x_36_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_36_, 0, v___x_32_);
lean_ctor_set(v___x_36_, 1, v___x_35_);
v___x_37_ = lean_box(0);
v___x_38_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_38_, 0, v___x_36_);
lean_ctor_set(v___x_38_, 1, v___x_37_);
v___x_39_ = l_Lean_Json_mkObj(v___x_38_);
lean_dec_ref_known(v___x_38_, 2);
return v___x_39_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_ReducibilityHints_toJson___boxed(lean_object* v_x_40_){
_start:
{
lean_object* v_res_41_; 
v_res_41_ = lp_proofEnvironment_Lean_ReducibilityHints_toJson(v_x_40_);
lean_dec(v_x_40_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_QuotKind_toJson(uint8_t v_x_54_){
_start:
{
switch(v_x_54_)
{
case 0:
{
lean_object* v___x_55_; 
v___x_55_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__1));
return v___x_55_;
}
case 1:
{
lean_object* v___x_56_; 
v___x_56_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__3));
return v___x_56_;
}
case 2:
{
lean_object* v___x_57_; 
v___x_57_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__5));
return v___x_57_;
}
default: 
{
lean_object* v___x_58_; 
v___x_58_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__7));
return v___x_58_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_QuotKind_toJson___boxed(lean_object* v_x_59_){
_start:
{
uint8_t v_x_64__boxed_60_; lean_object* v_res_61_; 
v_x_64__boxed_60_ = lean_unbox(v_x_59_);
v_res_61_ = lp_proofEnvironment_Lean_QuotKind_toJson(v_x_64__boxed_60_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson(uint8_t v_x_71_){
_start:
{
switch(v_x_71_)
{
case 0:
{
lean_object* v___x_72_; 
v___x_72_ = ((lean_object*)(lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__1));
return v___x_72_;
}
case 1:
{
lean_object* v___x_73_; 
v___x_73_ = ((lean_object*)(lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__3));
return v___x_73_;
}
default: 
{
lean_object* v___x_74_; 
v___x_74_ = ((lean_object*)(lp_proofEnvironment_Lean_DefinitionSafety_toJson___closed__5));
return v___x_74_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_DefinitionSafety_toJson___boxed(lean_object* v_x_75_){
_start:
{
uint8_t v_x_49__boxed_76_; lean_object* v_res_77_; 
v_x_49__boxed_76_ = lean_unbox(v_x_75_);
v_res_77_ = lp_proofEnvironment_Lean_DefinitionSafety_toJson(v_x_49__boxed_76_);
return v_res_77_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00Lean_KVMap_toJson_spec__0(lean_object* v_a_78_, lean_object* v_a_79_){
_start:
{
if (lean_obj_tag(v_a_78_) == 0)
{
lean_object* v___x_80_; 
v___x_80_ = l_List_reverse___redArg(v_a_79_);
return v___x_80_;
}
else
{
lean_object* v_head_81_; lean_object* v_tail_82_; lean_object* v___x_84_; uint8_t v_isShared_85_; uint8_t v_isSharedCheck_106_; 
v_head_81_ = lean_ctor_get(v_a_78_, 0);
v_tail_82_ = lean_ctor_get(v_a_78_, 1);
v_isSharedCheck_106_ = !lean_is_exclusive(v_a_78_);
if (v_isSharedCheck_106_ == 0)
{
v___x_84_ = v_a_78_;
v_isShared_85_ = v_isSharedCheck_106_;
goto v_resetjp_83_;
}
else
{
lean_inc(v_tail_82_);
lean_inc(v_head_81_);
lean_dec(v_a_78_);
v___x_84_ = lean_box(0);
v_isShared_85_ = v_isSharedCheck_106_;
goto v_resetjp_83_;
}
v_resetjp_83_:
{
lean_object* v_fst_86_; lean_object* v_snd_87_; lean_object* v___x_89_; uint8_t v_isShared_90_; uint8_t v_isSharedCheck_105_; 
v_fst_86_ = lean_ctor_get(v_head_81_, 0);
v_snd_87_ = lean_ctor_get(v_head_81_, 1);
v_isSharedCheck_105_ = !lean_is_exclusive(v_head_81_);
if (v_isSharedCheck_105_ == 0)
{
v___x_89_ = v_head_81_;
v_isShared_90_ = v_isSharedCheck_105_;
goto v_resetjp_88_;
}
else
{
lean_inc(v_snd_87_);
lean_inc(v_fst_86_);
lean_dec(v_head_81_);
v___x_89_ = lean_box(0);
v_isShared_90_ = v_isSharedCheck_105_;
goto v_resetjp_88_;
}
v_resetjp_88_:
{
uint8_t v___x_91_; lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_99_; 
v___x_91_ = 1;
v___x_92_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_86_, v___x_91_);
v___x_93_ = lean_unsigned_to_nat(0u);
v___x_94_ = l_Lean_instReprDataValue_repr(v_snd_87_, v___x_93_);
v___x_95_ = lean_unsigned_to_nat(120u);
v___x_96_ = l_Std_Format_pretty(v___x_94_, v___x_95_, v___x_93_, v___x_93_);
v___x_97_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_97_, 0, v___x_96_);
if (v_isShared_90_ == 0)
{
lean_ctor_set(v___x_89_, 1, v___x_97_);
lean_ctor_set(v___x_89_, 0, v___x_92_);
v___x_99_ = v___x_89_;
goto v_reusejp_98_;
}
else
{
lean_object* v_reuseFailAlloc_104_; 
v_reuseFailAlloc_104_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_104_, 0, v___x_92_);
lean_ctor_set(v_reuseFailAlloc_104_, 1, v___x_97_);
v___x_99_ = v_reuseFailAlloc_104_;
goto v_reusejp_98_;
}
v_reusejp_98_:
{
lean_object* v___x_101_; 
if (v_isShared_85_ == 0)
{
lean_ctor_set(v___x_84_, 1, v_a_79_);
lean_ctor_set(v___x_84_, 0, v___x_99_);
v___x_101_ = v___x_84_;
goto v_reusejp_100_;
}
else
{
lean_object* v_reuseFailAlloc_103_; 
v_reuseFailAlloc_103_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_103_, 0, v___x_99_);
lean_ctor_set(v_reuseFailAlloc_103_, 1, v_a_79_);
v___x_101_ = v_reuseFailAlloc_103_;
goto v_reusejp_100_;
}
v_reusejp_100_:
{
v_a_78_ = v_tail_82_;
v_a_79_ = v___x_101_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_KVMap_toJson(lean_object* v_kvs_107_){
_start:
{
lean_object* v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; 
v___x_108_ = lean_box(0);
v___x_109_ = lp_proofEnvironment_List_mapTR_loop___at___00Lean_KVMap_toJson_spec__0(v_kvs_107_, v___x_108_);
v___x_110_ = l_Lean_Json_mkObj(v___x_109_);
lean_dec(v___x_109_);
return v___x_110_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__0(void){
_start:
{
lean_object* v___x_111_; lean_object* v___x_112_; lean_object* v___x_113_; 
v___x_111_ = lean_box(0);
v___x_112_ = lean_unsigned_to_nat(524288u);
v___x_113_ = lean_mk_array(v___x_112_, v___x_111_);
return v___x_113_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__1(void){
_start:
{
lean_object* v___x_114_; lean_object* v___x_115_; lean_object* v___x_116_; 
v___x_114_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__0, &lp_proofEnvironment_M_run___redArg___closed__0_once, _init_lp_proofEnvironment_M_run___redArg___closed__0);
v___x_115_ = lean_unsigned_to_nat(0u);
v___x_116_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_116_, 0, v___x_115_);
lean_ctor_set(v___x_116_, 1, v___x_114_);
return v___x_116_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__2(void){
_start:
{
lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; 
v___x_117_ = lean_unsigned_to_nat(0u);
v___x_118_ = lean_box(0);
v___x_119_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__1, &lp_proofEnvironment_M_run___redArg___closed__1_once, _init_lp_proofEnvironment_M_run___redArg___closed__1);
v___x_120_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__1___redArg(v___x_119_, v___x_118_, v___x_117_);
return v___x_120_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__3(void){
_start:
{
lean_object* v___x_121_; lean_object* v___x_122_; lean_object* v___x_123_; 
v___x_121_ = lean_box(0);
v___x_122_ = lean_unsigned_to_nat(2048u);
v___x_123_ = lean_mk_array(v___x_122_, v___x_121_);
return v___x_123_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__4(void){
_start:
{
lean_object* v___x_124_; lean_object* v___x_125_; lean_object* v___x_126_; 
v___x_124_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__3, &lp_proofEnvironment_M_run___redArg___closed__3_once, _init_lp_proofEnvironment_M_run___redArg___closed__3);
v___x_125_ = lean_unsigned_to_nat(0u);
v___x_126_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_126_, 0, v___x_125_);
lean_ctor_set(v___x_126_, 1, v___x_124_);
return v___x_126_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__5(void){
_start:
{
lean_object* v___x_127_; lean_object* v___x_128_; lean_object* v___x_129_; lean_object* v___x_130_; 
v___x_127_ = lean_unsigned_to_nat(0u);
v___x_128_ = lean_box(0);
v___x_129_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__4, &lp_proofEnvironment_M_run___redArg___closed__4_once, _init_lp_proofEnvironment_M_run___redArg___closed__4);
v___x_130_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_AccLevelState_push_spec__0___redArg(v___x_129_, v___x_128_, v___x_127_);
return v___x_130_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__6(void){
_start:
{
lean_object* v___x_131_; lean_object* v___x_132_; lean_object* v___x_133_; 
v___x_131_ = lean_box(0);
v___x_132_ = lean_unsigned_to_nat(16777216u);
v___x_133_ = lean_mk_array(v___x_132_, v___x_131_);
return v___x_133_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__7(void){
_start:
{
lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; 
v___x_134_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__6, &lp_proofEnvironment_M_run___redArg___closed__6_once, _init_lp_proofEnvironment_M_run___redArg___closed__6);
v___x_135_ = lean_unsigned_to_nat(0u);
v___x_136_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_136_, 0, v___x_135_);
lean_ctor_set(v___x_136_, 1, v___x_134_);
return v___x_136_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__8(void){
_start:
{
lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; 
v___x_137_ = lean_box(0);
v___x_138_ = lean_unsigned_to_nat(16u);
v___x_139_ = lean_mk_array(v___x_138_, v___x_137_);
return v___x_139_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__9(void){
_start:
{
lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; 
v___x_140_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__8, &lp_proofEnvironment_M_run___redArg___closed__8_once, _init_lp_proofEnvironment_M_run___redArg___closed__8);
v___x_141_ = lean_unsigned_to_nat(0u);
v___x_142_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_142_, 0, v___x_141_);
lean_ctor_set(v___x_142_, 1, v___x_140_);
return v___x_142_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__10(void){
_start:
{
lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; 
v___x_143_ = lean_box(0);
v___x_144_ = lean_unsigned_to_nat(262144u);
v___x_145_ = lean_mk_array(v___x_144_, v___x_143_);
return v___x_145_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__11(void){
_start:
{
lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; 
v___x_146_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__10, &lp_proofEnvironment_M_run___redArg___closed__10_once, _init_lp_proofEnvironment_M_run___redArg___closed__10);
v___x_147_ = lean_unsigned_to_nat(0u);
v___x_148_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_148_, 0, v___x_147_);
lean_ctor_set(v___x_148_, 1, v___x_146_);
return v___x_148_;
}
}
static lean_object* _init_lp_proofEnvironment_M_run___redArg___closed__12(void){
_start:
{
lean_object* v___x_149_; uint8_t v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; 
v___x_149_ = lean_box(1);
v___x_150_ = 0;
v___x_151_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__11, &lp_proofEnvironment_M_run___redArg___closed__11_once, _init_lp_proofEnvironment_M_run___redArg___closed__11);
v___x_152_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__9, &lp_proofEnvironment_M_run___redArg___closed__9_once, _init_lp_proofEnvironment_M_run___redArg___closed__9);
v___x_153_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__7, &lp_proofEnvironment_M_run___redArg___closed__7_once, _init_lp_proofEnvironment_M_run___redArg___closed__7);
v___x_154_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__5, &lp_proofEnvironment_M_run___redArg___closed__5_once, _init_lp_proofEnvironment_M_run___redArg___closed__5);
v___x_155_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__2, &lp_proofEnvironment_M_run___redArg___closed__2_once, _init_lp_proofEnvironment_M_run___redArg___closed__2);
v___x_156_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_156_, 0, v___x_155_);
lean_ctor_set(v___x_156_, 1, v___x_154_);
lean_ctor_set(v___x_156_, 2, v___x_153_);
lean_ctor_set(v___x_156_, 3, v___x_152_);
lean_ctor_set(v___x_156_, 4, v___x_151_);
lean_ctor_set(v___x_156_, 5, v___x_149_);
lean_ctor_set_uint8(v___x_156_, sizeof(void*)*6, v___x_150_);
lean_ctor_set_uint8(v___x_156_, sizeof(void*)*6 + 1, v___x_150_);
lean_ctor_set_uint8(v___x_156_, sizeof(void*)*6 + 2, v___x_150_);
return v___x_156_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run___redArg(lean_object* v_env_157_, lean_object* v_act_158_){
_start:
{
lean_object* v___x_160_; lean_object* v___x_161_; 
v___x_160_ = lean_obj_once(&lp_proofEnvironment_M_run___redArg___closed__12, &lp_proofEnvironment_M_run___redArg___closed__12_once, _init_lp_proofEnvironment_M_run___redArg___closed__12);
v___x_161_ = lean_apply_3(v_act_158_, v_env_157_, v___x_160_, lean_box(0));
if (lean_obj_tag(v___x_161_) == 0)
{
lean_object* v_a_162_; lean_object* v___x_164_; uint8_t v_isShared_165_; uint8_t v_isSharedCheck_170_; 
v_a_162_ = lean_ctor_get(v___x_161_, 0);
v_isSharedCheck_170_ = !lean_is_exclusive(v___x_161_);
if (v_isSharedCheck_170_ == 0)
{
v___x_164_ = v___x_161_;
v_isShared_165_ = v_isSharedCheck_170_;
goto v_resetjp_163_;
}
else
{
lean_inc(v_a_162_);
lean_dec(v___x_161_);
v___x_164_ = lean_box(0);
v_isShared_165_ = v_isSharedCheck_170_;
goto v_resetjp_163_;
}
v_resetjp_163_:
{
lean_object* v_fst_166_; lean_object* v___x_168_; 
v_fst_166_ = lean_ctor_get(v_a_162_, 0);
lean_inc(v_fst_166_);
lean_dec(v_a_162_);
if (v_isShared_165_ == 0)
{
lean_ctor_set(v___x_164_, 0, v_fst_166_);
v___x_168_ = v___x_164_;
goto v_reusejp_167_;
}
else
{
lean_object* v_reuseFailAlloc_169_; 
v_reuseFailAlloc_169_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_169_, 0, v_fst_166_);
v___x_168_ = v_reuseFailAlloc_169_;
goto v_reusejp_167_;
}
v_reusejp_167_:
{
return v___x_168_;
}
}
}
else
{
lean_object* v_a_171_; lean_object* v___x_173_; uint8_t v_isShared_174_; uint8_t v_isSharedCheck_178_; 
v_a_171_ = lean_ctor_get(v___x_161_, 0);
v_isSharedCheck_178_ = !lean_is_exclusive(v___x_161_);
if (v_isSharedCheck_178_ == 0)
{
v___x_173_ = v___x_161_;
v_isShared_174_ = v_isSharedCheck_178_;
goto v_resetjp_172_;
}
else
{
lean_inc(v_a_171_);
lean_dec(v___x_161_);
v___x_173_ = lean_box(0);
v_isShared_174_ = v_isSharedCheck_178_;
goto v_resetjp_172_;
}
v_resetjp_172_:
{
lean_object* v___x_176_; 
if (v_isShared_174_ == 0)
{
v___x_176_ = v___x_173_;
goto v_reusejp_175_;
}
else
{
lean_object* v_reuseFailAlloc_177_; 
v_reuseFailAlloc_177_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_177_, 0, v_a_171_);
v___x_176_ = v_reuseFailAlloc_177_;
goto v_reusejp_175_;
}
v_reusejp_175_:
{
return v___x_176_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run___redArg___boxed(lean_object* v_env_179_, lean_object* v_act_180_, lean_object* v_a_181_){
_start:
{
lean_object* v_res_182_; 
v_res_182_ = lp_proofEnvironment_M_run___redArg(v_env_179_, v_act_180_);
return v_res_182_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run(lean_object* v_00_u03b1_183_, lean_object* v_env_184_, lean_object* v_act_185_){
_start:
{
lean_object* v___x_187_; 
v___x_187_ = lp_proofEnvironment_M_run___redArg(v_env_184_, v_act_185_);
return v___x_187_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_M_run___boxed(lean_object* v_00_u03b1_188_, lean_object* v_env_189_, lean_object* v_act_190_, lean_object* v_a_191_){
_start:
{
lean_object* v_res_192_; 
v_res_192_ = lp_proofEnvironment_M_run(v_00_u03b1_188_, v_env_189_, v_act_190_);
return v_res_192_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg___lam__0(lean_object* v_val_193_, lean_object* v_x_194_){
_start:
{
if (lean_obj_tag(v_x_194_) == 0)
{
lean_object* v_toConstantVal_195_; lean_object* v_name_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; 
v_toConstantVal_195_ = lean_ctor_get(v_val_193_, 0);
lean_inc_ref(v_toConstantVal_195_);
lean_dec_ref(v_val_193_);
v_name_196_ = lean_ctor_get(v_toConstantVal_195_, 0);
lean_inc(v_name_196_);
lean_dec_ref(v_toConstantVal_195_);
v___x_197_ = lean_box(1);
v___x_198_ = l_Lean_NameSet_insert(v___x_197_, v_name_196_);
v___x_199_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_199_, 0, v___x_198_);
return v___x_199_;
}
else
{
lean_object* v_toConstantVal_200_; lean_object* v_val_201_; lean_object* v___x_203_; uint8_t v_isShared_204_; uint8_t v_isSharedCheck_210_; 
v_toConstantVal_200_ = lean_ctor_get(v_val_193_, 0);
lean_inc_ref(v_toConstantVal_200_);
lean_dec_ref(v_val_193_);
v_val_201_ = lean_ctor_get(v_x_194_, 0);
v_isSharedCheck_210_ = !lean_is_exclusive(v_x_194_);
if (v_isSharedCheck_210_ == 0)
{
v___x_203_ = v_x_194_;
v_isShared_204_ = v_isSharedCheck_210_;
goto v_resetjp_202_;
}
else
{
lean_inc(v_val_201_);
lean_dec(v_x_194_);
v___x_203_ = lean_box(0);
v_isShared_204_ = v_isSharedCheck_210_;
goto v_resetjp_202_;
}
v_resetjp_202_:
{
lean_object* v_name_205_; lean_object* v___x_206_; lean_object* v___x_208_; 
v_name_205_ = lean_ctor_get(v_toConstantVal_200_, 0);
lean_inc(v_name_205_);
lean_dec_ref(v_toConstantVal_200_);
v___x_206_ = l_Lean_NameSet_insert(v_val_201_, v_name_205_);
if (v_isShared_204_ == 0)
{
lean_ctor_set(v___x_203_, 0, v___x_206_);
v___x_208_ = v___x_203_;
goto v_reusejp_207_;
}
else
{
lean_object* v_reuseFailAlloc_209_; 
v_reuseFailAlloc_209_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_209_, 0, v___x_206_);
v___x_208_ = v_reuseFailAlloc_209_;
goto v_reusejp_207_;
}
v_reusejp_207_:
{
return v___x_208_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(lean_object* v_val_211_, lean_object* v_k_212_, lean_object* v_t_213_){
_start:
{
if (lean_obj_tag(v_t_213_) == 0)
{
lean_object* v_size_214_; lean_object* v_k_215_; lean_object* v_v_216_; lean_object* v_l_217_; lean_object* v_r_218_; lean_object* v___x_220_; uint8_t v_isShared_221_; uint8_t v_isSharedCheck_233_; 
v_size_214_ = lean_ctor_get(v_t_213_, 0);
v_k_215_ = lean_ctor_get(v_t_213_, 1);
v_v_216_ = lean_ctor_get(v_t_213_, 2);
v_l_217_ = lean_ctor_get(v_t_213_, 3);
v_r_218_ = lean_ctor_get(v_t_213_, 4);
v_isSharedCheck_233_ = !lean_is_exclusive(v_t_213_);
if (v_isSharedCheck_233_ == 0)
{
v___x_220_ = v_t_213_;
v_isShared_221_ = v_isSharedCheck_233_;
goto v_resetjp_219_;
}
else
{
lean_inc(v_r_218_);
lean_inc(v_l_217_);
lean_inc(v_v_216_);
lean_inc(v_k_215_);
lean_inc(v_size_214_);
lean_dec(v_t_213_);
v___x_220_ = lean_box(0);
v_isShared_221_ = v_isSharedCheck_233_;
goto v_resetjp_219_;
}
v_resetjp_219_:
{
uint8_t v___x_222_; 
v___x_222_ = l___private_Lean_Data_Name_0__Lean_Name_quickCmpImpl(v_k_212_, v_k_215_);
switch(v___x_222_)
{
case 0:
{
lean_object* v_impl_223_; lean_object* v___x_224_; 
lean_del_object(v___x_220_);
lean_dec(v_size_214_);
v_impl_223_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(v_val_211_, v_k_212_, v_l_217_);
v___x_224_ = l_Std_DTreeMap_Internal_Impl_balance___redArg(v_k_215_, v_v_216_, v_impl_223_, v_r_218_);
return v___x_224_;
}
case 1:
{
lean_object* v___x_225_; lean_object* v___x_226_; lean_object* v_val_227_; lean_object* v___x_229_; 
lean_dec(v_k_215_);
v___x_225_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_225_, 0, v_v_216_);
v___x_226_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg___lam__0(v_val_211_, v___x_225_);
v_val_227_ = lean_ctor_get(v___x_226_, 0);
lean_inc(v_val_227_);
lean_dec(v___x_226_);
if (v_isShared_221_ == 0)
{
lean_ctor_set(v___x_220_, 2, v_val_227_);
lean_ctor_set(v___x_220_, 1, v_k_212_);
v___x_229_ = v___x_220_;
goto v_reusejp_228_;
}
else
{
lean_object* v_reuseFailAlloc_230_; 
v_reuseFailAlloc_230_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_230_, 0, v_size_214_);
lean_ctor_set(v_reuseFailAlloc_230_, 1, v_k_212_);
lean_ctor_set(v_reuseFailAlloc_230_, 2, v_val_227_);
lean_ctor_set(v_reuseFailAlloc_230_, 3, v_l_217_);
lean_ctor_set(v_reuseFailAlloc_230_, 4, v_r_218_);
v___x_229_ = v_reuseFailAlloc_230_;
goto v_reusejp_228_;
}
v_reusejp_228_:
{
return v___x_229_;
}
}
default: 
{
lean_object* v_impl_231_; lean_object* v___x_232_; 
lean_del_object(v___x_220_);
lean_dec(v_size_214_);
v_impl_231_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(v_val_211_, v_k_212_, v_r_218_);
v___x_232_ = l_Std_DTreeMap_Internal_Impl_balance___redArg(v_k_215_, v_v_216_, v_l_217_, v_impl_231_);
return v___x_232_;
}
}
}
}
else
{
lean_object* v___x_234_; lean_object* v___x_235_; lean_object* v_val_236_; lean_object* v___x_237_; lean_object* v___x_238_; 
v___x_234_ = lean_box(0);
v___x_235_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg___lam__0(v_val_211_, v___x_234_);
v_val_236_ = lean_ctor_get(v___x_235_, 0);
lean_inc(v_val_236_);
lean_dec(v___x_235_);
v___x_237_ = lean_unsigned_to_nat(1u);
v___x_238_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_238_, 0, v___x_237_);
lean_ctor_set(v___x_238_, 1, v_k_212_);
lean_ctor_set(v___x_238_, 2, v_val_236_);
lean_ctor_set(v___x_238_, 3, v_t_213_);
lean_ctor_set(v___x_238_, 4, v_t_213_);
return v___x_238_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg(lean_object* v_val_239_, lean_object* v_as_x27_240_, lean_object* v_b_241_, lean_object* v___y_242_){
_start:
{
if (lean_obj_tag(v_as_x27_240_) == 0)
{
lean_object* v___x_244_; lean_object* v___x_245_; 
lean_dec_ref(v_val_239_);
v___x_244_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_244_, 0, v_b_241_);
lean_ctor_set(v___x_244_, 1, v___y_242_);
v___x_245_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_245_, 0, v___x_244_);
return v___x_245_;
}
else
{
lean_object* v_head_246_; lean_object* v_tail_247_; lean_object* v___x_248_; 
v_head_246_ = lean_ctor_get(v_as_x27_240_, 0);
v_tail_247_ = lean_ctor_get(v_as_x27_240_, 1);
lean_inc(v_head_246_);
lean_inc_ref(v_val_239_);
v___x_248_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(v_val_239_, v_head_246_, v_b_241_);
v_as_x27_240_ = v_tail_247_;
v_b_241_ = v___x_248_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg___boxed(lean_object* v_val_250_, lean_object* v_as_x27_251_, lean_object* v_b_252_, lean_object* v___y_253_, lean_object* v___y_254_){
_start:
{
lean_object* v_res_255_; 
v_res_255_ = lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg(v_val_250_, v_as_x27_251_, v_b_252_, v___y_253_);
lean_dec(v_as_x27_251_);
return v_res_255_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_initState___lam__0(lean_object* v_x_256_, lean_object* v_y_257_, lean_object* v___y_258_, lean_object* v___y_259_, lean_object* v___y_260_){
_start:
{
lean_object* v_a_263_; lean_object* v_snd_264_; 
if (lean_obj_tag(v_y_257_) == 7)
{
lean_object* v_val_270_; lean_object* v_all_271_; lean_object* v___x_272_; lean_object* v_a_273_; lean_object* v_fst_274_; lean_object* v_snd_275_; 
v_val_270_ = lean_ctor_get(v_y_257_, 0);
lean_inc_ref(v_val_270_);
lean_dec_ref_known(v_y_257_, 1);
v_all_271_ = lean_ctor_get(v_val_270_, 1);
lean_inc(v_all_271_);
v___x_272_ = lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg(v_val_270_, v_all_271_, v___y_258_, v___y_260_);
lean_dec(v_all_271_);
v_a_273_ = lean_ctor_get(v___x_272_, 0);
lean_inc(v_a_273_);
lean_dec_ref(v___x_272_);
v_fst_274_ = lean_ctor_get(v_a_273_, 0);
lean_inc(v_fst_274_);
v_snd_275_ = lean_ctor_get(v_a_273_, 1);
lean_inc(v_snd_275_);
lean_dec(v_a_273_);
v_a_263_ = v_fst_274_;
v_snd_264_ = v_snd_275_;
goto v___jp_262_;
}
else
{
lean_dec_ref(v_y_257_);
v_a_263_ = v___y_258_;
v_snd_264_ = v___y_260_;
goto v___jp_262_;
}
v___jp_262_:
{
lean_object* v___x_265_; lean_object* v___x_266_; lean_object* v___x_267_; lean_object* v___x_268_; lean_object* v___x_269_; 
v___x_265_ = lean_box(0);
v___x_266_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_266_, 0, v___x_265_);
lean_ctor_set(v___x_266_, 1, v_a_263_);
v___x_267_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_267_, 0, v___x_266_);
v___x_268_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_268_, 0, v___x_267_);
lean_ctor_set(v___x_268_, 1, v_snd_264_);
v___x_269_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_269_, 0, v___x_268_);
return v___x_269_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_initState___lam__0___boxed(lean_object* v_x_276_, lean_object* v_y_277_, lean_object* v___y_278_, lean_object* v___y_279_, lean_object* v___y_280_, lean_object* v___y_281_){
_start:
{
lean_object* v_res_282_; 
v_res_282_ = lp_proofEnvironment_initState___lam__0(v_x_276_, v_y_277_, v___y_278_, v___y_279_, v___y_280_);
lean_dec_ref(v___y_279_);
lean_dec(v_x_276_);
return v_res_282_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_List_any___at___00initState_spec__0(lean_object* v_x_284_){
_start:
{
if (lean_obj_tag(v_x_284_) == 0)
{
uint8_t v___x_285_; 
v___x_285_ = 0;
return v___x_285_;
}
else
{
lean_object* v_head_286_; lean_object* v_tail_287_; lean_object* v___x_288_; uint8_t v___x_289_; 
v_head_286_ = lean_ctor_get(v_x_284_, 0);
v_tail_287_ = lean_ctor_get(v_x_284_, 1);
v___x_288_ = ((lean_object*)(lp_proofEnvironment_List_any___at___00initState_spec__0___closed__0));
v___x_289_ = lean_string_dec_eq(v_head_286_, v___x_288_);
if (v___x_289_ == 0)
{
v_x_284_ = v_tail_287_;
goto _start;
}
else
{
return v___x_289_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_any___at___00initState_spec__0___boxed(lean_object* v_x_291_){
_start:
{
uint8_t v_res_292_; lean_object* v_r_293_; 
v_res_292_ = lp_proofEnvironment_List_any___at___00initState_spec__0(v_x_291_);
lean_dec(v_x_291_);
v_r_293_ = lean_box(v_res_292_);
return v_r_293_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg(lean_object* v_f_294_, lean_object* v_x_295_, lean_object* v_x_296_, lean_object* v___y_297_, lean_object* v___y_298_, lean_object* v___y_299_){
_start:
{
if (lean_obj_tag(v_x_296_) == 0)
{
lean_object* v___x_301_; lean_object* v___x_302_; lean_object* v___x_303_; lean_object* v___x_304_; 
lean_dec_ref(v_f_294_);
v___x_301_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_301_, 0, v_x_295_);
lean_ctor_set(v___x_301_, 1, v___y_297_);
v___x_302_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_302_, 0, v___x_301_);
v___x_303_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_303_, 0, v___x_302_);
lean_ctor_set(v___x_303_, 1, v___y_299_);
v___x_304_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_304_, 0, v___x_303_);
return v___x_304_;
}
else
{
lean_object* v_key_305_; lean_object* v_value_306_; lean_object* v_tail_307_; lean_object* v___x_308_; 
v_key_305_ = lean_ctor_get(v_x_296_, 0);
lean_inc(v_key_305_);
v_value_306_ = lean_ctor_get(v_x_296_, 1);
lean_inc(v_value_306_);
v_tail_307_ = lean_ctor_get(v_x_296_, 2);
lean_inc(v_tail_307_);
lean_dec_ref_known(v_x_296_, 3);
lean_inc_ref(v_f_294_);
lean_inc_ref(v___y_298_);
v___x_308_ = lean_apply_6(v_f_294_, v_key_305_, v_value_306_, v___y_297_, v___y_298_, v___y_299_, lean_box(0));
if (lean_obj_tag(v___x_308_) == 0)
{
lean_object* v_a_309_; lean_object* v_fst_310_; 
v_a_309_ = lean_ctor_get(v___x_308_, 0);
lean_inc(v_a_309_);
v_fst_310_ = lean_ctor_get(v_a_309_, 0);
if (lean_obj_tag(v_fst_310_) == 0)
{
lean_dec(v_a_309_);
lean_dec(v_tail_307_);
lean_dec_ref(v_f_294_);
return v___x_308_;
}
else
{
lean_object* v_a_311_; lean_object* v_snd_312_; lean_object* v_fst_313_; lean_object* v_snd_314_; 
lean_dec_ref_known(v___x_308_, 1);
v_a_311_ = lean_ctor_get(v_fst_310_, 0);
lean_inc(v_a_311_);
v_snd_312_ = lean_ctor_get(v_a_309_, 1);
lean_inc(v_snd_312_);
lean_dec(v_a_309_);
v_fst_313_ = lean_ctor_get(v_a_311_, 0);
lean_inc(v_fst_313_);
v_snd_314_ = lean_ctor_get(v_a_311_, 1);
lean_inc(v_snd_314_);
lean_dec(v_a_311_);
v_x_295_ = v_fst_313_;
v_x_296_ = v_tail_307_;
v___y_297_ = v_snd_314_;
v___y_299_ = v_snd_312_;
goto _start;
}
}
else
{
lean_dec(v_tail_307_);
lean_dec_ref(v_f_294_);
return v___x_308_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg___boxed(lean_object* v_f_316_, lean_object* v_x_317_, lean_object* v_x_318_, lean_object* v___y_319_, lean_object* v___y_320_, lean_object* v___y_321_, lean_object* v___y_322_){
_start:
{
lean_object* v_res_323_; 
v_res_323_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg(v_f_316_, v_x_317_, v_x_318_, v___y_319_, v___y_320_, v___y_321_);
lean_dec_ref(v___y_320_);
return v_res_323_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg(lean_object* v_f_324_, lean_object* v_as_325_, size_t v_i_326_, size_t v_stop_327_, lean_object* v_b_328_, lean_object* v___y_329_, lean_object* v___y_330_, lean_object* v___y_331_){
_start:
{
uint8_t v___x_333_; 
v___x_333_ = lean_usize_dec_eq(v_i_326_, v_stop_327_);
if (v___x_333_ == 0)
{
lean_object* v___x_334_; lean_object* v___x_335_; lean_object* v___x_336_; 
v___x_334_ = lean_array_uget_borrowed(v_as_325_, v_i_326_);
v___x_335_ = lean_box(0);
lean_inc(v___x_334_);
lean_inc_ref(v_f_324_);
v___x_336_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg(v_f_324_, v___x_335_, v___x_334_, v___y_329_, v___y_330_, v___y_331_);
if (lean_obj_tag(v___x_336_) == 0)
{
lean_object* v_a_337_; lean_object* v_fst_338_; 
v_a_337_ = lean_ctor_get(v___x_336_, 0);
lean_inc(v_a_337_);
v_fst_338_ = lean_ctor_get(v_a_337_, 0);
if (lean_obj_tag(v_fst_338_) == 0)
{
lean_dec(v_a_337_);
lean_dec_ref(v_f_324_);
return v___x_336_;
}
else
{
lean_object* v_a_339_; lean_object* v_snd_340_; lean_object* v_fst_341_; lean_object* v_snd_342_; size_t v___x_343_; size_t v___x_344_; 
lean_dec_ref_known(v___x_336_, 1);
v_a_339_ = lean_ctor_get(v_fst_338_, 0);
lean_inc(v_a_339_);
v_snd_340_ = lean_ctor_get(v_a_337_, 1);
lean_inc(v_snd_340_);
lean_dec(v_a_337_);
v_fst_341_ = lean_ctor_get(v_a_339_, 0);
lean_inc(v_fst_341_);
v_snd_342_ = lean_ctor_get(v_a_339_, 1);
lean_inc(v_snd_342_);
lean_dec(v_a_339_);
v___x_343_ = ((size_t)1ULL);
v___x_344_ = lean_usize_add(v_i_326_, v___x_343_);
v_i_326_ = v___x_344_;
v_b_328_ = v_fst_341_;
v___y_329_ = v_snd_342_;
v___y_331_ = v_snd_340_;
goto _start;
}
}
else
{
lean_dec_ref(v_f_324_);
return v___x_336_;
}
}
else
{
lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v___x_349_; 
lean_dec_ref(v_f_324_);
v___x_346_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_346_, 0, v_b_328_);
lean_ctor_set(v___x_346_, 1, v___y_329_);
v___x_347_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_347_, 0, v___x_346_);
v___x_348_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_348_, 0, v___x_347_);
lean_ctor_set(v___x_348_, 1, v___y_331_);
v___x_349_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_349_, 0, v___x_348_);
return v___x_349_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg___boxed(lean_object* v_f_350_, lean_object* v_as_351_, lean_object* v_i_352_, lean_object* v_stop_353_, lean_object* v_b_354_, lean_object* v___y_355_, lean_object* v___y_356_, lean_object* v___y_357_, lean_object* v___y_358_){
_start:
{
size_t v_i_boxed_359_; size_t v_stop_boxed_360_; lean_object* v_res_361_; 
v_i_boxed_359_ = lean_unbox_usize(v_i_352_);
lean_dec(v_i_352_);
v_stop_boxed_360_ = lean_unbox_usize(v_stop_353_);
lean_dec(v_stop_353_);
v_res_361_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg(v_f_350_, v_as_351_, v_i_boxed_359_, v_stop_boxed_360_, v_b_354_, v___y_355_, v___y_356_, v___y_357_);
lean_dec_ref(v___y_356_);
lean_dec_ref(v_as_351_);
return v_res_361_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___lam__0(lean_object* v_f_362_, lean_object* v_x_363_, lean_object* v___y_364_, lean_object* v___y_365_, lean_object* v___y_366_, lean_object* v___y_367_, lean_object* v___y_368_){
_start:
{
lean_object* v___x_370_; 
lean_inc_ref(v___y_367_);
v___x_370_ = lean_apply_6(v_f_362_, v___y_364_, v___y_365_, v___y_366_, v___y_367_, v___y_368_, lean_box(0));
return v___x_370_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___lam__0___boxed(lean_object* v_f_371_, lean_object* v_x_372_, lean_object* v___y_373_, lean_object* v___y_374_, lean_object* v___y_375_, lean_object* v___y_376_, lean_object* v___y_377_, lean_object* v___y_378_){
_start:
{
lean_object* v_res_379_; 
v_res_379_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___lam__0(v_f_371_, v_x_372_, v___y_373_, v___y_374_, v___y_375_, v___y_376_, v___y_377_);
lean_dec_ref(v___y_376_);
return v_res_379_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg(lean_object* v_f_380_, lean_object* v_keys_381_, lean_object* v_vals_382_, lean_object* v_i_383_, lean_object* v_acc_384_, lean_object* v___y_385_, lean_object* v___y_386_, lean_object* v___y_387_){
_start:
{
lean_object* v___x_389_; uint8_t v___x_390_; 
v___x_389_ = lean_array_get_size(v_keys_381_);
v___x_390_ = lean_nat_dec_lt(v_i_383_, v___x_389_);
if (v___x_390_ == 0)
{
lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; lean_object* v___x_394_; 
lean_dec(v_i_383_);
lean_dec_ref(v_f_380_);
v___x_391_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_391_, 0, v_acc_384_);
lean_ctor_set(v___x_391_, 1, v___y_385_);
v___x_392_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_392_, 0, v___x_391_);
v___x_393_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_393_, 0, v___x_392_);
lean_ctor_set(v___x_393_, 1, v___y_387_);
v___x_394_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_394_, 0, v___x_393_);
return v___x_394_;
}
else
{
lean_object* v_k_395_; lean_object* v_v_396_; lean_object* v___x_397_; 
v_k_395_ = lean_array_fget_borrowed(v_keys_381_, v_i_383_);
v_v_396_ = lean_array_fget_borrowed(v_vals_382_, v_i_383_);
lean_inc_ref(v_f_380_);
lean_inc_ref(v___y_386_);
lean_inc(v_v_396_);
lean_inc(v_k_395_);
v___x_397_ = lean_apply_7(v_f_380_, v_acc_384_, v_k_395_, v_v_396_, v___y_385_, v___y_386_, v___y_387_, lean_box(0));
if (lean_obj_tag(v___x_397_) == 0)
{
lean_object* v_a_398_; lean_object* v_fst_399_; 
v_a_398_ = lean_ctor_get(v___x_397_, 0);
lean_inc(v_a_398_);
v_fst_399_ = lean_ctor_get(v_a_398_, 0);
if (lean_obj_tag(v_fst_399_) == 0)
{
lean_dec(v_a_398_);
lean_dec(v_i_383_);
lean_dec_ref(v_f_380_);
return v___x_397_;
}
else
{
lean_object* v_a_400_; lean_object* v_snd_401_; lean_object* v_fst_402_; lean_object* v_snd_403_; lean_object* v___x_404_; lean_object* v___x_405_; 
lean_dec_ref_known(v___x_397_, 1);
v_a_400_ = lean_ctor_get(v_fst_399_, 0);
lean_inc(v_a_400_);
v_snd_401_ = lean_ctor_get(v_a_398_, 1);
lean_inc(v_snd_401_);
lean_dec(v_a_398_);
v_fst_402_ = lean_ctor_get(v_a_400_, 0);
lean_inc(v_fst_402_);
v_snd_403_ = lean_ctor_get(v_a_400_, 1);
lean_inc(v_snd_403_);
lean_dec(v_a_400_);
v___x_404_ = lean_unsigned_to_nat(1u);
v___x_405_ = lean_nat_add(v_i_383_, v___x_404_);
lean_dec(v_i_383_);
v_i_383_ = v___x_405_;
v_acc_384_ = v_fst_402_;
v___y_385_ = v_snd_403_;
v___y_387_ = v_snd_401_;
goto _start;
}
}
else
{
lean_dec(v_i_383_);
lean_dec_ref(v_f_380_);
return v___x_397_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg___boxed(lean_object* v_f_407_, lean_object* v_keys_408_, lean_object* v_vals_409_, lean_object* v_i_410_, lean_object* v_acc_411_, lean_object* v___y_412_, lean_object* v___y_413_, lean_object* v___y_414_, lean_object* v___y_415_){
_start:
{
lean_object* v_res_416_; 
v_res_416_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg(v_f_407_, v_keys_408_, v_vals_409_, v_i_410_, v_acc_411_, v___y_412_, v___y_413_, v___y_414_);
lean_dec_ref(v___y_413_);
lean_dec_ref(v_vals_409_);
lean_dec_ref(v_keys_408_);
return v_res_416_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg(lean_object* v_f_417_, lean_object* v_as_418_, size_t v_i_419_, size_t v_stop_420_, lean_object* v_b_421_, lean_object* v___y_422_, lean_object* v___y_423_, lean_object* v___y_424_){
_start:
{
lean_object* v_fst_427_; lean_object* v_snd_428_; lean_object* v_snd_429_; lean_object* v___y_434_; uint8_t v___x_441_; 
v___x_441_ = lean_usize_dec_eq(v_i_419_, v_stop_420_);
if (v___x_441_ == 0)
{
lean_object* v___x_442_; 
v___x_442_ = lean_array_uget_borrowed(v_as_418_, v_i_419_);
switch(lean_obj_tag(v___x_442_))
{
case 0:
{
lean_object* v_key_443_; lean_object* v_val_444_; lean_object* v___x_445_; 
v_key_443_ = lean_ctor_get(v___x_442_, 0);
v_val_444_ = lean_ctor_get(v___x_442_, 1);
lean_inc_ref(v_f_417_);
lean_inc_ref(v___y_423_);
lean_inc(v_val_444_);
lean_inc(v_key_443_);
v___x_445_ = lean_apply_7(v_f_417_, v_b_421_, v_key_443_, v_val_444_, v___y_422_, v___y_423_, v___y_424_, lean_box(0));
v___y_434_ = v___x_445_;
goto v___jp_433_;
}
case 1:
{
lean_object* v_node_446_; lean_object* v___x_447_; 
v_node_446_ = lean_ctor_get(v___x_442_, 0);
lean_inc(v_node_446_);
lean_inc_ref(v_f_417_);
v___x_447_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(v_f_417_, v_node_446_, v_b_421_, v___y_422_, v___y_423_, v___y_424_);
v___y_434_ = v___x_447_;
goto v___jp_433_;
}
default: 
{
v_fst_427_ = v_b_421_;
v_snd_428_ = v___y_422_;
v_snd_429_ = v___y_424_;
goto v___jp_426_;
}
}
}
else
{
lean_object* v___x_448_; lean_object* v___x_449_; lean_object* v___x_450_; lean_object* v___x_451_; 
lean_dec_ref(v_f_417_);
v___x_448_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_448_, 0, v_b_421_);
lean_ctor_set(v___x_448_, 1, v___y_422_);
v___x_449_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_449_, 0, v___x_448_);
v___x_450_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_450_, 0, v___x_449_);
lean_ctor_set(v___x_450_, 1, v___y_424_);
v___x_451_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_451_, 0, v___x_450_);
return v___x_451_;
}
v___jp_426_:
{
size_t v___x_430_; size_t v___x_431_; 
v___x_430_ = ((size_t)1ULL);
v___x_431_ = lean_usize_add(v_i_419_, v___x_430_);
v_i_419_ = v___x_431_;
v_b_421_ = v_fst_427_;
v___y_422_ = v_snd_428_;
v___y_424_ = v_snd_429_;
goto _start;
}
v___jp_433_:
{
if (lean_obj_tag(v___y_434_) == 0)
{
lean_object* v_a_435_; lean_object* v_fst_436_; 
v_a_435_ = lean_ctor_get(v___y_434_, 0);
v_fst_436_ = lean_ctor_get(v_a_435_, 0);
if (lean_obj_tag(v_fst_436_) == 0)
{
lean_dec_ref(v_f_417_);
return v___y_434_;
}
else
{
lean_object* v_a_437_; lean_object* v_snd_438_; lean_object* v_fst_439_; lean_object* v_snd_440_; 
lean_inc(v_a_435_);
lean_dec_ref_known(v___y_434_, 1);
v_a_437_ = lean_ctor_get(v_fst_436_, 0);
lean_inc(v_a_437_);
v_snd_438_ = lean_ctor_get(v_a_435_, 1);
lean_inc(v_snd_438_);
lean_dec(v_a_435_);
v_fst_439_ = lean_ctor_get(v_a_437_, 0);
lean_inc(v_fst_439_);
v_snd_440_ = lean_ctor_get(v_a_437_, 1);
lean_inc(v_snd_440_);
lean_dec(v_a_437_);
v_fst_427_ = v_fst_439_;
v_snd_428_ = v_snd_440_;
v_snd_429_ = v_snd_438_;
goto v___jp_426_;
}
}
else
{
lean_dec_ref(v_f_417_);
return v___y_434_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(lean_object* v_f_452_, lean_object* v_x_453_, lean_object* v_x_454_, lean_object* v___y_455_, lean_object* v___y_456_, lean_object* v___y_457_){
_start:
{
if (lean_obj_tag(v_x_453_) == 0)
{
lean_object* v_es_459_; lean_object* v___x_461_; uint8_t v_isShared_462_; uint8_t v_isSharedCheck_485_; 
v_es_459_ = lean_ctor_get(v_x_453_, 0);
v_isSharedCheck_485_ = !lean_is_exclusive(v_x_453_);
if (v_isSharedCheck_485_ == 0)
{
v___x_461_ = v_x_453_;
v_isShared_462_ = v_isSharedCheck_485_;
goto v_resetjp_460_;
}
else
{
lean_inc(v_es_459_);
lean_dec(v_x_453_);
v___x_461_ = lean_box(0);
v_isShared_462_ = v_isSharedCheck_485_;
goto v_resetjp_460_;
}
v_resetjp_460_:
{
lean_object* v___x_463_; lean_object* v___x_464_; uint8_t v___x_465_; 
v___x_463_ = lean_unsigned_to_nat(0u);
v___x_464_ = lean_array_get_size(v_es_459_);
v___x_465_ = lean_nat_dec_lt(v___x_463_, v___x_464_);
if (v___x_465_ == 0)
{
lean_object* v___x_466_; lean_object* v___x_468_; 
lean_dec_ref(v_es_459_);
lean_dec_ref(v_f_452_);
v___x_466_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_466_, 0, v_x_454_);
lean_ctor_set(v___x_466_, 1, v___y_455_);
if (v_isShared_462_ == 0)
{
lean_ctor_set_tag(v___x_461_, 1);
lean_ctor_set(v___x_461_, 0, v___x_466_);
v___x_468_ = v___x_461_;
goto v_reusejp_467_;
}
else
{
lean_object* v_reuseFailAlloc_471_; 
v_reuseFailAlloc_471_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_471_, 0, v___x_466_);
v___x_468_ = v_reuseFailAlloc_471_;
goto v_reusejp_467_;
}
v_reusejp_467_:
{
lean_object* v___x_469_; lean_object* v___x_470_; 
v___x_469_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_469_, 0, v___x_468_);
lean_ctor_set(v___x_469_, 1, v___y_457_);
v___x_470_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_470_, 0, v___x_469_);
return v___x_470_;
}
}
else
{
uint8_t v___x_472_; 
v___x_472_ = lean_nat_dec_le(v___x_464_, v___x_464_);
if (v___x_472_ == 0)
{
if (v___x_465_ == 0)
{
lean_object* v___x_473_; lean_object* v___x_475_; 
lean_dec_ref(v_es_459_);
lean_dec_ref(v_f_452_);
v___x_473_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_473_, 0, v_x_454_);
lean_ctor_set(v___x_473_, 1, v___y_455_);
if (v_isShared_462_ == 0)
{
lean_ctor_set_tag(v___x_461_, 1);
lean_ctor_set(v___x_461_, 0, v___x_473_);
v___x_475_ = v___x_461_;
goto v_reusejp_474_;
}
else
{
lean_object* v_reuseFailAlloc_478_; 
v_reuseFailAlloc_478_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_478_, 0, v___x_473_);
v___x_475_ = v_reuseFailAlloc_478_;
goto v_reusejp_474_;
}
v_reusejp_474_:
{
lean_object* v___x_476_; lean_object* v___x_477_; 
v___x_476_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_476_, 0, v___x_475_);
lean_ctor_set(v___x_476_, 1, v___y_457_);
v___x_477_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_477_, 0, v___x_476_);
return v___x_477_;
}
}
else
{
size_t v___x_479_; size_t v___x_480_; lean_object* v___x_481_; 
lean_del_object(v___x_461_);
v___x_479_ = ((size_t)0ULL);
v___x_480_ = lean_usize_of_nat(v___x_464_);
v___x_481_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg(v_f_452_, v_es_459_, v___x_479_, v___x_480_, v_x_454_, v___y_455_, v___y_456_, v___y_457_);
lean_dec_ref(v_es_459_);
return v___x_481_;
}
}
else
{
size_t v___x_482_; size_t v___x_483_; lean_object* v___x_484_; 
lean_del_object(v___x_461_);
v___x_482_ = ((size_t)0ULL);
v___x_483_ = lean_usize_of_nat(v___x_464_);
v___x_484_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg(v_f_452_, v_es_459_, v___x_482_, v___x_483_, v_x_454_, v___y_455_, v___y_456_, v___y_457_);
lean_dec_ref(v_es_459_);
return v___x_484_;
}
}
}
}
else
{
lean_object* v_ks_486_; lean_object* v_vs_487_; lean_object* v___x_488_; lean_object* v___x_489_; 
v_ks_486_ = lean_ctor_get(v_x_453_, 0);
lean_inc_ref(v_ks_486_);
v_vs_487_ = lean_ctor_get(v_x_453_, 1);
lean_inc_ref(v_vs_487_);
lean_dec_ref_known(v_x_453_, 2);
v___x_488_ = lean_unsigned_to_nat(0u);
v___x_489_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg(v_f_452_, v_ks_486_, v_vs_487_, v___x_488_, v_x_454_, v___y_455_, v___y_456_, v___y_457_);
lean_dec_ref(v_vs_487_);
lean_dec_ref(v_ks_486_);
return v___x_489_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg___boxed(lean_object* v_f_490_, lean_object* v_x_491_, lean_object* v_x_492_, lean_object* v___y_493_, lean_object* v___y_494_, lean_object* v___y_495_, lean_object* v___y_496_){
_start:
{
lean_object* v_res_497_; 
v_res_497_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(v_f_490_, v_x_491_, v_x_492_, v___y_493_, v___y_494_, v___y_495_);
lean_dec_ref(v___y_494_);
return v_res_497_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg___boxed(lean_object* v_f_498_, lean_object* v_as_499_, lean_object* v_i_500_, lean_object* v_stop_501_, lean_object* v_b_502_, lean_object* v___y_503_, lean_object* v___y_504_, lean_object* v___y_505_, lean_object* v___y_506_){
_start:
{
size_t v_i_boxed_507_; size_t v_stop_boxed_508_; lean_object* v_res_509_; 
v_i_boxed_507_ = lean_unbox_usize(v_i_500_);
lean_dec(v_i_500_);
v_stop_boxed_508_ = lean_unbox_usize(v_stop_501_);
lean_dec(v_stop_501_);
v_res_509_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg(v_f_498_, v_as_499_, v_i_boxed_507_, v_stop_boxed_508_, v_b_502_, v___y_503_, v___y_504_, v___y_505_);
lean_dec_ref(v___y_504_);
lean_dec_ref(v_as_499_);
return v_res_509_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(lean_object* v_map_510_, lean_object* v_f_511_, lean_object* v___y_512_, lean_object* v___y_513_, lean_object* v___y_514_){
_start:
{
lean_object* v___f_516_; lean_object* v___x_517_; lean_object* v___x_518_; 
v___f_516_ = lean_alloc_closure((void*)(lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___lam__0___boxed), 8, 1);
lean_closure_set(v___f_516_, 0, v_f_511_);
v___x_517_ = lean_box(0);
v___x_518_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(v___f_516_, v_map_510_, v___x_517_, v___y_512_, v___y_513_, v___y_514_);
return v___x_518_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg___boxed(lean_object* v_map_519_, lean_object* v_f_520_, lean_object* v___y_521_, lean_object* v___y_522_, lean_object* v___y_523_, lean_object* v___y_524_){
_start:
{
lean_object* v_res_525_; 
v_res_525_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(v_map_519_, v_f_520_, v___y_521_, v___y_522_, v___y_523_);
lean_dec_ref(v___y_522_);
return v_res_525_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg(lean_object* v_s_526_, lean_object* v_f_527_, lean_object* v___y_528_, lean_object* v___y_529_, lean_object* v___y_530_){
_start:
{
lean_object* v_map_u2081_532_; lean_object* v_map_u2082_533_; lean_object* v_buckets_534_; lean_object* v___x_535_; lean_object* v___x_536_; uint8_t v___x_537_; 
v_map_u2081_532_ = lean_ctor_get(v_s_526_, 0);
lean_inc_ref(v_map_u2081_532_);
v_map_u2082_533_ = lean_ctor_get(v_s_526_, 1);
lean_inc_ref(v_map_u2082_533_);
lean_dec_ref(v_s_526_);
v_buckets_534_ = lean_ctor_get(v_map_u2081_532_, 1);
lean_inc_ref(v_buckets_534_);
lean_dec_ref(v_map_u2081_532_);
v___x_535_ = lean_unsigned_to_nat(0u);
v___x_536_ = lean_array_get_size(v_buckets_534_);
v___x_537_ = lean_nat_dec_lt(v___x_535_, v___x_536_);
if (v___x_537_ == 0)
{
lean_object* v___x_538_; 
lean_dec_ref(v_buckets_534_);
v___x_538_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(v_map_u2082_533_, v_f_527_, v___y_528_, v___y_529_, v___y_530_);
return v___x_538_;
}
else
{
lean_object* v___x_539_; uint8_t v___x_540_; 
v___x_539_ = lean_box(0);
v___x_540_ = lean_nat_dec_le(v___x_536_, v___x_536_);
if (v___x_540_ == 0)
{
if (v___x_537_ == 0)
{
lean_object* v___x_541_; 
lean_dec_ref(v_buckets_534_);
v___x_541_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(v_map_u2082_533_, v_f_527_, v___y_528_, v___y_529_, v___y_530_);
return v___x_541_;
}
else
{
size_t v___x_542_; size_t v___x_543_; lean_object* v___x_544_; 
v___x_542_ = ((size_t)0ULL);
v___x_543_ = lean_usize_of_nat(v___x_536_);
lean_inc_ref(v_f_527_);
v___x_544_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg(v_f_527_, v_buckets_534_, v___x_542_, v___x_543_, v___x_539_, v___y_528_, v___y_529_, v___y_530_);
lean_dec_ref(v_buckets_534_);
if (lean_obj_tag(v___x_544_) == 0)
{
lean_object* v_a_545_; lean_object* v_fst_546_; 
v_a_545_ = lean_ctor_get(v___x_544_, 0);
lean_inc(v_a_545_);
v_fst_546_ = lean_ctor_get(v_a_545_, 0);
if (lean_obj_tag(v_fst_546_) == 0)
{
lean_dec(v_a_545_);
lean_dec_ref(v_map_u2082_533_);
lean_dec_ref(v_f_527_);
return v___x_544_;
}
else
{
lean_object* v_a_547_; lean_object* v_snd_548_; lean_object* v_snd_549_; lean_object* v___x_550_; 
lean_dec_ref_known(v___x_544_, 1);
v_a_547_ = lean_ctor_get(v_fst_546_, 0);
lean_inc(v_a_547_);
v_snd_548_ = lean_ctor_get(v_a_545_, 1);
lean_inc(v_snd_548_);
lean_dec(v_a_545_);
v_snd_549_ = lean_ctor_get(v_a_547_, 1);
lean_inc(v_snd_549_);
lean_dec(v_a_547_);
v___x_550_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(v_map_u2082_533_, v_f_527_, v_snd_549_, v___y_529_, v_snd_548_);
return v___x_550_;
}
}
else
{
lean_dec_ref(v_map_u2082_533_);
lean_dec_ref(v_f_527_);
return v___x_544_;
}
}
}
else
{
size_t v___x_551_; size_t v___x_552_; lean_object* v___x_553_; 
v___x_551_ = ((size_t)0ULL);
v___x_552_ = lean_usize_of_nat(v___x_536_);
lean_inc_ref(v_f_527_);
v___x_553_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg(v_f_527_, v_buckets_534_, v___x_551_, v___x_552_, v___x_539_, v___y_528_, v___y_529_, v___y_530_);
lean_dec_ref(v_buckets_534_);
if (lean_obj_tag(v___x_553_) == 0)
{
lean_object* v_a_554_; lean_object* v_fst_555_; 
v_a_554_ = lean_ctor_get(v___x_553_, 0);
lean_inc(v_a_554_);
v_fst_555_ = lean_ctor_get(v_a_554_, 0);
if (lean_obj_tag(v_fst_555_) == 0)
{
lean_dec(v_a_554_);
lean_dec_ref(v_map_u2082_533_);
lean_dec_ref(v_f_527_);
return v___x_553_;
}
else
{
lean_object* v_a_556_; lean_object* v_snd_557_; lean_object* v_snd_558_; lean_object* v___x_559_; 
lean_dec_ref_known(v___x_553_, 1);
v_a_556_ = lean_ctor_get(v_fst_555_, 0);
lean_inc(v_a_556_);
v_snd_557_ = lean_ctor_get(v_a_554_, 1);
lean_inc(v_snd_557_);
lean_dec(v_a_554_);
v_snd_558_ = lean_ctor_get(v_a_556_, 1);
lean_inc(v_snd_558_);
lean_dec(v_a_556_);
v___x_559_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(v_map_u2082_533_, v_f_527_, v_snd_558_, v___y_529_, v_snd_557_);
return v___x_559_;
}
}
else
{
lean_dec_ref(v_map_u2082_533_);
lean_dec_ref(v_f_527_);
return v___x_553_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg___boxed(lean_object* v_s_560_, lean_object* v_f_561_, lean_object* v___y_562_, lean_object* v___y_563_, lean_object* v___y_564_, lean_object* v___y_565_){
_start:
{
lean_object* v_res_566_; 
v_res_566_ = lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg(v_s_560_, v_f_561_, v___y_562_, v___y_563_, v___y_564_);
lean_dec_ref(v___y_563_);
return v_res_566_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_List_any___at___00initState_spec__2(lean_object* v_x_568_){
_start:
{
if (lean_obj_tag(v_x_568_) == 0)
{
uint8_t v___x_569_; 
v___x_569_ = 0;
return v___x_569_;
}
else
{
lean_object* v_head_570_; lean_object* v_tail_571_; lean_object* v___x_572_; uint8_t v___x_573_; 
v_head_570_ = lean_ctor_get(v_x_568_, 0);
v_tail_571_ = lean_ctor_get(v_x_568_, 1);
v___x_572_ = ((lean_object*)(lp_proofEnvironment_List_any___at___00initState_spec__2___closed__0));
v___x_573_ = lean_string_dec_eq(v_head_570_, v___x_572_);
if (v___x_573_ == 0)
{
v_x_568_ = v_tail_571_;
goto _start;
}
else
{
return v___x_573_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_any___at___00initState_spec__2___boxed(lean_object* v_x_575_){
_start:
{
uint8_t v_res_576_; lean_object* v_r_577_; 
v_res_576_ = lp_proofEnvironment_List_any___at___00initState_spec__2(v_x_575_);
lean_dec(v_x_575_);
v_r_577_ = lean_box(v_res_576_);
return v_r_577_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_List_any___at___00initState_spec__1(lean_object* v_x_579_){
_start:
{
if (lean_obj_tag(v_x_579_) == 0)
{
uint8_t v___x_580_; 
v___x_580_ = 0;
return v___x_580_;
}
else
{
lean_object* v_head_581_; lean_object* v_tail_582_; lean_object* v___x_583_; uint8_t v___x_584_; 
v_head_581_ = lean_ctor_get(v_x_579_, 0);
v_tail_582_ = lean_ctor_get(v_x_579_, 1);
v___x_583_ = ((lean_object*)(lp_proofEnvironment_List_any___at___00initState_spec__1___closed__0));
v___x_584_ = lean_string_dec_eq(v_head_581_, v___x_583_);
if (v___x_584_ == 0)
{
v_x_579_ = v_tail_582_;
goto _start;
}
else
{
return v___x_584_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_any___at___00initState_spec__1___boxed(lean_object* v_x_586_){
_start:
{
uint8_t v_res_587_; lean_object* v_r_588_; 
v_res_587_ = lp_proofEnvironment_List_any___at___00initState_spec__1(v_x_586_);
lean_dec(v_x_586_);
v_r_588_ = lean_box(v_res_587_);
return v_r_588_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_initState(lean_object* v_env_590_, lean_object* v_cliOptions_591_, lean_object* v_a_592_, lean_object* v_a_593_){
_start:
{
lean_object* v___f_595_; lean_object* v_recursorMap_596_; lean_object* v___x_597_; lean_object* v___x_598_; 
v___f_595_ = ((lean_object*)(lp_proofEnvironment_initState___closed__0));
v_recursorMap_596_ = lean_box(1);
v___x_597_ = l_Lean_Environment_constants(v_env_590_);
v___x_598_ = lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg(v___x_597_, v___f_595_, v_recursorMap_596_, v_a_592_, v_a_593_);
if (lean_obj_tag(v___x_598_) == 0)
{
lean_object* v_a_599_; lean_object* v___x_601_; uint8_t v_isShared_602_; uint8_t v_isSharedCheck_637_; 
v_a_599_ = lean_ctor_get(v___x_598_, 0);
v_isSharedCheck_637_ = !lean_is_exclusive(v___x_598_);
if (v_isSharedCheck_637_ == 0)
{
v___x_601_ = v___x_598_;
v_isShared_602_ = v_isSharedCheck_637_;
goto v_resetjp_600_;
}
else
{
lean_inc(v_a_599_);
lean_dec(v___x_598_);
v___x_601_ = lean_box(0);
v_isShared_602_ = v_isSharedCheck_637_;
goto v_resetjp_600_;
}
v_resetjp_600_:
{
lean_object* v_fst_603_; lean_object* v_snd_604_; lean_object* v___x_606_; uint8_t v_isShared_607_; uint8_t v_isSharedCheck_636_; 
v_fst_603_ = lean_ctor_get(v_a_599_, 0);
v_snd_604_ = lean_ctor_get(v_a_599_, 1);
v_isSharedCheck_636_ = !lean_is_exclusive(v_a_599_);
if (v_isSharedCheck_636_ == 0)
{
v___x_606_ = v_a_599_;
v_isShared_607_ = v_isSharedCheck_636_;
goto v_resetjp_605_;
}
else
{
lean_inc(v_snd_604_);
lean_inc(v_fst_603_);
lean_dec(v_a_599_);
v___x_606_ = lean_box(0);
v_isShared_607_ = v_isSharedCheck_636_;
goto v_resetjp_605_;
}
v_resetjp_605_:
{
lean_object* v_fst_609_; 
if (lean_obj_tag(v_fst_603_) == 0)
{
lean_object* v_a_633_; 
v_a_633_ = lean_ctor_get(v_fst_603_, 0);
lean_inc(v_a_633_);
lean_dec_ref_known(v_fst_603_, 1);
v_fst_609_ = v_a_633_;
goto v___jp_608_;
}
else
{
lean_object* v_a_634_; lean_object* v_snd_635_; 
v_a_634_ = lean_ctor_get(v_fst_603_, 0);
lean_inc(v_a_634_);
lean_dec_ref_known(v_fst_603_, 1);
v_snd_635_ = lean_ctor_get(v_a_634_, 1);
lean_inc(v_snd_635_);
lean_dec(v_a_634_);
v_fst_609_ = v_snd_635_;
goto v___jp_608_;
}
v___jp_608_:
{
lean_object* v_visitedNames_610_; lean_object* v_visitedLevels_611_; lean_object* v_visitedExprs_612_; lean_object* v_visitedConstants_613_; lean_object* v_noMDataExprs_614_; lean_object* v___x_616_; uint8_t v_isShared_617_; uint8_t v_isSharedCheck_631_; 
v_visitedNames_610_ = lean_ctor_get(v_snd_604_, 0);
v_visitedLevels_611_ = lean_ctor_get(v_snd_604_, 1);
v_visitedExprs_612_ = lean_ctor_get(v_snd_604_, 2);
v_visitedConstants_613_ = lean_ctor_get(v_snd_604_, 3);
v_noMDataExprs_614_ = lean_ctor_get(v_snd_604_, 4);
v_isSharedCheck_631_ = !lean_is_exclusive(v_snd_604_);
if (v_isSharedCheck_631_ == 0)
{
lean_object* v_unused_632_; 
v_unused_632_ = lean_ctor_get(v_snd_604_, 5);
lean_dec(v_unused_632_);
v___x_616_ = v_snd_604_;
v_isShared_617_ = v_isSharedCheck_631_;
goto v_resetjp_615_;
}
else
{
lean_inc(v_noMDataExprs_614_);
lean_inc(v_visitedConstants_613_);
lean_inc(v_visitedExprs_612_);
lean_inc(v_visitedLevels_611_);
lean_inc(v_visitedNames_610_);
lean_dec(v_snd_604_);
v___x_616_ = lean_box(0);
v_isShared_617_ = v_isSharedCheck_631_;
goto v_resetjp_615_;
}
v_resetjp_615_:
{
lean_object* v___x_618_; uint8_t v___x_619_; uint8_t v___x_620_; uint8_t v___x_621_; lean_object* v___x_623_; 
v___x_618_ = lean_box(0);
v___x_619_ = lp_proofEnvironment_List_any___at___00initState_spec__0(v_cliOptions_591_);
v___x_620_ = lp_proofEnvironment_List_any___at___00initState_spec__1(v_cliOptions_591_);
v___x_621_ = lp_proofEnvironment_List_any___at___00initState_spec__2(v_cliOptions_591_);
if (v_isShared_617_ == 0)
{
lean_ctor_set(v___x_616_, 5, v_fst_609_);
v___x_623_ = v___x_616_;
goto v_reusejp_622_;
}
else
{
lean_object* v_reuseFailAlloc_630_; 
v_reuseFailAlloc_630_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_630_, 0, v_visitedNames_610_);
lean_ctor_set(v_reuseFailAlloc_630_, 1, v_visitedLevels_611_);
lean_ctor_set(v_reuseFailAlloc_630_, 2, v_visitedExprs_612_);
lean_ctor_set(v_reuseFailAlloc_630_, 3, v_visitedConstants_613_);
lean_ctor_set(v_reuseFailAlloc_630_, 4, v_noMDataExprs_614_);
lean_ctor_set(v_reuseFailAlloc_630_, 5, v_fst_609_);
v___x_623_ = v_reuseFailAlloc_630_;
goto v_reusejp_622_;
}
v_reusejp_622_:
{
lean_object* v___x_625_; 
lean_ctor_set_uint8(v___x_623_, sizeof(void*)*6, v___x_619_);
lean_ctor_set_uint8(v___x_623_, sizeof(void*)*6 + 1, v___x_620_);
lean_ctor_set_uint8(v___x_623_, sizeof(void*)*6 + 2, v___x_621_);
if (v_isShared_607_ == 0)
{
lean_ctor_set(v___x_606_, 1, v___x_623_);
lean_ctor_set(v___x_606_, 0, v___x_618_);
v___x_625_ = v___x_606_;
goto v_reusejp_624_;
}
else
{
lean_object* v_reuseFailAlloc_629_; 
v_reuseFailAlloc_629_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_629_, 0, v___x_618_);
lean_ctor_set(v_reuseFailAlloc_629_, 1, v___x_623_);
v___x_625_ = v_reuseFailAlloc_629_;
goto v_reusejp_624_;
}
v_reusejp_624_:
{
lean_object* v___x_627_; 
if (v_isShared_602_ == 0)
{
lean_ctor_set(v___x_601_, 0, v___x_625_);
v___x_627_ = v___x_601_;
goto v_reusejp_626_;
}
else
{
lean_object* v_reuseFailAlloc_628_; 
v_reuseFailAlloc_628_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_628_, 0, v___x_625_);
v___x_627_ = v_reuseFailAlloc_628_;
goto v_reusejp_626_;
}
v_reusejp_626_:
{
return v___x_627_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_638_; lean_object* v___x_640_; uint8_t v_isShared_641_; uint8_t v_isSharedCheck_645_; 
v_a_638_ = lean_ctor_get(v___x_598_, 0);
v_isSharedCheck_645_ = !lean_is_exclusive(v___x_598_);
if (v_isSharedCheck_645_ == 0)
{
v___x_640_ = v___x_598_;
v_isShared_641_ = v_isSharedCheck_645_;
goto v_resetjp_639_;
}
else
{
lean_inc(v_a_638_);
lean_dec(v___x_598_);
v___x_640_ = lean_box(0);
v_isShared_641_ = v_isSharedCheck_645_;
goto v_resetjp_639_;
}
v_resetjp_639_:
{
lean_object* v___x_643_; 
if (v_isShared_641_ == 0)
{
v___x_643_ = v___x_640_;
goto v_reusejp_642_;
}
else
{
lean_object* v_reuseFailAlloc_644_; 
v_reuseFailAlloc_644_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_644_, 0, v_a_638_);
v___x_643_ = v_reuseFailAlloc_644_;
goto v_reusejp_642_;
}
v_reusejp_642_:
{
return v___x_643_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_initState___boxed(lean_object* v_env_646_, lean_object* v_cliOptions_647_, lean_object* v_a_648_, lean_object* v_a_649_, lean_object* v_a_650_){
_start:
{
lean_object* v_res_651_; 
v_res_651_ = lp_proofEnvironment_initState(v_env_646_, v_cliOptions_647_, v_a_648_, v_a_649_);
lean_dec_ref(v_a_648_);
lean_dec(v_cliOptions_647_);
return v_res_651_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3(lean_object* v_val_652_, lean_object* v_k_653_, lean_object* v_t_654_, lean_object* v_hl_655_){
_start:
{
lean_object* v___x_656_; 
v___x_656_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_Const_alter___at___00initState_spec__3___redArg(v_val_652_, v_k_653_, v_t_654_);
return v___x_656_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4(lean_object* v_val_657_, lean_object* v_as_658_, lean_object* v_as_x27_659_, lean_object* v_b_660_, lean_object* v_a_661_, lean_object* v___y_662_, lean_object* v___y_663_){
_start:
{
lean_object* v___x_665_; 
v___x_665_ = lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___redArg(v_val_657_, v_as_x27_659_, v_b_660_, v___y_663_);
return v___x_665_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4___boxed(lean_object* v_val_666_, lean_object* v_as_667_, lean_object* v_as_x27_668_, lean_object* v_b_669_, lean_object* v_a_670_, lean_object* v___y_671_, lean_object* v___y_672_, lean_object* v___y_673_){
_start:
{
lean_object* v_res_674_; 
v_res_674_ = lp_proofEnvironment_List_forIn_x27_loop___at___00initState_spec__4(v_val_666_, v_as_667_, v_as_x27_668_, v_b_669_, v_a_670_, v___y_671_, v___y_672_);
lean_dec_ref(v___y_671_);
lean_dec(v_as_x27_668_);
lean_dec(v_as_667_);
return v_res_674_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5(lean_object* v_00_u03b2_675_, lean_object* v_s_676_, lean_object* v_f_677_, lean_object* v___y_678_, lean_object* v___y_679_, lean_object* v___y_680_){
_start:
{
lean_object* v___x_682_; 
v___x_682_ = lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___redArg(v_s_676_, v_f_677_, v___y_678_, v___y_679_, v___y_680_);
return v___x_682_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5___boxed(lean_object* v_00_u03b2_683_, lean_object* v_s_684_, lean_object* v_f_685_, lean_object* v___y_686_, lean_object* v___y_687_, lean_object* v___y_688_, lean_object* v___y_689_){
_start:
{
lean_object* v_res_690_; 
v_res_690_ = lp_proofEnvironment_Lean_SMap_forM___at___00initState_spec__5(v_00_u03b2_683_, v_s_684_, v_f_685_, v___y_686_, v___y_687_, v___y_688_);
lean_dec_ref(v___y_687_);
return v_res_690_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5(lean_object* v_00_u03b2_691_, lean_object* v_f_692_, lean_object* v_x_693_, lean_object* v_x_694_, lean_object* v___y_695_, lean_object* v___y_696_, lean_object* v___y_697_){
_start:
{
lean_object* v___x_699_; 
v___x_699_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___redArg(v_f_692_, v_x_693_, v_x_694_, v___y_695_, v___y_696_, v___y_697_);
return v___x_699_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5___boxed(lean_object* v_00_u03b2_700_, lean_object* v_f_701_, lean_object* v_x_702_, lean_object* v_x_703_, lean_object* v___y_704_, lean_object* v___y_705_, lean_object* v___y_706_, lean_object* v___y_707_){
_start:
{
lean_object* v_res_708_; 
v_res_708_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__5(v_00_u03b2_700_, v_f_701_, v_x_702_, v_x_703_, v___y_704_, v___y_705_, v___y_706_);
lean_dec_ref(v___y_705_);
return v_res_708_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6(lean_object* v_00_u03b2_709_, lean_object* v_map_710_, lean_object* v_f_711_, lean_object* v___y_712_, lean_object* v___y_713_, lean_object* v___y_714_){
_start:
{
lean_object* v___x_716_; 
v___x_716_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___redArg(v_map_710_, v_f_711_, v___y_712_, v___y_713_, v___y_714_);
return v___x_716_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6___boxed(lean_object* v_00_u03b2_717_, lean_object* v_map_718_, lean_object* v_f_719_, lean_object* v___y_720_, lean_object* v___y_721_, lean_object* v___y_722_, lean_object* v___y_723_){
_start:
{
lean_object* v_res_724_; 
v_res_724_ = lp_proofEnvironment_Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6(v_00_u03b2_717_, v_map_718_, v_f_719_, v___y_720_, v___y_721_, v___y_722_);
lean_dec_ref(v___y_721_);
return v_res_724_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7(lean_object* v_00_u03b2_725_, lean_object* v_f_726_, lean_object* v_as_727_, size_t v_i_728_, size_t v_stop_729_, lean_object* v_b_730_, lean_object* v___y_731_, lean_object* v___y_732_, lean_object* v___y_733_){
_start:
{
lean_object* v___x_735_; 
v___x_735_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___redArg(v_f_726_, v_as_727_, v_i_728_, v_stop_729_, v_b_730_, v___y_731_, v___y_732_, v___y_733_);
return v___x_735_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7___boxed(lean_object* v_00_u03b2_736_, lean_object* v_f_737_, lean_object* v_as_738_, lean_object* v_i_739_, lean_object* v_stop_740_, lean_object* v_b_741_, lean_object* v___y_742_, lean_object* v___y_743_, lean_object* v___y_744_, lean_object* v___y_745_){
_start:
{
size_t v_i_boxed_746_; size_t v_stop_boxed_747_; lean_object* v_res_748_; 
v_i_boxed_746_ = lean_unbox_usize(v_i_739_);
lean_dec(v_i_739_);
v_stop_boxed_747_ = lean_unbox_usize(v_stop_740_);
lean_dec(v_stop_740_);
v_res_748_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_SMap_forM___at___00initState_spec__5_spec__7(v_00_u03b2_736_, v_f_737_, v_as_738_, v_i_boxed_746_, v_stop_boxed_747_, v_b_741_, v___y_742_, v___y_743_, v___y_744_);
lean_dec_ref(v___y_743_);
lean_dec_ref(v_as_738_);
return v_res_748_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___redArg(lean_object* v_map_749_, lean_object* v_f_750_, lean_object* v_init_751_, lean_object* v___y_752_, lean_object* v___y_753_, lean_object* v___y_754_){
_start:
{
lean_object* v___x_756_; 
v___x_756_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(v_f_750_, v_map_749_, v_init_751_, v___y_752_, v___y_753_, v___y_754_);
return v___x_756_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___redArg___boxed(lean_object* v_map_757_, lean_object* v_f_758_, lean_object* v_init_759_, lean_object* v___y_760_, lean_object* v___y_761_, lean_object* v___y_762_, lean_object* v___y_763_){
_start:
{
lean_object* v_res_764_; 
v_res_764_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___redArg(v_map_757_, v_f_758_, v_init_759_, v___y_760_, v___y_761_, v___y_762_);
lean_dec_ref(v___y_761_);
return v_res_764_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7(lean_object* v_00_u03c3_765_, lean_object* v_00_u03b2_766_, lean_object* v_map_767_, lean_object* v_f_768_, lean_object* v_init_769_, lean_object* v___y_770_, lean_object* v___y_771_, lean_object* v___y_772_){
_start:
{
lean_object* v___x_774_; 
v___x_774_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(v_f_768_, v_map_767_, v_init_769_, v___y_770_, v___y_771_, v___y_772_);
return v___x_774_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7___boxed(lean_object* v_00_u03c3_775_, lean_object* v_00_u03b2_776_, lean_object* v_map_777_, lean_object* v_f_778_, lean_object* v_init_779_, lean_object* v___y_780_, lean_object* v___y_781_, lean_object* v___y_782_, lean_object* v___y_783_){
_start:
{
lean_object* v_res_784_; 
v_res_784_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7(v_00_u03c3_775_, v_00_u03b2_776_, v_map_777_, v_f_778_, v_init_779_, v___y_780_, v___y_781_, v___y_782_);
lean_dec_ref(v___y_781_);
return v_res_784_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8(lean_object* v_00_u03c3_785_, lean_object* v_00_u03b1_786_, lean_object* v_00_u03b2_787_, lean_object* v_f_788_, lean_object* v_x_789_, lean_object* v_x_790_, lean_object* v___y_791_, lean_object* v___y_792_, lean_object* v___y_793_){
_start:
{
lean_object* v___x_795_; 
v___x_795_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___redArg(v_f_788_, v_x_789_, v_x_790_, v___y_791_, v___y_792_, v___y_793_);
return v___x_795_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8___boxed(lean_object* v_00_u03c3_796_, lean_object* v_00_u03b1_797_, lean_object* v_00_u03b2_798_, lean_object* v_f_799_, lean_object* v_x_800_, lean_object* v_x_801_, lean_object* v___y_802_, lean_object* v___y_803_, lean_object* v___y_804_, lean_object* v___y_805_){
_start:
{
lean_object* v_res_806_; 
v_res_806_ = lp_proofEnvironment_Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8(v_00_u03c3_796_, v_00_u03b1_797_, v_00_u03b2_798_, v_f_799_, v_x_800_, v_x_801_, v___y_802_, v___y_803_, v___y_804_);
lean_dec_ref(v___y_803_);
return v_res_806_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10(lean_object* v_00_u03b1_807_, lean_object* v_00_u03b2_808_, lean_object* v_00_u03c3_809_, lean_object* v_f_810_, lean_object* v_as_811_, size_t v_i_812_, size_t v_stop_813_, lean_object* v_b_814_, lean_object* v___y_815_, lean_object* v___y_816_, lean_object* v___y_817_){
_start:
{
lean_object* v___x_819_; 
v___x_819_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___redArg(v_f_810_, v_as_811_, v_i_812_, v_stop_813_, v_b_814_, v___y_815_, v___y_816_, v___y_817_);
return v___x_819_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10___boxed(lean_object* v_00_u03b1_820_, lean_object* v_00_u03b2_821_, lean_object* v_00_u03c3_822_, lean_object* v_f_823_, lean_object* v_as_824_, lean_object* v_i_825_, lean_object* v_stop_826_, lean_object* v_b_827_, lean_object* v___y_828_, lean_object* v___y_829_, lean_object* v___y_830_, lean_object* v___y_831_){
_start:
{
size_t v_i_boxed_832_; size_t v_stop_boxed_833_; lean_object* v_res_834_; 
v_i_boxed_832_ = lean_unbox_usize(v_i_825_);
lean_dec(v_i_825_);
v_stop_boxed_833_ = lean_unbox_usize(v_stop_826_);
lean_dec(v_stop_826_);
v_res_834_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__10(v_00_u03b1_820_, v_00_u03b2_821_, v_00_u03c3_822_, v_f_823_, v_as_824_, v_i_boxed_832_, v_stop_boxed_833_, v_b_827_, v___y_828_, v___y_829_, v___y_830_);
lean_dec_ref(v___y_829_);
lean_dec_ref(v_as_824_);
return v_res_834_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11(lean_object* v_00_u03c3_835_, lean_object* v_00_u03b1_836_, lean_object* v_00_u03b2_837_, lean_object* v_f_838_, lean_object* v_keys_839_, lean_object* v_vals_840_, lean_object* v_heq_841_, lean_object* v_i_842_, lean_object* v_acc_843_, lean_object* v___y_844_, lean_object* v___y_845_, lean_object* v___y_846_){
_start:
{
lean_object* v___x_848_; 
v___x_848_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___redArg(v_f_838_, v_keys_839_, v_vals_840_, v_i_842_, v_acc_843_, v___y_844_, v___y_845_, v___y_846_);
return v___x_848_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11___boxed(lean_object* v_00_u03c3_849_, lean_object* v_00_u03b1_850_, lean_object* v_00_u03b2_851_, lean_object* v_f_852_, lean_object* v_keys_853_, lean_object* v_vals_854_, lean_object* v_heq_855_, lean_object* v_i_856_, lean_object* v_acc_857_, lean_object* v___y_858_, lean_object* v___y_859_, lean_object* v___y_860_, lean_object* v___y_861_){
_start:
{
lean_object* v_res_862_; 
v_res_862_ = lp_proofEnvironment___private_Lean_Data_PersistentHashMap_0__Lean_PersistentHashMap_foldlMAux_traverse___at___00Lean_PersistentHashMap_foldlMAux___at___00Lean_PersistentHashMap_foldlM___at___00Lean_PersistentHashMap_forM___at___00Lean_SMap_forM___at___00initState_spec__5_spec__6_spec__7_spec__8_spec__11(v_00_u03c3_849_, v_00_u03b1_850_, v_00_u03b2_851_, v_f_852_, v_keys_853_, v_vals_854_, v_heq_855_, v_i_856_, v_acc_857_, v___y_858_, v___y_859_, v___y_860_);
lean_dec_ref(v___y_859_);
lean_dec_ref(v_vals_854_);
lean_dec_ref(v_keys_853_);
return v_res_862_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx___redArg(lean_object* v_inst_864_, lean_object* v_inst_865_, lean_object* v_x_866_, lean_object* v_namespaced_867_, lean_object* v_getM_868_, lean_object* v_setM_869_, lean_object* v_rec_870_, lean_object* v_a_871_, lean_object* v_a_872_){
_start:
{
lean_object* v___x_874_; lean_object* v___x_875_; 
lean_inc_ref(v_getM_868_);
lean_inc_ref(v_a_872_);
v___x_874_ = lean_apply_1(v_getM_868_, v_a_872_);
lean_inc(v_x_866_);
lean_inc_ref(v_inst_864_);
lean_inc_ref(v_inst_865_);
v___x_875_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v_inst_865_, v_inst_864_, v___x_874_, v_x_866_);
lean_dec_ref(v___x_874_);
if (lean_obj_tag(v___x_875_) == 1)
{
lean_object* v_val_876_; lean_object* v___x_878_; uint8_t v_isShared_879_; uint8_t v_isSharedCheck_884_; 
lean_dec_ref(v_rec_870_);
lean_dec_ref(v_setM_869_);
lean_dec_ref(v_getM_868_);
lean_dec_ref(v_namespaced_867_);
lean_dec(v_x_866_);
lean_dec_ref(v_inst_865_);
lean_dec_ref(v_inst_864_);
v_val_876_ = lean_ctor_get(v___x_875_, 0);
v_isSharedCheck_884_ = !lean_is_exclusive(v___x_875_);
if (v_isSharedCheck_884_ == 0)
{
v___x_878_ = v___x_875_;
v_isShared_879_ = v_isSharedCheck_884_;
goto v_resetjp_877_;
}
else
{
lean_inc(v_val_876_);
lean_dec(v___x_875_);
v___x_878_ = lean_box(0);
v_isShared_879_ = v_isSharedCheck_884_;
goto v_resetjp_877_;
}
v_resetjp_877_:
{
lean_object* v___x_880_; lean_object* v___x_882_; 
v___x_880_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_880_, 0, v_val_876_);
lean_ctor_set(v___x_880_, 1, v_a_872_);
if (v_isShared_879_ == 0)
{
lean_ctor_set_tag(v___x_878_, 0);
lean_ctor_set(v___x_878_, 0, v___x_880_);
v___x_882_ = v___x_878_;
goto v_reusejp_881_;
}
else
{
lean_object* v_reuseFailAlloc_883_; 
v_reuseFailAlloc_883_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_883_, 0, v___x_880_);
v___x_882_ = v_reuseFailAlloc_883_;
goto v_reusejp_881_;
}
v_reusejp_881_:
{
return v___x_882_;
}
}
}
else
{
lean_object* v___x_885_; 
lean_dec(v___x_875_);
lean_inc_ref(v_a_871_);
v___x_885_ = lean_apply_3(v_rec_870_, v_a_871_, v_a_872_, lean_box(0));
if (lean_obj_tag(v___x_885_) == 0)
{
lean_object* v_a_886_; lean_object* v_fst_887_; lean_object* v_snd_888_; lean_object* v___x_890_; uint8_t v_isShared_891_; uint8_t v_isSharedCheck_921_; 
v_a_886_ = lean_ctor_get(v___x_885_, 0);
lean_inc(v_a_886_);
lean_dec_ref_known(v___x_885_, 1);
v_fst_887_ = lean_ctor_get(v_a_886_, 0);
v_snd_888_ = lean_ctor_get(v_a_886_, 1);
v_isSharedCheck_921_ = !lean_is_exclusive(v_a_886_);
if (v_isSharedCheck_921_ == 0)
{
v___x_890_ = v_a_886_;
v_isShared_891_ = v_isSharedCheck_921_;
goto v_resetjp_889_;
}
else
{
lean_inc(v_snd_888_);
lean_inc(v_fst_887_);
lean_dec(v_a_886_);
v___x_890_ = lean_box(0);
v_isShared_891_ = v_isSharedCheck_921_;
goto v_resetjp_889_;
}
v_resetjp_889_:
{
lean_object* v___x_892_; lean_object* v_size_893_; lean_object* v___f_894_; lean_object* v___x_895_; lean_object* v___x_896_; lean_object* v___x_897_; lean_object* v___x_898_; lean_object* v___x_899_; 
lean_inc(v_snd_888_);
v___x_892_ = lean_apply_1(v_getM_868_, v_snd_888_);
v_size_893_ = lean_ctor_get(v___x_892_, 0);
lean_inc_n(v_size_893_, 2);
v___f_894_ = ((lean_object*)(lp_proofEnvironment_getIdx___redArg___closed__0));
v___x_895_ = l_Lean_JsonNumber_fromNat(v_size_893_);
v___x_896_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_896_, 0, v___x_895_);
v___x_897_ = l_Lean_Json_setObjVal_x21(v_fst_887_, v_namespaced_867_, v___x_896_);
v___x_898_ = l_Lean_Json_compress(v___x_897_);
v___x_899_ = l_IO_println___redArg(v___f_894_, v___x_898_);
if (lean_obj_tag(v___x_899_) == 0)
{
lean_object* v___x_901_; uint8_t v_isShared_902_; uint8_t v_isSharedCheck_911_; 
v_isSharedCheck_911_ = !lean_is_exclusive(v___x_899_);
if (v_isSharedCheck_911_ == 0)
{
lean_object* v_unused_912_; 
v_unused_912_ = lean_ctor_get(v___x_899_, 0);
lean_dec(v_unused_912_);
v___x_901_ = v___x_899_;
v_isShared_902_ = v_isSharedCheck_911_;
goto v_resetjp_900_;
}
else
{
lean_dec(v___x_899_);
v___x_901_ = lean_box(0);
v_isShared_902_ = v_isSharedCheck_911_;
goto v_resetjp_900_;
}
v_resetjp_900_:
{
lean_object* v___x_903_; lean_object* v___x_904_; lean_object* v___x_906_; 
lean_inc(v_size_893_);
v___x_903_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v_inst_865_, v_inst_864_, v___x_892_, v_x_866_, v_size_893_);
v___x_904_ = lean_apply_2(v_setM_869_, v_snd_888_, v___x_903_);
if (v_isShared_891_ == 0)
{
lean_ctor_set(v___x_890_, 1, v___x_904_);
lean_ctor_set(v___x_890_, 0, v_size_893_);
v___x_906_ = v___x_890_;
goto v_reusejp_905_;
}
else
{
lean_object* v_reuseFailAlloc_910_; 
v_reuseFailAlloc_910_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_910_, 0, v_size_893_);
lean_ctor_set(v_reuseFailAlloc_910_, 1, v___x_904_);
v___x_906_ = v_reuseFailAlloc_910_;
goto v_reusejp_905_;
}
v_reusejp_905_:
{
lean_object* v___x_908_; 
if (v_isShared_902_ == 0)
{
lean_ctor_set(v___x_901_, 0, v___x_906_);
v___x_908_ = v___x_901_;
goto v_reusejp_907_;
}
else
{
lean_object* v_reuseFailAlloc_909_; 
v_reuseFailAlloc_909_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_909_, 0, v___x_906_);
v___x_908_ = v_reuseFailAlloc_909_;
goto v_reusejp_907_;
}
v_reusejp_907_:
{
return v___x_908_;
}
}
}
}
else
{
lean_object* v_a_913_; lean_object* v___x_915_; uint8_t v_isShared_916_; uint8_t v_isSharedCheck_920_; 
lean_dec(v_size_893_);
lean_dec_ref(v___x_892_);
lean_del_object(v___x_890_);
lean_dec(v_snd_888_);
lean_dec_ref(v_setM_869_);
lean_dec(v_x_866_);
lean_dec_ref(v_inst_865_);
lean_dec_ref(v_inst_864_);
v_a_913_ = lean_ctor_get(v___x_899_, 0);
v_isSharedCheck_920_ = !lean_is_exclusive(v___x_899_);
if (v_isSharedCheck_920_ == 0)
{
v___x_915_ = v___x_899_;
v_isShared_916_ = v_isSharedCheck_920_;
goto v_resetjp_914_;
}
else
{
lean_inc(v_a_913_);
lean_dec(v___x_899_);
v___x_915_ = lean_box(0);
v_isShared_916_ = v_isSharedCheck_920_;
goto v_resetjp_914_;
}
v_resetjp_914_:
{
lean_object* v___x_918_; 
if (v_isShared_916_ == 0)
{
v___x_918_ = v___x_915_;
goto v_reusejp_917_;
}
else
{
lean_object* v_reuseFailAlloc_919_; 
v_reuseFailAlloc_919_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_919_, 0, v_a_913_);
v___x_918_ = v_reuseFailAlloc_919_;
goto v_reusejp_917_;
}
v_reusejp_917_:
{
return v___x_918_;
}
}
}
}
}
else
{
lean_object* v_a_922_; lean_object* v___x_924_; uint8_t v_isShared_925_; uint8_t v_isSharedCheck_929_; 
lean_dec_ref(v_setM_869_);
lean_dec_ref(v_getM_868_);
lean_dec_ref(v_namespaced_867_);
lean_dec(v_x_866_);
lean_dec_ref(v_inst_865_);
lean_dec_ref(v_inst_864_);
v_a_922_ = lean_ctor_get(v___x_885_, 0);
v_isSharedCheck_929_ = !lean_is_exclusive(v___x_885_);
if (v_isSharedCheck_929_ == 0)
{
v___x_924_ = v___x_885_;
v_isShared_925_ = v_isSharedCheck_929_;
goto v_resetjp_923_;
}
else
{
lean_inc(v_a_922_);
lean_dec(v___x_885_);
v___x_924_ = lean_box(0);
v_isShared_925_ = v_isSharedCheck_929_;
goto v_resetjp_923_;
}
v_resetjp_923_:
{
lean_object* v___x_927_; 
if (v_isShared_925_ == 0)
{
v___x_927_ = v___x_924_;
goto v_reusejp_926_;
}
else
{
lean_object* v_reuseFailAlloc_928_; 
v_reuseFailAlloc_928_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_928_, 0, v_a_922_);
v___x_927_ = v_reuseFailAlloc_928_;
goto v_reusejp_926_;
}
v_reusejp_926_:
{
return v___x_927_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx___redArg___boxed(lean_object* v_inst_930_, lean_object* v_inst_931_, lean_object* v_x_932_, lean_object* v_namespaced_933_, lean_object* v_getM_934_, lean_object* v_setM_935_, lean_object* v_rec_936_, lean_object* v_a_937_, lean_object* v_a_938_, lean_object* v_a_939_){
_start:
{
lean_object* v_res_940_; 
v_res_940_ = lp_proofEnvironment_getIdx___redArg(v_inst_930_, v_inst_931_, v_x_932_, v_namespaced_933_, v_getM_934_, v_setM_935_, v_rec_936_, v_a_937_, v_a_938_);
lean_dec_ref(v_a_937_);
return v_res_940_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx(lean_object* v_00_u03b1_941_, lean_object* v_inst_942_, lean_object* v_inst_943_, lean_object* v_x_944_, lean_object* v_namespaced_945_, lean_object* v_getM_946_, lean_object* v_setM_947_, lean_object* v_rec_948_, lean_object* v_a_949_, lean_object* v_a_950_){
_start:
{
lean_object* v___x_952_; lean_object* v___x_953_; 
lean_inc_ref(v_getM_946_);
lean_inc_ref(v_a_950_);
v___x_952_ = lean_apply_1(v_getM_946_, v_a_950_);
lean_inc(v_x_944_);
lean_inc_ref(v_inst_942_);
lean_inc_ref(v_inst_943_);
v___x_953_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___redArg(v_inst_943_, v_inst_942_, v___x_952_, v_x_944_);
lean_dec_ref(v___x_952_);
if (lean_obj_tag(v___x_953_) == 1)
{
lean_object* v_val_954_; lean_object* v___x_956_; uint8_t v_isShared_957_; uint8_t v_isSharedCheck_962_; 
lean_dec_ref(v_rec_948_);
lean_dec_ref(v_setM_947_);
lean_dec_ref(v_getM_946_);
lean_dec_ref(v_namespaced_945_);
lean_dec(v_x_944_);
lean_dec_ref(v_inst_943_);
lean_dec_ref(v_inst_942_);
v_val_954_ = lean_ctor_get(v___x_953_, 0);
v_isSharedCheck_962_ = !lean_is_exclusive(v___x_953_);
if (v_isSharedCheck_962_ == 0)
{
v___x_956_ = v___x_953_;
v_isShared_957_ = v_isSharedCheck_962_;
goto v_resetjp_955_;
}
else
{
lean_inc(v_val_954_);
lean_dec(v___x_953_);
v___x_956_ = lean_box(0);
v_isShared_957_ = v_isSharedCheck_962_;
goto v_resetjp_955_;
}
v_resetjp_955_:
{
lean_object* v___x_958_; lean_object* v___x_960_; 
v___x_958_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_958_, 0, v_val_954_);
lean_ctor_set(v___x_958_, 1, v_a_950_);
if (v_isShared_957_ == 0)
{
lean_ctor_set_tag(v___x_956_, 0);
lean_ctor_set(v___x_956_, 0, v___x_958_);
v___x_960_ = v___x_956_;
goto v_reusejp_959_;
}
else
{
lean_object* v_reuseFailAlloc_961_; 
v_reuseFailAlloc_961_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_961_, 0, v___x_958_);
v___x_960_ = v_reuseFailAlloc_961_;
goto v_reusejp_959_;
}
v_reusejp_959_:
{
return v___x_960_;
}
}
}
else
{
lean_object* v___x_963_; 
lean_dec(v___x_953_);
lean_inc_ref(v_a_949_);
v___x_963_ = lean_apply_3(v_rec_948_, v_a_949_, v_a_950_, lean_box(0));
if (lean_obj_tag(v___x_963_) == 0)
{
lean_object* v_a_964_; lean_object* v_fst_965_; lean_object* v_snd_966_; lean_object* v___x_968_; uint8_t v_isShared_969_; uint8_t v_isSharedCheck_999_; 
v_a_964_ = lean_ctor_get(v___x_963_, 0);
lean_inc(v_a_964_);
lean_dec_ref_known(v___x_963_, 1);
v_fst_965_ = lean_ctor_get(v_a_964_, 0);
v_snd_966_ = lean_ctor_get(v_a_964_, 1);
v_isSharedCheck_999_ = !lean_is_exclusive(v_a_964_);
if (v_isSharedCheck_999_ == 0)
{
v___x_968_ = v_a_964_;
v_isShared_969_ = v_isSharedCheck_999_;
goto v_resetjp_967_;
}
else
{
lean_inc(v_snd_966_);
lean_inc(v_fst_965_);
lean_dec(v_a_964_);
v___x_968_ = lean_box(0);
v_isShared_969_ = v_isSharedCheck_999_;
goto v_resetjp_967_;
}
v_resetjp_967_:
{
lean_object* v___x_970_; lean_object* v_size_971_; lean_object* v___f_972_; lean_object* v___x_973_; lean_object* v___x_974_; lean_object* v___x_975_; lean_object* v___x_976_; lean_object* v___x_977_; 
lean_inc(v_snd_966_);
v___x_970_ = lean_apply_1(v_getM_946_, v_snd_966_);
v_size_971_ = lean_ctor_get(v___x_970_, 0);
lean_inc_n(v_size_971_, 2);
v___f_972_ = ((lean_object*)(lp_proofEnvironment_getIdx___redArg___closed__0));
v___x_973_ = l_Lean_JsonNumber_fromNat(v_size_971_);
v___x_974_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_974_, 0, v___x_973_);
v___x_975_ = l_Lean_Json_setObjVal_x21(v_fst_965_, v_namespaced_945_, v___x_974_);
v___x_976_ = l_Lean_Json_compress(v___x_975_);
v___x_977_ = l_IO_println___redArg(v___f_972_, v___x_976_);
if (lean_obj_tag(v___x_977_) == 0)
{
lean_object* v___x_979_; uint8_t v_isShared_980_; uint8_t v_isSharedCheck_989_; 
v_isSharedCheck_989_ = !lean_is_exclusive(v___x_977_);
if (v_isSharedCheck_989_ == 0)
{
lean_object* v_unused_990_; 
v_unused_990_ = lean_ctor_get(v___x_977_, 0);
lean_dec(v_unused_990_);
v___x_979_ = v___x_977_;
v_isShared_980_ = v_isSharedCheck_989_;
goto v_resetjp_978_;
}
else
{
lean_dec(v___x_977_);
v___x_979_ = lean_box(0);
v_isShared_980_ = v_isSharedCheck_989_;
goto v_resetjp_978_;
}
v_resetjp_978_:
{
lean_object* v___x_981_; lean_object* v___x_982_; lean_object* v___x_984_; 
lean_inc(v_size_971_);
v___x_981_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v_inst_943_, v_inst_942_, v___x_970_, v_x_944_, v_size_971_);
v___x_982_ = lean_apply_2(v_setM_947_, v_snd_966_, v___x_981_);
if (v_isShared_969_ == 0)
{
lean_ctor_set(v___x_968_, 1, v___x_982_);
lean_ctor_set(v___x_968_, 0, v_size_971_);
v___x_984_ = v___x_968_;
goto v_reusejp_983_;
}
else
{
lean_object* v_reuseFailAlloc_988_; 
v_reuseFailAlloc_988_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_988_, 0, v_size_971_);
lean_ctor_set(v_reuseFailAlloc_988_, 1, v___x_982_);
v___x_984_ = v_reuseFailAlloc_988_;
goto v_reusejp_983_;
}
v_reusejp_983_:
{
lean_object* v___x_986_; 
if (v_isShared_980_ == 0)
{
lean_ctor_set(v___x_979_, 0, v___x_984_);
v___x_986_ = v___x_979_;
goto v_reusejp_985_;
}
else
{
lean_object* v_reuseFailAlloc_987_; 
v_reuseFailAlloc_987_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_987_, 0, v___x_984_);
v___x_986_ = v_reuseFailAlloc_987_;
goto v_reusejp_985_;
}
v_reusejp_985_:
{
return v___x_986_;
}
}
}
}
else
{
lean_object* v_a_991_; lean_object* v___x_993_; uint8_t v_isShared_994_; uint8_t v_isSharedCheck_998_; 
lean_dec(v_size_971_);
lean_dec_ref(v___x_970_);
lean_del_object(v___x_968_);
lean_dec(v_snd_966_);
lean_dec_ref(v_setM_947_);
lean_dec(v_x_944_);
lean_dec_ref(v_inst_943_);
lean_dec_ref(v_inst_942_);
v_a_991_ = lean_ctor_get(v___x_977_, 0);
v_isSharedCheck_998_ = !lean_is_exclusive(v___x_977_);
if (v_isSharedCheck_998_ == 0)
{
v___x_993_ = v___x_977_;
v_isShared_994_ = v_isSharedCheck_998_;
goto v_resetjp_992_;
}
else
{
lean_inc(v_a_991_);
lean_dec(v___x_977_);
v___x_993_ = lean_box(0);
v_isShared_994_ = v_isSharedCheck_998_;
goto v_resetjp_992_;
}
v_resetjp_992_:
{
lean_object* v___x_996_; 
if (v_isShared_994_ == 0)
{
v___x_996_ = v___x_993_;
goto v_reusejp_995_;
}
else
{
lean_object* v_reuseFailAlloc_997_; 
v_reuseFailAlloc_997_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_997_, 0, v_a_991_);
v___x_996_ = v_reuseFailAlloc_997_;
goto v_reusejp_995_;
}
v_reusejp_995_:
{
return v___x_996_;
}
}
}
}
}
else
{
lean_object* v_a_1000_; lean_object* v___x_1002_; uint8_t v_isShared_1003_; uint8_t v_isSharedCheck_1007_; 
lean_dec_ref(v_setM_947_);
lean_dec_ref(v_getM_946_);
lean_dec_ref(v_namespaced_945_);
lean_dec(v_x_944_);
lean_dec_ref(v_inst_943_);
lean_dec_ref(v_inst_942_);
v_a_1000_ = lean_ctor_get(v___x_963_, 0);
v_isSharedCheck_1007_ = !lean_is_exclusive(v___x_963_);
if (v_isSharedCheck_1007_ == 0)
{
v___x_1002_ = v___x_963_;
v_isShared_1003_ = v_isSharedCheck_1007_;
goto v_resetjp_1001_;
}
else
{
lean_inc(v_a_1000_);
lean_dec(v___x_963_);
v___x_1002_ = lean_box(0);
v_isShared_1003_ = v_isSharedCheck_1007_;
goto v_resetjp_1001_;
}
v_resetjp_1001_:
{
lean_object* v___x_1005_; 
if (v_isShared_1003_ == 0)
{
v___x_1005_ = v___x_1002_;
goto v_reusejp_1004_;
}
else
{
lean_object* v_reuseFailAlloc_1006_; 
v_reuseFailAlloc_1006_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1006_, 0, v_a_1000_);
v___x_1005_ = v_reuseFailAlloc_1006_;
goto v_reusejp_1004_;
}
v_reusejp_1004_:
{
return v___x_1005_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_getIdx___boxed(lean_object* v_00_u03b1_1008_, lean_object* v_inst_1009_, lean_object* v_inst_1010_, lean_object* v_x_1011_, lean_object* v_namespaced_1012_, lean_object* v_getM_1013_, lean_object* v_setM_1014_, lean_object* v_rec_1015_, lean_object* v_a_1016_, lean_object* v_a_1017_, lean_object* v_a_1018_){
_start:
{
lean_object* v_res_1019_; 
v_res_1019_ = lp_proofEnvironment_getIdx(v_00_u03b1_1008_, v_inst_1009_, v_inst_1010_, v_x_1011_, v_namespaced_1012_, v_getM_1013_, v_setM_1014_, v_rec_1015_, v_a_1016_, v_a_1017_);
lean_dec_ref(v_a_1016_);
return v_res_1019_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0(void){
_start:
{
lean_object* v___x_1020_; 
v___x_1020_ = l_instMonadEIO(lean_box(0));
return v___x_1020_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpName_spec__0(lean_object* v_msg_1021_, lean_object* v___y_1022_, lean_object* v___y_1023_){
_start:
{
lean_object* v___x_1025_; lean_object* v___f_1026_; lean_object* v___f_1027_; lean_object* v___f_1028_; lean_object* v___f_1029_; lean_object* v___x_1030_; lean_object* v___x_1031_; lean_object* v___x_1032_; lean_object* v___x_1033_; lean_object* v___x_1034_; lean_object* v___x_1035_; lean_object* v___x_1036_; lean_object* v___x_1037_; lean_object* v___f_1038_; lean_object* v___x_1359__overap_1039_; lean_object* v___x_1040_; 
v___x_1025_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0);
v___f_1026_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1026_, 0, v___x_1025_);
v___f_1027_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1027_, 0, v___x_1025_);
v___f_1028_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1028_, 0, v___x_1025_);
v___f_1029_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1029_, 0, v___x_1025_);
v___x_1030_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1030_, 0, lean_box(0));
lean_closure_set(v___x_1030_, 1, lean_box(0));
lean_closure_set(v___x_1030_, 2, v___x_1025_);
v___x_1031_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1031_, 0, v___x_1030_);
lean_ctor_set(v___x_1031_, 1, v___f_1026_);
v___x_1032_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1032_, 0, lean_box(0));
lean_closure_set(v___x_1032_, 1, lean_box(0));
lean_closure_set(v___x_1032_, 2, v___x_1025_);
v___x_1033_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1033_, 0, v___x_1031_);
lean_ctor_set(v___x_1033_, 1, v___x_1032_);
lean_ctor_set(v___x_1033_, 2, v___f_1027_);
lean_ctor_set(v___x_1033_, 3, v___f_1028_);
lean_ctor_set(v___x_1033_, 4, v___f_1029_);
v___x_1034_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1034_, 0, lean_box(0));
lean_closure_set(v___x_1034_, 1, lean_box(0));
lean_closure_set(v___x_1034_, 2, v___x_1025_);
v___x_1035_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1035_, 0, v___x_1033_);
lean_ctor_set(v___x_1035_, 1, v___x_1034_);
v___x_1036_ = lean_box(0);
v___x_1037_ = l_instInhabitedOfMonad___redArg(v___x_1035_, v___x_1036_);
v___f_1038_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1038_, 0, v___x_1037_);
v___x_1359__overap_1039_ = lean_panic_fn_borrowed(v___f_1038_, v_msg_1021_);
lean_dec_ref(v___f_1038_);
lean_inc_ref(v___y_1022_);
v___x_1040_ = lean_apply_3(v___x_1359__overap_1039_, v___y_1022_, v___y_1023_, lean_box(0));
return v___x_1040_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpName_spec__0___boxed(lean_object* v_msg_1041_, lean_object* v___y_1042_, lean_object* v___y_1043_, lean_object* v___y_1044_){
_start:
{
lean_object* v_res_1045_; 
v_res_1045_ = lp_proofEnvironment_panic___at___00dumpName_spec__0(v_msg_1041_, v___y_1042_, v___y_1043_);
lean_dec_ref(v___y_1042_);
return v_res_1045_;
}
}
static lean_object* _init_lp_proofEnvironment_dumpName___closed__4(void){
_start:
{
lean_object* v___x_1050_; lean_object* v___x_1051_; lean_object* v___x_1052_; lean_object* v___x_1053_; lean_object* v___x_1054_; lean_object* v___x_1055_; 
v___x_1050_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__3));
v___x_1051_ = lean_unsigned_to_nat(18u);
v___x_1052_ = lean_unsigned_to_nat(97u);
v___x_1053_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__2));
v___x_1054_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_1055_ = l_mkPanicMessageWithDecl(v___x_1054_, v___x_1053_, v___x_1052_, v___x_1051_, v___x_1050_);
return v___x_1055_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpName(lean_object* v_n_1060_, lean_object* v_a_1061_, lean_object* v_a_1062_){
_start:
{
lean_object* v_visitedNames_1064_; lean_object* v___x_1065_; 
v_visitedNames_1064_ = lean_ctor_get(v_a_1062_, 0);
v___x_1065_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(v_visitedNames_1064_, v_n_1060_);
if (lean_obj_tag(v___x_1065_) == 1)
{
lean_object* v_val_1066_; lean_object* v___x_1068_; uint8_t v_isShared_1069_; uint8_t v_isSharedCheck_1074_; 
lean_dec(v_n_1060_);
v_val_1066_ = lean_ctor_get(v___x_1065_, 0);
v_isSharedCheck_1074_ = !lean_is_exclusive(v___x_1065_);
if (v_isSharedCheck_1074_ == 0)
{
v___x_1068_ = v___x_1065_;
v_isShared_1069_ = v_isSharedCheck_1074_;
goto v_resetjp_1067_;
}
else
{
lean_inc(v_val_1066_);
lean_dec(v___x_1065_);
v___x_1068_ = lean_box(0);
v_isShared_1069_ = v_isSharedCheck_1074_;
goto v_resetjp_1067_;
}
v_resetjp_1067_:
{
lean_object* v___x_1070_; lean_object* v___x_1072_; 
v___x_1070_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1070_, 0, v_val_1066_);
lean_ctor_set(v___x_1070_, 1, v_a_1062_);
if (v_isShared_1069_ == 0)
{
lean_ctor_set_tag(v___x_1068_, 0);
lean_ctor_set(v___x_1068_, 0, v___x_1070_);
v___x_1072_ = v___x_1068_;
goto v_reusejp_1071_;
}
else
{
lean_object* v_reuseFailAlloc_1073_; 
v_reuseFailAlloc_1073_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1073_, 0, v___x_1070_);
v___x_1072_ = v_reuseFailAlloc_1073_;
goto v_reusejp_1071_;
}
v_reusejp_1071_:
{
return v___x_1072_;
}
}
}
else
{
lean_object* v___x_1075_; lean_object* v_fst_1077_; lean_object* v_snd_1078_; 
lean_dec(v___x_1065_);
v___x_1075_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__0));
switch(lean_obj_tag(v_n_1060_))
{
case 0:
{
lean_object* v___x_1119_; lean_object* v___x_1120_; 
v___x_1119_ = lean_obj_once(&lp_proofEnvironment_dumpName___closed__4, &lp_proofEnvironment_dumpName___closed__4_once, _init_lp_proofEnvironment_dumpName___closed__4);
v___x_1120_ = lp_proofEnvironment_panic___at___00dumpName_spec__0(v___x_1119_, v_a_1061_, v_a_1062_);
if (lean_obj_tag(v___x_1120_) == 0)
{
lean_object* v_a_1121_; lean_object* v_fst_1122_; lean_object* v_snd_1123_; 
v_a_1121_ = lean_ctor_get(v___x_1120_, 0);
lean_inc(v_a_1121_);
lean_dec_ref_known(v___x_1120_, 1);
v_fst_1122_ = lean_ctor_get(v_a_1121_, 0);
lean_inc(v_fst_1122_);
v_snd_1123_ = lean_ctor_get(v_a_1121_, 1);
lean_inc(v_snd_1123_);
lean_dec(v_a_1121_);
v_fst_1077_ = v_fst_1122_;
v_snd_1078_ = v_snd_1123_;
goto v___jp_1076_;
}
else
{
lean_object* v_a_1124_; lean_object* v___x_1126_; uint8_t v_isShared_1127_; uint8_t v_isSharedCheck_1131_; 
v_a_1124_ = lean_ctor_get(v___x_1120_, 0);
v_isSharedCheck_1131_ = !lean_is_exclusive(v___x_1120_);
if (v_isSharedCheck_1131_ == 0)
{
v___x_1126_ = v___x_1120_;
v_isShared_1127_ = v_isSharedCheck_1131_;
goto v_resetjp_1125_;
}
else
{
lean_inc(v_a_1124_);
lean_dec(v___x_1120_);
v___x_1126_ = lean_box(0);
v_isShared_1127_ = v_isSharedCheck_1131_;
goto v_resetjp_1125_;
}
v_resetjp_1125_:
{
lean_object* v___x_1129_; 
if (v_isShared_1127_ == 0)
{
v___x_1129_ = v___x_1126_;
goto v_reusejp_1128_;
}
else
{
lean_object* v_reuseFailAlloc_1130_; 
v_reuseFailAlloc_1130_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1130_, 0, v_a_1124_);
v___x_1129_ = v_reuseFailAlloc_1130_;
goto v_reusejp_1128_;
}
v_reusejp_1128_:
{
return v___x_1129_;
}
}
}
}
case 1:
{
lean_object* v_pre_1132_; lean_object* v_str_1133_; lean_object* v___x_1134_; 
v_pre_1132_ = lean_ctor_get(v_n_1060_, 0);
v_str_1133_ = lean_ctor_get(v_n_1060_, 1);
lean_inc(v_pre_1132_);
v___x_1134_ = lp_proofEnvironment_dumpName(v_pre_1132_, v_a_1061_, v_a_1062_);
if (lean_obj_tag(v___x_1134_) == 0)
{
lean_object* v_a_1135_; lean_object* v___x_1137_; uint8_t v_isShared_1138_; uint8_t v_isSharedCheck_1163_; 
v_a_1135_ = lean_ctor_get(v___x_1134_, 0);
v_isSharedCheck_1163_ = !lean_is_exclusive(v___x_1134_);
if (v_isSharedCheck_1163_ == 0)
{
v___x_1137_ = v___x_1134_;
v_isShared_1138_ = v_isSharedCheck_1163_;
goto v_resetjp_1136_;
}
else
{
lean_inc(v_a_1135_);
lean_dec(v___x_1134_);
v___x_1137_ = lean_box(0);
v_isShared_1138_ = v_isSharedCheck_1163_;
goto v_resetjp_1136_;
}
v_resetjp_1136_:
{
lean_object* v_fst_1139_; lean_object* v_snd_1140_; lean_object* v___x_1142_; uint8_t v_isShared_1143_; uint8_t v_isSharedCheck_1162_; 
v_fst_1139_ = lean_ctor_get(v_a_1135_, 0);
v_snd_1140_ = lean_ctor_get(v_a_1135_, 1);
v_isSharedCheck_1162_ = !lean_is_exclusive(v_a_1135_);
if (v_isSharedCheck_1162_ == 0)
{
v___x_1142_ = v_a_1135_;
v_isShared_1143_ = v_isSharedCheck_1162_;
goto v_resetjp_1141_;
}
else
{
lean_inc(v_snd_1140_);
lean_inc(v_fst_1139_);
lean_dec(v_a_1135_);
v___x_1142_ = lean_box(0);
v_isShared_1143_ = v_isSharedCheck_1162_;
goto v_resetjp_1141_;
}
v_resetjp_1141_:
{
lean_object* v___x_1144_; lean_object* v___x_1145_; lean_object* v___x_1146_; lean_object* v___x_1148_; 
v___x_1144_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__5));
v___x_1145_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__6));
v___x_1146_ = l_Lean_JsonNumber_fromNat(v_fst_1139_);
if (v_isShared_1138_ == 0)
{
lean_ctor_set_tag(v___x_1137_, 2);
lean_ctor_set(v___x_1137_, 0, v___x_1146_);
v___x_1148_ = v___x_1137_;
goto v_reusejp_1147_;
}
else
{
lean_object* v_reuseFailAlloc_1161_; 
v_reuseFailAlloc_1161_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1161_, 0, v___x_1146_);
v___x_1148_ = v_reuseFailAlloc_1161_;
goto v_reusejp_1147_;
}
v_reusejp_1147_:
{
lean_object* v___x_1150_; 
if (v_isShared_1143_ == 0)
{
lean_ctor_set(v___x_1142_, 1, v___x_1148_);
lean_ctor_set(v___x_1142_, 0, v___x_1145_);
v___x_1150_ = v___x_1142_;
goto v_reusejp_1149_;
}
else
{
lean_object* v_reuseFailAlloc_1160_; 
v_reuseFailAlloc_1160_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1160_, 0, v___x_1145_);
lean_ctor_set(v_reuseFailAlloc_1160_, 1, v___x_1148_);
v___x_1150_ = v_reuseFailAlloc_1160_;
goto v_reusejp_1149_;
}
v_reusejp_1149_:
{
lean_object* v___x_1151_; lean_object* v___x_1152_; lean_object* v___x_1153_; lean_object* v___x_1154_; lean_object* v___x_1155_; lean_object* v___x_1156_; lean_object* v___x_1157_; lean_object* v___x_1158_; lean_object* v___x_1159_; 
lean_inc_ref(v_str_1133_);
v___x_1151_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1151_, 0, v_str_1133_);
v___x_1152_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1152_, 0, v___x_1144_);
lean_ctor_set(v___x_1152_, 1, v___x_1151_);
v___x_1153_ = lean_box(0);
v___x_1154_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1154_, 0, v___x_1152_);
lean_ctor_set(v___x_1154_, 1, v___x_1153_);
v___x_1155_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1155_, 0, v___x_1150_);
lean_ctor_set(v___x_1155_, 1, v___x_1154_);
v___x_1156_ = l_Lean_Json_mkObj(v___x_1155_);
lean_dec_ref_known(v___x_1155_, 2);
v___x_1157_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1157_, 0, v___x_1144_);
lean_ctor_set(v___x_1157_, 1, v___x_1156_);
v___x_1158_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1158_, 0, v___x_1157_);
lean_ctor_set(v___x_1158_, 1, v___x_1153_);
v___x_1159_ = l_Lean_Json_mkObj(v___x_1158_);
lean_dec_ref_known(v___x_1158_, 2);
v_fst_1077_ = v___x_1159_;
v_snd_1078_ = v_snd_1140_;
goto v___jp_1076_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_n_1060_, 2);
return v___x_1134_;
}
}
default: 
{
lean_object* v_pre_1164_; lean_object* v_i_1165_; lean_object* v___x_1166_; 
v_pre_1164_ = lean_ctor_get(v_n_1060_, 0);
v_i_1165_ = lean_ctor_get(v_n_1060_, 1);
lean_inc(v_pre_1164_);
v___x_1166_ = lp_proofEnvironment_dumpName(v_pre_1164_, v_a_1061_, v_a_1062_);
if (lean_obj_tag(v___x_1166_) == 0)
{
lean_object* v_a_1167_; lean_object* v___x_1169_; uint8_t v_isShared_1170_; uint8_t v_isSharedCheck_1197_; 
v_a_1167_ = lean_ctor_get(v___x_1166_, 0);
v_isSharedCheck_1197_ = !lean_is_exclusive(v___x_1166_);
if (v_isSharedCheck_1197_ == 0)
{
v___x_1169_ = v___x_1166_;
v_isShared_1170_ = v_isSharedCheck_1197_;
goto v_resetjp_1168_;
}
else
{
lean_inc(v_a_1167_);
lean_dec(v___x_1166_);
v___x_1169_ = lean_box(0);
v_isShared_1170_ = v_isSharedCheck_1197_;
goto v_resetjp_1168_;
}
v_resetjp_1168_:
{
lean_object* v_fst_1171_; lean_object* v_snd_1172_; lean_object* v___x_1174_; uint8_t v_isShared_1175_; uint8_t v_isSharedCheck_1196_; 
v_fst_1171_ = lean_ctor_get(v_a_1167_, 0);
v_snd_1172_ = lean_ctor_get(v_a_1167_, 1);
v_isSharedCheck_1196_ = !lean_is_exclusive(v_a_1167_);
if (v_isSharedCheck_1196_ == 0)
{
v___x_1174_ = v_a_1167_;
v_isShared_1175_ = v_isSharedCheck_1196_;
goto v_resetjp_1173_;
}
else
{
lean_inc(v_snd_1172_);
lean_inc(v_fst_1171_);
lean_dec(v_a_1167_);
v___x_1174_ = lean_box(0);
v_isShared_1175_ = v_isSharedCheck_1196_;
goto v_resetjp_1173_;
}
v_resetjp_1173_:
{
lean_object* v___x_1176_; lean_object* v___x_1177_; lean_object* v___x_1178_; lean_object* v___x_1180_; 
v___x_1176_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__7));
v___x_1177_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__6));
v___x_1178_ = l_Lean_JsonNumber_fromNat(v_fst_1171_);
if (v_isShared_1170_ == 0)
{
lean_ctor_set_tag(v___x_1169_, 2);
lean_ctor_set(v___x_1169_, 0, v___x_1178_);
v___x_1180_ = v___x_1169_;
goto v_reusejp_1179_;
}
else
{
lean_object* v_reuseFailAlloc_1195_; 
v_reuseFailAlloc_1195_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1195_, 0, v___x_1178_);
v___x_1180_ = v_reuseFailAlloc_1195_;
goto v_reusejp_1179_;
}
v_reusejp_1179_:
{
lean_object* v___x_1182_; 
if (v_isShared_1175_ == 0)
{
lean_ctor_set(v___x_1174_, 1, v___x_1180_);
lean_ctor_set(v___x_1174_, 0, v___x_1177_);
v___x_1182_ = v___x_1174_;
goto v_reusejp_1181_;
}
else
{
lean_object* v_reuseFailAlloc_1194_; 
v_reuseFailAlloc_1194_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1194_, 0, v___x_1177_);
lean_ctor_set(v_reuseFailAlloc_1194_, 1, v___x_1180_);
v___x_1182_ = v_reuseFailAlloc_1194_;
goto v_reusejp_1181_;
}
v_reusejp_1181_:
{
lean_object* v___x_1183_; lean_object* v___x_1184_; lean_object* v___x_1185_; lean_object* v___x_1186_; lean_object* v___x_1187_; lean_object* v___x_1188_; lean_object* v___x_1189_; lean_object* v___x_1190_; lean_object* v___x_1191_; lean_object* v___x_1192_; lean_object* v___x_1193_; 
v___x_1183_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__8));
lean_inc(v_i_1165_);
v___x_1184_ = l_Lean_JsonNumber_fromNat(v_i_1165_);
v___x_1185_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1185_, 0, v___x_1184_);
v___x_1186_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1186_, 0, v___x_1183_);
lean_ctor_set(v___x_1186_, 1, v___x_1185_);
v___x_1187_ = lean_box(0);
v___x_1188_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1188_, 0, v___x_1186_);
lean_ctor_set(v___x_1188_, 1, v___x_1187_);
v___x_1189_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1189_, 0, v___x_1182_);
lean_ctor_set(v___x_1189_, 1, v___x_1188_);
v___x_1190_ = l_Lean_Json_mkObj(v___x_1189_);
lean_dec_ref_known(v___x_1189_, 2);
v___x_1191_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1191_, 0, v___x_1176_);
lean_ctor_set(v___x_1191_, 1, v___x_1190_);
v___x_1192_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1192_, 0, v___x_1191_);
lean_ctor_set(v___x_1192_, 1, v___x_1187_);
v___x_1193_ = l_Lean_Json_mkObj(v___x_1192_);
lean_dec_ref_known(v___x_1192_, 2);
v_fst_1077_ = v___x_1193_;
v_snd_1078_ = v_snd_1172_;
goto v___jp_1076_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_n_1060_, 2);
return v___x_1166_;
}
}
}
v___jp_1076_:
{
lean_object* v_visitedNames_1079_; lean_object* v_visitedLevels_1080_; lean_object* v_visitedExprs_1081_; lean_object* v_visitedConstants_1082_; lean_object* v_noMDataExprs_1083_; uint8_t v_exportMData_1084_; uint8_t v_exportUnsafe_1085_; uint8_t v_ignoreMissing_1086_; lean_object* v_recursorMap_1087_; lean_object* v___x_1089_; uint8_t v_isShared_1090_; uint8_t v_isSharedCheck_1118_; 
v_visitedNames_1079_ = lean_ctor_get(v_snd_1078_, 0);
v_visitedLevels_1080_ = lean_ctor_get(v_snd_1078_, 1);
v_visitedExprs_1081_ = lean_ctor_get(v_snd_1078_, 2);
v_visitedConstants_1082_ = lean_ctor_get(v_snd_1078_, 3);
v_noMDataExprs_1083_ = lean_ctor_get(v_snd_1078_, 4);
v_exportMData_1084_ = lean_ctor_get_uint8(v_snd_1078_, sizeof(void*)*6);
v_exportUnsafe_1085_ = lean_ctor_get_uint8(v_snd_1078_, sizeof(void*)*6 + 1);
v_ignoreMissing_1086_ = lean_ctor_get_uint8(v_snd_1078_, sizeof(void*)*6 + 2);
v_recursorMap_1087_ = lean_ctor_get(v_snd_1078_, 5);
v_isSharedCheck_1118_ = !lean_is_exclusive(v_snd_1078_);
if (v_isSharedCheck_1118_ == 0)
{
v___x_1089_ = v_snd_1078_;
v_isShared_1090_ = v_isSharedCheck_1118_;
goto v_resetjp_1088_;
}
else
{
lean_inc(v_recursorMap_1087_);
lean_inc(v_noMDataExprs_1083_);
lean_inc(v_visitedConstants_1082_);
lean_inc(v_visitedExprs_1081_);
lean_inc(v_visitedLevels_1080_);
lean_inc(v_visitedNames_1079_);
lean_dec(v_snd_1078_);
v___x_1089_ = lean_box(0);
v_isShared_1090_ = v_isSharedCheck_1118_;
goto v_resetjp_1088_;
}
v_resetjp_1088_:
{
lean_object* v_size_1091_; lean_object* v___x_1092_; lean_object* v___x_1093_; lean_object* v___x_1094_; lean_object* v___x_1095_; lean_object* v___x_1096_; 
v_size_1091_ = lean_ctor_get(v_visitedNames_1079_, 0);
lean_inc_n(v_size_1091_, 2);
v___x_1092_ = l_Lean_JsonNumber_fromNat(v_size_1091_);
v___x_1093_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1093_, 0, v___x_1092_);
v___x_1094_ = l_Lean_Json_setObjVal_x21(v_fst_1077_, v___x_1075_, v___x_1093_);
v___x_1095_ = l_Lean_Json_compress(v___x_1094_);
v___x_1096_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1095_);
if (lean_obj_tag(v___x_1096_) == 0)
{
lean_object* v___x_1098_; uint8_t v_isShared_1099_; uint8_t v_isSharedCheck_1108_; 
v_isSharedCheck_1108_ = !lean_is_exclusive(v___x_1096_);
if (v_isSharedCheck_1108_ == 0)
{
lean_object* v_unused_1109_; 
v_unused_1109_ = lean_ctor_get(v___x_1096_, 0);
lean_dec(v_unused_1109_);
v___x_1098_ = v___x_1096_;
v_isShared_1099_ = v_isSharedCheck_1108_;
goto v_resetjp_1097_;
}
else
{
lean_dec(v___x_1096_);
v___x_1098_ = lean_box(0);
v_isShared_1099_ = v_isSharedCheck_1108_;
goto v_resetjp_1097_;
}
v_resetjp_1097_:
{
lean_object* v___x_1100_; lean_object* v___x_1102_; 
lean_inc(v_size_1091_);
v___x_1100_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__1___redArg(v_visitedNames_1079_, v_n_1060_, v_size_1091_);
if (v_isShared_1090_ == 0)
{
lean_ctor_set(v___x_1089_, 0, v___x_1100_);
v___x_1102_ = v___x_1089_;
goto v_reusejp_1101_;
}
else
{
lean_object* v_reuseFailAlloc_1107_; 
v_reuseFailAlloc_1107_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_1107_, 0, v___x_1100_);
lean_ctor_set(v_reuseFailAlloc_1107_, 1, v_visitedLevels_1080_);
lean_ctor_set(v_reuseFailAlloc_1107_, 2, v_visitedExprs_1081_);
lean_ctor_set(v_reuseFailAlloc_1107_, 3, v_visitedConstants_1082_);
lean_ctor_set(v_reuseFailAlloc_1107_, 4, v_noMDataExprs_1083_);
lean_ctor_set(v_reuseFailAlloc_1107_, 5, v_recursorMap_1087_);
lean_ctor_set_uint8(v_reuseFailAlloc_1107_, sizeof(void*)*6, v_exportMData_1084_);
lean_ctor_set_uint8(v_reuseFailAlloc_1107_, sizeof(void*)*6 + 1, v_exportUnsafe_1085_);
lean_ctor_set_uint8(v_reuseFailAlloc_1107_, sizeof(void*)*6 + 2, v_ignoreMissing_1086_);
v___x_1102_ = v_reuseFailAlloc_1107_;
goto v_reusejp_1101_;
}
v_reusejp_1101_:
{
lean_object* v___x_1103_; lean_object* v___x_1105_; 
v___x_1103_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1103_, 0, v_size_1091_);
lean_ctor_set(v___x_1103_, 1, v___x_1102_);
if (v_isShared_1099_ == 0)
{
lean_ctor_set(v___x_1098_, 0, v___x_1103_);
v___x_1105_ = v___x_1098_;
goto v_reusejp_1104_;
}
else
{
lean_object* v_reuseFailAlloc_1106_; 
v_reuseFailAlloc_1106_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1106_, 0, v___x_1103_);
v___x_1105_ = v_reuseFailAlloc_1106_;
goto v_reusejp_1104_;
}
v_reusejp_1104_:
{
return v___x_1105_;
}
}
}
}
else
{
lean_object* v_a_1110_; lean_object* v___x_1112_; uint8_t v_isShared_1113_; uint8_t v_isSharedCheck_1117_; 
lean_dec(v_size_1091_);
lean_del_object(v___x_1089_);
lean_dec(v_recursorMap_1087_);
lean_dec_ref(v_noMDataExprs_1083_);
lean_dec_ref(v_visitedConstants_1082_);
lean_dec_ref(v_visitedExprs_1081_);
lean_dec_ref(v_visitedLevels_1080_);
lean_dec_ref(v_visitedNames_1079_);
lean_dec(v_n_1060_);
v_a_1110_ = lean_ctor_get(v___x_1096_, 0);
v_isSharedCheck_1117_ = !lean_is_exclusive(v___x_1096_);
if (v_isSharedCheck_1117_ == 0)
{
v___x_1112_ = v___x_1096_;
v_isShared_1113_ = v_isSharedCheck_1117_;
goto v_resetjp_1111_;
}
else
{
lean_inc(v_a_1110_);
lean_dec(v___x_1096_);
v___x_1112_ = lean_box(0);
v_isShared_1113_ = v_isSharedCheck_1117_;
goto v_resetjp_1111_;
}
v_resetjp_1111_:
{
lean_object* v___x_1115_; 
if (v_isShared_1113_ == 0)
{
v___x_1115_ = v___x_1112_;
goto v_reusejp_1114_;
}
else
{
lean_object* v_reuseFailAlloc_1116_; 
v_reuseFailAlloc_1116_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1116_, 0, v_a_1110_);
v___x_1115_ = v_reuseFailAlloc_1116_;
goto v_reusejp_1114_;
}
v_reusejp_1114_:
{
return v___x_1115_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpName___boxed(lean_object* v_n_1198_, lean_object* v_a_1199_, lean_object* v_a_1200_, lean_object* v_a_1201_){
_start:
{
lean_object* v_res_1202_; 
v_res_1202_ = lp_proofEnvironment_dumpName(v_n_1198_, v_a_1199_, v_a_1200_);
lean_dec_ref(v_a_1199_);
return v_res_1202_;
}
}
static lean_object* _init_lp_proofEnvironment_dumpLevel___closed__6(void){
_start:
{
lean_object* v___x_1209_; lean_object* v___x_1210_; lean_object* v___x_1211_; lean_object* v___x_1212_; lean_object* v___x_1213_; lean_object* v___x_1214_; 
v___x_1209_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__3));
v___x_1210_ = lean_unsigned_to_nat(23u);
v___x_1211_ = lean_unsigned_to_nat(115u);
v___x_1212_ = ((lean_object*)(lp_proofEnvironment_dumpLevel___closed__5));
v___x_1213_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_1214_ = l_mkPanicMessageWithDecl(v___x_1213_, v___x_1212_, v___x_1211_, v___x_1210_, v___x_1209_);
return v___x_1214_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpLevel(lean_object* v_l_1215_, lean_object* v_a_1216_, lean_object* v_a_1217_){
_start:
{
lean_object* v_visitedLevels_1219_; lean_object* v___x_1220_; 
v_visitedLevels_1219_ = lean_ctor_get(v_a_1217_, 1);
v___x_1220_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_simplifyResultingUniverse_simp_spec__2___redArg(v_visitedLevels_1219_, v_l_1215_);
if (lean_obj_tag(v___x_1220_) == 1)
{
lean_object* v_val_1221_; lean_object* v___x_1223_; uint8_t v_isShared_1224_; uint8_t v_isSharedCheck_1229_; 
lean_dec(v_l_1215_);
v_val_1221_ = lean_ctor_get(v___x_1220_, 0);
v_isSharedCheck_1229_ = !lean_is_exclusive(v___x_1220_);
if (v_isSharedCheck_1229_ == 0)
{
v___x_1223_ = v___x_1220_;
v_isShared_1224_ = v_isSharedCheck_1229_;
goto v_resetjp_1222_;
}
else
{
lean_inc(v_val_1221_);
lean_dec(v___x_1220_);
v___x_1223_ = lean_box(0);
v_isShared_1224_ = v_isSharedCheck_1229_;
goto v_resetjp_1222_;
}
v_resetjp_1222_:
{
lean_object* v___x_1225_; lean_object* v___x_1227_; 
v___x_1225_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1225_, 0, v_val_1221_);
lean_ctor_set(v___x_1225_, 1, v_a_1217_);
if (v_isShared_1224_ == 0)
{
lean_ctor_set_tag(v___x_1223_, 0);
lean_ctor_set(v___x_1223_, 0, v___x_1225_);
v___x_1227_ = v___x_1223_;
goto v_reusejp_1226_;
}
else
{
lean_object* v_reuseFailAlloc_1228_; 
v_reuseFailAlloc_1228_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1228_, 0, v___x_1225_);
v___x_1227_ = v_reuseFailAlloc_1228_;
goto v_reusejp_1226_;
}
v_reusejp_1226_:
{
return v___x_1227_;
}
}
}
else
{
lean_object* v___x_1230_; lean_object* v_fst_1232_; lean_object* v_snd_1233_; 
lean_dec(v___x_1220_);
v___x_1230_ = ((lean_object*)(lp_proofEnvironment_dumpLevel___closed__0));
switch(lean_obj_tag(v_l_1215_))
{
case 1:
{
lean_object* v_a_1274_; lean_object* v___x_1275_; 
v_a_1274_ = lean_ctor_get(v_l_1215_, 0);
lean_inc(v_a_1274_);
v___x_1275_ = lp_proofEnvironment_dumpLevel(v_a_1274_, v_a_1216_, v_a_1217_);
if (lean_obj_tag(v___x_1275_) == 0)
{
lean_object* v_a_1276_; lean_object* v___x_1278_; uint8_t v_isShared_1279_; uint8_t v_isSharedCheck_1297_; 
v_a_1276_ = lean_ctor_get(v___x_1275_, 0);
v_isSharedCheck_1297_ = !lean_is_exclusive(v___x_1275_);
if (v_isSharedCheck_1297_ == 0)
{
v___x_1278_ = v___x_1275_;
v_isShared_1279_ = v_isSharedCheck_1297_;
goto v_resetjp_1277_;
}
else
{
lean_inc(v_a_1276_);
lean_dec(v___x_1275_);
v___x_1278_ = lean_box(0);
v_isShared_1279_ = v_isSharedCheck_1297_;
goto v_resetjp_1277_;
}
v_resetjp_1277_:
{
lean_object* v_fst_1280_; lean_object* v_snd_1281_; lean_object* v___x_1283_; uint8_t v_isShared_1284_; uint8_t v_isSharedCheck_1296_; 
v_fst_1280_ = lean_ctor_get(v_a_1276_, 0);
v_snd_1281_ = lean_ctor_get(v_a_1276_, 1);
v_isSharedCheck_1296_ = !lean_is_exclusive(v_a_1276_);
if (v_isSharedCheck_1296_ == 0)
{
v___x_1283_ = v_a_1276_;
v_isShared_1284_ = v_isSharedCheck_1296_;
goto v_resetjp_1282_;
}
else
{
lean_inc(v_snd_1281_);
lean_inc(v_fst_1280_);
lean_dec(v_a_1276_);
v___x_1283_ = lean_box(0);
v_isShared_1284_ = v_isSharedCheck_1296_;
goto v_resetjp_1282_;
}
v_resetjp_1282_:
{
lean_object* v___x_1285_; lean_object* v___x_1286_; lean_object* v___x_1288_; 
v___x_1285_ = ((lean_object*)(lp_proofEnvironment_dumpLevel___closed__1));
v___x_1286_ = l_Lean_JsonNumber_fromNat(v_fst_1280_);
if (v_isShared_1279_ == 0)
{
lean_ctor_set_tag(v___x_1278_, 2);
lean_ctor_set(v___x_1278_, 0, v___x_1286_);
v___x_1288_ = v___x_1278_;
goto v_reusejp_1287_;
}
else
{
lean_object* v_reuseFailAlloc_1295_; 
v_reuseFailAlloc_1295_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1295_, 0, v___x_1286_);
v___x_1288_ = v_reuseFailAlloc_1295_;
goto v_reusejp_1287_;
}
v_reusejp_1287_:
{
lean_object* v___x_1290_; 
if (v_isShared_1284_ == 0)
{
lean_ctor_set(v___x_1283_, 1, v___x_1288_);
lean_ctor_set(v___x_1283_, 0, v___x_1285_);
v___x_1290_ = v___x_1283_;
goto v_reusejp_1289_;
}
else
{
lean_object* v_reuseFailAlloc_1294_; 
v_reuseFailAlloc_1294_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1294_, 0, v___x_1285_);
lean_ctor_set(v_reuseFailAlloc_1294_, 1, v___x_1288_);
v___x_1290_ = v_reuseFailAlloc_1294_;
goto v_reusejp_1289_;
}
v_reusejp_1289_:
{
lean_object* v___x_1291_; lean_object* v___x_1292_; lean_object* v___x_1293_; 
v___x_1291_ = lean_box(0);
v___x_1292_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1292_, 0, v___x_1290_);
lean_ctor_set(v___x_1292_, 1, v___x_1291_);
v___x_1293_ = l_Lean_Json_mkObj(v___x_1292_);
lean_dec_ref_known(v___x_1292_, 2);
v_fst_1232_ = v___x_1293_;
v_snd_1233_ = v_snd_1281_;
goto v___jp_1231_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_l_1215_, 1);
return v___x_1275_;
}
}
case 2:
{
lean_object* v_a_1298_; lean_object* v_a_1299_; lean_object* v___x_1300_; 
v_a_1298_ = lean_ctor_get(v_l_1215_, 0);
v_a_1299_ = lean_ctor_get(v_l_1215_, 1);
lean_inc(v_a_1298_);
v___x_1300_ = lp_proofEnvironment_dumpLevel(v_a_1298_, v_a_1216_, v_a_1217_);
if (lean_obj_tag(v___x_1300_) == 0)
{
lean_object* v_a_1301_; lean_object* v___x_1303_; uint8_t v_isShared_1304_; uint8_t v_isSharedCheck_1345_; 
v_a_1301_ = lean_ctor_get(v___x_1300_, 0);
v_isSharedCheck_1345_ = !lean_is_exclusive(v___x_1300_);
if (v_isSharedCheck_1345_ == 0)
{
v___x_1303_ = v___x_1300_;
v_isShared_1304_ = v_isSharedCheck_1345_;
goto v_resetjp_1302_;
}
else
{
lean_inc(v_a_1301_);
lean_dec(v___x_1300_);
v___x_1303_ = lean_box(0);
v_isShared_1304_ = v_isSharedCheck_1345_;
goto v_resetjp_1302_;
}
v_resetjp_1302_:
{
lean_object* v_fst_1305_; lean_object* v_snd_1306_; lean_object* v___x_1308_; uint8_t v_isShared_1309_; uint8_t v_isSharedCheck_1344_; 
v_fst_1305_ = lean_ctor_get(v_a_1301_, 0);
v_snd_1306_ = lean_ctor_get(v_a_1301_, 1);
v_isSharedCheck_1344_ = !lean_is_exclusive(v_a_1301_);
if (v_isSharedCheck_1344_ == 0)
{
v___x_1308_ = v_a_1301_;
v_isShared_1309_ = v_isSharedCheck_1344_;
goto v_resetjp_1307_;
}
else
{
lean_inc(v_snd_1306_);
lean_inc(v_fst_1305_);
lean_dec(v_a_1301_);
v___x_1308_ = lean_box(0);
v_isShared_1309_ = v_isSharedCheck_1344_;
goto v_resetjp_1307_;
}
v_resetjp_1307_:
{
lean_object* v___x_1310_; 
lean_inc(v_a_1299_);
v___x_1310_ = lp_proofEnvironment_dumpLevel(v_a_1299_, v_a_1216_, v_snd_1306_);
if (lean_obj_tag(v___x_1310_) == 0)
{
lean_object* v_a_1311_; lean_object* v___x_1313_; uint8_t v_isShared_1314_; uint8_t v_isSharedCheck_1343_; 
v_a_1311_ = lean_ctor_get(v___x_1310_, 0);
v_isSharedCheck_1343_ = !lean_is_exclusive(v___x_1310_);
if (v_isSharedCheck_1343_ == 0)
{
v___x_1313_ = v___x_1310_;
v_isShared_1314_ = v_isSharedCheck_1343_;
goto v_resetjp_1312_;
}
else
{
lean_inc(v_a_1311_);
lean_dec(v___x_1310_);
v___x_1313_ = lean_box(0);
v_isShared_1314_ = v_isSharedCheck_1343_;
goto v_resetjp_1312_;
}
v_resetjp_1312_:
{
lean_object* v_fst_1315_; lean_object* v_snd_1316_; lean_object* v___x_1318_; uint8_t v_isShared_1319_; uint8_t v_isSharedCheck_1342_; 
v_fst_1315_ = lean_ctor_get(v_a_1311_, 0);
v_snd_1316_ = lean_ctor_get(v_a_1311_, 1);
v_isSharedCheck_1342_ = !lean_is_exclusive(v_a_1311_);
if (v_isSharedCheck_1342_ == 0)
{
v___x_1318_ = v_a_1311_;
v_isShared_1319_ = v_isSharedCheck_1342_;
goto v_resetjp_1317_;
}
else
{
lean_inc(v_snd_1316_);
lean_inc(v_fst_1315_);
lean_dec(v_a_1311_);
v___x_1318_ = lean_box(0);
v_isShared_1319_ = v_isSharedCheck_1342_;
goto v_resetjp_1317_;
}
v_resetjp_1317_:
{
lean_object* v___x_1320_; lean_object* v___x_1321_; lean_object* v___x_1323_; 
v___x_1320_ = ((lean_object*)(lp_proofEnvironment_dumpLevel___closed__2));
v___x_1321_ = l_Lean_JsonNumber_fromNat(v_fst_1305_);
if (v_isShared_1314_ == 0)
{
lean_ctor_set_tag(v___x_1313_, 2);
lean_ctor_set(v___x_1313_, 0, v___x_1321_);
v___x_1323_ = v___x_1313_;
goto v_reusejp_1322_;
}
else
{
lean_object* v_reuseFailAlloc_1341_; 
v_reuseFailAlloc_1341_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1341_, 0, v___x_1321_);
v___x_1323_ = v_reuseFailAlloc_1341_;
goto v_reusejp_1322_;
}
v_reusejp_1322_:
{
lean_object* v___x_1324_; lean_object* v___x_1326_; 
v___x_1324_ = l_Lean_JsonNumber_fromNat(v_fst_1315_);
if (v_isShared_1304_ == 0)
{
lean_ctor_set_tag(v___x_1303_, 2);
lean_ctor_set(v___x_1303_, 0, v___x_1324_);
v___x_1326_ = v___x_1303_;
goto v_reusejp_1325_;
}
else
{
lean_object* v_reuseFailAlloc_1340_; 
v_reuseFailAlloc_1340_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1340_, 0, v___x_1324_);
v___x_1326_ = v_reuseFailAlloc_1340_;
goto v_reusejp_1325_;
}
v_reusejp_1325_:
{
lean_object* v___x_1327_; lean_object* v___x_1328_; lean_object* v___x_1329_; lean_object* v___x_1330_; lean_object* v___x_1331_; lean_object* v___x_1333_; 
v___x_1327_ = lean_unsigned_to_nat(2u);
v___x_1328_ = lean_mk_empty_array_with_capacity(v___x_1327_);
v___x_1329_ = lean_array_push(v___x_1328_, v___x_1323_);
v___x_1330_ = lean_array_push(v___x_1329_, v___x_1326_);
v___x_1331_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_1331_, 0, v___x_1330_);
if (v_isShared_1319_ == 0)
{
lean_ctor_set(v___x_1318_, 1, v___x_1331_);
lean_ctor_set(v___x_1318_, 0, v___x_1320_);
v___x_1333_ = v___x_1318_;
goto v_reusejp_1332_;
}
else
{
lean_object* v_reuseFailAlloc_1339_; 
v_reuseFailAlloc_1339_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1339_, 0, v___x_1320_);
lean_ctor_set(v_reuseFailAlloc_1339_, 1, v___x_1331_);
v___x_1333_ = v_reuseFailAlloc_1339_;
goto v_reusejp_1332_;
}
v_reusejp_1332_:
{
lean_object* v___x_1334_; lean_object* v___x_1336_; 
v___x_1334_ = lean_box(0);
if (v_isShared_1309_ == 0)
{
lean_ctor_set_tag(v___x_1308_, 1);
lean_ctor_set(v___x_1308_, 1, v___x_1334_);
lean_ctor_set(v___x_1308_, 0, v___x_1333_);
v___x_1336_ = v___x_1308_;
goto v_reusejp_1335_;
}
else
{
lean_object* v_reuseFailAlloc_1338_; 
v_reuseFailAlloc_1338_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1338_, 0, v___x_1333_);
lean_ctor_set(v_reuseFailAlloc_1338_, 1, v___x_1334_);
v___x_1336_ = v_reuseFailAlloc_1338_;
goto v_reusejp_1335_;
}
v_reusejp_1335_:
{
lean_object* v___x_1337_; 
v___x_1337_ = l_Lean_Json_mkObj(v___x_1336_);
lean_dec_ref(v___x_1336_);
v_fst_1232_ = v___x_1337_;
v_snd_1233_ = v_snd_1316_;
goto v___jp_1231_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_1308_);
lean_dec(v_fst_1305_);
lean_del_object(v___x_1303_);
lean_dec_ref_known(v_l_1215_, 2);
return v___x_1310_;
}
}
}
}
else
{
lean_dec_ref_known(v_l_1215_, 2);
return v___x_1300_;
}
}
case 3:
{
lean_object* v_a_1346_; lean_object* v_a_1347_; lean_object* v___x_1348_; 
v_a_1346_ = lean_ctor_get(v_l_1215_, 0);
v_a_1347_ = lean_ctor_get(v_l_1215_, 1);
lean_inc(v_a_1346_);
v___x_1348_ = lp_proofEnvironment_dumpLevel(v_a_1346_, v_a_1216_, v_a_1217_);
if (lean_obj_tag(v___x_1348_) == 0)
{
lean_object* v_a_1349_; lean_object* v___x_1351_; uint8_t v_isShared_1352_; uint8_t v_isSharedCheck_1393_; 
v_a_1349_ = lean_ctor_get(v___x_1348_, 0);
v_isSharedCheck_1393_ = !lean_is_exclusive(v___x_1348_);
if (v_isSharedCheck_1393_ == 0)
{
v___x_1351_ = v___x_1348_;
v_isShared_1352_ = v_isSharedCheck_1393_;
goto v_resetjp_1350_;
}
else
{
lean_inc(v_a_1349_);
lean_dec(v___x_1348_);
v___x_1351_ = lean_box(0);
v_isShared_1352_ = v_isSharedCheck_1393_;
goto v_resetjp_1350_;
}
v_resetjp_1350_:
{
lean_object* v_fst_1353_; lean_object* v_snd_1354_; lean_object* v___x_1356_; uint8_t v_isShared_1357_; uint8_t v_isSharedCheck_1392_; 
v_fst_1353_ = lean_ctor_get(v_a_1349_, 0);
v_snd_1354_ = lean_ctor_get(v_a_1349_, 1);
v_isSharedCheck_1392_ = !lean_is_exclusive(v_a_1349_);
if (v_isSharedCheck_1392_ == 0)
{
v___x_1356_ = v_a_1349_;
v_isShared_1357_ = v_isSharedCheck_1392_;
goto v_resetjp_1355_;
}
else
{
lean_inc(v_snd_1354_);
lean_inc(v_fst_1353_);
lean_dec(v_a_1349_);
v___x_1356_ = lean_box(0);
v_isShared_1357_ = v_isSharedCheck_1392_;
goto v_resetjp_1355_;
}
v_resetjp_1355_:
{
lean_object* v___x_1358_; 
lean_inc(v_a_1347_);
v___x_1358_ = lp_proofEnvironment_dumpLevel(v_a_1347_, v_a_1216_, v_snd_1354_);
if (lean_obj_tag(v___x_1358_) == 0)
{
lean_object* v_a_1359_; lean_object* v___x_1361_; uint8_t v_isShared_1362_; uint8_t v_isSharedCheck_1391_; 
v_a_1359_ = lean_ctor_get(v___x_1358_, 0);
v_isSharedCheck_1391_ = !lean_is_exclusive(v___x_1358_);
if (v_isSharedCheck_1391_ == 0)
{
v___x_1361_ = v___x_1358_;
v_isShared_1362_ = v_isSharedCheck_1391_;
goto v_resetjp_1360_;
}
else
{
lean_inc(v_a_1359_);
lean_dec(v___x_1358_);
v___x_1361_ = lean_box(0);
v_isShared_1362_ = v_isSharedCheck_1391_;
goto v_resetjp_1360_;
}
v_resetjp_1360_:
{
lean_object* v_fst_1363_; lean_object* v_snd_1364_; lean_object* v___x_1366_; uint8_t v_isShared_1367_; uint8_t v_isSharedCheck_1390_; 
v_fst_1363_ = lean_ctor_get(v_a_1359_, 0);
v_snd_1364_ = lean_ctor_get(v_a_1359_, 1);
v_isSharedCheck_1390_ = !lean_is_exclusive(v_a_1359_);
if (v_isSharedCheck_1390_ == 0)
{
v___x_1366_ = v_a_1359_;
v_isShared_1367_ = v_isSharedCheck_1390_;
goto v_resetjp_1365_;
}
else
{
lean_inc(v_snd_1364_);
lean_inc(v_fst_1363_);
lean_dec(v_a_1359_);
v___x_1366_ = lean_box(0);
v_isShared_1367_ = v_isSharedCheck_1390_;
goto v_resetjp_1365_;
}
v_resetjp_1365_:
{
lean_object* v___x_1368_; lean_object* v___x_1369_; lean_object* v___x_1371_; 
v___x_1368_ = ((lean_object*)(lp_proofEnvironment_dumpLevel___closed__3));
v___x_1369_ = l_Lean_JsonNumber_fromNat(v_fst_1353_);
if (v_isShared_1362_ == 0)
{
lean_ctor_set_tag(v___x_1361_, 2);
lean_ctor_set(v___x_1361_, 0, v___x_1369_);
v___x_1371_ = v___x_1361_;
goto v_reusejp_1370_;
}
else
{
lean_object* v_reuseFailAlloc_1389_; 
v_reuseFailAlloc_1389_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1389_, 0, v___x_1369_);
v___x_1371_ = v_reuseFailAlloc_1389_;
goto v_reusejp_1370_;
}
v_reusejp_1370_:
{
lean_object* v___x_1372_; lean_object* v___x_1374_; 
v___x_1372_ = l_Lean_JsonNumber_fromNat(v_fst_1363_);
if (v_isShared_1352_ == 0)
{
lean_ctor_set_tag(v___x_1351_, 2);
lean_ctor_set(v___x_1351_, 0, v___x_1372_);
v___x_1374_ = v___x_1351_;
goto v_reusejp_1373_;
}
else
{
lean_object* v_reuseFailAlloc_1388_; 
v_reuseFailAlloc_1388_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1388_, 0, v___x_1372_);
v___x_1374_ = v_reuseFailAlloc_1388_;
goto v_reusejp_1373_;
}
v_reusejp_1373_:
{
lean_object* v___x_1375_; lean_object* v___x_1376_; lean_object* v___x_1377_; lean_object* v___x_1378_; lean_object* v___x_1379_; lean_object* v___x_1381_; 
v___x_1375_ = lean_unsigned_to_nat(2u);
v___x_1376_ = lean_mk_empty_array_with_capacity(v___x_1375_);
v___x_1377_ = lean_array_push(v___x_1376_, v___x_1371_);
v___x_1378_ = lean_array_push(v___x_1377_, v___x_1374_);
v___x_1379_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_1379_, 0, v___x_1378_);
if (v_isShared_1367_ == 0)
{
lean_ctor_set(v___x_1366_, 1, v___x_1379_);
lean_ctor_set(v___x_1366_, 0, v___x_1368_);
v___x_1381_ = v___x_1366_;
goto v_reusejp_1380_;
}
else
{
lean_object* v_reuseFailAlloc_1387_; 
v_reuseFailAlloc_1387_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1387_, 0, v___x_1368_);
lean_ctor_set(v_reuseFailAlloc_1387_, 1, v___x_1379_);
v___x_1381_ = v_reuseFailAlloc_1387_;
goto v_reusejp_1380_;
}
v_reusejp_1380_:
{
lean_object* v___x_1382_; lean_object* v___x_1384_; 
v___x_1382_ = lean_box(0);
if (v_isShared_1357_ == 0)
{
lean_ctor_set_tag(v___x_1356_, 1);
lean_ctor_set(v___x_1356_, 1, v___x_1382_);
lean_ctor_set(v___x_1356_, 0, v___x_1381_);
v___x_1384_ = v___x_1356_;
goto v_reusejp_1383_;
}
else
{
lean_object* v_reuseFailAlloc_1386_; 
v_reuseFailAlloc_1386_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1386_, 0, v___x_1381_);
lean_ctor_set(v_reuseFailAlloc_1386_, 1, v___x_1382_);
v___x_1384_ = v_reuseFailAlloc_1386_;
goto v_reusejp_1383_;
}
v_reusejp_1383_:
{
lean_object* v___x_1385_; 
v___x_1385_ = l_Lean_Json_mkObj(v___x_1384_);
lean_dec_ref(v___x_1384_);
v_fst_1232_ = v___x_1385_;
v_snd_1233_ = v_snd_1364_;
goto v___jp_1231_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_1356_);
lean_dec(v_fst_1353_);
lean_del_object(v___x_1351_);
lean_dec_ref_known(v_l_1215_, 2);
return v___x_1358_;
}
}
}
}
else
{
lean_dec_ref_known(v_l_1215_, 2);
return v___x_1348_;
}
}
case 4:
{
lean_object* v_a_1394_; lean_object* v___x_1395_; 
v_a_1394_ = lean_ctor_get(v_l_1215_, 0);
lean_inc(v_a_1394_);
v___x_1395_ = lp_proofEnvironment_dumpName(v_a_1394_, v_a_1216_, v_a_1217_);
if (lean_obj_tag(v___x_1395_) == 0)
{
lean_object* v_a_1396_; lean_object* v___x_1398_; uint8_t v_isShared_1399_; uint8_t v_isSharedCheck_1417_; 
v_a_1396_ = lean_ctor_get(v___x_1395_, 0);
v_isSharedCheck_1417_ = !lean_is_exclusive(v___x_1395_);
if (v_isSharedCheck_1417_ == 0)
{
v___x_1398_ = v___x_1395_;
v_isShared_1399_ = v_isSharedCheck_1417_;
goto v_resetjp_1397_;
}
else
{
lean_inc(v_a_1396_);
lean_dec(v___x_1395_);
v___x_1398_ = lean_box(0);
v_isShared_1399_ = v_isSharedCheck_1417_;
goto v_resetjp_1397_;
}
v_resetjp_1397_:
{
lean_object* v_fst_1400_; lean_object* v_snd_1401_; lean_object* v___x_1403_; uint8_t v_isShared_1404_; uint8_t v_isSharedCheck_1416_; 
v_fst_1400_ = lean_ctor_get(v_a_1396_, 0);
v_snd_1401_ = lean_ctor_get(v_a_1396_, 1);
v_isSharedCheck_1416_ = !lean_is_exclusive(v_a_1396_);
if (v_isSharedCheck_1416_ == 0)
{
v___x_1403_ = v_a_1396_;
v_isShared_1404_ = v_isSharedCheck_1416_;
goto v_resetjp_1402_;
}
else
{
lean_inc(v_snd_1401_);
lean_inc(v_fst_1400_);
lean_dec(v_a_1396_);
v___x_1403_ = lean_box(0);
v_isShared_1404_ = v_isSharedCheck_1416_;
goto v_resetjp_1402_;
}
v_resetjp_1402_:
{
lean_object* v___x_1405_; lean_object* v___x_1406_; lean_object* v___x_1408_; 
v___x_1405_ = ((lean_object*)(lp_proofEnvironment_dumpLevel___closed__4));
v___x_1406_ = l_Lean_JsonNumber_fromNat(v_fst_1400_);
if (v_isShared_1399_ == 0)
{
lean_ctor_set_tag(v___x_1398_, 2);
lean_ctor_set(v___x_1398_, 0, v___x_1406_);
v___x_1408_ = v___x_1398_;
goto v_reusejp_1407_;
}
else
{
lean_object* v_reuseFailAlloc_1415_; 
v_reuseFailAlloc_1415_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1415_, 0, v___x_1406_);
v___x_1408_ = v_reuseFailAlloc_1415_;
goto v_reusejp_1407_;
}
v_reusejp_1407_:
{
lean_object* v___x_1410_; 
if (v_isShared_1404_ == 0)
{
lean_ctor_set(v___x_1403_, 1, v___x_1408_);
lean_ctor_set(v___x_1403_, 0, v___x_1405_);
v___x_1410_ = v___x_1403_;
goto v_reusejp_1409_;
}
else
{
lean_object* v_reuseFailAlloc_1414_; 
v_reuseFailAlloc_1414_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1414_, 0, v___x_1405_);
lean_ctor_set(v_reuseFailAlloc_1414_, 1, v___x_1408_);
v___x_1410_ = v_reuseFailAlloc_1414_;
goto v_reusejp_1409_;
}
v_reusejp_1409_:
{
lean_object* v___x_1411_; lean_object* v___x_1412_; lean_object* v___x_1413_; 
v___x_1411_ = lean_box(0);
v___x_1412_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1412_, 0, v___x_1410_);
lean_ctor_set(v___x_1412_, 1, v___x_1411_);
v___x_1413_ = l_Lean_Json_mkObj(v___x_1412_);
lean_dec_ref_known(v___x_1412_, 2);
v_fst_1232_ = v___x_1413_;
v_snd_1233_ = v_snd_1401_;
goto v___jp_1231_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_l_1215_, 1);
return v___x_1395_;
}
}
default: 
{
lean_object* v___x_1418_; lean_object* v___x_1419_; 
v___x_1418_ = lean_obj_once(&lp_proofEnvironment_dumpLevel___closed__6, &lp_proofEnvironment_dumpLevel___closed__6_once, _init_lp_proofEnvironment_dumpLevel___closed__6);
v___x_1419_ = lp_proofEnvironment_panic___at___00dumpName_spec__0(v___x_1418_, v_a_1216_, v_a_1217_);
if (lean_obj_tag(v___x_1419_) == 0)
{
lean_object* v_a_1420_; lean_object* v_fst_1421_; lean_object* v_snd_1422_; 
v_a_1420_ = lean_ctor_get(v___x_1419_, 0);
lean_inc(v_a_1420_);
lean_dec_ref_known(v___x_1419_, 1);
v_fst_1421_ = lean_ctor_get(v_a_1420_, 0);
lean_inc(v_fst_1421_);
v_snd_1422_ = lean_ctor_get(v_a_1420_, 1);
lean_inc(v_snd_1422_);
lean_dec(v_a_1420_);
v_fst_1232_ = v_fst_1421_;
v_snd_1233_ = v_snd_1422_;
goto v___jp_1231_;
}
else
{
lean_object* v_a_1423_; lean_object* v___x_1425_; uint8_t v_isShared_1426_; uint8_t v_isSharedCheck_1430_; 
lean_dec(v_l_1215_);
v_a_1423_ = lean_ctor_get(v___x_1419_, 0);
v_isSharedCheck_1430_ = !lean_is_exclusive(v___x_1419_);
if (v_isSharedCheck_1430_ == 0)
{
v___x_1425_ = v___x_1419_;
v_isShared_1426_ = v_isSharedCheck_1430_;
goto v_resetjp_1424_;
}
else
{
lean_inc(v_a_1423_);
lean_dec(v___x_1419_);
v___x_1425_ = lean_box(0);
v_isShared_1426_ = v_isSharedCheck_1430_;
goto v_resetjp_1424_;
}
v_resetjp_1424_:
{
lean_object* v___x_1428_; 
if (v_isShared_1426_ == 0)
{
v___x_1428_ = v___x_1425_;
goto v_reusejp_1427_;
}
else
{
lean_object* v_reuseFailAlloc_1429_; 
v_reuseFailAlloc_1429_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1429_, 0, v_a_1423_);
v___x_1428_ = v_reuseFailAlloc_1429_;
goto v_reusejp_1427_;
}
v_reusejp_1427_:
{
return v___x_1428_;
}
}
}
}
}
v___jp_1231_:
{
lean_object* v_visitedLevels_1234_; lean_object* v_visitedNames_1235_; lean_object* v_visitedExprs_1236_; lean_object* v_visitedConstants_1237_; lean_object* v_noMDataExprs_1238_; uint8_t v_exportMData_1239_; uint8_t v_exportUnsafe_1240_; uint8_t v_ignoreMissing_1241_; lean_object* v_recursorMap_1242_; lean_object* v___x_1244_; uint8_t v_isShared_1245_; uint8_t v_isSharedCheck_1273_; 
v_visitedLevels_1234_ = lean_ctor_get(v_snd_1233_, 1);
v_visitedNames_1235_ = lean_ctor_get(v_snd_1233_, 0);
v_visitedExprs_1236_ = lean_ctor_get(v_snd_1233_, 2);
v_visitedConstants_1237_ = lean_ctor_get(v_snd_1233_, 3);
v_noMDataExprs_1238_ = lean_ctor_get(v_snd_1233_, 4);
v_exportMData_1239_ = lean_ctor_get_uint8(v_snd_1233_, sizeof(void*)*6);
v_exportUnsafe_1240_ = lean_ctor_get_uint8(v_snd_1233_, sizeof(void*)*6 + 1);
v_ignoreMissing_1241_ = lean_ctor_get_uint8(v_snd_1233_, sizeof(void*)*6 + 2);
v_recursorMap_1242_ = lean_ctor_get(v_snd_1233_, 5);
v_isSharedCheck_1273_ = !lean_is_exclusive(v_snd_1233_);
if (v_isSharedCheck_1273_ == 0)
{
v___x_1244_ = v_snd_1233_;
v_isShared_1245_ = v_isSharedCheck_1273_;
goto v_resetjp_1243_;
}
else
{
lean_inc(v_recursorMap_1242_);
lean_inc(v_noMDataExprs_1238_);
lean_inc(v_visitedConstants_1237_);
lean_inc(v_visitedExprs_1236_);
lean_inc(v_visitedLevels_1234_);
lean_inc(v_visitedNames_1235_);
lean_dec(v_snd_1233_);
v___x_1244_ = lean_box(0);
v_isShared_1245_ = v_isSharedCheck_1273_;
goto v_resetjp_1243_;
}
v_resetjp_1243_:
{
lean_object* v_size_1246_; lean_object* v___x_1247_; lean_object* v___x_1248_; lean_object* v___x_1249_; lean_object* v___x_1250_; lean_object* v___x_1251_; 
v_size_1246_ = lean_ctor_get(v_visitedLevels_1234_, 0);
lean_inc_n(v_size_1246_, 2);
v___x_1247_ = l_Lean_JsonNumber_fromNat(v_size_1246_);
v___x_1248_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1248_, 0, v___x_1247_);
v___x_1249_ = l_Lean_Json_setObjVal_x21(v_fst_1232_, v___x_1230_, v___x_1248_);
v___x_1250_ = l_Lean_Json_compress(v___x_1249_);
v___x_1251_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1250_);
if (lean_obj_tag(v___x_1251_) == 0)
{
lean_object* v___x_1253_; uint8_t v_isShared_1254_; uint8_t v_isSharedCheck_1263_; 
v_isSharedCheck_1263_ = !lean_is_exclusive(v___x_1251_);
if (v_isSharedCheck_1263_ == 0)
{
lean_object* v_unused_1264_; 
v_unused_1264_ = lean_ctor_get(v___x_1251_, 0);
lean_dec(v_unused_1264_);
v___x_1253_ = v___x_1251_;
v_isShared_1254_ = v_isSharedCheck_1263_;
goto v_resetjp_1252_;
}
else
{
lean_dec(v___x_1251_);
v___x_1253_ = lean_box(0);
v_isShared_1254_ = v_isSharedCheck_1263_;
goto v_resetjp_1252_;
}
v_resetjp_1252_:
{
lean_object* v___x_1255_; lean_object* v___x_1257_; 
lean_inc(v_size_1246_);
v___x_1255_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Elab_MutualInductive_0__Lean_Elab_Command_AccLevelState_push_spec__0___redArg(v_visitedLevels_1234_, v_l_1215_, v_size_1246_);
if (v_isShared_1245_ == 0)
{
lean_ctor_set(v___x_1244_, 1, v___x_1255_);
v___x_1257_ = v___x_1244_;
goto v_reusejp_1256_;
}
else
{
lean_object* v_reuseFailAlloc_1262_; 
v_reuseFailAlloc_1262_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_1262_, 0, v_visitedNames_1235_);
lean_ctor_set(v_reuseFailAlloc_1262_, 1, v___x_1255_);
lean_ctor_set(v_reuseFailAlloc_1262_, 2, v_visitedExprs_1236_);
lean_ctor_set(v_reuseFailAlloc_1262_, 3, v_visitedConstants_1237_);
lean_ctor_set(v_reuseFailAlloc_1262_, 4, v_noMDataExprs_1238_);
lean_ctor_set(v_reuseFailAlloc_1262_, 5, v_recursorMap_1242_);
lean_ctor_set_uint8(v_reuseFailAlloc_1262_, sizeof(void*)*6, v_exportMData_1239_);
lean_ctor_set_uint8(v_reuseFailAlloc_1262_, sizeof(void*)*6 + 1, v_exportUnsafe_1240_);
lean_ctor_set_uint8(v_reuseFailAlloc_1262_, sizeof(void*)*6 + 2, v_ignoreMissing_1241_);
v___x_1257_ = v_reuseFailAlloc_1262_;
goto v_reusejp_1256_;
}
v_reusejp_1256_:
{
lean_object* v___x_1258_; lean_object* v___x_1260_; 
v___x_1258_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1258_, 0, v_size_1246_);
lean_ctor_set(v___x_1258_, 1, v___x_1257_);
if (v_isShared_1254_ == 0)
{
lean_ctor_set(v___x_1253_, 0, v___x_1258_);
v___x_1260_ = v___x_1253_;
goto v_reusejp_1259_;
}
else
{
lean_object* v_reuseFailAlloc_1261_; 
v_reuseFailAlloc_1261_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1261_, 0, v___x_1258_);
v___x_1260_ = v_reuseFailAlloc_1261_;
goto v_reusejp_1259_;
}
v_reusejp_1259_:
{
return v___x_1260_;
}
}
}
}
else
{
lean_object* v_a_1265_; lean_object* v___x_1267_; uint8_t v_isShared_1268_; uint8_t v_isSharedCheck_1272_; 
lean_dec(v_size_1246_);
lean_del_object(v___x_1244_);
lean_dec(v_recursorMap_1242_);
lean_dec_ref(v_noMDataExprs_1238_);
lean_dec_ref(v_visitedConstants_1237_);
lean_dec_ref(v_visitedExprs_1236_);
lean_dec_ref(v_visitedNames_1235_);
lean_dec_ref(v_visitedLevels_1234_);
lean_dec(v_l_1215_);
v_a_1265_ = lean_ctor_get(v___x_1251_, 0);
v_isSharedCheck_1272_ = !lean_is_exclusive(v___x_1251_);
if (v_isSharedCheck_1272_ == 0)
{
v___x_1267_ = v___x_1251_;
v_isShared_1268_ = v_isSharedCheck_1272_;
goto v_resetjp_1266_;
}
else
{
lean_inc(v_a_1265_);
lean_dec(v___x_1251_);
v___x_1267_ = lean_box(0);
v_isShared_1268_ = v_isSharedCheck_1272_;
goto v_resetjp_1266_;
}
v_resetjp_1266_:
{
lean_object* v___x_1270_; 
if (v_isShared_1268_ == 0)
{
v___x_1270_ = v___x_1267_;
goto v_reusejp_1269_;
}
else
{
lean_object* v_reuseFailAlloc_1271_; 
v_reuseFailAlloc_1271_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1271_, 0, v_a_1265_);
v___x_1270_ = v_reuseFailAlloc_1271_;
goto v_reusejp_1269_;
}
v_reusejp_1269_:
{
return v___x_1270_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpLevel___boxed(lean_object* v_l_1431_, lean_object* v_a_1432_, lean_object* v_a_1433_, lean_object* v_a_1434_){
_start:
{
lean_object* v_res_1435_; 
v_res_1435_ = lp_proofEnvironment_dumpLevel(v_l_1431_, v_a_1432_, v_a_1433_);
lean_dec_ref(v_a_1432_);
return v_res_1435_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0(lean_object* v_x_1436_, lean_object* v_x_1437_, lean_object* v___y_1438_, lean_object* v___y_1439_){
_start:
{
if (lean_obj_tag(v_x_1436_) == 0)
{
lean_object* v___x_1441_; lean_object* v___x_1442_; lean_object* v___x_1443_; 
v___x_1441_ = l_List_reverse___redArg(v_x_1437_);
v___x_1442_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1442_, 0, v___x_1441_);
lean_ctor_set(v___x_1442_, 1, v___y_1439_);
v___x_1443_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1443_, 0, v___x_1442_);
return v___x_1443_;
}
else
{
lean_object* v_head_1444_; lean_object* v_tail_1445_; lean_object* v___x_1447_; uint8_t v_isShared_1448_; uint8_t v_isSharedCheck_1465_; 
v_head_1444_ = lean_ctor_get(v_x_1436_, 0);
v_tail_1445_ = lean_ctor_get(v_x_1436_, 1);
v_isSharedCheck_1465_ = !lean_is_exclusive(v_x_1436_);
if (v_isSharedCheck_1465_ == 0)
{
v___x_1447_ = v_x_1436_;
v_isShared_1448_ = v_isSharedCheck_1465_;
goto v_resetjp_1446_;
}
else
{
lean_inc(v_tail_1445_);
lean_inc(v_head_1444_);
lean_dec(v_x_1436_);
v___x_1447_ = lean_box(0);
v_isShared_1448_ = v_isSharedCheck_1465_;
goto v_resetjp_1446_;
}
v_resetjp_1446_:
{
lean_object* v___x_1449_; 
v___x_1449_ = lp_proofEnvironment_dumpName(v_head_1444_, v___y_1438_, v___y_1439_);
if (lean_obj_tag(v___x_1449_) == 0)
{
lean_object* v_a_1450_; lean_object* v_fst_1451_; lean_object* v_snd_1452_; lean_object* v___x_1454_; 
v_a_1450_ = lean_ctor_get(v___x_1449_, 0);
lean_inc(v_a_1450_);
lean_dec_ref_known(v___x_1449_, 1);
v_fst_1451_ = lean_ctor_get(v_a_1450_, 0);
lean_inc(v_fst_1451_);
v_snd_1452_ = lean_ctor_get(v_a_1450_, 1);
lean_inc(v_snd_1452_);
lean_dec(v_a_1450_);
if (v_isShared_1448_ == 0)
{
lean_ctor_set(v___x_1447_, 1, v_x_1437_);
lean_ctor_set(v___x_1447_, 0, v_fst_1451_);
v___x_1454_ = v___x_1447_;
goto v_reusejp_1453_;
}
else
{
lean_object* v_reuseFailAlloc_1456_; 
v_reuseFailAlloc_1456_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1456_, 0, v_fst_1451_);
lean_ctor_set(v_reuseFailAlloc_1456_, 1, v_x_1437_);
v___x_1454_ = v_reuseFailAlloc_1456_;
goto v_reusejp_1453_;
}
v_reusejp_1453_:
{
v_x_1436_ = v_tail_1445_;
v_x_1437_ = v___x_1454_;
v___y_1439_ = v_snd_1452_;
goto _start;
}
}
else
{
lean_object* v_a_1457_; lean_object* v___x_1459_; uint8_t v_isShared_1460_; uint8_t v_isSharedCheck_1464_; 
lean_del_object(v___x_1447_);
lean_dec(v_tail_1445_);
lean_dec(v_x_1437_);
v_a_1457_ = lean_ctor_get(v___x_1449_, 0);
v_isSharedCheck_1464_ = !lean_is_exclusive(v___x_1449_);
if (v_isSharedCheck_1464_ == 0)
{
v___x_1459_ = v___x_1449_;
v_isShared_1460_ = v_isSharedCheck_1464_;
goto v_resetjp_1458_;
}
else
{
lean_inc(v_a_1457_);
lean_dec(v___x_1449_);
v___x_1459_ = lean_box(0);
v_isShared_1460_ = v_isSharedCheck_1464_;
goto v_resetjp_1458_;
}
v_resetjp_1458_:
{
lean_object* v___x_1462_; 
if (v_isShared_1460_ == 0)
{
v___x_1462_ = v___x_1459_;
goto v_reusejp_1461_;
}
else
{
lean_object* v_reuseFailAlloc_1463_; 
v_reuseFailAlloc_1463_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1463_, 0, v_a_1457_);
v___x_1462_ = v_reuseFailAlloc_1463_;
goto v_reusejp_1461_;
}
v_reusejp_1461_:
{
return v___x_1462_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0___boxed(lean_object* v_x_1466_, lean_object* v_x_1467_, lean_object* v___y_1468_, lean_object* v___y_1469_, lean_object* v___y_1470_){
_start:
{
lean_object* v_res_1471_; 
v_res_1471_ = lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0(v_x_1466_, v_x_1467_, v___y_1468_, v___y_1469_);
lean_dec_ref(v___y_1468_);
return v_res_1471_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(lean_object* v_a_1472_){
_start:
{
lean_object* v___x_1473_; lean_object* v___x_1474_; 
v___x_1473_ = lean_array_mk(v_a_1472_);
v___x_1474_ = l_Lean_Array_toJson___at___00Lean_Firefox_instToJsonStackTable_toJson_spec__0(v___x_1473_);
return v___x_1474_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1(lean_object* v_x_1475_, lean_object* v_x_1476_, lean_object* v___y_1477_, lean_object* v___y_1478_){
_start:
{
if (lean_obj_tag(v_x_1475_) == 0)
{
lean_object* v___x_1480_; lean_object* v___x_1481_; lean_object* v___x_1482_; 
v___x_1480_ = l_List_reverse___redArg(v_x_1476_);
v___x_1481_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1481_, 0, v___x_1480_);
lean_ctor_set(v___x_1481_, 1, v___y_1478_);
v___x_1482_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1482_, 0, v___x_1481_);
return v___x_1482_;
}
else
{
lean_object* v_head_1483_; lean_object* v_tail_1484_; lean_object* v___x_1486_; uint8_t v_isShared_1487_; uint8_t v_isSharedCheck_1504_; 
v_head_1483_ = lean_ctor_get(v_x_1475_, 0);
v_tail_1484_ = lean_ctor_get(v_x_1475_, 1);
v_isSharedCheck_1504_ = !lean_is_exclusive(v_x_1475_);
if (v_isSharedCheck_1504_ == 0)
{
v___x_1486_ = v_x_1475_;
v_isShared_1487_ = v_isSharedCheck_1504_;
goto v_resetjp_1485_;
}
else
{
lean_inc(v_tail_1484_);
lean_inc(v_head_1483_);
lean_dec(v_x_1475_);
v___x_1486_ = lean_box(0);
v_isShared_1487_ = v_isSharedCheck_1504_;
goto v_resetjp_1485_;
}
v_resetjp_1485_:
{
lean_object* v___x_1488_; 
v___x_1488_ = lp_proofEnvironment_dumpLevel(v_head_1483_, v___y_1477_, v___y_1478_);
if (lean_obj_tag(v___x_1488_) == 0)
{
lean_object* v_a_1489_; lean_object* v_fst_1490_; lean_object* v_snd_1491_; lean_object* v___x_1493_; 
v_a_1489_ = lean_ctor_get(v___x_1488_, 0);
lean_inc(v_a_1489_);
lean_dec_ref_known(v___x_1488_, 1);
v_fst_1490_ = lean_ctor_get(v_a_1489_, 0);
lean_inc(v_fst_1490_);
v_snd_1491_ = lean_ctor_get(v_a_1489_, 1);
lean_inc(v_snd_1491_);
lean_dec(v_a_1489_);
if (v_isShared_1487_ == 0)
{
lean_ctor_set(v___x_1486_, 1, v_x_1476_);
lean_ctor_set(v___x_1486_, 0, v_fst_1490_);
v___x_1493_ = v___x_1486_;
goto v_reusejp_1492_;
}
else
{
lean_object* v_reuseFailAlloc_1495_; 
v_reuseFailAlloc_1495_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1495_, 0, v_fst_1490_);
lean_ctor_set(v_reuseFailAlloc_1495_, 1, v_x_1476_);
v___x_1493_ = v_reuseFailAlloc_1495_;
goto v_reusejp_1492_;
}
v_reusejp_1492_:
{
v_x_1475_ = v_tail_1484_;
v_x_1476_ = v___x_1493_;
v___y_1478_ = v_snd_1491_;
goto _start;
}
}
else
{
lean_object* v_a_1496_; lean_object* v___x_1498_; uint8_t v_isShared_1499_; uint8_t v_isSharedCheck_1503_; 
lean_del_object(v___x_1486_);
lean_dec(v_tail_1484_);
lean_dec(v_x_1476_);
v_a_1496_ = lean_ctor_get(v___x_1488_, 0);
v_isSharedCheck_1503_ = !lean_is_exclusive(v___x_1488_);
if (v_isSharedCheck_1503_ == 0)
{
v___x_1498_ = v___x_1488_;
v_isShared_1499_ = v_isSharedCheck_1503_;
goto v_resetjp_1497_;
}
else
{
lean_inc(v_a_1496_);
lean_dec(v___x_1488_);
v___x_1498_ = lean_box(0);
v_isShared_1499_ = v_isSharedCheck_1503_;
goto v_resetjp_1497_;
}
v_resetjp_1497_:
{
lean_object* v___x_1501_; 
if (v_isShared_1499_ == 0)
{
v___x_1501_ = v___x_1498_;
goto v_reusejp_1500_;
}
else
{
lean_object* v_reuseFailAlloc_1502_; 
v_reuseFailAlloc_1502_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1502_, 0, v_a_1496_);
v___x_1501_ = v_reuseFailAlloc_1502_;
goto v_reusejp_1500_;
}
v_reusejp_1500_:
{
return v___x_1501_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1___boxed(lean_object* v_x_1505_, lean_object* v_x_1506_, lean_object* v___y_1507_, lean_object* v___y_1508_, lean_object* v___y_1509_){
_start:
{
lean_object* v_res_1510_; 
v_res_1510_ = lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1(v_x_1505_, v_x_1506_, v___y_1507_, v___y_1508_);
lean_dec_ref(v___y_1507_);
return v_res_1510_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpUparams(lean_object* v_uparams_1511_, lean_object* v_a_1512_, lean_object* v_a_1513_){
_start:
{
lean_object* v___x_1515_; lean_object* v___x_1516_; 
v___x_1515_ = lean_box(0);
lean_inc(v_uparams_1511_);
v___x_1516_ = lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0(v_uparams_1511_, v___x_1515_, v_a_1512_, v_a_1513_);
if (lean_obj_tag(v___x_1516_) == 0)
{
lean_object* v_a_1517_; lean_object* v_fst_1518_; lean_object* v_snd_1519_; lean_object* v___x_1520_; lean_object* v___x_1521_; 
v_a_1517_ = lean_ctor_get(v___x_1516_, 0);
lean_inc(v_a_1517_);
lean_dec_ref_known(v___x_1516_, 1);
v_fst_1518_ = lean_ctor_get(v_a_1517_, 0);
lean_inc(v_fst_1518_);
v_snd_1519_ = lean_ctor_get(v_a_1517_, 1);
lean_inc(v_snd_1519_);
lean_dec(v_a_1517_);
v___x_1520_ = l_List_mapTR_loop___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__12(v_uparams_1511_, v___x_1515_);
v___x_1521_ = lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1(v___x_1520_, v___x_1515_, v_a_1512_, v_snd_1519_);
if (lean_obj_tag(v___x_1521_) == 0)
{
lean_object* v_a_1522_; lean_object* v___x_1524_; uint8_t v_isShared_1525_; uint8_t v_isSharedCheck_1539_; 
v_a_1522_ = lean_ctor_get(v___x_1521_, 0);
v_isSharedCheck_1539_ = !lean_is_exclusive(v___x_1521_);
if (v_isSharedCheck_1539_ == 0)
{
v___x_1524_ = v___x_1521_;
v_isShared_1525_ = v_isSharedCheck_1539_;
goto v_resetjp_1523_;
}
else
{
lean_inc(v_a_1522_);
lean_dec(v___x_1521_);
v___x_1524_ = lean_box(0);
v_isShared_1525_ = v_isSharedCheck_1539_;
goto v_resetjp_1523_;
}
v_resetjp_1523_:
{
lean_object* v_snd_1526_; lean_object* v___x_1528_; uint8_t v_isShared_1529_; uint8_t v_isSharedCheck_1537_; 
v_snd_1526_ = lean_ctor_get(v_a_1522_, 1);
v_isSharedCheck_1537_ = !lean_is_exclusive(v_a_1522_);
if (v_isSharedCheck_1537_ == 0)
{
lean_object* v_unused_1538_; 
v_unused_1538_ = lean_ctor_get(v_a_1522_, 0);
lean_dec(v_unused_1538_);
v___x_1528_ = v_a_1522_;
v_isShared_1529_ = v_isSharedCheck_1537_;
goto v_resetjp_1527_;
}
else
{
lean_inc(v_snd_1526_);
lean_dec(v_a_1522_);
v___x_1528_ = lean_box(0);
v_isShared_1529_ = v_isSharedCheck_1537_;
goto v_resetjp_1527_;
}
v_resetjp_1527_:
{
lean_object* v___x_1530_; lean_object* v___x_1532_; 
v___x_1530_ = lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(v_fst_1518_);
if (v_isShared_1529_ == 0)
{
lean_ctor_set(v___x_1528_, 0, v___x_1530_);
v___x_1532_ = v___x_1528_;
goto v_reusejp_1531_;
}
else
{
lean_object* v_reuseFailAlloc_1536_; 
v_reuseFailAlloc_1536_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1536_, 0, v___x_1530_);
lean_ctor_set(v_reuseFailAlloc_1536_, 1, v_snd_1526_);
v___x_1532_ = v_reuseFailAlloc_1536_;
goto v_reusejp_1531_;
}
v_reusejp_1531_:
{
lean_object* v___x_1534_; 
if (v_isShared_1525_ == 0)
{
lean_ctor_set(v___x_1524_, 0, v___x_1532_);
v___x_1534_ = v___x_1524_;
goto v_reusejp_1533_;
}
else
{
lean_object* v_reuseFailAlloc_1535_; 
v_reuseFailAlloc_1535_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1535_, 0, v___x_1532_);
v___x_1534_ = v_reuseFailAlloc_1535_;
goto v_reusejp_1533_;
}
v_reusejp_1533_:
{
return v___x_1534_;
}
}
}
}
}
else
{
lean_object* v_a_1540_; lean_object* v___x_1542_; uint8_t v_isShared_1543_; uint8_t v_isSharedCheck_1547_; 
lean_dec(v_fst_1518_);
v_a_1540_ = lean_ctor_get(v___x_1521_, 0);
v_isSharedCheck_1547_ = !lean_is_exclusive(v___x_1521_);
if (v_isSharedCheck_1547_ == 0)
{
v___x_1542_ = v___x_1521_;
v_isShared_1543_ = v_isSharedCheck_1547_;
goto v_resetjp_1541_;
}
else
{
lean_inc(v_a_1540_);
lean_dec(v___x_1521_);
v___x_1542_ = lean_box(0);
v_isShared_1543_ = v_isSharedCheck_1547_;
goto v_resetjp_1541_;
}
v_resetjp_1541_:
{
lean_object* v___x_1545_; 
if (v_isShared_1543_ == 0)
{
v___x_1545_ = v___x_1542_;
goto v_reusejp_1544_;
}
else
{
lean_object* v_reuseFailAlloc_1546_; 
v_reuseFailAlloc_1546_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1546_, 0, v_a_1540_);
v___x_1545_ = v_reuseFailAlloc_1546_;
goto v_reusejp_1544_;
}
v_reusejp_1544_:
{
return v___x_1545_;
}
}
}
}
else
{
lean_object* v_a_1548_; lean_object* v___x_1550_; uint8_t v_isShared_1551_; uint8_t v_isSharedCheck_1555_; 
lean_dec(v_uparams_1511_);
v_a_1548_ = lean_ctor_get(v___x_1516_, 0);
v_isSharedCheck_1555_ = !lean_is_exclusive(v___x_1516_);
if (v_isSharedCheck_1555_ == 0)
{
v___x_1550_ = v___x_1516_;
v_isShared_1551_ = v_isSharedCheck_1555_;
goto v_resetjp_1549_;
}
else
{
lean_inc(v_a_1548_);
lean_dec(v___x_1516_);
v___x_1550_ = lean_box(0);
v_isShared_1551_ = v_isSharedCheck_1555_;
goto v_resetjp_1549_;
}
v_resetjp_1549_:
{
lean_object* v___x_1553_; 
if (v_isShared_1551_ == 0)
{
v___x_1553_ = v___x_1550_;
goto v_reusejp_1552_;
}
else
{
lean_object* v_reuseFailAlloc_1554_; 
v_reuseFailAlloc_1554_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1554_, 0, v_a_1548_);
v___x_1553_ = v_reuseFailAlloc_1554_;
goto v_reusejp_1552_;
}
v_reusejp_1552_:
{
return v___x_1553_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpUparams___boxed(lean_object* v_uparams_1556_, lean_object* v_a_1557_, lean_object* v_a_1558_, lean_object* v_a_1559_){
_start:
{
lean_object* v_res_1560_; 
v_res_1560_ = lp_proofEnvironment_dumpUparams(v_uparams_1556_, v_a_1557_, v_a_1558_);
lean_dec_ref(v_a_1557_);
return v_res_1560_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpNames(lean_object* v_uparams_1561_, lean_object* v_a_1562_, lean_object* v_a_1563_){
_start:
{
lean_object* v___x_1565_; lean_object* v___x_1566_; 
v___x_1565_ = lean_box(0);
v___x_1566_ = lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__0(v_uparams_1561_, v___x_1565_, v_a_1562_, v_a_1563_);
if (lean_obj_tag(v___x_1566_) == 0)
{
lean_object* v_a_1567_; lean_object* v___x_1569_; uint8_t v_isShared_1570_; uint8_t v_isSharedCheck_1584_; 
v_a_1567_ = lean_ctor_get(v___x_1566_, 0);
v_isSharedCheck_1584_ = !lean_is_exclusive(v___x_1566_);
if (v_isSharedCheck_1584_ == 0)
{
v___x_1569_ = v___x_1566_;
v_isShared_1570_ = v_isSharedCheck_1584_;
goto v_resetjp_1568_;
}
else
{
lean_inc(v_a_1567_);
lean_dec(v___x_1566_);
v___x_1569_ = lean_box(0);
v_isShared_1570_ = v_isSharedCheck_1584_;
goto v_resetjp_1568_;
}
v_resetjp_1568_:
{
lean_object* v_fst_1571_; lean_object* v_snd_1572_; lean_object* v___x_1574_; uint8_t v_isShared_1575_; uint8_t v_isSharedCheck_1583_; 
v_fst_1571_ = lean_ctor_get(v_a_1567_, 0);
v_snd_1572_ = lean_ctor_get(v_a_1567_, 1);
v_isSharedCheck_1583_ = !lean_is_exclusive(v_a_1567_);
if (v_isSharedCheck_1583_ == 0)
{
v___x_1574_ = v_a_1567_;
v_isShared_1575_ = v_isSharedCheck_1583_;
goto v_resetjp_1573_;
}
else
{
lean_inc(v_snd_1572_);
lean_inc(v_fst_1571_);
lean_dec(v_a_1567_);
v___x_1574_ = lean_box(0);
v_isShared_1575_ = v_isSharedCheck_1583_;
goto v_resetjp_1573_;
}
v_resetjp_1573_:
{
lean_object* v___x_1576_; lean_object* v___x_1578_; 
v___x_1576_ = lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(v_fst_1571_);
if (v_isShared_1575_ == 0)
{
lean_ctor_set(v___x_1574_, 0, v___x_1576_);
v___x_1578_ = v___x_1574_;
goto v_reusejp_1577_;
}
else
{
lean_object* v_reuseFailAlloc_1582_; 
v_reuseFailAlloc_1582_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1582_, 0, v___x_1576_);
lean_ctor_set(v_reuseFailAlloc_1582_, 1, v_snd_1572_);
v___x_1578_ = v_reuseFailAlloc_1582_;
goto v_reusejp_1577_;
}
v_reusejp_1577_:
{
lean_object* v___x_1580_; 
if (v_isShared_1570_ == 0)
{
lean_ctor_set(v___x_1569_, 0, v___x_1578_);
v___x_1580_ = v___x_1569_;
goto v_reusejp_1579_;
}
else
{
lean_object* v_reuseFailAlloc_1581_; 
v_reuseFailAlloc_1581_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1581_, 0, v___x_1578_);
v___x_1580_ = v_reuseFailAlloc_1581_;
goto v_reusejp_1579_;
}
v_reusejp_1579_:
{
return v___x_1580_;
}
}
}
}
}
else
{
lean_object* v_a_1585_; lean_object* v___x_1587_; uint8_t v_isShared_1588_; uint8_t v_isSharedCheck_1592_; 
v_a_1585_ = lean_ctor_get(v___x_1566_, 0);
v_isSharedCheck_1592_ = !lean_is_exclusive(v___x_1566_);
if (v_isSharedCheck_1592_ == 0)
{
v___x_1587_ = v___x_1566_;
v_isShared_1588_ = v_isSharedCheck_1592_;
goto v_resetjp_1586_;
}
else
{
lean_inc(v_a_1585_);
lean_dec(v___x_1566_);
v___x_1587_ = lean_box(0);
v_isShared_1588_ = v_isSharedCheck_1592_;
goto v_resetjp_1586_;
}
v_resetjp_1586_:
{
lean_object* v___x_1590_; 
if (v_isShared_1588_ == 0)
{
v___x_1590_ = v___x_1587_;
goto v_reusejp_1589_;
}
else
{
lean_object* v_reuseFailAlloc_1591_; 
v_reuseFailAlloc_1591_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1591_, 0, v_a_1585_);
v___x_1590_ = v_reuseFailAlloc_1591_;
goto v_reusejp_1589_;
}
v_reusejp_1589_:
{
return v___x_1590_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpNames___boxed(lean_object* v_uparams_1593_, lean_object* v_a_1594_, lean_object* v_a_1595_, lean_object* v_a_1596_){
_start:
{
lean_object* v_res_1597_; 
v_res_1597_ = lp_proofEnvironment_dumpNames(v_uparams_1593_, v_a_1594_, v_a_1595_);
lean_dec_ref(v_a_1594_);
return v_res_1597_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00removeMData_spec__0(lean_object* v_msg_1598_, lean_object* v___y_1599_, lean_object* v___y_1600_){
_start:
{
lean_object* v___x_1602_; lean_object* v___f_1603_; lean_object* v___f_1604_; lean_object* v___f_1605_; lean_object* v___f_1606_; lean_object* v___x_1607_; lean_object* v___x_1608_; lean_object* v___x_1609_; lean_object* v___x_1610_; lean_object* v___x_1611_; lean_object* v___x_1612_; lean_object* v___x_1613_; lean_object* v___x_1614_; lean_object* v___f_1615_; lean_object* v___x_10892__overap_1616_; lean_object* v___x_1617_; 
v___x_1602_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0);
v___f_1603_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1603_, 0, v___x_1602_);
v___f_1604_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1604_, 0, v___x_1602_);
v___f_1605_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1605_, 0, v___x_1602_);
v___f_1606_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1606_, 0, v___x_1602_);
v___x_1607_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1607_, 0, lean_box(0));
lean_closure_set(v___x_1607_, 1, lean_box(0));
lean_closure_set(v___x_1607_, 2, v___x_1602_);
v___x_1608_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1608_, 0, v___x_1607_);
lean_ctor_set(v___x_1608_, 1, v___f_1603_);
v___x_1609_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1609_, 0, lean_box(0));
lean_closure_set(v___x_1609_, 1, lean_box(0));
lean_closure_set(v___x_1609_, 2, v___x_1602_);
v___x_1610_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1610_, 0, v___x_1608_);
lean_ctor_set(v___x_1610_, 1, v___x_1609_);
lean_ctor_set(v___x_1610_, 2, v___f_1604_);
lean_ctor_set(v___x_1610_, 3, v___f_1605_);
lean_ctor_set(v___x_1610_, 4, v___f_1606_);
v___x_1611_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1611_, 0, lean_box(0));
lean_closure_set(v___x_1611_, 1, lean_box(0));
lean_closure_set(v___x_1611_, 2, v___x_1602_);
v___x_1612_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1612_, 0, v___x_1610_);
lean_ctor_set(v___x_1612_, 1, v___x_1611_);
v___x_1613_ = l_Lean_instInhabitedExpr;
v___x_1614_ = l_instInhabitedOfMonad___redArg(v___x_1612_, v___x_1613_);
v___f_1615_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1615_, 0, v___x_1614_);
v___x_10892__overap_1616_ = lean_panic_fn_borrowed(v___f_1615_, v_msg_1598_);
lean_dec_ref(v___f_1615_);
lean_inc_ref(v___y_1599_);
v___x_1617_ = lean_apply_3(v___x_10892__overap_1616_, v___y_1599_, v___y_1600_, lean_box(0));
return v___x_1617_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00removeMData_spec__0___boxed(lean_object* v_msg_1618_, lean_object* v___y_1619_, lean_object* v___y_1620_, lean_object* v___y_1621_){
_start:
{
lean_object* v_res_1622_; 
v_res_1622_ = lp_proofEnvironment_panic___at___00removeMData_spec__0(v_msg_1618_, v___y_1619_, v___y_1620_);
lean_dec_ref(v___y_1619_);
return v_res_1622_;
}
}
static lean_object* _init_lp_proofEnvironment_removeMData___closed__1(void){
_start:
{
lean_object* v___x_1624_; lean_object* v___x_1625_; lean_object* v___x_1626_; lean_object* v___x_1627_; lean_object* v___x_1628_; lean_object* v___x_1629_; 
v___x_1624_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__3));
v___x_1625_ = lean_unsigned_to_nat(26u);
v___x_1626_ = lean_unsigned_to_nat(135u);
v___x_1627_ = ((lean_object*)(lp_proofEnvironment_removeMData___closed__0));
v___x_1628_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_1629_ = l_mkPanicMessageWithDecl(v___x_1628_, v___x_1627_, v___x_1626_, v___x_1625_, v___x_1624_);
return v___x_1629_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_removeMData(lean_object* v_e_1630_, lean_object* v_a_1631_, lean_object* v_a_1632_){
_start:
{
lean_object* v_e_x27_1635_; lean_object* v_visitedNames_1636_; lean_object* v_visitedLevels_1637_; lean_object* v_visitedExprs_1638_; lean_object* v_visitedConstants_1639_; lean_object* v_noMDataExprs_1640_; uint8_t v_exportMData_1641_; uint8_t v_exportUnsafe_1642_; uint8_t v_ignoreMissing_1643_; lean_object* v_recursorMap_1644_; lean_object* v_e_x27_1650_; lean_object* v___y_1651_; lean_object* v_visitedNames_1661_; lean_object* v_visitedLevels_1662_; lean_object* v_visitedExprs_1663_; lean_object* v_visitedConstants_1664_; lean_object* v_noMDataExprs_1665_; uint8_t v_exportMData_1666_; uint8_t v_exportUnsafe_1667_; uint8_t v_ignoreMissing_1668_; lean_object* v_recursorMap_1669_; lean_object* v___x_1670_; 
v_visitedNames_1661_ = lean_ctor_get(v_a_1632_, 0);
v_visitedLevels_1662_ = lean_ctor_get(v_a_1632_, 1);
v_visitedExprs_1663_ = lean_ctor_get(v_a_1632_, 2);
v_visitedConstants_1664_ = lean_ctor_get(v_a_1632_, 3);
v_noMDataExprs_1665_ = lean_ctor_get(v_a_1632_, 4);
v_exportMData_1666_ = lean_ctor_get_uint8(v_a_1632_, sizeof(void*)*6);
v_exportUnsafe_1667_ = lean_ctor_get_uint8(v_a_1632_, sizeof(void*)*6 + 1);
v_ignoreMissing_1668_ = lean_ctor_get_uint8(v_a_1632_, sizeof(void*)*6 + 2);
v_recursorMap_1669_ = lean_ctor_get(v_a_1632_, 5);
v___x_1670_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__1___redArg(v_noMDataExprs_1665_, v_e_1630_);
if (lean_obj_tag(v___x_1670_) == 1)
{
lean_object* v_val_1671_; lean_object* v___x_1673_; uint8_t v_isShared_1674_; uint8_t v_isSharedCheck_1679_; 
lean_dec_ref(v_e_1630_);
v_val_1671_ = lean_ctor_get(v___x_1670_, 0);
v_isSharedCheck_1679_ = !lean_is_exclusive(v___x_1670_);
if (v_isSharedCheck_1679_ == 0)
{
v___x_1673_ = v___x_1670_;
v_isShared_1674_ = v_isSharedCheck_1679_;
goto v_resetjp_1672_;
}
else
{
lean_inc(v_val_1671_);
lean_dec(v___x_1670_);
v___x_1673_ = lean_box(0);
v_isShared_1674_ = v_isSharedCheck_1679_;
goto v_resetjp_1672_;
}
v_resetjp_1672_:
{
lean_object* v___x_1675_; lean_object* v___x_1677_; 
v___x_1675_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1675_, 0, v_val_1671_);
lean_ctor_set(v___x_1675_, 1, v_a_1632_);
if (v_isShared_1674_ == 0)
{
lean_ctor_set_tag(v___x_1673_, 0);
lean_ctor_set(v___x_1673_, 0, v___x_1675_);
v___x_1677_ = v___x_1673_;
goto v_reusejp_1676_;
}
else
{
lean_object* v_reuseFailAlloc_1678_; 
v_reuseFailAlloc_1678_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1678_, 0, v___x_1675_);
v___x_1677_ = v_reuseFailAlloc_1678_;
goto v_reusejp_1676_;
}
v_reusejp_1676_:
{
return v___x_1677_;
}
}
}
else
{
lean_dec(v___x_1670_);
switch(lean_obj_tag(v_e_1630_))
{
case 1:
{
lean_object* v___x_1680_; lean_object* v___x_1681_; 
v___x_1680_ = lean_obj_once(&lp_proofEnvironment_removeMData___closed__1, &lp_proofEnvironment_removeMData___closed__1_once, _init_lp_proofEnvironment_removeMData___closed__1);
v___x_1681_ = lp_proofEnvironment_panic___at___00removeMData_spec__0(v___x_1680_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1681_) == 0)
{
lean_object* v_a_1682_; lean_object* v_fst_1683_; lean_object* v_snd_1684_; 
v_a_1682_ = lean_ctor_get(v___x_1681_, 0);
lean_inc(v_a_1682_);
lean_dec_ref_known(v___x_1681_, 1);
v_fst_1683_ = lean_ctor_get(v_a_1682_, 0);
lean_inc(v_fst_1683_);
v_snd_1684_ = lean_ctor_get(v_a_1682_, 1);
lean_inc(v_snd_1684_);
lean_dec(v_a_1682_);
v_e_x27_1650_ = v_fst_1683_;
v___y_1651_ = v_snd_1684_;
goto v___jp_1649_;
}
else
{
lean_dec_ref_known(v_e_1630_, 1);
return v___x_1681_;
}
}
case 2:
{
lean_object* v___x_1685_; lean_object* v___x_1686_; 
v___x_1685_ = lean_obj_once(&lp_proofEnvironment_removeMData___closed__1, &lp_proofEnvironment_removeMData___closed__1_once, _init_lp_proofEnvironment_removeMData___closed__1);
v___x_1686_ = lp_proofEnvironment_panic___at___00removeMData_spec__0(v___x_1685_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1686_) == 0)
{
lean_object* v_a_1687_; lean_object* v_fst_1688_; lean_object* v_snd_1689_; 
v_a_1687_ = lean_ctor_get(v___x_1686_, 0);
lean_inc(v_a_1687_);
lean_dec_ref_known(v___x_1686_, 1);
v_fst_1688_ = lean_ctor_get(v_a_1687_, 0);
lean_inc(v_fst_1688_);
v_snd_1689_ = lean_ctor_get(v_a_1687_, 1);
lean_inc(v_snd_1689_);
lean_dec(v_a_1687_);
v_e_x27_1650_ = v_fst_1688_;
v___y_1651_ = v_snd_1689_;
goto v___jp_1649_;
}
else
{
lean_dec_ref_known(v_e_1630_, 1);
return v___x_1686_;
}
}
case 5:
{
lean_object* v_fn_1690_; lean_object* v_arg_1691_; lean_object* v___x_1692_; 
v_fn_1690_ = lean_ctor_get(v_e_1630_, 0);
v_arg_1691_ = lean_ctor_get(v_e_1630_, 1);
lean_inc_ref(v_fn_1690_);
v___x_1692_ = lp_proofEnvironment_removeMData(v_fn_1690_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1692_) == 0)
{
lean_object* v_a_1693_; lean_object* v_fst_1694_; lean_object* v_snd_1695_; lean_object* v___x_1696_; 
v_a_1693_ = lean_ctor_get(v___x_1692_, 0);
lean_inc(v_a_1693_);
lean_dec_ref_known(v___x_1692_, 1);
v_fst_1694_ = lean_ctor_get(v_a_1693_, 0);
lean_inc(v_fst_1694_);
v_snd_1695_ = lean_ctor_get(v_a_1693_, 1);
lean_inc(v_snd_1695_);
lean_dec(v_a_1693_);
lean_inc_ref(v_arg_1691_);
v___x_1696_ = lp_proofEnvironment_removeMData(v_arg_1691_, v_a_1631_, v_snd_1695_);
if (lean_obj_tag(v___x_1696_) == 0)
{
lean_object* v_a_1697_; lean_object* v_fst_1698_; lean_object* v_snd_1699_; uint8_t v___y_1701_; size_t v___x_1703_; size_t v___x_1704_; uint8_t v___x_1705_; 
v_a_1697_ = lean_ctor_get(v___x_1696_, 0);
lean_inc(v_a_1697_);
lean_dec_ref_known(v___x_1696_, 1);
v_fst_1698_ = lean_ctor_get(v_a_1697_, 0);
lean_inc(v_fst_1698_);
v_snd_1699_ = lean_ctor_get(v_a_1697_, 1);
lean_inc(v_snd_1699_);
lean_dec(v_a_1697_);
v___x_1703_ = lean_ptr_addr(v_fn_1690_);
v___x_1704_ = lean_ptr_addr(v_fst_1694_);
v___x_1705_ = lean_usize_dec_eq(v___x_1703_, v___x_1704_);
if (v___x_1705_ == 0)
{
v___y_1701_ = v___x_1705_;
goto v___jp_1700_;
}
else
{
size_t v___x_1706_; size_t v___x_1707_; uint8_t v___x_1708_; 
v___x_1706_ = lean_ptr_addr(v_arg_1691_);
v___x_1707_ = lean_ptr_addr(v_fst_1698_);
v___x_1708_ = lean_usize_dec_eq(v___x_1706_, v___x_1707_);
v___y_1701_ = v___x_1708_;
goto v___jp_1700_;
}
v___jp_1700_:
{
if (v___y_1701_ == 0)
{
lean_object* v___x_1702_; 
v___x_1702_ = l_Lean_Expr_app___override(v_fst_1694_, v_fst_1698_);
v_e_x27_1650_ = v___x_1702_;
v___y_1651_ = v_snd_1699_;
goto v___jp_1649_;
}
else
{
lean_dec(v_fst_1698_);
lean_dec(v_fst_1694_);
lean_inc_ref(v_e_1630_);
v_e_x27_1650_ = v_e_1630_;
v___y_1651_ = v_snd_1699_;
goto v___jp_1649_;
}
}
}
else
{
lean_dec(v_fst_1694_);
lean_dec_ref_known(v_e_1630_, 2);
return v___x_1696_;
}
}
else
{
lean_dec_ref_known(v_e_1630_, 2);
return v___x_1692_;
}
}
case 6:
{
lean_object* v_binderName_1709_; lean_object* v_binderType_1710_; lean_object* v_body_1711_; uint8_t v_binderInfo_1712_; lean_object* v___x_1713_; 
v_binderName_1709_ = lean_ctor_get(v_e_1630_, 0);
v_binderType_1710_ = lean_ctor_get(v_e_1630_, 1);
v_body_1711_ = lean_ctor_get(v_e_1630_, 2);
v_binderInfo_1712_ = lean_ctor_get_uint8(v_e_1630_, sizeof(void*)*3 + 8);
lean_inc_ref(v_binderType_1710_);
v___x_1713_ = lp_proofEnvironment_removeMData(v_binderType_1710_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1713_) == 0)
{
lean_object* v_a_1714_; lean_object* v_fst_1715_; lean_object* v_snd_1716_; lean_object* v___x_1717_; 
v_a_1714_ = lean_ctor_get(v___x_1713_, 0);
lean_inc(v_a_1714_);
lean_dec_ref_known(v___x_1713_, 1);
v_fst_1715_ = lean_ctor_get(v_a_1714_, 0);
lean_inc(v_fst_1715_);
v_snd_1716_ = lean_ctor_get(v_a_1714_, 1);
lean_inc(v_snd_1716_);
lean_dec(v_a_1714_);
lean_inc_ref(v_body_1711_);
v___x_1717_ = lp_proofEnvironment_removeMData(v_body_1711_, v_a_1631_, v_snd_1716_);
if (lean_obj_tag(v___x_1717_) == 0)
{
lean_object* v_a_1718_; lean_object* v_fst_1719_; lean_object* v_snd_1720_; uint8_t v___y_1722_; size_t v___x_1726_; size_t v___x_1727_; uint8_t v___x_1728_; 
v_a_1718_ = lean_ctor_get(v___x_1717_, 0);
lean_inc(v_a_1718_);
lean_dec_ref_known(v___x_1717_, 1);
v_fst_1719_ = lean_ctor_get(v_a_1718_, 0);
lean_inc(v_fst_1719_);
v_snd_1720_ = lean_ctor_get(v_a_1718_, 1);
lean_inc(v_snd_1720_);
lean_dec(v_a_1718_);
v___x_1726_ = lean_ptr_addr(v_binderType_1710_);
v___x_1727_ = lean_ptr_addr(v_fst_1715_);
v___x_1728_ = lean_usize_dec_eq(v___x_1726_, v___x_1727_);
if (v___x_1728_ == 0)
{
v___y_1722_ = v___x_1728_;
goto v___jp_1721_;
}
else
{
size_t v___x_1729_; size_t v___x_1730_; uint8_t v___x_1731_; 
v___x_1729_ = lean_ptr_addr(v_body_1711_);
v___x_1730_ = lean_ptr_addr(v_fst_1719_);
v___x_1731_ = lean_usize_dec_eq(v___x_1729_, v___x_1730_);
v___y_1722_ = v___x_1731_;
goto v___jp_1721_;
}
v___jp_1721_:
{
if (v___y_1722_ == 0)
{
lean_object* v___x_1723_; 
lean_inc(v_binderName_1709_);
v___x_1723_ = l_Lean_Expr_lam___override(v_binderName_1709_, v_fst_1715_, v_fst_1719_, v_binderInfo_1712_);
v_e_x27_1650_ = v___x_1723_;
v___y_1651_ = v_snd_1720_;
goto v___jp_1649_;
}
else
{
uint8_t v___x_1724_; 
v___x_1724_ = l_Lean_instBEqBinderInfo_beq(v_binderInfo_1712_, v_binderInfo_1712_);
if (v___x_1724_ == 0)
{
lean_object* v___x_1725_; 
lean_inc(v_binderName_1709_);
v___x_1725_ = l_Lean_Expr_lam___override(v_binderName_1709_, v_fst_1715_, v_fst_1719_, v_binderInfo_1712_);
v_e_x27_1650_ = v___x_1725_;
v___y_1651_ = v_snd_1720_;
goto v___jp_1649_;
}
else
{
lean_dec(v_fst_1719_);
lean_dec(v_fst_1715_);
lean_inc_ref(v_e_1630_);
v_e_x27_1650_ = v_e_1630_;
v___y_1651_ = v_snd_1720_;
goto v___jp_1649_;
}
}
}
}
else
{
lean_dec(v_fst_1715_);
lean_dec_ref_known(v_e_1630_, 3);
return v___x_1717_;
}
}
else
{
lean_dec_ref_known(v_e_1630_, 3);
return v___x_1713_;
}
}
case 7:
{
lean_object* v_binderName_1732_; lean_object* v_binderType_1733_; lean_object* v_body_1734_; uint8_t v_binderInfo_1735_; lean_object* v___x_1736_; 
v_binderName_1732_ = lean_ctor_get(v_e_1630_, 0);
v_binderType_1733_ = lean_ctor_get(v_e_1630_, 1);
v_body_1734_ = lean_ctor_get(v_e_1630_, 2);
v_binderInfo_1735_ = lean_ctor_get_uint8(v_e_1630_, sizeof(void*)*3 + 8);
lean_inc_ref(v_binderType_1733_);
v___x_1736_ = lp_proofEnvironment_removeMData(v_binderType_1733_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1736_) == 0)
{
lean_object* v_a_1737_; lean_object* v_fst_1738_; lean_object* v_snd_1739_; lean_object* v___x_1740_; 
v_a_1737_ = lean_ctor_get(v___x_1736_, 0);
lean_inc(v_a_1737_);
lean_dec_ref_known(v___x_1736_, 1);
v_fst_1738_ = lean_ctor_get(v_a_1737_, 0);
lean_inc(v_fst_1738_);
v_snd_1739_ = lean_ctor_get(v_a_1737_, 1);
lean_inc(v_snd_1739_);
lean_dec(v_a_1737_);
lean_inc_ref(v_body_1734_);
v___x_1740_ = lp_proofEnvironment_removeMData(v_body_1734_, v_a_1631_, v_snd_1739_);
if (lean_obj_tag(v___x_1740_) == 0)
{
lean_object* v_a_1741_; lean_object* v_fst_1742_; lean_object* v_snd_1743_; uint8_t v___y_1745_; size_t v___x_1749_; size_t v___x_1750_; uint8_t v___x_1751_; 
v_a_1741_ = lean_ctor_get(v___x_1740_, 0);
lean_inc(v_a_1741_);
lean_dec_ref_known(v___x_1740_, 1);
v_fst_1742_ = lean_ctor_get(v_a_1741_, 0);
lean_inc(v_fst_1742_);
v_snd_1743_ = lean_ctor_get(v_a_1741_, 1);
lean_inc(v_snd_1743_);
lean_dec(v_a_1741_);
v___x_1749_ = lean_ptr_addr(v_binderType_1733_);
v___x_1750_ = lean_ptr_addr(v_fst_1738_);
v___x_1751_ = lean_usize_dec_eq(v___x_1749_, v___x_1750_);
if (v___x_1751_ == 0)
{
v___y_1745_ = v___x_1751_;
goto v___jp_1744_;
}
else
{
size_t v___x_1752_; size_t v___x_1753_; uint8_t v___x_1754_; 
v___x_1752_ = lean_ptr_addr(v_body_1734_);
v___x_1753_ = lean_ptr_addr(v_fst_1742_);
v___x_1754_ = lean_usize_dec_eq(v___x_1752_, v___x_1753_);
v___y_1745_ = v___x_1754_;
goto v___jp_1744_;
}
v___jp_1744_:
{
if (v___y_1745_ == 0)
{
lean_object* v___x_1746_; 
lean_inc(v_binderName_1732_);
v___x_1746_ = l_Lean_Expr_forallE___override(v_binderName_1732_, v_fst_1738_, v_fst_1742_, v_binderInfo_1735_);
v_e_x27_1650_ = v___x_1746_;
v___y_1651_ = v_snd_1743_;
goto v___jp_1649_;
}
else
{
uint8_t v___x_1747_; 
v___x_1747_ = l_Lean_instBEqBinderInfo_beq(v_binderInfo_1735_, v_binderInfo_1735_);
if (v___x_1747_ == 0)
{
lean_object* v___x_1748_; 
lean_inc(v_binderName_1732_);
v___x_1748_ = l_Lean_Expr_forallE___override(v_binderName_1732_, v_fst_1738_, v_fst_1742_, v_binderInfo_1735_);
v_e_x27_1650_ = v___x_1748_;
v___y_1651_ = v_snd_1743_;
goto v___jp_1649_;
}
else
{
lean_dec(v_fst_1742_);
lean_dec(v_fst_1738_);
lean_inc_ref(v_e_1630_);
v_e_x27_1650_ = v_e_1630_;
v___y_1651_ = v_snd_1743_;
goto v___jp_1649_;
}
}
}
}
else
{
lean_dec(v_fst_1738_);
lean_dec_ref_known(v_e_1630_, 3);
return v___x_1740_;
}
}
else
{
lean_dec_ref_known(v_e_1630_, 3);
return v___x_1736_;
}
}
case 8:
{
lean_object* v_declName_1755_; lean_object* v_type_1756_; lean_object* v_value_1757_; lean_object* v_body_1758_; uint8_t v_nondep_1759_; lean_object* v___x_1760_; 
v_declName_1755_ = lean_ctor_get(v_e_1630_, 0);
v_type_1756_ = lean_ctor_get(v_e_1630_, 1);
v_value_1757_ = lean_ctor_get(v_e_1630_, 2);
v_body_1758_ = lean_ctor_get(v_e_1630_, 3);
v_nondep_1759_ = lean_ctor_get_uint8(v_e_1630_, sizeof(void*)*4 + 8);
lean_inc_ref(v_type_1756_);
v___x_1760_ = lp_proofEnvironment_removeMData(v_type_1756_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1760_) == 0)
{
lean_object* v_a_1761_; lean_object* v_fst_1762_; lean_object* v_snd_1763_; lean_object* v___x_1764_; 
v_a_1761_ = lean_ctor_get(v___x_1760_, 0);
lean_inc(v_a_1761_);
lean_dec_ref_known(v___x_1760_, 1);
v_fst_1762_ = lean_ctor_get(v_a_1761_, 0);
lean_inc(v_fst_1762_);
v_snd_1763_ = lean_ctor_get(v_a_1761_, 1);
lean_inc(v_snd_1763_);
lean_dec(v_a_1761_);
lean_inc_ref(v_value_1757_);
v___x_1764_ = lp_proofEnvironment_removeMData(v_value_1757_, v_a_1631_, v_snd_1763_);
if (lean_obj_tag(v___x_1764_) == 0)
{
lean_object* v_a_1765_; lean_object* v_fst_1766_; lean_object* v_snd_1767_; lean_object* v___x_1768_; 
v_a_1765_ = lean_ctor_get(v___x_1764_, 0);
lean_inc(v_a_1765_);
lean_dec_ref_known(v___x_1764_, 1);
v_fst_1766_ = lean_ctor_get(v_a_1765_, 0);
lean_inc(v_fst_1766_);
v_snd_1767_ = lean_ctor_get(v_a_1765_, 1);
lean_inc(v_snd_1767_);
lean_dec(v_a_1765_);
lean_inc_ref(v_body_1758_);
v___x_1768_ = lp_proofEnvironment_removeMData(v_body_1758_, v_a_1631_, v_snd_1767_);
if (lean_obj_tag(v___x_1768_) == 0)
{
lean_object* v_a_1769_; lean_object* v_fst_1770_; lean_object* v_snd_1771_; uint8_t v___x_1772_; uint8_t v___y_1774_; size_t v___x_1781_; size_t v___x_1782_; uint8_t v___x_1783_; 
v_a_1769_ = lean_ctor_get(v___x_1768_, 0);
lean_inc(v_a_1769_);
lean_dec_ref_known(v___x_1768_, 1);
v_fst_1770_ = lean_ctor_get(v_a_1769_, 0);
lean_inc(v_fst_1770_);
v_snd_1771_ = lean_ctor_get(v_a_1769_, 1);
lean_inc(v_snd_1771_);
lean_dec(v_a_1769_);
v___x_1772_ = 0;
v___x_1781_ = lean_ptr_addr(v_type_1756_);
v___x_1782_ = lean_ptr_addr(v_fst_1762_);
v___x_1783_ = lean_usize_dec_eq(v___x_1781_, v___x_1782_);
if (v___x_1783_ == 0)
{
v___y_1774_ = v___x_1783_;
goto v___jp_1773_;
}
else
{
size_t v___x_1784_; size_t v___x_1785_; uint8_t v___x_1786_; 
v___x_1784_ = lean_ptr_addr(v_value_1757_);
v___x_1785_ = lean_ptr_addr(v_fst_1766_);
v___x_1786_ = lean_usize_dec_eq(v___x_1784_, v___x_1785_);
v___y_1774_ = v___x_1786_;
goto v___jp_1773_;
}
v___jp_1773_:
{
if (v___y_1774_ == 0)
{
lean_object* v___x_1775_; 
lean_inc(v_declName_1755_);
v___x_1775_ = l_Lean_Expr_letE___override(v_declName_1755_, v_fst_1762_, v_fst_1766_, v_fst_1770_, v___x_1772_);
v_e_x27_1650_ = v___x_1775_;
v___y_1651_ = v_snd_1771_;
goto v___jp_1649_;
}
else
{
size_t v___x_1776_; size_t v___x_1777_; uint8_t v___x_1778_; 
v___x_1776_ = lean_ptr_addr(v_body_1758_);
v___x_1777_ = lean_ptr_addr(v_fst_1770_);
v___x_1778_ = lean_usize_dec_eq(v___x_1776_, v___x_1777_);
if (v___x_1778_ == 0)
{
lean_object* v___x_1779_; 
lean_inc(v_declName_1755_);
v___x_1779_ = l_Lean_Expr_letE___override(v_declName_1755_, v_fst_1762_, v_fst_1766_, v_fst_1770_, v___x_1772_);
v_e_x27_1650_ = v___x_1779_;
v___y_1651_ = v_snd_1771_;
goto v___jp_1649_;
}
else
{
if (v_nondep_1759_ == 0)
{
lean_dec(v_fst_1770_);
lean_dec(v_fst_1766_);
lean_dec(v_fst_1762_);
lean_inc_ref(v_e_1630_);
v_e_x27_1650_ = v_e_1630_;
v___y_1651_ = v_snd_1771_;
goto v___jp_1649_;
}
else
{
lean_object* v___x_1780_; 
lean_inc(v_declName_1755_);
v___x_1780_ = l_Lean_Expr_letE___override(v_declName_1755_, v_fst_1762_, v_fst_1766_, v_fst_1770_, v___x_1772_);
v_e_x27_1650_ = v___x_1780_;
v___y_1651_ = v_snd_1771_;
goto v___jp_1649_;
}
}
}
}
}
else
{
lean_dec(v_fst_1766_);
lean_dec(v_fst_1762_);
lean_dec_ref_known(v_e_1630_, 4);
return v___x_1768_;
}
}
else
{
lean_dec(v_fst_1762_);
lean_dec_ref_known(v_e_1630_, 4);
return v___x_1764_;
}
}
else
{
lean_dec_ref_known(v_e_1630_, 4);
return v___x_1760_;
}
}
case 10:
{
lean_object* v_expr_1787_; lean_object* v___x_1788_; 
v_expr_1787_ = lean_ctor_get(v_e_1630_, 1);
lean_inc_ref(v_expr_1787_);
v___x_1788_ = lp_proofEnvironment_removeMData(v_expr_1787_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1788_) == 0)
{
lean_object* v_a_1789_; lean_object* v_fst_1790_; lean_object* v_snd_1791_; 
v_a_1789_ = lean_ctor_get(v___x_1788_, 0);
lean_inc(v_a_1789_);
lean_dec_ref_known(v___x_1788_, 1);
v_fst_1790_ = lean_ctor_get(v_a_1789_, 0);
lean_inc(v_fst_1790_);
v_snd_1791_ = lean_ctor_get(v_a_1789_, 1);
lean_inc(v_snd_1791_);
lean_dec(v_a_1789_);
v_e_x27_1650_ = v_fst_1790_;
v___y_1651_ = v_snd_1791_;
goto v___jp_1649_;
}
else
{
lean_dec_ref_known(v_e_1630_, 2);
return v___x_1788_;
}
}
case 11:
{
lean_object* v_typeName_1792_; lean_object* v_idx_1793_; lean_object* v_struct_1794_; lean_object* v___x_1795_; 
v_typeName_1792_ = lean_ctor_get(v_e_1630_, 0);
v_idx_1793_ = lean_ctor_get(v_e_1630_, 1);
v_struct_1794_ = lean_ctor_get(v_e_1630_, 2);
lean_inc_ref(v_struct_1794_);
v___x_1795_ = lp_proofEnvironment_removeMData(v_struct_1794_, v_a_1631_, v_a_1632_);
if (lean_obj_tag(v___x_1795_) == 0)
{
lean_object* v_a_1796_; lean_object* v_fst_1797_; lean_object* v_snd_1798_; size_t v___x_1799_; size_t v___x_1800_; uint8_t v___x_1801_; 
v_a_1796_ = lean_ctor_get(v___x_1795_, 0);
lean_inc(v_a_1796_);
lean_dec_ref_known(v___x_1795_, 1);
v_fst_1797_ = lean_ctor_get(v_a_1796_, 0);
lean_inc(v_fst_1797_);
v_snd_1798_ = lean_ctor_get(v_a_1796_, 1);
lean_inc(v_snd_1798_);
lean_dec(v_a_1796_);
v___x_1799_ = lean_ptr_addr(v_struct_1794_);
v___x_1800_ = lean_ptr_addr(v_fst_1797_);
v___x_1801_ = lean_usize_dec_eq(v___x_1799_, v___x_1800_);
if (v___x_1801_ == 0)
{
lean_object* v___x_1802_; 
lean_inc(v_idx_1793_);
lean_inc(v_typeName_1792_);
v___x_1802_ = l_Lean_Expr_proj___override(v_typeName_1792_, v_idx_1793_, v_fst_1797_);
v_e_x27_1650_ = v___x_1802_;
v___y_1651_ = v_snd_1798_;
goto v___jp_1649_;
}
else
{
lean_dec(v_fst_1797_);
lean_inc_ref(v_e_1630_);
v_e_x27_1650_ = v_e_1630_;
v___y_1651_ = v_snd_1798_;
goto v___jp_1649_;
}
}
else
{
lean_dec_ref_known(v_e_1630_, 3);
return v___x_1795_;
}
}
default: 
{
lean_inc(v_recursorMap_1669_);
lean_inc_ref(v_noMDataExprs_1665_);
lean_inc_ref(v_visitedConstants_1664_);
lean_inc_ref(v_visitedExprs_1663_);
lean_inc_ref(v_visitedLevels_1662_);
lean_inc_ref(v_visitedNames_1661_);
lean_dec_ref(v_a_1632_);
lean_inc_ref(v_e_1630_);
v_e_x27_1635_ = v_e_1630_;
v_visitedNames_1636_ = v_visitedNames_1661_;
v_visitedLevels_1637_ = v_visitedLevels_1662_;
v_visitedExprs_1638_ = v_visitedExprs_1663_;
v_visitedConstants_1639_ = v_visitedConstants_1664_;
v_noMDataExprs_1640_ = v_noMDataExprs_1665_;
v_exportMData_1641_ = v_exportMData_1666_;
v_exportUnsafe_1642_ = v_exportUnsafe_1667_;
v_ignoreMissing_1643_ = v_ignoreMissing_1668_;
v_recursorMap_1644_ = v_recursorMap_1669_;
goto v___jp_1634_;
}
}
}
v___jp_1634_:
{
lean_object* v___x_1645_; lean_object* v___x_1646_; lean_object* v___x_1647_; lean_object* v___x_1648_; 
lean_inc_ref(v_e_x27_1635_);
v___x_1645_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__2___redArg(v_noMDataExprs_1640_, v_e_1630_, v_e_x27_1635_);
v___x_1646_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_1646_, 0, v_visitedNames_1636_);
lean_ctor_set(v___x_1646_, 1, v_visitedLevels_1637_);
lean_ctor_set(v___x_1646_, 2, v_visitedExprs_1638_);
lean_ctor_set(v___x_1646_, 3, v_visitedConstants_1639_);
lean_ctor_set(v___x_1646_, 4, v___x_1645_);
lean_ctor_set(v___x_1646_, 5, v_recursorMap_1644_);
lean_ctor_set_uint8(v___x_1646_, sizeof(void*)*6, v_exportMData_1641_);
lean_ctor_set_uint8(v___x_1646_, sizeof(void*)*6 + 1, v_exportUnsafe_1642_);
lean_ctor_set_uint8(v___x_1646_, sizeof(void*)*6 + 2, v_ignoreMissing_1643_);
v___x_1647_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1647_, 0, v_e_x27_1635_);
lean_ctor_set(v___x_1647_, 1, v___x_1646_);
v___x_1648_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1648_, 0, v___x_1647_);
return v___x_1648_;
}
v___jp_1649_:
{
lean_object* v_visitedNames_1652_; lean_object* v_visitedLevels_1653_; lean_object* v_visitedExprs_1654_; lean_object* v_visitedConstants_1655_; lean_object* v_noMDataExprs_1656_; uint8_t v_exportMData_1657_; uint8_t v_exportUnsafe_1658_; uint8_t v_ignoreMissing_1659_; lean_object* v_recursorMap_1660_; 
v_visitedNames_1652_ = lean_ctor_get(v___y_1651_, 0);
lean_inc_ref(v_visitedNames_1652_);
v_visitedLevels_1653_ = lean_ctor_get(v___y_1651_, 1);
lean_inc_ref(v_visitedLevels_1653_);
v_visitedExprs_1654_ = lean_ctor_get(v___y_1651_, 2);
lean_inc_ref(v_visitedExprs_1654_);
v_visitedConstants_1655_ = lean_ctor_get(v___y_1651_, 3);
lean_inc_ref(v_visitedConstants_1655_);
v_noMDataExprs_1656_ = lean_ctor_get(v___y_1651_, 4);
lean_inc_ref(v_noMDataExprs_1656_);
v_exportMData_1657_ = lean_ctor_get_uint8(v___y_1651_, sizeof(void*)*6);
v_exportUnsafe_1658_ = lean_ctor_get_uint8(v___y_1651_, sizeof(void*)*6 + 1);
v_ignoreMissing_1659_ = lean_ctor_get_uint8(v___y_1651_, sizeof(void*)*6 + 2);
v_recursorMap_1660_ = lean_ctor_get(v___y_1651_, 5);
lean_inc(v_recursorMap_1660_);
lean_dec_ref(v___y_1651_);
v_e_x27_1635_ = v_e_x27_1650_;
v_visitedNames_1636_ = v_visitedNames_1652_;
v_visitedLevels_1637_ = v_visitedLevels_1653_;
v_visitedExprs_1638_ = v_visitedExprs_1654_;
v_visitedConstants_1639_ = v_visitedConstants_1655_;
v_noMDataExprs_1640_ = v_noMDataExprs_1656_;
v_exportMData_1641_ = v_exportMData_1657_;
v_exportUnsafe_1642_ = v_exportUnsafe_1658_;
v_ignoreMissing_1643_ = v_ignoreMissing_1659_;
v_recursorMap_1644_ = v_recursorMap_1660_;
goto v___jp_1634_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_removeMData___boxed(lean_object* v_e_1803_, lean_object* v_a_1804_, lean_object* v_a_1805_, lean_object* v_a_1806_){
_start:
{
lean_object* v_res_1807_; 
v_res_1807_ = lp_proofEnvironment_removeMData(v_e_1803_, v_a_1804_, v_a_1805_);
lean_dec_ref(v_a_1804_);
return v_res_1807_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj___redArg(lean_object* v_fields_1808_, lean_object* v_a_1809_){
_start:
{
lean_object* v___x_1811_; lean_object* v___x_1812_; lean_object* v___x_1813_; 
v___x_1811_ = l_Lean_Json_mkObj(v_fields_1808_);
v___x_1812_ = l_Lean_Json_compress(v___x_1811_);
v___x_1813_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1812_);
if (lean_obj_tag(v___x_1813_) == 0)
{
lean_object* v_a_1814_; lean_object* v___x_1816_; uint8_t v_isShared_1817_; uint8_t v_isSharedCheck_1822_; 
v_a_1814_ = lean_ctor_get(v___x_1813_, 0);
v_isSharedCheck_1822_ = !lean_is_exclusive(v___x_1813_);
if (v_isSharedCheck_1822_ == 0)
{
v___x_1816_ = v___x_1813_;
v_isShared_1817_ = v_isSharedCheck_1822_;
goto v_resetjp_1815_;
}
else
{
lean_inc(v_a_1814_);
lean_dec(v___x_1813_);
v___x_1816_ = lean_box(0);
v_isShared_1817_ = v_isSharedCheck_1822_;
goto v_resetjp_1815_;
}
v_resetjp_1815_:
{
lean_object* v___x_1818_; lean_object* v___x_1820_; 
v___x_1818_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1818_, 0, v_a_1814_);
lean_ctor_set(v___x_1818_, 1, v_a_1809_);
if (v_isShared_1817_ == 0)
{
lean_ctor_set(v___x_1816_, 0, v___x_1818_);
v___x_1820_ = v___x_1816_;
goto v_reusejp_1819_;
}
else
{
lean_object* v_reuseFailAlloc_1821_; 
v_reuseFailAlloc_1821_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1821_, 0, v___x_1818_);
v___x_1820_ = v_reuseFailAlloc_1821_;
goto v_reusejp_1819_;
}
v_reusejp_1819_:
{
return v___x_1820_;
}
}
}
else
{
lean_object* v_a_1823_; lean_object* v___x_1825_; uint8_t v_isShared_1826_; uint8_t v_isSharedCheck_1830_; 
lean_dec_ref(v_a_1809_);
v_a_1823_ = lean_ctor_get(v___x_1813_, 0);
v_isSharedCheck_1830_ = !lean_is_exclusive(v___x_1813_);
if (v_isSharedCheck_1830_ == 0)
{
v___x_1825_ = v___x_1813_;
v_isShared_1826_ = v_isSharedCheck_1830_;
goto v_resetjp_1824_;
}
else
{
lean_inc(v_a_1823_);
lean_dec(v___x_1813_);
v___x_1825_ = lean_box(0);
v_isShared_1826_ = v_isSharedCheck_1830_;
goto v_resetjp_1824_;
}
v_resetjp_1824_:
{
lean_object* v___x_1828_; 
if (v_isShared_1826_ == 0)
{
v___x_1828_ = v___x_1825_;
goto v_reusejp_1827_;
}
else
{
lean_object* v_reuseFailAlloc_1829_; 
v_reuseFailAlloc_1829_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1829_, 0, v_a_1823_);
v___x_1828_ = v_reuseFailAlloc_1829_;
goto v_reusejp_1827_;
}
v_reusejp_1827_:
{
return v___x_1828_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj___redArg___boxed(lean_object* v_fields_1831_, lean_object* v_a_1832_, lean_object* v_a_1833_){
_start:
{
lean_object* v_res_1834_; 
v_res_1834_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v_fields_1831_, v_a_1832_);
lean_dec(v_fields_1831_);
return v_res_1834_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj(lean_object* v_fields_1835_, lean_object* v_a_1836_, lean_object* v_a_1837_){
_start:
{
lean_object* v___x_1839_; 
v___x_1839_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v_fields_1835_, v_a_1837_);
return v___x_1839_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpObj___boxed(lean_object* v_fields_1840_, lean_object* v_a_1841_, lean_object* v_a_1842_, lean_object* v_a_1843_){
_start:
{
lean_object* v_res_1844_; 
v_res_1844_ = lp_proofEnvironment_dumpConstant_dumpObj(v_fields_1840_, v_a_1841_, v_a_1842_);
lean_dec_ref(v_a_1841_);
lean_dec(v_fields_1840_);
return v_res_1844_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__4(lean_object* v_msg_1845_, lean_object* v___y_1846_, lean_object* v___y_1847_){
_start:
{
lean_object* v___x_1849_; lean_object* v___f_1850_; lean_object* v___f_1851_; lean_object* v___f_1852_; lean_object* v___f_1853_; lean_object* v___x_1854_; lean_object* v___x_1855_; lean_object* v___x_1856_; lean_object* v___x_1857_; lean_object* v___x_1858_; lean_object* v___x_1859_; lean_object* v___x_1860_; lean_object* v___x_1861_; lean_object* v___f_1862_; lean_object* v___x_173216__overap_1863_; lean_object* v___x_1864_; 
v___x_1849_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0);
v___f_1850_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1850_, 0, v___x_1849_);
v___f_1851_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1851_, 0, v___x_1849_);
v___f_1852_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1852_, 0, v___x_1849_);
v___f_1853_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1853_, 0, v___x_1849_);
v___x_1854_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1854_, 0, lean_box(0));
lean_closure_set(v___x_1854_, 1, lean_box(0));
lean_closure_set(v___x_1854_, 2, v___x_1849_);
v___x_1855_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1855_, 0, v___x_1854_);
lean_ctor_set(v___x_1855_, 1, v___f_1850_);
v___x_1856_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1856_, 0, lean_box(0));
lean_closure_set(v___x_1856_, 1, lean_box(0));
lean_closure_set(v___x_1856_, 2, v___x_1849_);
v___x_1857_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1857_, 0, v___x_1855_);
lean_ctor_set(v___x_1857_, 1, v___x_1856_);
lean_ctor_set(v___x_1857_, 2, v___f_1851_);
lean_ctor_set(v___x_1857_, 3, v___f_1852_);
lean_ctor_set(v___x_1857_, 4, v___f_1853_);
v___x_1858_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1858_, 0, lean_box(0));
lean_closure_set(v___x_1858_, 1, lean_box(0));
lean_closure_set(v___x_1858_, 2, v___x_1849_);
v___x_1859_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1859_, 0, v___x_1857_);
lean_ctor_set(v___x_1859_, 1, v___x_1858_);
v___x_1860_ = lean_box(0);
v___x_1861_ = l_instInhabitedOfMonad___redArg(v___x_1859_, v___x_1860_);
v___f_1862_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1862_, 0, v___x_1861_);
v___x_173216__overap_1863_ = lean_panic_fn_borrowed(v___f_1862_, v_msg_1845_);
lean_dec_ref(v___f_1862_);
lean_inc_ref(v___y_1846_);
v___x_1864_ = lean_apply_3(v___x_173216__overap_1863_, v___y_1846_, v___y_1847_, lean_box(0));
return v___x_1864_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__4___boxed(lean_object* v_msg_1865_, lean_object* v___y_1866_, lean_object* v___y_1867_, lean_object* v___y_1868_){
_start:
{
lean_object* v_res_1869_; 
v_res_1869_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__4(v_msg_1865_, v___y_1866_, v___y_1867_);
lean_dec_ref(v___y_1866_);
return v_res_1869_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00dumpConstant_spec__3___closed__0(void){
_start:
{
lean_object* v___x_1870_; 
v___x_1870_ = l_Array_instInhabited(lean_box(0));
return v___x_1870_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__3(lean_object* v_msg_1871_, lean_object* v___y_1872_, lean_object* v___y_1873_){
_start:
{
lean_object* v___x_1875_; lean_object* v___f_1876_; lean_object* v___f_1877_; lean_object* v___f_1878_; lean_object* v___f_1879_; lean_object* v___x_1880_; lean_object* v___x_1881_; lean_object* v___x_1882_; lean_object* v___x_1883_; lean_object* v___x_1884_; lean_object* v___x_1885_; lean_object* v___x_1886_; lean_object* v___x_1887_; lean_object* v___x_1888_; lean_object* v___f_1889_; lean_object* v___x_173204__overap_1890_; lean_object* v___x_1891_; 
v___x_1875_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0);
v___f_1876_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1876_, 0, v___x_1875_);
v___f_1877_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1877_, 0, v___x_1875_);
v___f_1878_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1878_, 0, v___x_1875_);
v___f_1879_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1879_, 0, v___x_1875_);
v___x_1880_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1880_, 0, lean_box(0));
lean_closure_set(v___x_1880_, 1, lean_box(0));
lean_closure_set(v___x_1880_, 2, v___x_1875_);
v___x_1881_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1881_, 0, v___x_1880_);
lean_ctor_set(v___x_1881_, 1, v___f_1876_);
v___x_1882_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_1882_, 0, lean_box(0));
lean_closure_set(v___x_1882_, 1, lean_box(0));
lean_closure_set(v___x_1882_, 2, v___x_1875_);
v___x_1883_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1883_, 0, v___x_1881_);
lean_ctor_set(v___x_1883_, 1, v___x_1882_);
lean_ctor_set(v___x_1883_, 2, v___f_1877_);
lean_ctor_set(v___x_1883_, 3, v___f_1878_);
lean_ctor_set(v___x_1883_, 4, v___f_1879_);
v___x_1884_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_1884_, 0, lean_box(0));
lean_closure_set(v___x_1884_, 1, lean_box(0));
lean_closure_set(v___x_1884_, 2, v___x_1875_);
v___x_1885_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1885_, 0, v___x_1883_);
lean_ctor_set(v___x_1885_, 1, v___x_1884_);
v___x_1886_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpConstant_spec__3___closed__0, &lp_proofEnvironment_panic___at___00dumpConstant_spec__3___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpConstant_spec__3___closed__0);
v___x_1887_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1887_, 0, v___x_1886_);
v___x_1888_ = l_instInhabitedOfMonad___redArg(v___x_1885_, v___x_1887_);
v___f_1889_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_1889_, 0, v___x_1888_);
v___x_173204__overap_1890_ = lean_panic_fn_borrowed(v___f_1889_, v_msg_1871_);
lean_dec_ref(v___f_1889_);
lean_inc_ref(v___y_1872_);
v___x_1891_ = lean_apply_3(v___x_173204__overap_1890_, v___y_1872_, v___y_1873_, lean_box(0));
return v___x_1891_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__3___boxed(lean_object* v_msg_1892_, lean_object* v___y_1893_, lean_object* v___y_1894_, lean_object* v___y_1895_){
_start:
{
lean_object* v_res_1896_; 
v_res_1896_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__3(v_msg_1892_, v___y_1893_, v___y_1894_);
lean_dec_ref(v___y_1893_);
return v_res_1896_;
}
}
static lean_object* _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__2(void){
_start:
{
lean_object* v___x_1899_; lean_object* v___x_1900_; lean_object* v___x_1901_; lean_object* v___x_1902_; lean_object* v___x_1903_; lean_object* v___x_1904_; 
v___x_1899_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__1));
v___x_1900_ = lean_unsigned_to_nat(8u);
v___x_1901_ = lean_unsigned_to_nat(337u);
v___x_1902_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_1903_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_1904_ = l_mkPanicMessageWithDecl(v___x_1903_, v___x_1902_, v___x_1901_, v___x_1900_, v___x_1899_);
return v___x_1904_;
}
}
static lean_object* _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__4(void){
_start:
{
lean_object* v___x_1906_; lean_object* v___x_1907_; lean_object* v___x_1908_; lean_object* v___x_1909_; lean_object* v___x_1910_; lean_object* v___x_1911_; 
v___x_1906_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__3));
v___x_1907_ = lean_unsigned_to_nat(13u);
v___x_1908_ = lean_unsigned_to_nat(339u);
v___x_1909_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_1910_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_1911_ = l_mkPanicMessageWithDecl(v___x_1910_, v___x_1909_, v___x_1908_, v___x_1907_, v___x_1906_);
return v___x_1911_;
}
}
static lean_object* _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8(void){
_start:
{
lean_object* v___x_1915_; lean_object* v___x_1916_; lean_object* v___x_1917_; lean_object* v___x_1918_; lean_object* v___x_1919_; lean_object* v___x_1920_; 
v___x_1915_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__7));
v___x_1916_ = lean_unsigned_to_nat(14u);
v___x_1917_ = lean_unsigned_to_nat(22u);
v___x_1918_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__6));
v___x_1919_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__5));
v___x_1920_ = l_mkPanicMessageWithDecl(v___x_1919_, v___x_1918_, v___x_1917_, v___x_1916_, v___x_1915_);
return v___x_1920_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12(uint8_t v___x_1921_, lean_object* v_init_1922_, lean_object* v_x_1923_, lean_object* v___y_1924_, lean_object* v___y_1925_){
_start:
{
lean_object* v_d_1928_; lean_object* v___y_1929_; 
if (lean_obj_tag(v_x_1923_) == 0)
{
lean_object* v_k_1933_; lean_object* v_l_1934_; lean_object* v_r_1935_; lean_object* v___x_1936_; 
v_k_1933_ = lean_ctor_get(v_x_1923_, 1);
lean_inc(v_k_1933_);
v_l_1934_ = lean_ctor_get(v_x_1923_, 3);
lean_inc(v_l_1934_);
v_r_1935_ = lean_ctor_get(v_x_1923_, 4);
lean_inc(v_r_1935_);
lean_dec_ref_known(v_x_1923_, 5);
v___x_1936_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12(v___x_1921_, v_init_1922_, v_l_1934_, v___y_1924_, v___y_1925_);
if (lean_obj_tag(v___x_1936_) == 0)
{
lean_object* v_a_1937_; lean_object* v_fst_1938_; 
v_a_1937_ = lean_ctor_get(v___x_1936_, 0);
lean_inc(v_a_1937_);
lean_dec_ref_known(v___x_1936_, 1);
v_fst_1938_ = lean_ctor_get(v_a_1937_, 0);
lean_inc(v_fst_1938_);
if (lean_obj_tag(v_fst_1938_) == 0)
{
lean_object* v_snd_1939_; lean_object* v_a_1940_; 
lean_dec(v_r_1935_);
lean_dec(v_k_1933_);
v_snd_1939_ = lean_ctor_get(v_a_1937_, 1);
lean_inc(v_snd_1939_);
lean_dec(v_a_1937_);
v_a_1940_ = lean_ctor_get(v_fst_1938_, 0);
lean_inc(v_a_1940_);
lean_dec_ref_known(v_fst_1938_, 1);
v_d_1928_ = v_a_1940_;
v___y_1929_ = v_snd_1939_;
goto v___jp_1927_;
}
else
{
lean_object* v_snd_1941_; lean_object* v_a_1942_; lean_object* v___y_1944_; lean_object* v___y_1948_; lean_object* v___x_1974_; 
v_snd_1941_ = lean_ctor_get(v_a_1937_, 1);
lean_inc(v_snd_1941_);
lean_dec(v_a_1937_);
v_a_1942_ = lean_ctor_get(v_fst_1938_, 0);
lean_inc(v_a_1942_);
lean_dec_ref_known(v_fst_1938_, 1);
lean_inc_ref(v___y_1924_);
v___x_1974_ = l_Lean_Environment_find_x3f(v___y_1924_, v_k_1933_, v___x_1921_);
if (lean_obj_tag(v___x_1974_) == 0)
{
lean_object* v___x_1975_; lean_object* v___x_1976_; 
v___x_1975_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8);
v___x_1976_ = l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(v___x_1975_);
v___y_1948_ = v___x_1976_;
goto v___jp_1947_;
}
else
{
lean_object* v_val_1977_; 
v_val_1977_ = lean_ctor_get(v___x_1974_, 0);
lean_inc(v_val_1977_);
lean_dec_ref_known(v___x_1974_, 1);
v___y_1948_ = v_val_1977_;
goto v___jp_1947_;
}
v___jp_1943_:
{
lean_object* v___x_1945_; 
v___x_1945_ = lean_array_push(v_a_1942_, v___y_1944_);
v_init_1922_ = v___x_1945_;
v_x_1923_ = v_r_1935_;
v___y_1925_ = v_snd_1941_;
goto _start;
}
v___jp_1947_:
{
if (lean_obj_tag(v___y_1948_) == 7)
{
lean_object* v_val_1949_; uint8_t v_isUnsafe_1950_; 
v_val_1949_ = lean_ctor_get(v___y_1948_, 0);
lean_inc_ref(v_val_1949_);
lean_dec_ref_known(v___y_1948_, 1);
v_isUnsafe_1950_ = lean_ctor_get_uint8(v_val_1949_, sizeof(void*)*7 + 1);
if (v_isUnsafe_1950_ == 0)
{
v___y_1944_ = v_val_1949_;
goto v___jp_1943_;
}
else
{
if (v___x_1921_ == 0)
{
uint8_t v_exportUnsafe_1951_; 
v_exportUnsafe_1951_ = lean_ctor_get_uint8(v_snd_1941_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_1951_ == 0)
{
lean_object* v___x_1952_; lean_object* v___x_1953_; 
lean_dec_ref(v_val_1949_);
lean_dec(v_a_1942_);
v___x_1952_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__2, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__2_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__2);
v___x_1953_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__3(v___x_1952_, v___y_1924_, v_snd_1941_);
if (lean_obj_tag(v___x_1953_) == 0)
{
lean_object* v_a_1954_; lean_object* v_fst_1955_; 
v_a_1954_ = lean_ctor_get(v___x_1953_, 0);
lean_inc(v_a_1954_);
lean_dec_ref_known(v___x_1953_, 1);
v_fst_1955_ = lean_ctor_get(v_a_1954_, 0);
lean_inc(v_fst_1955_);
if (lean_obj_tag(v_fst_1955_) == 0)
{
lean_object* v_snd_1956_; lean_object* v_a_1957_; 
lean_dec(v_r_1935_);
v_snd_1956_ = lean_ctor_get(v_a_1954_, 1);
lean_inc(v_snd_1956_);
lean_dec(v_a_1954_);
v_a_1957_ = lean_ctor_get(v_fst_1955_, 0);
lean_inc(v_a_1957_);
lean_dec_ref_known(v_fst_1955_, 1);
v_d_1928_ = v_a_1957_;
v___y_1929_ = v_snd_1956_;
goto v___jp_1927_;
}
else
{
lean_object* v_snd_1958_; lean_object* v_a_1959_; 
v_snd_1958_ = lean_ctor_get(v_a_1954_, 1);
lean_inc(v_snd_1958_);
lean_dec(v_a_1954_);
v_a_1959_ = lean_ctor_get(v_fst_1955_, 0);
lean_inc(v_a_1959_);
lean_dec_ref_known(v_fst_1955_, 1);
v_init_1922_ = v_a_1959_;
v_x_1923_ = v_r_1935_;
v___y_1925_ = v_snd_1958_;
goto _start;
}
}
else
{
lean_dec(v_r_1935_);
return v___x_1953_;
}
}
else
{
v___y_1944_ = v_val_1949_;
goto v___jp_1943_;
}
}
else
{
v___y_1944_ = v_val_1949_;
goto v___jp_1943_;
}
}
}
else
{
lean_object* v___x_1961_; lean_object* v___x_1962_; 
lean_dec_ref(v___y_1948_);
v___x_1961_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__4, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__4_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__4);
v___x_1962_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__4(v___x_1961_, v___y_1924_, v_snd_1941_);
if (lean_obj_tag(v___x_1962_) == 0)
{
lean_object* v_a_1963_; lean_object* v_snd_1964_; 
v_a_1963_ = lean_ctor_get(v___x_1962_, 0);
lean_inc(v_a_1963_);
lean_dec_ref_known(v___x_1962_, 1);
v_snd_1964_ = lean_ctor_get(v_a_1963_, 1);
lean_inc(v_snd_1964_);
lean_dec(v_a_1963_);
v_init_1922_ = v_a_1942_;
v_x_1923_ = v_r_1935_;
v___y_1925_ = v_snd_1964_;
goto _start;
}
else
{
lean_object* v_a_1966_; lean_object* v___x_1968_; uint8_t v_isShared_1969_; uint8_t v_isSharedCheck_1973_; 
lean_dec(v_a_1942_);
lean_dec(v_r_1935_);
v_a_1966_ = lean_ctor_get(v___x_1962_, 0);
v_isSharedCheck_1973_ = !lean_is_exclusive(v___x_1962_);
if (v_isSharedCheck_1973_ == 0)
{
v___x_1968_ = v___x_1962_;
v_isShared_1969_ = v_isSharedCheck_1973_;
goto v_resetjp_1967_;
}
else
{
lean_inc(v_a_1966_);
lean_dec(v___x_1962_);
v___x_1968_ = lean_box(0);
v_isShared_1969_ = v_isSharedCheck_1973_;
goto v_resetjp_1967_;
}
v_resetjp_1967_:
{
lean_object* v___x_1971_; 
if (v_isShared_1969_ == 0)
{
v___x_1971_ = v___x_1968_;
goto v_reusejp_1970_;
}
else
{
lean_object* v_reuseFailAlloc_1972_; 
v_reuseFailAlloc_1972_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1972_, 0, v_a_1966_);
v___x_1971_ = v_reuseFailAlloc_1972_;
goto v_reusejp_1970_;
}
v_reusejp_1970_:
{
return v___x_1971_;
}
}
}
}
}
}
}
else
{
lean_dec(v_r_1935_);
lean_dec(v_k_1933_);
return v___x_1936_;
}
}
else
{
lean_object* v___x_1978_; lean_object* v___x_1979_; lean_object* v___x_1980_; 
v___x_1978_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1978_, 0, v_init_1922_);
v___x_1979_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1979_, 0, v___x_1978_);
lean_ctor_set(v___x_1979_, 1, v___y_1925_);
v___x_1980_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1980_, 0, v___x_1979_);
return v___x_1980_;
}
v___jp_1927_:
{
lean_object* v___x_1930_; lean_object* v___x_1931_; lean_object* v___x_1932_; 
v___x_1930_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1930_, 0, v_d_1928_);
v___x_1931_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1931_, 0, v___x_1930_);
lean_ctor_set(v___x_1931_, 1, v___y_1929_);
v___x_1932_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1932_, 0, v___x_1931_);
return v___x_1932_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___boxed(lean_object* v___x_1981_, lean_object* v_init_1982_, lean_object* v_x_1983_, lean_object* v___y_1984_, lean_object* v___y_1985_, lean_object* v___y_1986_){
_start:
{
uint8_t v___x_182391__boxed_1987_; lean_object* v_res_1988_; 
v___x_182391__boxed_1987_ = lean_unbox(v___x_1981_);
v_res_1988_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12(v___x_182391__boxed_1987_, v_init_1982_, v_x_1983_, v___y_1984_, v___y_1985_);
lean_dec_ref(v___y_1984_);
return v_res_1988_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00dumpConstant_spec__6___closed__0(void){
_start:
{
lean_object* v___x_1989_; 
v___x_1989_ = l_Array_instInhabited(lean_box(0));
return v___x_1989_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__6(lean_object* v_msg_1990_, lean_object* v___y_1991_, lean_object* v___y_1992_){
_start:
{
lean_object* v___x_1994_; lean_object* v___f_1995_; lean_object* v___f_1996_; lean_object* v___f_1997_; lean_object* v___f_1998_; lean_object* v___x_1999_; lean_object* v___x_2000_; lean_object* v___x_2001_; lean_object* v___x_2002_; lean_object* v___x_2003_; lean_object* v___x_2004_; lean_object* v___x_2005_; lean_object* v___x_2006_; lean_object* v___x_2007_; lean_object* v___f_2008_; lean_object* v___x_173937__overap_2009_; lean_object* v___x_2010_; 
v___x_1994_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0);
v___f_1995_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_1995_, 0, v___x_1994_);
v___f_1996_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_1996_, 0, v___x_1994_);
v___f_1997_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_1997_, 0, v___x_1994_);
v___f_1998_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_1998_, 0, v___x_1994_);
v___x_1999_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_1999_, 0, lean_box(0));
lean_closure_set(v___x_1999_, 1, lean_box(0));
lean_closure_set(v___x_1999_, 2, v___x_1994_);
v___x_2000_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2000_, 0, v___x_1999_);
lean_ctor_set(v___x_2000_, 1, v___f_1995_);
v___x_2001_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_2001_, 0, lean_box(0));
lean_closure_set(v___x_2001_, 1, lean_box(0));
lean_closure_set(v___x_2001_, 2, v___x_1994_);
v___x_2002_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_2002_, 0, v___x_2000_);
lean_ctor_set(v___x_2002_, 1, v___x_2001_);
lean_ctor_set(v___x_2002_, 2, v___f_1996_);
lean_ctor_set(v___x_2002_, 3, v___f_1997_);
lean_ctor_set(v___x_2002_, 4, v___f_1998_);
v___x_2003_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_2003_, 0, lean_box(0));
lean_closure_set(v___x_2003_, 1, lean_box(0));
lean_closure_set(v___x_2003_, 2, v___x_1994_);
v___x_2004_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2004_, 0, v___x_2002_);
lean_ctor_set(v___x_2004_, 1, v___x_2003_);
v___x_2005_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpConstant_spec__6___closed__0, &lp_proofEnvironment_panic___at___00dumpConstant_spec__6___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpConstant_spec__6___closed__0);
v___x_2006_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2006_, 0, v___x_2005_);
v___x_2007_ = l_instInhabitedOfMonad___redArg(v___x_2004_, v___x_2006_);
v___f_2008_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_2008_, 0, v___x_2007_);
v___x_173937__overap_2009_ = lean_panic_fn_borrowed(v___f_2008_, v_msg_1990_);
lean_dec_ref(v___f_2008_);
lean_inc_ref(v___y_1991_);
v___x_2010_ = lean_apply_3(v___x_173937__overap_2009_, v___y_1991_, v___y_1992_, lean_box(0));
return v___x_2010_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__6___boxed(lean_object* v_msg_2011_, lean_object* v___y_2012_, lean_object* v___y_2013_, lean_object* v___y_2014_){
_start:
{
lean_object* v_res_2015_; 
v_res_2015_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__6(v_msg_2011_, v___y_2012_, v___y_2013_);
lean_dec_ref(v___y_2012_);
return v_res_2015_;
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__1(void){
_start:
{
lean_object* v___x_2017_; lean_object* v___x_2018_; lean_object* v___x_2019_; lean_object* v___x_2020_; lean_object* v___x_2021_; lean_object* v___x_2022_; 
v___x_2017_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__0));
v___x_2018_ = lean_unsigned_to_nat(10u);
v___x_2019_ = lean_unsigned_to_nat(317u);
v___x_2020_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_2021_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_2022_ = l_mkPanicMessageWithDecl(v___x_2021_, v___x_2020_, v___x_2019_, v___x_2018_, v___x_2017_);
return v___x_2022_;
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__3(void){
_start:
{
lean_object* v___x_2024_; lean_object* v___x_2025_; lean_object* v___x_2026_; lean_object* v___x_2027_; lean_object* v___x_2028_; lean_object* v___x_2029_; 
v___x_2024_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__2));
v___x_2025_ = lean_unsigned_to_nat(15u);
v___x_2026_ = lean_unsigned_to_nat(319u);
v___x_2027_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_2028_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_2029_ = l_mkPanicMessageWithDecl(v___x_2028_, v___x_2027_, v___x_2026_, v___x_2025_, v___x_2024_);
return v___x_2029_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg(uint8_t v___y_2030_, uint8_t v___x_2031_, lean_object* v_as_x27_2032_, lean_object* v_b_2033_, lean_object* v___y_2034_, lean_object* v___y_2035_){
_start:
{
if (lean_obj_tag(v_as_x27_2032_) == 0)
{
lean_object* v___x_2037_; lean_object* v___x_2038_; 
v___x_2037_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2037_, 0, v_b_2033_);
lean_ctor_set(v___x_2037_, 1, v___y_2035_);
v___x_2038_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2038_, 0, v___x_2037_);
return v___x_2038_;
}
else
{
lean_object* v_head_2039_; lean_object* v_tail_2040_; lean_object* v___y_2042_; lean_object* v___y_2046_; uint8_t v___y_2047_; lean_object* v___y_2082_; lean_object* v___x_2098_; 
v_head_2039_ = lean_ctor_get(v_as_x27_2032_, 0);
v_tail_2040_ = lean_ctor_get(v_as_x27_2032_, 1);
lean_inc(v_head_2039_);
lean_inc_ref(v___y_2034_);
v___x_2098_ = l_Lean_Environment_find_x3f(v___y_2034_, v_head_2039_, v___x_2031_);
if (lean_obj_tag(v___x_2098_) == 0)
{
lean_object* v___x_2099_; lean_object* v___x_2100_; 
v___x_2099_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8);
v___x_2100_ = l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(v___x_2099_);
v___y_2082_ = v___x_2100_;
goto v___jp_2081_;
}
else
{
lean_object* v_val_2101_; 
v_val_2101_ = lean_ctor_get(v___x_2098_, 0);
lean_inc(v_val_2101_);
lean_dec_ref_known(v___x_2098_, 1);
v___y_2082_ = v_val_2101_;
goto v___jp_2081_;
}
v___jp_2041_:
{
lean_object* v___x_2043_; 
v___x_2043_ = lean_array_push(v_b_2033_, v___y_2042_);
v_as_x27_2032_ = v_tail_2040_;
v_b_2033_ = v___x_2043_;
goto _start;
}
v___jp_2045_:
{
if (v___y_2047_ == 0)
{
uint8_t v_exportUnsafe_2048_; 
v_exportUnsafe_2048_ = lean_ctor_get_uint8(v___y_2035_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_2048_ == 0)
{
lean_object* v___x_2049_; lean_object* v___x_2050_; 
lean_dec_ref(v___y_2046_);
lean_dec_ref(v_b_2033_);
v___x_2049_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__1, &lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__1_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__1);
v___x_2050_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__6(v___x_2049_, v___y_2034_, v___y_2035_);
if (lean_obj_tag(v___x_2050_) == 0)
{
lean_object* v_a_2051_; lean_object* v___x_2053_; uint8_t v_isShared_2054_; uint8_t v_isSharedCheck_2072_; 
v_a_2051_ = lean_ctor_get(v___x_2050_, 0);
v_isSharedCheck_2072_ = !lean_is_exclusive(v___x_2050_);
if (v_isSharedCheck_2072_ == 0)
{
v___x_2053_ = v___x_2050_;
v_isShared_2054_ = v_isSharedCheck_2072_;
goto v_resetjp_2052_;
}
else
{
lean_inc(v_a_2051_);
lean_dec(v___x_2050_);
v___x_2053_ = lean_box(0);
v_isShared_2054_ = v_isSharedCheck_2072_;
goto v_resetjp_2052_;
}
v_resetjp_2052_:
{
lean_object* v_fst_2055_; 
v_fst_2055_ = lean_ctor_get(v_a_2051_, 0);
lean_inc(v_fst_2055_);
if (lean_obj_tag(v_fst_2055_) == 0)
{
lean_object* v_snd_2056_; lean_object* v___x_2058_; uint8_t v_isShared_2059_; uint8_t v_isSharedCheck_2067_; 
v_snd_2056_ = lean_ctor_get(v_a_2051_, 1);
v_isSharedCheck_2067_ = !lean_is_exclusive(v_a_2051_);
if (v_isSharedCheck_2067_ == 0)
{
lean_object* v_unused_2068_; 
v_unused_2068_ = lean_ctor_get(v_a_2051_, 0);
lean_dec(v_unused_2068_);
v___x_2058_ = v_a_2051_;
v_isShared_2059_ = v_isSharedCheck_2067_;
goto v_resetjp_2057_;
}
else
{
lean_inc(v_snd_2056_);
lean_dec(v_a_2051_);
v___x_2058_ = lean_box(0);
v_isShared_2059_ = v_isSharedCheck_2067_;
goto v_resetjp_2057_;
}
v_resetjp_2057_:
{
lean_object* v_a_2060_; lean_object* v___x_2062_; 
v_a_2060_ = lean_ctor_get(v_fst_2055_, 0);
lean_inc(v_a_2060_);
lean_dec_ref_known(v_fst_2055_, 1);
if (v_isShared_2059_ == 0)
{
lean_ctor_set(v___x_2058_, 0, v_a_2060_);
v___x_2062_ = v___x_2058_;
goto v_reusejp_2061_;
}
else
{
lean_object* v_reuseFailAlloc_2066_; 
v_reuseFailAlloc_2066_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2066_, 0, v_a_2060_);
lean_ctor_set(v_reuseFailAlloc_2066_, 1, v_snd_2056_);
v___x_2062_ = v_reuseFailAlloc_2066_;
goto v_reusejp_2061_;
}
v_reusejp_2061_:
{
lean_object* v___x_2064_; 
if (v_isShared_2054_ == 0)
{
lean_ctor_set(v___x_2053_, 0, v___x_2062_);
v___x_2064_ = v___x_2053_;
goto v_reusejp_2063_;
}
else
{
lean_object* v_reuseFailAlloc_2065_; 
v_reuseFailAlloc_2065_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2065_, 0, v___x_2062_);
v___x_2064_ = v_reuseFailAlloc_2065_;
goto v_reusejp_2063_;
}
v_reusejp_2063_:
{
return v___x_2064_;
}
}
}
}
else
{
lean_object* v_snd_2069_; lean_object* v_a_2070_; 
lean_del_object(v___x_2053_);
v_snd_2069_ = lean_ctor_get(v_a_2051_, 1);
lean_inc(v_snd_2069_);
lean_dec(v_a_2051_);
v_a_2070_ = lean_ctor_get(v_fst_2055_, 0);
lean_inc(v_a_2070_);
lean_dec_ref_known(v_fst_2055_, 1);
v_as_x27_2032_ = v_tail_2040_;
v_b_2033_ = v_a_2070_;
v___y_2035_ = v_snd_2069_;
goto _start;
}
}
}
else
{
lean_object* v_a_2073_; lean_object* v___x_2075_; uint8_t v_isShared_2076_; uint8_t v_isSharedCheck_2080_; 
v_a_2073_ = lean_ctor_get(v___x_2050_, 0);
v_isSharedCheck_2080_ = !lean_is_exclusive(v___x_2050_);
if (v_isSharedCheck_2080_ == 0)
{
v___x_2075_ = v___x_2050_;
v_isShared_2076_ = v_isSharedCheck_2080_;
goto v_resetjp_2074_;
}
else
{
lean_inc(v_a_2073_);
lean_dec(v___x_2050_);
v___x_2075_ = lean_box(0);
v_isShared_2076_ = v_isSharedCheck_2080_;
goto v_resetjp_2074_;
}
v_resetjp_2074_:
{
lean_object* v___x_2078_; 
if (v_isShared_2076_ == 0)
{
v___x_2078_ = v___x_2075_;
goto v_reusejp_2077_;
}
else
{
lean_object* v_reuseFailAlloc_2079_; 
v_reuseFailAlloc_2079_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2079_, 0, v_a_2073_);
v___x_2078_ = v_reuseFailAlloc_2079_;
goto v_reusejp_2077_;
}
v_reusejp_2077_:
{
return v___x_2078_;
}
}
}
}
else
{
v___y_2042_ = v___y_2046_;
goto v___jp_2041_;
}
}
else
{
v___y_2042_ = v___y_2046_;
goto v___jp_2041_;
}
}
v___jp_2081_:
{
if (lean_obj_tag(v___y_2082_) == 6)
{
lean_object* v_val_2083_; uint8_t v_isUnsafe_2084_; 
v_val_2083_ = lean_ctor_get(v___y_2082_, 0);
lean_inc_ref(v_val_2083_);
lean_dec_ref_known(v___y_2082_, 1);
v_isUnsafe_2084_ = lean_ctor_get_uint8(v_val_2083_, sizeof(void*)*5);
if (v_isUnsafe_2084_ == 0)
{
v___y_2046_ = v_val_2083_;
v___y_2047_ = v___y_2030_;
goto v___jp_2045_;
}
else
{
v___y_2046_ = v_val_2083_;
v___y_2047_ = v___x_2031_;
goto v___jp_2045_;
}
}
else
{
lean_object* v___x_2085_; lean_object* v___x_2086_; 
lean_dec_ref(v___y_2082_);
v___x_2085_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__3, &lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__3_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___closed__3);
v___x_2086_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__4(v___x_2085_, v___y_2034_, v___y_2035_);
if (lean_obj_tag(v___x_2086_) == 0)
{
lean_object* v_a_2087_; lean_object* v_snd_2088_; 
v_a_2087_ = lean_ctor_get(v___x_2086_, 0);
lean_inc(v_a_2087_);
lean_dec_ref_known(v___x_2086_, 1);
v_snd_2088_ = lean_ctor_get(v_a_2087_, 1);
lean_inc(v_snd_2088_);
lean_dec(v_a_2087_);
v_as_x27_2032_ = v_tail_2040_;
v___y_2035_ = v_snd_2088_;
goto _start;
}
else
{
lean_object* v_a_2090_; lean_object* v___x_2092_; uint8_t v_isShared_2093_; uint8_t v_isSharedCheck_2097_; 
lean_dec_ref(v_b_2033_);
v_a_2090_ = lean_ctor_get(v___x_2086_, 0);
v_isSharedCheck_2097_ = !lean_is_exclusive(v___x_2086_);
if (v_isSharedCheck_2097_ == 0)
{
v___x_2092_ = v___x_2086_;
v_isShared_2093_ = v_isSharedCheck_2097_;
goto v_resetjp_2091_;
}
else
{
lean_inc(v_a_2090_);
lean_dec(v___x_2086_);
v___x_2092_ = lean_box(0);
v_isShared_2093_ = v_isSharedCheck_2097_;
goto v_resetjp_2091_;
}
v_resetjp_2091_:
{
lean_object* v___x_2095_; 
if (v_isShared_2093_ == 0)
{
v___x_2095_ = v___x_2092_;
goto v_reusejp_2094_;
}
else
{
lean_object* v_reuseFailAlloc_2096_; 
v_reuseFailAlloc_2096_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2096_, 0, v_a_2090_);
v___x_2095_ = v_reuseFailAlloc_2096_;
goto v_reusejp_2094_;
}
v_reusejp_2094_:
{
return v___x_2095_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg___boxed(lean_object* v___y_2102_, lean_object* v___x_2103_, lean_object* v_as_x27_2104_, lean_object* v_b_2105_, lean_object* v___y_2106_, lean_object* v___y_2107_, lean_object* v___y_2108_){
_start:
{
uint8_t v___y_182623__boxed_2109_; uint8_t v___x_182624__boxed_2110_; lean_object* v_res_2111_; 
v___y_182623__boxed_2109_ = lean_unbox(v___y_2102_);
v___x_182624__boxed_2110_ = lean_unbox(v___x_2103_);
v_res_2111_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg(v___y_182623__boxed_2109_, v___x_182624__boxed_2110_, v_as_x27_2104_, v_b_2105_, v___y_2106_, v___y_2107_);
lean_dec_ref(v___y_2106_);
lean_dec(v_as_x27_2104_);
return v_res_2111_;
}
}
static lean_object* _init_lp_proofEnvironment_panic___at___00dumpConstant_spec__8___closed__0(void){
_start:
{
lean_object* v___x_2112_; 
v___x_2112_ = l_Array_instInhabited(lean_box(0));
return v___x_2112_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__8(lean_object* v_msg_2113_, lean_object* v___y_2114_, lean_object* v___y_2115_){
_start:
{
lean_object* v___x_2117_; lean_object* v___f_2118_; lean_object* v___f_2119_; lean_object* v___f_2120_; lean_object* v___f_2121_; lean_object* v___x_2122_; lean_object* v___x_2123_; lean_object* v___x_2124_; lean_object* v___x_2125_; lean_object* v___x_2126_; lean_object* v___x_2127_; lean_object* v___x_2128_; lean_object* v___x_2129_; lean_object* v___x_2130_; lean_object* v___x_2131_; lean_object* v___x_2132_; lean_object* v___x_2133_; lean_object* v___f_2134_; lean_object* v___x_174601__overap_2135_; lean_object* v___x_2136_; 
v___x_2117_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0, &lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpName_spec__0___closed__0);
v___f_2118_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__1), 6, 1);
lean_closure_set(v___f_2118_, 0, v___x_2117_);
v___f_2119_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__4), 6, 1);
lean_closure_set(v___f_2119_, 0, v___x_2117_);
v___f_2120_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__7), 6, 1);
lean_closure_set(v___f_2120_, 0, v___x_2117_);
v___f_2121_ = lean_alloc_closure((void*)(l_StateT_instMonad___redArg___lam__9), 6, 1);
lean_closure_set(v___f_2121_, 0, v___x_2117_);
v___x_2122_ = lean_alloc_closure((void*)(l_StateT_map), 8, 3);
lean_closure_set(v___x_2122_, 0, lean_box(0));
lean_closure_set(v___x_2122_, 1, lean_box(0));
lean_closure_set(v___x_2122_, 2, v___x_2117_);
v___x_2123_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2123_, 0, v___x_2122_);
lean_ctor_set(v___x_2123_, 1, v___f_2118_);
v___x_2124_ = lean_alloc_closure((void*)(l_StateT_pure), 6, 3);
lean_closure_set(v___x_2124_, 0, lean_box(0));
lean_closure_set(v___x_2124_, 1, lean_box(0));
lean_closure_set(v___x_2124_, 2, v___x_2117_);
v___x_2125_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_2125_, 0, v___x_2123_);
lean_ctor_set(v___x_2125_, 1, v___x_2124_);
lean_ctor_set(v___x_2125_, 2, v___f_2119_);
lean_ctor_set(v___x_2125_, 3, v___f_2120_);
lean_ctor_set(v___x_2125_, 4, v___f_2121_);
v___x_2126_ = lean_alloc_closure((void*)(l_StateT_bind), 8, 3);
lean_closure_set(v___x_2126_, 0, lean_box(0));
lean_closure_set(v___x_2126_, 1, lean_box(0));
lean_closure_set(v___x_2126_, 2, v___x_2117_);
v___x_2127_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2127_, 0, v___x_2125_);
lean_ctor_set(v___x_2127_, 1, v___x_2126_);
v___x_2128_ = lean_obj_once(&lp_proofEnvironment_panic___at___00dumpConstant_spec__8___closed__0, &lp_proofEnvironment_panic___at___00dumpConstant_spec__8___closed__0_once, _init_lp_proofEnvironment_panic___at___00dumpConstant_spec__8___closed__0);
v___x_2129_ = lean_box(1);
v___x_2130_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2130_, 0, v___x_2128_);
lean_ctor_set(v___x_2130_, 1, v___x_2129_);
v___x_2131_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2131_, 0, v___x_2128_);
lean_ctor_set(v___x_2131_, 1, v___x_2130_);
v___x_2132_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2132_, 0, v___x_2131_);
v___x_2133_ = l_instInhabitedOfMonad___redArg(v___x_2127_, v___x_2132_);
v___f_2134_ = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_2134_, 0, v___x_2133_);
v___x_174601__overap_2135_ = lean_panic_fn_borrowed(v___f_2134_, v_msg_2113_);
lean_dec_ref(v___f_2134_);
lean_inc_ref(v___y_2114_);
v___x_2136_ = lean_apply_3(v___x_174601__overap_2135_, v___y_2114_, v___y_2115_, lean_box(0));
return v___x_2136_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_panic___at___00dumpConstant_spec__8___boxed(lean_object* v_msg_2137_, lean_object* v___y_2138_, lean_object* v___y_2139_, lean_object* v___y_2140_){
_start:
{
lean_object* v_res_2141_; 
v_res_2141_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__8(v_msg_2137_, v___y_2138_, v___y_2139_);
lean_dec_ref(v___y_2138_);
return v_res_2141_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__13(lean_object* v_as_2142_, size_t v_sz_2143_, size_t v_i_2144_, lean_object* v_b_2145_, lean_object* v___y_2146_, lean_object* v___y_2147_){
_start:
{
uint8_t v___x_2149_; 
v___x_2149_ = lean_usize_dec_lt(v_i_2144_, v_sz_2143_);
if (v___x_2149_ == 0)
{
lean_object* v___x_2150_; lean_object* v___x_2151_; 
v___x_2150_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2150_, 0, v_b_2145_);
lean_ctor_set(v___x_2150_, 1, v___y_2147_);
v___x_2151_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2151_, 0, v___x_2150_);
return v___x_2151_;
}
else
{
lean_object* v_visitedNames_2152_; lean_object* v_visitedLevels_2153_; lean_object* v_visitedExprs_2154_; lean_object* v_visitedConstants_2155_; lean_object* v_noMDataExprs_2156_; uint8_t v_exportMData_2157_; uint8_t v_exportUnsafe_2158_; uint8_t v_ignoreMissing_2159_; lean_object* v_recursorMap_2160_; lean_object* v___x_2162_; uint8_t v_isShared_2163_; uint8_t v_isSharedCheck_2179_; 
v_visitedNames_2152_ = lean_ctor_get(v___y_2147_, 0);
v_visitedLevels_2153_ = lean_ctor_get(v___y_2147_, 1);
v_visitedExprs_2154_ = lean_ctor_get(v___y_2147_, 2);
v_visitedConstants_2155_ = lean_ctor_get(v___y_2147_, 3);
v_noMDataExprs_2156_ = lean_ctor_get(v___y_2147_, 4);
v_exportMData_2157_ = lean_ctor_get_uint8(v___y_2147_, sizeof(void*)*6);
v_exportUnsafe_2158_ = lean_ctor_get_uint8(v___y_2147_, sizeof(void*)*6 + 1);
v_ignoreMissing_2159_ = lean_ctor_get_uint8(v___y_2147_, sizeof(void*)*6 + 2);
v_recursorMap_2160_ = lean_ctor_get(v___y_2147_, 5);
v_isSharedCheck_2179_ = !lean_is_exclusive(v___y_2147_);
if (v_isSharedCheck_2179_ == 0)
{
v___x_2162_ = v___y_2147_;
v_isShared_2163_ = v_isSharedCheck_2179_;
goto v_resetjp_2161_;
}
else
{
lean_inc(v_recursorMap_2160_);
lean_inc(v_noMDataExprs_2156_);
lean_inc(v_visitedConstants_2155_);
lean_inc(v_visitedExprs_2154_);
lean_inc(v_visitedLevels_2153_);
lean_inc(v_visitedNames_2152_);
lean_dec(v___y_2147_);
v___x_2162_ = lean_box(0);
v_isShared_2163_ = v_isSharedCheck_2179_;
goto v_resetjp_2161_;
}
v_resetjp_2161_:
{
lean_object* v_a_2164_; lean_object* v_toConstantVal_2165_; lean_object* v_name_2166_; lean_object* v_type_2167_; lean_object* v___x_2168_; lean_object* v___x_2170_; 
v_a_2164_ = lean_array_uget_borrowed(v_as_2142_, v_i_2144_);
v_toConstantVal_2165_ = lean_ctor_get(v_a_2164_, 0);
v_name_2166_ = lean_ctor_get(v_toConstantVal_2165_, 0);
v_type_2167_ = lean_ctor_get(v_toConstantVal_2165_, 2);
lean_inc(v_name_2166_);
v___x_2168_ = l_Lean_NameHashSet_insert(v_visitedConstants_2155_, v_name_2166_);
if (v_isShared_2163_ == 0)
{
lean_ctor_set(v___x_2162_, 3, v___x_2168_);
v___x_2170_ = v___x_2162_;
goto v_reusejp_2169_;
}
else
{
lean_object* v_reuseFailAlloc_2178_; 
v_reuseFailAlloc_2178_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_2178_, 0, v_visitedNames_2152_);
lean_ctor_set(v_reuseFailAlloc_2178_, 1, v_visitedLevels_2153_);
lean_ctor_set(v_reuseFailAlloc_2178_, 2, v_visitedExprs_2154_);
lean_ctor_set(v_reuseFailAlloc_2178_, 3, v___x_2168_);
lean_ctor_set(v_reuseFailAlloc_2178_, 4, v_noMDataExprs_2156_);
lean_ctor_set(v_reuseFailAlloc_2178_, 5, v_recursorMap_2160_);
lean_ctor_set_uint8(v_reuseFailAlloc_2178_, sizeof(void*)*6, v_exportMData_2157_);
lean_ctor_set_uint8(v_reuseFailAlloc_2178_, sizeof(void*)*6 + 1, v_exportUnsafe_2158_);
lean_ctor_set_uint8(v_reuseFailAlloc_2178_, sizeof(void*)*6 + 2, v_ignoreMissing_2159_);
v___x_2170_ = v_reuseFailAlloc_2178_;
goto v_reusejp_2169_;
}
v_reusejp_2169_:
{
lean_object* v___x_2171_; 
lean_inc_ref(v_type_2167_);
v___x_2171_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_2167_, v___y_2146_, v___x_2170_);
if (lean_obj_tag(v___x_2171_) == 0)
{
lean_object* v_a_2172_; lean_object* v_snd_2173_; lean_object* v___x_2174_; size_t v___x_2175_; size_t v___x_2176_; 
v_a_2172_ = lean_ctor_get(v___x_2171_, 0);
lean_inc(v_a_2172_);
lean_dec_ref_known(v___x_2171_, 1);
v_snd_2173_ = lean_ctor_get(v_a_2172_, 1);
lean_inc(v_snd_2173_);
lean_dec(v_a_2172_);
v___x_2174_ = lean_box(0);
v___x_2175_ = ((size_t)1ULL);
v___x_2176_ = lean_usize_add(v_i_2144_, v___x_2175_);
v_i_2144_ = v___x_2176_;
v_b_2145_ = v___x_2174_;
v___y_2147_ = v_snd_2173_;
goto _start;
}
else
{
return v___x_2171_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg(lean_object* v_as_x27_2180_, lean_object* v_b_2181_, lean_object* v___y_2182_, lean_object* v___y_2183_){
_start:
{
if (lean_obj_tag(v_as_x27_2180_) == 0)
{
lean_object* v___x_2185_; lean_object* v___x_2186_; 
v___x_2185_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2185_, 0, v_b_2181_);
lean_ctor_set(v___x_2185_, 1, v___y_2183_);
v___x_2186_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2186_, 0, v___x_2185_);
return v___x_2186_;
}
else
{
lean_object* v_head_2187_; lean_object* v_tail_2188_; lean_object* v_rhs_2189_; lean_object* v___x_2190_; 
v_head_2187_ = lean_ctor_get(v_as_x27_2180_, 0);
v_tail_2188_ = lean_ctor_get(v_as_x27_2180_, 1);
v_rhs_2189_ = lean_ctor_get(v_head_2187_, 2);
lean_inc_ref(v_rhs_2189_);
v___x_2190_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_rhs_2189_, v___y_2182_, v___y_2183_);
if (lean_obj_tag(v___x_2190_) == 0)
{
lean_object* v_a_2191_; lean_object* v_snd_2192_; lean_object* v___x_2193_; 
v_a_2191_ = lean_ctor_get(v___x_2190_, 0);
lean_inc(v_a_2191_);
lean_dec_ref_known(v___x_2190_, 1);
v_snd_2192_ = lean_ctor_get(v_a_2191_, 1);
lean_inc(v_snd_2192_);
lean_dec(v_a_2191_);
v___x_2193_ = lean_box(0);
v_as_x27_2180_ = v_tail_2188_;
v_b_2181_ = v___x_2193_;
v___y_2183_ = v_snd_2192_;
goto _start;
}
else
{
return v___x_2190_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__14(lean_object* v_as_2195_, size_t v_sz_2196_, size_t v_i_2197_, lean_object* v_b_2198_, lean_object* v___y_2199_, lean_object* v___y_2200_){
_start:
{
uint8_t v___x_2202_; 
v___x_2202_ = lean_usize_dec_lt(v_i_2197_, v_sz_2196_);
if (v___x_2202_ == 0)
{
lean_object* v___x_2203_; lean_object* v___x_2204_; 
v___x_2203_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2203_, 0, v_b_2198_);
lean_ctor_set(v___x_2203_, 1, v___y_2200_);
v___x_2204_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2204_, 0, v___x_2203_);
return v___x_2204_;
}
else
{
lean_object* v_a_2205_; lean_object* v_rules_2206_; lean_object* v___x_2207_; lean_object* v___x_2208_; 
v_a_2205_ = lean_array_uget_borrowed(v_as_2195_, v_i_2197_);
v_rules_2206_ = lean_ctor_get(v_a_2205_, 6);
v___x_2207_ = lean_box(0);
v___x_2208_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg(v_rules_2206_, v___x_2207_, v___y_2199_, v___y_2200_);
if (lean_obj_tag(v___x_2208_) == 0)
{
lean_object* v_a_2209_; lean_object* v_snd_2210_; size_t v___x_2211_; size_t v___x_2212_; 
v_a_2209_ = lean_ctor_get(v___x_2208_, 0);
lean_inc(v_a_2209_);
lean_dec_ref_known(v___x_2208_, 1);
v_snd_2210_ = lean_ctor_get(v_a_2209_, 1);
lean_inc(v_snd_2210_);
lean_dec(v_a_2209_);
v___x_2211_ = ((size_t)1ULL);
v___x_2212_ = lean_usize_add(v_i_2197_, v___x_2211_);
v_i_2197_ = v___x_2212_;
v_b_2198_ = v___x_2207_;
v___y_2200_ = v_snd_2210_;
goto _start;
}
else
{
return v___x_2208_;
}
}
}
}
static lean_object* _init_lp_proofEnvironment_dumpExpr___closed__0(void){
_start:
{
lean_object* v___x_2214_; lean_object* v___x_2215_; lean_object* v___x_2216_; 
v___x_2214_ = lean_box(0);
v___x_2215_ = lean_unsigned_to_nat(16u);
v___x_2216_ = lean_mk_array(v___x_2215_, v___x_2214_);
return v___x_2216_;
}
}
static lean_object* _init_lp_proofEnvironment_dumpExpr___closed__1(void){
_start:
{
lean_object* v___x_2217_; lean_object* v___x_2218_; lean_object* v___x_2219_; 
v___x_2217_ = lean_obj_once(&lp_proofEnvironment_dumpExpr___closed__0, &lp_proofEnvironment_dumpExpr___closed__0_once, _init_lp_proofEnvironment_dumpExpr___closed__0);
v___x_2218_ = lean_unsigned_to_nat(0u);
v___x_2219_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2219_, 0, v___x_2218_);
lean_ctor_set(v___x_2219_, 1, v___x_2217_);
return v___x_2219_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpNatDeps(lean_object* v_a_2239_, lean_object* v_a_2240_){
_start:
{
lean_object* v_visitedConstants_2246_; lean_object* v_nat_2247_; uint8_t v___x_2248_; 
v_visitedConstants_2246_ = lean_ctor_get(v_a_2240_, 3);
v_nat_2247_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux_dumpNatDeps___closed__1));
v___x_2248_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_2246_, v_nat_2247_);
if (v___x_2248_ == 0)
{
lean_object* v___x_2249_; 
lean_inc_ref(v_a_2239_);
v___x_2249_ = l_Lean_Environment_find_x3f(v_a_2239_, v_nat_2247_, v___x_2248_);
if (lean_obj_tag(v___x_2249_) == 0)
{
goto v___jp_2242_;
}
else
{
lean_object* v___x_2250_; 
lean_dec_ref_known(v___x_2249_, 1);
v___x_2250_ = lp_proofEnvironment_dumpConstant(v_nat_2247_, v_a_2239_, v_a_2240_);
return v___x_2250_;
}
}
else
{
goto v___jp_2242_;
}
v___jp_2242_:
{
lean_object* v___x_2243_; lean_object* v___x_2244_; lean_object* v___x_2245_; 
v___x_2243_ = lean_box(0);
v___x_2244_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2244_, 0, v___x_2243_);
lean_ctor_set(v___x_2244_, 1, v_a_2240_);
v___x_2245_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2245_, 0, v___x_2244_);
return v___x_2245_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps(lean_object* v_a_2262_, lean_object* v_a_2263_){
_start:
{
lean_object* v___y_2266_; lean_object* v___y_2271_; lean_object* v___y_2272_; lean_object* v_visitedConstants_2273_; lean_object* v_visitedConstants_2278_; lean_object* v_charOfNat_2279_; uint8_t v___x_2280_; 
v_visitedConstants_2278_ = lean_ctor_get(v_a_2263_, 3);
v_charOfNat_2279_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__5));
v___x_2280_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_2278_, v_charOfNat_2279_);
if (v___x_2280_ == 0)
{
lean_object* v___x_2281_; 
lean_inc_ref(v_a_2262_);
v___x_2281_ = l_Lean_Environment_find_x3f(v_a_2262_, v_charOfNat_2279_, v___x_2280_);
if (lean_obj_tag(v___x_2281_) == 0)
{
lean_inc_ref(v_visitedConstants_2278_);
v___y_2271_ = v_a_2262_;
v___y_2272_ = v_a_2263_;
v_visitedConstants_2273_ = v_visitedConstants_2278_;
goto v___jp_2270_;
}
else
{
lean_object* v___x_2282_; 
lean_dec_ref_known(v___x_2281_, 1);
v___x_2282_ = lp_proofEnvironment_dumpConstant(v_charOfNat_2279_, v_a_2262_, v_a_2263_);
if (lean_obj_tag(v___x_2282_) == 0)
{
lean_object* v_a_2283_; lean_object* v_snd_2284_; lean_object* v_visitedConstants_2285_; 
v_a_2283_ = lean_ctor_get(v___x_2282_, 0);
lean_inc(v_a_2283_);
lean_dec_ref_known(v___x_2282_, 1);
v_snd_2284_ = lean_ctor_get(v_a_2283_, 1);
lean_inc(v_snd_2284_);
lean_dec(v_a_2283_);
v_visitedConstants_2285_ = lean_ctor_get(v_snd_2284_, 3);
lean_inc_ref(v_visitedConstants_2285_);
v___y_2271_ = v_a_2262_;
v___y_2272_ = v_snd_2284_;
v_visitedConstants_2273_ = v_visitedConstants_2285_;
goto v___jp_2270_;
}
else
{
return v___x_2282_;
}
}
}
else
{
lean_inc_ref(v_visitedConstants_2278_);
v___y_2271_ = v_a_2262_;
v___y_2272_ = v_a_2263_;
v_visitedConstants_2273_ = v_visitedConstants_2278_;
goto v___jp_2270_;
}
v___jp_2265_:
{
lean_object* v___x_2267_; lean_object* v___x_2268_; lean_object* v___x_2269_; 
v___x_2267_ = lean_box(0);
v___x_2268_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2268_, 0, v___x_2267_);
lean_ctor_set(v___x_2268_, 1, v___y_2266_);
v___x_2269_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2269_, 0, v___x_2268_);
return v___x_2269_;
}
v___jp_2270_:
{
lean_object* v___x_2274_; uint8_t v___x_2275_; 
v___x_2274_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux_dumpStrDeps___closed__2));
v___x_2275_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_2273_, v___x_2274_);
lean_dec_ref(v_visitedConstants_2273_);
if (v___x_2275_ == 0)
{
lean_object* v___x_2276_; 
lean_inc_ref(v___y_2271_);
v___x_2276_ = l_Lean_Environment_find_x3f(v___y_2271_, v___x_2274_, v___x_2275_);
if (lean_obj_tag(v___x_2276_) == 0)
{
v___y_2266_ = v___y_2272_;
goto v___jp_2265_;
}
else
{
lean_object* v___x_2277_; 
lean_dec_ref_known(v___x_2276_, 1);
v___x_2277_ = lp_proofEnvironment_dumpConstant(v___x_2274_, v___y_2271_, v___y_2272_);
return v___x_2277_;
}
}
else
{
v___y_2266_ = v___y_2272_;
goto v___jp_2265_;
}
}
}
}
static lean_object* _init_lp_proofEnvironment_dumpExprAux___closed__26(void){
_start:
{
lean_object* v___x_2296_; lean_object* v___x_2297_; lean_object* v___x_2298_; lean_object* v___x_2299_; lean_object* v___x_2300_; lean_object* v___x_2301_; 
v___x_2296_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__25));
v___x_2297_ = lean_unsigned_to_nat(29u);
v___x_2298_ = lean_unsigned_to_nat(160u);
v___x_2299_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__24));
v___x_2300_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_2301_ = l_mkPanicMessageWithDecl(v___x_2300_, v___x_2299_, v___x_2298_, v___x_2297_, v___x_2296_);
return v___x_2301_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux(lean_object* v_e_2302_, lean_object* v_a_2303_, lean_object* v_a_2304_){
_start:
{
lean_object* v_visitedNames_2306_; lean_object* v_visitedLevels_2307_; lean_object* v_visitedExprs_2308_; lean_object* v_visitedConstants_2309_; lean_object* v_noMDataExprs_2310_; uint8_t v_exportMData_2311_; uint8_t v_exportUnsafe_2312_; uint8_t v_ignoreMissing_2313_; lean_object* v_recursorMap_2314_; lean_object* v___x_2315_; 
v_visitedNames_2306_ = lean_ctor_get(v_a_2304_, 0);
v_visitedLevels_2307_ = lean_ctor_get(v_a_2304_, 1);
v_visitedExprs_2308_ = lean_ctor_get(v_a_2304_, 2);
v_visitedConstants_2309_ = lean_ctor_get(v_a_2304_, 3);
v_noMDataExprs_2310_ = lean_ctor_get(v_a_2304_, 4);
v_exportMData_2311_ = lean_ctor_get_uint8(v_a_2304_, sizeof(void*)*6);
v_exportUnsafe_2312_ = lean_ctor_get_uint8(v_a_2304_, sizeof(void*)*6 + 1);
v_ignoreMissing_2313_ = lean_ctor_get_uint8(v_a_2304_, sizeof(void*)*6 + 2);
v_recursorMap_2314_ = lean_ctor_get(v_a_2304_, 5);
v___x_2315_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__1___redArg(v_visitedExprs_2308_, v_e_2302_);
if (lean_obj_tag(v___x_2315_) == 1)
{
lean_object* v_val_2316_; lean_object* v___x_2318_; uint8_t v_isShared_2319_; uint8_t v_isSharedCheck_2324_; 
lean_dec_ref(v_e_2302_);
v_val_2316_ = lean_ctor_get(v___x_2315_, 0);
v_isSharedCheck_2324_ = !lean_is_exclusive(v___x_2315_);
if (v_isSharedCheck_2324_ == 0)
{
v___x_2318_ = v___x_2315_;
v_isShared_2319_ = v_isSharedCheck_2324_;
goto v_resetjp_2317_;
}
else
{
lean_inc(v_val_2316_);
lean_dec(v___x_2315_);
v___x_2318_ = lean_box(0);
v_isShared_2319_ = v_isSharedCheck_2324_;
goto v_resetjp_2317_;
}
v_resetjp_2317_:
{
lean_object* v___x_2320_; lean_object* v___x_2322_; 
v___x_2320_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2320_, 0, v_val_2316_);
lean_ctor_set(v___x_2320_, 1, v_a_2304_);
if (v_isShared_2319_ == 0)
{
lean_ctor_set_tag(v___x_2318_, 0);
lean_ctor_set(v___x_2318_, 0, v___x_2320_);
v___x_2322_ = v___x_2318_;
goto v_reusejp_2321_;
}
else
{
lean_object* v_reuseFailAlloc_2323_; 
v_reuseFailAlloc_2323_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2323_, 0, v___x_2320_);
v___x_2322_ = v_reuseFailAlloc_2323_;
goto v_reusejp_2321_;
}
v_reusejp_2321_:
{
return v___x_2322_;
}
}
}
else
{
lean_object* v___x_2325_; lean_object* v_fst_2327_; lean_object* v_visitedNames_2328_; lean_object* v_visitedLevels_2329_; lean_object* v_visitedExprs_2330_; lean_object* v_visitedConstants_2331_; lean_object* v_noMDataExprs_2332_; uint8_t v_exportMData_2333_; uint8_t v_exportUnsafe_2334_; uint8_t v_ignoreMissing_2335_; lean_object* v_recursorMap_2336_; lean_object* v_fst_2363_; lean_object* v_snd_2364_; 
lean_dec(v___x_2315_);
v___x_2325_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__0));
switch(lean_obj_tag(v_e_2302_))
{
case 0:
{
lean_object* v_deBruijnIndex_2374_; lean_object* v___x_2375_; lean_object* v___x_2376_; lean_object* v___x_2377_; lean_object* v___x_2378_; lean_object* v___x_2379_; lean_object* v___x_2380_; lean_object* v___x_2381_; 
lean_inc(v_recursorMap_2314_);
lean_inc_ref(v_noMDataExprs_2310_);
lean_inc_ref(v_visitedConstants_2309_);
lean_inc_ref(v_visitedExprs_2308_);
lean_inc_ref(v_visitedLevels_2307_);
lean_inc_ref(v_visitedNames_2306_);
lean_dec_ref(v_a_2304_);
v_deBruijnIndex_2374_ = lean_ctor_get(v_e_2302_, 0);
v___x_2375_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__1));
lean_inc(v_deBruijnIndex_2374_);
v___x_2376_ = l_Lean_JsonNumber_fromNat(v_deBruijnIndex_2374_);
v___x_2377_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2377_, 0, v___x_2376_);
v___x_2378_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2378_, 0, v___x_2375_);
lean_ctor_set(v___x_2378_, 1, v___x_2377_);
v___x_2379_ = lean_box(0);
v___x_2380_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2380_, 0, v___x_2378_);
lean_ctor_set(v___x_2380_, 1, v___x_2379_);
v___x_2381_ = l_Lean_Json_mkObj(v___x_2380_);
lean_dec_ref_known(v___x_2380_, 2);
v_fst_2327_ = v___x_2381_;
v_visitedNames_2328_ = v_visitedNames_2306_;
v_visitedLevels_2329_ = v_visitedLevels_2307_;
v_visitedExprs_2330_ = v_visitedExprs_2308_;
v_visitedConstants_2331_ = v_visitedConstants_2309_;
v_noMDataExprs_2332_ = v_noMDataExprs_2310_;
v_exportMData_2333_ = v_exportMData_2311_;
v_exportUnsafe_2334_ = v_exportUnsafe_2312_;
v_ignoreMissing_2335_ = v_ignoreMissing_2313_;
v_recursorMap_2336_ = v_recursorMap_2314_;
goto v___jp_2326_;
}
case 3:
{
lean_object* v_u_2382_; lean_object* v___x_2383_; 
v_u_2382_ = lean_ctor_get(v_e_2302_, 0);
lean_inc(v_u_2382_);
v___x_2383_ = lp_proofEnvironment_dumpLevel(v_u_2382_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2383_) == 0)
{
lean_object* v_a_2384_; lean_object* v___x_2386_; uint8_t v_isShared_2387_; uint8_t v_isSharedCheck_2405_; 
v_a_2384_ = lean_ctor_get(v___x_2383_, 0);
v_isSharedCheck_2405_ = !lean_is_exclusive(v___x_2383_);
if (v_isSharedCheck_2405_ == 0)
{
v___x_2386_ = v___x_2383_;
v_isShared_2387_ = v_isSharedCheck_2405_;
goto v_resetjp_2385_;
}
else
{
lean_inc(v_a_2384_);
lean_dec(v___x_2383_);
v___x_2386_ = lean_box(0);
v_isShared_2387_ = v_isSharedCheck_2405_;
goto v_resetjp_2385_;
}
v_resetjp_2385_:
{
lean_object* v_fst_2388_; lean_object* v_snd_2389_; lean_object* v___x_2391_; uint8_t v_isShared_2392_; uint8_t v_isSharedCheck_2404_; 
v_fst_2388_ = lean_ctor_get(v_a_2384_, 0);
v_snd_2389_ = lean_ctor_get(v_a_2384_, 1);
v_isSharedCheck_2404_ = !lean_is_exclusive(v_a_2384_);
if (v_isSharedCheck_2404_ == 0)
{
v___x_2391_ = v_a_2384_;
v_isShared_2392_ = v_isSharedCheck_2404_;
goto v_resetjp_2390_;
}
else
{
lean_inc(v_snd_2389_);
lean_inc(v_fst_2388_);
lean_dec(v_a_2384_);
v___x_2391_ = lean_box(0);
v_isShared_2392_ = v_isSharedCheck_2404_;
goto v_resetjp_2390_;
}
v_resetjp_2390_:
{
lean_object* v___x_2393_; lean_object* v___x_2394_; lean_object* v___x_2396_; 
v___x_2393_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__2));
v___x_2394_ = l_Lean_JsonNumber_fromNat(v_fst_2388_);
if (v_isShared_2387_ == 0)
{
lean_ctor_set_tag(v___x_2386_, 2);
lean_ctor_set(v___x_2386_, 0, v___x_2394_);
v___x_2396_ = v___x_2386_;
goto v_reusejp_2395_;
}
else
{
lean_object* v_reuseFailAlloc_2403_; 
v_reuseFailAlloc_2403_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2403_, 0, v___x_2394_);
v___x_2396_ = v_reuseFailAlloc_2403_;
goto v_reusejp_2395_;
}
v_reusejp_2395_:
{
lean_object* v___x_2398_; 
if (v_isShared_2392_ == 0)
{
lean_ctor_set(v___x_2391_, 1, v___x_2396_);
lean_ctor_set(v___x_2391_, 0, v___x_2393_);
v___x_2398_ = v___x_2391_;
goto v_reusejp_2397_;
}
else
{
lean_object* v_reuseFailAlloc_2402_; 
v_reuseFailAlloc_2402_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2402_, 0, v___x_2393_);
lean_ctor_set(v_reuseFailAlloc_2402_, 1, v___x_2396_);
v___x_2398_ = v_reuseFailAlloc_2402_;
goto v_reusejp_2397_;
}
v_reusejp_2397_:
{
lean_object* v___x_2399_; lean_object* v___x_2400_; lean_object* v___x_2401_; 
v___x_2399_ = lean_box(0);
v___x_2400_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2400_, 0, v___x_2398_);
lean_ctor_set(v___x_2400_, 1, v___x_2399_);
v___x_2401_ = l_Lean_Json_mkObj(v___x_2400_);
lean_dec_ref_known(v___x_2400_, 2);
v_fst_2363_ = v___x_2401_;
v_snd_2364_ = v_snd_2389_;
goto v___jp_2362_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 1);
return v___x_2383_;
}
}
case 4:
{
lean_object* v_declName_2406_; lean_object* v_us_2407_; lean_object* v___x_2408_; 
v_declName_2406_ = lean_ctor_get(v_e_2302_, 0);
v_us_2407_ = lean_ctor_get(v_e_2302_, 1);
lean_inc(v_declName_2406_);
v___x_2408_ = lp_proofEnvironment_dumpName(v_declName_2406_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2408_) == 0)
{
lean_object* v_a_2409_; lean_object* v___x_2411_; uint8_t v_isShared_2412_; uint8_t v_isSharedCheck_2456_; 
v_a_2409_ = lean_ctor_get(v___x_2408_, 0);
v_isSharedCheck_2456_ = !lean_is_exclusive(v___x_2408_);
if (v_isSharedCheck_2456_ == 0)
{
v___x_2411_ = v___x_2408_;
v_isShared_2412_ = v_isSharedCheck_2456_;
goto v_resetjp_2410_;
}
else
{
lean_inc(v_a_2409_);
lean_dec(v___x_2408_);
v___x_2411_ = lean_box(0);
v_isShared_2412_ = v_isSharedCheck_2456_;
goto v_resetjp_2410_;
}
v_resetjp_2410_:
{
lean_object* v_fst_2413_; lean_object* v_snd_2414_; lean_object* v___x_2416_; uint8_t v_isShared_2417_; uint8_t v_isSharedCheck_2455_; 
v_fst_2413_ = lean_ctor_get(v_a_2409_, 0);
v_snd_2414_ = lean_ctor_get(v_a_2409_, 1);
v_isSharedCheck_2455_ = !lean_is_exclusive(v_a_2409_);
if (v_isSharedCheck_2455_ == 0)
{
v___x_2416_ = v_a_2409_;
v_isShared_2417_ = v_isSharedCheck_2455_;
goto v_resetjp_2415_;
}
else
{
lean_inc(v_snd_2414_);
lean_inc(v_fst_2413_);
lean_dec(v_a_2409_);
v___x_2416_ = lean_box(0);
v_isShared_2417_ = v_isSharedCheck_2455_;
goto v_resetjp_2415_;
}
v_resetjp_2415_:
{
lean_object* v___x_2418_; lean_object* v___x_2419_; 
v___x_2418_ = lean_box(0);
lean_inc(v_us_2407_);
v___x_2419_ = lp_proofEnvironment_List_mapM_loop___at___00dumpUparams_spec__1(v_us_2407_, v___x_2418_, v_a_2303_, v_snd_2414_);
if (lean_obj_tag(v___x_2419_) == 0)
{
lean_object* v_a_2420_; lean_object* v_fst_2421_; lean_object* v_snd_2422_; lean_object* v___x_2424_; uint8_t v_isShared_2425_; uint8_t v_isSharedCheck_2446_; 
v_a_2420_ = lean_ctor_get(v___x_2419_, 0);
lean_inc(v_a_2420_);
lean_dec_ref_known(v___x_2419_, 1);
v_fst_2421_ = lean_ctor_get(v_a_2420_, 0);
v_snd_2422_ = lean_ctor_get(v_a_2420_, 1);
v_isSharedCheck_2446_ = !lean_is_exclusive(v_a_2420_);
if (v_isSharedCheck_2446_ == 0)
{
v___x_2424_ = v_a_2420_;
v_isShared_2425_ = v_isSharedCheck_2446_;
goto v_resetjp_2423_;
}
else
{
lean_inc(v_snd_2422_);
lean_inc(v_fst_2421_);
lean_dec(v_a_2420_);
v___x_2424_ = lean_box(0);
v_isShared_2425_ = v_isSharedCheck_2446_;
goto v_resetjp_2423_;
}
v_resetjp_2423_:
{
lean_object* v___x_2426_; lean_object* v___x_2427_; lean_object* v___x_2428_; lean_object* v___x_2430_; 
v___x_2426_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__3));
v___x_2427_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_2428_ = l_Lean_JsonNumber_fromNat(v_fst_2413_);
if (v_isShared_2412_ == 0)
{
lean_ctor_set_tag(v___x_2411_, 2);
lean_ctor_set(v___x_2411_, 0, v___x_2428_);
v___x_2430_ = v___x_2411_;
goto v_reusejp_2429_;
}
else
{
lean_object* v_reuseFailAlloc_2445_; 
v_reuseFailAlloc_2445_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2445_, 0, v___x_2428_);
v___x_2430_ = v_reuseFailAlloc_2445_;
goto v_reusejp_2429_;
}
v_reusejp_2429_:
{
lean_object* v___x_2432_; 
if (v_isShared_2425_ == 0)
{
lean_ctor_set(v___x_2424_, 1, v___x_2430_);
lean_ctor_set(v___x_2424_, 0, v___x_2427_);
v___x_2432_ = v___x_2424_;
goto v_reusejp_2431_;
}
else
{
lean_object* v_reuseFailAlloc_2444_; 
v_reuseFailAlloc_2444_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2444_, 0, v___x_2427_);
lean_ctor_set(v_reuseFailAlloc_2444_, 1, v___x_2430_);
v___x_2432_ = v_reuseFailAlloc_2444_;
goto v_reusejp_2431_;
}
v_reusejp_2431_:
{
lean_object* v___x_2433_; lean_object* v___x_2434_; lean_object* v___x_2436_; 
v___x_2433_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__4));
v___x_2434_ = lp_proofEnvironment_Lean_List_toJson___at___00dumpUparams_spec__2(v_fst_2421_);
if (v_isShared_2417_ == 0)
{
lean_ctor_set(v___x_2416_, 1, v___x_2434_);
lean_ctor_set(v___x_2416_, 0, v___x_2433_);
v___x_2436_ = v___x_2416_;
goto v_reusejp_2435_;
}
else
{
lean_object* v_reuseFailAlloc_2443_; 
v_reuseFailAlloc_2443_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2443_, 0, v___x_2433_);
lean_ctor_set(v_reuseFailAlloc_2443_, 1, v___x_2434_);
v___x_2436_ = v_reuseFailAlloc_2443_;
goto v_reusejp_2435_;
}
v_reusejp_2435_:
{
lean_object* v___x_2437_; lean_object* v___x_2438_; lean_object* v___x_2439_; lean_object* v___x_2440_; lean_object* v___x_2441_; lean_object* v___x_2442_; 
v___x_2437_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2437_, 0, v___x_2436_);
lean_ctor_set(v___x_2437_, 1, v___x_2418_);
v___x_2438_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2438_, 0, v___x_2432_);
lean_ctor_set(v___x_2438_, 1, v___x_2437_);
v___x_2439_ = l_Lean_Json_mkObj(v___x_2438_);
lean_dec_ref_known(v___x_2438_, 2);
v___x_2440_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2440_, 0, v___x_2426_);
lean_ctor_set(v___x_2440_, 1, v___x_2439_);
v___x_2441_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2441_, 0, v___x_2440_);
lean_ctor_set(v___x_2441_, 1, v___x_2418_);
v___x_2442_ = l_Lean_Json_mkObj(v___x_2441_);
lean_dec_ref_known(v___x_2441_, 2);
v_fst_2363_ = v___x_2442_;
v_snd_2364_ = v_snd_2422_;
goto v___jp_2362_;
}
}
}
}
}
else
{
lean_object* v_a_2447_; lean_object* v___x_2449_; uint8_t v_isShared_2450_; uint8_t v_isSharedCheck_2454_; 
lean_del_object(v___x_2416_);
lean_dec(v_fst_2413_);
lean_del_object(v___x_2411_);
lean_dec_ref_known(v_e_2302_, 2);
v_a_2447_ = lean_ctor_get(v___x_2419_, 0);
v_isSharedCheck_2454_ = !lean_is_exclusive(v___x_2419_);
if (v_isSharedCheck_2454_ == 0)
{
v___x_2449_ = v___x_2419_;
v_isShared_2450_ = v_isSharedCheck_2454_;
goto v_resetjp_2448_;
}
else
{
lean_inc(v_a_2447_);
lean_dec(v___x_2419_);
v___x_2449_ = lean_box(0);
v_isShared_2450_ = v_isSharedCheck_2454_;
goto v_resetjp_2448_;
}
v_resetjp_2448_:
{
lean_object* v___x_2452_; 
if (v_isShared_2450_ == 0)
{
v___x_2452_ = v___x_2449_;
goto v_reusejp_2451_;
}
else
{
lean_object* v_reuseFailAlloc_2453_; 
v_reuseFailAlloc_2453_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2453_, 0, v_a_2447_);
v___x_2452_ = v_reuseFailAlloc_2453_;
goto v_reusejp_2451_;
}
v_reusejp_2451_:
{
return v___x_2452_;
}
}
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 2);
return v___x_2408_;
}
}
case 5:
{
lean_object* v_fn_2457_; lean_object* v_arg_2458_; lean_object* v___x_2459_; 
v_fn_2457_ = lean_ctor_get(v_e_2302_, 0);
v_arg_2458_ = lean_ctor_get(v_e_2302_, 1);
lean_inc_ref(v_fn_2457_);
v___x_2459_ = lp_proofEnvironment_dumpExprAux(v_fn_2457_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2459_) == 0)
{
lean_object* v_a_2460_; lean_object* v___x_2462_; uint8_t v_isShared_2463_; uint8_t v_isSharedCheck_2506_; 
v_a_2460_ = lean_ctor_get(v___x_2459_, 0);
v_isSharedCheck_2506_ = !lean_is_exclusive(v___x_2459_);
if (v_isSharedCheck_2506_ == 0)
{
v___x_2462_ = v___x_2459_;
v_isShared_2463_ = v_isSharedCheck_2506_;
goto v_resetjp_2461_;
}
else
{
lean_inc(v_a_2460_);
lean_dec(v___x_2459_);
v___x_2462_ = lean_box(0);
v_isShared_2463_ = v_isSharedCheck_2506_;
goto v_resetjp_2461_;
}
v_resetjp_2461_:
{
lean_object* v_fst_2464_; lean_object* v_snd_2465_; lean_object* v___x_2467_; uint8_t v_isShared_2468_; uint8_t v_isSharedCheck_2505_; 
v_fst_2464_ = lean_ctor_get(v_a_2460_, 0);
v_snd_2465_ = lean_ctor_get(v_a_2460_, 1);
v_isSharedCheck_2505_ = !lean_is_exclusive(v_a_2460_);
if (v_isSharedCheck_2505_ == 0)
{
v___x_2467_ = v_a_2460_;
v_isShared_2468_ = v_isSharedCheck_2505_;
goto v_resetjp_2466_;
}
else
{
lean_inc(v_snd_2465_);
lean_inc(v_fst_2464_);
lean_dec(v_a_2460_);
v___x_2467_ = lean_box(0);
v_isShared_2468_ = v_isSharedCheck_2505_;
goto v_resetjp_2466_;
}
v_resetjp_2466_:
{
lean_object* v___x_2469_; 
lean_inc_ref(v_arg_2458_);
v___x_2469_ = lp_proofEnvironment_dumpExprAux(v_arg_2458_, v_a_2303_, v_snd_2465_);
if (lean_obj_tag(v___x_2469_) == 0)
{
lean_object* v_a_2470_; lean_object* v___x_2472_; uint8_t v_isShared_2473_; uint8_t v_isSharedCheck_2504_; 
v_a_2470_ = lean_ctor_get(v___x_2469_, 0);
v_isSharedCheck_2504_ = !lean_is_exclusive(v___x_2469_);
if (v_isSharedCheck_2504_ == 0)
{
v___x_2472_ = v___x_2469_;
v_isShared_2473_ = v_isSharedCheck_2504_;
goto v_resetjp_2471_;
}
else
{
lean_inc(v_a_2470_);
lean_dec(v___x_2469_);
v___x_2472_ = lean_box(0);
v_isShared_2473_ = v_isSharedCheck_2504_;
goto v_resetjp_2471_;
}
v_resetjp_2471_:
{
lean_object* v_fst_2474_; lean_object* v_snd_2475_; lean_object* v___x_2477_; uint8_t v_isShared_2478_; uint8_t v_isSharedCheck_2503_; 
v_fst_2474_ = lean_ctor_get(v_a_2470_, 0);
v_snd_2475_ = lean_ctor_get(v_a_2470_, 1);
v_isSharedCheck_2503_ = !lean_is_exclusive(v_a_2470_);
if (v_isSharedCheck_2503_ == 0)
{
v___x_2477_ = v_a_2470_;
v_isShared_2478_ = v_isSharedCheck_2503_;
goto v_resetjp_2476_;
}
else
{
lean_inc(v_snd_2475_);
lean_inc(v_fst_2474_);
lean_dec(v_a_2470_);
v___x_2477_ = lean_box(0);
v_isShared_2478_ = v_isSharedCheck_2503_;
goto v_resetjp_2476_;
}
v_resetjp_2476_:
{
lean_object* v___x_2479_; lean_object* v___x_2480_; lean_object* v___x_2481_; lean_object* v___x_2483_; 
v___x_2479_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__5));
v___x_2480_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__6));
v___x_2481_ = l_Lean_JsonNumber_fromNat(v_fst_2464_);
if (v_isShared_2473_ == 0)
{
lean_ctor_set_tag(v___x_2472_, 2);
lean_ctor_set(v___x_2472_, 0, v___x_2481_);
v___x_2483_ = v___x_2472_;
goto v_reusejp_2482_;
}
else
{
lean_object* v_reuseFailAlloc_2502_; 
v_reuseFailAlloc_2502_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2502_, 0, v___x_2481_);
v___x_2483_ = v_reuseFailAlloc_2502_;
goto v_reusejp_2482_;
}
v_reusejp_2482_:
{
lean_object* v___x_2485_; 
if (v_isShared_2478_ == 0)
{
lean_ctor_set(v___x_2477_, 1, v___x_2483_);
lean_ctor_set(v___x_2477_, 0, v___x_2480_);
v___x_2485_ = v___x_2477_;
goto v_reusejp_2484_;
}
else
{
lean_object* v_reuseFailAlloc_2501_; 
v_reuseFailAlloc_2501_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2501_, 0, v___x_2480_);
lean_ctor_set(v_reuseFailAlloc_2501_, 1, v___x_2483_);
v___x_2485_ = v_reuseFailAlloc_2501_;
goto v_reusejp_2484_;
}
v_reusejp_2484_:
{
lean_object* v___x_2486_; lean_object* v___x_2487_; lean_object* v___x_2489_; 
v___x_2486_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__7));
v___x_2487_ = l_Lean_JsonNumber_fromNat(v_fst_2474_);
if (v_isShared_2463_ == 0)
{
lean_ctor_set_tag(v___x_2462_, 2);
lean_ctor_set(v___x_2462_, 0, v___x_2487_);
v___x_2489_ = v___x_2462_;
goto v_reusejp_2488_;
}
else
{
lean_object* v_reuseFailAlloc_2500_; 
v_reuseFailAlloc_2500_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2500_, 0, v___x_2487_);
v___x_2489_ = v_reuseFailAlloc_2500_;
goto v_reusejp_2488_;
}
v_reusejp_2488_:
{
lean_object* v___x_2491_; 
if (v_isShared_2468_ == 0)
{
lean_ctor_set(v___x_2467_, 1, v___x_2489_);
lean_ctor_set(v___x_2467_, 0, v___x_2486_);
v___x_2491_ = v___x_2467_;
goto v_reusejp_2490_;
}
else
{
lean_object* v_reuseFailAlloc_2499_; 
v_reuseFailAlloc_2499_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2499_, 0, v___x_2486_);
lean_ctor_set(v_reuseFailAlloc_2499_, 1, v___x_2489_);
v___x_2491_ = v_reuseFailAlloc_2499_;
goto v_reusejp_2490_;
}
v_reusejp_2490_:
{
lean_object* v___x_2492_; lean_object* v___x_2493_; lean_object* v___x_2494_; lean_object* v___x_2495_; lean_object* v___x_2496_; lean_object* v___x_2497_; lean_object* v___x_2498_; 
v___x_2492_ = lean_box(0);
v___x_2493_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2493_, 0, v___x_2491_);
lean_ctor_set(v___x_2493_, 1, v___x_2492_);
v___x_2494_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2494_, 0, v___x_2485_);
lean_ctor_set(v___x_2494_, 1, v___x_2493_);
v___x_2495_ = l_Lean_Json_mkObj(v___x_2494_);
lean_dec_ref_known(v___x_2494_, 2);
v___x_2496_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2496_, 0, v___x_2479_);
lean_ctor_set(v___x_2496_, 1, v___x_2495_);
v___x_2497_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2497_, 0, v___x_2496_);
lean_ctor_set(v___x_2497_, 1, v___x_2492_);
v___x_2498_ = l_Lean_Json_mkObj(v___x_2497_);
lean_dec_ref_known(v___x_2497_, 2);
v_fst_2363_ = v___x_2498_;
v_snd_2364_ = v_snd_2475_;
goto v___jp_2362_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2467_);
lean_dec(v_fst_2464_);
lean_del_object(v___x_2462_);
lean_dec_ref_known(v_e_2302_, 2);
return v___x_2469_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 2);
return v___x_2459_;
}
}
case 6:
{
lean_object* v_binderName_2507_; lean_object* v_binderType_2508_; lean_object* v_body_2509_; uint8_t v_binderInfo_2510_; lean_object* v___x_2511_; 
v_binderName_2507_ = lean_ctor_get(v_e_2302_, 0);
v_binderType_2508_ = lean_ctor_get(v_e_2302_, 1);
v_body_2509_ = lean_ctor_get(v_e_2302_, 2);
v_binderInfo_2510_ = lean_ctor_get_uint8(v_e_2302_, sizeof(void*)*3 + 8);
lean_inc(v_binderName_2507_);
v___x_2511_ = lp_proofEnvironment_dumpName(v_binderName_2507_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2511_) == 0)
{
lean_object* v_a_2512_; lean_object* v___x_2514_; uint8_t v_isShared_2515_; uint8_t v_isSharedCheck_2583_; 
v_a_2512_ = lean_ctor_get(v___x_2511_, 0);
v_isSharedCheck_2583_ = !lean_is_exclusive(v___x_2511_);
if (v_isSharedCheck_2583_ == 0)
{
v___x_2514_ = v___x_2511_;
v_isShared_2515_ = v_isSharedCheck_2583_;
goto v_resetjp_2513_;
}
else
{
lean_inc(v_a_2512_);
lean_dec(v___x_2511_);
v___x_2514_ = lean_box(0);
v_isShared_2515_ = v_isSharedCheck_2583_;
goto v_resetjp_2513_;
}
v_resetjp_2513_:
{
lean_object* v_fst_2516_; lean_object* v_snd_2517_; lean_object* v___x_2519_; uint8_t v_isShared_2520_; uint8_t v_isSharedCheck_2582_; 
v_fst_2516_ = lean_ctor_get(v_a_2512_, 0);
v_snd_2517_ = lean_ctor_get(v_a_2512_, 1);
v_isSharedCheck_2582_ = !lean_is_exclusive(v_a_2512_);
if (v_isSharedCheck_2582_ == 0)
{
v___x_2519_ = v_a_2512_;
v_isShared_2520_ = v_isSharedCheck_2582_;
goto v_resetjp_2518_;
}
else
{
lean_inc(v_snd_2517_);
lean_inc(v_fst_2516_);
lean_dec(v_a_2512_);
v___x_2519_ = lean_box(0);
v_isShared_2520_ = v_isSharedCheck_2582_;
goto v_resetjp_2518_;
}
v_resetjp_2518_:
{
lean_object* v___x_2521_; 
lean_inc_ref(v_binderType_2508_);
v___x_2521_ = lp_proofEnvironment_dumpExprAux(v_binderType_2508_, v_a_2303_, v_snd_2517_);
if (lean_obj_tag(v___x_2521_) == 0)
{
lean_object* v_a_2522_; lean_object* v___x_2524_; uint8_t v_isShared_2525_; uint8_t v_isSharedCheck_2581_; 
v_a_2522_ = lean_ctor_get(v___x_2521_, 0);
v_isSharedCheck_2581_ = !lean_is_exclusive(v___x_2521_);
if (v_isSharedCheck_2581_ == 0)
{
v___x_2524_ = v___x_2521_;
v_isShared_2525_ = v_isSharedCheck_2581_;
goto v_resetjp_2523_;
}
else
{
lean_inc(v_a_2522_);
lean_dec(v___x_2521_);
v___x_2524_ = lean_box(0);
v_isShared_2525_ = v_isSharedCheck_2581_;
goto v_resetjp_2523_;
}
v_resetjp_2523_:
{
lean_object* v_fst_2526_; lean_object* v_snd_2527_; lean_object* v___x_2529_; uint8_t v_isShared_2530_; uint8_t v_isSharedCheck_2580_; 
v_fst_2526_ = lean_ctor_get(v_a_2522_, 0);
v_snd_2527_ = lean_ctor_get(v_a_2522_, 1);
v_isSharedCheck_2580_ = !lean_is_exclusive(v_a_2522_);
if (v_isSharedCheck_2580_ == 0)
{
v___x_2529_ = v_a_2522_;
v_isShared_2530_ = v_isSharedCheck_2580_;
goto v_resetjp_2528_;
}
else
{
lean_inc(v_snd_2527_);
lean_inc(v_fst_2526_);
lean_dec(v_a_2522_);
v___x_2529_ = lean_box(0);
v_isShared_2530_ = v_isSharedCheck_2580_;
goto v_resetjp_2528_;
}
v_resetjp_2528_:
{
lean_object* v___x_2531_; 
lean_inc_ref(v_body_2509_);
v___x_2531_ = lp_proofEnvironment_dumpExprAux(v_body_2509_, v_a_2303_, v_snd_2527_);
if (lean_obj_tag(v___x_2531_) == 0)
{
lean_object* v_a_2532_; lean_object* v___x_2534_; uint8_t v_isShared_2535_; uint8_t v_isSharedCheck_2579_; 
v_a_2532_ = lean_ctor_get(v___x_2531_, 0);
v_isSharedCheck_2579_ = !lean_is_exclusive(v___x_2531_);
if (v_isSharedCheck_2579_ == 0)
{
v___x_2534_ = v___x_2531_;
v_isShared_2535_ = v_isSharedCheck_2579_;
goto v_resetjp_2533_;
}
else
{
lean_inc(v_a_2532_);
lean_dec(v___x_2531_);
v___x_2534_ = lean_box(0);
v_isShared_2535_ = v_isSharedCheck_2579_;
goto v_resetjp_2533_;
}
v_resetjp_2533_:
{
lean_object* v_fst_2536_; lean_object* v_snd_2537_; lean_object* v___x_2539_; uint8_t v_isShared_2540_; uint8_t v_isSharedCheck_2578_; 
v_fst_2536_ = lean_ctor_get(v_a_2532_, 0);
v_snd_2537_ = lean_ctor_get(v_a_2532_, 1);
v_isSharedCheck_2578_ = !lean_is_exclusive(v_a_2532_);
if (v_isSharedCheck_2578_ == 0)
{
v___x_2539_ = v_a_2532_;
v_isShared_2540_ = v_isSharedCheck_2578_;
goto v_resetjp_2538_;
}
else
{
lean_inc(v_snd_2537_);
lean_inc(v_fst_2536_);
lean_dec(v_a_2532_);
v___x_2539_ = lean_box(0);
v_isShared_2540_ = v_isSharedCheck_2578_;
goto v_resetjp_2538_;
}
v_resetjp_2538_:
{
lean_object* v___x_2541_; lean_object* v___x_2542_; lean_object* v___x_2543_; lean_object* v___x_2545_; 
v___x_2541_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__8));
v___x_2542_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_2543_ = l_Lean_JsonNumber_fromNat(v_fst_2516_);
if (v_isShared_2535_ == 0)
{
lean_ctor_set_tag(v___x_2534_, 2);
lean_ctor_set(v___x_2534_, 0, v___x_2543_);
v___x_2545_ = v___x_2534_;
goto v_reusejp_2544_;
}
else
{
lean_object* v_reuseFailAlloc_2577_; 
v_reuseFailAlloc_2577_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2577_, 0, v___x_2543_);
v___x_2545_ = v_reuseFailAlloc_2577_;
goto v_reusejp_2544_;
}
v_reusejp_2544_:
{
lean_object* v___x_2547_; 
if (v_isShared_2540_ == 0)
{
lean_ctor_set(v___x_2539_, 1, v___x_2545_);
lean_ctor_set(v___x_2539_, 0, v___x_2542_);
v___x_2547_ = v___x_2539_;
goto v_reusejp_2546_;
}
else
{
lean_object* v_reuseFailAlloc_2576_; 
v_reuseFailAlloc_2576_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2576_, 0, v___x_2542_);
lean_ctor_set(v_reuseFailAlloc_2576_, 1, v___x_2545_);
v___x_2547_ = v_reuseFailAlloc_2576_;
goto v_reusejp_2546_;
}
v_reusejp_2546_:
{
lean_object* v___x_2548_; lean_object* v___x_2549_; lean_object* v___x_2551_; 
v___x_2548_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_2549_ = l_Lean_JsonNumber_fromNat(v_fst_2526_);
if (v_isShared_2525_ == 0)
{
lean_ctor_set_tag(v___x_2524_, 2);
lean_ctor_set(v___x_2524_, 0, v___x_2549_);
v___x_2551_ = v___x_2524_;
goto v_reusejp_2550_;
}
else
{
lean_object* v_reuseFailAlloc_2575_; 
v_reuseFailAlloc_2575_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2575_, 0, v___x_2549_);
v___x_2551_ = v_reuseFailAlloc_2575_;
goto v_reusejp_2550_;
}
v_reusejp_2550_:
{
lean_object* v___x_2553_; 
if (v_isShared_2530_ == 0)
{
lean_ctor_set(v___x_2529_, 1, v___x_2551_);
lean_ctor_set(v___x_2529_, 0, v___x_2548_);
v___x_2553_ = v___x_2529_;
goto v_reusejp_2552_;
}
else
{
lean_object* v_reuseFailAlloc_2574_; 
v_reuseFailAlloc_2574_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2574_, 0, v___x_2548_);
lean_ctor_set(v_reuseFailAlloc_2574_, 1, v___x_2551_);
v___x_2553_ = v_reuseFailAlloc_2574_;
goto v_reusejp_2552_;
}
v_reusejp_2552_:
{
lean_object* v___x_2554_; lean_object* v___x_2555_; lean_object* v___x_2557_; 
v___x_2554_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__9));
v___x_2555_ = l_Lean_JsonNumber_fromNat(v_fst_2536_);
if (v_isShared_2515_ == 0)
{
lean_ctor_set_tag(v___x_2514_, 2);
lean_ctor_set(v___x_2514_, 0, v___x_2555_);
v___x_2557_ = v___x_2514_;
goto v_reusejp_2556_;
}
else
{
lean_object* v_reuseFailAlloc_2573_; 
v_reuseFailAlloc_2573_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2573_, 0, v___x_2555_);
v___x_2557_ = v_reuseFailAlloc_2573_;
goto v_reusejp_2556_;
}
v_reusejp_2556_:
{
lean_object* v___x_2559_; 
if (v_isShared_2520_ == 0)
{
lean_ctor_set(v___x_2519_, 1, v___x_2557_);
lean_ctor_set(v___x_2519_, 0, v___x_2554_);
v___x_2559_ = v___x_2519_;
goto v_reusejp_2558_;
}
else
{
lean_object* v_reuseFailAlloc_2572_; 
v_reuseFailAlloc_2572_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2572_, 0, v___x_2554_);
lean_ctor_set(v_reuseFailAlloc_2572_, 1, v___x_2557_);
v___x_2559_ = v_reuseFailAlloc_2572_;
goto v_reusejp_2558_;
}
v_reusejp_2558_:
{
lean_object* v___x_2560_; lean_object* v___x_2561_; lean_object* v___x_2562_; lean_object* v___x_2563_; lean_object* v___x_2564_; lean_object* v___x_2565_; lean_object* v___x_2566_; lean_object* v___x_2567_; lean_object* v___x_2568_; lean_object* v___x_2569_; lean_object* v___x_2570_; lean_object* v___x_2571_; 
v___x_2560_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__10));
v___x_2561_ = lp_proofEnvironment_Lean_BinderInfo_toJson(v_binderInfo_2510_);
v___x_2562_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2562_, 0, v___x_2560_);
lean_ctor_set(v___x_2562_, 1, v___x_2561_);
v___x_2563_ = lean_box(0);
v___x_2564_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2564_, 0, v___x_2562_);
lean_ctor_set(v___x_2564_, 1, v___x_2563_);
v___x_2565_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2565_, 0, v___x_2559_);
lean_ctor_set(v___x_2565_, 1, v___x_2564_);
v___x_2566_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2566_, 0, v___x_2553_);
lean_ctor_set(v___x_2566_, 1, v___x_2565_);
v___x_2567_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2567_, 0, v___x_2547_);
lean_ctor_set(v___x_2567_, 1, v___x_2566_);
v___x_2568_ = l_Lean_Json_mkObj(v___x_2567_);
lean_dec_ref_known(v___x_2567_, 2);
v___x_2569_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2569_, 0, v___x_2541_);
lean_ctor_set(v___x_2569_, 1, v___x_2568_);
v___x_2570_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2570_, 0, v___x_2569_);
lean_ctor_set(v___x_2570_, 1, v___x_2563_);
v___x_2571_ = l_Lean_Json_mkObj(v___x_2570_);
lean_dec_ref_known(v___x_2570_, 2);
v_fst_2363_ = v___x_2571_;
v_snd_2364_ = v_snd_2537_;
goto v___jp_2362_;
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2529_);
lean_dec(v_fst_2526_);
lean_del_object(v___x_2524_);
lean_del_object(v___x_2519_);
lean_dec(v_fst_2516_);
lean_del_object(v___x_2514_);
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2531_;
}
}
}
}
else
{
lean_del_object(v___x_2519_);
lean_dec(v_fst_2516_);
lean_del_object(v___x_2514_);
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2521_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2511_;
}
}
case 7:
{
lean_object* v_binderName_2584_; lean_object* v_binderType_2585_; lean_object* v_body_2586_; uint8_t v_binderInfo_2587_; lean_object* v___x_2588_; 
v_binderName_2584_ = lean_ctor_get(v_e_2302_, 0);
v_binderType_2585_ = lean_ctor_get(v_e_2302_, 1);
v_body_2586_ = lean_ctor_get(v_e_2302_, 2);
v_binderInfo_2587_ = lean_ctor_get_uint8(v_e_2302_, sizeof(void*)*3 + 8);
lean_inc(v_binderName_2584_);
v___x_2588_ = lp_proofEnvironment_dumpName(v_binderName_2584_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2588_) == 0)
{
lean_object* v_a_2589_; lean_object* v___x_2591_; uint8_t v_isShared_2592_; uint8_t v_isSharedCheck_2660_; 
v_a_2589_ = lean_ctor_get(v___x_2588_, 0);
v_isSharedCheck_2660_ = !lean_is_exclusive(v___x_2588_);
if (v_isSharedCheck_2660_ == 0)
{
v___x_2591_ = v___x_2588_;
v_isShared_2592_ = v_isSharedCheck_2660_;
goto v_resetjp_2590_;
}
else
{
lean_inc(v_a_2589_);
lean_dec(v___x_2588_);
v___x_2591_ = lean_box(0);
v_isShared_2592_ = v_isSharedCheck_2660_;
goto v_resetjp_2590_;
}
v_resetjp_2590_:
{
lean_object* v_fst_2593_; lean_object* v_snd_2594_; lean_object* v___x_2596_; uint8_t v_isShared_2597_; uint8_t v_isSharedCheck_2659_; 
v_fst_2593_ = lean_ctor_get(v_a_2589_, 0);
v_snd_2594_ = lean_ctor_get(v_a_2589_, 1);
v_isSharedCheck_2659_ = !lean_is_exclusive(v_a_2589_);
if (v_isSharedCheck_2659_ == 0)
{
v___x_2596_ = v_a_2589_;
v_isShared_2597_ = v_isSharedCheck_2659_;
goto v_resetjp_2595_;
}
else
{
lean_inc(v_snd_2594_);
lean_inc(v_fst_2593_);
lean_dec(v_a_2589_);
v___x_2596_ = lean_box(0);
v_isShared_2597_ = v_isSharedCheck_2659_;
goto v_resetjp_2595_;
}
v_resetjp_2595_:
{
lean_object* v___x_2598_; 
lean_inc_ref(v_binderType_2585_);
v___x_2598_ = lp_proofEnvironment_dumpExprAux(v_binderType_2585_, v_a_2303_, v_snd_2594_);
if (lean_obj_tag(v___x_2598_) == 0)
{
lean_object* v_a_2599_; lean_object* v___x_2601_; uint8_t v_isShared_2602_; uint8_t v_isSharedCheck_2658_; 
v_a_2599_ = lean_ctor_get(v___x_2598_, 0);
v_isSharedCheck_2658_ = !lean_is_exclusive(v___x_2598_);
if (v_isSharedCheck_2658_ == 0)
{
v___x_2601_ = v___x_2598_;
v_isShared_2602_ = v_isSharedCheck_2658_;
goto v_resetjp_2600_;
}
else
{
lean_inc(v_a_2599_);
lean_dec(v___x_2598_);
v___x_2601_ = lean_box(0);
v_isShared_2602_ = v_isSharedCheck_2658_;
goto v_resetjp_2600_;
}
v_resetjp_2600_:
{
lean_object* v_fst_2603_; lean_object* v_snd_2604_; lean_object* v___x_2606_; uint8_t v_isShared_2607_; uint8_t v_isSharedCheck_2657_; 
v_fst_2603_ = lean_ctor_get(v_a_2599_, 0);
v_snd_2604_ = lean_ctor_get(v_a_2599_, 1);
v_isSharedCheck_2657_ = !lean_is_exclusive(v_a_2599_);
if (v_isSharedCheck_2657_ == 0)
{
v___x_2606_ = v_a_2599_;
v_isShared_2607_ = v_isSharedCheck_2657_;
goto v_resetjp_2605_;
}
else
{
lean_inc(v_snd_2604_);
lean_inc(v_fst_2603_);
lean_dec(v_a_2599_);
v___x_2606_ = lean_box(0);
v_isShared_2607_ = v_isSharedCheck_2657_;
goto v_resetjp_2605_;
}
v_resetjp_2605_:
{
lean_object* v___x_2608_; 
lean_inc_ref(v_body_2586_);
v___x_2608_ = lp_proofEnvironment_dumpExprAux(v_body_2586_, v_a_2303_, v_snd_2604_);
if (lean_obj_tag(v___x_2608_) == 0)
{
lean_object* v_a_2609_; lean_object* v___x_2611_; uint8_t v_isShared_2612_; uint8_t v_isSharedCheck_2656_; 
v_a_2609_ = lean_ctor_get(v___x_2608_, 0);
v_isSharedCheck_2656_ = !lean_is_exclusive(v___x_2608_);
if (v_isSharedCheck_2656_ == 0)
{
v___x_2611_ = v___x_2608_;
v_isShared_2612_ = v_isSharedCheck_2656_;
goto v_resetjp_2610_;
}
else
{
lean_inc(v_a_2609_);
lean_dec(v___x_2608_);
v___x_2611_ = lean_box(0);
v_isShared_2612_ = v_isSharedCheck_2656_;
goto v_resetjp_2610_;
}
v_resetjp_2610_:
{
lean_object* v_fst_2613_; lean_object* v_snd_2614_; lean_object* v___x_2616_; uint8_t v_isShared_2617_; uint8_t v_isSharedCheck_2655_; 
v_fst_2613_ = lean_ctor_get(v_a_2609_, 0);
v_snd_2614_ = lean_ctor_get(v_a_2609_, 1);
v_isSharedCheck_2655_ = !lean_is_exclusive(v_a_2609_);
if (v_isSharedCheck_2655_ == 0)
{
v___x_2616_ = v_a_2609_;
v_isShared_2617_ = v_isSharedCheck_2655_;
goto v_resetjp_2615_;
}
else
{
lean_inc(v_snd_2614_);
lean_inc(v_fst_2613_);
lean_dec(v_a_2609_);
v___x_2616_ = lean_box(0);
v_isShared_2617_ = v_isSharedCheck_2655_;
goto v_resetjp_2615_;
}
v_resetjp_2615_:
{
lean_object* v___x_2618_; lean_object* v___x_2619_; lean_object* v___x_2620_; lean_object* v___x_2622_; 
v___x_2618_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__11));
v___x_2619_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_2620_ = l_Lean_JsonNumber_fromNat(v_fst_2593_);
if (v_isShared_2612_ == 0)
{
lean_ctor_set_tag(v___x_2611_, 2);
lean_ctor_set(v___x_2611_, 0, v___x_2620_);
v___x_2622_ = v___x_2611_;
goto v_reusejp_2621_;
}
else
{
lean_object* v_reuseFailAlloc_2654_; 
v_reuseFailAlloc_2654_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2654_, 0, v___x_2620_);
v___x_2622_ = v_reuseFailAlloc_2654_;
goto v_reusejp_2621_;
}
v_reusejp_2621_:
{
lean_object* v___x_2624_; 
if (v_isShared_2617_ == 0)
{
lean_ctor_set(v___x_2616_, 1, v___x_2622_);
lean_ctor_set(v___x_2616_, 0, v___x_2619_);
v___x_2624_ = v___x_2616_;
goto v_reusejp_2623_;
}
else
{
lean_object* v_reuseFailAlloc_2653_; 
v_reuseFailAlloc_2653_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2653_, 0, v___x_2619_);
lean_ctor_set(v_reuseFailAlloc_2653_, 1, v___x_2622_);
v___x_2624_ = v_reuseFailAlloc_2653_;
goto v_reusejp_2623_;
}
v_reusejp_2623_:
{
lean_object* v___x_2625_; lean_object* v___x_2626_; lean_object* v___x_2628_; 
v___x_2625_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_2626_ = l_Lean_JsonNumber_fromNat(v_fst_2603_);
if (v_isShared_2602_ == 0)
{
lean_ctor_set_tag(v___x_2601_, 2);
lean_ctor_set(v___x_2601_, 0, v___x_2626_);
v___x_2628_ = v___x_2601_;
goto v_reusejp_2627_;
}
else
{
lean_object* v_reuseFailAlloc_2652_; 
v_reuseFailAlloc_2652_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2652_, 0, v___x_2626_);
v___x_2628_ = v_reuseFailAlloc_2652_;
goto v_reusejp_2627_;
}
v_reusejp_2627_:
{
lean_object* v___x_2630_; 
if (v_isShared_2607_ == 0)
{
lean_ctor_set(v___x_2606_, 1, v___x_2628_);
lean_ctor_set(v___x_2606_, 0, v___x_2625_);
v___x_2630_ = v___x_2606_;
goto v_reusejp_2629_;
}
else
{
lean_object* v_reuseFailAlloc_2651_; 
v_reuseFailAlloc_2651_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2651_, 0, v___x_2625_);
lean_ctor_set(v_reuseFailAlloc_2651_, 1, v___x_2628_);
v___x_2630_ = v_reuseFailAlloc_2651_;
goto v_reusejp_2629_;
}
v_reusejp_2629_:
{
lean_object* v___x_2631_; lean_object* v___x_2632_; lean_object* v___x_2634_; 
v___x_2631_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__9));
v___x_2632_ = l_Lean_JsonNumber_fromNat(v_fst_2613_);
if (v_isShared_2592_ == 0)
{
lean_ctor_set_tag(v___x_2591_, 2);
lean_ctor_set(v___x_2591_, 0, v___x_2632_);
v___x_2634_ = v___x_2591_;
goto v_reusejp_2633_;
}
else
{
lean_object* v_reuseFailAlloc_2650_; 
v_reuseFailAlloc_2650_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2650_, 0, v___x_2632_);
v___x_2634_ = v_reuseFailAlloc_2650_;
goto v_reusejp_2633_;
}
v_reusejp_2633_:
{
lean_object* v___x_2636_; 
if (v_isShared_2597_ == 0)
{
lean_ctor_set(v___x_2596_, 1, v___x_2634_);
lean_ctor_set(v___x_2596_, 0, v___x_2631_);
v___x_2636_ = v___x_2596_;
goto v_reusejp_2635_;
}
else
{
lean_object* v_reuseFailAlloc_2649_; 
v_reuseFailAlloc_2649_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2649_, 0, v___x_2631_);
lean_ctor_set(v_reuseFailAlloc_2649_, 1, v___x_2634_);
v___x_2636_ = v_reuseFailAlloc_2649_;
goto v_reusejp_2635_;
}
v_reusejp_2635_:
{
lean_object* v___x_2637_; lean_object* v___x_2638_; lean_object* v___x_2639_; lean_object* v___x_2640_; lean_object* v___x_2641_; lean_object* v___x_2642_; lean_object* v___x_2643_; lean_object* v___x_2644_; lean_object* v___x_2645_; lean_object* v___x_2646_; lean_object* v___x_2647_; lean_object* v___x_2648_; 
v___x_2637_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__10));
v___x_2638_ = lp_proofEnvironment_Lean_BinderInfo_toJson(v_binderInfo_2587_);
v___x_2639_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2639_, 0, v___x_2637_);
lean_ctor_set(v___x_2639_, 1, v___x_2638_);
v___x_2640_ = lean_box(0);
v___x_2641_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2641_, 0, v___x_2639_);
lean_ctor_set(v___x_2641_, 1, v___x_2640_);
v___x_2642_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2642_, 0, v___x_2636_);
lean_ctor_set(v___x_2642_, 1, v___x_2641_);
v___x_2643_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2643_, 0, v___x_2630_);
lean_ctor_set(v___x_2643_, 1, v___x_2642_);
v___x_2644_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2644_, 0, v___x_2624_);
lean_ctor_set(v___x_2644_, 1, v___x_2643_);
v___x_2645_ = l_Lean_Json_mkObj(v___x_2644_);
lean_dec_ref_known(v___x_2644_, 2);
v___x_2646_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2646_, 0, v___x_2618_);
lean_ctor_set(v___x_2646_, 1, v___x_2645_);
v___x_2647_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2647_, 0, v___x_2646_);
lean_ctor_set(v___x_2647_, 1, v___x_2640_);
v___x_2648_ = l_Lean_Json_mkObj(v___x_2647_);
lean_dec_ref_known(v___x_2647_, 2);
v_fst_2363_ = v___x_2648_;
v_snd_2364_ = v_snd_2614_;
goto v___jp_2362_;
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2606_);
lean_dec(v_fst_2603_);
lean_del_object(v___x_2601_);
lean_del_object(v___x_2596_);
lean_dec(v_fst_2593_);
lean_del_object(v___x_2591_);
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2608_;
}
}
}
}
else
{
lean_del_object(v___x_2596_);
lean_dec(v_fst_2593_);
lean_del_object(v___x_2591_);
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2598_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2588_;
}
}
case 8:
{
lean_object* v_declName_2661_; lean_object* v_type_2662_; lean_object* v_value_2663_; lean_object* v_body_2664_; uint8_t v_nondep_2665_; lean_object* v___x_2666_; 
v_declName_2661_ = lean_ctor_get(v_e_2302_, 0);
v_type_2662_ = lean_ctor_get(v_e_2302_, 1);
v_value_2663_ = lean_ctor_get(v_e_2302_, 2);
v_body_2664_ = lean_ctor_get(v_e_2302_, 3);
v_nondep_2665_ = lean_ctor_get_uint8(v_e_2302_, sizeof(void*)*4 + 8);
lean_inc(v_declName_2661_);
v___x_2666_ = lp_proofEnvironment_dumpName(v_declName_2661_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2666_) == 0)
{
lean_object* v_a_2667_; lean_object* v___x_2669_; uint8_t v_isShared_2670_; uint8_t v_isSharedCheck_2759_; 
v_a_2667_ = lean_ctor_get(v___x_2666_, 0);
v_isSharedCheck_2759_ = !lean_is_exclusive(v___x_2666_);
if (v_isSharedCheck_2759_ == 0)
{
v___x_2669_ = v___x_2666_;
v_isShared_2670_ = v_isSharedCheck_2759_;
goto v_resetjp_2668_;
}
else
{
lean_inc(v_a_2667_);
lean_dec(v___x_2666_);
v___x_2669_ = lean_box(0);
v_isShared_2670_ = v_isSharedCheck_2759_;
goto v_resetjp_2668_;
}
v_resetjp_2668_:
{
lean_object* v_fst_2671_; lean_object* v_snd_2672_; lean_object* v___x_2674_; uint8_t v_isShared_2675_; uint8_t v_isSharedCheck_2758_; 
v_fst_2671_ = lean_ctor_get(v_a_2667_, 0);
v_snd_2672_ = lean_ctor_get(v_a_2667_, 1);
v_isSharedCheck_2758_ = !lean_is_exclusive(v_a_2667_);
if (v_isSharedCheck_2758_ == 0)
{
v___x_2674_ = v_a_2667_;
v_isShared_2675_ = v_isSharedCheck_2758_;
goto v_resetjp_2673_;
}
else
{
lean_inc(v_snd_2672_);
lean_inc(v_fst_2671_);
lean_dec(v_a_2667_);
v___x_2674_ = lean_box(0);
v_isShared_2675_ = v_isSharedCheck_2758_;
goto v_resetjp_2673_;
}
v_resetjp_2673_:
{
lean_object* v___x_2676_; 
lean_inc_ref(v_type_2662_);
v___x_2676_ = lp_proofEnvironment_dumpExprAux(v_type_2662_, v_a_2303_, v_snd_2672_);
if (lean_obj_tag(v___x_2676_) == 0)
{
lean_object* v_a_2677_; lean_object* v___x_2679_; uint8_t v_isShared_2680_; uint8_t v_isSharedCheck_2757_; 
v_a_2677_ = lean_ctor_get(v___x_2676_, 0);
v_isSharedCheck_2757_ = !lean_is_exclusive(v___x_2676_);
if (v_isSharedCheck_2757_ == 0)
{
v___x_2679_ = v___x_2676_;
v_isShared_2680_ = v_isSharedCheck_2757_;
goto v_resetjp_2678_;
}
else
{
lean_inc(v_a_2677_);
lean_dec(v___x_2676_);
v___x_2679_ = lean_box(0);
v_isShared_2680_ = v_isSharedCheck_2757_;
goto v_resetjp_2678_;
}
v_resetjp_2678_:
{
lean_object* v_fst_2681_; lean_object* v_snd_2682_; lean_object* v___x_2684_; uint8_t v_isShared_2685_; uint8_t v_isSharedCheck_2756_; 
v_fst_2681_ = lean_ctor_get(v_a_2677_, 0);
v_snd_2682_ = lean_ctor_get(v_a_2677_, 1);
v_isSharedCheck_2756_ = !lean_is_exclusive(v_a_2677_);
if (v_isSharedCheck_2756_ == 0)
{
v___x_2684_ = v_a_2677_;
v_isShared_2685_ = v_isSharedCheck_2756_;
goto v_resetjp_2683_;
}
else
{
lean_inc(v_snd_2682_);
lean_inc(v_fst_2681_);
lean_dec(v_a_2677_);
v___x_2684_ = lean_box(0);
v_isShared_2685_ = v_isSharedCheck_2756_;
goto v_resetjp_2683_;
}
v_resetjp_2683_:
{
lean_object* v___x_2686_; 
lean_inc_ref(v_value_2663_);
v___x_2686_ = lp_proofEnvironment_dumpExprAux(v_value_2663_, v_a_2303_, v_snd_2682_);
if (lean_obj_tag(v___x_2686_) == 0)
{
lean_object* v_a_2687_; lean_object* v___x_2689_; uint8_t v_isShared_2690_; uint8_t v_isSharedCheck_2755_; 
v_a_2687_ = lean_ctor_get(v___x_2686_, 0);
v_isSharedCheck_2755_ = !lean_is_exclusive(v___x_2686_);
if (v_isSharedCheck_2755_ == 0)
{
v___x_2689_ = v___x_2686_;
v_isShared_2690_ = v_isSharedCheck_2755_;
goto v_resetjp_2688_;
}
else
{
lean_inc(v_a_2687_);
lean_dec(v___x_2686_);
v___x_2689_ = lean_box(0);
v_isShared_2690_ = v_isSharedCheck_2755_;
goto v_resetjp_2688_;
}
v_resetjp_2688_:
{
lean_object* v_fst_2691_; lean_object* v_snd_2692_; lean_object* v___x_2694_; uint8_t v_isShared_2695_; uint8_t v_isSharedCheck_2754_; 
v_fst_2691_ = lean_ctor_get(v_a_2687_, 0);
v_snd_2692_ = lean_ctor_get(v_a_2687_, 1);
v_isSharedCheck_2754_ = !lean_is_exclusive(v_a_2687_);
if (v_isSharedCheck_2754_ == 0)
{
v___x_2694_ = v_a_2687_;
v_isShared_2695_ = v_isSharedCheck_2754_;
goto v_resetjp_2693_;
}
else
{
lean_inc(v_snd_2692_);
lean_inc(v_fst_2691_);
lean_dec(v_a_2687_);
v___x_2694_ = lean_box(0);
v_isShared_2695_ = v_isSharedCheck_2754_;
goto v_resetjp_2693_;
}
v_resetjp_2693_:
{
lean_object* v___x_2696_; 
lean_inc_ref(v_body_2664_);
v___x_2696_ = lp_proofEnvironment_dumpExprAux(v_body_2664_, v_a_2303_, v_snd_2692_);
if (lean_obj_tag(v___x_2696_) == 0)
{
lean_object* v_a_2697_; lean_object* v___x_2699_; uint8_t v_isShared_2700_; uint8_t v_isSharedCheck_2753_; 
v_a_2697_ = lean_ctor_get(v___x_2696_, 0);
v_isSharedCheck_2753_ = !lean_is_exclusive(v___x_2696_);
if (v_isSharedCheck_2753_ == 0)
{
v___x_2699_ = v___x_2696_;
v_isShared_2700_ = v_isSharedCheck_2753_;
goto v_resetjp_2698_;
}
else
{
lean_inc(v_a_2697_);
lean_dec(v___x_2696_);
v___x_2699_ = lean_box(0);
v_isShared_2700_ = v_isSharedCheck_2753_;
goto v_resetjp_2698_;
}
v_resetjp_2698_:
{
lean_object* v_fst_2701_; lean_object* v_snd_2702_; lean_object* v___x_2704_; uint8_t v_isShared_2705_; uint8_t v_isSharedCheck_2752_; 
v_fst_2701_ = lean_ctor_get(v_a_2697_, 0);
v_snd_2702_ = lean_ctor_get(v_a_2697_, 1);
v_isSharedCheck_2752_ = !lean_is_exclusive(v_a_2697_);
if (v_isSharedCheck_2752_ == 0)
{
v___x_2704_ = v_a_2697_;
v_isShared_2705_ = v_isSharedCheck_2752_;
goto v_resetjp_2703_;
}
else
{
lean_inc(v_snd_2702_);
lean_inc(v_fst_2701_);
lean_dec(v_a_2697_);
v___x_2704_ = lean_box(0);
v_isShared_2705_ = v_isSharedCheck_2752_;
goto v_resetjp_2703_;
}
v_resetjp_2703_:
{
lean_object* v___x_2706_; lean_object* v___x_2707_; lean_object* v___x_2708_; lean_object* v___x_2710_; 
v___x_2706_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__12));
v___x_2707_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_2708_ = l_Lean_JsonNumber_fromNat(v_fst_2671_);
if (v_isShared_2700_ == 0)
{
lean_ctor_set_tag(v___x_2699_, 2);
lean_ctor_set(v___x_2699_, 0, v___x_2708_);
v___x_2710_ = v___x_2699_;
goto v_reusejp_2709_;
}
else
{
lean_object* v_reuseFailAlloc_2751_; 
v_reuseFailAlloc_2751_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2751_, 0, v___x_2708_);
v___x_2710_ = v_reuseFailAlloc_2751_;
goto v_reusejp_2709_;
}
v_reusejp_2709_:
{
lean_object* v___x_2712_; 
if (v_isShared_2705_ == 0)
{
lean_ctor_set(v___x_2704_, 1, v___x_2710_);
lean_ctor_set(v___x_2704_, 0, v___x_2707_);
v___x_2712_ = v___x_2704_;
goto v_reusejp_2711_;
}
else
{
lean_object* v_reuseFailAlloc_2750_; 
v_reuseFailAlloc_2750_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2750_, 0, v___x_2707_);
lean_ctor_set(v_reuseFailAlloc_2750_, 1, v___x_2710_);
v___x_2712_ = v_reuseFailAlloc_2750_;
goto v_reusejp_2711_;
}
v_reusejp_2711_:
{
lean_object* v___x_2713_; lean_object* v___x_2714_; lean_object* v___x_2716_; 
v___x_2713_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_2714_ = l_Lean_JsonNumber_fromNat(v_fst_2681_);
if (v_isShared_2690_ == 0)
{
lean_ctor_set_tag(v___x_2689_, 2);
lean_ctor_set(v___x_2689_, 0, v___x_2714_);
v___x_2716_ = v___x_2689_;
goto v_reusejp_2715_;
}
else
{
lean_object* v_reuseFailAlloc_2749_; 
v_reuseFailAlloc_2749_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2749_, 0, v___x_2714_);
v___x_2716_ = v_reuseFailAlloc_2749_;
goto v_reusejp_2715_;
}
v_reusejp_2715_:
{
lean_object* v___x_2718_; 
if (v_isShared_2695_ == 0)
{
lean_ctor_set(v___x_2694_, 1, v___x_2716_);
lean_ctor_set(v___x_2694_, 0, v___x_2713_);
v___x_2718_ = v___x_2694_;
goto v_reusejp_2717_;
}
else
{
lean_object* v_reuseFailAlloc_2748_; 
v_reuseFailAlloc_2748_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2748_, 0, v___x_2713_);
lean_ctor_set(v_reuseFailAlloc_2748_, 1, v___x_2716_);
v___x_2718_ = v_reuseFailAlloc_2748_;
goto v_reusejp_2717_;
}
v_reusejp_2717_:
{
lean_object* v___x_2719_; lean_object* v___x_2720_; lean_object* v___x_2722_; 
v___x_2719_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__13));
v___x_2720_ = l_Lean_JsonNumber_fromNat(v_fst_2691_);
if (v_isShared_2680_ == 0)
{
lean_ctor_set_tag(v___x_2679_, 2);
lean_ctor_set(v___x_2679_, 0, v___x_2720_);
v___x_2722_ = v___x_2679_;
goto v_reusejp_2721_;
}
else
{
lean_object* v_reuseFailAlloc_2747_; 
v_reuseFailAlloc_2747_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2747_, 0, v___x_2720_);
v___x_2722_ = v_reuseFailAlloc_2747_;
goto v_reusejp_2721_;
}
v_reusejp_2721_:
{
lean_object* v___x_2724_; 
if (v_isShared_2685_ == 0)
{
lean_ctor_set(v___x_2684_, 1, v___x_2722_);
lean_ctor_set(v___x_2684_, 0, v___x_2719_);
v___x_2724_ = v___x_2684_;
goto v_reusejp_2723_;
}
else
{
lean_object* v_reuseFailAlloc_2746_; 
v_reuseFailAlloc_2746_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2746_, 0, v___x_2719_);
lean_ctor_set(v_reuseFailAlloc_2746_, 1, v___x_2722_);
v___x_2724_ = v_reuseFailAlloc_2746_;
goto v_reusejp_2723_;
}
v_reusejp_2723_:
{
lean_object* v___x_2725_; lean_object* v___x_2726_; lean_object* v___x_2728_; 
v___x_2725_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__9));
v___x_2726_ = l_Lean_JsonNumber_fromNat(v_fst_2701_);
if (v_isShared_2670_ == 0)
{
lean_ctor_set_tag(v___x_2669_, 2);
lean_ctor_set(v___x_2669_, 0, v___x_2726_);
v___x_2728_ = v___x_2669_;
goto v_reusejp_2727_;
}
else
{
lean_object* v_reuseFailAlloc_2745_; 
v_reuseFailAlloc_2745_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2745_, 0, v___x_2726_);
v___x_2728_ = v_reuseFailAlloc_2745_;
goto v_reusejp_2727_;
}
v_reusejp_2727_:
{
lean_object* v___x_2730_; 
if (v_isShared_2675_ == 0)
{
lean_ctor_set(v___x_2674_, 1, v___x_2728_);
lean_ctor_set(v___x_2674_, 0, v___x_2725_);
v___x_2730_ = v___x_2674_;
goto v_reusejp_2729_;
}
else
{
lean_object* v_reuseFailAlloc_2744_; 
v_reuseFailAlloc_2744_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2744_, 0, v___x_2725_);
lean_ctor_set(v_reuseFailAlloc_2744_, 1, v___x_2728_);
v___x_2730_ = v_reuseFailAlloc_2744_;
goto v_reusejp_2729_;
}
v_reusejp_2729_:
{
lean_object* v___x_2731_; lean_object* v___x_2732_; lean_object* v___x_2733_; lean_object* v___x_2734_; lean_object* v___x_2735_; lean_object* v___x_2736_; lean_object* v___x_2737_; lean_object* v___x_2738_; lean_object* v___x_2739_; lean_object* v___x_2740_; lean_object* v___x_2741_; lean_object* v___x_2742_; lean_object* v___x_2743_; 
v___x_2731_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__14));
v___x_2732_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_2732_, 0, v_nondep_2665_);
v___x_2733_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2733_, 0, v___x_2731_);
lean_ctor_set(v___x_2733_, 1, v___x_2732_);
v___x_2734_ = lean_box(0);
v___x_2735_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2735_, 0, v___x_2733_);
lean_ctor_set(v___x_2735_, 1, v___x_2734_);
v___x_2736_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2736_, 0, v___x_2730_);
lean_ctor_set(v___x_2736_, 1, v___x_2735_);
v___x_2737_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2737_, 0, v___x_2724_);
lean_ctor_set(v___x_2737_, 1, v___x_2736_);
v___x_2738_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2738_, 0, v___x_2718_);
lean_ctor_set(v___x_2738_, 1, v___x_2737_);
v___x_2739_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2739_, 0, v___x_2712_);
lean_ctor_set(v___x_2739_, 1, v___x_2738_);
v___x_2740_ = l_Lean_Json_mkObj(v___x_2739_);
lean_dec_ref_known(v___x_2739_, 2);
v___x_2741_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2741_, 0, v___x_2706_);
lean_ctor_set(v___x_2741_, 1, v___x_2740_);
v___x_2742_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2742_, 0, v___x_2741_);
lean_ctor_set(v___x_2742_, 1, v___x_2734_);
v___x_2743_ = l_Lean_Json_mkObj(v___x_2742_);
lean_dec_ref_known(v___x_2742_, 2);
v_fst_2363_ = v___x_2743_;
v_snd_2364_ = v_snd_2702_;
goto v___jp_2362_;
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2694_);
lean_dec(v_fst_2691_);
lean_del_object(v___x_2689_);
lean_del_object(v___x_2684_);
lean_dec(v_fst_2681_);
lean_del_object(v___x_2679_);
lean_del_object(v___x_2674_);
lean_dec(v_fst_2671_);
lean_del_object(v___x_2669_);
lean_dec_ref_known(v_e_2302_, 4);
return v___x_2696_;
}
}
}
}
else
{
lean_del_object(v___x_2684_);
lean_dec(v_fst_2681_);
lean_del_object(v___x_2679_);
lean_del_object(v___x_2674_);
lean_dec(v_fst_2671_);
lean_del_object(v___x_2669_);
lean_dec_ref_known(v_e_2302_, 4);
return v___x_2686_;
}
}
}
}
else
{
lean_del_object(v___x_2674_);
lean_dec(v_fst_2671_);
lean_del_object(v___x_2669_);
lean_dec_ref_known(v_e_2302_, 4);
return v___x_2676_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 4);
return v___x_2666_;
}
}
case 9:
{
lean_object* v_a_2760_; 
v_a_2760_ = lean_ctor_get(v_e_2302_, 0);
lean_inc_ref(v_a_2760_);
if (lean_obj_tag(v_a_2760_) == 0)
{
lean_object* v_val_2761_; lean_object* v___x_2763_; uint8_t v_isShared_2764_; uint8_t v_isSharedCheck_2792_; 
v_val_2761_ = lean_ctor_get(v_a_2760_, 0);
v_isSharedCheck_2792_ = !lean_is_exclusive(v_a_2760_);
if (v_isSharedCheck_2792_ == 0)
{
v___x_2763_ = v_a_2760_;
v_isShared_2764_ = v_isSharedCheck_2792_;
goto v_resetjp_2762_;
}
else
{
lean_inc(v_val_2761_);
lean_dec(v_a_2760_);
v___x_2763_ = lean_box(0);
v_isShared_2764_ = v_isSharedCheck_2792_;
goto v_resetjp_2762_;
}
v_resetjp_2762_:
{
lean_object* v___x_2765_; 
v___x_2765_ = lp_proofEnvironment_dumpExprAux_dumpNatDeps(v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2765_) == 0)
{
lean_object* v_a_2766_; lean_object* v_snd_2767_; lean_object* v___x_2769_; uint8_t v_isShared_2770_; uint8_t v_isSharedCheck_2782_; 
v_a_2766_ = lean_ctor_get(v___x_2765_, 0);
lean_inc(v_a_2766_);
lean_dec_ref_known(v___x_2765_, 1);
v_snd_2767_ = lean_ctor_get(v_a_2766_, 1);
v_isSharedCheck_2782_ = !lean_is_exclusive(v_a_2766_);
if (v_isSharedCheck_2782_ == 0)
{
lean_object* v_unused_2783_; 
v_unused_2783_ = lean_ctor_get(v_a_2766_, 0);
lean_dec(v_unused_2783_);
v___x_2769_ = v_a_2766_;
v_isShared_2770_ = v_isSharedCheck_2782_;
goto v_resetjp_2768_;
}
else
{
lean_inc(v_snd_2767_);
lean_dec(v_a_2766_);
v___x_2769_ = lean_box(0);
v_isShared_2770_ = v_isSharedCheck_2782_;
goto v_resetjp_2768_;
}
v_resetjp_2768_:
{
lean_object* v___x_2771_; lean_object* v___x_2772_; lean_object* v___x_2774_; 
v___x_2771_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__15));
v___x_2772_ = l_Nat_reprFast(v_val_2761_);
if (v_isShared_2764_ == 0)
{
lean_ctor_set_tag(v___x_2763_, 3);
lean_ctor_set(v___x_2763_, 0, v___x_2772_);
v___x_2774_ = v___x_2763_;
goto v_reusejp_2773_;
}
else
{
lean_object* v_reuseFailAlloc_2781_; 
v_reuseFailAlloc_2781_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2781_, 0, v___x_2772_);
v___x_2774_ = v_reuseFailAlloc_2781_;
goto v_reusejp_2773_;
}
v_reusejp_2773_:
{
lean_object* v___x_2776_; 
if (v_isShared_2770_ == 0)
{
lean_ctor_set(v___x_2769_, 1, v___x_2774_);
lean_ctor_set(v___x_2769_, 0, v___x_2771_);
v___x_2776_ = v___x_2769_;
goto v_reusejp_2775_;
}
else
{
lean_object* v_reuseFailAlloc_2780_; 
v_reuseFailAlloc_2780_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2780_, 0, v___x_2771_);
lean_ctor_set(v_reuseFailAlloc_2780_, 1, v___x_2774_);
v___x_2776_ = v_reuseFailAlloc_2780_;
goto v_reusejp_2775_;
}
v_reusejp_2775_:
{
lean_object* v___x_2777_; lean_object* v___x_2778_; lean_object* v___x_2779_; 
v___x_2777_ = lean_box(0);
v___x_2778_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2778_, 0, v___x_2776_);
lean_ctor_set(v___x_2778_, 1, v___x_2777_);
v___x_2779_ = l_Lean_Json_mkObj(v___x_2778_);
lean_dec_ref_known(v___x_2778_, 2);
v_fst_2363_ = v___x_2779_;
v_snd_2364_ = v_snd_2767_;
goto v___jp_2362_;
}
}
}
}
else
{
lean_object* v_a_2784_; lean_object* v___x_2786_; uint8_t v_isShared_2787_; uint8_t v_isSharedCheck_2791_; 
lean_del_object(v___x_2763_);
lean_dec(v_val_2761_);
lean_dec_ref_known(v_e_2302_, 1);
v_a_2784_ = lean_ctor_get(v___x_2765_, 0);
v_isSharedCheck_2791_ = !lean_is_exclusive(v___x_2765_);
if (v_isSharedCheck_2791_ == 0)
{
v___x_2786_ = v___x_2765_;
v_isShared_2787_ = v_isSharedCheck_2791_;
goto v_resetjp_2785_;
}
else
{
lean_inc(v_a_2784_);
lean_dec(v___x_2765_);
v___x_2786_ = lean_box(0);
v_isShared_2787_ = v_isSharedCheck_2791_;
goto v_resetjp_2785_;
}
v_resetjp_2785_:
{
lean_object* v___x_2789_; 
if (v_isShared_2787_ == 0)
{
v___x_2789_ = v___x_2786_;
goto v_reusejp_2788_;
}
else
{
lean_object* v_reuseFailAlloc_2790_; 
v_reuseFailAlloc_2790_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2790_, 0, v_a_2784_);
v___x_2789_ = v_reuseFailAlloc_2790_;
goto v_reusejp_2788_;
}
v_reusejp_2788_:
{
return v___x_2789_;
}
}
}
}
}
else
{
lean_object* v_val_2793_; lean_object* v___x_2795_; uint8_t v_isShared_2796_; uint8_t v_isSharedCheck_2823_; 
v_val_2793_ = lean_ctor_get(v_a_2760_, 0);
v_isSharedCheck_2823_ = !lean_is_exclusive(v_a_2760_);
if (v_isSharedCheck_2823_ == 0)
{
v___x_2795_ = v_a_2760_;
v_isShared_2796_ = v_isSharedCheck_2823_;
goto v_resetjp_2794_;
}
else
{
lean_inc(v_val_2793_);
lean_dec(v_a_2760_);
v___x_2795_ = lean_box(0);
v_isShared_2796_ = v_isSharedCheck_2823_;
goto v_resetjp_2794_;
}
v_resetjp_2794_:
{
lean_object* v___x_2797_; 
v___x_2797_ = lp_proofEnvironment_dumpExprAux_dumpStrDeps(v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2797_) == 0)
{
lean_object* v_a_2798_; lean_object* v_snd_2799_; lean_object* v___x_2801_; uint8_t v_isShared_2802_; uint8_t v_isSharedCheck_2813_; 
v_a_2798_ = lean_ctor_get(v___x_2797_, 0);
lean_inc(v_a_2798_);
lean_dec_ref_known(v___x_2797_, 1);
v_snd_2799_ = lean_ctor_get(v_a_2798_, 1);
v_isSharedCheck_2813_ = !lean_is_exclusive(v_a_2798_);
if (v_isSharedCheck_2813_ == 0)
{
lean_object* v_unused_2814_; 
v_unused_2814_ = lean_ctor_get(v_a_2798_, 0);
lean_dec(v_unused_2814_);
v___x_2801_ = v_a_2798_;
v_isShared_2802_ = v_isSharedCheck_2813_;
goto v_resetjp_2800_;
}
else
{
lean_inc(v_snd_2799_);
lean_dec(v_a_2798_);
v___x_2801_ = lean_box(0);
v_isShared_2802_ = v_isSharedCheck_2813_;
goto v_resetjp_2800_;
}
v_resetjp_2800_:
{
lean_object* v___x_2803_; lean_object* v___x_2805_; 
v___x_2803_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__16));
if (v_isShared_2796_ == 0)
{
lean_ctor_set_tag(v___x_2795_, 3);
v___x_2805_ = v___x_2795_;
goto v_reusejp_2804_;
}
else
{
lean_object* v_reuseFailAlloc_2812_; 
v_reuseFailAlloc_2812_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2812_, 0, v_val_2793_);
v___x_2805_ = v_reuseFailAlloc_2812_;
goto v_reusejp_2804_;
}
v_reusejp_2804_:
{
lean_object* v___x_2807_; 
if (v_isShared_2802_ == 0)
{
lean_ctor_set(v___x_2801_, 1, v___x_2805_);
lean_ctor_set(v___x_2801_, 0, v___x_2803_);
v___x_2807_ = v___x_2801_;
goto v_reusejp_2806_;
}
else
{
lean_object* v_reuseFailAlloc_2811_; 
v_reuseFailAlloc_2811_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2811_, 0, v___x_2803_);
lean_ctor_set(v_reuseFailAlloc_2811_, 1, v___x_2805_);
v___x_2807_ = v_reuseFailAlloc_2811_;
goto v_reusejp_2806_;
}
v_reusejp_2806_:
{
lean_object* v___x_2808_; lean_object* v___x_2809_; lean_object* v___x_2810_; 
v___x_2808_ = lean_box(0);
v___x_2809_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2809_, 0, v___x_2807_);
lean_ctor_set(v___x_2809_, 1, v___x_2808_);
v___x_2810_ = l_Lean_Json_mkObj(v___x_2809_);
lean_dec_ref_known(v___x_2809_, 2);
v_fst_2363_ = v___x_2810_;
v_snd_2364_ = v_snd_2799_;
goto v___jp_2362_;
}
}
}
}
else
{
lean_object* v_a_2815_; lean_object* v___x_2817_; uint8_t v_isShared_2818_; uint8_t v_isSharedCheck_2822_; 
lean_del_object(v___x_2795_);
lean_dec_ref(v_val_2793_);
lean_dec_ref_known(v_e_2302_, 1);
v_a_2815_ = lean_ctor_get(v___x_2797_, 0);
v_isSharedCheck_2822_ = !lean_is_exclusive(v___x_2797_);
if (v_isSharedCheck_2822_ == 0)
{
v___x_2817_ = v___x_2797_;
v_isShared_2818_ = v_isSharedCheck_2822_;
goto v_resetjp_2816_;
}
else
{
lean_inc(v_a_2815_);
lean_dec(v___x_2797_);
v___x_2817_ = lean_box(0);
v_isShared_2818_ = v_isSharedCheck_2822_;
goto v_resetjp_2816_;
}
v_resetjp_2816_:
{
lean_object* v___x_2820_; 
if (v_isShared_2818_ == 0)
{
v___x_2820_ = v___x_2817_;
goto v_reusejp_2819_;
}
else
{
lean_object* v_reuseFailAlloc_2821_; 
v_reuseFailAlloc_2821_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2821_, 0, v_a_2815_);
v___x_2820_ = v_reuseFailAlloc_2821_;
goto v_reusejp_2819_;
}
v_reusejp_2819_:
{
return v___x_2820_;
}
}
}
}
}
}
case 10:
{
lean_object* v_data_2824_; lean_object* v_expr_2825_; lean_object* v___x_2826_; 
v_data_2824_ = lean_ctor_get(v_e_2302_, 0);
v_expr_2825_ = lean_ctor_get(v_e_2302_, 1);
lean_inc_ref(v_expr_2825_);
v___x_2826_ = lp_proofEnvironment_dumpExprAux(v_expr_2825_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2826_) == 0)
{
lean_object* v_a_2827_; lean_object* v___x_2829_; uint8_t v_isShared_2830_; uint8_t v_isSharedCheck_2856_; 
v_a_2827_ = lean_ctor_get(v___x_2826_, 0);
v_isSharedCheck_2856_ = !lean_is_exclusive(v___x_2826_);
if (v_isSharedCheck_2856_ == 0)
{
v___x_2829_ = v___x_2826_;
v_isShared_2830_ = v_isSharedCheck_2856_;
goto v_resetjp_2828_;
}
else
{
lean_inc(v_a_2827_);
lean_dec(v___x_2826_);
v___x_2829_ = lean_box(0);
v_isShared_2830_ = v_isSharedCheck_2856_;
goto v_resetjp_2828_;
}
v_resetjp_2828_:
{
lean_object* v_fst_2831_; lean_object* v_snd_2832_; lean_object* v___x_2834_; uint8_t v_isShared_2835_; uint8_t v_isSharedCheck_2855_; 
v_fst_2831_ = lean_ctor_get(v_a_2827_, 0);
v_snd_2832_ = lean_ctor_get(v_a_2827_, 1);
v_isSharedCheck_2855_ = !lean_is_exclusive(v_a_2827_);
if (v_isSharedCheck_2855_ == 0)
{
v___x_2834_ = v_a_2827_;
v_isShared_2835_ = v_isSharedCheck_2855_;
goto v_resetjp_2833_;
}
else
{
lean_inc(v_snd_2832_);
lean_inc(v_fst_2831_);
lean_dec(v_a_2827_);
v___x_2834_ = lean_box(0);
v_isShared_2835_ = v_isSharedCheck_2855_;
goto v_resetjp_2833_;
}
v_resetjp_2833_:
{
lean_object* v___x_2836_; lean_object* v___x_2837_; lean_object* v___x_2838_; lean_object* v___x_2840_; 
v___x_2836_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__17));
v___x_2837_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__18));
lean_inc(v_data_2824_);
v___x_2838_ = lp_proofEnvironment_Lean_KVMap_toJson(v_data_2824_);
if (v_isShared_2835_ == 0)
{
lean_ctor_set(v___x_2834_, 1, v___x_2838_);
lean_ctor_set(v___x_2834_, 0, v___x_2837_);
v___x_2840_ = v___x_2834_;
goto v_reusejp_2839_;
}
else
{
lean_object* v_reuseFailAlloc_2854_; 
v_reuseFailAlloc_2854_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2854_, 0, v___x_2837_);
lean_ctor_set(v_reuseFailAlloc_2854_, 1, v___x_2838_);
v___x_2840_ = v_reuseFailAlloc_2854_;
goto v_reusejp_2839_;
}
v_reusejp_2839_:
{
lean_object* v___x_2841_; lean_object* v___x_2842_; lean_object* v___x_2844_; 
v___x_2841_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__19));
v___x_2842_ = l_Lean_JsonNumber_fromNat(v_fst_2831_);
if (v_isShared_2830_ == 0)
{
lean_ctor_set_tag(v___x_2829_, 2);
lean_ctor_set(v___x_2829_, 0, v___x_2842_);
v___x_2844_ = v___x_2829_;
goto v_reusejp_2843_;
}
else
{
lean_object* v_reuseFailAlloc_2853_; 
v_reuseFailAlloc_2853_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2853_, 0, v___x_2842_);
v___x_2844_ = v_reuseFailAlloc_2853_;
goto v_reusejp_2843_;
}
v_reusejp_2843_:
{
lean_object* v___x_2845_; lean_object* v___x_2846_; lean_object* v___x_2847_; lean_object* v___x_2848_; lean_object* v___x_2849_; lean_object* v___x_2850_; lean_object* v___x_2851_; lean_object* v___x_2852_; 
v___x_2845_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2845_, 0, v___x_2841_);
lean_ctor_set(v___x_2845_, 1, v___x_2844_);
v___x_2846_ = lean_box(0);
v___x_2847_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2847_, 0, v___x_2845_);
lean_ctor_set(v___x_2847_, 1, v___x_2846_);
v___x_2848_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2848_, 0, v___x_2840_);
lean_ctor_set(v___x_2848_, 1, v___x_2847_);
v___x_2849_ = l_Lean_Json_mkObj(v___x_2848_);
lean_dec_ref_known(v___x_2848_, 2);
v___x_2850_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2850_, 0, v___x_2836_);
lean_ctor_set(v___x_2850_, 1, v___x_2849_);
v___x_2851_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2851_, 0, v___x_2850_);
lean_ctor_set(v___x_2851_, 1, v___x_2846_);
v___x_2852_ = l_Lean_Json_mkObj(v___x_2851_);
lean_dec_ref_known(v___x_2851_, 2);
v_fst_2363_ = v___x_2852_;
v_snd_2364_ = v_snd_2832_;
goto v___jp_2362_;
}
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 2);
return v___x_2826_;
}
}
case 11:
{
lean_object* v_typeName_2857_; lean_object* v_idx_2858_; lean_object* v_struct_2859_; lean_object* v___x_2860_; 
v_typeName_2857_ = lean_ctor_get(v_e_2302_, 0);
v_idx_2858_ = lean_ctor_get(v_e_2302_, 1);
v_struct_2859_ = lean_ctor_get(v_e_2302_, 2);
lean_inc(v_typeName_2857_);
v___x_2860_ = lp_proofEnvironment_dumpName(v_typeName_2857_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2860_) == 0)
{
lean_object* v_a_2861_; lean_object* v___x_2863_; uint8_t v_isShared_2864_; uint8_t v_isSharedCheck_2912_; 
v_a_2861_ = lean_ctor_get(v___x_2860_, 0);
v_isSharedCheck_2912_ = !lean_is_exclusive(v___x_2860_);
if (v_isSharedCheck_2912_ == 0)
{
v___x_2863_ = v___x_2860_;
v_isShared_2864_ = v_isSharedCheck_2912_;
goto v_resetjp_2862_;
}
else
{
lean_inc(v_a_2861_);
lean_dec(v___x_2860_);
v___x_2863_ = lean_box(0);
v_isShared_2864_ = v_isSharedCheck_2912_;
goto v_resetjp_2862_;
}
v_resetjp_2862_:
{
lean_object* v_fst_2865_; lean_object* v_snd_2866_; lean_object* v___x_2868_; uint8_t v_isShared_2869_; uint8_t v_isSharedCheck_2911_; 
v_fst_2865_ = lean_ctor_get(v_a_2861_, 0);
v_snd_2866_ = lean_ctor_get(v_a_2861_, 1);
v_isSharedCheck_2911_ = !lean_is_exclusive(v_a_2861_);
if (v_isSharedCheck_2911_ == 0)
{
v___x_2868_ = v_a_2861_;
v_isShared_2869_ = v_isSharedCheck_2911_;
goto v_resetjp_2867_;
}
else
{
lean_inc(v_snd_2866_);
lean_inc(v_fst_2865_);
lean_dec(v_a_2861_);
v___x_2868_ = lean_box(0);
v_isShared_2869_ = v_isSharedCheck_2911_;
goto v_resetjp_2867_;
}
v_resetjp_2867_:
{
lean_object* v___x_2870_; 
lean_inc_ref(v_struct_2859_);
v___x_2870_ = lp_proofEnvironment_dumpExprAux(v_struct_2859_, v_a_2303_, v_snd_2866_);
if (lean_obj_tag(v___x_2870_) == 0)
{
lean_object* v_a_2871_; lean_object* v___x_2873_; uint8_t v_isShared_2874_; uint8_t v_isSharedCheck_2910_; 
v_a_2871_ = lean_ctor_get(v___x_2870_, 0);
v_isSharedCheck_2910_ = !lean_is_exclusive(v___x_2870_);
if (v_isSharedCheck_2910_ == 0)
{
v___x_2873_ = v___x_2870_;
v_isShared_2874_ = v_isSharedCheck_2910_;
goto v_resetjp_2872_;
}
else
{
lean_inc(v_a_2871_);
lean_dec(v___x_2870_);
v___x_2873_ = lean_box(0);
v_isShared_2874_ = v_isSharedCheck_2910_;
goto v_resetjp_2872_;
}
v_resetjp_2872_:
{
lean_object* v_fst_2875_; lean_object* v_snd_2876_; lean_object* v___x_2878_; uint8_t v_isShared_2879_; uint8_t v_isSharedCheck_2909_; 
v_fst_2875_ = lean_ctor_get(v_a_2871_, 0);
v_snd_2876_ = lean_ctor_get(v_a_2871_, 1);
v_isSharedCheck_2909_ = !lean_is_exclusive(v_a_2871_);
if (v_isSharedCheck_2909_ == 0)
{
v___x_2878_ = v_a_2871_;
v_isShared_2879_ = v_isSharedCheck_2909_;
goto v_resetjp_2877_;
}
else
{
lean_inc(v_snd_2876_);
lean_inc(v_fst_2875_);
lean_dec(v_a_2871_);
v___x_2878_ = lean_box(0);
v_isShared_2879_ = v_isSharedCheck_2909_;
goto v_resetjp_2877_;
}
v_resetjp_2877_:
{
lean_object* v___x_2880_; lean_object* v___x_2881_; lean_object* v___x_2882_; lean_object* v___x_2884_; 
v___x_2880_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__20));
v___x_2881_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__21));
v___x_2882_ = l_Lean_JsonNumber_fromNat(v_fst_2865_);
if (v_isShared_2874_ == 0)
{
lean_ctor_set_tag(v___x_2873_, 2);
lean_ctor_set(v___x_2873_, 0, v___x_2882_);
v___x_2884_ = v___x_2873_;
goto v_reusejp_2883_;
}
else
{
lean_object* v_reuseFailAlloc_2908_; 
v_reuseFailAlloc_2908_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2908_, 0, v___x_2882_);
v___x_2884_ = v_reuseFailAlloc_2908_;
goto v_reusejp_2883_;
}
v_reusejp_2883_:
{
lean_object* v___x_2886_; 
if (v_isShared_2879_ == 0)
{
lean_ctor_set(v___x_2878_, 1, v___x_2884_);
lean_ctor_set(v___x_2878_, 0, v___x_2881_);
v___x_2886_ = v___x_2878_;
goto v_reusejp_2885_;
}
else
{
lean_object* v_reuseFailAlloc_2907_; 
v_reuseFailAlloc_2907_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2907_, 0, v___x_2881_);
lean_ctor_set(v_reuseFailAlloc_2907_, 1, v___x_2884_);
v___x_2886_ = v_reuseFailAlloc_2907_;
goto v_reusejp_2885_;
}
v_reusejp_2885_:
{
lean_object* v___x_2887_; lean_object* v___x_2888_; lean_object* v___x_2890_; 
v___x_2887_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__22));
lean_inc(v_idx_2858_);
v___x_2888_ = l_Lean_JsonNumber_fromNat(v_idx_2858_);
if (v_isShared_2864_ == 0)
{
lean_ctor_set_tag(v___x_2863_, 2);
lean_ctor_set(v___x_2863_, 0, v___x_2888_);
v___x_2890_ = v___x_2863_;
goto v_reusejp_2889_;
}
else
{
lean_object* v_reuseFailAlloc_2906_; 
v_reuseFailAlloc_2906_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2906_, 0, v___x_2888_);
v___x_2890_ = v_reuseFailAlloc_2906_;
goto v_reusejp_2889_;
}
v_reusejp_2889_:
{
lean_object* v___x_2892_; 
if (v_isShared_2869_ == 0)
{
lean_ctor_set(v___x_2868_, 1, v___x_2890_);
lean_ctor_set(v___x_2868_, 0, v___x_2887_);
v___x_2892_ = v___x_2868_;
goto v_reusejp_2891_;
}
else
{
lean_object* v_reuseFailAlloc_2905_; 
v_reuseFailAlloc_2905_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2905_, 0, v___x_2887_);
lean_ctor_set(v_reuseFailAlloc_2905_, 1, v___x_2890_);
v___x_2892_ = v_reuseFailAlloc_2905_;
goto v_reusejp_2891_;
}
v_reusejp_2891_:
{
lean_object* v___x_2893_; lean_object* v___x_2894_; lean_object* v___x_2895_; lean_object* v___x_2896_; lean_object* v___x_2897_; lean_object* v___x_2898_; lean_object* v___x_2899_; lean_object* v___x_2900_; lean_object* v___x_2901_; lean_object* v___x_2902_; lean_object* v___x_2903_; lean_object* v___x_2904_; 
v___x_2893_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__23));
v___x_2894_ = l_Lean_JsonNumber_fromNat(v_fst_2875_);
v___x_2895_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2895_, 0, v___x_2894_);
v___x_2896_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2896_, 0, v___x_2893_);
lean_ctor_set(v___x_2896_, 1, v___x_2895_);
v___x_2897_ = lean_box(0);
v___x_2898_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2898_, 0, v___x_2896_);
lean_ctor_set(v___x_2898_, 1, v___x_2897_);
v___x_2899_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2899_, 0, v___x_2892_);
lean_ctor_set(v___x_2899_, 1, v___x_2898_);
v___x_2900_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2900_, 0, v___x_2886_);
lean_ctor_set(v___x_2900_, 1, v___x_2899_);
v___x_2901_ = l_Lean_Json_mkObj(v___x_2900_);
lean_dec_ref_known(v___x_2900_, 2);
v___x_2902_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2902_, 0, v___x_2880_);
lean_ctor_set(v___x_2902_, 1, v___x_2901_);
v___x_2903_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2903_, 0, v___x_2902_);
lean_ctor_set(v___x_2903_, 1, v___x_2897_);
v___x_2904_ = l_Lean_Json_mkObj(v___x_2903_);
lean_dec_ref_known(v___x_2903_, 2);
v_fst_2363_ = v___x_2904_;
v_snd_2364_ = v_snd_2876_;
goto v___jp_2362_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_2868_);
lean_dec(v_fst_2865_);
lean_del_object(v___x_2863_);
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2870_;
}
}
}
}
else
{
lean_dec_ref_known(v_e_2302_, 3);
return v___x_2860_;
}
}
default: 
{
lean_object* v___x_2913_; lean_object* v___x_2914_; 
v___x_2913_ = lean_obj_once(&lp_proofEnvironment_dumpExprAux___closed__26, &lp_proofEnvironment_dumpExprAux___closed__26_once, _init_lp_proofEnvironment_dumpExprAux___closed__26);
v___x_2914_ = lp_proofEnvironment_panic___at___00dumpName_spec__0(v___x_2913_, v_a_2303_, v_a_2304_);
if (lean_obj_tag(v___x_2914_) == 0)
{
lean_object* v_a_2915_; lean_object* v_fst_2916_; lean_object* v_snd_2917_; 
v_a_2915_ = lean_ctor_get(v___x_2914_, 0);
lean_inc(v_a_2915_);
lean_dec_ref_known(v___x_2914_, 1);
v_fst_2916_ = lean_ctor_get(v_a_2915_, 0);
lean_inc(v_fst_2916_);
v_snd_2917_ = lean_ctor_get(v_a_2915_, 1);
lean_inc(v_snd_2917_);
lean_dec(v_a_2915_);
v_fst_2363_ = v_fst_2916_;
v_snd_2364_ = v_snd_2917_;
goto v___jp_2362_;
}
else
{
lean_object* v_a_2918_; lean_object* v___x_2920_; uint8_t v_isShared_2921_; uint8_t v_isSharedCheck_2925_; 
lean_dec_ref(v_e_2302_);
v_a_2918_ = lean_ctor_get(v___x_2914_, 0);
v_isSharedCheck_2925_ = !lean_is_exclusive(v___x_2914_);
if (v_isSharedCheck_2925_ == 0)
{
v___x_2920_ = v___x_2914_;
v_isShared_2921_ = v_isSharedCheck_2925_;
goto v_resetjp_2919_;
}
else
{
lean_inc(v_a_2918_);
lean_dec(v___x_2914_);
v___x_2920_ = lean_box(0);
v_isShared_2921_ = v_isSharedCheck_2925_;
goto v_resetjp_2919_;
}
v_resetjp_2919_:
{
lean_object* v___x_2923_; 
if (v_isShared_2921_ == 0)
{
v___x_2923_ = v___x_2920_;
goto v_reusejp_2922_;
}
else
{
lean_object* v_reuseFailAlloc_2924_; 
v_reuseFailAlloc_2924_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2924_, 0, v_a_2918_);
v___x_2923_ = v_reuseFailAlloc_2924_;
goto v_reusejp_2922_;
}
v_reusejp_2922_:
{
return v___x_2923_;
}
}
}
}
}
v___jp_2326_:
{
lean_object* v_size_2337_; lean_object* v___x_2338_; lean_object* v___x_2339_; lean_object* v___x_2340_; lean_object* v___x_2341_; lean_object* v___x_2342_; 
v_size_2337_ = lean_ctor_get(v_visitedExprs_2330_, 0);
lean_inc_n(v_size_2337_, 2);
v___x_2338_ = l_Lean_JsonNumber_fromNat(v_size_2337_);
v___x_2339_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2339_, 0, v___x_2338_);
v___x_2340_ = l_Lean_Json_setObjVal_x21(v_fst_2327_, v___x_2325_, v___x_2339_);
v___x_2341_ = l_Lean_Json_compress(v___x_2340_);
v___x_2342_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_2341_);
if (lean_obj_tag(v___x_2342_) == 0)
{
lean_object* v___x_2344_; uint8_t v_isShared_2345_; uint8_t v_isSharedCheck_2352_; 
v_isSharedCheck_2352_ = !lean_is_exclusive(v___x_2342_);
if (v_isSharedCheck_2352_ == 0)
{
lean_object* v_unused_2353_; 
v_unused_2353_ = lean_ctor_get(v___x_2342_, 0);
lean_dec(v_unused_2353_);
v___x_2344_ = v___x_2342_;
v_isShared_2345_ = v_isSharedCheck_2352_;
goto v_resetjp_2343_;
}
else
{
lean_dec(v___x_2342_);
v___x_2344_ = lean_box(0);
v_isShared_2345_ = v_isSharedCheck_2352_;
goto v_resetjp_2343_;
}
v_resetjp_2343_:
{
lean_object* v___x_2346_; lean_object* v___x_2347_; lean_object* v___x_2348_; lean_object* v___x_2350_; 
lean_inc(v_size_2337_);
v___x_2346_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_Lean_Meta_ForEachExpr_0__Lean_Meta_forEachExpr_x27_visit___at___00Lean_Meta_forEachExpr_x27___at___00__private_Lean_Linter_Extra_UnusedDecidableInType_0__Lean_Linter_Extra_UnusedDecidableInType_collectFVarsOutsideOfProofs_spec__0_spec__0_spec__2___redArg(v_visitedExprs_2330_, v_e_2302_, v_size_2337_);
v___x_2347_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v___x_2347_, 0, v_visitedNames_2328_);
lean_ctor_set(v___x_2347_, 1, v_visitedLevels_2329_);
lean_ctor_set(v___x_2347_, 2, v___x_2346_);
lean_ctor_set(v___x_2347_, 3, v_visitedConstants_2331_);
lean_ctor_set(v___x_2347_, 4, v_noMDataExprs_2332_);
lean_ctor_set(v___x_2347_, 5, v_recursorMap_2336_);
lean_ctor_set_uint8(v___x_2347_, sizeof(void*)*6, v_exportMData_2333_);
lean_ctor_set_uint8(v___x_2347_, sizeof(void*)*6 + 1, v_exportUnsafe_2334_);
lean_ctor_set_uint8(v___x_2347_, sizeof(void*)*6 + 2, v_ignoreMissing_2335_);
v___x_2348_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2348_, 0, v_size_2337_);
lean_ctor_set(v___x_2348_, 1, v___x_2347_);
if (v_isShared_2345_ == 0)
{
lean_ctor_set(v___x_2344_, 0, v___x_2348_);
v___x_2350_ = v___x_2344_;
goto v_reusejp_2349_;
}
else
{
lean_object* v_reuseFailAlloc_2351_; 
v_reuseFailAlloc_2351_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2351_, 0, v___x_2348_);
v___x_2350_ = v_reuseFailAlloc_2351_;
goto v_reusejp_2349_;
}
v_reusejp_2349_:
{
return v___x_2350_;
}
}
}
else
{
lean_object* v_a_2354_; lean_object* v___x_2356_; uint8_t v_isShared_2357_; uint8_t v_isSharedCheck_2361_; 
lean_dec(v_size_2337_);
lean_dec(v_recursorMap_2336_);
lean_dec_ref(v_noMDataExprs_2332_);
lean_dec_ref(v_visitedConstants_2331_);
lean_dec_ref(v_visitedExprs_2330_);
lean_dec_ref(v_visitedLevels_2329_);
lean_dec_ref(v_visitedNames_2328_);
lean_dec_ref(v_e_2302_);
v_a_2354_ = lean_ctor_get(v___x_2342_, 0);
v_isSharedCheck_2361_ = !lean_is_exclusive(v___x_2342_);
if (v_isSharedCheck_2361_ == 0)
{
v___x_2356_ = v___x_2342_;
v_isShared_2357_ = v_isSharedCheck_2361_;
goto v_resetjp_2355_;
}
else
{
lean_inc(v_a_2354_);
lean_dec(v___x_2342_);
v___x_2356_ = lean_box(0);
v_isShared_2357_ = v_isSharedCheck_2361_;
goto v_resetjp_2355_;
}
v_resetjp_2355_:
{
lean_object* v___x_2359_; 
if (v_isShared_2357_ == 0)
{
v___x_2359_ = v___x_2356_;
goto v_reusejp_2358_;
}
else
{
lean_object* v_reuseFailAlloc_2360_; 
v_reuseFailAlloc_2360_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2360_, 0, v_a_2354_);
v___x_2359_ = v_reuseFailAlloc_2360_;
goto v_reusejp_2358_;
}
v_reusejp_2358_:
{
return v___x_2359_;
}
}
}
}
v___jp_2362_:
{
lean_object* v_visitedNames_2365_; lean_object* v_visitedLevels_2366_; lean_object* v_visitedExprs_2367_; lean_object* v_visitedConstants_2368_; lean_object* v_noMDataExprs_2369_; uint8_t v_exportMData_2370_; uint8_t v_exportUnsafe_2371_; uint8_t v_ignoreMissing_2372_; lean_object* v_recursorMap_2373_; 
v_visitedNames_2365_ = lean_ctor_get(v_snd_2364_, 0);
lean_inc_ref(v_visitedNames_2365_);
v_visitedLevels_2366_ = lean_ctor_get(v_snd_2364_, 1);
lean_inc_ref(v_visitedLevels_2366_);
v_visitedExprs_2367_ = lean_ctor_get(v_snd_2364_, 2);
lean_inc_ref(v_visitedExprs_2367_);
v_visitedConstants_2368_ = lean_ctor_get(v_snd_2364_, 3);
lean_inc_ref(v_visitedConstants_2368_);
v_noMDataExprs_2369_ = lean_ctor_get(v_snd_2364_, 4);
lean_inc_ref(v_noMDataExprs_2369_);
v_exportMData_2370_ = lean_ctor_get_uint8(v_snd_2364_, sizeof(void*)*6);
v_exportUnsafe_2371_ = lean_ctor_get_uint8(v_snd_2364_, sizeof(void*)*6 + 1);
v_ignoreMissing_2372_ = lean_ctor_get_uint8(v_snd_2364_, sizeof(void*)*6 + 2);
v_recursorMap_2373_ = lean_ctor_get(v_snd_2364_, 5);
lean_inc(v_recursorMap_2373_);
lean_dec_ref(v_snd_2364_);
v_fst_2327_ = v_fst_2363_;
v_visitedNames_2328_ = v_visitedNames_2365_;
v_visitedLevels_2329_ = v_visitedLevels_2366_;
v_visitedExprs_2330_ = v_visitedExprs_2367_;
v_visitedConstants_2331_ = v_visitedConstants_2368_;
v_noMDataExprs_2332_ = v_noMDataExprs_2369_;
v_exportMData_2333_ = v_exportMData_2370_;
v_exportUnsafe_2334_ = v_exportUnsafe_2371_;
v_ignoreMissing_2335_ = v_ignoreMissing_2372_;
v_recursorMap_2336_ = v_recursorMap_2373_;
goto v___jp_2326_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExpr(lean_object* v_e_2926_, lean_object* v_a_2927_, lean_object* v_a_2928_){
_start:
{
uint8_t v_exportMData_2930_; 
v_exportMData_2930_ = lean_ctor_get_uint8(v_a_2928_, sizeof(void*)*6);
if (v_exportMData_2930_ == 0)
{
lean_object* v_visitedNames_2931_; lean_object* v_visitedLevels_2932_; lean_object* v_visitedExprs_2933_; lean_object* v_visitedConstants_2934_; uint8_t v_exportUnsafe_2935_; uint8_t v_ignoreMissing_2936_; lean_object* v_recursorMap_2937_; lean_object* v___x_2939_; uint8_t v_isShared_2940_; uint8_t v_isSharedCheck_2958_; 
v_visitedNames_2931_ = lean_ctor_get(v_a_2928_, 0);
v_visitedLevels_2932_ = lean_ctor_get(v_a_2928_, 1);
v_visitedExprs_2933_ = lean_ctor_get(v_a_2928_, 2);
v_visitedConstants_2934_ = lean_ctor_get(v_a_2928_, 3);
v_exportUnsafe_2935_ = lean_ctor_get_uint8(v_a_2928_, sizeof(void*)*6 + 1);
v_ignoreMissing_2936_ = lean_ctor_get_uint8(v_a_2928_, sizeof(void*)*6 + 2);
v_recursorMap_2937_ = lean_ctor_get(v_a_2928_, 5);
v_isSharedCheck_2958_ = !lean_is_exclusive(v_a_2928_);
if (v_isSharedCheck_2958_ == 0)
{
lean_object* v_unused_2959_; 
v_unused_2959_ = lean_ctor_get(v_a_2928_, 4);
lean_dec(v_unused_2959_);
v___x_2939_ = v_a_2928_;
v_isShared_2940_ = v_isSharedCheck_2958_;
goto v_resetjp_2938_;
}
else
{
lean_inc(v_recursorMap_2937_);
lean_inc(v_visitedConstants_2934_);
lean_inc(v_visitedExprs_2933_);
lean_inc(v_visitedLevels_2932_);
lean_inc(v_visitedNames_2931_);
lean_dec(v_a_2928_);
v___x_2939_ = lean_box(0);
v_isShared_2940_ = v_isSharedCheck_2958_;
goto v_resetjp_2938_;
}
v_resetjp_2938_:
{
lean_object* v___x_2941_; lean_object* v___x_2943_; 
v___x_2941_ = lean_obj_once(&lp_proofEnvironment_dumpExpr___closed__1, &lp_proofEnvironment_dumpExpr___closed__1_once, _init_lp_proofEnvironment_dumpExpr___closed__1);
if (v_isShared_2940_ == 0)
{
lean_ctor_set(v___x_2939_, 4, v___x_2941_);
v___x_2943_ = v___x_2939_;
goto v_reusejp_2942_;
}
else
{
lean_object* v_reuseFailAlloc_2957_; 
v_reuseFailAlloc_2957_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_2957_, 0, v_visitedNames_2931_);
lean_ctor_set(v_reuseFailAlloc_2957_, 1, v_visitedLevels_2932_);
lean_ctor_set(v_reuseFailAlloc_2957_, 2, v_visitedExprs_2933_);
lean_ctor_set(v_reuseFailAlloc_2957_, 3, v_visitedConstants_2934_);
lean_ctor_set(v_reuseFailAlloc_2957_, 4, v___x_2941_);
lean_ctor_set(v_reuseFailAlloc_2957_, 5, v_recursorMap_2937_);
lean_ctor_set_uint8(v_reuseFailAlloc_2957_, sizeof(void*)*6, v_exportMData_2930_);
lean_ctor_set_uint8(v_reuseFailAlloc_2957_, sizeof(void*)*6 + 1, v_exportUnsafe_2935_);
lean_ctor_set_uint8(v_reuseFailAlloc_2957_, sizeof(void*)*6 + 2, v_ignoreMissing_2936_);
v___x_2943_ = v_reuseFailAlloc_2957_;
goto v_reusejp_2942_;
}
v_reusejp_2942_:
{
lean_object* v___x_2944_; 
v___x_2944_ = lp_proofEnvironment_removeMData(v_e_2926_, v_a_2927_, v___x_2943_);
if (lean_obj_tag(v___x_2944_) == 0)
{
lean_object* v_a_2945_; lean_object* v_fst_2946_; lean_object* v_snd_2947_; lean_object* v___x_2948_; 
v_a_2945_ = lean_ctor_get(v___x_2944_, 0);
lean_inc(v_a_2945_);
lean_dec_ref_known(v___x_2944_, 1);
v_fst_2946_ = lean_ctor_get(v_a_2945_, 0);
lean_inc(v_fst_2946_);
v_snd_2947_ = lean_ctor_get(v_a_2945_, 1);
lean_inc(v_snd_2947_);
lean_dec(v_a_2945_);
v___x_2948_ = lp_proofEnvironment_dumpExprAux(v_fst_2946_, v_a_2927_, v_snd_2947_);
return v___x_2948_;
}
else
{
lean_object* v_a_2949_; lean_object* v___x_2951_; uint8_t v_isShared_2952_; uint8_t v_isSharedCheck_2956_; 
v_a_2949_ = lean_ctor_get(v___x_2944_, 0);
v_isSharedCheck_2956_ = !lean_is_exclusive(v___x_2944_);
if (v_isSharedCheck_2956_ == 0)
{
v___x_2951_ = v___x_2944_;
v_isShared_2952_ = v_isSharedCheck_2956_;
goto v_resetjp_2950_;
}
else
{
lean_inc(v_a_2949_);
lean_dec(v___x_2944_);
v___x_2951_ = lean_box(0);
v_isShared_2952_ = v_isSharedCheck_2956_;
goto v_resetjp_2950_;
}
v_resetjp_2950_:
{
lean_object* v___x_2954_; 
if (v_isShared_2952_ == 0)
{
v___x_2954_ = v___x_2951_;
goto v_reusejp_2953_;
}
else
{
lean_object* v_reuseFailAlloc_2955_; 
v_reuseFailAlloc_2955_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2955_, 0, v_a_2949_);
v___x_2954_ = v_reuseFailAlloc_2955_;
goto v_reusejp_2953_;
}
v_reusejp_2953_:
{
return v___x_2954_;
}
}
}
}
}
}
else
{
lean_object* v___x_2960_; 
v___x_2960_ = lp_proofEnvironment_dumpExprAux(v_e_2926_, v_a_2927_, v_a_2928_);
return v___x_2960_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15(size_t v_sz_2970_, size_t v_i_2971_, lean_object* v_bs_2972_, lean_object* v___y_2973_, lean_object* v___y_2974_){
_start:
{
uint8_t v___x_2976_; 
v___x_2976_ = lean_usize_dec_lt(v_i_2971_, v_sz_2970_);
if (v___x_2976_ == 0)
{
lean_object* v___x_2977_; lean_object* v___x_2978_; 
v___x_2977_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2977_, 0, v_bs_2972_);
lean_ctor_set(v___x_2977_, 1, v___y_2974_);
v___x_2978_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2978_, 0, v___x_2977_);
return v___x_2978_;
}
else
{
lean_object* v_v_2979_; lean_object* v_toConstantVal_2980_; lean_object* v_numParams_2981_; lean_object* v_numIndices_2982_; lean_object* v_all_2983_; lean_object* v_ctors_2984_; lean_object* v_numNested_2985_; uint8_t v_isRec_2986_; uint8_t v_isUnsafe_2987_; uint8_t v_isReflexive_2988_; lean_object* v_name_2989_; lean_object* v_levelParams_2990_; lean_object* v_type_2991_; lean_object* v___x_2992_; 
v_v_2979_ = lean_array_uget_borrowed(v_bs_2972_, v_i_2971_);
v_toConstantVal_2980_ = lean_ctor_get(v_v_2979_, 0);
v_numParams_2981_ = lean_ctor_get(v_v_2979_, 1);
lean_inc(v_numParams_2981_);
v_numIndices_2982_ = lean_ctor_get(v_v_2979_, 2);
lean_inc(v_numIndices_2982_);
v_all_2983_ = lean_ctor_get(v_v_2979_, 3);
lean_inc(v_all_2983_);
v_ctors_2984_ = lean_ctor_get(v_v_2979_, 4);
lean_inc(v_ctors_2984_);
v_numNested_2985_ = lean_ctor_get(v_v_2979_, 5);
lean_inc(v_numNested_2985_);
v_isRec_2986_ = lean_ctor_get_uint8(v_v_2979_, sizeof(void*)*6);
v_isUnsafe_2987_ = lean_ctor_get_uint8(v_v_2979_, sizeof(void*)*6 + 1);
v_isReflexive_2988_ = lean_ctor_get_uint8(v_v_2979_, sizeof(void*)*6 + 2);
v_name_2989_ = lean_ctor_get(v_toConstantVal_2980_, 0);
v_levelParams_2990_ = lean_ctor_get(v_toConstantVal_2980_, 1);
lean_inc(v_levelParams_2990_);
v_type_2991_ = lean_ctor_get(v_toConstantVal_2980_, 2);
lean_inc_ref(v_type_2991_);
lean_inc(v_name_2989_);
v___x_2992_ = lp_proofEnvironment_dumpName(v_name_2989_, v___y_2973_, v___y_2974_);
if (lean_obj_tag(v___x_2992_) == 0)
{
lean_object* v_a_2993_; lean_object* v_fst_2994_; lean_object* v_snd_2995_; lean_object* v___x_2997_; uint8_t v_isShared_2998_; uint8_t v_isSharedCheck_3137_; 
v_a_2993_ = lean_ctor_get(v___x_2992_, 0);
lean_inc(v_a_2993_);
lean_dec_ref_known(v___x_2992_, 1);
v_fst_2994_ = lean_ctor_get(v_a_2993_, 0);
v_snd_2995_ = lean_ctor_get(v_a_2993_, 1);
v_isSharedCheck_3137_ = !lean_is_exclusive(v_a_2993_);
if (v_isSharedCheck_3137_ == 0)
{
v___x_2997_ = v_a_2993_;
v_isShared_2998_ = v_isSharedCheck_3137_;
goto v_resetjp_2996_;
}
else
{
lean_inc(v_snd_2995_);
lean_inc(v_fst_2994_);
lean_dec(v_a_2993_);
v___x_2997_ = lean_box(0);
v_isShared_2998_ = v_isSharedCheck_3137_;
goto v_resetjp_2996_;
}
v_resetjp_2996_:
{
lean_object* v___x_2999_; lean_object* v_bs_x27_3000_; lean_object* v_fst_3002_; lean_object* v_snd_3003_; lean_object* v___y_3009_; lean_object* v___x_3021_; 
v___x_2999_ = lean_unsigned_to_nat(0u);
v_bs_x27_3000_ = lean_array_uset(v_bs_2972_, v_i_2971_, v___x_2999_);
v___x_3021_ = lp_proofEnvironment_dumpUparams(v_levelParams_2990_, v___y_2973_, v_snd_2995_);
if (lean_obj_tag(v___x_3021_) == 0)
{
lean_object* v_a_3022_; lean_object* v___x_3024_; uint8_t v_isShared_3025_; uint8_t v_isSharedCheck_3136_; 
v_a_3022_ = lean_ctor_get(v___x_3021_, 0);
v_isSharedCheck_3136_ = !lean_is_exclusive(v___x_3021_);
if (v_isSharedCheck_3136_ == 0)
{
v___x_3024_ = v___x_3021_;
v_isShared_3025_ = v_isSharedCheck_3136_;
goto v_resetjp_3023_;
}
else
{
lean_inc(v_a_3022_);
lean_dec(v___x_3021_);
v___x_3024_ = lean_box(0);
v_isShared_3025_ = v_isSharedCheck_3136_;
goto v_resetjp_3023_;
}
v_resetjp_3023_:
{
lean_object* v_fst_3026_; lean_object* v_snd_3027_; lean_object* v___x_3029_; uint8_t v_isShared_3030_; uint8_t v_isSharedCheck_3135_; 
v_fst_3026_ = lean_ctor_get(v_a_3022_, 0);
v_snd_3027_ = lean_ctor_get(v_a_3022_, 1);
v_isSharedCheck_3135_ = !lean_is_exclusive(v_a_3022_);
if (v_isSharedCheck_3135_ == 0)
{
v___x_3029_ = v_a_3022_;
v_isShared_3030_ = v_isSharedCheck_3135_;
goto v_resetjp_3028_;
}
else
{
lean_inc(v_snd_3027_);
lean_inc(v_fst_3026_);
lean_dec(v_a_3022_);
v___x_3029_ = lean_box(0);
v_isShared_3030_ = v_isSharedCheck_3135_;
goto v_resetjp_3028_;
}
v_resetjp_3028_:
{
lean_object* v___x_3031_; 
v___x_3031_ = lp_proofEnvironment_dumpExpr(v_type_2991_, v___y_2973_, v_snd_3027_);
if (lean_obj_tag(v___x_3031_) == 0)
{
lean_object* v_a_3032_; lean_object* v_fst_3033_; lean_object* v_snd_3034_; lean_object* v___x_3036_; uint8_t v_isShared_3037_; uint8_t v_isSharedCheck_3126_; 
v_a_3032_ = lean_ctor_get(v___x_3031_, 0);
lean_inc(v_a_3032_);
lean_dec_ref_known(v___x_3031_, 1);
v_fst_3033_ = lean_ctor_get(v_a_3032_, 0);
v_snd_3034_ = lean_ctor_get(v_a_3032_, 1);
v_isSharedCheck_3126_ = !lean_is_exclusive(v_a_3032_);
if (v_isSharedCheck_3126_ == 0)
{
v___x_3036_ = v_a_3032_;
v_isShared_3037_ = v_isSharedCheck_3126_;
goto v_resetjp_3035_;
}
else
{
lean_inc(v_snd_3034_);
lean_inc(v_fst_3033_);
lean_dec(v_a_3032_);
v___x_3036_ = lean_box(0);
v_isShared_3037_ = v_isSharedCheck_3126_;
goto v_resetjp_3035_;
}
v_resetjp_3035_:
{
lean_object* v___x_3038_; 
v___x_3038_ = lp_proofEnvironment_dumpNames(v_all_2983_, v___y_2973_, v_snd_3034_);
if (lean_obj_tag(v___x_3038_) == 0)
{
lean_object* v_a_3039_; lean_object* v___x_3041_; uint8_t v_isShared_3042_; uint8_t v_isSharedCheck_3125_; 
v_a_3039_ = lean_ctor_get(v___x_3038_, 0);
v_isSharedCheck_3125_ = !lean_is_exclusive(v___x_3038_);
if (v_isSharedCheck_3125_ == 0)
{
v___x_3041_ = v___x_3038_;
v_isShared_3042_ = v_isSharedCheck_3125_;
goto v_resetjp_3040_;
}
else
{
lean_inc(v_a_3039_);
lean_dec(v___x_3038_);
v___x_3041_ = lean_box(0);
v_isShared_3042_ = v_isSharedCheck_3125_;
goto v_resetjp_3040_;
}
v_resetjp_3040_:
{
lean_object* v_fst_3043_; lean_object* v_snd_3044_; lean_object* v___x_3046_; uint8_t v_isShared_3047_; uint8_t v_isSharedCheck_3124_; 
v_fst_3043_ = lean_ctor_get(v_a_3039_, 0);
v_snd_3044_ = lean_ctor_get(v_a_3039_, 1);
v_isSharedCheck_3124_ = !lean_is_exclusive(v_a_3039_);
if (v_isSharedCheck_3124_ == 0)
{
v___x_3046_ = v_a_3039_;
v_isShared_3047_ = v_isSharedCheck_3124_;
goto v_resetjp_3045_;
}
else
{
lean_inc(v_snd_3044_);
lean_inc(v_fst_3043_);
lean_dec(v_a_3039_);
v___x_3046_ = lean_box(0);
v_isShared_3047_ = v_isSharedCheck_3124_;
goto v_resetjp_3045_;
}
v_resetjp_3045_:
{
lean_object* v___x_3048_; 
v___x_3048_ = lp_proofEnvironment_dumpNames(v_ctors_2984_, v___y_2973_, v_snd_3044_);
if (lean_obj_tag(v___x_3048_) == 0)
{
lean_object* v_a_3049_; lean_object* v___x_3051_; uint8_t v_isShared_3052_; uint8_t v_isSharedCheck_3123_; 
v_a_3049_ = lean_ctor_get(v___x_3048_, 0);
v_isSharedCheck_3123_ = !lean_is_exclusive(v___x_3048_);
if (v_isSharedCheck_3123_ == 0)
{
v___x_3051_ = v___x_3048_;
v_isShared_3052_ = v_isSharedCheck_3123_;
goto v_resetjp_3050_;
}
else
{
lean_inc(v_a_3049_);
lean_dec(v___x_3048_);
v___x_3051_ = lean_box(0);
v_isShared_3052_ = v_isSharedCheck_3123_;
goto v_resetjp_3050_;
}
v_resetjp_3050_:
{
lean_object* v_fst_3053_; lean_object* v_snd_3054_; lean_object* v___x_3056_; uint8_t v_isShared_3057_; uint8_t v_isSharedCheck_3122_; 
v_fst_3053_ = lean_ctor_get(v_a_3049_, 0);
v_snd_3054_ = lean_ctor_get(v_a_3049_, 1);
v_isSharedCheck_3122_ = !lean_is_exclusive(v_a_3049_);
if (v_isSharedCheck_3122_ == 0)
{
v___x_3056_ = v_a_3049_;
v_isShared_3057_ = v_isSharedCheck_3122_;
goto v_resetjp_3055_;
}
else
{
lean_inc(v_snd_3054_);
lean_inc(v_fst_3053_);
lean_dec(v_a_3049_);
v___x_3056_ = lean_box(0);
v_isShared_3057_ = v_isSharedCheck_3122_;
goto v_resetjp_3055_;
}
v_resetjp_3055_:
{
lean_object* v___x_3058_; lean_object* v___x_3059_; lean_object* v___x_3061_; 
v___x_3058_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_3059_ = l_Lean_JsonNumber_fromNat(v_fst_2994_);
if (v_isShared_3052_ == 0)
{
lean_ctor_set_tag(v___x_3051_, 2);
lean_ctor_set(v___x_3051_, 0, v___x_3059_);
v___x_3061_ = v___x_3051_;
goto v_reusejp_3060_;
}
else
{
lean_object* v_reuseFailAlloc_3121_; 
v_reuseFailAlloc_3121_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3121_, 0, v___x_3059_);
v___x_3061_ = v_reuseFailAlloc_3121_;
goto v_reusejp_3060_;
}
v_reusejp_3060_:
{
lean_object* v___x_3063_; 
if (v_isShared_3057_ == 0)
{
lean_ctor_set(v___x_3056_, 1, v___x_3061_);
lean_ctor_set(v___x_3056_, 0, v___x_3058_);
v___x_3063_ = v___x_3056_;
goto v_reusejp_3062_;
}
else
{
lean_object* v_reuseFailAlloc_3120_; 
v_reuseFailAlloc_3120_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3120_, 0, v___x_3058_);
lean_ctor_set(v_reuseFailAlloc_3120_, 1, v___x_3061_);
v___x_3063_ = v_reuseFailAlloc_3120_;
goto v_reusejp_3062_;
}
v_reusejp_3062_:
{
lean_object* v___x_3064_; lean_object* v___x_3066_; 
v___x_3064_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_3047_ == 0)
{
lean_ctor_set(v___x_3046_, 1, v_fst_3026_);
lean_ctor_set(v___x_3046_, 0, v___x_3064_);
v___x_3066_ = v___x_3046_;
goto v_reusejp_3065_;
}
else
{
lean_object* v_reuseFailAlloc_3119_; 
v_reuseFailAlloc_3119_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3119_, 0, v___x_3064_);
lean_ctor_set(v_reuseFailAlloc_3119_, 1, v_fst_3026_);
v___x_3066_ = v_reuseFailAlloc_3119_;
goto v_reusejp_3065_;
}
v_reusejp_3065_:
{
lean_object* v___x_3067_; lean_object* v___x_3068_; lean_object* v___x_3070_; 
v___x_3067_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_3068_ = l_Lean_JsonNumber_fromNat(v_fst_3033_);
if (v_isShared_3042_ == 0)
{
lean_ctor_set_tag(v___x_3041_, 2);
lean_ctor_set(v___x_3041_, 0, v___x_3068_);
v___x_3070_ = v___x_3041_;
goto v_reusejp_3069_;
}
else
{
lean_object* v_reuseFailAlloc_3118_; 
v_reuseFailAlloc_3118_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3118_, 0, v___x_3068_);
v___x_3070_ = v_reuseFailAlloc_3118_;
goto v_reusejp_3069_;
}
v_reusejp_3069_:
{
lean_object* v___x_3072_; 
if (v_isShared_3037_ == 0)
{
lean_ctor_set(v___x_3036_, 1, v___x_3070_);
lean_ctor_set(v___x_3036_, 0, v___x_3067_);
v___x_3072_ = v___x_3036_;
goto v_reusejp_3071_;
}
else
{
lean_object* v_reuseFailAlloc_3117_; 
v_reuseFailAlloc_3117_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3117_, 0, v___x_3067_);
lean_ctor_set(v_reuseFailAlloc_3117_, 1, v___x_3070_);
v___x_3072_ = v_reuseFailAlloc_3117_;
goto v_reusejp_3071_;
}
v_reusejp_3071_:
{
lean_object* v___x_3073_; lean_object* v___x_3074_; lean_object* v___x_3076_; 
v___x_3073_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__4));
v___x_3074_ = l_Lean_JsonNumber_fromNat(v_numParams_2981_);
if (v_isShared_3025_ == 0)
{
lean_ctor_set_tag(v___x_3024_, 2);
lean_ctor_set(v___x_3024_, 0, v___x_3074_);
v___x_3076_ = v___x_3024_;
goto v_reusejp_3075_;
}
else
{
lean_object* v_reuseFailAlloc_3116_; 
v_reuseFailAlloc_3116_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3116_, 0, v___x_3074_);
v___x_3076_ = v_reuseFailAlloc_3116_;
goto v_reusejp_3075_;
}
v_reusejp_3075_:
{
lean_object* v___x_3078_; 
if (v_isShared_3030_ == 0)
{
lean_ctor_set(v___x_3029_, 1, v___x_3076_);
lean_ctor_set(v___x_3029_, 0, v___x_3073_);
v___x_3078_ = v___x_3029_;
goto v_reusejp_3077_;
}
else
{
lean_object* v_reuseFailAlloc_3115_; 
v_reuseFailAlloc_3115_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3115_, 0, v___x_3073_);
lean_ctor_set(v_reuseFailAlloc_3115_, 1, v___x_3076_);
v___x_3078_ = v_reuseFailAlloc_3115_;
goto v_reusejp_3077_;
}
v_reusejp_3077_:
{
lean_object* v___x_3079_; lean_object* v___x_3080_; lean_object* v___x_3081_; lean_object* v___x_3083_; 
v___x_3079_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__0));
v___x_3080_ = l_Lean_JsonNumber_fromNat(v_numIndices_2982_);
v___x_3081_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3081_, 0, v___x_3080_);
if (v_isShared_2998_ == 0)
{
lean_ctor_set(v___x_2997_, 1, v___x_3081_);
lean_ctor_set(v___x_2997_, 0, v___x_3079_);
v___x_3083_ = v___x_2997_;
goto v_reusejp_3082_;
}
else
{
lean_object* v_reuseFailAlloc_3114_; 
v_reuseFailAlloc_3114_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3114_, 0, v___x_3079_);
lean_ctor_set(v_reuseFailAlloc_3114_, 1, v___x_3081_);
v___x_3083_ = v_reuseFailAlloc_3114_;
goto v_reusejp_3082_;
}
v_reusejp_3082_:
{
lean_object* v___x_3084_; lean_object* v___x_3085_; lean_object* v___x_3086_; lean_object* v___x_3087_; lean_object* v___x_3088_; lean_object* v___x_3089_; lean_object* v___x_3090_; lean_object* v___x_3091_; lean_object* v___x_3092_; lean_object* v___x_3093_; lean_object* v___x_3094_; lean_object* v___x_3095_; lean_object* v___x_3096_; lean_object* v___x_3097_; lean_object* v___x_3098_; lean_object* v___x_3099_; lean_object* v___x_3100_; lean_object* v___x_3101_; lean_object* v___x_3102_; lean_object* v___x_3103_; lean_object* v___x_3104_; lean_object* v___x_3105_; lean_object* v___x_3106_; lean_object* v___x_3107_; lean_object* v___x_3108_; lean_object* v___x_3109_; lean_object* v___x_3110_; lean_object* v___x_3111_; lean_object* v___x_3112_; lean_object* v___x_3113_; 
v___x_3084_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1));
v___x_3085_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3085_, 0, v___x_3084_);
lean_ctor_set(v___x_3085_, 1, v_fst_3043_);
v___x_3086_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__2));
v___x_3087_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3087_, 0, v___x_3086_);
lean_ctor_set(v___x_3087_, 1, v_fst_3053_);
v___x_3088_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__3));
v___x_3089_ = l_Lean_JsonNumber_fromNat(v_numNested_2985_);
v___x_3090_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3090_, 0, v___x_3089_);
v___x_3091_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3091_, 0, v___x_3088_);
lean_ctor_set(v___x_3091_, 1, v___x_3090_);
v___x_3092_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__4));
v___x_3093_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3093_, 0, v_isRec_2986_);
v___x_3094_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3094_, 0, v___x_3092_);
lean_ctor_set(v___x_3094_, 1, v___x_3093_);
v___x_3095_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__5));
v___x_3096_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3096_, 0, v_isReflexive_2988_);
v___x_3097_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3097_, 0, v___x_3095_);
lean_ctor_set(v___x_3097_, 1, v___x_3096_);
v___x_3098_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6));
v___x_3099_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3099_, 0, v_isUnsafe_2987_);
v___x_3100_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3100_, 0, v___x_3098_);
lean_ctor_set(v___x_3100_, 1, v___x_3099_);
v___x_3101_ = lean_box(0);
v___x_3102_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3102_, 0, v___x_3100_);
lean_ctor_set(v___x_3102_, 1, v___x_3101_);
v___x_3103_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3103_, 0, v___x_3097_);
lean_ctor_set(v___x_3103_, 1, v___x_3102_);
v___x_3104_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3104_, 0, v___x_3094_);
lean_ctor_set(v___x_3104_, 1, v___x_3103_);
v___x_3105_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3105_, 0, v___x_3091_);
lean_ctor_set(v___x_3105_, 1, v___x_3104_);
v___x_3106_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3106_, 0, v___x_3087_);
lean_ctor_set(v___x_3106_, 1, v___x_3105_);
v___x_3107_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3107_, 0, v___x_3085_);
lean_ctor_set(v___x_3107_, 1, v___x_3106_);
v___x_3108_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3108_, 0, v___x_3083_);
lean_ctor_set(v___x_3108_, 1, v___x_3107_);
v___x_3109_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3109_, 0, v___x_3078_);
lean_ctor_set(v___x_3109_, 1, v___x_3108_);
v___x_3110_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3110_, 0, v___x_3072_);
lean_ctor_set(v___x_3110_, 1, v___x_3109_);
v___x_3111_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3111_, 0, v___x_3066_);
lean_ctor_set(v___x_3111_, 1, v___x_3110_);
v___x_3112_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3112_, 0, v___x_3063_);
lean_ctor_set(v___x_3112_, 1, v___x_3111_);
v___x_3113_ = l_Lean_Json_mkObj(v___x_3112_);
lean_dec_ref_known(v___x_3112_, 2);
v_fst_3002_ = v___x_3113_;
v_snd_3003_ = v_snd_3054_;
goto v___jp_3001_;
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_3046_);
lean_dec(v_fst_3043_);
lean_del_object(v___x_3041_);
lean_del_object(v___x_3036_);
lean_dec(v_fst_3033_);
lean_del_object(v___x_3029_);
lean_dec(v_fst_3026_);
lean_del_object(v___x_3024_);
lean_del_object(v___x_2997_);
lean_dec(v_fst_2994_);
lean_dec(v_numNested_2985_);
lean_dec(v_numIndices_2982_);
lean_dec(v_numParams_2981_);
v___y_3009_ = v___x_3048_;
goto v___jp_3008_;
}
}
}
}
else
{
lean_del_object(v___x_3036_);
lean_dec(v_fst_3033_);
lean_del_object(v___x_3029_);
lean_dec(v_fst_3026_);
lean_del_object(v___x_3024_);
lean_del_object(v___x_2997_);
lean_dec(v_fst_2994_);
lean_dec(v_numNested_2985_);
lean_dec(v_ctors_2984_);
lean_dec(v_numIndices_2982_);
lean_dec(v_numParams_2981_);
v___y_3009_ = v___x_3038_;
goto v___jp_3008_;
}
}
}
else
{
lean_object* v_a_3127_; lean_object* v___x_3129_; uint8_t v_isShared_3130_; uint8_t v_isSharedCheck_3134_; 
lean_del_object(v___x_3029_);
lean_dec(v_fst_3026_);
lean_del_object(v___x_3024_);
lean_dec_ref(v_bs_x27_3000_);
lean_del_object(v___x_2997_);
lean_dec(v_fst_2994_);
lean_dec(v_numNested_2985_);
lean_dec(v_ctors_2984_);
lean_dec(v_all_2983_);
lean_dec(v_numIndices_2982_);
lean_dec(v_numParams_2981_);
v_a_3127_ = lean_ctor_get(v___x_3031_, 0);
v_isSharedCheck_3134_ = !lean_is_exclusive(v___x_3031_);
if (v_isSharedCheck_3134_ == 0)
{
v___x_3129_ = v___x_3031_;
v_isShared_3130_ = v_isSharedCheck_3134_;
goto v_resetjp_3128_;
}
else
{
lean_inc(v_a_3127_);
lean_dec(v___x_3031_);
v___x_3129_ = lean_box(0);
v_isShared_3130_ = v_isSharedCheck_3134_;
goto v_resetjp_3128_;
}
v_resetjp_3128_:
{
lean_object* v___x_3132_; 
if (v_isShared_3130_ == 0)
{
v___x_3132_ = v___x_3129_;
goto v_reusejp_3131_;
}
else
{
lean_object* v_reuseFailAlloc_3133_; 
v_reuseFailAlloc_3133_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3133_, 0, v_a_3127_);
v___x_3132_ = v_reuseFailAlloc_3133_;
goto v_reusejp_3131_;
}
v_reusejp_3131_:
{
return v___x_3132_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_2997_);
lean_dec(v_fst_2994_);
lean_dec_ref(v_type_2991_);
lean_dec(v_numNested_2985_);
lean_dec(v_ctors_2984_);
lean_dec(v_all_2983_);
lean_dec(v_numIndices_2982_);
lean_dec(v_numParams_2981_);
v___y_3009_ = v___x_3021_;
goto v___jp_3008_;
}
v___jp_3001_:
{
size_t v___x_3004_; size_t v___x_3005_; lean_object* v___x_3006_; 
v___x_3004_ = ((size_t)1ULL);
v___x_3005_ = lean_usize_add(v_i_2971_, v___x_3004_);
v___x_3006_ = lean_array_uset(v_bs_x27_3000_, v_i_2971_, v_fst_3002_);
v_i_2971_ = v___x_3005_;
v_bs_2972_ = v___x_3006_;
v___y_2974_ = v_snd_3003_;
goto _start;
}
v___jp_3008_:
{
if (lean_obj_tag(v___y_3009_) == 0)
{
lean_object* v_a_3010_; lean_object* v_fst_3011_; lean_object* v_snd_3012_; 
v_a_3010_ = lean_ctor_get(v___y_3009_, 0);
lean_inc(v_a_3010_);
lean_dec_ref_known(v___y_3009_, 1);
v_fst_3011_ = lean_ctor_get(v_a_3010_, 0);
lean_inc(v_fst_3011_);
v_snd_3012_ = lean_ctor_get(v_a_3010_, 1);
lean_inc(v_snd_3012_);
lean_dec(v_a_3010_);
v_fst_3002_ = v_fst_3011_;
v_snd_3003_ = v_snd_3012_;
goto v___jp_3001_;
}
else
{
lean_object* v_a_3013_; lean_object* v___x_3015_; uint8_t v_isShared_3016_; uint8_t v_isSharedCheck_3020_; 
lean_dec_ref(v_bs_x27_3000_);
v_a_3013_ = lean_ctor_get(v___y_3009_, 0);
v_isSharedCheck_3020_ = !lean_is_exclusive(v___y_3009_);
if (v_isSharedCheck_3020_ == 0)
{
v___x_3015_ = v___y_3009_;
v_isShared_3016_ = v_isSharedCheck_3020_;
goto v_resetjp_3014_;
}
else
{
lean_inc(v_a_3013_);
lean_dec(v___y_3009_);
v___x_3015_ = lean_box(0);
v_isShared_3016_ = v_isSharedCheck_3020_;
goto v_resetjp_3014_;
}
v_resetjp_3014_:
{
lean_object* v___x_3018_; 
if (v_isShared_3016_ == 0)
{
v___x_3018_ = v___x_3015_;
goto v_reusejp_3017_;
}
else
{
lean_object* v_reuseFailAlloc_3019_; 
v_reuseFailAlloc_3019_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3019_, 0, v_a_3013_);
v___x_3018_ = v_reuseFailAlloc_3019_;
goto v_reusejp_3017_;
}
v_reusejp_3017_:
{
return v___x_3018_;
}
}
}
}
}
}
else
{
lean_object* v_a_3138_; lean_object* v___x_3140_; uint8_t v_isShared_3141_; uint8_t v_isSharedCheck_3145_; 
lean_dec_ref(v_type_2991_);
lean_dec(v_levelParams_2990_);
lean_dec(v_numNested_2985_);
lean_dec(v_ctors_2984_);
lean_dec(v_all_2983_);
lean_dec(v_numIndices_2982_);
lean_dec(v_numParams_2981_);
lean_dec_ref(v_bs_2972_);
v_a_3138_ = lean_ctor_get(v___x_2992_, 0);
v_isSharedCheck_3145_ = !lean_is_exclusive(v___x_2992_);
if (v_isSharedCheck_3145_ == 0)
{
v___x_3140_ = v___x_2992_;
v_isShared_3141_ = v_isSharedCheck_3145_;
goto v_resetjp_3139_;
}
else
{
lean_inc(v_a_3138_);
lean_dec(v___x_2992_);
v___x_3140_ = lean_box(0);
v_isShared_3141_ = v_isSharedCheck_3145_;
goto v_resetjp_3139_;
}
v_resetjp_3139_:
{
lean_object* v___x_3143_; 
if (v_isShared_3141_ == 0)
{
v___x_3143_ = v___x_3140_;
goto v_reusejp_3142_;
}
else
{
lean_object* v_reuseFailAlloc_3144_; 
v_reuseFailAlloc_3144_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3144_, 0, v_a_3138_);
v___x_3143_ = v_reuseFailAlloc_3144_;
goto v_reusejp_3142_;
}
v_reusejp_3142_:
{
return v___x_3143_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16(size_t v_sz_3149_, size_t v_i_3150_, lean_object* v_bs_3151_, lean_object* v___y_3152_, lean_object* v___y_3153_){
_start:
{
uint8_t v___x_3155_; 
v___x_3155_ = lean_usize_dec_lt(v_i_3150_, v_sz_3149_);
if (v___x_3155_ == 0)
{
lean_object* v___x_3156_; lean_object* v___x_3157_; 
v___x_3156_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3156_, 0, v_bs_3151_);
lean_ctor_set(v___x_3156_, 1, v___y_3153_);
v___x_3157_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3157_, 0, v___x_3156_);
return v___x_3157_;
}
else
{
lean_object* v_v_3158_; lean_object* v_toConstantVal_3159_; lean_object* v_induct_3160_; lean_object* v_cidx_3161_; lean_object* v_numParams_3162_; lean_object* v_numFields_3163_; uint8_t v_isUnsafe_3164_; lean_object* v_name_3165_; lean_object* v_levelParams_3166_; lean_object* v_type_3167_; lean_object* v___x_3168_; 
v_v_3158_ = lean_array_uget_borrowed(v_bs_3151_, v_i_3150_);
v_toConstantVal_3159_ = lean_ctor_get(v_v_3158_, 0);
v_induct_3160_ = lean_ctor_get(v_v_3158_, 1);
lean_inc(v_induct_3160_);
v_cidx_3161_ = lean_ctor_get(v_v_3158_, 2);
lean_inc(v_cidx_3161_);
v_numParams_3162_ = lean_ctor_get(v_v_3158_, 3);
lean_inc(v_numParams_3162_);
v_numFields_3163_ = lean_ctor_get(v_v_3158_, 4);
lean_inc(v_numFields_3163_);
v_isUnsafe_3164_ = lean_ctor_get_uint8(v_v_3158_, sizeof(void*)*5);
v_name_3165_ = lean_ctor_get(v_toConstantVal_3159_, 0);
v_levelParams_3166_ = lean_ctor_get(v_toConstantVal_3159_, 1);
lean_inc(v_levelParams_3166_);
v_type_3167_ = lean_ctor_get(v_toConstantVal_3159_, 2);
lean_inc_ref(v_type_3167_);
lean_inc(v_name_3165_);
v___x_3168_ = lp_proofEnvironment_dumpName(v_name_3165_, v___y_3152_, v___y_3153_);
if (lean_obj_tag(v___x_3168_) == 0)
{
lean_object* v_a_3169_; lean_object* v_fst_3170_; lean_object* v_snd_3171_; lean_object* v___x_3173_; uint8_t v_isShared_3174_; uint8_t v_isSharedCheck_3282_; 
v_a_3169_ = lean_ctor_get(v___x_3168_, 0);
lean_inc(v_a_3169_);
lean_dec_ref_known(v___x_3168_, 1);
v_fst_3170_ = lean_ctor_get(v_a_3169_, 0);
v_snd_3171_ = lean_ctor_get(v_a_3169_, 1);
v_isSharedCheck_3282_ = !lean_is_exclusive(v_a_3169_);
if (v_isSharedCheck_3282_ == 0)
{
v___x_3173_ = v_a_3169_;
v_isShared_3174_ = v_isSharedCheck_3282_;
goto v_resetjp_3172_;
}
else
{
lean_inc(v_snd_3171_);
lean_inc(v_fst_3170_);
lean_dec(v_a_3169_);
v___x_3173_ = lean_box(0);
v_isShared_3174_ = v_isSharedCheck_3282_;
goto v_resetjp_3172_;
}
v_resetjp_3172_:
{
lean_object* v___x_3175_; lean_object* v_bs_x27_3176_; lean_object* v_fst_3178_; lean_object* v_snd_3179_; lean_object* v___x_3184_; 
v___x_3175_ = lean_unsigned_to_nat(0u);
v_bs_x27_3176_ = lean_array_uset(v_bs_3151_, v_i_3150_, v___x_3175_);
v___x_3184_ = lp_proofEnvironment_dumpUparams(v_levelParams_3166_, v___y_3152_, v_snd_3171_);
if (lean_obj_tag(v___x_3184_) == 0)
{
lean_object* v_a_3185_; lean_object* v_fst_3186_; lean_object* v_snd_3187_; lean_object* v___x_3189_; uint8_t v_isShared_3190_; uint8_t v_isSharedCheck_3270_; 
v_a_3185_ = lean_ctor_get(v___x_3184_, 0);
lean_inc(v_a_3185_);
lean_dec_ref_known(v___x_3184_, 1);
v_fst_3186_ = lean_ctor_get(v_a_3185_, 0);
v_snd_3187_ = lean_ctor_get(v_a_3185_, 1);
v_isSharedCheck_3270_ = !lean_is_exclusive(v_a_3185_);
if (v_isSharedCheck_3270_ == 0)
{
v___x_3189_ = v_a_3185_;
v_isShared_3190_ = v_isSharedCheck_3270_;
goto v_resetjp_3188_;
}
else
{
lean_inc(v_snd_3187_);
lean_inc(v_fst_3186_);
lean_dec(v_a_3185_);
v___x_3189_ = lean_box(0);
v_isShared_3190_ = v_isSharedCheck_3270_;
goto v_resetjp_3188_;
}
v_resetjp_3188_:
{
lean_object* v___x_3191_; 
v___x_3191_ = lp_proofEnvironment_dumpExpr(v_type_3167_, v___y_3152_, v_snd_3187_);
if (lean_obj_tag(v___x_3191_) == 0)
{
lean_object* v_a_3192_; lean_object* v_fst_3193_; lean_object* v_snd_3194_; lean_object* v___x_3196_; uint8_t v_isShared_3197_; uint8_t v_isSharedCheck_3261_; 
v_a_3192_ = lean_ctor_get(v___x_3191_, 0);
lean_inc(v_a_3192_);
lean_dec_ref_known(v___x_3191_, 1);
v_fst_3193_ = lean_ctor_get(v_a_3192_, 0);
v_snd_3194_ = lean_ctor_get(v_a_3192_, 1);
v_isSharedCheck_3261_ = !lean_is_exclusive(v_a_3192_);
if (v_isSharedCheck_3261_ == 0)
{
v___x_3196_ = v_a_3192_;
v_isShared_3197_ = v_isSharedCheck_3261_;
goto v_resetjp_3195_;
}
else
{
lean_inc(v_snd_3194_);
lean_inc(v_fst_3193_);
lean_dec(v_a_3192_);
v___x_3196_ = lean_box(0);
v_isShared_3197_ = v_isSharedCheck_3261_;
goto v_resetjp_3195_;
}
v_resetjp_3195_:
{
lean_object* v___x_3198_; 
v___x_3198_ = lp_proofEnvironment_dumpName(v_induct_3160_, v___y_3152_, v_snd_3194_);
if (lean_obj_tag(v___x_3198_) == 0)
{
lean_object* v_a_3199_; lean_object* v_fst_3200_; lean_object* v_snd_3201_; lean_object* v___x_3203_; uint8_t v_isShared_3204_; uint8_t v_isSharedCheck_3252_; 
v_a_3199_ = lean_ctor_get(v___x_3198_, 0);
lean_inc(v_a_3199_);
lean_dec_ref_known(v___x_3198_, 1);
v_fst_3200_ = lean_ctor_get(v_a_3199_, 0);
v_snd_3201_ = lean_ctor_get(v_a_3199_, 1);
v_isSharedCheck_3252_ = !lean_is_exclusive(v_a_3199_);
if (v_isSharedCheck_3252_ == 0)
{
v___x_3203_ = v_a_3199_;
v_isShared_3204_ = v_isSharedCheck_3252_;
goto v_resetjp_3202_;
}
else
{
lean_inc(v_snd_3201_);
lean_inc(v_fst_3200_);
lean_dec(v_a_3199_);
v___x_3203_ = lean_box(0);
v_isShared_3204_ = v_isSharedCheck_3252_;
goto v_resetjp_3202_;
}
v_resetjp_3202_:
{
lean_object* v___x_3205_; lean_object* v___x_3206_; lean_object* v___x_3207_; lean_object* v___x_3209_; 
v___x_3205_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_3206_ = l_Lean_JsonNumber_fromNat(v_fst_3170_);
v___x_3207_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3207_, 0, v___x_3206_);
if (v_isShared_3204_ == 0)
{
lean_ctor_set(v___x_3203_, 1, v___x_3207_);
lean_ctor_set(v___x_3203_, 0, v___x_3205_);
v___x_3209_ = v___x_3203_;
goto v_reusejp_3208_;
}
else
{
lean_object* v_reuseFailAlloc_3251_; 
v_reuseFailAlloc_3251_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3251_, 0, v___x_3205_);
lean_ctor_set(v_reuseFailAlloc_3251_, 1, v___x_3207_);
v___x_3209_ = v_reuseFailAlloc_3251_;
goto v_reusejp_3208_;
}
v_reusejp_3208_:
{
lean_object* v___x_3210_; lean_object* v___x_3212_; 
v___x_3210_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_3197_ == 0)
{
lean_ctor_set(v___x_3196_, 1, v_fst_3186_);
lean_ctor_set(v___x_3196_, 0, v___x_3210_);
v___x_3212_ = v___x_3196_;
goto v_reusejp_3211_;
}
else
{
lean_object* v_reuseFailAlloc_3250_; 
v_reuseFailAlloc_3250_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3250_, 0, v___x_3210_);
lean_ctor_set(v_reuseFailAlloc_3250_, 1, v_fst_3186_);
v___x_3212_ = v_reuseFailAlloc_3250_;
goto v_reusejp_3211_;
}
v_reusejp_3211_:
{
lean_object* v___x_3213_; lean_object* v___x_3214_; lean_object* v___x_3215_; lean_object* v___x_3217_; 
v___x_3213_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_3214_ = l_Lean_JsonNumber_fromNat(v_fst_3193_);
v___x_3215_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3215_, 0, v___x_3214_);
if (v_isShared_3190_ == 0)
{
lean_ctor_set(v___x_3189_, 1, v___x_3215_);
lean_ctor_set(v___x_3189_, 0, v___x_3213_);
v___x_3217_ = v___x_3189_;
goto v_reusejp_3216_;
}
else
{
lean_object* v_reuseFailAlloc_3249_; 
v_reuseFailAlloc_3249_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3249_, 0, v___x_3213_);
lean_ctor_set(v_reuseFailAlloc_3249_, 1, v___x_3215_);
v___x_3217_ = v_reuseFailAlloc_3249_;
goto v_reusejp_3216_;
}
v_reusejp_3216_:
{
lean_object* v___x_3218_; lean_object* v___x_3219_; lean_object* v___x_3220_; lean_object* v___x_3222_; 
v___x_3218_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__2));
v___x_3219_ = l_Lean_JsonNumber_fromNat(v_fst_3200_);
v___x_3220_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3220_, 0, v___x_3219_);
if (v_isShared_3174_ == 0)
{
lean_ctor_set(v___x_3173_, 1, v___x_3220_);
lean_ctor_set(v___x_3173_, 0, v___x_3218_);
v___x_3222_ = v___x_3173_;
goto v_reusejp_3221_;
}
else
{
lean_object* v_reuseFailAlloc_3248_; 
v_reuseFailAlloc_3248_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3248_, 0, v___x_3218_);
lean_ctor_set(v_reuseFailAlloc_3248_, 1, v___x_3220_);
v___x_3222_ = v_reuseFailAlloc_3248_;
goto v_reusejp_3221_;
}
v_reusejp_3221_:
{
lean_object* v___x_3223_; lean_object* v___x_3224_; lean_object* v___x_3225_; lean_object* v___x_3226_; lean_object* v___x_3227_; lean_object* v___x_3228_; lean_object* v___x_3229_; lean_object* v___x_3230_; lean_object* v___x_3231_; lean_object* v___x_3232_; lean_object* v___x_3233_; lean_object* v___x_3234_; lean_object* v___x_3235_; lean_object* v___x_3236_; lean_object* v___x_3237_; lean_object* v___x_3238_; lean_object* v___x_3239_; lean_object* v___x_3240_; lean_object* v___x_3241_; lean_object* v___x_3242_; lean_object* v___x_3243_; lean_object* v___x_3244_; lean_object* v___x_3245_; lean_object* v___x_3246_; lean_object* v___x_3247_; 
v___x_3223_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__3));
v___x_3224_ = l_Lean_JsonNumber_fromNat(v_cidx_3161_);
v___x_3225_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3225_, 0, v___x_3224_);
v___x_3226_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3226_, 0, v___x_3223_);
lean_ctor_set(v___x_3226_, 1, v___x_3225_);
v___x_3227_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__4));
v___x_3228_ = l_Lean_JsonNumber_fromNat(v_numParams_3162_);
v___x_3229_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3229_, 0, v___x_3228_);
v___x_3230_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3230_, 0, v___x_3227_);
lean_ctor_set(v___x_3230_, 1, v___x_3229_);
v___x_3231_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__5));
v___x_3232_ = l_Lean_JsonNumber_fromNat(v_numFields_3163_);
v___x_3233_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3233_, 0, v___x_3232_);
v___x_3234_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3234_, 0, v___x_3231_);
lean_ctor_set(v___x_3234_, 1, v___x_3233_);
v___x_3235_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6));
v___x_3236_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3236_, 0, v_isUnsafe_3164_);
v___x_3237_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3237_, 0, v___x_3235_);
lean_ctor_set(v___x_3237_, 1, v___x_3236_);
v___x_3238_ = lean_box(0);
v___x_3239_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3239_, 0, v___x_3237_);
lean_ctor_set(v___x_3239_, 1, v___x_3238_);
v___x_3240_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3240_, 0, v___x_3234_);
lean_ctor_set(v___x_3240_, 1, v___x_3239_);
v___x_3241_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3241_, 0, v___x_3230_);
lean_ctor_set(v___x_3241_, 1, v___x_3240_);
v___x_3242_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3242_, 0, v___x_3226_);
lean_ctor_set(v___x_3242_, 1, v___x_3241_);
v___x_3243_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3243_, 0, v___x_3222_);
lean_ctor_set(v___x_3243_, 1, v___x_3242_);
v___x_3244_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3244_, 0, v___x_3217_);
lean_ctor_set(v___x_3244_, 1, v___x_3243_);
v___x_3245_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3245_, 0, v___x_3212_);
lean_ctor_set(v___x_3245_, 1, v___x_3244_);
v___x_3246_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3246_, 0, v___x_3209_);
lean_ctor_set(v___x_3246_, 1, v___x_3245_);
v___x_3247_ = l_Lean_Json_mkObj(v___x_3246_);
lean_dec_ref_known(v___x_3246_, 2);
v_fst_3178_ = v___x_3247_;
v_snd_3179_ = v_snd_3201_;
goto v___jp_3177_;
}
}
}
}
}
}
else
{
lean_object* v_a_3253_; lean_object* v___x_3255_; uint8_t v_isShared_3256_; uint8_t v_isSharedCheck_3260_; 
lean_del_object(v___x_3196_);
lean_dec(v_fst_3193_);
lean_del_object(v___x_3189_);
lean_dec(v_fst_3186_);
lean_dec_ref(v_bs_x27_3176_);
lean_del_object(v___x_3173_);
lean_dec(v_fst_3170_);
lean_dec(v_numFields_3163_);
lean_dec(v_numParams_3162_);
lean_dec(v_cidx_3161_);
v_a_3253_ = lean_ctor_get(v___x_3198_, 0);
v_isSharedCheck_3260_ = !lean_is_exclusive(v___x_3198_);
if (v_isSharedCheck_3260_ == 0)
{
v___x_3255_ = v___x_3198_;
v_isShared_3256_ = v_isSharedCheck_3260_;
goto v_resetjp_3254_;
}
else
{
lean_inc(v_a_3253_);
lean_dec(v___x_3198_);
v___x_3255_ = lean_box(0);
v_isShared_3256_ = v_isSharedCheck_3260_;
goto v_resetjp_3254_;
}
v_resetjp_3254_:
{
lean_object* v___x_3258_; 
if (v_isShared_3256_ == 0)
{
v___x_3258_ = v___x_3255_;
goto v_reusejp_3257_;
}
else
{
lean_object* v_reuseFailAlloc_3259_; 
v_reuseFailAlloc_3259_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3259_, 0, v_a_3253_);
v___x_3258_ = v_reuseFailAlloc_3259_;
goto v_reusejp_3257_;
}
v_reusejp_3257_:
{
return v___x_3258_;
}
}
}
}
}
else
{
lean_object* v_a_3262_; lean_object* v___x_3264_; uint8_t v_isShared_3265_; uint8_t v_isSharedCheck_3269_; 
lean_del_object(v___x_3189_);
lean_dec(v_fst_3186_);
lean_dec_ref(v_bs_x27_3176_);
lean_del_object(v___x_3173_);
lean_dec(v_fst_3170_);
lean_dec(v_numFields_3163_);
lean_dec(v_numParams_3162_);
lean_dec(v_cidx_3161_);
lean_dec(v_induct_3160_);
v_a_3262_ = lean_ctor_get(v___x_3191_, 0);
v_isSharedCheck_3269_ = !lean_is_exclusive(v___x_3191_);
if (v_isSharedCheck_3269_ == 0)
{
v___x_3264_ = v___x_3191_;
v_isShared_3265_ = v_isSharedCheck_3269_;
goto v_resetjp_3263_;
}
else
{
lean_inc(v_a_3262_);
lean_dec(v___x_3191_);
v___x_3264_ = lean_box(0);
v_isShared_3265_ = v_isSharedCheck_3269_;
goto v_resetjp_3263_;
}
v_resetjp_3263_:
{
lean_object* v___x_3267_; 
if (v_isShared_3265_ == 0)
{
v___x_3267_ = v___x_3264_;
goto v_reusejp_3266_;
}
else
{
lean_object* v_reuseFailAlloc_3268_; 
v_reuseFailAlloc_3268_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3268_, 0, v_a_3262_);
v___x_3267_ = v_reuseFailAlloc_3268_;
goto v_reusejp_3266_;
}
v_reusejp_3266_:
{
return v___x_3267_;
}
}
}
}
}
else
{
lean_del_object(v___x_3173_);
lean_dec(v_fst_3170_);
lean_dec_ref(v_type_3167_);
lean_dec(v_numFields_3163_);
lean_dec(v_numParams_3162_);
lean_dec(v_cidx_3161_);
lean_dec(v_induct_3160_);
if (lean_obj_tag(v___x_3184_) == 0)
{
lean_object* v_a_3271_; lean_object* v_fst_3272_; lean_object* v_snd_3273_; 
v_a_3271_ = lean_ctor_get(v___x_3184_, 0);
lean_inc(v_a_3271_);
lean_dec_ref_known(v___x_3184_, 1);
v_fst_3272_ = lean_ctor_get(v_a_3271_, 0);
lean_inc(v_fst_3272_);
v_snd_3273_ = lean_ctor_get(v_a_3271_, 1);
lean_inc(v_snd_3273_);
lean_dec(v_a_3271_);
v_fst_3178_ = v_fst_3272_;
v_snd_3179_ = v_snd_3273_;
goto v___jp_3177_;
}
else
{
lean_object* v_a_3274_; lean_object* v___x_3276_; uint8_t v_isShared_3277_; uint8_t v_isSharedCheck_3281_; 
lean_dec_ref(v_bs_x27_3176_);
v_a_3274_ = lean_ctor_get(v___x_3184_, 0);
v_isSharedCheck_3281_ = !lean_is_exclusive(v___x_3184_);
if (v_isSharedCheck_3281_ == 0)
{
v___x_3276_ = v___x_3184_;
v_isShared_3277_ = v_isSharedCheck_3281_;
goto v_resetjp_3275_;
}
else
{
lean_inc(v_a_3274_);
lean_dec(v___x_3184_);
v___x_3276_ = lean_box(0);
v_isShared_3277_ = v_isSharedCheck_3281_;
goto v_resetjp_3275_;
}
v_resetjp_3275_:
{
lean_object* v___x_3279_; 
if (v_isShared_3277_ == 0)
{
v___x_3279_ = v___x_3276_;
goto v_reusejp_3278_;
}
else
{
lean_object* v_reuseFailAlloc_3280_; 
v_reuseFailAlloc_3280_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3280_, 0, v_a_3274_);
v___x_3279_ = v_reuseFailAlloc_3280_;
goto v_reusejp_3278_;
}
v_reusejp_3278_:
{
return v___x_3279_;
}
}
}
}
v___jp_3177_:
{
size_t v___x_3180_; size_t v___x_3181_; lean_object* v___x_3182_; 
v___x_3180_ = ((size_t)1ULL);
v___x_3181_ = lean_usize_add(v_i_3150_, v___x_3180_);
v___x_3182_ = lean_array_uset(v_bs_x27_3176_, v_i_3150_, v_fst_3178_);
v_i_3150_ = v___x_3181_;
v_bs_3151_ = v___x_3182_;
v___y_3153_ = v_snd_3179_;
goto _start;
}
}
}
else
{
lean_object* v_a_3283_; lean_object* v___x_3285_; uint8_t v_isShared_3286_; uint8_t v_isSharedCheck_3290_; 
lean_dec_ref(v_type_3167_);
lean_dec(v_levelParams_3166_);
lean_dec(v_numFields_3163_);
lean_dec(v_numParams_3162_);
lean_dec(v_cidx_3161_);
lean_dec(v_induct_3160_);
lean_dec_ref(v_bs_3151_);
v_a_3283_ = lean_ctor_get(v___x_3168_, 0);
v_isSharedCheck_3290_ = !lean_is_exclusive(v___x_3168_);
if (v_isSharedCheck_3290_ == 0)
{
v___x_3285_ = v___x_3168_;
v_isShared_3286_ = v_isSharedCheck_3290_;
goto v_resetjp_3284_;
}
else
{
lean_inc(v_a_3283_);
lean_dec(v___x_3168_);
v___x_3285_ = lean_box(0);
v_isShared_3286_ = v_isSharedCheck_3290_;
goto v_resetjp_3284_;
}
v_resetjp_3284_:
{
lean_object* v___x_3288_; 
if (v_isShared_3286_ == 0)
{
v___x_3288_ = v___x_3285_;
goto v_reusejp_3287_;
}
else
{
lean_object* v_reuseFailAlloc_3289_; 
v_reuseFailAlloc_3289_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3289_, 0, v_a_3283_);
v___x_3288_ = v_reuseFailAlloc_3289_;
goto v_reusejp_3287_;
}
v_reusejp_3287_:
{
return v___x_3288_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpRecRule(lean_object* v_rule_3293_, lean_object* v_a_3294_, lean_object* v_a_3295_){
_start:
{
lean_object* v_ctor_3297_; lean_object* v_nfields_3298_; lean_object* v_rhs_3299_; lean_object* v___x_3300_; 
v_ctor_3297_ = lean_ctor_get(v_rule_3293_, 0);
lean_inc(v_ctor_3297_);
v_nfields_3298_ = lean_ctor_get(v_rule_3293_, 1);
lean_inc(v_nfields_3298_);
v_rhs_3299_ = lean_ctor_get(v_rule_3293_, 2);
lean_inc_ref(v_rhs_3299_);
lean_dec_ref(v_rule_3293_);
v___x_3300_ = lp_proofEnvironment_dumpName(v_ctor_3297_, v_a_3294_, v_a_3295_);
if (lean_obj_tag(v___x_3300_) == 0)
{
lean_object* v_a_3301_; lean_object* v_fst_3302_; lean_object* v_snd_3303_; lean_object* v___x_3305_; uint8_t v_isShared_3306_; uint8_t v_isSharedCheck_3352_; 
v_a_3301_ = lean_ctor_get(v___x_3300_, 0);
lean_inc(v_a_3301_);
lean_dec_ref_known(v___x_3300_, 1);
v_fst_3302_ = lean_ctor_get(v_a_3301_, 0);
v_snd_3303_ = lean_ctor_get(v_a_3301_, 1);
v_isSharedCheck_3352_ = !lean_is_exclusive(v_a_3301_);
if (v_isSharedCheck_3352_ == 0)
{
v___x_3305_ = v_a_3301_;
v_isShared_3306_ = v_isSharedCheck_3352_;
goto v_resetjp_3304_;
}
else
{
lean_inc(v_snd_3303_);
lean_inc(v_fst_3302_);
lean_dec(v_a_3301_);
v___x_3305_ = lean_box(0);
v_isShared_3306_ = v_isSharedCheck_3352_;
goto v_resetjp_3304_;
}
v_resetjp_3304_:
{
lean_object* v___x_3307_; 
v___x_3307_ = lp_proofEnvironment_dumpExpr(v_rhs_3299_, v_a_3294_, v_snd_3303_);
if (lean_obj_tag(v___x_3307_) == 0)
{
lean_object* v_a_3308_; lean_object* v___x_3310_; uint8_t v_isShared_3311_; uint8_t v_isSharedCheck_3343_; 
v_a_3308_ = lean_ctor_get(v___x_3307_, 0);
v_isSharedCheck_3343_ = !lean_is_exclusive(v___x_3307_);
if (v_isSharedCheck_3343_ == 0)
{
v___x_3310_ = v___x_3307_;
v_isShared_3311_ = v_isSharedCheck_3343_;
goto v_resetjp_3309_;
}
else
{
lean_inc(v_a_3308_);
lean_dec(v___x_3307_);
v___x_3310_ = lean_box(0);
v_isShared_3311_ = v_isSharedCheck_3343_;
goto v_resetjp_3309_;
}
v_resetjp_3309_:
{
lean_object* v_fst_3312_; lean_object* v_snd_3313_; lean_object* v___x_3315_; uint8_t v_isShared_3316_; uint8_t v_isSharedCheck_3342_; 
v_fst_3312_ = lean_ctor_get(v_a_3308_, 0);
v_snd_3313_ = lean_ctor_get(v_a_3308_, 1);
v_isSharedCheck_3342_ = !lean_is_exclusive(v_a_3308_);
if (v_isSharedCheck_3342_ == 0)
{
v___x_3315_ = v_a_3308_;
v_isShared_3316_ = v_isSharedCheck_3342_;
goto v_resetjp_3314_;
}
else
{
lean_inc(v_snd_3313_);
lean_inc(v_fst_3312_);
lean_dec(v_a_3308_);
v___x_3315_ = lean_box(0);
v_isShared_3316_ = v_isSharedCheck_3342_;
goto v_resetjp_3314_;
}
v_resetjp_3314_:
{
lean_object* v___x_3317_; lean_object* v___x_3318_; lean_object* v___x_3319_; lean_object* v___x_3321_; 
v___x_3317_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__2));
v___x_3318_ = l_Lean_JsonNumber_fromNat(v_fst_3302_);
v___x_3319_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3319_, 0, v___x_3318_);
if (v_isShared_3316_ == 0)
{
lean_ctor_set(v___x_3315_, 1, v___x_3319_);
lean_ctor_set(v___x_3315_, 0, v___x_3317_);
v___x_3321_ = v___x_3315_;
goto v_reusejp_3320_;
}
else
{
lean_object* v_reuseFailAlloc_3341_; 
v_reuseFailAlloc_3341_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3341_, 0, v___x_3317_);
lean_ctor_set(v_reuseFailAlloc_3341_, 1, v___x_3319_);
v___x_3321_ = v_reuseFailAlloc_3341_;
goto v_reusejp_3320_;
}
v_reusejp_3320_:
{
lean_object* v___x_3322_; lean_object* v___x_3323_; lean_object* v___x_3324_; lean_object* v___x_3326_; 
v___x_3322_ = ((lean_object*)(lp_proofEnvironment_dumpConstant_dumpRecRule___closed__0));
v___x_3323_ = l_Lean_JsonNumber_fromNat(v_nfields_3298_);
v___x_3324_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3324_, 0, v___x_3323_);
if (v_isShared_3306_ == 0)
{
lean_ctor_set(v___x_3305_, 1, v___x_3324_);
lean_ctor_set(v___x_3305_, 0, v___x_3322_);
v___x_3326_ = v___x_3305_;
goto v_reusejp_3325_;
}
else
{
lean_object* v_reuseFailAlloc_3340_; 
v_reuseFailAlloc_3340_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3340_, 0, v___x_3322_);
lean_ctor_set(v_reuseFailAlloc_3340_, 1, v___x_3324_);
v___x_3326_ = v_reuseFailAlloc_3340_;
goto v_reusejp_3325_;
}
v_reusejp_3325_:
{
lean_object* v___x_3327_; lean_object* v___x_3328_; lean_object* v___x_3329_; lean_object* v___x_3330_; lean_object* v___x_3331_; lean_object* v___x_3332_; lean_object* v___x_3333_; lean_object* v___x_3334_; lean_object* v___x_3335_; lean_object* v___x_3336_; lean_object* v___x_3338_; 
v___x_3327_ = ((lean_object*)(lp_proofEnvironment_dumpConstant_dumpRecRule___closed__1));
v___x_3328_ = l_Lean_JsonNumber_fromNat(v_fst_3312_);
v___x_3329_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3329_, 0, v___x_3328_);
v___x_3330_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3330_, 0, v___x_3327_);
lean_ctor_set(v___x_3330_, 1, v___x_3329_);
v___x_3331_ = lean_box(0);
v___x_3332_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3332_, 0, v___x_3330_);
lean_ctor_set(v___x_3332_, 1, v___x_3331_);
v___x_3333_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3333_, 0, v___x_3326_);
lean_ctor_set(v___x_3333_, 1, v___x_3332_);
v___x_3334_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3334_, 0, v___x_3321_);
lean_ctor_set(v___x_3334_, 1, v___x_3333_);
v___x_3335_ = l_Lean_Json_mkObj(v___x_3334_);
lean_dec_ref_known(v___x_3334_, 2);
v___x_3336_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3336_, 0, v___x_3335_);
lean_ctor_set(v___x_3336_, 1, v_snd_3313_);
if (v_isShared_3311_ == 0)
{
lean_ctor_set(v___x_3310_, 0, v___x_3336_);
v___x_3338_ = v___x_3310_;
goto v_reusejp_3337_;
}
else
{
lean_object* v_reuseFailAlloc_3339_; 
v_reuseFailAlloc_3339_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3339_, 0, v___x_3336_);
v___x_3338_ = v_reuseFailAlloc_3339_;
goto v_reusejp_3337_;
}
v_reusejp_3337_:
{
return v___x_3338_;
}
}
}
}
}
}
else
{
lean_object* v_a_3344_; lean_object* v___x_3346_; uint8_t v_isShared_3347_; uint8_t v_isSharedCheck_3351_; 
lean_del_object(v___x_3305_);
lean_dec(v_fst_3302_);
lean_dec(v_nfields_3298_);
v_a_3344_ = lean_ctor_get(v___x_3307_, 0);
v_isSharedCheck_3351_ = !lean_is_exclusive(v___x_3307_);
if (v_isSharedCheck_3351_ == 0)
{
v___x_3346_ = v___x_3307_;
v_isShared_3347_ = v_isSharedCheck_3351_;
goto v_resetjp_3345_;
}
else
{
lean_inc(v_a_3344_);
lean_dec(v___x_3307_);
v___x_3346_ = lean_box(0);
v_isShared_3347_ = v_isSharedCheck_3351_;
goto v_resetjp_3345_;
}
v_resetjp_3345_:
{
lean_object* v___x_3349_; 
if (v_isShared_3347_ == 0)
{
v___x_3349_ = v___x_3346_;
goto v_reusejp_3348_;
}
else
{
lean_object* v_reuseFailAlloc_3350_; 
v_reuseFailAlloc_3350_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3350_, 0, v_a_3344_);
v___x_3349_ = v_reuseFailAlloc_3350_;
goto v_reusejp_3348_;
}
v_reusejp_3348_:
{
return v___x_3349_;
}
}
}
}
}
else
{
lean_object* v_a_3353_; lean_object* v___x_3355_; uint8_t v_isShared_3356_; uint8_t v_isSharedCheck_3360_; 
lean_dec_ref(v_rhs_3299_);
lean_dec(v_nfields_3298_);
v_a_3353_ = lean_ctor_get(v___x_3300_, 0);
v_isSharedCheck_3360_ = !lean_is_exclusive(v___x_3300_);
if (v_isSharedCheck_3360_ == 0)
{
v___x_3355_ = v___x_3300_;
v_isShared_3356_ = v_isSharedCheck_3360_;
goto v_resetjp_3354_;
}
else
{
lean_inc(v_a_3353_);
lean_dec(v___x_3300_);
v___x_3355_ = lean_box(0);
v_isShared_3356_ = v_isSharedCheck_3360_;
goto v_resetjp_3354_;
}
v_resetjp_3354_:
{
lean_object* v___x_3358_; 
if (v_isShared_3356_ == 0)
{
v___x_3358_ = v___x_3355_;
goto v_reusejp_3357_;
}
else
{
lean_object* v_reuseFailAlloc_3359_; 
v_reuseFailAlloc_3359_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3359_, 0, v_a_3353_);
v___x_3358_ = v_reuseFailAlloc_3359_;
goto v_reusejp_3357_;
}
v_reusejp_3357_:
{
return v___x_3358_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpConstant_spec__2(lean_object* v_x_3361_, lean_object* v_x_3362_, lean_object* v___y_3363_, lean_object* v___y_3364_){
_start:
{
if (lean_obj_tag(v_x_3361_) == 0)
{
lean_object* v___x_3366_; lean_object* v___x_3367_; lean_object* v___x_3368_; 
v___x_3366_ = l_List_reverse___redArg(v_x_3362_);
v___x_3367_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3367_, 0, v___x_3366_);
lean_ctor_set(v___x_3367_, 1, v___y_3364_);
v___x_3368_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3368_, 0, v___x_3367_);
return v___x_3368_;
}
else
{
lean_object* v_head_3369_; lean_object* v_tail_3370_; lean_object* v___x_3372_; uint8_t v_isShared_3373_; uint8_t v_isSharedCheck_3390_; 
v_head_3369_ = lean_ctor_get(v_x_3361_, 0);
v_tail_3370_ = lean_ctor_get(v_x_3361_, 1);
v_isSharedCheck_3390_ = !lean_is_exclusive(v_x_3361_);
if (v_isSharedCheck_3390_ == 0)
{
v___x_3372_ = v_x_3361_;
v_isShared_3373_ = v_isSharedCheck_3390_;
goto v_resetjp_3371_;
}
else
{
lean_inc(v_tail_3370_);
lean_inc(v_head_3369_);
lean_dec(v_x_3361_);
v___x_3372_ = lean_box(0);
v_isShared_3373_ = v_isSharedCheck_3390_;
goto v_resetjp_3371_;
}
v_resetjp_3371_:
{
lean_object* v___x_3374_; 
v___x_3374_ = lp_proofEnvironment_dumpConstant_dumpRecRule(v_head_3369_, v___y_3363_, v___y_3364_);
if (lean_obj_tag(v___x_3374_) == 0)
{
lean_object* v_a_3375_; lean_object* v_fst_3376_; lean_object* v_snd_3377_; lean_object* v___x_3379_; 
v_a_3375_ = lean_ctor_get(v___x_3374_, 0);
lean_inc(v_a_3375_);
lean_dec_ref_known(v___x_3374_, 1);
v_fst_3376_ = lean_ctor_get(v_a_3375_, 0);
lean_inc(v_fst_3376_);
v_snd_3377_ = lean_ctor_get(v_a_3375_, 1);
lean_inc(v_snd_3377_);
lean_dec(v_a_3375_);
if (v_isShared_3373_ == 0)
{
lean_ctor_set(v___x_3372_, 1, v_x_3362_);
lean_ctor_set(v___x_3372_, 0, v_fst_3376_);
v___x_3379_ = v___x_3372_;
goto v_reusejp_3378_;
}
else
{
lean_object* v_reuseFailAlloc_3381_; 
v_reuseFailAlloc_3381_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3381_, 0, v_fst_3376_);
lean_ctor_set(v_reuseFailAlloc_3381_, 1, v_x_3362_);
v___x_3379_ = v_reuseFailAlloc_3381_;
goto v_reusejp_3378_;
}
v_reusejp_3378_:
{
v_x_3361_ = v_tail_3370_;
v_x_3362_ = v___x_3379_;
v___y_3364_ = v_snd_3377_;
goto _start;
}
}
else
{
lean_object* v_a_3382_; lean_object* v___x_3384_; uint8_t v_isShared_3385_; uint8_t v_isSharedCheck_3389_; 
lean_del_object(v___x_3372_);
lean_dec(v_tail_3370_);
lean_dec(v_x_3362_);
v_a_3382_ = lean_ctor_get(v___x_3374_, 0);
v_isSharedCheck_3389_ = !lean_is_exclusive(v___x_3374_);
if (v_isSharedCheck_3389_ == 0)
{
v___x_3384_ = v___x_3374_;
v_isShared_3385_ = v_isSharedCheck_3389_;
goto v_resetjp_3383_;
}
else
{
lean_inc(v_a_3382_);
lean_dec(v___x_3374_);
v___x_3384_ = lean_box(0);
v_isShared_3385_ = v_isSharedCheck_3389_;
goto v_resetjp_3383_;
}
v_resetjp_3383_:
{
lean_object* v___x_3387_; 
if (v_isShared_3385_ == 0)
{
v___x_3387_ = v___x_3384_;
goto v_reusejp_3386_;
}
else
{
lean_object* v_reuseFailAlloc_3388_; 
v_reuseFailAlloc_3388_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3388_, 0, v_a_3382_);
v___x_3387_ = v_reuseFailAlloc_3388_;
goto v_reusejp_3386_;
}
v_reusejp_3386_:
{
return v___x_3387_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17(size_t v_sz_3395_, size_t v_i_3396_, lean_object* v_bs_3397_, lean_object* v___y_3398_, lean_object* v___y_3399_){
_start:
{
uint8_t v___x_3401_; 
v___x_3401_ = lean_usize_dec_lt(v_i_3396_, v_sz_3395_);
if (v___x_3401_ == 0)
{
lean_object* v___x_3402_; lean_object* v___x_3403_; 
v___x_3402_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3402_, 0, v_bs_3397_);
lean_ctor_set(v___x_3402_, 1, v___y_3399_);
v___x_3403_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3403_, 0, v___x_3402_);
return v___x_3403_;
}
else
{
lean_object* v_v_3404_; lean_object* v_toConstantVal_3405_; lean_object* v_all_3406_; lean_object* v_numParams_3407_; lean_object* v_numIndices_3408_; lean_object* v_numMotives_3409_; lean_object* v_numMinors_3410_; lean_object* v_rules_3411_; uint8_t v_k_3412_; uint8_t v_isUnsafe_3413_; lean_object* v_name_3414_; lean_object* v_levelParams_3415_; lean_object* v_type_3416_; lean_object* v___x_3417_; 
v_v_3404_ = lean_array_uget_borrowed(v_bs_3397_, v_i_3396_);
v_toConstantVal_3405_ = lean_ctor_get(v_v_3404_, 0);
v_all_3406_ = lean_ctor_get(v_v_3404_, 1);
lean_inc(v_all_3406_);
v_numParams_3407_ = lean_ctor_get(v_v_3404_, 2);
lean_inc(v_numParams_3407_);
v_numIndices_3408_ = lean_ctor_get(v_v_3404_, 3);
lean_inc(v_numIndices_3408_);
v_numMotives_3409_ = lean_ctor_get(v_v_3404_, 4);
lean_inc(v_numMotives_3409_);
v_numMinors_3410_ = lean_ctor_get(v_v_3404_, 5);
lean_inc(v_numMinors_3410_);
v_rules_3411_ = lean_ctor_get(v_v_3404_, 6);
lean_inc(v_rules_3411_);
v_k_3412_ = lean_ctor_get_uint8(v_v_3404_, sizeof(void*)*7);
v_isUnsafe_3413_ = lean_ctor_get_uint8(v_v_3404_, sizeof(void*)*7 + 1);
v_name_3414_ = lean_ctor_get(v_toConstantVal_3405_, 0);
v_levelParams_3415_ = lean_ctor_get(v_toConstantVal_3405_, 1);
lean_inc(v_levelParams_3415_);
v_type_3416_ = lean_ctor_get(v_toConstantVal_3405_, 2);
lean_inc_ref(v_type_3416_);
lean_inc(v_name_3414_);
v___x_3417_ = lp_proofEnvironment_dumpName(v_name_3414_, v___y_3398_, v___y_3399_);
if (lean_obj_tag(v___x_3417_) == 0)
{
lean_object* v_a_3418_; lean_object* v_fst_3419_; lean_object* v_snd_3420_; lean_object* v___x_3422_; uint8_t v_isShared_3423_; uint8_t v_isSharedCheck_3566_; 
v_a_3418_ = lean_ctor_get(v___x_3417_, 0);
lean_inc(v_a_3418_);
lean_dec_ref_known(v___x_3417_, 1);
v_fst_3419_ = lean_ctor_get(v_a_3418_, 0);
v_snd_3420_ = lean_ctor_get(v_a_3418_, 1);
v_isSharedCheck_3566_ = !lean_is_exclusive(v_a_3418_);
if (v_isSharedCheck_3566_ == 0)
{
v___x_3422_ = v_a_3418_;
v_isShared_3423_ = v_isSharedCheck_3566_;
goto v_resetjp_3421_;
}
else
{
lean_inc(v_snd_3420_);
lean_inc(v_fst_3419_);
lean_dec(v_a_3418_);
v___x_3422_ = lean_box(0);
v_isShared_3423_ = v_isSharedCheck_3566_;
goto v_resetjp_3421_;
}
v_resetjp_3421_:
{
lean_object* v___x_3424_; lean_object* v_bs_x27_3425_; lean_object* v_fst_3427_; lean_object* v_snd_3428_; lean_object* v___y_3434_; lean_object* v___x_3446_; 
v___x_3424_ = lean_unsigned_to_nat(0u);
v_bs_x27_3425_ = lean_array_uset(v_bs_3397_, v_i_3396_, v___x_3424_);
v___x_3446_ = lp_proofEnvironment_dumpUparams(v_levelParams_3415_, v___y_3398_, v_snd_3420_);
if (lean_obj_tag(v___x_3446_) == 0)
{
lean_object* v_a_3447_; lean_object* v___x_3449_; uint8_t v_isShared_3450_; uint8_t v_isSharedCheck_3565_; 
v_a_3447_ = lean_ctor_get(v___x_3446_, 0);
v_isSharedCheck_3565_ = !lean_is_exclusive(v___x_3446_);
if (v_isSharedCheck_3565_ == 0)
{
v___x_3449_ = v___x_3446_;
v_isShared_3450_ = v_isSharedCheck_3565_;
goto v_resetjp_3448_;
}
else
{
lean_inc(v_a_3447_);
lean_dec(v___x_3446_);
v___x_3449_ = lean_box(0);
v_isShared_3450_ = v_isSharedCheck_3565_;
goto v_resetjp_3448_;
}
v_resetjp_3448_:
{
lean_object* v_fst_3451_; lean_object* v_snd_3452_; lean_object* v___x_3454_; uint8_t v_isShared_3455_; uint8_t v_isSharedCheck_3564_; 
v_fst_3451_ = lean_ctor_get(v_a_3447_, 0);
v_snd_3452_ = lean_ctor_get(v_a_3447_, 1);
v_isSharedCheck_3564_ = !lean_is_exclusive(v_a_3447_);
if (v_isSharedCheck_3564_ == 0)
{
v___x_3454_ = v_a_3447_;
v_isShared_3455_ = v_isSharedCheck_3564_;
goto v_resetjp_3453_;
}
else
{
lean_inc(v_snd_3452_);
lean_inc(v_fst_3451_);
lean_dec(v_a_3447_);
v___x_3454_ = lean_box(0);
v_isShared_3455_ = v_isSharedCheck_3564_;
goto v_resetjp_3453_;
}
v_resetjp_3453_:
{
lean_object* v___x_3456_; 
v___x_3456_ = lp_proofEnvironment_dumpExpr(v_type_3416_, v___y_3398_, v_snd_3452_);
if (lean_obj_tag(v___x_3456_) == 0)
{
lean_object* v_a_3457_; lean_object* v_fst_3458_; lean_object* v_snd_3459_; lean_object* v___x_3461_; uint8_t v_isShared_3462_; uint8_t v_isSharedCheck_3555_; 
v_a_3457_ = lean_ctor_get(v___x_3456_, 0);
lean_inc(v_a_3457_);
lean_dec_ref_known(v___x_3456_, 1);
v_fst_3458_ = lean_ctor_get(v_a_3457_, 0);
v_snd_3459_ = lean_ctor_get(v_a_3457_, 1);
v_isSharedCheck_3555_ = !lean_is_exclusive(v_a_3457_);
if (v_isSharedCheck_3555_ == 0)
{
v___x_3461_ = v_a_3457_;
v_isShared_3462_ = v_isSharedCheck_3555_;
goto v_resetjp_3460_;
}
else
{
lean_inc(v_snd_3459_);
lean_inc(v_fst_3458_);
lean_dec(v_a_3457_);
v___x_3461_ = lean_box(0);
v_isShared_3462_ = v_isSharedCheck_3555_;
goto v_resetjp_3460_;
}
v_resetjp_3460_:
{
lean_object* v___x_3463_; 
v___x_3463_ = lp_proofEnvironment_dumpNames(v_all_3406_, v___y_3398_, v_snd_3459_);
if (lean_obj_tag(v___x_3463_) == 0)
{
lean_object* v_a_3464_; lean_object* v___x_3466_; uint8_t v_isShared_3467_; uint8_t v_isSharedCheck_3554_; 
v_a_3464_ = lean_ctor_get(v___x_3463_, 0);
v_isSharedCheck_3554_ = !lean_is_exclusive(v___x_3463_);
if (v_isSharedCheck_3554_ == 0)
{
v___x_3466_ = v___x_3463_;
v_isShared_3467_ = v_isSharedCheck_3554_;
goto v_resetjp_3465_;
}
else
{
lean_inc(v_a_3464_);
lean_dec(v___x_3463_);
v___x_3466_ = lean_box(0);
v_isShared_3467_ = v_isSharedCheck_3554_;
goto v_resetjp_3465_;
}
v_resetjp_3465_:
{
lean_object* v_fst_3468_; lean_object* v_snd_3469_; lean_object* v___x_3471_; uint8_t v_isShared_3472_; uint8_t v_isSharedCheck_3553_; 
v_fst_3468_ = lean_ctor_get(v_a_3464_, 0);
v_snd_3469_ = lean_ctor_get(v_a_3464_, 1);
v_isSharedCheck_3553_ = !lean_is_exclusive(v_a_3464_);
if (v_isSharedCheck_3553_ == 0)
{
v___x_3471_ = v_a_3464_;
v_isShared_3472_ = v_isSharedCheck_3553_;
goto v_resetjp_3470_;
}
else
{
lean_inc(v_snd_3469_);
lean_inc(v_fst_3468_);
lean_dec(v_a_3464_);
v___x_3471_ = lean_box(0);
v_isShared_3472_ = v_isSharedCheck_3553_;
goto v_resetjp_3470_;
}
v_resetjp_3470_:
{
lean_object* v___x_3473_; lean_object* v___x_3474_; 
v___x_3473_ = lean_box(0);
v___x_3474_ = lp_proofEnvironment_List_mapM_loop___at___00dumpConstant_spec__2(v_rules_3411_, v___x_3473_, v___y_3398_, v_snd_3469_);
if (lean_obj_tag(v___x_3474_) == 0)
{
lean_object* v_a_3475_; lean_object* v_fst_3476_; lean_object* v_snd_3477_; lean_object* v___x_3479_; uint8_t v_isShared_3480_; uint8_t v_isSharedCheck_3544_; 
v_a_3475_ = lean_ctor_get(v___x_3474_, 0);
lean_inc(v_a_3475_);
lean_dec_ref_known(v___x_3474_, 1);
v_fst_3476_ = lean_ctor_get(v_a_3475_, 0);
v_snd_3477_ = lean_ctor_get(v_a_3475_, 1);
v_isSharedCheck_3544_ = !lean_is_exclusive(v_a_3475_);
if (v_isSharedCheck_3544_ == 0)
{
v___x_3479_ = v_a_3475_;
v_isShared_3480_ = v_isSharedCheck_3544_;
goto v_resetjp_3478_;
}
else
{
lean_inc(v_snd_3477_);
lean_inc(v_fst_3476_);
lean_dec(v_a_3475_);
v___x_3479_ = lean_box(0);
v_isShared_3480_ = v_isSharedCheck_3544_;
goto v_resetjp_3478_;
}
v_resetjp_3478_:
{
lean_object* v___x_3481_; lean_object* v___x_3482_; lean_object* v___x_3484_; 
v___x_3481_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_3482_ = l_Lean_JsonNumber_fromNat(v_fst_3419_);
if (v_isShared_3467_ == 0)
{
lean_ctor_set_tag(v___x_3466_, 2);
lean_ctor_set(v___x_3466_, 0, v___x_3482_);
v___x_3484_ = v___x_3466_;
goto v_reusejp_3483_;
}
else
{
lean_object* v_reuseFailAlloc_3543_; 
v_reuseFailAlloc_3543_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3543_, 0, v___x_3482_);
v___x_3484_ = v_reuseFailAlloc_3543_;
goto v_reusejp_3483_;
}
v_reusejp_3483_:
{
lean_object* v___x_3486_; 
if (v_isShared_3480_ == 0)
{
lean_ctor_set(v___x_3479_, 1, v___x_3484_);
lean_ctor_set(v___x_3479_, 0, v___x_3481_);
v___x_3486_ = v___x_3479_;
goto v_reusejp_3485_;
}
else
{
lean_object* v_reuseFailAlloc_3542_; 
v_reuseFailAlloc_3542_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3542_, 0, v___x_3481_);
lean_ctor_set(v_reuseFailAlloc_3542_, 1, v___x_3484_);
v___x_3486_ = v_reuseFailAlloc_3542_;
goto v_reusejp_3485_;
}
v_reusejp_3485_:
{
lean_object* v___x_3487_; lean_object* v___x_3489_; 
v___x_3487_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_3472_ == 0)
{
lean_ctor_set(v___x_3471_, 1, v_fst_3451_);
lean_ctor_set(v___x_3471_, 0, v___x_3487_);
v___x_3489_ = v___x_3471_;
goto v_reusejp_3488_;
}
else
{
lean_object* v_reuseFailAlloc_3541_; 
v_reuseFailAlloc_3541_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3541_, 0, v___x_3487_);
lean_ctor_set(v_reuseFailAlloc_3541_, 1, v_fst_3451_);
v___x_3489_ = v_reuseFailAlloc_3541_;
goto v_reusejp_3488_;
}
v_reusejp_3488_:
{
lean_object* v___x_3490_; lean_object* v___x_3491_; lean_object* v___x_3493_; 
v___x_3490_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_3491_ = l_Lean_JsonNumber_fromNat(v_fst_3458_);
if (v_isShared_3450_ == 0)
{
lean_ctor_set_tag(v___x_3449_, 2);
lean_ctor_set(v___x_3449_, 0, v___x_3491_);
v___x_3493_ = v___x_3449_;
goto v_reusejp_3492_;
}
else
{
lean_object* v_reuseFailAlloc_3540_; 
v_reuseFailAlloc_3540_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3540_, 0, v___x_3491_);
v___x_3493_ = v_reuseFailAlloc_3540_;
goto v_reusejp_3492_;
}
v_reusejp_3492_:
{
lean_object* v___x_3495_; 
if (v_isShared_3462_ == 0)
{
lean_ctor_set(v___x_3461_, 1, v___x_3493_);
lean_ctor_set(v___x_3461_, 0, v___x_3490_);
v___x_3495_ = v___x_3461_;
goto v_reusejp_3494_;
}
else
{
lean_object* v_reuseFailAlloc_3539_; 
v_reuseFailAlloc_3539_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3539_, 0, v___x_3490_);
lean_ctor_set(v_reuseFailAlloc_3539_, 1, v___x_3493_);
v___x_3495_ = v_reuseFailAlloc_3539_;
goto v_reusejp_3494_;
}
v_reusejp_3494_:
{
lean_object* v___x_3496_; lean_object* v___x_3498_; 
v___x_3496_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1));
if (v_isShared_3455_ == 0)
{
lean_ctor_set(v___x_3454_, 1, v_fst_3468_);
lean_ctor_set(v___x_3454_, 0, v___x_3496_);
v___x_3498_ = v___x_3454_;
goto v_reusejp_3497_;
}
else
{
lean_object* v_reuseFailAlloc_3538_; 
v_reuseFailAlloc_3538_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3538_, 0, v___x_3496_);
lean_ctor_set(v_reuseFailAlloc_3538_, 1, v_fst_3468_);
v___x_3498_ = v_reuseFailAlloc_3538_;
goto v_reusejp_3497_;
}
v_reusejp_3497_:
{
lean_object* v___x_3499_; lean_object* v___x_3500_; lean_object* v___x_3501_; lean_object* v___x_3503_; 
v___x_3499_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__4));
v___x_3500_ = l_Lean_JsonNumber_fromNat(v_numParams_3407_);
v___x_3501_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3501_, 0, v___x_3500_);
if (v_isShared_3423_ == 0)
{
lean_ctor_set(v___x_3422_, 1, v___x_3501_);
lean_ctor_set(v___x_3422_, 0, v___x_3499_);
v___x_3503_ = v___x_3422_;
goto v_reusejp_3502_;
}
else
{
lean_object* v_reuseFailAlloc_3537_; 
v_reuseFailAlloc_3537_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3537_, 0, v___x_3499_);
lean_ctor_set(v_reuseFailAlloc_3537_, 1, v___x_3501_);
v___x_3503_ = v_reuseFailAlloc_3537_;
goto v_reusejp_3502_;
}
v_reusejp_3502_:
{
lean_object* v___x_3504_; lean_object* v___x_3505_; lean_object* v___x_3506_; lean_object* v___x_3507_; lean_object* v___x_3508_; lean_object* v___x_3509_; lean_object* v___x_3510_; lean_object* v___x_3511_; lean_object* v___x_3512_; lean_object* v___x_3513_; lean_object* v___x_3514_; lean_object* v___x_3515_; lean_object* v___x_3516_; lean_object* v___x_3517_; lean_object* v___x_3518_; lean_object* v___x_3519_; lean_object* v___x_3520_; lean_object* v___x_3521_; lean_object* v___x_3522_; lean_object* v___x_3523_; lean_object* v___x_3524_; lean_object* v___x_3525_; lean_object* v___x_3526_; lean_object* v___x_3527_; lean_object* v___x_3528_; lean_object* v___x_3529_; lean_object* v___x_3530_; lean_object* v___x_3531_; lean_object* v___x_3532_; lean_object* v___x_3533_; lean_object* v___x_3534_; lean_object* v___x_3535_; lean_object* v___x_3536_; 
v___x_3504_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__0));
v___x_3505_ = l_Lean_JsonNumber_fromNat(v_numIndices_3408_);
v___x_3506_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3506_, 0, v___x_3505_);
v___x_3507_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3507_, 0, v___x_3504_);
lean_ctor_set(v___x_3507_, 1, v___x_3506_);
v___x_3508_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__0));
v___x_3509_ = l_Lean_JsonNumber_fromNat(v_numMotives_3409_);
v___x_3510_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3510_, 0, v___x_3509_);
v___x_3511_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3511_, 0, v___x_3508_);
lean_ctor_set(v___x_3511_, 1, v___x_3510_);
v___x_3512_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__1));
v___x_3513_ = l_Lean_JsonNumber_fromNat(v_numMinors_3410_);
v___x_3514_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_3514_, 0, v___x_3513_);
v___x_3515_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3515_, 0, v___x_3512_);
lean_ctor_set(v___x_3515_, 1, v___x_3514_);
v___x_3516_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__2));
v___x_3517_ = l_Lean_List_toJson___at___00Lean_Option_toJson___at___00Lean_Server_instToJsonIlean_toJson_spec__1_spec__1(v_fst_3476_);
v___x_3518_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3518_, 0, v___x_3516_);
lean_ctor_set(v___x_3518_, 1, v___x_3517_);
v___x_3519_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___closed__3));
v___x_3520_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3520_, 0, v_k_3412_);
v___x_3521_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3521_, 0, v___x_3519_);
lean_ctor_set(v___x_3521_, 1, v___x_3520_);
v___x_3522_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6));
v___x_3523_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_3523_, 0, v_isUnsafe_3413_);
v___x_3524_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3524_, 0, v___x_3522_);
lean_ctor_set(v___x_3524_, 1, v___x_3523_);
v___x_3525_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3525_, 0, v___x_3524_);
lean_ctor_set(v___x_3525_, 1, v___x_3473_);
v___x_3526_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3526_, 0, v___x_3521_);
lean_ctor_set(v___x_3526_, 1, v___x_3525_);
v___x_3527_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3527_, 0, v___x_3518_);
lean_ctor_set(v___x_3527_, 1, v___x_3526_);
v___x_3528_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3528_, 0, v___x_3515_);
lean_ctor_set(v___x_3528_, 1, v___x_3527_);
v___x_3529_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3529_, 0, v___x_3511_);
lean_ctor_set(v___x_3529_, 1, v___x_3528_);
v___x_3530_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3530_, 0, v___x_3507_);
lean_ctor_set(v___x_3530_, 1, v___x_3529_);
v___x_3531_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3531_, 0, v___x_3503_);
lean_ctor_set(v___x_3531_, 1, v___x_3530_);
v___x_3532_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3532_, 0, v___x_3498_);
lean_ctor_set(v___x_3532_, 1, v___x_3531_);
v___x_3533_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3533_, 0, v___x_3495_);
lean_ctor_set(v___x_3533_, 1, v___x_3532_);
v___x_3534_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3534_, 0, v___x_3489_);
lean_ctor_set(v___x_3534_, 1, v___x_3533_);
v___x_3535_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3535_, 0, v___x_3486_);
lean_ctor_set(v___x_3535_, 1, v___x_3534_);
v___x_3536_ = l_Lean_Json_mkObj(v___x_3535_);
lean_dec_ref_known(v___x_3535_, 2);
v_fst_3427_ = v___x_3536_;
v_snd_3428_ = v_snd_3477_;
goto v___jp_3426_;
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_3545_; lean_object* v___x_3547_; uint8_t v_isShared_3548_; uint8_t v_isSharedCheck_3552_; 
lean_del_object(v___x_3471_);
lean_dec(v_fst_3468_);
lean_del_object(v___x_3466_);
lean_del_object(v___x_3461_);
lean_dec(v_fst_3458_);
lean_del_object(v___x_3454_);
lean_dec(v_fst_3451_);
lean_del_object(v___x_3449_);
lean_dec_ref(v_bs_x27_3425_);
lean_del_object(v___x_3422_);
lean_dec(v_fst_3419_);
lean_dec(v_numMinors_3410_);
lean_dec(v_numMotives_3409_);
lean_dec(v_numIndices_3408_);
lean_dec(v_numParams_3407_);
v_a_3545_ = lean_ctor_get(v___x_3474_, 0);
v_isSharedCheck_3552_ = !lean_is_exclusive(v___x_3474_);
if (v_isSharedCheck_3552_ == 0)
{
v___x_3547_ = v___x_3474_;
v_isShared_3548_ = v_isSharedCheck_3552_;
goto v_resetjp_3546_;
}
else
{
lean_inc(v_a_3545_);
lean_dec(v___x_3474_);
v___x_3547_ = lean_box(0);
v_isShared_3548_ = v_isSharedCheck_3552_;
goto v_resetjp_3546_;
}
v_resetjp_3546_:
{
lean_object* v___x_3550_; 
if (v_isShared_3548_ == 0)
{
v___x_3550_ = v___x_3547_;
goto v_reusejp_3549_;
}
else
{
lean_object* v_reuseFailAlloc_3551_; 
v_reuseFailAlloc_3551_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3551_, 0, v_a_3545_);
v___x_3550_ = v_reuseFailAlloc_3551_;
goto v_reusejp_3549_;
}
v_reusejp_3549_:
{
return v___x_3550_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_3461_);
lean_dec(v_fst_3458_);
lean_del_object(v___x_3454_);
lean_dec(v_fst_3451_);
lean_del_object(v___x_3449_);
lean_del_object(v___x_3422_);
lean_dec(v_fst_3419_);
lean_dec(v_rules_3411_);
lean_dec(v_numMinors_3410_);
lean_dec(v_numMotives_3409_);
lean_dec(v_numIndices_3408_);
lean_dec(v_numParams_3407_);
v___y_3434_ = v___x_3463_;
goto v___jp_3433_;
}
}
}
else
{
lean_object* v_a_3556_; lean_object* v___x_3558_; uint8_t v_isShared_3559_; uint8_t v_isSharedCheck_3563_; 
lean_del_object(v___x_3454_);
lean_dec(v_fst_3451_);
lean_del_object(v___x_3449_);
lean_dec_ref(v_bs_x27_3425_);
lean_del_object(v___x_3422_);
lean_dec(v_fst_3419_);
lean_dec(v_rules_3411_);
lean_dec(v_numMinors_3410_);
lean_dec(v_numMotives_3409_);
lean_dec(v_numIndices_3408_);
lean_dec(v_numParams_3407_);
lean_dec(v_all_3406_);
v_a_3556_ = lean_ctor_get(v___x_3456_, 0);
v_isSharedCheck_3563_ = !lean_is_exclusive(v___x_3456_);
if (v_isSharedCheck_3563_ == 0)
{
v___x_3558_ = v___x_3456_;
v_isShared_3559_ = v_isSharedCheck_3563_;
goto v_resetjp_3557_;
}
else
{
lean_inc(v_a_3556_);
lean_dec(v___x_3456_);
v___x_3558_ = lean_box(0);
v_isShared_3559_ = v_isSharedCheck_3563_;
goto v_resetjp_3557_;
}
v_resetjp_3557_:
{
lean_object* v___x_3561_; 
if (v_isShared_3559_ == 0)
{
v___x_3561_ = v___x_3558_;
goto v_reusejp_3560_;
}
else
{
lean_object* v_reuseFailAlloc_3562_; 
v_reuseFailAlloc_3562_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3562_, 0, v_a_3556_);
v___x_3561_ = v_reuseFailAlloc_3562_;
goto v_reusejp_3560_;
}
v_reusejp_3560_:
{
return v___x_3561_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_3422_);
lean_dec(v_fst_3419_);
lean_dec_ref(v_type_3416_);
lean_dec(v_rules_3411_);
lean_dec(v_numMinors_3410_);
lean_dec(v_numMotives_3409_);
lean_dec(v_numIndices_3408_);
lean_dec(v_numParams_3407_);
lean_dec(v_all_3406_);
v___y_3434_ = v___x_3446_;
goto v___jp_3433_;
}
v___jp_3426_:
{
size_t v___x_3429_; size_t v___x_3430_; lean_object* v___x_3431_; 
v___x_3429_ = ((size_t)1ULL);
v___x_3430_ = lean_usize_add(v_i_3396_, v___x_3429_);
v___x_3431_ = lean_array_uset(v_bs_x27_3425_, v_i_3396_, v_fst_3427_);
v_i_3396_ = v___x_3430_;
v_bs_3397_ = v___x_3431_;
v___y_3399_ = v_snd_3428_;
goto _start;
}
v___jp_3433_:
{
if (lean_obj_tag(v___y_3434_) == 0)
{
lean_object* v_a_3435_; lean_object* v_fst_3436_; lean_object* v_snd_3437_; 
v_a_3435_ = lean_ctor_get(v___y_3434_, 0);
lean_inc(v_a_3435_);
lean_dec_ref_known(v___y_3434_, 1);
v_fst_3436_ = lean_ctor_get(v_a_3435_, 0);
lean_inc(v_fst_3436_);
v_snd_3437_ = lean_ctor_get(v_a_3435_, 1);
lean_inc(v_snd_3437_);
lean_dec(v_a_3435_);
v_fst_3427_ = v_fst_3436_;
v_snd_3428_ = v_snd_3437_;
goto v___jp_3426_;
}
else
{
lean_object* v_a_3438_; lean_object* v___x_3440_; uint8_t v_isShared_3441_; uint8_t v_isSharedCheck_3445_; 
lean_dec_ref(v_bs_x27_3425_);
v_a_3438_ = lean_ctor_get(v___y_3434_, 0);
v_isSharedCheck_3445_ = !lean_is_exclusive(v___y_3434_);
if (v_isSharedCheck_3445_ == 0)
{
v___x_3440_ = v___y_3434_;
v_isShared_3441_ = v_isSharedCheck_3445_;
goto v_resetjp_3439_;
}
else
{
lean_inc(v_a_3438_);
lean_dec(v___y_3434_);
v___x_3440_ = lean_box(0);
v_isShared_3441_ = v_isSharedCheck_3445_;
goto v_resetjp_3439_;
}
v_resetjp_3439_:
{
lean_object* v___x_3443_; 
if (v_isShared_3441_ == 0)
{
v___x_3443_ = v___x_3440_;
goto v_reusejp_3442_;
}
else
{
lean_object* v_reuseFailAlloc_3444_; 
v_reuseFailAlloc_3444_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3444_, 0, v_a_3438_);
v___x_3443_ = v_reuseFailAlloc_3444_;
goto v_reusejp_3442_;
}
v_reusejp_3442_:
{
return v___x_3443_;
}
}
}
}
}
}
else
{
lean_object* v_a_3567_; lean_object* v___x_3569_; uint8_t v_isShared_3570_; uint8_t v_isSharedCheck_3574_; 
lean_dec_ref(v_type_3416_);
lean_dec(v_levelParams_3415_);
lean_dec(v_rules_3411_);
lean_dec(v_numMinors_3410_);
lean_dec(v_numMotives_3409_);
lean_dec(v_numIndices_3408_);
lean_dec(v_numParams_3407_);
lean_dec(v_all_3406_);
lean_dec_ref(v_bs_3397_);
v_a_3567_ = lean_ctor_get(v___x_3417_, 0);
v_isSharedCheck_3574_ = !lean_is_exclusive(v___x_3417_);
if (v_isSharedCheck_3574_ == 0)
{
v___x_3569_ = v___x_3417_;
v_isShared_3570_ = v_isSharedCheck_3574_;
goto v_resetjp_3568_;
}
else
{
lean_inc(v_a_3567_);
lean_dec(v___x_3417_);
v___x_3569_ = lean_box(0);
v_isShared_3570_ = v_isSharedCheck_3574_;
goto v_resetjp_3568_;
}
v_resetjp_3568_:
{
lean_object* v___x_3572_; 
if (v_isShared_3570_ == 0)
{
v___x_3572_ = v___x_3569_;
goto v_reusejp_3571_;
}
else
{
lean_object* v_reuseFailAlloc_3573_; 
v_reuseFailAlloc_3573_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3573_, 0, v_a_3567_);
v___x_3572_ = v_reuseFailAlloc_3573_;
goto v_reusejp_3571_;
}
v_reusejp_3571_:
{
return v___x_3572_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg(uint8_t v___x_3623_, lean_object* v_as_x27_3624_, lean_object* v_b_3625_, lean_object* v___y_3626_, lean_object* v___y_3627_){
_start:
{
if (lean_obj_tag(v_as_x27_3624_) == 0)
{
lean_object* v___x_3629_; lean_object* v___x_3630_; 
v___x_3629_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3629_, 0, v_b_3625_);
lean_ctor_set(v___x_3629_, 1, v___y_3627_);
v___x_3630_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3630_, 0, v___x_3629_);
return v___x_3630_;
}
else
{
lean_object* v_head_3631_; lean_object* v_tail_3632_; lean_object* v___x_3633_; lean_object* v___y_3635_; lean_object* v___y_3636_; lean_object* v___x_3664_; 
lean_dec_ref(v_b_3625_);
v_head_3631_ = lean_ctor_get(v_as_x27_3624_, 0);
v_tail_3632_ = lean_ctor_get(v_as_x27_3624_, 1);
v___x_3633_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__0));
lean_inc(v_head_3631_);
lean_inc_ref(v___y_3626_);
v___x_3664_ = l_Lean_Environment_find_x3f(v___y_3626_, v_head_3631_, v___x_3623_);
if (lean_obj_tag(v___x_3664_) == 1)
{
lean_object* v_val_3665_; lean_object* v___x_3667_; uint8_t v_isShared_3668_; uint8_t v_isSharedCheck_3788_; 
v_val_3665_ = lean_ctor_get(v___x_3664_, 0);
v_isSharedCheck_3788_ = !lean_is_exclusive(v___x_3664_);
if (v_isSharedCheck_3788_ == 0)
{
v___x_3667_ = v___x_3664_;
v_isShared_3668_ = v_isSharedCheck_3788_;
goto v_resetjp_3666_;
}
else
{
lean_inc(v_val_3665_);
lean_dec(v___x_3664_);
v___x_3667_ = lean_box(0);
v_isShared_3668_ = v_isSharedCheck_3788_;
goto v_resetjp_3666_;
}
v_resetjp_3666_:
{
if (lean_obj_tag(v_val_3665_) == 4)
{
lean_object* v_val_3669_; lean_object* v___x_3671_; uint8_t v_isShared_3672_; uint8_t v_isSharedCheck_3787_; 
v_val_3669_ = lean_ctor_get(v_val_3665_, 0);
v_isSharedCheck_3787_ = !lean_is_exclusive(v_val_3665_);
if (v_isSharedCheck_3787_ == 0)
{
v___x_3671_ = v_val_3665_;
v_isShared_3672_ = v_isSharedCheck_3787_;
goto v_resetjp_3670_;
}
else
{
lean_inc(v_val_3669_);
lean_dec(v_val_3665_);
v___x_3671_ = lean_box(0);
v_isShared_3672_ = v_isSharedCheck_3787_;
goto v_resetjp_3670_;
}
v_resetjp_3670_:
{
lean_object* v_toConstantVal_3673_; lean_object* v_visitedNames_3674_; lean_object* v_visitedLevels_3675_; lean_object* v_visitedExprs_3676_; lean_object* v_visitedConstants_3677_; lean_object* v_noMDataExprs_3678_; uint8_t v_exportMData_3679_; uint8_t v_exportUnsafe_3680_; uint8_t v_ignoreMissing_3681_; lean_object* v_recursorMap_3682_; lean_object* v___x_3684_; uint8_t v_isShared_3685_; uint8_t v_isSharedCheck_3786_; 
v_toConstantVal_3673_ = lean_ctor_get(v_val_3669_, 0);
lean_inc_ref(v_toConstantVal_3673_);
v_visitedNames_3674_ = lean_ctor_get(v___y_3627_, 0);
v_visitedLevels_3675_ = lean_ctor_get(v___y_3627_, 1);
v_visitedExprs_3676_ = lean_ctor_get(v___y_3627_, 2);
v_visitedConstants_3677_ = lean_ctor_get(v___y_3627_, 3);
v_noMDataExprs_3678_ = lean_ctor_get(v___y_3627_, 4);
v_exportMData_3679_ = lean_ctor_get_uint8(v___y_3627_, sizeof(void*)*6);
v_exportUnsafe_3680_ = lean_ctor_get_uint8(v___y_3627_, sizeof(void*)*6 + 1);
v_ignoreMissing_3681_ = lean_ctor_get_uint8(v___y_3627_, sizeof(void*)*6 + 2);
v_recursorMap_3682_ = lean_ctor_get(v___y_3627_, 5);
v_isSharedCheck_3786_ = !lean_is_exclusive(v___y_3627_);
if (v_isSharedCheck_3786_ == 0)
{
v___x_3684_ = v___y_3627_;
v_isShared_3685_ = v_isSharedCheck_3786_;
goto v_resetjp_3683_;
}
else
{
lean_inc(v_recursorMap_3682_);
lean_inc(v_noMDataExprs_3678_);
lean_inc(v_visitedConstants_3677_);
lean_inc(v_visitedExprs_3676_);
lean_inc(v_visitedLevels_3675_);
lean_inc(v_visitedNames_3674_);
lean_dec(v___y_3627_);
v___x_3684_ = lean_box(0);
v_isShared_3685_ = v_isSharedCheck_3786_;
goto v_resetjp_3683_;
}
v_resetjp_3683_:
{
uint8_t v_kind_3686_; lean_object* v_name_3687_; lean_object* v_levelParams_3688_; lean_object* v_type_3689_; lean_object* v___x_3690_; lean_object* v___x_3692_; 
v_kind_3686_ = lean_ctor_get_uint8(v_val_3669_, sizeof(void*)*1);
lean_dec_ref(v_val_3669_);
v_name_3687_ = lean_ctor_get(v_toConstantVal_3673_, 0);
lean_inc(v_name_3687_);
v_levelParams_3688_ = lean_ctor_get(v_toConstantVal_3673_, 1);
lean_inc(v_levelParams_3688_);
v_type_3689_ = lean_ctor_get(v_toConstantVal_3673_, 2);
lean_inc_ref(v_type_3689_);
lean_dec_ref(v_toConstantVal_3673_);
lean_inc(v_head_3631_);
v___x_3690_ = l_Lean_NameHashSet_insert(v_visitedConstants_3677_, v_head_3631_);
if (v_isShared_3685_ == 0)
{
lean_ctor_set(v___x_3684_, 3, v___x_3690_);
v___x_3692_ = v___x_3684_;
goto v_reusejp_3691_;
}
else
{
lean_object* v_reuseFailAlloc_3785_; 
v_reuseFailAlloc_3785_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_3785_, 0, v_visitedNames_3674_);
lean_ctor_set(v_reuseFailAlloc_3785_, 1, v_visitedLevels_3675_);
lean_ctor_set(v_reuseFailAlloc_3785_, 2, v_visitedExprs_3676_);
lean_ctor_set(v_reuseFailAlloc_3785_, 3, v___x_3690_);
lean_ctor_set(v_reuseFailAlloc_3785_, 4, v_noMDataExprs_3678_);
lean_ctor_set(v_reuseFailAlloc_3785_, 5, v_recursorMap_3682_);
lean_ctor_set_uint8(v_reuseFailAlloc_3785_, sizeof(void*)*6, v_exportMData_3679_);
lean_ctor_set_uint8(v_reuseFailAlloc_3785_, sizeof(void*)*6 + 1, v_exportUnsafe_3680_);
lean_ctor_set_uint8(v_reuseFailAlloc_3785_, sizeof(void*)*6 + 2, v_ignoreMissing_3681_);
v___x_3692_ = v_reuseFailAlloc_3785_;
goto v_reusejp_3691_;
}
v_reusejp_3691_:
{
lean_object* v___x_3693_; 
v___x_3693_ = lp_proofEnvironment_dumpName(v_name_3687_, v___y_3626_, v___x_3692_);
if (lean_obj_tag(v___x_3693_) == 0)
{
lean_object* v_a_3694_; lean_object* v_fst_3695_; lean_object* v_snd_3696_; lean_object* v___x_3698_; uint8_t v_isShared_3699_; uint8_t v_isSharedCheck_3776_; 
v_a_3694_ = lean_ctor_get(v___x_3693_, 0);
lean_inc(v_a_3694_);
lean_dec_ref_known(v___x_3693_, 1);
v_fst_3695_ = lean_ctor_get(v_a_3694_, 0);
v_snd_3696_ = lean_ctor_get(v_a_3694_, 1);
v_isSharedCheck_3776_ = !lean_is_exclusive(v_a_3694_);
if (v_isSharedCheck_3776_ == 0)
{
v___x_3698_ = v_a_3694_;
v_isShared_3699_ = v_isSharedCheck_3776_;
goto v_resetjp_3697_;
}
else
{
lean_inc(v_snd_3696_);
lean_inc(v_fst_3695_);
lean_dec(v_a_3694_);
v___x_3698_ = lean_box(0);
v_isShared_3699_ = v_isSharedCheck_3776_;
goto v_resetjp_3697_;
}
v_resetjp_3697_:
{
lean_object* v___x_3700_; 
v___x_3700_ = lp_proofEnvironment_dumpUparams(v_levelParams_3688_, v___y_3626_, v_snd_3696_);
if (lean_obj_tag(v___x_3700_) == 0)
{
lean_object* v_a_3701_; lean_object* v_fst_3702_; lean_object* v_snd_3703_; lean_object* v___x_3705_; uint8_t v_isShared_3706_; uint8_t v_isSharedCheck_3767_; 
v_a_3701_ = lean_ctor_get(v___x_3700_, 0);
lean_inc(v_a_3701_);
lean_dec_ref_known(v___x_3700_, 1);
v_fst_3702_ = lean_ctor_get(v_a_3701_, 0);
v_snd_3703_ = lean_ctor_get(v_a_3701_, 1);
v_isSharedCheck_3767_ = !lean_is_exclusive(v_a_3701_);
if (v_isSharedCheck_3767_ == 0)
{
v___x_3705_ = v_a_3701_;
v_isShared_3706_ = v_isSharedCheck_3767_;
goto v_resetjp_3704_;
}
else
{
lean_inc(v_snd_3703_);
lean_inc(v_fst_3702_);
lean_dec(v_a_3701_);
v___x_3705_ = lean_box(0);
v_isShared_3706_ = v_isSharedCheck_3767_;
goto v_resetjp_3704_;
}
v_resetjp_3704_:
{
lean_object* v___x_3707_; 
v___x_3707_ = lp_proofEnvironment_dumpExpr(v_type_3689_, v___y_3626_, v_snd_3703_);
if (lean_obj_tag(v___x_3707_) == 0)
{
lean_object* v_a_3708_; lean_object* v_fst_3709_; lean_object* v_snd_3710_; lean_object* v___x_3712_; uint8_t v_isShared_3713_; uint8_t v_isSharedCheck_3758_; 
v_a_3708_ = lean_ctor_get(v___x_3707_, 0);
lean_inc(v_a_3708_);
lean_dec_ref_known(v___x_3707_, 1);
v_fst_3709_ = lean_ctor_get(v_a_3708_, 0);
v_snd_3710_ = lean_ctor_get(v_a_3708_, 1);
v_isSharedCheck_3758_ = !lean_is_exclusive(v_a_3708_);
if (v_isSharedCheck_3758_ == 0)
{
v___x_3712_ = v_a_3708_;
v_isShared_3713_ = v_isSharedCheck_3758_;
goto v_resetjp_3711_;
}
else
{
lean_inc(v_snd_3710_);
lean_inc(v_fst_3709_);
lean_dec(v_a_3708_);
v___x_3712_ = lean_box(0);
v_isShared_3713_ = v_isSharedCheck_3758_;
goto v_resetjp_3711_;
}
v_resetjp_3711_:
{
lean_object* v___x_3714_; lean_object* v___x_3715_; lean_object* v___x_3716_; lean_object* v___x_3718_; 
v___x_3714_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__5));
v___x_3715_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_3716_ = l_Lean_JsonNumber_fromNat(v_fst_3695_);
if (v_isShared_3672_ == 0)
{
lean_ctor_set_tag(v___x_3671_, 2);
lean_ctor_set(v___x_3671_, 0, v___x_3716_);
v___x_3718_ = v___x_3671_;
goto v_reusejp_3717_;
}
else
{
lean_object* v_reuseFailAlloc_3757_; 
v_reuseFailAlloc_3757_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3757_, 0, v___x_3716_);
v___x_3718_ = v_reuseFailAlloc_3757_;
goto v_reusejp_3717_;
}
v_reusejp_3717_:
{
lean_object* v___x_3720_; 
if (v_isShared_3713_ == 0)
{
lean_ctor_set(v___x_3712_, 1, v___x_3718_);
lean_ctor_set(v___x_3712_, 0, v___x_3715_);
v___x_3720_ = v___x_3712_;
goto v_reusejp_3719_;
}
else
{
lean_object* v_reuseFailAlloc_3756_; 
v_reuseFailAlloc_3756_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3756_, 0, v___x_3715_);
lean_ctor_set(v_reuseFailAlloc_3756_, 1, v___x_3718_);
v___x_3720_ = v_reuseFailAlloc_3756_;
goto v_reusejp_3719_;
}
v_reusejp_3719_:
{
lean_object* v___x_3721_; lean_object* v___x_3723_; 
v___x_3721_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_3706_ == 0)
{
lean_ctor_set(v___x_3705_, 1, v_fst_3702_);
lean_ctor_set(v___x_3705_, 0, v___x_3721_);
v___x_3723_ = v___x_3705_;
goto v_reusejp_3722_;
}
else
{
lean_object* v_reuseFailAlloc_3755_; 
v_reuseFailAlloc_3755_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3755_, 0, v___x_3721_);
lean_ctor_set(v_reuseFailAlloc_3755_, 1, v_fst_3702_);
v___x_3723_ = v_reuseFailAlloc_3755_;
goto v_reusejp_3722_;
}
v_reusejp_3722_:
{
lean_object* v___x_3724_; lean_object* v___x_3725_; lean_object* v___x_3727_; 
v___x_3724_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_3725_ = l_Lean_JsonNumber_fromNat(v_fst_3709_);
if (v_isShared_3668_ == 0)
{
lean_ctor_set_tag(v___x_3667_, 2);
lean_ctor_set(v___x_3667_, 0, v___x_3725_);
v___x_3727_ = v___x_3667_;
goto v_reusejp_3726_;
}
else
{
lean_object* v_reuseFailAlloc_3754_; 
v_reuseFailAlloc_3754_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3754_, 0, v___x_3725_);
v___x_3727_ = v_reuseFailAlloc_3754_;
goto v_reusejp_3726_;
}
v_reusejp_3726_:
{
lean_object* v___x_3729_; 
if (v_isShared_3699_ == 0)
{
lean_ctor_set(v___x_3698_, 1, v___x_3727_);
lean_ctor_set(v___x_3698_, 0, v___x_3724_);
v___x_3729_ = v___x_3698_;
goto v_reusejp_3728_;
}
else
{
lean_object* v_reuseFailAlloc_3753_; 
v_reuseFailAlloc_3753_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3753_, 0, v___x_3724_);
lean_ctor_set(v_reuseFailAlloc_3753_, 1, v___x_3727_);
v___x_3729_ = v_reuseFailAlloc_3753_;
goto v_reusejp_3728_;
}
v_reusejp_3728_:
{
lean_object* v___x_3730_; lean_object* v___x_3731_; lean_object* v___x_3732_; lean_object* v___x_3733_; lean_object* v___x_3734_; lean_object* v___x_3735_; lean_object* v___x_3736_; lean_object* v___x_3737_; lean_object* v___x_3738_; lean_object* v___x_3739_; lean_object* v___x_3740_; lean_object* v___x_3741_; 
v___x_3730_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__6));
v___x_3731_ = lp_proofEnvironment_Lean_QuotKind_toJson(v_kind_3686_);
v___x_3732_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3732_, 0, v___x_3730_);
lean_ctor_set(v___x_3732_, 1, v___x_3731_);
v___x_3733_ = lean_box(0);
v___x_3734_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3734_, 0, v___x_3732_);
lean_ctor_set(v___x_3734_, 1, v___x_3733_);
v___x_3735_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3735_, 0, v___x_3729_);
lean_ctor_set(v___x_3735_, 1, v___x_3734_);
v___x_3736_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3736_, 0, v___x_3723_);
lean_ctor_set(v___x_3736_, 1, v___x_3735_);
v___x_3737_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3737_, 0, v___x_3720_);
lean_ctor_set(v___x_3737_, 1, v___x_3736_);
v___x_3738_ = l_Lean_Json_mkObj(v___x_3737_);
lean_dec_ref_known(v___x_3737_, 2);
v___x_3739_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3739_, 0, v___x_3714_);
lean_ctor_set(v___x_3739_, 1, v___x_3738_);
v___x_3740_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_3740_, 0, v___x_3739_);
lean_ctor_set(v___x_3740_, 1, v___x_3733_);
v___x_3741_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v___x_3740_, v_snd_3710_);
lean_dec_ref_known(v___x_3740_, 2);
if (lean_obj_tag(v___x_3741_) == 0)
{
lean_object* v_a_3742_; lean_object* v_snd_3743_; 
v_a_3742_ = lean_ctor_get(v___x_3741_, 0);
lean_inc(v_a_3742_);
lean_dec_ref_known(v___x_3741_, 1);
v_snd_3743_ = lean_ctor_get(v_a_3742_, 1);
lean_inc(v_snd_3743_);
lean_dec(v_a_3742_);
v_as_x27_3624_ = v_tail_3632_;
v_b_3625_ = v___x_3633_;
v___y_3627_ = v_snd_3743_;
goto _start;
}
else
{
lean_object* v_a_3745_; lean_object* v___x_3747_; uint8_t v_isShared_3748_; uint8_t v_isSharedCheck_3752_; 
v_a_3745_ = lean_ctor_get(v___x_3741_, 0);
v_isSharedCheck_3752_ = !lean_is_exclusive(v___x_3741_);
if (v_isSharedCheck_3752_ == 0)
{
v___x_3747_ = v___x_3741_;
v_isShared_3748_ = v_isSharedCheck_3752_;
goto v_resetjp_3746_;
}
else
{
lean_inc(v_a_3745_);
lean_dec(v___x_3741_);
v___x_3747_ = lean_box(0);
v_isShared_3748_ = v_isSharedCheck_3752_;
goto v_resetjp_3746_;
}
v_resetjp_3746_:
{
lean_object* v___x_3750_; 
if (v_isShared_3748_ == 0)
{
v___x_3750_ = v___x_3747_;
goto v_reusejp_3749_;
}
else
{
lean_object* v_reuseFailAlloc_3751_; 
v_reuseFailAlloc_3751_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3751_, 0, v_a_3745_);
v___x_3750_ = v_reuseFailAlloc_3751_;
goto v_reusejp_3749_;
}
v_reusejp_3749_:
{
return v___x_3750_;
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_3759_; lean_object* v___x_3761_; uint8_t v_isShared_3762_; uint8_t v_isSharedCheck_3766_; 
lean_del_object(v___x_3705_);
lean_dec(v_fst_3702_);
lean_del_object(v___x_3698_);
lean_dec(v_fst_3695_);
lean_del_object(v___x_3671_);
lean_del_object(v___x_3667_);
v_a_3759_ = lean_ctor_get(v___x_3707_, 0);
v_isSharedCheck_3766_ = !lean_is_exclusive(v___x_3707_);
if (v_isSharedCheck_3766_ == 0)
{
v___x_3761_ = v___x_3707_;
v_isShared_3762_ = v_isSharedCheck_3766_;
goto v_resetjp_3760_;
}
else
{
lean_inc(v_a_3759_);
lean_dec(v___x_3707_);
v___x_3761_ = lean_box(0);
v_isShared_3762_ = v_isSharedCheck_3766_;
goto v_resetjp_3760_;
}
v_resetjp_3760_:
{
lean_object* v___x_3764_; 
if (v_isShared_3762_ == 0)
{
v___x_3764_ = v___x_3761_;
goto v_reusejp_3763_;
}
else
{
lean_object* v_reuseFailAlloc_3765_; 
v_reuseFailAlloc_3765_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3765_, 0, v_a_3759_);
v___x_3764_ = v_reuseFailAlloc_3765_;
goto v_reusejp_3763_;
}
v_reusejp_3763_:
{
return v___x_3764_;
}
}
}
}
}
else
{
lean_object* v_a_3768_; lean_object* v___x_3770_; uint8_t v_isShared_3771_; uint8_t v_isSharedCheck_3775_; 
lean_del_object(v___x_3698_);
lean_dec(v_fst_3695_);
lean_dec_ref(v_type_3689_);
lean_del_object(v___x_3671_);
lean_del_object(v___x_3667_);
v_a_3768_ = lean_ctor_get(v___x_3700_, 0);
v_isSharedCheck_3775_ = !lean_is_exclusive(v___x_3700_);
if (v_isSharedCheck_3775_ == 0)
{
v___x_3770_ = v___x_3700_;
v_isShared_3771_ = v_isSharedCheck_3775_;
goto v_resetjp_3769_;
}
else
{
lean_inc(v_a_3768_);
lean_dec(v___x_3700_);
v___x_3770_ = lean_box(0);
v_isShared_3771_ = v_isSharedCheck_3775_;
goto v_resetjp_3769_;
}
v_resetjp_3769_:
{
lean_object* v___x_3773_; 
if (v_isShared_3771_ == 0)
{
v___x_3773_ = v___x_3770_;
goto v_reusejp_3772_;
}
else
{
lean_object* v_reuseFailAlloc_3774_; 
v_reuseFailAlloc_3774_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3774_, 0, v_a_3768_);
v___x_3773_ = v_reuseFailAlloc_3774_;
goto v_reusejp_3772_;
}
v_reusejp_3772_:
{
return v___x_3773_;
}
}
}
}
}
else
{
lean_object* v_a_3777_; lean_object* v___x_3779_; uint8_t v_isShared_3780_; uint8_t v_isSharedCheck_3784_; 
lean_dec_ref(v_type_3689_);
lean_dec(v_levelParams_3688_);
lean_del_object(v___x_3671_);
lean_del_object(v___x_3667_);
v_a_3777_ = lean_ctor_get(v___x_3693_, 0);
v_isSharedCheck_3784_ = !lean_is_exclusive(v___x_3693_);
if (v_isSharedCheck_3784_ == 0)
{
v___x_3779_ = v___x_3693_;
v_isShared_3780_ = v_isSharedCheck_3784_;
goto v_resetjp_3778_;
}
else
{
lean_inc(v_a_3777_);
lean_dec(v___x_3693_);
v___x_3779_ = lean_box(0);
v_isShared_3780_ = v_isSharedCheck_3784_;
goto v_resetjp_3778_;
}
v_resetjp_3778_:
{
lean_object* v___x_3782_; 
if (v_isShared_3780_ == 0)
{
v___x_3782_ = v___x_3779_;
goto v_reusejp_3781_;
}
else
{
lean_object* v_reuseFailAlloc_3783_; 
v_reuseFailAlloc_3783_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3783_, 0, v_a_3777_);
v___x_3782_ = v_reuseFailAlloc_3783_;
goto v_reusejp_3781_;
}
v_reusejp_3781_:
{
return v___x_3782_;
}
}
}
}
}
}
}
else
{
lean_del_object(v___x_3667_);
lean_dec(v_val_3665_);
v___y_3635_ = v___y_3626_;
v___y_3636_ = v___y_3627_;
goto v___jp_3634_;
}
}
}
else
{
lean_dec(v___x_3664_);
v___y_3635_ = v___y_3626_;
v___y_3636_ = v___y_3627_;
goto v___jp_3634_;
}
v___jp_3634_:
{
uint8_t v_ignoreMissing_3637_; 
v_ignoreMissing_3637_ = lean_ctor_get_uint8(v___y_3636_, sizeof(void*)*6 + 2);
if (v_ignoreMissing_3637_ == 0)
{
lean_object* v___x_3638_; lean_object* v___x_3639_; lean_object* v___x_3640_; lean_object* v___x_3641_; lean_object* v___x_3642_; uint8_t v___x_3643_; lean_object* v___x_3644_; lean_object* v___x_3645_; lean_object* v___x_3646_; lean_object* v___x_3647_; lean_object* v___x_3648_; lean_object* v___x_3649_; 
v___x_3638_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_3639_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_3640_ = lean_unsigned_to_nat(296u);
v___x_3641_ = lean_unsigned_to_nat(52u);
v___x_3642_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__1));
v___x_3643_ = 1;
lean_inc(v_head_3631_);
v___x_3644_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_3631_, v___x_3643_);
v___x_3645_ = lean_string_append(v___x_3642_, v___x_3644_);
lean_dec_ref(v___x_3644_);
v___x_3646_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__2));
v___x_3647_ = lean_string_append(v___x_3645_, v___x_3646_);
v___x_3648_ = l_mkPanicMessageWithDecl(v___x_3638_, v___x_3639_, v___x_3640_, v___x_3641_, v___x_3647_);
lean_dec_ref(v___x_3647_);
v___x_3649_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__4(v___x_3648_, v___y_3635_, v___y_3636_);
if (lean_obj_tag(v___x_3649_) == 0)
{
lean_object* v_a_3650_; lean_object* v_snd_3651_; 
v_a_3650_ = lean_ctor_get(v___x_3649_, 0);
lean_inc(v_a_3650_);
lean_dec_ref_known(v___x_3649_, 1);
v_snd_3651_ = lean_ctor_get(v_a_3650_, 1);
lean_inc(v_snd_3651_);
lean_dec(v_a_3650_);
v_as_x27_3624_ = v_tail_3632_;
v_b_3625_ = v___x_3633_;
v___y_3627_ = v_snd_3651_;
goto _start;
}
else
{
lean_object* v_a_3653_; lean_object* v___x_3655_; uint8_t v_isShared_3656_; uint8_t v_isSharedCheck_3660_; 
v_a_3653_ = lean_ctor_get(v___x_3649_, 0);
v_isSharedCheck_3660_ = !lean_is_exclusive(v___x_3649_);
if (v_isSharedCheck_3660_ == 0)
{
v___x_3655_ = v___x_3649_;
v_isShared_3656_ = v_isSharedCheck_3660_;
goto v_resetjp_3654_;
}
else
{
lean_inc(v_a_3653_);
lean_dec(v___x_3649_);
v___x_3655_ = lean_box(0);
v_isShared_3656_ = v_isSharedCheck_3660_;
goto v_resetjp_3654_;
}
v_resetjp_3654_:
{
lean_object* v___x_3658_; 
if (v_isShared_3656_ == 0)
{
v___x_3658_ = v___x_3655_;
goto v_reusejp_3657_;
}
else
{
lean_object* v_reuseFailAlloc_3659_; 
v_reuseFailAlloc_3659_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3659_, 0, v_a_3653_);
v___x_3658_ = v_reuseFailAlloc_3659_;
goto v_reusejp_3657_;
}
v_reusejp_3657_:
{
return v___x_3658_;
}
}
}
}
else
{
lean_object* v___x_3661_; lean_object* v___x_3662_; lean_object* v___x_3663_; 
v___x_3661_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__4));
v___x_3662_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3662_, 0, v___x_3661_);
lean_ctor_set(v___x_3662_, 1, v___y_3636_);
v___x_3663_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3663_, 0, v___x_3662_);
return v___x_3663_;
}
}
}
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__2(void){
_start:
{
lean_object* v___x_3799_; lean_object* v___x_3800_; lean_object* v___x_3801_; lean_object* v___x_3802_; lean_object* v___x_3803_; lean_object* v___x_3804_; 
v___x_3799_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__1));
v___x_3800_ = lean_unsigned_to_nat(11u);
v___x_3801_ = lean_unsigned_to_nat(324u);
v___x_3802_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_3803_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_3804_ = l_mkPanicMessageWithDecl(v___x_3803_, v___x_3802_, v___x_3801_, v___x_3800_, v___x_3799_);
return v___x_3804_;
}
}
static lean_object* _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__4(void){
_start:
{
lean_object* v___x_3806_; lean_object* v___x_3807_; lean_object* v___x_3808_; lean_object* v___x_3809_; lean_object* v___x_3810_; lean_object* v___x_3811_; 
v___x_3806_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__3));
v___x_3807_ = lean_unsigned_to_nat(6u);
v___x_3808_ = lean_unsigned_to_nat(312u);
v___x_3809_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_3810_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_3811_ = l_mkPanicMessageWithDecl(v___x_3810_, v___x_3809_, v___x_3808_, v___x_3807_, v___x_3806_);
return v___x_3811_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg(uint8_t v___x_3812_, lean_object* v_val_3813_, lean_object* v_as_x27_3814_, lean_object* v_b_3815_, lean_object* v___y_3816_, lean_object* v___y_3817_){
_start:
{
if (lean_obj_tag(v_as_x27_3814_) == 0)
{
lean_object* v___x_3819_; lean_object* v___x_3820_; 
v___x_3819_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3819_, 0, v_b_3815_);
lean_ctor_set(v___x_3819_, 1, v___y_3817_);
v___x_3820_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3820_, 0, v___x_3819_);
return v___x_3820_;
}
else
{
lean_object* v_head_3821_; lean_object* v_tail_3822_; lean_object* v___y_3824_; lean_object* v_snd_3855_; lean_object* v_fst_3856_; lean_object* v_fst_3857_; lean_object* v_snd_3858_; lean_object* v___y_3860_; uint8_t v___y_3861_; lean_object* v___y_3942_; lean_object* v___x_3949_; 
v_head_3821_ = lean_ctor_get(v_as_x27_3814_, 0);
v_tail_3822_ = lean_ctor_get(v_as_x27_3814_, 1);
v_snd_3855_ = lean_ctor_get(v_b_3815_, 1);
lean_inc(v_snd_3855_);
v_fst_3856_ = lean_ctor_get(v_b_3815_, 0);
lean_inc(v_fst_3856_);
lean_dec_ref(v_b_3815_);
v_fst_3857_ = lean_ctor_get(v_snd_3855_, 0);
lean_inc(v_fst_3857_);
v_snd_3858_ = lean_ctor_get(v_snd_3855_, 1);
lean_inc(v_snd_3858_);
lean_dec(v_snd_3855_);
lean_inc(v_head_3821_);
lean_inc_ref(v___y_3816_);
v___x_3949_ = l_Lean_Environment_find_x3f(v___y_3816_, v_head_3821_, v___x_3812_);
if (lean_obj_tag(v___x_3949_) == 0)
{
lean_object* v___x_3950_; lean_object* v___x_3951_; 
v___x_3950_ = lean_obj_once(&lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8, &lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8_once, _init_lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__8);
v___x_3951_ = l_panic___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_emitMainFnIfNeeded_emitMainFn_spec__0(v___x_3950_);
v___y_3942_ = v___x_3951_;
goto v___jp_3941_;
}
else
{
lean_object* v_val_3952_; 
v_val_3952_ = lean_ctor_get(v___x_3949_, 0);
lean_inc(v_val_3952_);
lean_dec_ref_known(v___x_3949_, 1);
v___y_3942_ = v_val_3952_;
goto v___jp_3941_;
}
v___jp_3823_:
{
if (lean_obj_tag(v___y_3824_) == 0)
{
lean_object* v_a_3825_; lean_object* v___x_3827_; uint8_t v_isShared_3828_; uint8_t v_isSharedCheck_3846_; 
v_a_3825_ = lean_ctor_get(v___y_3824_, 0);
v_isSharedCheck_3846_ = !lean_is_exclusive(v___y_3824_);
if (v_isSharedCheck_3846_ == 0)
{
v___x_3827_ = v___y_3824_;
v_isShared_3828_ = v_isSharedCheck_3846_;
goto v_resetjp_3826_;
}
else
{
lean_inc(v_a_3825_);
lean_dec(v___y_3824_);
v___x_3827_ = lean_box(0);
v_isShared_3828_ = v_isSharedCheck_3846_;
goto v_resetjp_3826_;
}
v_resetjp_3826_:
{
lean_object* v_fst_3829_; 
v_fst_3829_ = lean_ctor_get(v_a_3825_, 0);
lean_inc(v_fst_3829_);
if (lean_obj_tag(v_fst_3829_) == 0)
{
lean_object* v_snd_3830_; lean_object* v___x_3832_; uint8_t v_isShared_3833_; uint8_t v_isSharedCheck_3841_; 
v_snd_3830_ = lean_ctor_get(v_a_3825_, 1);
v_isSharedCheck_3841_ = !lean_is_exclusive(v_a_3825_);
if (v_isSharedCheck_3841_ == 0)
{
lean_object* v_unused_3842_; 
v_unused_3842_ = lean_ctor_get(v_a_3825_, 0);
lean_dec(v_unused_3842_);
v___x_3832_ = v_a_3825_;
v_isShared_3833_ = v_isSharedCheck_3841_;
goto v_resetjp_3831_;
}
else
{
lean_inc(v_snd_3830_);
lean_dec(v_a_3825_);
v___x_3832_ = lean_box(0);
v_isShared_3833_ = v_isSharedCheck_3841_;
goto v_resetjp_3831_;
}
v_resetjp_3831_:
{
lean_object* v_a_3834_; lean_object* v___x_3836_; 
v_a_3834_ = lean_ctor_get(v_fst_3829_, 0);
lean_inc(v_a_3834_);
lean_dec_ref_known(v_fst_3829_, 1);
if (v_isShared_3833_ == 0)
{
lean_ctor_set(v___x_3832_, 0, v_a_3834_);
v___x_3836_ = v___x_3832_;
goto v_reusejp_3835_;
}
else
{
lean_object* v_reuseFailAlloc_3840_; 
v_reuseFailAlloc_3840_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3840_, 0, v_a_3834_);
lean_ctor_set(v_reuseFailAlloc_3840_, 1, v_snd_3830_);
v___x_3836_ = v_reuseFailAlloc_3840_;
goto v_reusejp_3835_;
}
v_reusejp_3835_:
{
lean_object* v___x_3838_; 
if (v_isShared_3828_ == 0)
{
lean_ctor_set(v___x_3827_, 0, v___x_3836_);
v___x_3838_ = v___x_3827_;
goto v_reusejp_3837_;
}
else
{
lean_object* v_reuseFailAlloc_3839_; 
v_reuseFailAlloc_3839_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3839_, 0, v___x_3836_);
v___x_3838_ = v_reuseFailAlloc_3839_;
goto v_reusejp_3837_;
}
v_reusejp_3837_:
{
return v___x_3838_;
}
}
}
}
else
{
lean_object* v_snd_3843_; lean_object* v_a_3844_; 
lean_del_object(v___x_3827_);
v_snd_3843_ = lean_ctor_get(v_a_3825_, 1);
lean_inc(v_snd_3843_);
lean_dec(v_a_3825_);
v_a_3844_ = lean_ctor_get(v_fst_3829_, 0);
lean_inc(v_a_3844_);
lean_dec_ref_known(v_fst_3829_, 1);
v_as_x27_3814_ = v_tail_3822_;
v_b_3815_ = v_a_3844_;
v___y_3817_ = v_snd_3843_;
goto _start;
}
}
}
else
{
lean_object* v_a_3847_; lean_object* v___x_3849_; uint8_t v_isShared_3850_; uint8_t v_isSharedCheck_3854_; 
v_a_3847_ = lean_ctor_get(v___y_3824_, 0);
v_isSharedCheck_3854_ = !lean_is_exclusive(v___y_3824_);
if (v_isSharedCheck_3854_ == 0)
{
v___x_3849_ = v___y_3824_;
v_isShared_3850_ = v_isSharedCheck_3854_;
goto v_resetjp_3848_;
}
else
{
lean_inc(v_a_3847_);
lean_dec(v___y_3824_);
v___x_3849_ = lean_box(0);
v_isShared_3850_ = v_isSharedCheck_3854_;
goto v_resetjp_3848_;
}
v_resetjp_3848_:
{
lean_object* v___x_3852_; 
if (v_isShared_3850_ == 0)
{
v___x_3852_ = v___x_3849_;
goto v_reusejp_3851_;
}
else
{
lean_object* v_reuseFailAlloc_3853_; 
v_reuseFailAlloc_3853_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3853_, 0, v_a_3847_);
v___x_3852_ = v_reuseFailAlloc_3853_;
goto v_reusejp_3851_;
}
v_reusejp_3851_:
{
return v___x_3852_;
}
}
}
}
v___jp_3859_:
{
lean_object* v_toConstantVal_3862_; lean_object* v_ctors_3863_; lean_object* v___x_3864_; 
v_toConstantVal_3862_ = lean_ctor_get(v___y_3860_, 0);
v_ctors_3863_ = lean_ctor_get(v___y_3860_, 4);
v___x_3864_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg(v___y_3861_, v___x_3812_, v_ctors_3863_, v_fst_3857_, v___y_3816_, v___y_3817_);
if (lean_obj_tag(v___x_3864_) == 0)
{
lean_object* v_a_3865_; lean_object* v_snd_3866_; lean_object* v_fst_3867_; lean_object* v___x_3869_; uint8_t v_isShared_3870_; uint8_t v_isSharedCheck_3932_; 
v_a_3865_ = lean_ctor_get(v___x_3864_, 0);
lean_inc(v_a_3865_);
lean_dec_ref_known(v___x_3864_, 1);
v_snd_3866_ = lean_ctor_get(v_a_3865_, 1);
v_fst_3867_ = lean_ctor_get(v_a_3865_, 0);
v_isSharedCheck_3932_ = !lean_is_exclusive(v_a_3865_);
if (v_isSharedCheck_3932_ == 0)
{
v___x_3869_ = v_a_3865_;
v_isShared_3870_ = v_isSharedCheck_3932_;
goto v_resetjp_3868_;
}
else
{
lean_inc(v_snd_3866_);
lean_inc(v_fst_3867_);
lean_dec(v_a_3865_);
v___x_3869_ = lean_box(0);
v_isShared_3870_ = v_isSharedCheck_3932_;
goto v_resetjp_3868_;
}
v_resetjp_3868_:
{
lean_object* v_visitedNames_3871_; lean_object* v_visitedLevels_3872_; lean_object* v_visitedExprs_3873_; lean_object* v_visitedConstants_3874_; lean_object* v_noMDataExprs_3875_; uint8_t v_exportMData_3876_; uint8_t v_exportUnsafe_3877_; uint8_t v_ignoreMissing_3878_; lean_object* v_recursorMap_3879_; lean_object* v___x_3881_; uint8_t v_isShared_3882_; uint8_t v_isSharedCheck_3931_; 
v_visitedNames_3871_ = lean_ctor_get(v_snd_3866_, 0);
v_visitedLevels_3872_ = lean_ctor_get(v_snd_3866_, 1);
v_visitedExprs_3873_ = lean_ctor_get(v_snd_3866_, 2);
v_visitedConstants_3874_ = lean_ctor_get(v_snd_3866_, 3);
v_noMDataExprs_3875_ = lean_ctor_get(v_snd_3866_, 4);
v_exportMData_3876_ = lean_ctor_get_uint8(v_snd_3866_, sizeof(void*)*6);
v_exportUnsafe_3877_ = lean_ctor_get_uint8(v_snd_3866_, sizeof(void*)*6 + 1);
v_ignoreMissing_3878_ = lean_ctor_get_uint8(v_snd_3866_, sizeof(void*)*6 + 2);
v_recursorMap_3879_ = lean_ctor_get(v_snd_3866_, 5);
v_isSharedCheck_3931_ = !lean_is_exclusive(v_snd_3866_);
if (v_isSharedCheck_3931_ == 0)
{
v___x_3881_ = v_snd_3866_;
v_isShared_3882_ = v_isSharedCheck_3931_;
goto v_resetjp_3880_;
}
else
{
lean_inc(v_recursorMap_3879_);
lean_inc(v_noMDataExprs_3875_);
lean_inc(v_visitedConstants_3874_);
lean_inc(v_visitedExprs_3873_);
lean_inc(v_visitedLevels_3872_);
lean_inc(v_visitedNames_3871_);
lean_dec(v_snd_3866_);
v___x_3881_ = lean_box(0);
v_isShared_3882_ = v_isSharedCheck_3931_;
goto v_resetjp_3880_;
}
v_resetjp_3880_:
{
lean_object* v_type_3883_; lean_object* v___x_3884_; lean_object* v___x_3886_; 
v_type_3883_ = lean_ctor_get(v_toConstantVal_3862_, 2);
lean_inc(v_head_3821_);
v___x_3884_ = l_Lean_NameHashSet_insert(v_visitedConstants_3874_, v_head_3821_);
if (v_isShared_3882_ == 0)
{
lean_ctor_set(v___x_3881_, 3, v___x_3884_);
v___x_3886_ = v___x_3881_;
goto v_reusejp_3885_;
}
else
{
lean_object* v_reuseFailAlloc_3930_; 
v_reuseFailAlloc_3930_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_3930_, 0, v_visitedNames_3871_);
lean_ctor_set(v_reuseFailAlloc_3930_, 1, v_visitedLevels_3872_);
lean_ctor_set(v_reuseFailAlloc_3930_, 2, v_visitedExprs_3873_);
lean_ctor_set(v_reuseFailAlloc_3930_, 3, v___x_3884_);
lean_ctor_set(v_reuseFailAlloc_3930_, 4, v_noMDataExprs_3875_);
lean_ctor_set(v_reuseFailAlloc_3930_, 5, v_recursorMap_3879_);
lean_ctor_set_uint8(v_reuseFailAlloc_3930_, sizeof(void*)*6, v_exportMData_3876_);
lean_ctor_set_uint8(v_reuseFailAlloc_3930_, sizeof(void*)*6 + 1, v_exportUnsafe_3877_);
lean_ctor_set_uint8(v_reuseFailAlloc_3930_, sizeof(void*)*6 + 2, v_ignoreMissing_3878_);
v___x_3886_ = v_reuseFailAlloc_3930_;
goto v_reusejp_3885_;
}
v_reusejp_3885_:
{
lean_object* v___x_3887_; 
lean_inc_ref(v_type_3883_);
v___x_3887_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_3883_, v___y_3816_, v___x_3886_);
if (lean_obj_tag(v___x_3887_) == 0)
{
lean_object* v_a_3888_; lean_object* v_snd_3889_; lean_object* v___x_3891_; uint8_t v_isShared_3892_; uint8_t v_isSharedCheck_3920_; 
v_a_3888_ = lean_ctor_get(v___x_3887_, 0);
lean_inc(v_a_3888_);
lean_dec_ref_known(v___x_3887_, 1);
v_snd_3889_ = lean_ctor_get(v_a_3888_, 1);
v_isSharedCheck_3920_ = !lean_is_exclusive(v_a_3888_);
if (v_isSharedCheck_3920_ == 0)
{
lean_object* v_unused_3921_; 
v_unused_3921_ = lean_ctor_get(v_a_3888_, 0);
lean_dec(v_unused_3921_);
v___x_3891_ = v_a_3888_;
v_isShared_3892_ = v_isSharedCheck_3920_;
goto v_resetjp_3890_;
}
else
{
lean_inc(v_snd_3889_);
lean_dec(v_a_3888_);
v___x_3891_ = lean_box(0);
v_isShared_3892_ = v_isSharedCheck_3920_;
goto v_resetjp_3890_;
}
v_resetjp_3890_:
{
lean_object* v_toConstantVal_3893_; lean_object* v_recursorMap_3894_; lean_object* v_name_3895_; lean_object* v___x_3896_; lean_object* v___x_3897_; 
v_toConstantVal_3893_ = lean_ctor_get(v_val_3813_, 0);
v_recursorMap_3894_ = lean_ctor_get(v_snd_3889_, 5);
v_name_3895_ = lean_ctor_get(v_toConstantVal_3893_, 0);
v___x_3896_ = lean_array_push(v_fst_3856_, v___y_3860_);
v___x_3897_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Doc_0__Lean_Elab_Tactic_Doc_showParserName___at___00Lean_Elab_Tactic_Doc_elabPrintTacTags_spec__6_spec__10___redArg(v_recursorMap_3894_, v_name_3895_);
if (lean_obj_tag(v___x_3897_) == 1)
{
lean_object* v_val_3898_; lean_object* v___x_3899_; lean_object* v___x_3900_; lean_object* v___x_3902_; 
v_val_3898_ = lean_ctor_get(v___x_3897_, 0);
lean_inc(v_val_3898_);
lean_dec_ref_known(v___x_3897_, 1);
v___x_3899_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__0));
v___x_3900_ = l_Std_DTreeMap_Internal_Impl_union___at___00Std_DTreeMap_union_spec__0___redArg(v___x_3899_, v_snd_3858_, v_val_3898_);
if (v_isShared_3892_ == 0)
{
lean_ctor_set(v___x_3891_, 1, v___x_3900_);
lean_ctor_set(v___x_3891_, 0, v_fst_3867_);
v___x_3902_ = v___x_3891_;
goto v_reusejp_3901_;
}
else
{
lean_object* v_reuseFailAlloc_3907_; 
v_reuseFailAlloc_3907_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3907_, 0, v_fst_3867_);
lean_ctor_set(v_reuseFailAlloc_3907_, 1, v___x_3900_);
v___x_3902_ = v_reuseFailAlloc_3907_;
goto v_reusejp_3901_;
}
v_reusejp_3901_:
{
lean_object* v___x_3904_; 
if (v_isShared_3870_ == 0)
{
lean_ctor_set(v___x_3869_, 1, v___x_3902_);
lean_ctor_set(v___x_3869_, 0, v___x_3896_);
v___x_3904_ = v___x_3869_;
goto v_reusejp_3903_;
}
else
{
lean_object* v_reuseFailAlloc_3906_; 
v_reuseFailAlloc_3906_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3906_, 0, v___x_3896_);
lean_ctor_set(v_reuseFailAlloc_3906_, 1, v___x_3902_);
v___x_3904_ = v_reuseFailAlloc_3906_;
goto v_reusejp_3903_;
}
v_reusejp_3903_:
{
v_as_x27_3814_ = v_tail_3822_;
v_b_3815_ = v___x_3904_;
v___y_3817_ = v_snd_3889_;
goto _start;
}
}
}
else
{
lean_object* v___x_3908_; lean_object* v___x_3909_; uint8_t v___x_3910_; 
lean_dec(v___x_3897_);
v___x_3908_ = lean_array_get_size(v_fst_3867_);
v___x_3909_ = lean_unsigned_to_nat(0u);
v___x_3910_ = lean_nat_dec_eq(v___x_3908_, v___x_3909_);
if (v___x_3910_ == 0)
{
lean_object* v___x_3911_; lean_object* v___x_3912_; 
lean_dec_ref(v___x_3896_);
lean_del_object(v___x_3891_);
lean_del_object(v___x_3869_);
lean_dec(v_fst_3867_);
lean_dec(v_snd_3858_);
v___x_3911_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__2, &lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__2_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__2);
v___x_3912_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__8(v___x_3911_, v___y_3816_, v_snd_3889_);
v___y_3824_ = v___x_3912_;
goto v___jp_3823_;
}
else
{
lean_object* v___x_3914_; 
if (v_isShared_3892_ == 0)
{
lean_ctor_set(v___x_3891_, 1, v_snd_3858_);
lean_ctor_set(v___x_3891_, 0, v_fst_3867_);
v___x_3914_ = v___x_3891_;
goto v_reusejp_3913_;
}
else
{
lean_object* v_reuseFailAlloc_3919_; 
v_reuseFailAlloc_3919_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3919_, 0, v_fst_3867_);
lean_ctor_set(v_reuseFailAlloc_3919_, 1, v_snd_3858_);
v___x_3914_ = v_reuseFailAlloc_3919_;
goto v_reusejp_3913_;
}
v_reusejp_3913_:
{
lean_object* v___x_3916_; 
if (v_isShared_3870_ == 0)
{
lean_ctor_set(v___x_3869_, 1, v___x_3914_);
lean_ctor_set(v___x_3869_, 0, v___x_3896_);
v___x_3916_ = v___x_3869_;
goto v_reusejp_3915_;
}
else
{
lean_object* v_reuseFailAlloc_3918_; 
v_reuseFailAlloc_3918_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3918_, 0, v___x_3896_);
lean_ctor_set(v_reuseFailAlloc_3918_, 1, v___x_3914_);
v___x_3916_ = v_reuseFailAlloc_3918_;
goto v_reusejp_3915_;
}
v_reusejp_3915_:
{
v_as_x27_3814_ = v_tail_3822_;
v_b_3815_ = v___x_3916_;
v___y_3817_ = v_snd_3889_;
goto _start;
}
}
}
}
}
}
else
{
lean_object* v_a_3922_; lean_object* v___x_3924_; uint8_t v_isShared_3925_; uint8_t v_isSharedCheck_3929_; 
lean_del_object(v___x_3869_);
lean_dec(v_fst_3867_);
lean_dec_ref(v___y_3860_);
lean_dec(v_snd_3858_);
lean_dec(v_fst_3856_);
v_a_3922_ = lean_ctor_get(v___x_3887_, 0);
v_isSharedCheck_3929_ = !lean_is_exclusive(v___x_3887_);
if (v_isSharedCheck_3929_ == 0)
{
v___x_3924_ = v___x_3887_;
v_isShared_3925_ = v_isSharedCheck_3929_;
goto v_resetjp_3923_;
}
else
{
lean_inc(v_a_3922_);
lean_dec(v___x_3887_);
v___x_3924_ = lean_box(0);
v_isShared_3925_ = v_isSharedCheck_3929_;
goto v_resetjp_3923_;
}
v_resetjp_3923_:
{
lean_object* v___x_3927_; 
if (v_isShared_3925_ == 0)
{
v___x_3927_ = v___x_3924_;
goto v_reusejp_3926_;
}
else
{
lean_object* v_reuseFailAlloc_3928_; 
v_reuseFailAlloc_3928_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3928_, 0, v_a_3922_);
v___x_3927_ = v_reuseFailAlloc_3928_;
goto v_reusejp_3926_;
}
v_reusejp_3926_:
{
return v___x_3927_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_3933_; lean_object* v___x_3935_; uint8_t v_isShared_3936_; uint8_t v_isSharedCheck_3940_; 
lean_dec_ref(v___y_3860_);
lean_dec(v_snd_3858_);
lean_dec(v_fst_3856_);
v_a_3933_ = lean_ctor_get(v___x_3864_, 0);
v_isSharedCheck_3940_ = !lean_is_exclusive(v___x_3864_);
if (v_isSharedCheck_3940_ == 0)
{
v___x_3935_ = v___x_3864_;
v_isShared_3936_ = v_isSharedCheck_3940_;
goto v_resetjp_3934_;
}
else
{
lean_inc(v_a_3933_);
lean_dec(v___x_3864_);
v___x_3935_ = lean_box(0);
v_isShared_3936_ = v_isSharedCheck_3940_;
goto v_resetjp_3934_;
}
v_resetjp_3934_:
{
lean_object* v___x_3938_; 
if (v_isShared_3936_ == 0)
{
v___x_3938_ = v___x_3935_;
goto v_reusejp_3937_;
}
else
{
lean_object* v_reuseFailAlloc_3939_; 
v_reuseFailAlloc_3939_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3939_, 0, v_a_3933_);
v___x_3938_ = v_reuseFailAlloc_3939_;
goto v_reusejp_3937_;
}
v_reusejp_3937_:
{
return v___x_3938_;
}
}
}
}
v___jp_3941_:
{
lean_object* v___x_3943_; uint8_t v_isUnsafe_3944_; 
v___x_3943_ = l_Lean_ConstantInfo_inductiveVal_x21(v___y_3942_);
lean_dec_ref(v___y_3942_);
v_isUnsafe_3944_ = lean_ctor_get_uint8(v___x_3943_, sizeof(void*)*6 + 1);
if (v_isUnsafe_3944_ == 0)
{
uint8_t v___x_3945_; 
v___x_3945_ = 1;
v___y_3860_ = v___x_3943_;
v___y_3861_ = v___x_3945_;
goto v___jp_3859_;
}
else
{
if (v___x_3812_ == 0)
{
uint8_t v_exportUnsafe_3946_; 
v_exportUnsafe_3946_ = lean_ctor_get_uint8(v___y_3817_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_3946_ == 0)
{
lean_object* v___x_3947_; lean_object* v___x_3948_; 
lean_dec_ref(v___x_3943_);
lean_dec(v_snd_3858_);
lean_dec(v_fst_3857_);
lean_dec(v_fst_3856_);
v___x_3947_ = lean_obj_once(&lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__4, &lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__4_once, _init_lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___closed__4);
v___x_3948_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__8(v___x_3947_, v___y_3816_, v___y_3817_);
v___y_3824_ = v___x_3948_;
goto v___jp_3823_;
}
else
{
v___y_3860_ = v___x_3943_;
v___y_3861_ = v_exportUnsafe_3946_;
goto v___jp_3859_;
}
}
else
{
v___y_3860_ = v___x_3943_;
v___y_3861_ = v___x_3812_;
goto v___jp_3859_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__11(lean_object* v_as_3953_, size_t v_sz_3954_, size_t v_i_3955_, lean_object* v_b_3956_, lean_object* v___y_3957_, lean_object* v___y_3958_){
_start:
{
uint8_t v___x_3960_; 
v___x_3960_ = lean_usize_dec_lt(v_i_3955_, v_sz_3954_);
if (v___x_3960_ == 0)
{
lean_object* v___x_3961_; lean_object* v___x_3962_; 
v___x_3961_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3961_, 0, v_b_3956_);
lean_ctor_set(v___x_3961_, 1, v___y_3958_);
v___x_3962_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3962_, 0, v___x_3961_);
return v___x_3962_;
}
else
{
lean_object* v_visitedNames_3963_; lean_object* v_visitedLevels_3964_; lean_object* v_visitedExprs_3965_; lean_object* v_visitedConstants_3966_; lean_object* v_noMDataExprs_3967_; uint8_t v_exportMData_3968_; uint8_t v_exportUnsafe_3969_; uint8_t v_ignoreMissing_3970_; lean_object* v_recursorMap_3971_; lean_object* v___x_3973_; uint8_t v_isShared_3974_; uint8_t v_isSharedCheck_3990_; 
v_visitedNames_3963_ = lean_ctor_get(v___y_3958_, 0);
v_visitedLevels_3964_ = lean_ctor_get(v___y_3958_, 1);
v_visitedExprs_3965_ = lean_ctor_get(v___y_3958_, 2);
v_visitedConstants_3966_ = lean_ctor_get(v___y_3958_, 3);
v_noMDataExprs_3967_ = lean_ctor_get(v___y_3958_, 4);
v_exportMData_3968_ = lean_ctor_get_uint8(v___y_3958_, sizeof(void*)*6);
v_exportUnsafe_3969_ = lean_ctor_get_uint8(v___y_3958_, sizeof(void*)*6 + 1);
v_ignoreMissing_3970_ = lean_ctor_get_uint8(v___y_3958_, sizeof(void*)*6 + 2);
v_recursorMap_3971_ = lean_ctor_get(v___y_3958_, 5);
v_isSharedCheck_3990_ = !lean_is_exclusive(v___y_3958_);
if (v_isSharedCheck_3990_ == 0)
{
v___x_3973_ = v___y_3958_;
v_isShared_3974_ = v_isSharedCheck_3990_;
goto v_resetjp_3972_;
}
else
{
lean_inc(v_recursorMap_3971_);
lean_inc(v_noMDataExprs_3967_);
lean_inc(v_visitedConstants_3966_);
lean_inc(v_visitedExprs_3965_);
lean_inc(v_visitedLevels_3964_);
lean_inc(v_visitedNames_3963_);
lean_dec(v___y_3958_);
v___x_3973_ = lean_box(0);
v_isShared_3974_ = v_isSharedCheck_3990_;
goto v_resetjp_3972_;
}
v_resetjp_3972_:
{
lean_object* v_a_3975_; lean_object* v_toConstantVal_3976_; lean_object* v_name_3977_; lean_object* v_type_3978_; lean_object* v___x_3979_; lean_object* v___x_3981_; 
v_a_3975_ = lean_array_uget_borrowed(v_as_3953_, v_i_3955_);
v_toConstantVal_3976_ = lean_ctor_get(v_a_3975_, 0);
v_name_3977_ = lean_ctor_get(v_toConstantVal_3976_, 0);
v_type_3978_ = lean_ctor_get(v_toConstantVal_3976_, 2);
lean_inc(v_name_3977_);
v___x_3979_ = l_Lean_NameHashSet_insert(v_visitedConstants_3966_, v_name_3977_);
if (v_isShared_3974_ == 0)
{
lean_ctor_set(v___x_3973_, 3, v___x_3979_);
v___x_3981_ = v___x_3973_;
goto v_reusejp_3980_;
}
else
{
lean_object* v_reuseFailAlloc_3989_; 
v_reuseFailAlloc_3989_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_3989_, 0, v_visitedNames_3963_);
lean_ctor_set(v_reuseFailAlloc_3989_, 1, v_visitedLevels_3964_);
lean_ctor_set(v_reuseFailAlloc_3989_, 2, v_visitedExprs_3965_);
lean_ctor_set(v_reuseFailAlloc_3989_, 3, v___x_3979_);
lean_ctor_set(v_reuseFailAlloc_3989_, 4, v_noMDataExprs_3967_);
lean_ctor_set(v_reuseFailAlloc_3989_, 5, v_recursorMap_3971_);
lean_ctor_set_uint8(v_reuseFailAlloc_3989_, sizeof(void*)*6, v_exportMData_3968_);
lean_ctor_set_uint8(v_reuseFailAlloc_3989_, sizeof(void*)*6 + 1, v_exportUnsafe_3969_);
lean_ctor_set_uint8(v_reuseFailAlloc_3989_, sizeof(void*)*6 + 2, v_ignoreMissing_3970_);
v___x_3981_ = v_reuseFailAlloc_3989_;
goto v_reusejp_3980_;
}
v_reusejp_3980_:
{
lean_object* v___x_3982_; 
lean_inc_ref(v_type_3978_);
v___x_3982_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_3978_, v___y_3957_, v___x_3981_);
if (lean_obj_tag(v___x_3982_) == 0)
{
lean_object* v_a_3983_; lean_object* v_snd_3984_; lean_object* v___x_3985_; size_t v___x_3986_; size_t v___x_3987_; 
v_a_3983_ = lean_ctor_get(v___x_3982_, 0);
lean_inc(v_a_3983_);
lean_dec_ref_known(v___x_3982_, 1);
v_snd_3984_ = lean_ctor_get(v_a_3983_, 1);
lean_inc(v_snd_3984_);
lean_dec(v_a_3983_);
v___x_3985_ = lean_box(0);
v___x_3986_ = ((size_t)1ULL);
v___x_3987_ = lean_usize_add(v_i_3955_, v___x_3986_);
v_i_3955_ = v___x_3987_;
v_b_3956_ = v___x_3985_;
v___y_3958_ = v_snd_3984_;
goto _start;
}
else
{
return v___x_3982_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg(lean_object* v_as_x27_3991_, lean_object* v_b_3992_, lean_object* v___y_3993_, lean_object* v___y_3994_){
_start:
{
if (lean_obj_tag(v_as_x27_3991_) == 0)
{
lean_object* v___x_3996_; lean_object* v___x_3997_; 
v___x_3996_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3996_, 0, v_b_3992_);
lean_ctor_set(v___x_3996_, 1, v___y_3994_);
v___x_3997_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3997_, 0, v___x_3996_);
return v___x_3997_;
}
else
{
lean_object* v_head_3998_; lean_object* v_tail_3999_; lean_object* v___x_4000_; 
v_head_3998_ = lean_ctor_get(v_as_x27_3991_, 0);
v_tail_3999_ = lean_ctor_get(v_as_x27_3991_, 1);
lean_inc(v_head_3998_);
v___x_4000_ = lp_proofEnvironment_dumpConstant(v_head_3998_, v___y_3993_, v___y_3994_);
if (lean_obj_tag(v___x_4000_) == 0)
{
lean_object* v_a_4001_; lean_object* v_snd_4002_; lean_object* v___x_4003_; 
v_a_4001_ = lean_ctor_get(v___x_4000_, 0);
lean_inc(v_a_4001_);
lean_dec_ref_known(v___x_4000_, 1);
v_snd_4002_ = lean_ctor_get(v_a_4001_, 1);
lean_inc(v_snd_4002_);
lean_dec(v_a_4001_);
v___x_4003_ = lean_box(0);
v_as_x27_3991_ = v_tail_3999_;
v_b_3992_ = v___x_4003_;
v___y_3994_ = v_snd_4002_;
goto _start;
}
else
{
return v___x_4000_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant(lean_object* v_c_4005_, lean_object* v_a_4006_, lean_object* v_a_4007_){
_start:
{
lean_object* v___y_4014_; size_t v___y_4015_; lean_object* v___y_4016_; lean_object* v___y_4017_; size_t v___y_4018_; lean_object* v_fst_4019_; lean_object* v_snd_4020_; uint8_t v___x_4115_; lean_object* v___x_4116_; 
v___x_4115_ = 0;
lean_inc(v_c_4005_);
lean_inc_ref(v_a_4006_);
v___x_4116_ = l_Lean_Environment_find_x3f(v_a_4006_, v_c_4005_, v___x_4115_);
if (lean_obj_tag(v___x_4116_) == 1)
{
lean_object* v_val_4117_; uint8_t v___y_4856_; uint8_t v___x_4857_; 
v_val_4117_ = lean_ctor_get(v___x_4116_, 0);
lean_inc(v_val_4117_);
lean_dec_ref_known(v___x_4116_, 1);
v___x_4857_ = l_Lean_ConstantInfo_isUnsafe(v_val_4117_);
if (v___x_4857_ == 0)
{
v___y_4856_ = v___x_4857_;
goto v___jp_4855_;
}
else
{
uint8_t v_exportUnsafe_4858_; 
v_exportUnsafe_4858_ = lean_ctor_get_uint8(v_a_4007_, sizeof(void*)*6 + 1);
if (v_exportUnsafe_4858_ == 0)
{
v___y_4856_ = v___x_4857_;
goto v___jp_4855_;
}
else
{
goto v___jp_4118_;
}
}
v___jp_4118_:
{
lean_object* v_visitedNames_4119_; lean_object* v_visitedLevels_4120_; lean_object* v_visitedExprs_4121_; lean_object* v_visitedConstants_4122_; lean_object* v_noMDataExprs_4123_; uint8_t v_exportMData_4124_; uint8_t v_exportUnsafe_4125_; uint8_t v_ignoreMissing_4126_; lean_object* v_recursorMap_4127_; uint8_t v___x_4128_; 
v_visitedNames_4119_ = lean_ctor_get(v_a_4007_, 0);
v_visitedLevels_4120_ = lean_ctor_get(v_a_4007_, 1);
v_visitedExprs_4121_ = lean_ctor_get(v_a_4007_, 2);
v_visitedConstants_4122_ = lean_ctor_get(v_a_4007_, 3);
v_noMDataExprs_4123_ = lean_ctor_get(v_a_4007_, 4);
v_exportMData_4124_ = lean_ctor_get_uint8(v_a_4007_, sizeof(void*)*6);
v_exportUnsafe_4125_ = lean_ctor_get_uint8(v_a_4007_, sizeof(void*)*6 + 1);
v_ignoreMissing_4126_ = lean_ctor_get_uint8(v_a_4007_, sizeof(void*)*6 + 2);
v_recursorMap_4127_ = lean_ctor_get(v_a_4007_, 5);
v___x_4128_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_visitedConstants_4122_, v_c_4005_);
if (v___x_4128_ == 0)
{
lean_object* v___x_4130_; uint8_t v_isShared_4131_; uint8_t v_isSharedCheck_4848_; 
lean_inc(v_recursorMap_4127_);
lean_inc_ref(v_noMDataExprs_4123_);
lean_inc_ref(v_visitedConstants_4122_);
lean_inc_ref(v_visitedExprs_4121_);
lean_inc_ref(v_visitedLevels_4120_);
lean_inc_ref(v_visitedNames_4119_);
v_isSharedCheck_4848_ = !lean_is_exclusive(v_a_4007_);
if (v_isSharedCheck_4848_ == 0)
{
lean_object* v_unused_4849_; lean_object* v_unused_4850_; lean_object* v_unused_4851_; lean_object* v_unused_4852_; lean_object* v_unused_4853_; lean_object* v_unused_4854_; 
v_unused_4849_ = lean_ctor_get(v_a_4007_, 5);
lean_dec(v_unused_4849_);
v_unused_4850_ = lean_ctor_get(v_a_4007_, 4);
lean_dec(v_unused_4850_);
v_unused_4851_ = lean_ctor_get(v_a_4007_, 3);
lean_dec(v_unused_4851_);
v_unused_4852_ = lean_ctor_get(v_a_4007_, 2);
lean_dec(v_unused_4852_);
v_unused_4853_ = lean_ctor_get(v_a_4007_, 1);
lean_dec(v_unused_4853_);
v_unused_4854_ = lean_ctor_get(v_a_4007_, 0);
lean_dec(v_unused_4854_);
v___x_4130_ = v_a_4007_;
v_isShared_4131_ = v_isSharedCheck_4848_;
goto v_resetjp_4129_;
}
else
{
lean_dec(v_a_4007_);
v___x_4130_ = lean_box(0);
v_isShared_4131_ = v_isSharedCheck_4848_;
goto v_resetjp_4129_;
}
v_resetjp_4129_:
{
lean_object* v___x_4132_; lean_object* v___x_4134_; 
v___x_4132_ = l_Lean_NameHashSet_insert(v_visitedConstants_4122_, v_c_4005_);
if (v_isShared_4131_ == 0)
{
lean_ctor_set(v___x_4130_, 3, v___x_4132_);
v___x_4134_ = v___x_4130_;
goto v_reusejp_4133_;
}
else
{
lean_object* v_reuseFailAlloc_4847_; 
v_reuseFailAlloc_4847_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_4847_, 0, v_visitedNames_4119_);
lean_ctor_set(v_reuseFailAlloc_4847_, 1, v_visitedLevels_4120_);
lean_ctor_set(v_reuseFailAlloc_4847_, 2, v_visitedExprs_4121_);
lean_ctor_set(v_reuseFailAlloc_4847_, 3, v___x_4132_);
lean_ctor_set(v_reuseFailAlloc_4847_, 4, v_noMDataExprs_4123_);
lean_ctor_set(v_reuseFailAlloc_4847_, 5, v_recursorMap_4127_);
lean_ctor_set_uint8(v_reuseFailAlloc_4847_, sizeof(void*)*6, v_exportMData_4124_);
lean_ctor_set_uint8(v_reuseFailAlloc_4847_, sizeof(void*)*6 + 1, v_exportUnsafe_4125_);
lean_ctor_set_uint8(v_reuseFailAlloc_4847_, sizeof(void*)*6 + 2, v_ignoreMissing_4126_);
v___x_4134_ = v_reuseFailAlloc_4847_;
goto v_reusejp_4133_;
}
v_reusejp_4133_:
{
switch(lean_obj_tag(v_val_4117_))
{
case 0:
{
lean_object* v_val_4135_; lean_object* v___x_4137_; uint8_t v_isShared_4138_; uint8_t v_isSharedCheck_4239_; 
v_val_4135_ = lean_ctor_get(v_val_4117_, 0);
v_isSharedCheck_4239_ = !lean_is_exclusive(v_val_4117_);
if (v_isSharedCheck_4239_ == 0)
{
v___x_4137_ = v_val_4117_;
v_isShared_4138_ = v_isSharedCheck_4239_;
goto v_resetjp_4136_;
}
else
{
lean_inc(v_val_4135_);
lean_dec(v_val_4117_);
v___x_4137_ = lean_box(0);
v_isShared_4138_ = v_isSharedCheck_4239_;
goto v_resetjp_4136_;
}
v_resetjp_4136_:
{
lean_object* v_toConstantVal_4139_; uint8_t v_isUnsafe_4140_; lean_object* v_name_4141_; lean_object* v_levelParams_4142_; lean_object* v_type_4143_; lean_object* v___x_4144_; 
v_toConstantVal_4139_ = lean_ctor_get(v_val_4135_, 0);
lean_inc_ref(v_toConstantVal_4139_);
v_isUnsafe_4140_ = lean_ctor_get_uint8(v_val_4135_, sizeof(void*)*1);
lean_dec_ref(v_val_4135_);
v_name_4141_ = lean_ctor_get(v_toConstantVal_4139_, 0);
lean_inc(v_name_4141_);
v_levelParams_4142_ = lean_ctor_get(v_toConstantVal_4139_, 1);
lean_inc(v_levelParams_4142_);
v_type_4143_ = lean_ctor_get(v_toConstantVal_4139_, 2);
lean_inc_ref_n(v_type_4143_, 2);
lean_dec_ref(v_toConstantVal_4139_);
v___x_4144_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_4143_, v_a_4006_, v___x_4134_);
if (lean_obj_tag(v___x_4144_) == 0)
{
lean_object* v_a_4145_; lean_object* v___x_4147_; uint8_t v_isShared_4148_; uint8_t v_isSharedCheck_4238_; 
v_a_4145_ = lean_ctor_get(v___x_4144_, 0);
v_isSharedCheck_4238_ = !lean_is_exclusive(v___x_4144_);
if (v_isSharedCheck_4238_ == 0)
{
v___x_4147_ = v___x_4144_;
v_isShared_4148_ = v_isSharedCheck_4238_;
goto v_resetjp_4146_;
}
else
{
lean_inc(v_a_4145_);
lean_dec(v___x_4144_);
v___x_4147_ = lean_box(0);
v_isShared_4148_ = v_isSharedCheck_4238_;
goto v_resetjp_4146_;
}
v_resetjp_4146_:
{
lean_object* v_snd_4149_; lean_object* v___x_4151_; uint8_t v_isShared_4152_; uint8_t v_isSharedCheck_4236_; 
v_snd_4149_ = lean_ctor_get(v_a_4145_, 1);
v_isSharedCheck_4236_ = !lean_is_exclusive(v_a_4145_);
if (v_isSharedCheck_4236_ == 0)
{
lean_object* v_unused_4237_; 
v_unused_4237_ = lean_ctor_get(v_a_4145_, 0);
lean_dec(v_unused_4237_);
v___x_4151_ = v_a_4145_;
v_isShared_4152_ = v_isSharedCheck_4236_;
goto v_resetjp_4150_;
}
else
{
lean_inc(v_snd_4149_);
lean_dec(v_a_4145_);
v___x_4151_ = lean_box(0);
v_isShared_4152_ = v_isSharedCheck_4236_;
goto v_resetjp_4150_;
}
v_resetjp_4150_:
{
lean_object* v___x_4153_; 
v___x_4153_ = lp_proofEnvironment_dumpName(v_name_4141_, v_a_4006_, v_snd_4149_);
if (lean_obj_tag(v___x_4153_) == 0)
{
lean_object* v_a_4154_; lean_object* v_fst_4155_; lean_object* v_snd_4156_; lean_object* v___x_4158_; uint8_t v_isShared_4159_; uint8_t v_isSharedCheck_4227_; 
v_a_4154_ = lean_ctor_get(v___x_4153_, 0);
lean_inc(v_a_4154_);
lean_dec_ref_known(v___x_4153_, 1);
v_fst_4155_ = lean_ctor_get(v_a_4154_, 0);
v_snd_4156_ = lean_ctor_get(v_a_4154_, 1);
v_isSharedCheck_4227_ = !lean_is_exclusive(v_a_4154_);
if (v_isSharedCheck_4227_ == 0)
{
v___x_4158_ = v_a_4154_;
v_isShared_4159_ = v_isSharedCheck_4227_;
goto v_resetjp_4157_;
}
else
{
lean_inc(v_snd_4156_);
lean_inc(v_fst_4155_);
lean_dec(v_a_4154_);
v___x_4158_ = lean_box(0);
v_isShared_4159_ = v_isSharedCheck_4227_;
goto v_resetjp_4157_;
}
v_resetjp_4157_:
{
lean_object* v___x_4160_; 
v___x_4160_ = lp_proofEnvironment_dumpUparams(v_levelParams_4142_, v_a_4006_, v_snd_4156_);
if (lean_obj_tag(v___x_4160_) == 0)
{
lean_object* v_a_4161_; lean_object* v_fst_4162_; lean_object* v_snd_4163_; lean_object* v___x_4165_; uint8_t v_isShared_4166_; uint8_t v_isSharedCheck_4218_; 
v_a_4161_ = lean_ctor_get(v___x_4160_, 0);
lean_inc(v_a_4161_);
lean_dec_ref_known(v___x_4160_, 1);
v_fst_4162_ = lean_ctor_get(v_a_4161_, 0);
v_snd_4163_ = lean_ctor_get(v_a_4161_, 1);
v_isSharedCheck_4218_ = !lean_is_exclusive(v_a_4161_);
if (v_isSharedCheck_4218_ == 0)
{
v___x_4165_ = v_a_4161_;
v_isShared_4166_ = v_isSharedCheck_4218_;
goto v_resetjp_4164_;
}
else
{
lean_inc(v_snd_4163_);
lean_inc(v_fst_4162_);
lean_dec(v_a_4161_);
v___x_4165_ = lean_box(0);
v_isShared_4166_ = v_isSharedCheck_4218_;
goto v_resetjp_4164_;
}
v_resetjp_4164_:
{
lean_object* v___x_4167_; 
v___x_4167_ = lp_proofEnvironment_dumpExpr(v_type_4143_, v_a_4006_, v_snd_4163_);
if (lean_obj_tag(v___x_4167_) == 0)
{
lean_object* v_a_4168_; lean_object* v_fst_4169_; lean_object* v_snd_4170_; lean_object* v___x_4172_; uint8_t v_isShared_4173_; uint8_t v_isSharedCheck_4209_; 
v_a_4168_ = lean_ctor_get(v___x_4167_, 0);
lean_inc(v_a_4168_);
lean_dec_ref_known(v___x_4167_, 1);
v_fst_4169_ = lean_ctor_get(v_a_4168_, 0);
v_snd_4170_ = lean_ctor_get(v_a_4168_, 1);
v_isSharedCheck_4209_ = !lean_is_exclusive(v_a_4168_);
if (v_isSharedCheck_4209_ == 0)
{
v___x_4172_ = v_a_4168_;
v_isShared_4173_ = v_isSharedCheck_4209_;
goto v_resetjp_4171_;
}
else
{
lean_inc(v_snd_4170_);
lean_inc(v_fst_4169_);
lean_dec(v_a_4168_);
v___x_4172_ = lean_box(0);
v_isShared_4173_ = v_isSharedCheck_4209_;
goto v_resetjp_4171_;
}
v_resetjp_4171_:
{
lean_object* v___x_4174_; lean_object* v___x_4175_; lean_object* v___x_4176_; lean_object* v___x_4178_; 
v___x_4174_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__3));
v___x_4175_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_4176_ = l_Lean_JsonNumber_fromNat(v_fst_4155_);
if (v_isShared_4148_ == 0)
{
lean_ctor_set_tag(v___x_4147_, 2);
lean_ctor_set(v___x_4147_, 0, v___x_4176_);
v___x_4178_ = v___x_4147_;
goto v_reusejp_4177_;
}
else
{
lean_object* v_reuseFailAlloc_4208_; 
v_reuseFailAlloc_4208_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4208_, 0, v___x_4176_);
v___x_4178_ = v_reuseFailAlloc_4208_;
goto v_reusejp_4177_;
}
v_reusejp_4177_:
{
lean_object* v___x_4180_; 
if (v_isShared_4173_ == 0)
{
lean_ctor_set(v___x_4172_, 1, v___x_4178_);
lean_ctor_set(v___x_4172_, 0, v___x_4175_);
v___x_4180_ = v___x_4172_;
goto v_reusejp_4179_;
}
else
{
lean_object* v_reuseFailAlloc_4207_; 
v_reuseFailAlloc_4207_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4207_, 0, v___x_4175_);
lean_ctor_set(v_reuseFailAlloc_4207_, 1, v___x_4178_);
v___x_4180_ = v_reuseFailAlloc_4207_;
goto v_reusejp_4179_;
}
v_reusejp_4179_:
{
lean_object* v___x_4181_; lean_object* v___x_4183_; 
v___x_4181_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_4166_ == 0)
{
lean_ctor_set(v___x_4165_, 1, v_fst_4162_);
lean_ctor_set(v___x_4165_, 0, v___x_4181_);
v___x_4183_ = v___x_4165_;
goto v_reusejp_4182_;
}
else
{
lean_object* v_reuseFailAlloc_4206_; 
v_reuseFailAlloc_4206_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4206_, 0, v___x_4181_);
lean_ctor_set(v_reuseFailAlloc_4206_, 1, v_fst_4162_);
v___x_4183_ = v_reuseFailAlloc_4206_;
goto v_reusejp_4182_;
}
v_reusejp_4182_:
{
lean_object* v___x_4184_; lean_object* v___x_4185_; lean_object* v___x_4187_; 
v___x_4184_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_4185_ = l_Lean_JsonNumber_fromNat(v_fst_4169_);
if (v_isShared_4138_ == 0)
{
lean_ctor_set_tag(v___x_4137_, 2);
lean_ctor_set(v___x_4137_, 0, v___x_4185_);
v___x_4187_ = v___x_4137_;
goto v_reusejp_4186_;
}
else
{
lean_object* v_reuseFailAlloc_4205_; 
v_reuseFailAlloc_4205_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4205_, 0, v___x_4185_);
v___x_4187_ = v_reuseFailAlloc_4205_;
goto v_reusejp_4186_;
}
v_reusejp_4186_:
{
lean_object* v___x_4189_; 
if (v_isShared_4159_ == 0)
{
lean_ctor_set(v___x_4158_, 1, v___x_4187_);
lean_ctor_set(v___x_4158_, 0, v___x_4184_);
v___x_4189_ = v___x_4158_;
goto v_reusejp_4188_;
}
else
{
lean_object* v_reuseFailAlloc_4204_; 
v_reuseFailAlloc_4204_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4204_, 0, v___x_4184_);
lean_ctor_set(v_reuseFailAlloc_4204_, 1, v___x_4187_);
v___x_4189_ = v_reuseFailAlloc_4204_;
goto v_reusejp_4188_;
}
v_reusejp_4188_:
{
lean_object* v___x_4190_; lean_object* v___x_4191_; lean_object* v___x_4193_; 
v___x_4190_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6));
v___x_4191_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_4191_, 0, v_isUnsafe_4140_);
if (v_isShared_4152_ == 0)
{
lean_ctor_set(v___x_4151_, 1, v___x_4191_);
lean_ctor_set(v___x_4151_, 0, v___x_4190_);
v___x_4193_ = v___x_4151_;
goto v_reusejp_4192_;
}
else
{
lean_object* v_reuseFailAlloc_4203_; 
v_reuseFailAlloc_4203_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4203_, 0, v___x_4190_);
lean_ctor_set(v_reuseFailAlloc_4203_, 1, v___x_4191_);
v___x_4193_ = v_reuseFailAlloc_4203_;
goto v_reusejp_4192_;
}
v_reusejp_4192_:
{
lean_object* v___x_4194_; lean_object* v___x_4195_; lean_object* v___x_4196_; lean_object* v___x_4197_; lean_object* v___x_4198_; lean_object* v___x_4199_; lean_object* v___x_4200_; lean_object* v___x_4201_; lean_object* v___x_4202_; 
v___x_4194_ = lean_box(0);
v___x_4195_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4195_, 0, v___x_4193_);
lean_ctor_set(v___x_4195_, 1, v___x_4194_);
v___x_4196_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4196_, 0, v___x_4189_);
lean_ctor_set(v___x_4196_, 1, v___x_4195_);
v___x_4197_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4197_, 0, v___x_4183_);
lean_ctor_set(v___x_4197_, 1, v___x_4196_);
v___x_4198_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4198_, 0, v___x_4180_);
lean_ctor_set(v___x_4198_, 1, v___x_4197_);
v___x_4199_ = l_Lean_Json_mkObj(v___x_4198_);
lean_dec_ref_known(v___x_4198_, 2);
v___x_4200_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4200_, 0, v___x_4174_);
lean_ctor_set(v___x_4200_, 1, v___x_4199_);
v___x_4201_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4201_, 0, v___x_4200_);
lean_ctor_set(v___x_4201_, 1, v___x_4194_);
v___x_4202_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v___x_4201_, v_snd_4170_);
lean_dec_ref_known(v___x_4201_, 2);
return v___x_4202_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4210_; lean_object* v___x_4212_; uint8_t v_isShared_4213_; uint8_t v_isSharedCheck_4217_; 
lean_del_object(v___x_4165_);
lean_dec(v_fst_4162_);
lean_del_object(v___x_4158_);
lean_dec(v_fst_4155_);
lean_del_object(v___x_4151_);
lean_del_object(v___x_4147_);
lean_del_object(v___x_4137_);
v_a_4210_ = lean_ctor_get(v___x_4167_, 0);
v_isSharedCheck_4217_ = !lean_is_exclusive(v___x_4167_);
if (v_isSharedCheck_4217_ == 0)
{
v___x_4212_ = v___x_4167_;
v_isShared_4213_ = v_isSharedCheck_4217_;
goto v_resetjp_4211_;
}
else
{
lean_inc(v_a_4210_);
lean_dec(v___x_4167_);
v___x_4212_ = lean_box(0);
v_isShared_4213_ = v_isSharedCheck_4217_;
goto v_resetjp_4211_;
}
v_resetjp_4211_:
{
lean_object* v___x_4215_; 
if (v_isShared_4213_ == 0)
{
v___x_4215_ = v___x_4212_;
goto v_reusejp_4214_;
}
else
{
lean_object* v_reuseFailAlloc_4216_; 
v_reuseFailAlloc_4216_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4216_, 0, v_a_4210_);
v___x_4215_ = v_reuseFailAlloc_4216_;
goto v_reusejp_4214_;
}
v_reusejp_4214_:
{
return v___x_4215_;
}
}
}
}
}
else
{
lean_object* v_a_4219_; lean_object* v___x_4221_; uint8_t v_isShared_4222_; uint8_t v_isSharedCheck_4226_; 
lean_del_object(v___x_4158_);
lean_dec(v_fst_4155_);
lean_del_object(v___x_4151_);
lean_del_object(v___x_4147_);
lean_dec_ref(v_type_4143_);
lean_del_object(v___x_4137_);
v_a_4219_ = lean_ctor_get(v___x_4160_, 0);
v_isSharedCheck_4226_ = !lean_is_exclusive(v___x_4160_);
if (v_isSharedCheck_4226_ == 0)
{
v___x_4221_ = v___x_4160_;
v_isShared_4222_ = v_isSharedCheck_4226_;
goto v_resetjp_4220_;
}
else
{
lean_inc(v_a_4219_);
lean_dec(v___x_4160_);
v___x_4221_ = lean_box(0);
v_isShared_4222_ = v_isSharedCheck_4226_;
goto v_resetjp_4220_;
}
v_resetjp_4220_:
{
lean_object* v___x_4224_; 
if (v_isShared_4222_ == 0)
{
v___x_4224_ = v___x_4221_;
goto v_reusejp_4223_;
}
else
{
lean_object* v_reuseFailAlloc_4225_; 
v_reuseFailAlloc_4225_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4225_, 0, v_a_4219_);
v___x_4224_ = v_reuseFailAlloc_4225_;
goto v_reusejp_4223_;
}
v_reusejp_4223_:
{
return v___x_4224_;
}
}
}
}
}
else
{
lean_object* v_a_4228_; lean_object* v___x_4230_; uint8_t v_isShared_4231_; uint8_t v_isSharedCheck_4235_; 
lean_del_object(v___x_4151_);
lean_del_object(v___x_4147_);
lean_dec_ref(v_type_4143_);
lean_dec(v_levelParams_4142_);
lean_del_object(v___x_4137_);
v_a_4228_ = lean_ctor_get(v___x_4153_, 0);
v_isSharedCheck_4235_ = !lean_is_exclusive(v___x_4153_);
if (v_isSharedCheck_4235_ == 0)
{
v___x_4230_ = v___x_4153_;
v_isShared_4231_ = v_isSharedCheck_4235_;
goto v_resetjp_4229_;
}
else
{
lean_inc(v_a_4228_);
lean_dec(v___x_4153_);
v___x_4230_ = lean_box(0);
v_isShared_4231_ = v_isSharedCheck_4235_;
goto v_resetjp_4229_;
}
v_resetjp_4229_:
{
lean_object* v___x_4233_; 
if (v_isShared_4231_ == 0)
{
v___x_4233_ = v___x_4230_;
goto v_reusejp_4232_;
}
else
{
lean_object* v_reuseFailAlloc_4234_; 
v_reuseFailAlloc_4234_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4234_, 0, v_a_4228_);
v___x_4233_ = v_reuseFailAlloc_4234_;
goto v_reusejp_4232_;
}
v_reusejp_4232_:
{
return v___x_4233_;
}
}
}
}
}
}
else
{
lean_dec_ref(v_type_4143_);
lean_dec(v_levelParams_4142_);
lean_dec(v_name_4141_);
lean_del_object(v___x_4137_);
return v___x_4144_;
}
}
}
case 1:
{
lean_object* v_val_4240_; lean_object* v___x_4242_; uint8_t v_isShared_4243_; uint8_t v_isSharedCheck_4411_; 
v_val_4240_ = lean_ctor_get(v_val_4117_, 0);
v_isSharedCheck_4411_ = !lean_is_exclusive(v_val_4117_);
if (v_isSharedCheck_4411_ == 0)
{
v___x_4242_ = v_val_4117_;
v_isShared_4243_ = v_isSharedCheck_4411_;
goto v_resetjp_4241_;
}
else
{
lean_inc(v_val_4240_);
lean_dec(v_val_4117_);
v___x_4242_ = lean_box(0);
v_isShared_4243_ = v_isSharedCheck_4411_;
goto v_resetjp_4241_;
}
v_resetjp_4241_:
{
lean_object* v_toConstantVal_4244_; lean_object* v_value_4245_; lean_object* v_hints_4246_; uint8_t v_safety_4247_; lean_object* v_all_4248_; lean_object* v_name_4249_; lean_object* v_levelParams_4250_; lean_object* v_type_4251_; lean_object* v___x_4252_; 
v_toConstantVal_4244_ = lean_ctor_get(v_val_4240_, 0);
lean_inc_ref(v_toConstantVal_4244_);
v_value_4245_ = lean_ctor_get(v_val_4240_, 1);
lean_inc_ref(v_value_4245_);
v_hints_4246_ = lean_ctor_get(v_val_4240_, 2);
lean_inc(v_hints_4246_);
v_safety_4247_ = lean_ctor_get_uint8(v_val_4240_, sizeof(void*)*4);
v_all_4248_ = lean_ctor_get(v_val_4240_, 3);
lean_inc(v_all_4248_);
lean_dec_ref(v_val_4240_);
v_name_4249_ = lean_ctor_get(v_toConstantVal_4244_, 0);
lean_inc(v_name_4249_);
v_levelParams_4250_ = lean_ctor_get(v_toConstantVal_4244_, 1);
lean_inc(v_levelParams_4250_);
v_type_4251_ = lean_ctor_get(v_toConstantVal_4244_, 2);
lean_inc_ref_n(v_type_4251_, 2);
lean_dec_ref(v_toConstantVal_4244_);
v___x_4252_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_4251_, v_a_4006_, v___x_4134_);
if (lean_obj_tag(v___x_4252_) == 0)
{
lean_object* v_a_4253_; lean_object* v___x_4255_; uint8_t v_isShared_4256_; uint8_t v_isSharedCheck_4410_; 
v_a_4253_ = lean_ctor_get(v___x_4252_, 0);
v_isSharedCheck_4410_ = !lean_is_exclusive(v___x_4252_);
if (v_isSharedCheck_4410_ == 0)
{
v___x_4255_ = v___x_4252_;
v_isShared_4256_ = v_isSharedCheck_4410_;
goto v_resetjp_4254_;
}
else
{
lean_inc(v_a_4253_);
lean_dec(v___x_4252_);
v___x_4255_ = lean_box(0);
v_isShared_4256_ = v_isSharedCheck_4410_;
goto v_resetjp_4254_;
}
v_resetjp_4254_:
{
lean_object* v_snd_4257_; lean_object* v___x_4259_; uint8_t v_isShared_4260_; uint8_t v_isSharedCheck_4408_; 
v_snd_4257_ = lean_ctor_get(v_a_4253_, 1);
v_isSharedCheck_4408_ = !lean_is_exclusive(v_a_4253_);
if (v_isSharedCheck_4408_ == 0)
{
lean_object* v_unused_4409_; 
v_unused_4409_ = lean_ctor_get(v_a_4253_, 0);
lean_dec(v_unused_4409_);
v___x_4259_ = v_a_4253_;
v_isShared_4260_ = v_isSharedCheck_4408_;
goto v_resetjp_4258_;
}
else
{
lean_inc(v_snd_4257_);
lean_dec(v_a_4253_);
v___x_4259_ = lean_box(0);
v_isShared_4260_ = v_isSharedCheck_4408_;
goto v_resetjp_4258_;
}
v_resetjp_4258_:
{
lean_object* v___x_4261_; 
lean_inc_ref(v_value_4245_);
v___x_4261_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_value_4245_, v_a_4006_, v_snd_4257_);
if (lean_obj_tag(v___x_4261_) == 0)
{
lean_object* v_a_4262_; lean_object* v___x_4264_; uint8_t v_isShared_4265_; uint8_t v_isSharedCheck_4407_; 
v_a_4262_ = lean_ctor_get(v___x_4261_, 0);
v_isSharedCheck_4407_ = !lean_is_exclusive(v___x_4261_);
if (v_isSharedCheck_4407_ == 0)
{
v___x_4264_ = v___x_4261_;
v_isShared_4265_ = v_isSharedCheck_4407_;
goto v_resetjp_4263_;
}
else
{
lean_inc(v_a_4262_);
lean_dec(v___x_4261_);
v___x_4264_ = lean_box(0);
v_isShared_4265_ = v_isSharedCheck_4407_;
goto v_resetjp_4263_;
}
v_resetjp_4263_:
{
lean_object* v_snd_4266_; lean_object* v___x_4268_; uint8_t v_isShared_4269_; uint8_t v_isSharedCheck_4405_; 
v_snd_4266_ = lean_ctor_get(v_a_4262_, 1);
v_isSharedCheck_4405_ = !lean_is_exclusive(v_a_4262_);
if (v_isSharedCheck_4405_ == 0)
{
lean_object* v_unused_4406_; 
v_unused_4406_ = lean_ctor_get(v_a_4262_, 0);
lean_dec(v_unused_4406_);
v___x_4268_ = v_a_4262_;
v_isShared_4269_ = v_isSharedCheck_4405_;
goto v_resetjp_4267_;
}
else
{
lean_inc(v_snd_4266_);
lean_dec(v_a_4262_);
v___x_4268_ = lean_box(0);
v_isShared_4269_ = v_isSharedCheck_4405_;
goto v_resetjp_4267_;
}
v_resetjp_4267_:
{
lean_object* v___x_4270_; 
v___x_4270_ = lp_proofEnvironment_dumpName(v_name_4249_, v_a_4006_, v_snd_4266_);
if (lean_obj_tag(v___x_4270_) == 0)
{
lean_object* v_a_4271_; lean_object* v_fst_4272_; lean_object* v_snd_4273_; lean_object* v___x_4275_; uint8_t v_isShared_4276_; uint8_t v_isSharedCheck_4396_; 
v_a_4271_ = lean_ctor_get(v___x_4270_, 0);
lean_inc(v_a_4271_);
lean_dec_ref_known(v___x_4270_, 1);
v_fst_4272_ = lean_ctor_get(v_a_4271_, 0);
v_snd_4273_ = lean_ctor_get(v_a_4271_, 1);
v_isSharedCheck_4396_ = !lean_is_exclusive(v_a_4271_);
if (v_isSharedCheck_4396_ == 0)
{
v___x_4275_ = v_a_4271_;
v_isShared_4276_ = v_isSharedCheck_4396_;
goto v_resetjp_4274_;
}
else
{
lean_inc(v_snd_4273_);
lean_inc(v_fst_4272_);
lean_dec(v_a_4271_);
v___x_4275_ = lean_box(0);
v_isShared_4276_ = v_isSharedCheck_4396_;
goto v_resetjp_4274_;
}
v_resetjp_4274_:
{
lean_object* v___x_4277_; 
v___x_4277_ = lp_proofEnvironment_dumpUparams(v_levelParams_4250_, v_a_4006_, v_snd_4273_);
if (lean_obj_tag(v___x_4277_) == 0)
{
lean_object* v_a_4278_; lean_object* v_fst_4279_; lean_object* v_snd_4280_; lean_object* v___x_4282_; uint8_t v_isShared_4283_; uint8_t v_isSharedCheck_4387_; 
v_a_4278_ = lean_ctor_get(v___x_4277_, 0);
lean_inc(v_a_4278_);
lean_dec_ref_known(v___x_4277_, 1);
v_fst_4279_ = lean_ctor_get(v_a_4278_, 0);
v_snd_4280_ = lean_ctor_get(v_a_4278_, 1);
v_isSharedCheck_4387_ = !lean_is_exclusive(v_a_4278_);
if (v_isSharedCheck_4387_ == 0)
{
v___x_4282_ = v_a_4278_;
v_isShared_4283_ = v_isSharedCheck_4387_;
goto v_resetjp_4281_;
}
else
{
lean_inc(v_snd_4280_);
lean_inc(v_fst_4279_);
lean_dec(v_a_4278_);
v___x_4282_ = lean_box(0);
v_isShared_4283_ = v_isSharedCheck_4387_;
goto v_resetjp_4281_;
}
v_resetjp_4281_:
{
lean_object* v___x_4284_; 
v___x_4284_ = lp_proofEnvironment_dumpExpr(v_type_4251_, v_a_4006_, v_snd_4280_);
if (lean_obj_tag(v___x_4284_) == 0)
{
lean_object* v_a_4285_; lean_object* v_fst_4286_; lean_object* v_snd_4287_; lean_object* v___x_4289_; uint8_t v_isShared_4290_; uint8_t v_isSharedCheck_4378_; 
v_a_4285_ = lean_ctor_get(v___x_4284_, 0);
lean_inc(v_a_4285_);
lean_dec_ref_known(v___x_4284_, 1);
v_fst_4286_ = lean_ctor_get(v_a_4285_, 0);
v_snd_4287_ = lean_ctor_get(v_a_4285_, 1);
v_isSharedCheck_4378_ = !lean_is_exclusive(v_a_4285_);
if (v_isSharedCheck_4378_ == 0)
{
v___x_4289_ = v_a_4285_;
v_isShared_4290_ = v_isSharedCheck_4378_;
goto v_resetjp_4288_;
}
else
{
lean_inc(v_snd_4287_);
lean_inc(v_fst_4286_);
lean_dec(v_a_4285_);
v___x_4289_ = lean_box(0);
v_isShared_4290_ = v_isSharedCheck_4378_;
goto v_resetjp_4288_;
}
v_resetjp_4288_:
{
lean_object* v___x_4291_; 
v___x_4291_ = lp_proofEnvironment_dumpExpr(v_value_4245_, v_a_4006_, v_snd_4287_);
if (lean_obj_tag(v___x_4291_) == 0)
{
lean_object* v_a_4292_; lean_object* v_fst_4293_; lean_object* v_snd_4294_; lean_object* v___x_4296_; uint8_t v_isShared_4297_; uint8_t v_isSharedCheck_4369_; 
v_a_4292_ = lean_ctor_get(v___x_4291_, 0);
lean_inc(v_a_4292_);
lean_dec_ref_known(v___x_4291_, 1);
v_fst_4293_ = lean_ctor_get(v_a_4292_, 0);
v_snd_4294_ = lean_ctor_get(v_a_4292_, 1);
v_isSharedCheck_4369_ = !lean_is_exclusive(v_a_4292_);
if (v_isSharedCheck_4369_ == 0)
{
v___x_4296_ = v_a_4292_;
v_isShared_4297_ = v_isSharedCheck_4369_;
goto v_resetjp_4295_;
}
else
{
lean_inc(v_snd_4294_);
lean_inc(v_fst_4293_);
lean_dec(v_a_4292_);
v___x_4296_ = lean_box(0);
v_isShared_4297_ = v_isSharedCheck_4369_;
goto v_resetjp_4295_;
}
v_resetjp_4295_:
{
lean_object* v___x_4298_; 
v___x_4298_ = lp_proofEnvironment_dumpNames(v_all_4248_, v_a_4006_, v_snd_4294_);
if (lean_obj_tag(v___x_4298_) == 0)
{
lean_object* v_a_4299_; lean_object* v_fst_4300_; lean_object* v_snd_4301_; lean_object* v___x_4303_; uint8_t v_isShared_4304_; uint8_t v_isSharedCheck_4360_; 
v_a_4299_ = lean_ctor_get(v___x_4298_, 0);
lean_inc(v_a_4299_);
lean_dec_ref_known(v___x_4298_, 1);
v_fst_4300_ = lean_ctor_get(v_a_4299_, 0);
v_snd_4301_ = lean_ctor_get(v_a_4299_, 1);
v_isSharedCheck_4360_ = !lean_is_exclusive(v_a_4299_);
if (v_isSharedCheck_4360_ == 0)
{
v___x_4303_ = v_a_4299_;
v_isShared_4304_ = v_isSharedCheck_4360_;
goto v_resetjp_4302_;
}
else
{
lean_inc(v_snd_4301_);
lean_inc(v_fst_4300_);
lean_dec(v_a_4299_);
v___x_4303_ = lean_box(0);
v_isShared_4304_ = v_isSharedCheck_4360_;
goto v_resetjp_4302_;
}
v_resetjp_4302_:
{
lean_object* v___x_4305_; lean_object* v___x_4306_; lean_object* v___x_4307_; lean_object* v___x_4309_; 
v___x_4305_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__4));
v___x_4306_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_4307_ = l_Lean_JsonNumber_fromNat(v_fst_4272_);
if (v_isShared_4265_ == 0)
{
lean_ctor_set_tag(v___x_4264_, 2);
lean_ctor_set(v___x_4264_, 0, v___x_4307_);
v___x_4309_ = v___x_4264_;
goto v_reusejp_4308_;
}
else
{
lean_object* v_reuseFailAlloc_4359_; 
v_reuseFailAlloc_4359_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4359_, 0, v___x_4307_);
v___x_4309_ = v_reuseFailAlloc_4359_;
goto v_reusejp_4308_;
}
v_reusejp_4308_:
{
lean_object* v___x_4311_; 
if (v_isShared_4304_ == 0)
{
lean_ctor_set(v___x_4303_, 1, v___x_4309_);
lean_ctor_set(v___x_4303_, 0, v___x_4306_);
v___x_4311_ = v___x_4303_;
goto v_reusejp_4310_;
}
else
{
lean_object* v_reuseFailAlloc_4358_; 
v_reuseFailAlloc_4358_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4358_, 0, v___x_4306_);
lean_ctor_set(v_reuseFailAlloc_4358_, 1, v___x_4309_);
v___x_4311_ = v_reuseFailAlloc_4358_;
goto v_reusejp_4310_;
}
v_reusejp_4310_:
{
lean_object* v___x_4312_; lean_object* v___x_4314_; 
v___x_4312_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_4297_ == 0)
{
lean_ctor_set(v___x_4296_, 1, v_fst_4279_);
lean_ctor_set(v___x_4296_, 0, v___x_4312_);
v___x_4314_ = v___x_4296_;
goto v_reusejp_4313_;
}
else
{
lean_object* v_reuseFailAlloc_4357_; 
v_reuseFailAlloc_4357_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4357_, 0, v___x_4312_);
lean_ctor_set(v_reuseFailAlloc_4357_, 1, v_fst_4279_);
v___x_4314_ = v_reuseFailAlloc_4357_;
goto v_reusejp_4313_;
}
v_reusejp_4313_:
{
lean_object* v___x_4315_; lean_object* v___x_4316_; lean_object* v___x_4318_; 
v___x_4315_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_4316_ = l_Lean_JsonNumber_fromNat(v_fst_4286_);
if (v_isShared_4256_ == 0)
{
lean_ctor_set_tag(v___x_4255_, 2);
lean_ctor_set(v___x_4255_, 0, v___x_4316_);
v___x_4318_ = v___x_4255_;
goto v_reusejp_4317_;
}
else
{
lean_object* v_reuseFailAlloc_4356_; 
v_reuseFailAlloc_4356_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4356_, 0, v___x_4316_);
v___x_4318_ = v_reuseFailAlloc_4356_;
goto v_reusejp_4317_;
}
v_reusejp_4317_:
{
lean_object* v___x_4320_; 
if (v_isShared_4290_ == 0)
{
lean_ctor_set(v___x_4289_, 1, v___x_4318_);
lean_ctor_set(v___x_4289_, 0, v___x_4315_);
v___x_4320_ = v___x_4289_;
goto v_reusejp_4319_;
}
else
{
lean_object* v_reuseFailAlloc_4355_; 
v_reuseFailAlloc_4355_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4355_, 0, v___x_4315_);
lean_ctor_set(v_reuseFailAlloc_4355_, 1, v___x_4318_);
v___x_4320_ = v_reuseFailAlloc_4355_;
goto v_reusejp_4319_;
}
v_reusejp_4319_:
{
lean_object* v___x_4321_; lean_object* v___x_4322_; lean_object* v___x_4324_; 
v___x_4321_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__13));
v___x_4322_ = l_Lean_JsonNumber_fromNat(v_fst_4293_);
if (v_isShared_4243_ == 0)
{
lean_ctor_set_tag(v___x_4242_, 2);
lean_ctor_set(v___x_4242_, 0, v___x_4322_);
v___x_4324_ = v___x_4242_;
goto v_reusejp_4323_;
}
else
{
lean_object* v_reuseFailAlloc_4354_; 
v_reuseFailAlloc_4354_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4354_, 0, v___x_4322_);
v___x_4324_ = v_reuseFailAlloc_4354_;
goto v_reusejp_4323_;
}
v_reusejp_4323_:
{
lean_object* v___x_4326_; 
if (v_isShared_4283_ == 0)
{
lean_ctor_set(v___x_4282_, 1, v___x_4324_);
lean_ctor_set(v___x_4282_, 0, v___x_4321_);
v___x_4326_ = v___x_4282_;
goto v_reusejp_4325_;
}
else
{
lean_object* v_reuseFailAlloc_4353_; 
v_reuseFailAlloc_4353_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4353_, 0, v___x_4321_);
lean_ctor_set(v_reuseFailAlloc_4353_, 1, v___x_4324_);
v___x_4326_ = v_reuseFailAlloc_4353_;
goto v_reusejp_4325_;
}
v_reusejp_4325_:
{
lean_object* v___x_4327_; lean_object* v___x_4328_; lean_object* v___x_4330_; 
v___x_4327_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__5));
v___x_4328_ = lp_proofEnvironment_Lean_ReducibilityHints_toJson(v_hints_4246_);
lean_dec(v_hints_4246_);
if (v_isShared_4276_ == 0)
{
lean_ctor_set(v___x_4275_, 1, v___x_4328_);
lean_ctor_set(v___x_4275_, 0, v___x_4327_);
v___x_4330_ = v___x_4275_;
goto v_reusejp_4329_;
}
else
{
lean_object* v_reuseFailAlloc_4352_; 
v_reuseFailAlloc_4352_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4352_, 0, v___x_4327_);
lean_ctor_set(v_reuseFailAlloc_4352_, 1, v___x_4328_);
v___x_4330_ = v_reuseFailAlloc_4352_;
goto v_reusejp_4329_;
}
v_reusejp_4329_:
{
lean_object* v___x_4331_; lean_object* v___x_4332_; lean_object* v___x_4334_; 
v___x_4331_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__6));
v___x_4332_ = lp_proofEnvironment_Lean_DefinitionSafety_toJson(v_safety_4247_);
if (v_isShared_4269_ == 0)
{
lean_ctor_set(v___x_4268_, 1, v___x_4332_);
lean_ctor_set(v___x_4268_, 0, v___x_4331_);
v___x_4334_ = v___x_4268_;
goto v_reusejp_4333_;
}
else
{
lean_object* v_reuseFailAlloc_4351_; 
v_reuseFailAlloc_4351_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4351_, 0, v___x_4331_);
lean_ctor_set(v_reuseFailAlloc_4351_, 1, v___x_4332_);
v___x_4334_ = v_reuseFailAlloc_4351_;
goto v_reusejp_4333_;
}
v_reusejp_4333_:
{
lean_object* v___x_4335_; lean_object* v___x_4337_; 
v___x_4335_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1));
if (v_isShared_4260_ == 0)
{
lean_ctor_set(v___x_4259_, 1, v_fst_4300_);
lean_ctor_set(v___x_4259_, 0, v___x_4335_);
v___x_4337_ = v___x_4259_;
goto v_reusejp_4336_;
}
else
{
lean_object* v_reuseFailAlloc_4350_; 
v_reuseFailAlloc_4350_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4350_, 0, v___x_4335_);
lean_ctor_set(v_reuseFailAlloc_4350_, 1, v_fst_4300_);
v___x_4337_ = v_reuseFailAlloc_4350_;
goto v_reusejp_4336_;
}
v_reusejp_4336_:
{
lean_object* v___x_4338_; lean_object* v___x_4339_; lean_object* v___x_4340_; lean_object* v___x_4341_; lean_object* v___x_4342_; lean_object* v___x_4343_; lean_object* v___x_4344_; lean_object* v___x_4345_; lean_object* v___x_4346_; lean_object* v___x_4347_; lean_object* v___x_4348_; lean_object* v___x_4349_; 
v___x_4338_ = lean_box(0);
v___x_4339_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4339_, 0, v___x_4337_);
lean_ctor_set(v___x_4339_, 1, v___x_4338_);
v___x_4340_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4340_, 0, v___x_4334_);
lean_ctor_set(v___x_4340_, 1, v___x_4339_);
v___x_4341_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4341_, 0, v___x_4330_);
lean_ctor_set(v___x_4341_, 1, v___x_4340_);
v___x_4342_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4342_, 0, v___x_4326_);
lean_ctor_set(v___x_4342_, 1, v___x_4341_);
v___x_4343_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4343_, 0, v___x_4320_);
lean_ctor_set(v___x_4343_, 1, v___x_4342_);
v___x_4344_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4344_, 0, v___x_4314_);
lean_ctor_set(v___x_4344_, 1, v___x_4343_);
v___x_4345_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4345_, 0, v___x_4311_);
lean_ctor_set(v___x_4345_, 1, v___x_4344_);
v___x_4346_ = l_Lean_Json_mkObj(v___x_4345_);
lean_dec_ref_known(v___x_4345_, 2);
v___x_4347_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4347_, 0, v___x_4305_);
lean_ctor_set(v___x_4347_, 1, v___x_4346_);
v___x_4348_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4348_, 0, v___x_4347_);
lean_ctor_set(v___x_4348_, 1, v___x_4338_);
v___x_4349_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v___x_4348_, v_snd_4301_);
lean_dec_ref_known(v___x_4348_, 2);
return v___x_4349_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4361_; lean_object* v___x_4363_; uint8_t v_isShared_4364_; uint8_t v_isSharedCheck_4368_; 
lean_del_object(v___x_4296_);
lean_dec(v_fst_4293_);
lean_del_object(v___x_4289_);
lean_dec(v_fst_4286_);
lean_del_object(v___x_4282_);
lean_dec(v_fst_4279_);
lean_del_object(v___x_4275_);
lean_dec(v_fst_4272_);
lean_del_object(v___x_4268_);
lean_del_object(v___x_4264_);
lean_del_object(v___x_4259_);
lean_del_object(v___x_4255_);
lean_dec(v_hints_4246_);
lean_del_object(v___x_4242_);
v_a_4361_ = lean_ctor_get(v___x_4298_, 0);
v_isSharedCheck_4368_ = !lean_is_exclusive(v___x_4298_);
if (v_isSharedCheck_4368_ == 0)
{
v___x_4363_ = v___x_4298_;
v_isShared_4364_ = v_isSharedCheck_4368_;
goto v_resetjp_4362_;
}
else
{
lean_inc(v_a_4361_);
lean_dec(v___x_4298_);
v___x_4363_ = lean_box(0);
v_isShared_4364_ = v_isSharedCheck_4368_;
goto v_resetjp_4362_;
}
v_resetjp_4362_:
{
lean_object* v___x_4366_; 
if (v_isShared_4364_ == 0)
{
v___x_4366_ = v___x_4363_;
goto v_reusejp_4365_;
}
else
{
lean_object* v_reuseFailAlloc_4367_; 
v_reuseFailAlloc_4367_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4367_, 0, v_a_4361_);
v___x_4366_ = v_reuseFailAlloc_4367_;
goto v_reusejp_4365_;
}
v_reusejp_4365_:
{
return v___x_4366_;
}
}
}
}
}
else
{
lean_object* v_a_4370_; lean_object* v___x_4372_; uint8_t v_isShared_4373_; uint8_t v_isSharedCheck_4377_; 
lean_del_object(v___x_4289_);
lean_dec(v_fst_4286_);
lean_del_object(v___x_4282_);
lean_dec(v_fst_4279_);
lean_del_object(v___x_4275_);
lean_dec(v_fst_4272_);
lean_del_object(v___x_4268_);
lean_del_object(v___x_4264_);
lean_del_object(v___x_4259_);
lean_del_object(v___x_4255_);
lean_dec(v_all_4248_);
lean_dec(v_hints_4246_);
lean_del_object(v___x_4242_);
v_a_4370_ = lean_ctor_get(v___x_4291_, 0);
v_isSharedCheck_4377_ = !lean_is_exclusive(v___x_4291_);
if (v_isSharedCheck_4377_ == 0)
{
v___x_4372_ = v___x_4291_;
v_isShared_4373_ = v_isSharedCheck_4377_;
goto v_resetjp_4371_;
}
else
{
lean_inc(v_a_4370_);
lean_dec(v___x_4291_);
v___x_4372_ = lean_box(0);
v_isShared_4373_ = v_isSharedCheck_4377_;
goto v_resetjp_4371_;
}
v_resetjp_4371_:
{
lean_object* v___x_4375_; 
if (v_isShared_4373_ == 0)
{
v___x_4375_ = v___x_4372_;
goto v_reusejp_4374_;
}
else
{
lean_object* v_reuseFailAlloc_4376_; 
v_reuseFailAlloc_4376_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4376_, 0, v_a_4370_);
v___x_4375_ = v_reuseFailAlloc_4376_;
goto v_reusejp_4374_;
}
v_reusejp_4374_:
{
return v___x_4375_;
}
}
}
}
}
else
{
lean_object* v_a_4379_; lean_object* v___x_4381_; uint8_t v_isShared_4382_; uint8_t v_isSharedCheck_4386_; 
lean_del_object(v___x_4282_);
lean_dec(v_fst_4279_);
lean_del_object(v___x_4275_);
lean_dec(v_fst_4272_);
lean_del_object(v___x_4268_);
lean_del_object(v___x_4264_);
lean_del_object(v___x_4259_);
lean_del_object(v___x_4255_);
lean_dec(v_all_4248_);
lean_dec(v_hints_4246_);
lean_dec_ref(v_value_4245_);
lean_del_object(v___x_4242_);
v_a_4379_ = lean_ctor_get(v___x_4284_, 0);
v_isSharedCheck_4386_ = !lean_is_exclusive(v___x_4284_);
if (v_isSharedCheck_4386_ == 0)
{
v___x_4381_ = v___x_4284_;
v_isShared_4382_ = v_isSharedCheck_4386_;
goto v_resetjp_4380_;
}
else
{
lean_inc(v_a_4379_);
lean_dec(v___x_4284_);
v___x_4381_ = lean_box(0);
v_isShared_4382_ = v_isSharedCheck_4386_;
goto v_resetjp_4380_;
}
v_resetjp_4380_:
{
lean_object* v___x_4384_; 
if (v_isShared_4382_ == 0)
{
v___x_4384_ = v___x_4381_;
goto v_reusejp_4383_;
}
else
{
lean_object* v_reuseFailAlloc_4385_; 
v_reuseFailAlloc_4385_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4385_, 0, v_a_4379_);
v___x_4384_ = v_reuseFailAlloc_4385_;
goto v_reusejp_4383_;
}
v_reusejp_4383_:
{
return v___x_4384_;
}
}
}
}
}
else
{
lean_object* v_a_4388_; lean_object* v___x_4390_; uint8_t v_isShared_4391_; uint8_t v_isSharedCheck_4395_; 
lean_del_object(v___x_4275_);
lean_dec(v_fst_4272_);
lean_del_object(v___x_4268_);
lean_del_object(v___x_4264_);
lean_del_object(v___x_4259_);
lean_del_object(v___x_4255_);
lean_dec_ref(v_type_4251_);
lean_dec(v_all_4248_);
lean_dec(v_hints_4246_);
lean_dec_ref(v_value_4245_);
lean_del_object(v___x_4242_);
v_a_4388_ = lean_ctor_get(v___x_4277_, 0);
v_isSharedCheck_4395_ = !lean_is_exclusive(v___x_4277_);
if (v_isSharedCheck_4395_ == 0)
{
v___x_4390_ = v___x_4277_;
v_isShared_4391_ = v_isSharedCheck_4395_;
goto v_resetjp_4389_;
}
else
{
lean_inc(v_a_4388_);
lean_dec(v___x_4277_);
v___x_4390_ = lean_box(0);
v_isShared_4391_ = v_isSharedCheck_4395_;
goto v_resetjp_4389_;
}
v_resetjp_4389_:
{
lean_object* v___x_4393_; 
if (v_isShared_4391_ == 0)
{
v___x_4393_ = v___x_4390_;
goto v_reusejp_4392_;
}
else
{
lean_object* v_reuseFailAlloc_4394_; 
v_reuseFailAlloc_4394_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4394_, 0, v_a_4388_);
v___x_4393_ = v_reuseFailAlloc_4394_;
goto v_reusejp_4392_;
}
v_reusejp_4392_:
{
return v___x_4393_;
}
}
}
}
}
else
{
lean_object* v_a_4397_; lean_object* v___x_4399_; uint8_t v_isShared_4400_; uint8_t v_isSharedCheck_4404_; 
lean_del_object(v___x_4268_);
lean_del_object(v___x_4264_);
lean_del_object(v___x_4259_);
lean_del_object(v___x_4255_);
lean_dec_ref(v_type_4251_);
lean_dec(v_levelParams_4250_);
lean_dec(v_all_4248_);
lean_dec(v_hints_4246_);
lean_dec_ref(v_value_4245_);
lean_del_object(v___x_4242_);
v_a_4397_ = lean_ctor_get(v___x_4270_, 0);
v_isSharedCheck_4404_ = !lean_is_exclusive(v___x_4270_);
if (v_isSharedCheck_4404_ == 0)
{
v___x_4399_ = v___x_4270_;
v_isShared_4400_ = v_isSharedCheck_4404_;
goto v_resetjp_4398_;
}
else
{
lean_inc(v_a_4397_);
lean_dec(v___x_4270_);
v___x_4399_ = lean_box(0);
v_isShared_4400_ = v_isSharedCheck_4404_;
goto v_resetjp_4398_;
}
v_resetjp_4398_:
{
lean_object* v___x_4402_; 
if (v_isShared_4400_ == 0)
{
v___x_4402_ = v___x_4399_;
goto v_reusejp_4401_;
}
else
{
lean_object* v_reuseFailAlloc_4403_; 
v_reuseFailAlloc_4403_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4403_, 0, v_a_4397_);
v___x_4402_ = v_reuseFailAlloc_4403_;
goto v_reusejp_4401_;
}
v_reusejp_4401_:
{
return v___x_4402_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_4259_);
lean_del_object(v___x_4255_);
lean_dec_ref(v_type_4251_);
lean_dec(v_levelParams_4250_);
lean_dec(v_name_4249_);
lean_dec(v_all_4248_);
lean_dec(v_hints_4246_);
lean_dec_ref(v_value_4245_);
lean_del_object(v___x_4242_);
return v___x_4261_;
}
}
}
}
else
{
lean_dec_ref(v_type_4251_);
lean_dec(v_levelParams_4250_);
lean_dec(v_name_4249_);
lean_dec(v_all_4248_);
lean_dec(v_hints_4246_);
lean_dec_ref(v_value_4245_);
lean_del_object(v___x_4242_);
return v___x_4252_;
}
}
}
case 2:
{
lean_object* v_val_4412_; lean_object* v___x_4414_; uint8_t v_isShared_4415_; uint8_t v_isSharedCheck_4573_; 
v_val_4412_ = lean_ctor_get(v_val_4117_, 0);
v_isSharedCheck_4573_ = !lean_is_exclusive(v_val_4117_);
if (v_isSharedCheck_4573_ == 0)
{
v___x_4414_ = v_val_4117_;
v_isShared_4415_ = v_isSharedCheck_4573_;
goto v_resetjp_4413_;
}
else
{
lean_inc(v_val_4412_);
lean_dec(v_val_4117_);
v___x_4414_ = lean_box(0);
v_isShared_4415_ = v_isSharedCheck_4573_;
goto v_resetjp_4413_;
}
v_resetjp_4413_:
{
lean_object* v_toConstantVal_4416_; lean_object* v_value_4417_; lean_object* v_all_4418_; lean_object* v_name_4419_; lean_object* v_levelParams_4420_; lean_object* v_type_4421_; lean_object* v___x_4422_; 
v_toConstantVal_4416_ = lean_ctor_get(v_val_4412_, 0);
lean_inc_ref(v_toConstantVal_4416_);
v_value_4417_ = lean_ctor_get(v_val_4412_, 1);
lean_inc_ref(v_value_4417_);
v_all_4418_ = lean_ctor_get(v_val_4412_, 2);
lean_inc(v_all_4418_);
lean_dec_ref(v_val_4412_);
v_name_4419_ = lean_ctor_get(v_toConstantVal_4416_, 0);
lean_inc(v_name_4419_);
v_levelParams_4420_ = lean_ctor_get(v_toConstantVal_4416_, 1);
lean_inc(v_levelParams_4420_);
v_type_4421_ = lean_ctor_get(v_toConstantVal_4416_, 2);
lean_inc_ref_n(v_type_4421_, 2);
lean_dec_ref(v_toConstantVal_4416_);
v___x_4422_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_4421_, v_a_4006_, v___x_4134_);
if (lean_obj_tag(v___x_4422_) == 0)
{
lean_object* v_a_4423_; lean_object* v___x_4425_; uint8_t v_isShared_4426_; uint8_t v_isSharedCheck_4572_; 
v_a_4423_ = lean_ctor_get(v___x_4422_, 0);
v_isSharedCheck_4572_ = !lean_is_exclusive(v___x_4422_);
if (v_isSharedCheck_4572_ == 0)
{
v___x_4425_ = v___x_4422_;
v_isShared_4426_ = v_isSharedCheck_4572_;
goto v_resetjp_4424_;
}
else
{
lean_inc(v_a_4423_);
lean_dec(v___x_4422_);
v___x_4425_ = lean_box(0);
v_isShared_4426_ = v_isSharedCheck_4572_;
goto v_resetjp_4424_;
}
v_resetjp_4424_:
{
lean_object* v_snd_4427_; lean_object* v___x_4429_; uint8_t v_isShared_4430_; uint8_t v_isSharedCheck_4570_; 
v_snd_4427_ = lean_ctor_get(v_a_4423_, 1);
v_isSharedCheck_4570_ = !lean_is_exclusive(v_a_4423_);
if (v_isSharedCheck_4570_ == 0)
{
lean_object* v_unused_4571_; 
v_unused_4571_ = lean_ctor_get(v_a_4423_, 0);
lean_dec(v_unused_4571_);
v___x_4429_ = v_a_4423_;
v_isShared_4430_ = v_isSharedCheck_4570_;
goto v_resetjp_4428_;
}
else
{
lean_inc(v_snd_4427_);
lean_dec(v_a_4423_);
v___x_4429_ = lean_box(0);
v_isShared_4430_ = v_isSharedCheck_4570_;
goto v_resetjp_4428_;
}
v_resetjp_4428_:
{
lean_object* v___x_4431_; 
lean_inc_ref(v_value_4417_);
v___x_4431_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_value_4417_, v_a_4006_, v_snd_4427_);
if (lean_obj_tag(v___x_4431_) == 0)
{
lean_object* v_a_4432_; lean_object* v___x_4434_; uint8_t v_isShared_4435_; uint8_t v_isSharedCheck_4569_; 
v_a_4432_ = lean_ctor_get(v___x_4431_, 0);
v_isSharedCheck_4569_ = !lean_is_exclusive(v___x_4431_);
if (v_isSharedCheck_4569_ == 0)
{
v___x_4434_ = v___x_4431_;
v_isShared_4435_ = v_isSharedCheck_4569_;
goto v_resetjp_4433_;
}
else
{
lean_inc(v_a_4432_);
lean_dec(v___x_4431_);
v___x_4434_ = lean_box(0);
v_isShared_4435_ = v_isSharedCheck_4569_;
goto v_resetjp_4433_;
}
v_resetjp_4433_:
{
lean_object* v_snd_4436_; lean_object* v___x_4438_; uint8_t v_isShared_4439_; uint8_t v_isSharedCheck_4567_; 
v_snd_4436_ = lean_ctor_get(v_a_4432_, 1);
v_isSharedCheck_4567_ = !lean_is_exclusive(v_a_4432_);
if (v_isSharedCheck_4567_ == 0)
{
lean_object* v_unused_4568_; 
v_unused_4568_ = lean_ctor_get(v_a_4432_, 0);
lean_dec(v_unused_4568_);
v___x_4438_ = v_a_4432_;
v_isShared_4439_ = v_isSharedCheck_4567_;
goto v_resetjp_4437_;
}
else
{
lean_inc(v_snd_4436_);
lean_dec(v_a_4432_);
v___x_4438_ = lean_box(0);
v_isShared_4439_ = v_isSharedCheck_4567_;
goto v_resetjp_4437_;
}
v_resetjp_4437_:
{
lean_object* v___x_4440_; 
v___x_4440_ = lp_proofEnvironment_dumpName(v_name_4419_, v_a_4006_, v_snd_4436_);
if (lean_obj_tag(v___x_4440_) == 0)
{
lean_object* v_a_4441_; lean_object* v_fst_4442_; lean_object* v_snd_4443_; lean_object* v___x_4445_; uint8_t v_isShared_4446_; uint8_t v_isSharedCheck_4558_; 
v_a_4441_ = lean_ctor_get(v___x_4440_, 0);
lean_inc(v_a_4441_);
lean_dec_ref_known(v___x_4440_, 1);
v_fst_4442_ = lean_ctor_get(v_a_4441_, 0);
v_snd_4443_ = lean_ctor_get(v_a_4441_, 1);
v_isSharedCheck_4558_ = !lean_is_exclusive(v_a_4441_);
if (v_isSharedCheck_4558_ == 0)
{
v___x_4445_ = v_a_4441_;
v_isShared_4446_ = v_isSharedCheck_4558_;
goto v_resetjp_4444_;
}
else
{
lean_inc(v_snd_4443_);
lean_inc(v_fst_4442_);
lean_dec(v_a_4441_);
v___x_4445_ = lean_box(0);
v_isShared_4446_ = v_isSharedCheck_4558_;
goto v_resetjp_4444_;
}
v_resetjp_4444_:
{
lean_object* v___x_4447_; 
v___x_4447_ = lp_proofEnvironment_dumpUparams(v_levelParams_4420_, v_a_4006_, v_snd_4443_);
if (lean_obj_tag(v___x_4447_) == 0)
{
lean_object* v_a_4448_; lean_object* v_fst_4449_; lean_object* v_snd_4450_; lean_object* v___x_4452_; uint8_t v_isShared_4453_; uint8_t v_isSharedCheck_4549_; 
v_a_4448_ = lean_ctor_get(v___x_4447_, 0);
lean_inc(v_a_4448_);
lean_dec_ref_known(v___x_4447_, 1);
v_fst_4449_ = lean_ctor_get(v_a_4448_, 0);
v_snd_4450_ = lean_ctor_get(v_a_4448_, 1);
v_isSharedCheck_4549_ = !lean_is_exclusive(v_a_4448_);
if (v_isSharedCheck_4549_ == 0)
{
v___x_4452_ = v_a_4448_;
v_isShared_4453_ = v_isSharedCheck_4549_;
goto v_resetjp_4451_;
}
else
{
lean_inc(v_snd_4450_);
lean_inc(v_fst_4449_);
lean_dec(v_a_4448_);
v___x_4452_ = lean_box(0);
v_isShared_4453_ = v_isSharedCheck_4549_;
goto v_resetjp_4451_;
}
v_resetjp_4451_:
{
lean_object* v___x_4454_; 
v___x_4454_ = lp_proofEnvironment_dumpExpr(v_type_4421_, v_a_4006_, v_snd_4450_);
if (lean_obj_tag(v___x_4454_) == 0)
{
lean_object* v_a_4455_; lean_object* v_fst_4456_; lean_object* v_snd_4457_; lean_object* v___x_4459_; uint8_t v_isShared_4460_; uint8_t v_isSharedCheck_4540_; 
v_a_4455_ = lean_ctor_get(v___x_4454_, 0);
lean_inc(v_a_4455_);
lean_dec_ref_known(v___x_4454_, 1);
v_fst_4456_ = lean_ctor_get(v_a_4455_, 0);
v_snd_4457_ = lean_ctor_get(v_a_4455_, 1);
v_isSharedCheck_4540_ = !lean_is_exclusive(v_a_4455_);
if (v_isSharedCheck_4540_ == 0)
{
v___x_4459_ = v_a_4455_;
v_isShared_4460_ = v_isSharedCheck_4540_;
goto v_resetjp_4458_;
}
else
{
lean_inc(v_snd_4457_);
lean_inc(v_fst_4456_);
lean_dec(v_a_4455_);
v___x_4459_ = lean_box(0);
v_isShared_4460_ = v_isSharedCheck_4540_;
goto v_resetjp_4458_;
}
v_resetjp_4458_:
{
lean_object* v___x_4461_; 
v___x_4461_ = lp_proofEnvironment_dumpExpr(v_value_4417_, v_a_4006_, v_snd_4457_);
if (lean_obj_tag(v___x_4461_) == 0)
{
lean_object* v_a_4462_; lean_object* v_fst_4463_; lean_object* v_snd_4464_; lean_object* v___x_4466_; uint8_t v_isShared_4467_; uint8_t v_isSharedCheck_4531_; 
v_a_4462_ = lean_ctor_get(v___x_4461_, 0);
lean_inc(v_a_4462_);
lean_dec_ref_known(v___x_4461_, 1);
v_fst_4463_ = lean_ctor_get(v_a_4462_, 0);
v_snd_4464_ = lean_ctor_get(v_a_4462_, 1);
v_isSharedCheck_4531_ = !lean_is_exclusive(v_a_4462_);
if (v_isSharedCheck_4531_ == 0)
{
v___x_4466_ = v_a_4462_;
v_isShared_4467_ = v_isSharedCheck_4531_;
goto v_resetjp_4465_;
}
else
{
lean_inc(v_snd_4464_);
lean_inc(v_fst_4463_);
lean_dec(v_a_4462_);
v___x_4466_ = lean_box(0);
v_isShared_4467_ = v_isSharedCheck_4531_;
goto v_resetjp_4465_;
}
v_resetjp_4465_:
{
lean_object* v___x_4468_; 
v___x_4468_ = lp_proofEnvironment_dumpNames(v_all_4418_, v_a_4006_, v_snd_4464_);
if (lean_obj_tag(v___x_4468_) == 0)
{
lean_object* v_a_4469_; lean_object* v_fst_4470_; lean_object* v_snd_4471_; lean_object* v___x_4473_; uint8_t v_isShared_4474_; uint8_t v_isSharedCheck_4522_; 
v_a_4469_ = lean_ctor_get(v___x_4468_, 0);
lean_inc(v_a_4469_);
lean_dec_ref_known(v___x_4468_, 1);
v_fst_4470_ = lean_ctor_get(v_a_4469_, 0);
v_snd_4471_ = lean_ctor_get(v_a_4469_, 1);
v_isSharedCheck_4522_ = !lean_is_exclusive(v_a_4469_);
if (v_isSharedCheck_4522_ == 0)
{
v___x_4473_ = v_a_4469_;
v_isShared_4474_ = v_isSharedCheck_4522_;
goto v_resetjp_4472_;
}
else
{
lean_inc(v_snd_4471_);
lean_inc(v_fst_4470_);
lean_dec(v_a_4469_);
v___x_4473_ = lean_box(0);
v_isShared_4474_ = v_isSharedCheck_4522_;
goto v_resetjp_4472_;
}
v_resetjp_4472_:
{
lean_object* v___x_4475_; lean_object* v___x_4476_; lean_object* v___x_4477_; lean_object* v___x_4479_; 
v___x_4475_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__7));
v___x_4476_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_4477_ = l_Lean_JsonNumber_fromNat(v_fst_4442_);
if (v_isShared_4435_ == 0)
{
lean_ctor_set_tag(v___x_4434_, 2);
lean_ctor_set(v___x_4434_, 0, v___x_4477_);
v___x_4479_ = v___x_4434_;
goto v_reusejp_4478_;
}
else
{
lean_object* v_reuseFailAlloc_4521_; 
v_reuseFailAlloc_4521_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4521_, 0, v___x_4477_);
v___x_4479_ = v_reuseFailAlloc_4521_;
goto v_reusejp_4478_;
}
v_reusejp_4478_:
{
lean_object* v___x_4481_; 
if (v_isShared_4474_ == 0)
{
lean_ctor_set(v___x_4473_, 1, v___x_4479_);
lean_ctor_set(v___x_4473_, 0, v___x_4476_);
v___x_4481_ = v___x_4473_;
goto v_reusejp_4480_;
}
else
{
lean_object* v_reuseFailAlloc_4520_; 
v_reuseFailAlloc_4520_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4520_, 0, v___x_4476_);
lean_ctor_set(v_reuseFailAlloc_4520_, 1, v___x_4479_);
v___x_4481_ = v_reuseFailAlloc_4520_;
goto v_reusejp_4480_;
}
v_reusejp_4480_:
{
lean_object* v___x_4482_; lean_object* v___x_4484_; 
v___x_4482_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_4467_ == 0)
{
lean_ctor_set(v___x_4466_, 1, v_fst_4449_);
lean_ctor_set(v___x_4466_, 0, v___x_4482_);
v___x_4484_ = v___x_4466_;
goto v_reusejp_4483_;
}
else
{
lean_object* v_reuseFailAlloc_4519_; 
v_reuseFailAlloc_4519_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4519_, 0, v___x_4482_);
lean_ctor_set(v_reuseFailAlloc_4519_, 1, v_fst_4449_);
v___x_4484_ = v_reuseFailAlloc_4519_;
goto v_reusejp_4483_;
}
v_reusejp_4483_:
{
lean_object* v___x_4485_; lean_object* v___x_4486_; lean_object* v___x_4488_; 
v___x_4485_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_4486_ = l_Lean_JsonNumber_fromNat(v_fst_4456_);
if (v_isShared_4426_ == 0)
{
lean_ctor_set_tag(v___x_4425_, 2);
lean_ctor_set(v___x_4425_, 0, v___x_4486_);
v___x_4488_ = v___x_4425_;
goto v_reusejp_4487_;
}
else
{
lean_object* v_reuseFailAlloc_4518_; 
v_reuseFailAlloc_4518_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4518_, 0, v___x_4486_);
v___x_4488_ = v_reuseFailAlloc_4518_;
goto v_reusejp_4487_;
}
v_reusejp_4487_:
{
lean_object* v___x_4490_; 
if (v_isShared_4460_ == 0)
{
lean_ctor_set(v___x_4459_, 1, v___x_4488_);
lean_ctor_set(v___x_4459_, 0, v___x_4485_);
v___x_4490_ = v___x_4459_;
goto v_reusejp_4489_;
}
else
{
lean_object* v_reuseFailAlloc_4517_; 
v_reuseFailAlloc_4517_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4517_, 0, v___x_4485_);
lean_ctor_set(v_reuseFailAlloc_4517_, 1, v___x_4488_);
v___x_4490_ = v_reuseFailAlloc_4517_;
goto v_reusejp_4489_;
}
v_reusejp_4489_:
{
lean_object* v___x_4491_; lean_object* v___x_4492_; lean_object* v___x_4494_; 
v___x_4491_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__13));
v___x_4492_ = l_Lean_JsonNumber_fromNat(v_fst_4463_);
if (v_isShared_4415_ == 0)
{
lean_ctor_set(v___x_4414_, 0, v___x_4492_);
v___x_4494_ = v___x_4414_;
goto v_reusejp_4493_;
}
else
{
lean_object* v_reuseFailAlloc_4516_; 
v_reuseFailAlloc_4516_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4516_, 0, v___x_4492_);
v___x_4494_ = v_reuseFailAlloc_4516_;
goto v_reusejp_4493_;
}
v_reusejp_4493_:
{
lean_object* v___x_4496_; 
if (v_isShared_4453_ == 0)
{
lean_ctor_set(v___x_4452_, 1, v___x_4494_);
lean_ctor_set(v___x_4452_, 0, v___x_4491_);
v___x_4496_ = v___x_4452_;
goto v_reusejp_4495_;
}
else
{
lean_object* v_reuseFailAlloc_4515_; 
v_reuseFailAlloc_4515_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4515_, 0, v___x_4491_);
lean_ctor_set(v_reuseFailAlloc_4515_, 1, v___x_4494_);
v___x_4496_ = v_reuseFailAlloc_4515_;
goto v_reusejp_4495_;
}
v_reusejp_4495_:
{
lean_object* v___x_4497_; lean_object* v___x_4499_; 
v___x_4497_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1));
if (v_isShared_4446_ == 0)
{
lean_ctor_set(v___x_4445_, 1, v_fst_4470_);
lean_ctor_set(v___x_4445_, 0, v___x_4497_);
v___x_4499_ = v___x_4445_;
goto v_reusejp_4498_;
}
else
{
lean_object* v_reuseFailAlloc_4514_; 
v_reuseFailAlloc_4514_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4514_, 0, v___x_4497_);
lean_ctor_set(v_reuseFailAlloc_4514_, 1, v_fst_4470_);
v___x_4499_ = v_reuseFailAlloc_4514_;
goto v_reusejp_4498_;
}
v_reusejp_4498_:
{
lean_object* v___x_4500_; lean_object* v___x_4502_; 
v___x_4500_ = lean_box(0);
if (v_isShared_4430_ == 0)
{
lean_ctor_set_tag(v___x_4429_, 1);
lean_ctor_set(v___x_4429_, 1, v___x_4500_);
lean_ctor_set(v___x_4429_, 0, v___x_4499_);
v___x_4502_ = v___x_4429_;
goto v_reusejp_4501_;
}
else
{
lean_object* v_reuseFailAlloc_4513_; 
v_reuseFailAlloc_4513_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4513_, 0, v___x_4499_);
lean_ctor_set(v_reuseFailAlloc_4513_, 1, v___x_4500_);
v___x_4502_ = v_reuseFailAlloc_4513_;
goto v_reusejp_4501_;
}
v_reusejp_4501_:
{
lean_object* v___x_4503_; lean_object* v___x_4504_; lean_object* v___x_4505_; lean_object* v___x_4506_; lean_object* v___x_4507_; lean_object* v___x_4509_; 
v___x_4503_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4503_, 0, v___x_4496_);
lean_ctor_set(v___x_4503_, 1, v___x_4502_);
v___x_4504_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4504_, 0, v___x_4490_);
lean_ctor_set(v___x_4504_, 1, v___x_4503_);
v___x_4505_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4505_, 0, v___x_4484_);
lean_ctor_set(v___x_4505_, 1, v___x_4504_);
v___x_4506_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4506_, 0, v___x_4481_);
lean_ctor_set(v___x_4506_, 1, v___x_4505_);
v___x_4507_ = l_Lean_Json_mkObj(v___x_4506_);
lean_dec_ref_known(v___x_4506_, 2);
if (v_isShared_4439_ == 0)
{
lean_ctor_set(v___x_4438_, 1, v___x_4507_);
lean_ctor_set(v___x_4438_, 0, v___x_4475_);
v___x_4509_ = v___x_4438_;
goto v_reusejp_4508_;
}
else
{
lean_object* v_reuseFailAlloc_4512_; 
v_reuseFailAlloc_4512_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4512_, 0, v___x_4475_);
lean_ctor_set(v_reuseFailAlloc_4512_, 1, v___x_4507_);
v___x_4509_ = v_reuseFailAlloc_4512_;
goto v_reusejp_4508_;
}
v_reusejp_4508_:
{
lean_object* v___x_4510_; lean_object* v___x_4511_; 
v___x_4510_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4510_, 0, v___x_4509_);
lean_ctor_set(v___x_4510_, 1, v___x_4500_);
v___x_4511_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v___x_4510_, v_snd_4471_);
lean_dec_ref_known(v___x_4510_, 2);
return v___x_4511_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4523_; lean_object* v___x_4525_; uint8_t v_isShared_4526_; uint8_t v_isSharedCheck_4530_; 
lean_del_object(v___x_4466_);
lean_dec(v_fst_4463_);
lean_del_object(v___x_4459_);
lean_dec(v_fst_4456_);
lean_del_object(v___x_4452_);
lean_dec(v_fst_4449_);
lean_del_object(v___x_4445_);
lean_dec(v_fst_4442_);
lean_del_object(v___x_4438_);
lean_del_object(v___x_4434_);
lean_del_object(v___x_4429_);
lean_del_object(v___x_4425_);
lean_del_object(v___x_4414_);
v_a_4523_ = lean_ctor_get(v___x_4468_, 0);
v_isSharedCheck_4530_ = !lean_is_exclusive(v___x_4468_);
if (v_isSharedCheck_4530_ == 0)
{
v___x_4525_ = v___x_4468_;
v_isShared_4526_ = v_isSharedCheck_4530_;
goto v_resetjp_4524_;
}
else
{
lean_inc(v_a_4523_);
lean_dec(v___x_4468_);
v___x_4525_ = lean_box(0);
v_isShared_4526_ = v_isSharedCheck_4530_;
goto v_resetjp_4524_;
}
v_resetjp_4524_:
{
lean_object* v___x_4528_; 
if (v_isShared_4526_ == 0)
{
v___x_4528_ = v___x_4525_;
goto v_reusejp_4527_;
}
else
{
lean_object* v_reuseFailAlloc_4529_; 
v_reuseFailAlloc_4529_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4529_, 0, v_a_4523_);
v___x_4528_ = v_reuseFailAlloc_4529_;
goto v_reusejp_4527_;
}
v_reusejp_4527_:
{
return v___x_4528_;
}
}
}
}
}
else
{
lean_object* v_a_4532_; lean_object* v___x_4534_; uint8_t v_isShared_4535_; uint8_t v_isSharedCheck_4539_; 
lean_del_object(v___x_4459_);
lean_dec(v_fst_4456_);
lean_del_object(v___x_4452_);
lean_dec(v_fst_4449_);
lean_del_object(v___x_4445_);
lean_dec(v_fst_4442_);
lean_del_object(v___x_4438_);
lean_del_object(v___x_4434_);
lean_del_object(v___x_4429_);
lean_del_object(v___x_4425_);
lean_dec(v_all_4418_);
lean_del_object(v___x_4414_);
v_a_4532_ = lean_ctor_get(v___x_4461_, 0);
v_isSharedCheck_4539_ = !lean_is_exclusive(v___x_4461_);
if (v_isSharedCheck_4539_ == 0)
{
v___x_4534_ = v___x_4461_;
v_isShared_4535_ = v_isSharedCheck_4539_;
goto v_resetjp_4533_;
}
else
{
lean_inc(v_a_4532_);
lean_dec(v___x_4461_);
v___x_4534_ = lean_box(0);
v_isShared_4535_ = v_isSharedCheck_4539_;
goto v_resetjp_4533_;
}
v_resetjp_4533_:
{
lean_object* v___x_4537_; 
if (v_isShared_4535_ == 0)
{
v___x_4537_ = v___x_4534_;
goto v_reusejp_4536_;
}
else
{
lean_object* v_reuseFailAlloc_4538_; 
v_reuseFailAlloc_4538_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4538_, 0, v_a_4532_);
v___x_4537_ = v_reuseFailAlloc_4538_;
goto v_reusejp_4536_;
}
v_reusejp_4536_:
{
return v___x_4537_;
}
}
}
}
}
else
{
lean_object* v_a_4541_; lean_object* v___x_4543_; uint8_t v_isShared_4544_; uint8_t v_isSharedCheck_4548_; 
lean_del_object(v___x_4452_);
lean_dec(v_fst_4449_);
lean_del_object(v___x_4445_);
lean_dec(v_fst_4442_);
lean_del_object(v___x_4438_);
lean_del_object(v___x_4434_);
lean_del_object(v___x_4429_);
lean_del_object(v___x_4425_);
lean_dec(v_all_4418_);
lean_dec_ref(v_value_4417_);
lean_del_object(v___x_4414_);
v_a_4541_ = lean_ctor_get(v___x_4454_, 0);
v_isSharedCheck_4548_ = !lean_is_exclusive(v___x_4454_);
if (v_isSharedCheck_4548_ == 0)
{
v___x_4543_ = v___x_4454_;
v_isShared_4544_ = v_isSharedCheck_4548_;
goto v_resetjp_4542_;
}
else
{
lean_inc(v_a_4541_);
lean_dec(v___x_4454_);
v___x_4543_ = lean_box(0);
v_isShared_4544_ = v_isSharedCheck_4548_;
goto v_resetjp_4542_;
}
v_resetjp_4542_:
{
lean_object* v___x_4546_; 
if (v_isShared_4544_ == 0)
{
v___x_4546_ = v___x_4543_;
goto v_reusejp_4545_;
}
else
{
lean_object* v_reuseFailAlloc_4547_; 
v_reuseFailAlloc_4547_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4547_, 0, v_a_4541_);
v___x_4546_ = v_reuseFailAlloc_4547_;
goto v_reusejp_4545_;
}
v_reusejp_4545_:
{
return v___x_4546_;
}
}
}
}
}
else
{
lean_object* v_a_4550_; lean_object* v___x_4552_; uint8_t v_isShared_4553_; uint8_t v_isSharedCheck_4557_; 
lean_del_object(v___x_4445_);
lean_dec(v_fst_4442_);
lean_del_object(v___x_4438_);
lean_del_object(v___x_4434_);
lean_del_object(v___x_4429_);
lean_del_object(v___x_4425_);
lean_dec_ref(v_type_4421_);
lean_dec(v_all_4418_);
lean_dec_ref(v_value_4417_);
lean_del_object(v___x_4414_);
v_a_4550_ = lean_ctor_get(v___x_4447_, 0);
v_isSharedCheck_4557_ = !lean_is_exclusive(v___x_4447_);
if (v_isSharedCheck_4557_ == 0)
{
v___x_4552_ = v___x_4447_;
v_isShared_4553_ = v_isSharedCheck_4557_;
goto v_resetjp_4551_;
}
else
{
lean_inc(v_a_4550_);
lean_dec(v___x_4447_);
v___x_4552_ = lean_box(0);
v_isShared_4553_ = v_isSharedCheck_4557_;
goto v_resetjp_4551_;
}
v_resetjp_4551_:
{
lean_object* v___x_4555_; 
if (v_isShared_4553_ == 0)
{
v___x_4555_ = v___x_4552_;
goto v_reusejp_4554_;
}
else
{
lean_object* v_reuseFailAlloc_4556_; 
v_reuseFailAlloc_4556_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4556_, 0, v_a_4550_);
v___x_4555_ = v_reuseFailAlloc_4556_;
goto v_reusejp_4554_;
}
v_reusejp_4554_:
{
return v___x_4555_;
}
}
}
}
}
else
{
lean_object* v_a_4559_; lean_object* v___x_4561_; uint8_t v_isShared_4562_; uint8_t v_isSharedCheck_4566_; 
lean_del_object(v___x_4438_);
lean_del_object(v___x_4434_);
lean_del_object(v___x_4429_);
lean_del_object(v___x_4425_);
lean_dec_ref(v_type_4421_);
lean_dec(v_levelParams_4420_);
lean_dec(v_all_4418_);
lean_dec_ref(v_value_4417_);
lean_del_object(v___x_4414_);
v_a_4559_ = lean_ctor_get(v___x_4440_, 0);
v_isSharedCheck_4566_ = !lean_is_exclusive(v___x_4440_);
if (v_isSharedCheck_4566_ == 0)
{
v___x_4561_ = v___x_4440_;
v_isShared_4562_ = v_isSharedCheck_4566_;
goto v_resetjp_4560_;
}
else
{
lean_inc(v_a_4559_);
lean_dec(v___x_4440_);
v___x_4561_ = lean_box(0);
v_isShared_4562_ = v_isSharedCheck_4566_;
goto v_resetjp_4560_;
}
v_resetjp_4560_:
{
lean_object* v___x_4564_; 
if (v_isShared_4562_ == 0)
{
v___x_4564_ = v___x_4561_;
goto v_reusejp_4563_;
}
else
{
lean_object* v_reuseFailAlloc_4565_; 
v_reuseFailAlloc_4565_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4565_, 0, v_a_4559_);
v___x_4564_ = v_reuseFailAlloc_4565_;
goto v_reusejp_4563_;
}
v_reusejp_4563_:
{
return v___x_4564_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_4429_);
lean_del_object(v___x_4425_);
lean_dec_ref(v_type_4421_);
lean_dec(v_levelParams_4420_);
lean_dec(v_name_4419_);
lean_dec(v_all_4418_);
lean_dec_ref(v_value_4417_);
lean_del_object(v___x_4414_);
return v___x_4431_;
}
}
}
}
else
{
lean_dec_ref(v_type_4421_);
lean_dec(v_levelParams_4420_);
lean_dec(v_name_4419_);
lean_dec(v_all_4418_);
lean_dec_ref(v_value_4417_);
lean_del_object(v___x_4414_);
return v___x_4422_;
}
}
}
case 3:
{
lean_object* v_val_4574_; lean_object* v___x_4576_; uint8_t v_isShared_4577_; uint8_t v_isSharedCheck_4740_; 
v_val_4574_ = lean_ctor_get(v_val_4117_, 0);
v_isSharedCheck_4740_ = !lean_is_exclusive(v_val_4117_);
if (v_isSharedCheck_4740_ == 0)
{
v___x_4576_ = v_val_4117_;
v_isShared_4577_ = v_isSharedCheck_4740_;
goto v_resetjp_4575_;
}
else
{
lean_inc(v_val_4574_);
lean_dec(v_val_4117_);
v___x_4576_ = lean_box(0);
v_isShared_4577_ = v_isSharedCheck_4740_;
goto v_resetjp_4575_;
}
v_resetjp_4575_:
{
lean_object* v_toConstantVal_4578_; lean_object* v_value_4579_; uint8_t v_isUnsafe_4580_; lean_object* v_all_4581_; lean_object* v_name_4582_; lean_object* v_levelParams_4583_; lean_object* v_type_4584_; lean_object* v___x_4585_; 
v_toConstantVal_4578_ = lean_ctor_get(v_val_4574_, 0);
lean_inc_ref(v_toConstantVal_4578_);
v_value_4579_ = lean_ctor_get(v_val_4574_, 1);
lean_inc_ref(v_value_4579_);
v_isUnsafe_4580_ = lean_ctor_get_uint8(v_val_4574_, sizeof(void*)*3);
v_all_4581_ = lean_ctor_get(v_val_4574_, 2);
lean_inc(v_all_4581_);
lean_dec_ref(v_val_4574_);
v_name_4582_ = lean_ctor_get(v_toConstantVal_4578_, 0);
lean_inc(v_name_4582_);
v_levelParams_4583_ = lean_ctor_get(v_toConstantVal_4578_, 1);
lean_inc(v_levelParams_4583_);
v_type_4584_ = lean_ctor_get(v_toConstantVal_4578_, 2);
lean_inc_ref_n(v_type_4584_, 2);
lean_dec_ref(v_toConstantVal_4578_);
v___x_4585_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_type_4584_, v_a_4006_, v___x_4134_);
if (lean_obj_tag(v___x_4585_) == 0)
{
lean_object* v_a_4586_; lean_object* v___x_4588_; uint8_t v_isShared_4589_; uint8_t v_isSharedCheck_4739_; 
v_a_4586_ = lean_ctor_get(v___x_4585_, 0);
v_isSharedCheck_4739_ = !lean_is_exclusive(v___x_4585_);
if (v_isSharedCheck_4739_ == 0)
{
v___x_4588_ = v___x_4585_;
v_isShared_4589_ = v_isSharedCheck_4739_;
goto v_resetjp_4587_;
}
else
{
lean_inc(v_a_4586_);
lean_dec(v___x_4585_);
v___x_4588_ = lean_box(0);
v_isShared_4589_ = v_isSharedCheck_4739_;
goto v_resetjp_4587_;
}
v_resetjp_4587_:
{
lean_object* v_snd_4590_; lean_object* v___x_4592_; uint8_t v_isShared_4593_; uint8_t v_isSharedCheck_4737_; 
v_snd_4590_ = lean_ctor_get(v_a_4586_, 1);
v_isSharedCheck_4737_ = !lean_is_exclusive(v_a_4586_);
if (v_isSharedCheck_4737_ == 0)
{
lean_object* v_unused_4738_; 
v_unused_4738_ = lean_ctor_get(v_a_4586_, 0);
lean_dec(v_unused_4738_);
v___x_4592_ = v_a_4586_;
v_isShared_4593_ = v_isSharedCheck_4737_;
goto v_resetjp_4591_;
}
else
{
lean_inc(v_snd_4590_);
lean_dec(v_a_4586_);
v___x_4592_ = lean_box(0);
v_isShared_4593_ = v_isSharedCheck_4737_;
goto v_resetjp_4591_;
}
v_resetjp_4591_:
{
lean_object* v___x_4594_; 
lean_inc_ref(v_value_4579_);
v___x_4594_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_value_4579_, v_a_4006_, v_snd_4590_);
if (lean_obj_tag(v___x_4594_) == 0)
{
lean_object* v_a_4595_; lean_object* v___x_4597_; uint8_t v_isShared_4598_; uint8_t v_isSharedCheck_4736_; 
v_a_4595_ = lean_ctor_get(v___x_4594_, 0);
v_isSharedCheck_4736_ = !lean_is_exclusive(v___x_4594_);
if (v_isSharedCheck_4736_ == 0)
{
v___x_4597_ = v___x_4594_;
v_isShared_4598_ = v_isSharedCheck_4736_;
goto v_resetjp_4596_;
}
else
{
lean_inc(v_a_4595_);
lean_dec(v___x_4594_);
v___x_4597_ = lean_box(0);
v_isShared_4598_ = v_isSharedCheck_4736_;
goto v_resetjp_4596_;
}
v_resetjp_4596_:
{
lean_object* v_snd_4599_; lean_object* v___x_4601_; uint8_t v_isShared_4602_; uint8_t v_isSharedCheck_4734_; 
v_snd_4599_ = lean_ctor_get(v_a_4595_, 1);
v_isSharedCheck_4734_ = !lean_is_exclusive(v_a_4595_);
if (v_isSharedCheck_4734_ == 0)
{
lean_object* v_unused_4735_; 
v_unused_4735_ = lean_ctor_get(v_a_4595_, 0);
lean_dec(v_unused_4735_);
v___x_4601_ = v_a_4595_;
v_isShared_4602_ = v_isSharedCheck_4734_;
goto v_resetjp_4600_;
}
else
{
lean_inc(v_snd_4599_);
lean_dec(v_a_4595_);
v___x_4601_ = lean_box(0);
v_isShared_4602_ = v_isSharedCheck_4734_;
goto v_resetjp_4600_;
}
v_resetjp_4600_:
{
lean_object* v___x_4603_; 
v___x_4603_ = lp_proofEnvironment_dumpName(v_name_4582_, v_a_4006_, v_snd_4599_);
if (lean_obj_tag(v___x_4603_) == 0)
{
lean_object* v_a_4604_; lean_object* v_fst_4605_; lean_object* v_snd_4606_; lean_object* v___x_4608_; uint8_t v_isShared_4609_; uint8_t v_isSharedCheck_4725_; 
v_a_4604_ = lean_ctor_get(v___x_4603_, 0);
lean_inc(v_a_4604_);
lean_dec_ref_known(v___x_4603_, 1);
v_fst_4605_ = lean_ctor_get(v_a_4604_, 0);
v_snd_4606_ = lean_ctor_get(v_a_4604_, 1);
v_isSharedCheck_4725_ = !lean_is_exclusive(v_a_4604_);
if (v_isSharedCheck_4725_ == 0)
{
v___x_4608_ = v_a_4604_;
v_isShared_4609_ = v_isSharedCheck_4725_;
goto v_resetjp_4607_;
}
else
{
lean_inc(v_snd_4606_);
lean_inc(v_fst_4605_);
lean_dec(v_a_4604_);
v___x_4608_ = lean_box(0);
v_isShared_4609_ = v_isSharedCheck_4725_;
goto v_resetjp_4607_;
}
v_resetjp_4607_:
{
lean_object* v___x_4610_; 
v___x_4610_ = lp_proofEnvironment_dumpUparams(v_levelParams_4583_, v_a_4006_, v_snd_4606_);
if (lean_obj_tag(v___x_4610_) == 0)
{
lean_object* v_a_4611_; lean_object* v_fst_4612_; lean_object* v_snd_4613_; lean_object* v___x_4615_; uint8_t v_isShared_4616_; uint8_t v_isSharedCheck_4716_; 
v_a_4611_ = lean_ctor_get(v___x_4610_, 0);
lean_inc(v_a_4611_);
lean_dec_ref_known(v___x_4610_, 1);
v_fst_4612_ = lean_ctor_get(v_a_4611_, 0);
v_snd_4613_ = lean_ctor_get(v_a_4611_, 1);
v_isSharedCheck_4716_ = !lean_is_exclusive(v_a_4611_);
if (v_isSharedCheck_4716_ == 0)
{
v___x_4615_ = v_a_4611_;
v_isShared_4616_ = v_isSharedCheck_4716_;
goto v_resetjp_4614_;
}
else
{
lean_inc(v_snd_4613_);
lean_inc(v_fst_4612_);
lean_dec(v_a_4611_);
v___x_4615_ = lean_box(0);
v_isShared_4616_ = v_isSharedCheck_4716_;
goto v_resetjp_4614_;
}
v_resetjp_4614_:
{
lean_object* v___x_4617_; 
v___x_4617_ = lp_proofEnvironment_dumpExpr(v_type_4584_, v_a_4006_, v_snd_4613_);
if (lean_obj_tag(v___x_4617_) == 0)
{
lean_object* v_a_4618_; lean_object* v_fst_4619_; lean_object* v_snd_4620_; lean_object* v___x_4622_; uint8_t v_isShared_4623_; uint8_t v_isSharedCheck_4707_; 
v_a_4618_ = lean_ctor_get(v___x_4617_, 0);
lean_inc(v_a_4618_);
lean_dec_ref_known(v___x_4617_, 1);
v_fst_4619_ = lean_ctor_get(v_a_4618_, 0);
v_snd_4620_ = lean_ctor_get(v_a_4618_, 1);
v_isSharedCheck_4707_ = !lean_is_exclusive(v_a_4618_);
if (v_isSharedCheck_4707_ == 0)
{
v___x_4622_ = v_a_4618_;
v_isShared_4623_ = v_isSharedCheck_4707_;
goto v_resetjp_4621_;
}
else
{
lean_inc(v_snd_4620_);
lean_inc(v_fst_4619_);
lean_dec(v_a_4618_);
v___x_4622_ = lean_box(0);
v_isShared_4623_ = v_isSharedCheck_4707_;
goto v_resetjp_4621_;
}
v_resetjp_4621_:
{
lean_object* v___x_4624_; 
v___x_4624_ = lp_proofEnvironment_dumpExpr(v_value_4579_, v_a_4006_, v_snd_4620_);
if (lean_obj_tag(v___x_4624_) == 0)
{
lean_object* v_a_4625_; lean_object* v_fst_4626_; lean_object* v_snd_4627_; lean_object* v___x_4629_; uint8_t v_isShared_4630_; uint8_t v_isSharedCheck_4698_; 
v_a_4625_ = lean_ctor_get(v___x_4624_, 0);
lean_inc(v_a_4625_);
lean_dec_ref_known(v___x_4624_, 1);
v_fst_4626_ = lean_ctor_get(v_a_4625_, 0);
v_snd_4627_ = lean_ctor_get(v_a_4625_, 1);
v_isSharedCheck_4698_ = !lean_is_exclusive(v_a_4625_);
if (v_isSharedCheck_4698_ == 0)
{
v___x_4629_ = v_a_4625_;
v_isShared_4630_ = v_isSharedCheck_4698_;
goto v_resetjp_4628_;
}
else
{
lean_inc(v_snd_4627_);
lean_inc(v_fst_4626_);
lean_dec(v_a_4625_);
v___x_4629_ = lean_box(0);
v_isShared_4630_ = v_isSharedCheck_4698_;
goto v_resetjp_4628_;
}
v_resetjp_4628_:
{
lean_object* v___x_4631_; 
v___x_4631_ = lp_proofEnvironment_dumpNames(v_all_4581_, v_a_4006_, v_snd_4627_);
if (lean_obj_tag(v___x_4631_) == 0)
{
lean_object* v_a_4632_; lean_object* v_fst_4633_; lean_object* v_snd_4634_; lean_object* v___x_4636_; uint8_t v_isShared_4637_; uint8_t v_isSharedCheck_4689_; 
v_a_4632_ = lean_ctor_get(v___x_4631_, 0);
lean_inc(v_a_4632_);
lean_dec_ref_known(v___x_4631_, 1);
v_fst_4633_ = lean_ctor_get(v_a_4632_, 0);
v_snd_4634_ = lean_ctor_get(v_a_4632_, 1);
v_isSharedCheck_4689_ = !lean_is_exclusive(v_a_4632_);
if (v_isSharedCheck_4689_ == 0)
{
v___x_4636_ = v_a_4632_;
v_isShared_4637_ = v_isSharedCheck_4689_;
goto v_resetjp_4635_;
}
else
{
lean_inc(v_snd_4634_);
lean_inc(v_fst_4633_);
lean_dec(v_a_4632_);
v___x_4636_ = lean_box(0);
v_isShared_4637_ = v_isSharedCheck_4689_;
goto v_resetjp_4635_;
}
v_resetjp_4635_:
{
lean_object* v___x_4638_; lean_object* v___x_4639_; lean_object* v___x_4640_; lean_object* v___x_4642_; 
v___x_4638_ = ((lean_object*)(lp_proofEnvironment_Lean_ReducibilityHints_toJson___closed__0));
v___x_4639_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__0));
v___x_4640_ = l_Lean_JsonNumber_fromNat(v_fst_4605_);
if (v_isShared_4598_ == 0)
{
lean_ctor_set_tag(v___x_4597_, 2);
lean_ctor_set(v___x_4597_, 0, v___x_4640_);
v___x_4642_ = v___x_4597_;
goto v_reusejp_4641_;
}
else
{
lean_object* v_reuseFailAlloc_4688_; 
v_reuseFailAlloc_4688_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4688_, 0, v___x_4640_);
v___x_4642_ = v_reuseFailAlloc_4688_;
goto v_reusejp_4641_;
}
v_reusejp_4641_:
{
lean_object* v___x_4644_; 
if (v_isShared_4637_ == 0)
{
lean_ctor_set(v___x_4636_, 1, v___x_4642_);
lean_ctor_set(v___x_4636_, 0, v___x_4639_);
v___x_4644_ = v___x_4636_;
goto v_reusejp_4643_;
}
else
{
lean_object* v_reuseFailAlloc_4687_; 
v_reuseFailAlloc_4687_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4687_, 0, v___x_4639_);
lean_ctor_set(v_reuseFailAlloc_4687_, 1, v___x_4642_);
v___x_4644_ = v_reuseFailAlloc_4687_;
goto v_reusejp_4643_;
}
v_reusejp_4643_:
{
lean_object* v___x_4645_; lean_object* v___x_4647_; 
v___x_4645_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__1));
if (v_isShared_4630_ == 0)
{
lean_ctor_set(v___x_4629_, 1, v_fst_4612_);
lean_ctor_set(v___x_4629_, 0, v___x_4645_);
v___x_4647_ = v___x_4629_;
goto v_reusejp_4646_;
}
else
{
lean_object* v_reuseFailAlloc_4686_; 
v_reuseFailAlloc_4686_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4686_, 0, v___x_4645_);
lean_ctor_set(v_reuseFailAlloc_4686_, 1, v_fst_4612_);
v___x_4647_ = v_reuseFailAlloc_4686_;
goto v_reusejp_4646_;
}
v_reusejp_4646_:
{
lean_object* v___x_4648_; lean_object* v___x_4649_; lean_object* v___x_4651_; 
v___x_4648_ = ((lean_object*)(lp_proofEnvironment_Lean_QuotKind_toJson___closed__0));
v___x_4649_ = l_Lean_JsonNumber_fromNat(v_fst_4619_);
if (v_isShared_4589_ == 0)
{
lean_ctor_set_tag(v___x_4588_, 2);
lean_ctor_set(v___x_4588_, 0, v___x_4649_);
v___x_4651_ = v___x_4588_;
goto v_reusejp_4650_;
}
else
{
lean_object* v_reuseFailAlloc_4685_; 
v_reuseFailAlloc_4685_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4685_, 0, v___x_4649_);
v___x_4651_ = v_reuseFailAlloc_4685_;
goto v_reusejp_4650_;
}
v_reusejp_4650_:
{
lean_object* v___x_4653_; 
if (v_isShared_4623_ == 0)
{
lean_ctor_set(v___x_4622_, 1, v___x_4651_);
lean_ctor_set(v___x_4622_, 0, v___x_4648_);
v___x_4653_ = v___x_4622_;
goto v_reusejp_4652_;
}
else
{
lean_object* v_reuseFailAlloc_4684_; 
v_reuseFailAlloc_4684_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4684_, 0, v___x_4648_);
lean_ctor_set(v_reuseFailAlloc_4684_, 1, v___x_4651_);
v___x_4653_ = v_reuseFailAlloc_4684_;
goto v_reusejp_4652_;
}
v_reusejp_4652_:
{
lean_object* v___x_4654_; lean_object* v___x_4655_; lean_object* v___x_4657_; 
v___x_4654_ = ((lean_object*)(lp_proofEnvironment_dumpExprAux___closed__13));
v___x_4655_ = l_Lean_JsonNumber_fromNat(v_fst_4626_);
if (v_isShared_4577_ == 0)
{
lean_ctor_set_tag(v___x_4576_, 2);
lean_ctor_set(v___x_4576_, 0, v___x_4655_);
v___x_4657_ = v___x_4576_;
goto v_reusejp_4656_;
}
else
{
lean_object* v_reuseFailAlloc_4683_; 
v_reuseFailAlloc_4683_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4683_, 0, v___x_4655_);
v___x_4657_ = v_reuseFailAlloc_4683_;
goto v_reusejp_4656_;
}
v_reusejp_4656_:
{
lean_object* v___x_4659_; 
if (v_isShared_4616_ == 0)
{
lean_ctor_set(v___x_4615_, 1, v___x_4657_);
lean_ctor_set(v___x_4615_, 0, v___x_4654_);
v___x_4659_ = v___x_4615_;
goto v_reusejp_4658_;
}
else
{
lean_object* v_reuseFailAlloc_4682_; 
v_reuseFailAlloc_4682_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4682_, 0, v___x_4654_);
lean_ctor_set(v_reuseFailAlloc_4682_, 1, v___x_4657_);
v___x_4659_ = v_reuseFailAlloc_4682_;
goto v_reusejp_4658_;
}
v_reusejp_4658_:
{
lean_object* v___x_4660_; lean_object* v___x_4662_; 
v___x_4660_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__1));
if (v_isShared_4609_ == 0)
{
lean_ctor_set(v___x_4608_, 1, v_fst_4633_);
lean_ctor_set(v___x_4608_, 0, v___x_4660_);
v___x_4662_ = v___x_4608_;
goto v_reusejp_4661_;
}
else
{
lean_object* v_reuseFailAlloc_4681_; 
v_reuseFailAlloc_4681_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4681_, 0, v___x_4660_);
lean_ctor_set(v_reuseFailAlloc_4681_, 1, v_fst_4633_);
v___x_4662_ = v_reuseFailAlloc_4681_;
goto v_reusejp_4661_;
}
v_reusejp_4661_:
{
lean_object* v___x_4663_; lean_object* v___x_4664_; lean_object* v___x_4666_; 
v___x_4663_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___closed__6));
v___x_4664_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_4664_, 0, v_isUnsafe_4580_);
if (v_isShared_4602_ == 0)
{
lean_ctor_set(v___x_4601_, 1, v___x_4664_);
lean_ctor_set(v___x_4601_, 0, v___x_4663_);
v___x_4666_ = v___x_4601_;
goto v_reusejp_4665_;
}
else
{
lean_object* v_reuseFailAlloc_4680_; 
v_reuseFailAlloc_4680_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4680_, 0, v___x_4663_);
lean_ctor_set(v_reuseFailAlloc_4680_, 1, v___x_4664_);
v___x_4666_ = v_reuseFailAlloc_4680_;
goto v_reusejp_4665_;
}
v_reusejp_4665_:
{
lean_object* v___x_4667_; lean_object* v___x_4668_; lean_object* v___x_4669_; lean_object* v___x_4670_; lean_object* v___x_4671_; lean_object* v___x_4672_; lean_object* v___x_4673_; lean_object* v___x_4674_; lean_object* v___x_4676_; 
v___x_4667_ = lean_box(0);
v___x_4668_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4668_, 0, v___x_4666_);
lean_ctor_set(v___x_4668_, 1, v___x_4667_);
v___x_4669_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4669_, 0, v___x_4662_);
lean_ctor_set(v___x_4669_, 1, v___x_4668_);
v___x_4670_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4670_, 0, v___x_4659_);
lean_ctor_set(v___x_4670_, 1, v___x_4669_);
v___x_4671_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4671_, 0, v___x_4653_);
lean_ctor_set(v___x_4671_, 1, v___x_4670_);
v___x_4672_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4672_, 0, v___x_4647_);
lean_ctor_set(v___x_4672_, 1, v___x_4671_);
v___x_4673_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4673_, 0, v___x_4644_);
lean_ctor_set(v___x_4673_, 1, v___x_4672_);
v___x_4674_ = l_Lean_Json_mkObj(v___x_4673_);
lean_dec_ref_known(v___x_4673_, 2);
if (v_isShared_4593_ == 0)
{
lean_ctor_set(v___x_4592_, 1, v___x_4674_);
lean_ctor_set(v___x_4592_, 0, v___x_4638_);
v___x_4676_ = v___x_4592_;
goto v_reusejp_4675_;
}
else
{
lean_object* v_reuseFailAlloc_4679_; 
v_reuseFailAlloc_4679_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4679_, 0, v___x_4638_);
lean_ctor_set(v_reuseFailAlloc_4679_, 1, v___x_4674_);
v___x_4676_ = v_reuseFailAlloc_4679_;
goto v_reusejp_4675_;
}
v_reusejp_4675_:
{
lean_object* v___x_4677_; lean_object* v___x_4678_; 
v___x_4677_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4677_, 0, v___x_4676_);
lean_ctor_set(v___x_4677_, 1, v___x_4667_);
v___x_4678_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v___x_4677_, v_snd_4634_);
lean_dec_ref_known(v___x_4677_, 2);
return v___x_4678_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_4690_; lean_object* v___x_4692_; uint8_t v_isShared_4693_; uint8_t v_isSharedCheck_4697_; 
lean_del_object(v___x_4629_);
lean_dec(v_fst_4626_);
lean_del_object(v___x_4622_);
lean_dec(v_fst_4619_);
lean_del_object(v___x_4615_);
lean_dec(v_fst_4612_);
lean_del_object(v___x_4608_);
lean_dec(v_fst_4605_);
lean_del_object(v___x_4601_);
lean_del_object(v___x_4597_);
lean_del_object(v___x_4592_);
lean_del_object(v___x_4588_);
lean_del_object(v___x_4576_);
v_a_4690_ = lean_ctor_get(v___x_4631_, 0);
v_isSharedCheck_4697_ = !lean_is_exclusive(v___x_4631_);
if (v_isSharedCheck_4697_ == 0)
{
v___x_4692_ = v___x_4631_;
v_isShared_4693_ = v_isSharedCheck_4697_;
goto v_resetjp_4691_;
}
else
{
lean_inc(v_a_4690_);
lean_dec(v___x_4631_);
v___x_4692_ = lean_box(0);
v_isShared_4693_ = v_isSharedCheck_4697_;
goto v_resetjp_4691_;
}
v_resetjp_4691_:
{
lean_object* v___x_4695_; 
if (v_isShared_4693_ == 0)
{
v___x_4695_ = v___x_4692_;
goto v_reusejp_4694_;
}
else
{
lean_object* v_reuseFailAlloc_4696_; 
v_reuseFailAlloc_4696_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4696_, 0, v_a_4690_);
v___x_4695_ = v_reuseFailAlloc_4696_;
goto v_reusejp_4694_;
}
v_reusejp_4694_:
{
return v___x_4695_;
}
}
}
}
}
else
{
lean_object* v_a_4699_; lean_object* v___x_4701_; uint8_t v_isShared_4702_; uint8_t v_isSharedCheck_4706_; 
lean_del_object(v___x_4622_);
lean_dec(v_fst_4619_);
lean_del_object(v___x_4615_);
lean_dec(v_fst_4612_);
lean_del_object(v___x_4608_);
lean_dec(v_fst_4605_);
lean_del_object(v___x_4601_);
lean_del_object(v___x_4597_);
lean_del_object(v___x_4592_);
lean_del_object(v___x_4588_);
lean_dec(v_all_4581_);
lean_del_object(v___x_4576_);
v_a_4699_ = lean_ctor_get(v___x_4624_, 0);
v_isSharedCheck_4706_ = !lean_is_exclusive(v___x_4624_);
if (v_isSharedCheck_4706_ == 0)
{
v___x_4701_ = v___x_4624_;
v_isShared_4702_ = v_isSharedCheck_4706_;
goto v_resetjp_4700_;
}
else
{
lean_inc(v_a_4699_);
lean_dec(v___x_4624_);
v___x_4701_ = lean_box(0);
v_isShared_4702_ = v_isSharedCheck_4706_;
goto v_resetjp_4700_;
}
v_resetjp_4700_:
{
lean_object* v___x_4704_; 
if (v_isShared_4702_ == 0)
{
v___x_4704_ = v___x_4701_;
goto v_reusejp_4703_;
}
else
{
lean_object* v_reuseFailAlloc_4705_; 
v_reuseFailAlloc_4705_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4705_, 0, v_a_4699_);
v___x_4704_ = v_reuseFailAlloc_4705_;
goto v_reusejp_4703_;
}
v_reusejp_4703_:
{
return v___x_4704_;
}
}
}
}
}
else
{
lean_object* v_a_4708_; lean_object* v___x_4710_; uint8_t v_isShared_4711_; uint8_t v_isSharedCheck_4715_; 
lean_del_object(v___x_4615_);
lean_dec(v_fst_4612_);
lean_del_object(v___x_4608_);
lean_dec(v_fst_4605_);
lean_del_object(v___x_4601_);
lean_del_object(v___x_4597_);
lean_del_object(v___x_4592_);
lean_del_object(v___x_4588_);
lean_dec(v_all_4581_);
lean_dec_ref(v_value_4579_);
lean_del_object(v___x_4576_);
v_a_4708_ = lean_ctor_get(v___x_4617_, 0);
v_isSharedCheck_4715_ = !lean_is_exclusive(v___x_4617_);
if (v_isSharedCheck_4715_ == 0)
{
v___x_4710_ = v___x_4617_;
v_isShared_4711_ = v_isSharedCheck_4715_;
goto v_resetjp_4709_;
}
else
{
lean_inc(v_a_4708_);
lean_dec(v___x_4617_);
v___x_4710_ = lean_box(0);
v_isShared_4711_ = v_isSharedCheck_4715_;
goto v_resetjp_4709_;
}
v_resetjp_4709_:
{
lean_object* v___x_4713_; 
if (v_isShared_4711_ == 0)
{
v___x_4713_ = v___x_4710_;
goto v_reusejp_4712_;
}
else
{
lean_object* v_reuseFailAlloc_4714_; 
v_reuseFailAlloc_4714_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4714_, 0, v_a_4708_);
v___x_4713_ = v_reuseFailAlloc_4714_;
goto v_reusejp_4712_;
}
v_reusejp_4712_:
{
return v___x_4713_;
}
}
}
}
}
else
{
lean_object* v_a_4717_; lean_object* v___x_4719_; uint8_t v_isShared_4720_; uint8_t v_isSharedCheck_4724_; 
lean_del_object(v___x_4608_);
lean_dec(v_fst_4605_);
lean_del_object(v___x_4601_);
lean_del_object(v___x_4597_);
lean_del_object(v___x_4592_);
lean_del_object(v___x_4588_);
lean_dec_ref(v_type_4584_);
lean_dec(v_all_4581_);
lean_dec_ref(v_value_4579_);
lean_del_object(v___x_4576_);
v_a_4717_ = lean_ctor_get(v___x_4610_, 0);
v_isSharedCheck_4724_ = !lean_is_exclusive(v___x_4610_);
if (v_isSharedCheck_4724_ == 0)
{
v___x_4719_ = v___x_4610_;
v_isShared_4720_ = v_isSharedCheck_4724_;
goto v_resetjp_4718_;
}
else
{
lean_inc(v_a_4717_);
lean_dec(v___x_4610_);
v___x_4719_ = lean_box(0);
v_isShared_4720_ = v_isSharedCheck_4724_;
goto v_resetjp_4718_;
}
v_resetjp_4718_:
{
lean_object* v___x_4722_; 
if (v_isShared_4720_ == 0)
{
v___x_4722_ = v___x_4719_;
goto v_reusejp_4721_;
}
else
{
lean_object* v_reuseFailAlloc_4723_; 
v_reuseFailAlloc_4723_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4723_, 0, v_a_4717_);
v___x_4722_ = v_reuseFailAlloc_4723_;
goto v_reusejp_4721_;
}
v_reusejp_4721_:
{
return v___x_4722_;
}
}
}
}
}
else
{
lean_object* v_a_4726_; lean_object* v___x_4728_; uint8_t v_isShared_4729_; uint8_t v_isSharedCheck_4733_; 
lean_del_object(v___x_4601_);
lean_del_object(v___x_4597_);
lean_del_object(v___x_4592_);
lean_del_object(v___x_4588_);
lean_dec_ref(v_type_4584_);
lean_dec(v_levelParams_4583_);
lean_dec(v_all_4581_);
lean_dec_ref(v_value_4579_);
lean_del_object(v___x_4576_);
v_a_4726_ = lean_ctor_get(v___x_4603_, 0);
v_isSharedCheck_4733_ = !lean_is_exclusive(v___x_4603_);
if (v_isSharedCheck_4733_ == 0)
{
v___x_4728_ = v___x_4603_;
v_isShared_4729_ = v_isSharedCheck_4733_;
goto v_resetjp_4727_;
}
else
{
lean_inc(v_a_4726_);
lean_dec(v___x_4603_);
v___x_4728_ = lean_box(0);
v_isShared_4729_ = v_isSharedCheck_4733_;
goto v_resetjp_4727_;
}
v_resetjp_4727_:
{
lean_object* v___x_4731_; 
if (v_isShared_4729_ == 0)
{
v___x_4731_ = v___x_4728_;
goto v_reusejp_4730_;
}
else
{
lean_object* v_reuseFailAlloc_4732_; 
v_reuseFailAlloc_4732_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4732_, 0, v_a_4726_);
v___x_4731_ = v_reuseFailAlloc_4732_;
goto v_reusejp_4730_;
}
v_reusejp_4730_:
{
return v___x_4731_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_4592_);
lean_del_object(v___x_4588_);
lean_dec_ref(v_type_4584_);
lean_dec(v_levelParams_4583_);
lean_dec(v_name_4582_);
lean_dec(v_all_4581_);
lean_dec_ref(v_value_4579_);
lean_del_object(v___x_4576_);
return v___x_4594_;
}
}
}
}
else
{
lean_dec_ref(v_type_4584_);
lean_dec(v_levelParams_4583_);
lean_dec(v_name_4582_);
lean_dec(v_all_4581_);
lean_dec_ref(v_value_4579_);
lean_del_object(v___x_4576_);
return v___x_4585_;
}
}
}
case 4:
{
lean_object* v___x_4741_; lean_object* v___x_4742_; 
lean_dec_ref_known(v_val_4117_, 1);
v___x_4741_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__9));
v___x_4742_ = lp_proofEnvironment_dumpConstant(v___x_4741_, v_a_4006_, v___x_4134_);
if (lean_obj_tag(v___x_4742_) == 0)
{
lean_object* v_a_4743_; lean_object* v_snd_4744_; lean_object* v___x_4745_; lean_object* v___x_4746_; lean_object* v___x_4747_; lean_object* v___x_4748_; 
v_a_4743_ = lean_ctor_get(v___x_4742_, 0);
lean_inc(v_a_4743_);
lean_dec_ref_known(v___x_4742_, 1);
v_snd_4744_ = lean_ctor_get(v_a_4743_, 1);
lean_inc(v_snd_4744_);
lean_dec(v_a_4743_);
v___x_4745_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__19));
v___x_4746_ = lean_box(0);
v___x_4747_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__0));
v___x_4748_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg(v___x_4128_, v___x_4745_, v___x_4747_, v_a_4006_, v_snd_4744_);
if (lean_obj_tag(v___x_4748_) == 0)
{
lean_object* v_a_4749_; lean_object* v___x_4751_; uint8_t v_isShared_4752_; uint8_t v_isSharedCheck_4775_; 
v_a_4749_ = lean_ctor_get(v___x_4748_, 0);
v_isSharedCheck_4775_ = !lean_is_exclusive(v___x_4748_);
if (v_isSharedCheck_4775_ == 0)
{
v___x_4751_ = v___x_4748_;
v_isShared_4752_ = v_isSharedCheck_4775_;
goto v_resetjp_4750_;
}
else
{
lean_inc(v_a_4749_);
lean_dec(v___x_4748_);
v___x_4751_ = lean_box(0);
v_isShared_4752_ = v_isSharedCheck_4775_;
goto v_resetjp_4750_;
}
v_resetjp_4750_:
{
lean_object* v_fst_4753_; lean_object* v_fst_4754_; lean_object* v___x_4756_; uint8_t v_isShared_4757_; uint8_t v_isSharedCheck_4773_; 
v_fst_4753_ = lean_ctor_get(v_a_4749_, 0);
lean_inc(v_fst_4753_);
v_fst_4754_ = lean_ctor_get(v_fst_4753_, 0);
v_isSharedCheck_4773_ = !lean_is_exclusive(v_fst_4753_);
if (v_isSharedCheck_4773_ == 0)
{
lean_object* v_unused_4774_; 
v_unused_4774_ = lean_ctor_get(v_fst_4753_, 1);
lean_dec(v_unused_4774_);
v___x_4756_ = v_fst_4753_;
v_isShared_4757_ = v_isSharedCheck_4773_;
goto v_resetjp_4755_;
}
else
{
lean_inc(v_fst_4754_);
lean_dec(v_fst_4753_);
v___x_4756_ = lean_box(0);
v_isShared_4757_ = v_isSharedCheck_4773_;
goto v_resetjp_4755_;
}
v_resetjp_4755_:
{
if (lean_obj_tag(v_fst_4754_) == 0)
{
lean_object* v_snd_4758_; lean_object* v___x_4760_; 
v_snd_4758_ = lean_ctor_get(v_a_4749_, 1);
lean_inc(v_snd_4758_);
lean_dec(v_a_4749_);
if (v_isShared_4757_ == 0)
{
lean_ctor_set(v___x_4756_, 1, v_snd_4758_);
lean_ctor_set(v___x_4756_, 0, v___x_4746_);
v___x_4760_ = v___x_4756_;
goto v_reusejp_4759_;
}
else
{
lean_object* v_reuseFailAlloc_4764_; 
v_reuseFailAlloc_4764_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4764_, 0, v___x_4746_);
lean_ctor_set(v_reuseFailAlloc_4764_, 1, v_snd_4758_);
v___x_4760_ = v_reuseFailAlloc_4764_;
goto v_reusejp_4759_;
}
v_reusejp_4759_:
{
lean_object* v___x_4762_; 
if (v_isShared_4752_ == 0)
{
lean_ctor_set(v___x_4751_, 0, v___x_4760_);
v___x_4762_ = v___x_4751_;
goto v_reusejp_4761_;
}
else
{
lean_object* v_reuseFailAlloc_4763_; 
v_reuseFailAlloc_4763_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4763_, 0, v___x_4760_);
v___x_4762_ = v_reuseFailAlloc_4763_;
goto v_reusejp_4761_;
}
v_reusejp_4761_:
{
return v___x_4762_;
}
}
}
else
{
lean_object* v_snd_4765_; lean_object* v_val_4766_; lean_object* v___x_4768_; 
v_snd_4765_ = lean_ctor_get(v_a_4749_, 1);
lean_inc(v_snd_4765_);
lean_dec(v_a_4749_);
v_val_4766_ = lean_ctor_get(v_fst_4754_, 0);
lean_inc(v_val_4766_);
lean_dec_ref_known(v_fst_4754_, 1);
if (v_isShared_4757_ == 0)
{
lean_ctor_set(v___x_4756_, 1, v_snd_4765_);
lean_ctor_set(v___x_4756_, 0, v_val_4766_);
v___x_4768_ = v___x_4756_;
goto v_reusejp_4767_;
}
else
{
lean_object* v_reuseFailAlloc_4772_; 
v_reuseFailAlloc_4772_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4772_, 0, v_val_4766_);
lean_ctor_set(v_reuseFailAlloc_4772_, 1, v_snd_4765_);
v___x_4768_ = v_reuseFailAlloc_4772_;
goto v_reusejp_4767_;
}
v_reusejp_4767_:
{
lean_object* v___x_4770_; 
if (v_isShared_4752_ == 0)
{
lean_ctor_set(v___x_4751_, 0, v___x_4768_);
v___x_4770_ = v___x_4751_;
goto v_reusejp_4769_;
}
else
{
lean_object* v_reuseFailAlloc_4771_; 
v_reuseFailAlloc_4771_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4771_, 0, v___x_4768_);
v___x_4770_ = v_reuseFailAlloc_4771_;
goto v_reusejp_4769_;
}
v_reusejp_4769_:
{
return v___x_4770_;
}
}
}
}
}
}
else
{
lean_object* v_a_4776_; lean_object* v___x_4778_; uint8_t v_isShared_4779_; uint8_t v_isSharedCheck_4783_; 
v_a_4776_ = lean_ctor_get(v___x_4748_, 0);
v_isSharedCheck_4783_ = !lean_is_exclusive(v___x_4748_);
if (v_isSharedCheck_4783_ == 0)
{
v___x_4778_ = v___x_4748_;
v_isShared_4779_ = v_isSharedCheck_4783_;
goto v_resetjp_4777_;
}
else
{
lean_inc(v_a_4776_);
lean_dec(v___x_4748_);
v___x_4778_ = lean_box(0);
v_isShared_4779_ = v_isSharedCheck_4783_;
goto v_resetjp_4777_;
}
v_resetjp_4777_:
{
lean_object* v___x_4781_; 
if (v_isShared_4779_ == 0)
{
v___x_4781_ = v___x_4778_;
goto v_reusejp_4780_;
}
else
{
lean_object* v_reuseFailAlloc_4782_; 
v_reuseFailAlloc_4782_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4782_, 0, v_a_4776_);
v___x_4781_ = v_reuseFailAlloc_4782_;
goto v_reusejp_4780_;
}
v_reusejp_4780_:
{
return v___x_4781_;
}
}
}
}
else
{
return v___x_4742_;
}
}
case 5:
{
lean_object* v_val_4784_; lean_object* v_all_4785_; lean_object* v___x_4786_; lean_object* v___x_4787_; lean_object* v___x_4788_; 
v_val_4784_ = lean_ctor_get(v_val_4117_, 0);
lean_inc_ref(v_val_4784_);
lean_dec_ref_known(v_val_4117_, 1);
v_all_4785_ = lean_ctor_get(v_val_4784_, 3);
lean_inc(v_all_4785_);
v___x_4786_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__20));
v___x_4787_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__22));
v___x_4788_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg(v___x_4128_, v_val_4784_, v_all_4785_, v___x_4787_, v_a_4006_, v___x_4134_);
lean_dec(v_all_4785_);
lean_dec_ref(v_val_4784_);
if (lean_obj_tag(v___x_4788_) == 0)
{
lean_object* v_a_4789_; lean_object* v_fst_4790_; lean_object* v_snd_4791_; lean_object* v_snd_4792_; lean_object* v_fst_4793_; lean_object* v_fst_4794_; lean_object* v_snd_4795_; lean_object* v___x_4796_; size_t v_sz_4797_; size_t v___x_4798_; lean_object* v___x_4799_; 
v_a_4789_ = lean_ctor_get(v___x_4788_, 0);
lean_inc(v_a_4789_);
lean_dec_ref_known(v___x_4788_, 1);
v_fst_4790_ = lean_ctor_get(v_a_4789_, 0);
lean_inc(v_fst_4790_);
v_snd_4791_ = lean_ctor_get(v_fst_4790_, 1);
lean_inc(v_snd_4791_);
v_snd_4792_ = lean_ctor_get(v_a_4789_, 1);
lean_inc(v_snd_4792_);
lean_dec(v_a_4789_);
v_fst_4793_ = lean_ctor_get(v_fst_4790_, 0);
lean_inc(v_fst_4793_);
lean_dec(v_fst_4790_);
v_fst_4794_ = lean_ctor_get(v_snd_4791_, 0);
lean_inc(v_fst_4794_);
v_snd_4795_ = lean_ctor_get(v_snd_4791_, 1);
lean_inc(v_snd_4795_);
lean_dec(v_snd_4791_);
v___x_4796_ = lean_box(0);
v_sz_4797_ = lean_array_size(v_fst_4794_);
v___x_4798_ = ((size_t)0ULL);
v___x_4799_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__11(v_fst_4794_, v_sz_4797_, v___x_4798_, v___x_4796_, v_a_4006_, v_snd_4792_);
if (lean_obj_tag(v___x_4799_) == 0)
{
lean_object* v_a_4800_; lean_object* v_snd_4801_; lean_object* v___x_4802_; 
v_a_4800_ = lean_ctor_get(v___x_4799_, 0);
lean_inc(v_a_4800_);
lean_dec_ref_known(v___x_4799_, 1);
v_snd_4801_ = lean_ctor_get(v_a_4800_, 1);
lean_inc(v_snd_4801_);
lean_dec(v_a_4800_);
v___x_4802_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12(v___x_4128_, v___x_4786_, v_snd_4795_, v_a_4006_, v_snd_4801_);
if (lean_obj_tag(v___x_4802_) == 0)
{
lean_object* v_a_4803_; lean_object* v_fst_4804_; lean_object* v_snd_4805_; lean_object* v_a_4806_; 
v_a_4803_ = lean_ctor_get(v___x_4802_, 0);
lean_inc(v_a_4803_);
lean_dec_ref_known(v___x_4802_, 1);
v_fst_4804_ = lean_ctor_get(v_a_4803_, 0);
lean_inc(v_fst_4804_);
v_snd_4805_ = lean_ctor_get(v_a_4803_, 1);
lean_inc(v_snd_4805_);
lean_dec(v_a_4803_);
v_a_4806_ = lean_ctor_get(v_fst_4804_, 0);
lean_inc(v_a_4806_);
lean_dec(v_fst_4804_);
v___y_4014_ = v_fst_4794_;
v___y_4015_ = v___x_4798_;
v___y_4016_ = v___x_4796_;
v___y_4017_ = v_fst_4793_;
v___y_4018_ = v_sz_4797_;
v_fst_4019_ = v_a_4806_;
v_snd_4020_ = v_snd_4805_;
goto v___jp_4013_;
}
else
{
lean_object* v_a_4807_; lean_object* v___x_4809_; uint8_t v_isShared_4810_; uint8_t v_isSharedCheck_4814_; 
lean_dec(v_fst_4794_);
lean_dec(v_fst_4793_);
v_a_4807_ = lean_ctor_get(v___x_4802_, 0);
v_isSharedCheck_4814_ = !lean_is_exclusive(v___x_4802_);
if (v_isSharedCheck_4814_ == 0)
{
v___x_4809_ = v___x_4802_;
v_isShared_4810_ = v_isSharedCheck_4814_;
goto v_resetjp_4808_;
}
else
{
lean_inc(v_a_4807_);
lean_dec(v___x_4802_);
v___x_4809_ = lean_box(0);
v_isShared_4810_ = v_isSharedCheck_4814_;
goto v_resetjp_4808_;
}
v_resetjp_4808_:
{
lean_object* v___x_4812_; 
if (v_isShared_4810_ == 0)
{
v___x_4812_ = v___x_4809_;
goto v_reusejp_4811_;
}
else
{
lean_object* v_reuseFailAlloc_4813_; 
v_reuseFailAlloc_4813_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4813_, 0, v_a_4807_);
v___x_4812_ = v_reuseFailAlloc_4813_;
goto v_reusejp_4811_;
}
v_reusejp_4811_:
{
return v___x_4812_;
}
}
}
}
else
{
lean_dec(v_snd_4795_);
lean_dec(v_fst_4794_);
lean_dec(v_fst_4793_);
return v___x_4799_;
}
}
else
{
lean_object* v_a_4815_; lean_object* v___x_4817_; uint8_t v_isShared_4818_; uint8_t v_isSharedCheck_4822_; 
v_a_4815_ = lean_ctor_get(v___x_4788_, 0);
v_isSharedCheck_4822_ = !lean_is_exclusive(v___x_4788_);
if (v_isSharedCheck_4822_ == 0)
{
v___x_4817_ = v___x_4788_;
v_isShared_4818_ = v_isSharedCheck_4822_;
goto v_resetjp_4816_;
}
else
{
lean_inc(v_a_4815_);
lean_dec(v___x_4788_);
v___x_4817_ = lean_box(0);
v_isShared_4818_ = v_isSharedCheck_4822_;
goto v_resetjp_4816_;
}
v_resetjp_4816_:
{
lean_object* v___x_4820_; 
if (v_isShared_4818_ == 0)
{
v___x_4820_ = v___x_4817_;
goto v_reusejp_4819_;
}
else
{
lean_object* v_reuseFailAlloc_4821_; 
v_reuseFailAlloc_4821_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4821_, 0, v_a_4815_);
v___x_4820_ = v_reuseFailAlloc_4821_;
goto v_reusejp_4819_;
}
v_reusejp_4819_:
{
return v___x_4820_;
}
}
}
}
case 6:
{
lean_object* v_val_4823_; lean_object* v_induct_4824_; 
v_val_4823_ = lean_ctor_get(v_val_4117_, 0);
lean_inc_ref(v_val_4823_);
lean_dec_ref_known(v_val_4117_, 1);
v_induct_4824_ = lean_ctor_get(v_val_4823_, 1);
lean_inc(v_induct_4824_);
lean_dec_ref(v_val_4823_);
v_c_4005_ = v_induct_4824_;
v_a_4007_ = v___x_4134_;
goto _start;
}
default: 
{
lean_object* v_val_4826_; lean_object* v_all_4827_; lean_object* v___x_4828_; lean_object* v___x_4829_; 
v_val_4826_ = lean_ctor_get(v_val_4117_, 0);
lean_inc_ref(v_val_4826_);
lean_dec_ref_known(v_val_4117_, 1);
v_all_4827_ = lean_ctor_get(v_val_4826_, 1);
lean_inc(v_all_4827_);
lean_dec_ref(v_val_4826_);
v___x_4828_ = lean_box(0);
v___x_4829_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg(v_all_4827_, v___x_4828_, v_a_4006_, v___x_4134_);
lean_dec(v_all_4827_);
if (lean_obj_tag(v___x_4829_) == 0)
{
lean_object* v_a_4830_; lean_object* v___x_4832_; uint8_t v_isShared_4833_; uint8_t v_isSharedCheck_4846_; 
v_a_4830_ = lean_ctor_get(v___x_4829_, 0);
v_isSharedCheck_4846_ = !lean_is_exclusive(v___x_4829_);
if (v_isSharedCheck_4846_ == 0)
{
v___x_4832_ = v___x_4829_;
v_isShared_4833_ = v_isSharedCheck_4846_;
goto v_resetjp_4831_;
}
else
{
lean_inc(v_a_4830_);
lean_dec(v___x_4829_);
v___x_4832_ = lean_box(0);
v_isShared_4833_ = v_isSharedCheck_4846_;
goto v_resetjp_4831_;
}
v_resetjp_4831_:
{
lean_object* v_snd_4834_; lean_object* v___x_4836_; uint8_t v_isShared_4837_; uint8_t v_isSharedCheck_4844_; 
v_snd_4834_ = lean_ctor_get(v_a_4830_, 1);
v_isSharedCheck_4844_ = !lean_is_exclusive(v_a_4830_);
if (v_isSharedCheck_4844_ == 0)
{
lean_object* v_unused_4845_; 
v_unused_4845_ = lean_ctor_get(v_a_4830_, 0);
lean_dec(v_unused_4845_);
v___x_4836_ = v_a_4830_;
v_isShared_4837_ = v_isSharedCheck_4844_;
goto v_resetjp_4835_;
}
else
{
lean_inc(v_snd_4834_);
lean_dec(v_a_4830_);
v___x_4836_ = lean_box(0);
v_isShared_4837_ = v_isSharedCheck_4844_;
goto v_resetjp_4835_;
}
v_resetjp_4835_:
{
lean_object* v___x_4839_; 
if (v_isShared_4837_ == 0)
{
lean_ctor_set(v___x_4836_, 0, v___x_4828_);
v___x_4839_ = v___x_4836_;
goto v_reusejp_4838_;
}
else
{
lean_object* v_reuseFailAlloc_4843_; 
v_reuseFailAlloc_4843_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4843_, 0, v___x_4828_);
lean_ctor_set(v_reuseFailAlloc_4843_, 1, v_snd_4834_);
v___x_4839_ = v_reuseFailAlloc_4843_;
goto v_reusejp_4838_;
}
v_reusejp_4838_:
{
lean_object* v___x_4841_; 
if (v_isShared_4833_ == 0)
{
lean_ctor_set(v___x_4832_, 0, v___x_4839_);
v___x_4841_ = v___x_4832_;
goto v_reusejp_4840_;
}
else
{
lean_object* v_reuseFailAlloc_4842_; 
v_reuseFailAlloc_4842_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4842_, 0, v___x_4839_);
v___x_4841_ = v_reuseFailAlloc_4842_;
goto v_reusejp_4840_;
}
v_reusejp_4840_:
{
return v___x_4841_;
}
}
}
}
}
else
{
return v___x_4829_;
}
}
}
}
}
}
else
{
lean_dec(v_val_4117_);
lean_dec(v_c_4005_);
goto v___jp_4009_;
}
}
v___jp_4855_:
{
if (v___y_4856_ == 0)
{
goto v___jp_4118_;
}
else
{
lean_dec(v_val_4117_);
lean_dec(v_c_4005_);
goto v___jp_4009_;
}
}
}
else
{
uint8_t v_ignoreMissing_4859_; 
lean_dec(v___x_4116_);
v_ignoreMissing_4859_ = lean_ctor_get_uint8(v_a_4007_, sizeof(void*)*6 + 2);
if (v_ignoreMissing_4859_ == 0)
{
lean_object* v___x_4860_; lean_object* v___x_4861_; lean_object* v___x_4862_; lean_object* v___x_4863_; lean_object* v___x_4864_; uint8_t v___x_4865_; lean_object* v___x_4866_; lean_object* v___x_4867_; lean_object* v___x_4868_; lean_object* v___x_4869_; lean_object* v___x_4870_; lean_object* v___x_4871_; 
v___x_4860_ = ((lean_object*)(lp_proofEnvironment_dumpName___closed__1));
v___x_4861_ = ((lean_object*)(lp_proofEnvironment_Std_DTreeMap_Internal_Impl_forInStep___at___00dumpConstant_spec__12___closed__0));
v___x_4862_ = lean_unsigned_to_nat(237u);
v___x_4863_ = lean_unsigned_to_nat(48u);
v___x_4864_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__1));
v___x_4865_ = 1;
v___x_4866_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_c_4005_, v___x_4865_);
v___x_4867_ = lean_string_append(v___x_4864_, v___x_4866_);
lean_dec_ref(v___x_4866_);
v___x_4868_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___closed__2));
v___x_4869_ = lean_string_append(v___x_4867_, v___x_4868_);
v___x_4870_ = l_mkPanicMessageWithDecl(v___x_4860_, v___x_4861_, v___x_4862_, v___x_4863_, v___x_4869_);
lean_dec_ref(v___x_4869_);
v___x_4871_ = lp_proofEnvironment_panic___at___00dumpConstant_spec__4(v___x_4870_, v_a_4006_, v_a_4007_);
return v___x_4871_;
}
else
{
lean_object* v___x_4872_; lean_object* v___x_4873_; lean_object* v___x_4874_; 
lean_dec(v_c_4005_);
v___x_4872_ = lean_box(0);
v___x_4873_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4873_, 0, v___x_4872_);
lean_ctor_set(v___x_4873_, 1, v_a_4007_);
v___x_4874_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4874_, 0, v___x_4873_);
return v___x_4874_;
}
}
v___jp_4009_:
{
lean_object* v___x_4010_; lean_object* v___x_4011_; lean_object* v___x_4012_; 
v___x_4010_ = lean_box(0);
v___x_4011_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4011_, 0, v___x_4010_);
lean_ctor_set(v___x_4011_, 1, v_a_4007_);
v___x_4012_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4012_, 0, v___x_4011_);
return v___x_4012_;
}
v___jp_4013_:
{
size_t v_sz_4021_; lean_object* v___x_4022_; 
v_sz_4021_ = lean_array_size(v_fst_4019_);
v___x_4022_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__13(v_fst_4019_, v_sz_4021_, v___y_4015_, v___y_4016_, v_a_4006_, v_snd_4020_);
if (lean_obj_tag(v___x_4022_) == 0)
{
lean_object* v_a_4023_; lean_object* v_snd_4024_; lean_object* v___x_4026_; uint8_t v_isShared_4027_; uint8_t v_isSharedCheck_4113_; 
v_a_4023_ = lean_ctor_get(v___x_4022_, 0);
lean_inc(v_a_4023_);
lean_dec_ref_known(v___x_4022_, 1);
v_snd_4024_ = lean_ctor_get(v_a_4023_, 1);
v_isSharedCheck_4113_ = !lean_is_exclusive(v_a_4023_);
if (v_isSharedCheck_4113_ == 0)
{
lean_object* v_unused_4114_; 
v_unused_4114_ = lean_ctor_get(v_a_4023_, 0);
lean_dec(v_unused_4114_);
v___x_4026_ = v_a_4023_;
v_isShared_4027_ = v_isSharedCheck_4113_;
goto v_resetjp_4025_;
}
else
{
lean_inc(v_snd_4024_);
lean_dec(v_a_4023_);
v___x_4026_ = lean_box(0);
v_isShared_4027_ = v_isSharedCheck_4113_;
goto v_resetjp_4025_;
}
v_resetjp_4025_:
{
lean_object* v___x_4028_; 
v___x_4028_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__14(v_fst_4019_, v_sz_4021_, v___y_4015_, v___y_4016_, v_a_4006_, v_snd_4024_);
if (lean_obj_tag(v___x_4028_) == 0)
{
lean_object* v_a_4029_; lean_object* v_snd_4030_; lean_object* v___x_4032_; uint8_t v_isShared_4033_; uint8_t v_isSharedCheck_4111_; 
v_a_4029_ = lean_ctor_get(v___x_4028_, 0);
lean_inc(v_a_4029_);
lean_dec_ref_known(v___x_4028_, 1);
v_snd_4030_ = lean_ctor_get(v_a_4029_, 1);
v_isSharedCheck_4111_ = !lean_is_exclusive(v_a_4029_);
if (v_isSharedCheck_4111_ == 0)
{
lean_object* v_unused_4112_; 
v_unused_4112_ = lean_ctor_get(v_a_4029_, 0);
lean_dec(v_unused_4112_);
v___x_4032_ = v_a_4029_;
v_isShared_4033_ = v_isSharedCheck_4111_;
goto v_resetjp_4031_;
}
else
{
lean_inc(v_snd_4030_);
lean_dec(v_a_4029_);
v___x_4032_ = lean_box(0);
v_isShared_4033_ = v_isSharedCheck_4111_;
goto v_resetjp_4031_;
}
v_resetjp_4031_:
{
size_t v_sz_4034_; lean_object* v___x_4035_; 
v_sz_4034_ = lean_array_size(v___y_4017_);
v___x_4035_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15(v_sz_4034_, v___y_4015_, v___y_4017_, v_a_4006_, v_snd_4030_);
if (lean_obj_tag(v___x_4035_) == 0)
{
lean_object* v_a_4036_; lean_object* v_fst_4037_; lean_object* v_snd_4038_; lean_object* v___x_4040_; uint8_t v_isShared_4041_; uint8_t v_isSharedCheck_4102_; 
v_a_4036_ = lean_ctor_get(v___x_4035_, 0);
lean_inc(v_a_4036_);
lean_dec_ref_known(v___x_4035_, 1);
v_fst_4037_ = lean_ctor_get(v_a_4036_, 0);
v_snd_4038_ = lean_ctor_get(v_a_4036_, 1);
v_isSharedCheck_4102_ = !lean_is_exclusive(v_a_4036_);
if (v_isSharedCheck_4102_ == 0)
{
v___x_4040_ = v_a_4036_;
v_isShared_4041_ = v_isSharedCheck_4102_;
goto v_resetjp_4039_;
}
else
{
lean_inc(v_snd_4038_);
lean_inc(v_fst_4037_);
lean_dec(v_a_4036_);
v___x_4040_ = lean_box(0);
v_isShared_4041_ = v_isSharedCheck_4102_;
goto v_resetjp_4039_;
}
v_resetjp_4039_:
{
lean_object* v___x_4042_; 
v___x_4042_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16(v___y_4018_, v___y_4015_, v___y_4014_, v_a_4006_, v_snd_4038_);
if (lean_obj_tag(v___x_4042_) == 0)
{
lean_object* v_a_4043_; lean_object* v_fst_4044_; lean_object* v_snd_4045_; lean_object* v___x_4047_; uint8_t v_isShared_4048_; uint8_t v_isSharedCheck_4093_; 
v_a_4043_ = lean_ctor_get(v___x_4042_, 0);
lean_inc(v_a_4043_);
lean_dec_ref_known(v___x_4042_, 1);
v_fst_4044_ = lean_ctor_get(v_a_4043_, 0);
v_snd_4045_ = lean_ctor_get(v_a_4043_, 1);
v_isSharedCheck_4093_ = !lean_is_exclusive(v_a_4043_);
if (v_isSharedCheck_4093_ == 0)
{
v___x_4047_ = v_a_4043_;
v_isShared_4048_ = v_isSharedCheck_4093_;
goto v_resetjp_4046_;
}
else
{
lean_inc(v_snd_4045_);
lean_inc(v_fst_4044_);
lean_dec(v_a_4043_);
v___x_4047_ = lean_box(0);
v_isShared_4048_ = v_isSharedCheck_4093_;
goto v_resetjp_4046_;
}
v_resetjp_4046_:
{
lean_object* v___x_4049_; 
v___x_4049_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17(v_sz_4021_, v___y_4015_, v_fst_4019_, v_a_4006_, v_snd_4045_);
if (lean_obj_tag(v___x_4049_) == 0)
{
lean_object* v_a_4050_; lean_object* v_fst_4051_; lean_object* v_snd_4052_; lean_object* v___x_4054_; uint8_t v_isShared_4055_; uint8_t v_isSharedCheck_4084_; 
v_a_4050_ = lean_ctor_get(v___x_4049_, 0);
lean_inc(v_a_4050_);
lean_dec_ref_known(v___x_4049_, 1);
v_fst_4051_ = lean_ctor_get(v_a_4050_, 0);
v_snd_4052_ = lean_ctor_get(v_a_4050_, 1);
v_isSharedCheck_4084_ = !lean_is_exclusive(v_a_4050_);
if (v_isSharedCheck_4084_ == 0)
{
v___x_4054_ = v_a_4050_;
v_isShared_4055_ = v_isSharedCheck_4084_;
goto v_resetjp_4053_;
}
else
{
lean_inc(v_snd_4052_);
lean_inc(v_fst_4051_);
lean_dec(v_a_4050_);
v___x_4054_ = lean_box(0);
v_isShared_4055_ = v_isSharedCheck_4084_;
goto v_resetjp_4053_;
}
v_resetjp_4053_:
{
lean_object* v___x_4056_; lean_object* v___x_4057_; lean_object* v___x_4058_; lean_object* v___x_4060_; 
v___x_4056_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__0));
v___x_4057_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__1));
v___x_4058_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_4037_);
if (v_isShared_4055_ == 0)
{
lean_ctor_set(v___x_4054_, 1, v___x_4058_);
lean_ctor_set(v___x_4054_, 0, v___x_4057_);
v___x_4060_ = v___x_4054_;
goto v_reusejp_4059_;
}
else
{
lean_object* v_reuseFailAlloc_4083_; 
v_reuseFailAlloc_4083_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4083_, 0, v___x_4057_);
lean_ctor_set(v_reuseFailAlloc_4083_, 1, v___x_4058_);
v___x_4060_ = v_reuseFailAlloc_4083_;
goto v_reusejp_4059_;
}
v_reusejp_4059_:
{
lean_object* v___x_4061_; lean_object* v___x_4062_; lean_object* v___x_4064_; 
v___x_4061_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___closed__2));
v___x_4062_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_4044_);
if (v_isShared_4048_ == 0)
{
lean_ctor_set(v___x_4047_, 1, v___x_4062_);
lean_ctor_set(v___x_4047_, 0, v___x_4061_);
v___x_4064_ = v___x_4047_;
goto v_reusejp_4063_;
}
else
{
lean_object* v_reuseFailAlloc_4082_; 
v_reuseFailAlloc_4082_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4082_, 0, v___x_4061_);
lean_ctor_set(v_reuseFailAlloc_4082_, 1, v___x_4062_);
v___x_4064_ = v_reuseFailAlloc_4082_;
goto v_reusejp_4063_;
}
v_reusejp_4063_:
{
lean_object* v___x_4065_; lean_object* v___x_4066_; lean_object* v___x_4068_; 
v___x_4065_ = ((lean_object*)(lp_proofEnvironment_dumpConstant___closed__2));
v___x_4066_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_4051_);
if (v_isShared_4041_ == 0)
{
lean_ctor_set(v___x_4040_, 1, v___x_4066_);
lean_ctor_set(v___x_4040_, 0, v___x_4065_);
v___x_4068_ = v___x_4040_;
goto v_reusejp_4067_;
}
else
{
lean_object* v_reuseFailAlloc_4081_; 
v_reuseFailAlloc_4081_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4081_, 0, v___x_4065_);
lean_ctor_set(v_reuseFailAlloc_4081_, 1, v___x_4066_);
v___x_4068_ = v_reuseFailAlloc_4081_;
goto v_reusejp_4067_;
}
v_reusejp_4067_:
{
lean_object* v___x_4069_; lean_object* v___x_4071_; 
v___x_4069_ = lean_box(0);
if (v_isShared_4027_ == 0)
{
lean_ctor_set_tag(v___x_4026_, 1);
lean_ctor_set(v___x_4026_, 1, v___x_4069_);
lean_ctor_set(v___x_4026_, 0, v___x_4068_);
v___x_4071_ = v___x_4026_;
goto v_reusejp_4070_;
}
else
{
lean_object* v_reuseFailAlloc_4080_; 
v_reuseFailAlloc_4080_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4080_, 0, v___x_4068_);
lean_ctor_set(v_reuseFailAlloc_4080_, 1, v___x_4069_);
v___x_4071_ = v_reuseFailAlloc_4080_;
goto v_reusejp_4070_;
}
v_reusejp_4070_:
{
lean_object* v___x_4072_; lean_object* v___x_4073_; lean_object* v___x_4074_; lean_object* v___x_4076_; 
v___x_4072_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4072_, 0, v___x_4064_);
lean_ctor_set(v___x_4072_, 1, v___x_4071_);
v___x_4073_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4073_, 0, v___x_4060_);
lean_ctor_set(v___x_4073_, 1, v___x_4072_);
v___x_4074_ = l_Lean_Json_mkObj(v___x_4073_);
lean_dec_ref_known(v___x_4073_, 2);
if (v_isShared_4033_ == 0)
{
lean_ctor_set(v___x_4032_, 1, v___x_4074_);
lean_ctor_set(v___x_4032_, 0, v___x_4056_);
v___x_4076_ = v___x_4032_;
goto v_reusejp_4075_;
}
else
{
lean_object* v_reuseFailAlloc_4079_; 
v_reuseFailAlloc_4079_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4079_, 0, v___x_4056_);
lean_ctor_set(v_reuseFailAlloc_4079_, 1, v___x_4074_);
v___x_4076_ = v_reuseFailAlloc_4079_;
goto v_reusejp_4075_;
}
v_reusejp_4075_:
{
lean_object* v___x_4077_; lean_object* v___x_4078_; 
v___x_4077_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_4077_, 0, v___x_4076_);
lean_ctor_set(v___x_4077_, 1, v___x_4069_);
v___x_4078_ = lp_proofEnvironment_dumpConstant_dumpObj___redArg(v___x_4077_, v_snd_4052_);
lean_dec_ref_known(v___x_4077_, 2);
return v___x_4078_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_4085_; lean_object* v___x_4087_; uint8_t v_isShared_4088_; uint8_t v_isSharedCheck_4092_; 
lean_del_object(v___x_4047_);
lean_dec(v_fst_4044_);
lean_del_object(v___x_4040_);
lean_dec(v_fst_4037_);
lean_del_object(v___x_4032_);
lean_del_object(v___x_4026_);
v_a_4085_ = lean_ctor_get(v___x_4049_, 0);
v_isSharedCheck_4092_ = !lean_is_exclusive(v___x_4049_);
if (v_isSharedCheck_4092_ == 0)
{
v___x_4087_ = v___x_4049_;
v_isShared_4088_ = v_isSharedCheck_4092_;
goto v_resetjp_4086_;
}
else
{
lean_inc(v_a_4085_);
lean_dec(v___x_4049_);
v___x_4087_ = lean_box(0);
v_isShared_4088_ = v_isSharedCheck_4092_;
goto v_resetjp_4086_;
}
v_resetjp_4086_:
{
lean_object* v___x_4090_; 
if (v_isShared_4088_ == 0)
{
v___x_4090_ = v___x_4087_;
goto v_reusejp_4089_;
}
else
{
lean_object* v_reuseFailAlloc_4091_; 
v_reuseFailAlloc_4091_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4091_, 0, v_a_4085_);
v___x_4090_ = v_reuseFailAlloc_4091_;
goto v_reusejp_4089_;
}
v_reusejp_4089_:
{
return v___x_4090_;
}
}
}
}
}
else
{
lean_object* v_a_4094_; lean_object* v___x_4096_; uint8_t v_isShared_4097_; uint8_t v_isSharedCheck_4101_; 
lean_del_object(v___x_4040_);
lean_dec(v_fst_4037_);
lean_del_object(v___x_4032_);
lean_del_object(v___x_4026_);
lean_dec_ref(v_fst_4019_);
v_a_4094_ = lean_ctor_get(v___x_4042_, 0);
v_isSharedCheck_4101_ = !lean_is_exclusive(v___x_4042_);
if (v_isSharedCheck_4101_ == 0)
{
v___x_4096_ = v___x_4042_;
v_isShared_4097_ = v_isSharedCheck_4101_;
goto v_resetjp_4095_;
}
else
{
lean_inc(v_a_4094_);
lean_dec(v___x_4042_);
v___x_4096_ = lean_box(0);
v_isShared_4097_ = v_isSharedCheck_4101_;
goto v_resetjp_4095_;
}
v_resetjp_4095_:
{
lean_object* v___x_4099_; 
if (v_isShared_4097_ == 0)
{
v___x_4099_ = v___x_4096_;
goto v_reusejp_4098_;
}
else
{
lean_object* v_reuseFailAlloc_4100_; 
v_reuseFailAlloc_4100_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4100_, 0, v_a_4094_);
v___x_4099_ = v_reuseFailAlloc_4100_;
goto v_reusejp_4098_;
}
v_reusejp_4098_:
{
return v___x_4099_;
}
}
}
}
}
else
{
lean_object* v_a_4103_; lean_object* v___x_4105_; uint8_t v_isShared_4106_; uint8_t v_isSharedCheck_4110_; 
lean_del_object(v___x_4032_);
lean_del_object(v___x_4026_);
lean_dec_ref(v_fst_4019_);
lean_dec(v___y_4014_);
v_a_4103_ = lean_ctor_get(v___x_4035_, 0);
v_isSharedCheck_4110_ = !lean_is_exclusive(v___x_4035_);
if (v_isSharedCheck_4110_ == 0)
{
v___x_4105_ = v___x_4035_;
v_isShared_4106_ = v_isSharedCheck_4110_;
goto v_resetjp_4104_;
}
else
{
lean_inc(v_a_4103_);
lean_dec(v___x_4035_);
v___x_4105_ = lean_box(0);
v_isShared_4106_ = v_isSharedCheck_4110_;
goto v_resetjp_4104_;
}
v_resetjp_4104_:
{
lean_object* v___x_4108_; 
if (v_isShared_4106_ == 0)
{
v___x_4108_ = v___x_4105_;
goto v_reusejp_4107_;
}
else
{
lean_object* v_reuseFailAlloc_4109_; 
v_reuseFailAlloc_4109_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4109_, 0, v_a_4103_);
v___x_4108_ = v_reuseFailAlloc_4109_;
goto v_reusejp_4107_;
}
v_reusejp_4107_:
{
return v___x_4108_;
}
}
}
}
}
else
{
lean_del_object(v___x_4026_);
lean_dec_ref(v_fst_4019_);
lean_dec(v___y_4017_);
lean_dec(v___y_4014_);
return v___x_4028_;
}
}
}
else
{
lean_dec_ref(v_fst_4019_);
lean_dec(v___y_4017_);
lean_dec(v___y_4014_);
return v___x_4022_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_dumpDeps_spec__0(lean_object* v_as_4875_, size_t v_sz_4876_, size_t v_i_4877_, lean_object* v_b_4878_, lean_object* v___y_4879_, lean_object* v___y_4880_){
_start:
{
uint8_t v___x_4882_; 
v___x_4882_ = lean_usize_dec_lt(v_i_4877_, v_sz_4876_);
if (v___x_4882_ == 0)
{
lean_object* v___x_4883_; lean_object* v___x_4884_; 
v___x_4883_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4883_, 0, v_b_4878_);
lean_ctor_set(v___x_4883_, 1, v___y_4880_);
v___x_4884_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4884_, 0, v___x_4883_);
return v___x_4884_;
}
else
{
lean_object* v_a_4885_; lean_object* v___x_4886_; 
v_a_4885_ = lean_array_uget_borrowed(v_as_4875_, v_i_4877_);
lean_inc(v_a_4885_);
v___x_4886_ = lp_proofEnvironment_dumpConstant(v_a_4885_, v___y_4879_, v___y_4880_);
if (lean_obj_tag(v___x_4886_) == 0)
{
lean_object* v_a_4887_; lean_object* v_snd_4888_; lean_object* v___x_4889_; size_t v___x_4890_; size_t v___x_4891_; 
v_a_4887_ = lean_ctor_get(v___x_4886_, 0);
lean_inc(v_a_4887_);
lean_dec_ref_known(v___x_4886_, 1);
v_snd_4888_ = lean_ctor_get(v_a_4887_, 1);
lean_inc(v_snd_4888_);
lean_dec(v_a_4887_);
v___x_4889_ = lean_box(0);
v___x_4890_ = ((size_t)1ULL);
v___x_4891_ = lean_usize_add(v_i_4877_, v___x_4890_);
v_i_4877_ = v___x_4891_;
v_b_4878_ = v___x_4889_;
v___y_4880_ = v_snd_4888_;
goto _start;
}
else
{
return v___x_4886_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpDeps(lean_object* v_e_4893_, lean_object* v_a_4894_, lean_object* v_a_4895_){
_start:
{
lean_object* v___x_4897_; lean_object* v___x_4898_; size_t v_sz_4899_; size_t v___x_4900_; lean_object* v___x_4901_; 
v___x_4897_ = l_Lean_Expr_getUsedConstants(v_e_4893_);
v___x_4898_ = lean_box(0);
v_sz_4899_ = lean_array_size(v___x_4897_);
v___x_4900_ = ((size_t)0ULL);
v___x_4901_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_dumpDeps_spec__0(v___x_4897_, v_sz_4899_, v___x_4900_, v___x_4898_, v_a_4894_, v_a_4895_);
lean_dec_ref(v___x_4897_);
if (lean_obj_tag(v___x_4901_) == 0)
{
lean_object* v_a_4902_; lean_object* v___x_4904_; uint8_t v_isShared_4905_; uint8_t v_isSharedCheck_4918_; 
v_a_4902_ = lean_ctor_get(v___x_4901_, 0);
v_isSharedCheck_4918_ = !lean_is_exclusive(v___x_4901_);
if (v_isSharedCheck_4918_ == 0)
{
v___x_4904_ = v___x_4901_;
v_isShared_4905_ = v_isSharedCheck_4918_;
goto v_resetjp_4903_;
}
else
{
lean_inc(v_a_4902_);
lean_dec(v___x_4901_);
v___x_4904_ = lean_box(0);
v_isShared_4905_ = v_isSharedCheck_4918_;
goto v_resetjp_4903_;
}
v_resetjp_4903_:
{
lean_object* v_snd_4906_; lean_object* v___x_4908_; uint8_t v_isShared_4909_; uint8_t v_isSharedCheck_4916_; 
v_snd_4906_ = lean_ctor_get(v_a_4902_, 1);
v_isSharedCheck_4916_ = !lean_is_exclusive(v_a_4902_);
if (v_isSharedCheck_4916_ == 0)
{
lean_object* v_unused_4917_; 
v_unused_4917_ = lean_ctor_get(v_a_4902_, 0);
lean_dec(v_unused_4917_);
v___x_4908_ = v_a_4902_;
v_isShared_4909_ = v_isSharedCheck_4916_;
goto v_resetjp_4907_;
}
else
{
lean_inc(v_snd_4906_);
lean_dec(v_a_4902_);
v___x_4908_ = lean_box(0);
v_isShared_4909_ = v_isSharedCheck_4916_;
goto v_resetjp_4907_;
}
v_resetjp_4907_:
{
lean_object* v___x_4911_; 
if (v_isShared_4909_ == 0)
{
lean_ctor_set(v___x_4908_, 0, v___x_4898_);
v___x_4911_ = v___x_4908_;
goto v_reusejp_4910_;
}
else
{
lean_object* v_reuseFailAlloc_4915_; 
v_reuseFailAlloc_4915_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4915_, 0, v___x_4898_);
lean_ctor_set(v_reuseFailAlloc_4915_, 1, v_snd_4906_);
v___x_4911_ = v_reuseFailAlloc_4915_;
goto v_reusejp_4910_;
}
v_reusejp_4910_:
{
lean_object* v___x_4913_; 
if (v_isShared_4905_ == 0)
{
lean_ctor_set(v___x_4904_, 0, v___x_4911_);
v___x_4913_ = v___x_4904_;
goto v_reusejp_4912_;
}
else
{
lean_object* v_reuseFailAlloc_4914_; 
v_reuseFailAlloc_4914_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4914_, 0, v___x_4911_);
v___x_4913_ = v_reuseFailAlloc_4914_;
goto v_reusejp_4912_;
}
v_reusejp_4912_:
{
return v___x_4913_;
}
}
}
}
}
else
{
return v___x_4901_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpDeps___boxed(lean_object* v_e_4919_, lean_object* v_a_4920_, lean_object* v_a_4921_, lean_object* v_a_4922_){
_start:
{
lean_object* v_res_4923_; 
v_res_4923_ = lp_proofEnvironment_dumpConstant_dumpDeps(v_e_4919_, v_a_4920_, v_a_4921_);
lean_dec_ref(v_a_4920_);
return v_res_4923_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg___boxed(lean_object* v_as_x27_4924_, lean_object* v_b_4925_, lean_object* v___y_4926_, lean_object* v___y_4927_, lean_object* v___y_4928_){
_start:
{
lean_object* v_res_4929_; 
v_res_4929_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg(v_as_x27_4924_, v_b_4925_, v___y_4926_, v___y_4927_);
lean_dec_ref(v___y_4926_);
lean_dec(v_as_x27_4924_);
return v_res_4929_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg___boxed(lean_object* v_as_x27_4930_, lean_object* v_b_4931_, lean_object* v___y_4932_, lean_object* v___y_4933_, lean_object* v___y_4934_){
_start:
{
lean_object* v_res_4935_; 
v_res_4935_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg(v_as_x27_4930_, v_b_4931_, v___y_4932_, v___y_4933_);
lean_dec_ref(v___y_4932_);
lean_dec(v_as_x27_4930_);
return v_res_4935_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00dumpConstant_spec__2___boxed(lean_object* v_x_4936_, lean_object* v_x_4937_, lean_object* v___y_4938_, lean_object* v___y_4939_, lean_object* v___y_4940_){
_start:
{
lean_object* v_res_4941_; 
v_res_4941_ = lp_proofEnvironment_List_mapM_loop___at___00dumpConstant_spec__2(v_x_4936_, v_x_4937_, v___y_4938_, v___y_4939_);
lean_dec_ref(v___y_4938_);
return v_res_4941_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_dumpDeps_spec__0___boxed(lean_object* v_as_4942_, lean_object* v_sz_4943_, lean_object* v_i_4944_, lean_object* v_b_4945_, lean_object* v___y_4946_, lean_object* v___y_4947_, lean_object* v___y_4948_){
_start:
{
size_t v_sz_boxed_4949_; size_t v_i_boxed_4950_; lean_object* v_res_4951_; 
v_sz_boxed_4949_ = lean_unbox_usize(v_sz_4943_);
lean_dec(v_sz_4943_);
v_i_boxed_4950_ = lean_unbox_usize(v_i_4944_);
lean_dec(v_i_4944_);
v_res_4951_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_dumpDeps_spec__0(v_as_4942_, v_sz_boxed_4949_, v_i_boxed_4950_, v_b_4945_, v___y_4946_, v___y_4947_);
lean_dec_ref(v___y_4946_);
lean_dec_ref(v_as_4942_);
return v_res_4951_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpNatDeps___boxed(lean_object* v_a_4952_, lean_object* v_a_4953_, lean_object* v_a_4954_){
_start:
{
lean_object* v_res_4955_; 
v_res_4955_ = lp_proofEnvironment_dumpExprAux_dumpNatDeps(v_a_4952_, v_a_4953_);
lean_dec_ref(v_a_4952_);
return v_res_4955_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__14___boxed(lean_object* v_as_4956_, lean_object* v_sz_4957_, lean_object* v_i_4958_, lean_object* v_b_4959_, lean_object* v___y_4960_, lean_object* v___y_4961_, lean_object* v___y_4962_){
_start:
{
size_t v_sz_boxed_4963_; size_t v_i_boxed_4964_; lean_object* v_res_4965_; 
v_sz_boxed_4963_ = lean_unbox_usize(v_sz_4957_);
lean_dec(v_sz_4957_);
v_i_boxed_4964_ = lean_unbox_usize(v_i_4958_);
lean_dec(v_i_4958_);
v_res_4965_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__14(v_as_4956_, v_sz_boxed_4963_, v_i_boxed_4964_, v_b_4959_, v___y_4960_, v___y_4961_);
lean_dec_ref(v___y_4960_);
lean_dec_ref(v_as_4956_);
return v_res_4965_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExpr___boxed(lean_object* v_e_4966_, lean_object* v_a_4967_, lean_object* v_a_4968_, lean_object* v_a_4969_){
_start:
{
lean_object* v_res_4970_; 
v_res_4970_ = lp_proofEnvironment_dumpExpr(v_e_4966_, v_a_4967_, v_a_4968_);
lean_dec_ref(v_a_4967_);
return v_res_4970_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__11___boxed(lean_object* v_as_4971_, lean_object* v_sz_4972_, lean_object* v_i_4973_, lean_object* v_b_4974_, lean_object* v___y_4975_, lean_object* v___y_4976_, lean_object* v___y_4977_){
_start:
{
size_t v_sz_boxed_4978_; size_t v_i_boxed_4979_; lean_object* v_res_4980_; 
v_sz_boxed_4978_ = lean_unbox_usize(v_sz_4972_);
lean_dec(v_sz_4972_);
v_i_boxed_4979_ = lean_unbox_usize(v_i_4973_);
lean_dec(v_i_4973_);
v_res_4980_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__11(v_as_4971_, v_sz_boxed_4978_, v_i_boxed_4979_, v_b_4974_, v___y_4975_, v___y_4976_);
lean_dec_ref(v___y_4975_);
lean_dec_ref(v_as_4971_);
return v_res_4980_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__13___boxed(lean_object* v_as_4981_, lean_object* v_sz_4982_, lean_object* v_i_4983_, lean_object* v_b_4984_, lean_object* v___y_4985_, lean_object* v___y_4986_, lean_object* v___y_4987_){
_start:
{
size_t v_sz_boxed_4988_; size_t v_i_boxed_4989_; lean_object* v_res_4990_; 
v_sz_boxed_4988_ = lean_unbox_usize(v_sz_4982_);
lean_dec(v_sz_4982_);
v_i_boxed_4989_ = lean_unbox_usize(v_i_4983_);
lean_dec(v_i_4983_);
v_res_4990_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00dumpConstant_spec__13(v_as_4981_, v_sz_boxed_4988_, v_i_boxed_4989_, v_b_4984_, v___y_4985_, v___y_4986_);
lean_dec_ref(v___y_4985_);
lean_dec_ref(v_as_4981_);
return v_res_4990_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant_dumpRecRule___boxed(lean_object* v_rule_4991_, lean_object* v_a_4992_, lean_object* v_a_4993_, lean_object* v_a_4994_){
_start:
{
lean_object* v_res_4995_; 
v_res_4995_ = lp_proofEnvironment_dumpConstant_dumpRecRule(v_rule_4991_, v_a_4992_, v_a_4993_);
lean_dec_ref(v_a_4992_);
return v_res_4995_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux_dumpStrDeps___boxed(lean_object* v_a_4996_, lean_object* v_a_4997_, lean_object* v_a_4998_){
_start:
{
lean_object* v_res_4999_; 
v_res_4999_ = lp_proofEnvironment_dumpExprAux_dumpStrDeps(v_a_4996_, v_a_4997_);
lean_dec_ref(v_a_4996_);
return v_res_4999_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16___boxed(lean_object* v_sz_5000_, lean_object* v_i_5001_, lean_object* v_bs_5002_, lean_object* v___y_5003_, lean_object* v___y_5004_, lean_object* v___y_5005_){
_start:
{
size_t v_sz_boxed_5006_; size_t v_i_boxed_5007_; lean_object* v_res_5008_; 
v_sz_boxed_5006_ = lean_unbox_usize(v_sz_5000_);
lean_dec(v_sz_5000_);
v_i_boxed_5007_ = lean_unbox_usize(v_i_5001_);
lean_dec(v_i_5001_);
v_res_5008_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__16(v_sz_boxed_5006_, v_i_boxed_5007_, v_bs_5002_, v___y_5003_, v___y_5004_);
lean_dec_ref(v___y_5003_);
return v_res_5008_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg___boxed(lean_object* v___x_5009_, lean_object* v_as_x27_5010_, lean_object* v_b_5011_, lean_object* v___y_5012_, lean_object* v___y_5013_, lean_object* v___y_5014_){
_start:
{
uint8_t v___x_183360__boxed_5015_; lean_object* v_res_5016_; 
v___x_183360__boxed_5015_ = lean_unbox(v___x_5009_);
v_res_5016_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg(v___x_183360__boxed_5015_, v_as_x27_5010_, v_b_5011_, v___y_5012_, v___y_5013_);
lean_dec_ref(v___y_5012_);
lean_dec(v_as_x27_5010_);
return v_res_5016_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15___boxed(lean_object* v_sz_5017_, lean_object* v_i_5018_, lean_object* v_bs_5019_, lean_object* v___y_5020_, lean_object* v___y_5021_, lean_object* v___y_5022_){
_start:
{
size_t v_sz_boxed_5023_; size_t v_i_boxed_5024_; lean_object* v_res_5025_; 
v_sz_boxed_5023_ = lean_unbox_usize(v_sz_5017_);
lean_dec(v_sz_5017_);
v_i_boxed_5024_ = lean_unbox_usize(v_i_5018_);
lean_dec(v_i_5018_);
v_res_5025_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__15(v_sz_boxed_5023_, v_i_boxed_5024_, v_bs_5019_, v___y_5020_, v___y_5021_);
lean_dec_ref(v___y_5020_);
return v_res_5025_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17___boxed(lean_object* v_sz_5026_, lean_object* v_i_5027_, lean_object* v_bs_5028_, lean_object* v___y_5029_, lean_object* v___y_5030_, lean_object* v___y_5031_){
_start:
{
size_t v_sz_boxed_5032_; size_t v_i_boxed_5033_; lean_object* v_res_5034_; 
v_sz_boxed_5032_ = lean_unbox_usize(v_sz_5026_);
lean_dec(v_sz_5026_);
v_i_boxed_5033_ = lean_unbox_usize(v_i_5027_);
lean_dec(v_i_5027_);
v_res_5034_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00dumpConstant_spec__17(v_sz_boxed_5032_, v_i_boxed_5033_, v_bs_5028_, v___y_5029_, v___y_5030_);
lean_dec_ref(v___y_5029_);
return v_res_5034_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg___boxed(lean_object* v___x_5035_, lean_object* v_val_5036_, lean_object* v_as_x27_5037_, lean_object* v_b_5038_, lean_object* v___y_5039_, lean_object* v___y_5040_, lean_object* v___y_5041_){
_start:
{
uint8_t v___x_183665__boxed_5042_; lean_object* v_res_5043_; 
v___x_183665__boxed_5042_ = lean_unbox(v___x_5035_);
v_res_5043_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg(v___x_183665__boxed_5042_, v_val_5036_, v_as_x27_5037_, v_b_5038_, v___y_5039_, v___y_5040_);
lean_dec_ref(v___y_5039_);
lean_dec(v_as_x27_5037_);
lean_dec_ref(v_val_5036_);
return v_res_5043_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpExprAux___boxed(lean_object* v_e_5044_, lean_object* v_a_5045_, lean_object* v_a_5046_, lean_object* v_a_5047_){
_start:
{
lean_object* v_res_5048_; 
v_res_5048_ = lp_proofEnvironment_dumpExprAux(v_e_5044_, v_a_5045_, v_a_5046_);
lean_dec_ref(v_a_5045_);
return v_res_5048_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpConstant___boxed(lean_object* v_c_5049_, lean_object* v_a_5050_, lean_object* v_a_5051_, lean_object* v_a_5052_){
_start:
{
lean_object* v_res_5053_; 
v_res_5053_ = lp_proofEnvironment_dumpConstant(v_c_5049_, v_a_5050_, v_a_5051_);
lean_dec_ref(v_a_5050_);
return v_res_5053_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5(uint8_t v___x_5054_, lean_object* v_as_5055_, lean_object* v_as_x27_5056_, lean_object* v_b_5057_, lean_object* v_a_5058_, lean_object* v___y_5059_, lean_object* v___y_5060_){
_start:
{
lean_object* v___x_5062_; 
v___x_5062_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___redArg(v___x_5054_, v_as_x27_5056_, v_b_5057_, v___y_5059_, v___y_5060_);
return v___x_5062_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5___boxed(lean_object* v___x_5063_, lean_object* v_as_5064_, lean_object* v_as_x27_5065_, lean_object* v_b_5066_, lean_object* v_a_5067_, lean_object* v___y_5068_, lean_object* v___y_5069_, lean_object* v___y_5070_){
_start:
{
uint8_t v___x_188232__boxed_5071_; lean_object* v_res_5072_; 
v___x_188232__boxed_5071_ = lean_unbox(v___x_5063_);
v_res_5072_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__5(v___x_188232__boxed_5071_, v_as_5064_, v_as_x27_5065_, v_b_5066_, v_a_5067_, v___y_5068_, v___y_5069_);
lean_dec_ref(v___y_5068_);
lean_dec(v_as_x27_5065_);
lean_dec(v_as_5064_);
return v_res_5072_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7(uint8_t v___y_5073_, uint8_t v___x_5074_, lean_object* v_as_5075_, lean_object* v_as_x27_5076_, lean_object* v_b_5077_, lean_object* v_a_5078_, lean_object* v___y_5079_, lean_object* v___y_5080_){
_start:
{
lean_object* v___x_5082_; 
v___x_5082_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___redArg(v___y_5073_, v___x_5074_, v_as_x27_5076_, v_b_5077_, v___y_5079_, v___y_5080_);
return v___x_5082_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7___boxed(lean_object* v___y_5083_, lean_object* v___x_5084_, lean_object* v_as_5085_, lean_object* v_as_x27_5086_, lean_object* v_b_5087_, lean_object* v_a_5088_, lean_object* v___y_5089_, lean_object* v___y_5090_, lean_object* v___y_5091_){
_start:
{
uint8_t v___y_188249__boxed_5092_; uint8_t v___x_188250__boxed_5093_; lean_object* v_res_5094_; 
v___y_188249__boxed_5092_ = lean_unbox(v___y_5083_);
v___x_188250__boxed_5093_ = lean_unbox(v___x_5084_);
v_res_5094_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__7(v___y_188249__boxed_5092_, v___x_188250__boxed_5093_, v_as_5085_, v_as_x27_5086_, v_b_5087_, v_a_5088_, v___y_5089_, v___y_5090_);
lean_dec_ref(v___y_5089_);
lean_dec(v_as_x27_5086_);
lean_dec(v_as_5085_);
return v_res_5094_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9(uint8_t v___x_5095_, lean_object* v_val_5096_, lean_object* v_as_5097_, lean_object* v_as_x27_5098_, lean_object* v_b_5099_, lean_object* v_a_5100_, lean_object* v___y_5101_, lean_object* v___y_5102_){
_start:
{
lean_object* v___x_5104_; 
v___x_5104_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___redArg(v___x_5095_, v_val_5096_, v_as_x27_5098_, v_b_5099_, v___y_5101_, v___y_5102_);
return v___x_5104_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9___boxed(lean_object* v___x_5105_, lean_object* v_val_5106_, lean_object* v_as_5107_, lean_object* v_as_x27_5108_, lean_object* v_b_5109_, lean_object* v_a_5110_, lean_object* v___y_5111_, lean_object* v___y_5112_, lean_object* v___y_5113_){
_start:
{
uint8_t v___x_188269__boxed_5114_; lean_object* v_res_5115_; 
v___x_188269__boxed_5114_ = lean_unbox(v___x_5105_);
v_res_5115_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__9(v___x_188269__boxed_5114_, v_val_5106_, v_as_5107_, v_as_x27_5108_, v_b_5109_, v_a_5110_, v___y_5111_, v___y_5112_);
lean_dec_ref(v___y_5111_);
lean_dec(v_as_x27_5108_);
lean_dec(v_as_5107_);
lean_dec_ref(v_val_5106_);
return v_res_5115_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10(lean_object* v_as_5116_, lean_object* v_as_x27_5117_, lean_object* v_b_5118_, lean_object* v_a_5119_, lean_object* v___y_5120_, lean_object* v___y_5121_){
_start:
{
lean_object* v___x_5123_; 
v___x_5123_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___redArg(v_as_x27_5117_, v_b_5118_, v___y_5120_, v___y_5121_);
return v___x_5123_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10___boxed(lean_object* v_as_5124_, lean_object* v_as_x27_5125_, lean_object* v_b_5126_, lean_object* v_a_5127_, lean_object* v___y_5128_, lean_object* v___y_5129_, lean_object* v___y_5130_){
_start:
{
lean_object* v_res_5131_; 
v_res_5131_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__10(v_as_5124_, v_as_x27_5125_, v_b_5126_, v_a_5127_, v___y_5128_, v___y_5129_);
lean_dec_ref(v___y_5128_);
lean_dec(v_as_x27_5125_);
lean_dec(v_as_5124_);
return v_res_5131_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18(lean_object* v_as_5132_, lean_object* v_as_x27_5133_, lean_object* v_b_5134_, lean_object* v_a_5135_, lean_object* v___y_5136_, lean_object* v___y_5137_){
_start:
{
lean_object* v___x_5139_; 
v___x_5139_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___redArg(v_as_x27_5133_, v_b_5134_, v___y_5136_, v___y_5137_);
return v___x_5139_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18___boxed(lean_object* v_as_5140_, lean_object* v_as_x27_5141_, lean_object* v_b_5142_, lean_object* v_a_5143_, lean_object* v___y_5144_, lean_object* v___y_5145_, lean_object* v___y_5146_){
_start:
{
lean_object* v_res_5147_; 
v_res_5147_ = lp_proofEnvironment_List_forIn_x27_loop___at___00dumpConstant_spec__18(v_as_5140_, v_as_x27_5141_, v_b_5142_, v_a_5143_, v___y_5144_, v___y_5145_);
lean_dec_ref(v___y_5144_);
lean_dec(v_as_x27_5141_);
lean_dec(v_as_5140_);
return v_res_5147_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__1(void){
_start:
{
lean_object* v___x_5149_; lean_object* v___x_5150_; 
v___x_5149_ = l_Lean_versionString;
v___x_5150_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_5150_, 0, v___x_5149_);
return v___x_5150_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__2(void){
_start:
{
lean_object* v___x_5151_; lean_object* v___x_5152_; lean_object* v___x_5153_; 
v___x_5151_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__1, &lp_proofEnvironment_exportMetadata___closed__1_once, _init_lp_proofEnvironment_exportMetadata___closed__1);
v___x_5152_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__0));
v___x_5153_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5153_, 0, v___x_5152_);
lean_ctor_set(v___x_5153_, 1, v___x_5151_);
return v___x_5153_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__4(void){
_start:
{
lean_object* v___x_5155_; lean_object* v___x_5156_; 
v___x_5155_ = l_Lean_githash;
v___x_5156_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_5156_, 0, v___x_5155_);
return v___x_5156_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__5(void){
_start:
{
lean_object* v___x_5157_; lean_object* v___x_5158_; lean_object* v___x_5159_; 
v___x_5157_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__4, &lp_proofEnvironment_exportMetadata___closed__4_once, _init_lp_proofEnvironment_exportMetadata___closed__4);
v___x_5158_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__3));
v___x_5159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5159_, 0, v___x_5158_);
lean_ctor_set(v___x_5159_, 1, v___x_5157_);
return v___x_5159_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__6(void){
_start:
{
lean_object* v___x_5160_; lean_object* v___x_5161_; lean_object* v___x_5162_; 
v___x_5160_ = lean_box(0);
v___x_5161_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__5, &lp_proofEnvironment_exportMetadata___closed__5_once, _init_lp_proofEnvironment_exportMetadata___closed__5);
v___x_5162_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5162_, 0, v___x_5161_);
lean_ctor_set(v___x_5162_, 1, v___x_5160_);
return v___x_5162_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__7(void){
_start:
{
lean_object* v___x_5163_; lean_object* v___x_5164_; lean_object* v___x_5165_; 
v___x_5163_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__6, &lp_proofEnvironment_exportMetadata___closed__6_once, _init_lp_proofEnvironment_exportMetadata___closed__6);
v___x_5164_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__2, &lp_proofEnvironment_exportMetadata___closed__2_once, _init_lp_proofEnvironment_exportMetadata___closed__2);
v___x_5165_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5165_, 0, v___x_5164_);
lean_ctor_set(v___x_5165_, 1, v___x_5163_);
return v___x_5165_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__8(void){
_start:
{
lean_object* v___x_5166_; lean_object* v_leanMeta_5167_; 
v___x_5166_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__7, &lp_proofEnvironment_exportMetadata___closed__7_once, _init_lp_proofEnvironment_exportMetadata___closed__7);
v_leanMeta_5167_ = l_Lean_Json_mkObj(v___x_5166_);
return v_leanMeta_5167_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__17(void){
_start:
{
lean_object* v___x_5186_; lean_object* v_exporterMeta_5187_; 
v___x_5186_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__16));
v_exporterMeta_5187_ = l_Lean_Json_mkObj(v___x_5186_);
return v_exporterMeta_5187_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__18(void){
_start:
{
lean_object* v___x_5188_; lean_object* v_formatMeta_5189_; 
v___x_5188_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__15));
v_formatMeta_5189_ = l_Lean_Json_mkObj(v___x_5188_);
return v_formatMeta_5189_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__21(void){
_start:
{
lean_object* v_exporterMeta_5192_; lean_object* v___x_5193_; lean_object* v___x_5194_; 
v_exporterMeta_5192_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__17, &lp_proofEnvironment_exportMetadata___closed__17_once, _init_lp_proofEnvironment_exportMetadata___closed__17);
v___x_5193_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__20));
v___x_5194_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5194_, 0, v___x_5193_);
lean_ctor_set(v___x_5194_, 1, v_exporterMeta_5192_);
return v___x_5194_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__23(void){
_start:
{
lean_object* v_leanMeta_5196_; lean_object* v___x_5197_; lean_object* v___x_5198_; 
v_leanMeta_5196_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__8, &lp_proofEnvironment_exportMetadata___closed__8_once, _init_lp_proofEnvironment_exportMetadata___closed__8);
v___x_5197_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__22));
v___x_5198_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5198_, 0, v___x_5197_);
lean_ctor_set(v___x_5198_, 1, v_leanMeta_5196_);
return v___x_5198_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__25(void){
_start:
{
lean_object* v_formatMeta_5200_; lean_object* v___x_5201_; lean_object* v___x_5202_; 
v_formatMeta_5200_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__18, &lp_proofEnvironment_exportMetadata___closed__18_once, _init_lp_proofEnvironment_exportMetadata___closed__18);
v___x_5201_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__24));
v___x_5202_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5202_, 0, v___x_5201_);
lean_ctor_set(v___x_5202_, 1, v_formatMeta_5200_);
return v___x_5202_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__26(void){
_start:
{
lean_object* v___x_5203_; lean_object* v___x_5204_; lean_object* v___x_5205_; 
v___x_5203_ = lean_box(0);
v___x_5204_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__25, &lp_proofEnvironment_exportMetadata___closed__25_once, _init_lp_proofEnvironment_exportMetadata___closed__25);
v___x_5205_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5205_, 0, v___x_5204_);
lean_ctor_set(v___x_5205_, 1, v___x_5203_);
return v___x_5205_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__27(void){
_start:
{
lean_object* v___x_5206_; lean_object* v___x_5207_; lean_object* v___x_5208_; 
v___x_5206_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__26, &lp_proofEnvironment_exportMetadata___closed__26_once, _init_lp_proofEnvironment_exportMetadata___closed__26);
v___x_5207_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__23, &lp_proofEnvironment_exportMetadata___closed__23_once, _init_lp_proofEnvironment_exportMetadata___closed__23);
v___x_5208_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5208_, 0, v___x_5207_);
lean_ctor_set(v___x_5208_, 1, v___x_5206_);
return v___x_5208_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__28(void){
_start:
{
lean_object* v___x_5209_; lean_object* v___x_5210_; lean_object* v___x_5211_; 
v___x_5209_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__27, &lp_proofEnvironment_exportMetadata___closed__27_once, _init_lp_proofEnvironment_exportMetadata___closed__27);
v___x_5210_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__21, &lp_proofEnvironment_exportMetadata___closed__21_once, _init_lp_proofEnvironment_exportMetadata___closed__21);
v___x_5211_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5211_, 0, v___x_5210_);
lean_ctor_set(v___x_5211_, 1, v___x_5209_);
return v___x_5211_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__29(void){
_start:
{
lean_object* v___x_5212_; lean_object* v___x_5213_; 
v___x_5212_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__28, &lp_proofEnvironment_exportMetadata___closed__28_once, _init_lp_proofEnvironment_exportMetadata___closed__28);
v___x_5213_ = l_Lean_Json_mkObj(v___x_5212_);
return v___x_5213_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__30(void){
_start:
{
lean_object* v___x_5214_; lean_object* v___x_5215_; lean_object* v___x_5216_; 
v___x_5214_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__29, &lp_proofEnvironment_exportMetadata___closed__29_once, _init_lp_proofEnvironment_exportMetadata___closed__29);
v___x_5215_ = ((lean_object*)(lp_proofEnvironment_exportMetadata___closed__19));
v___x_5216_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5216_, 0, v___x_5215_);
lean_ctor_set(v___x_5216_, 1, v___x_5214_);
return v___x_5216_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__31(void){
_start:
{
lean_object* v___x_5217_; lean_object* v___x_5218_; lean_object* v___x_5219_; 
v___x_5217_ = lean_box(0);
v___x_5218_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__30, &lp_proofEnvironment_exportMetadata___closed__30_once, _init_lp_proofEnvironment_exportMetadata___closed__30);
v___x_5219_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_5219_, 0, v___x_5218_);
lean_ctor_set(v___x_5219_, 1, v___x_5217_);
return v___x_5219_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata___closed__32(void){
_start:
{
lean_object* v___x_5220_; lean_object* v___x_5221_; 
v___x_5220_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__31, &lp_proofEnvironment_exportMetadata___closed__31_once, _init_lp_proofEnvironment_exportMetadata___closed__31);
v___x_5221_ = l_Lean_Json_mkObj(v___x_5220_);
return v___x_5221_;
}
}
static lean_object* _init_lp_proofEnvironment_exportMetadata(void){
_start:
{
lean_object* v___x_5222_; 
v___x_5222_ = lean_obj_once(&lp_proofEnvironment_exportMetadata___closed__32, &lp_proofEnvironment_exportMetadata___closed__32_once, _init_lp_proofEnvironment_exportMetadata___closed__32);
return v___x_5222_;
}
}
static lean_object* _init_lp_proofEnvironment_dumpMetadata___redArg___closed__0(void){
_start:
{
lean_object* v___x_5223_; lean_object* v___x_5224_; 
v___x_5223_ = lp_proofEnvironment_exportMetadata;
v___x_5224_ = l_Lean_Json_compress(v___x_5223_);
return v___x_5224_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata___redArg(lean_object* v_a_5225_){
_start:
{
lean_object* v___x_5227_; lean_object* v___x_5228_; 
v___x_5227_ = lean_obj_once(&lp_proofEnvironment_dumpMetadata___redArg___closed__0, &lp_proofEnvironment_dumpMetadata___redArg___closed__0_once, _init_lp_proofEnvironment_dumpMetadata___redArg___closed__0);
v___x_5228_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_5227_);
if (lean_obj_tag(v___x_5228_) == 0)
{
lean_object* v_a_5229_; lean_object* v___x_5231_; uint8_t v_isShared_5232_; uint8_t v_isSharedCheck_5237_; 
v_a_5229_ = lean_ctor_get(v___x_5228_, 0);
v_isSharedCheck_5237_ = !lean_is_exclusive(v___x_5228_);
if (v_isSharedCheck_5237_ == 0)
{
v___x_5231_ = v___x_5228_;
v_isShared_5232_ = v_isSharedCheck_5237_;
goto v_resetjp_5230_;
}
else
{
lean_inc(v_a_5229_);
lean_dec(v___x_5228_);
v___x_5231_ = lean_box(0);
v_isShared_5232_ = v_isSharedCheck_5237_;
goto v_resetjp_5230_;
}
v_resetjp_5230_:
{
lean_object* v___x_5233_; lean_object* v___x_5235_; 
v___x_5233_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5233_, 0, v_a_5229_);
lean_ctor_set(v___x_5233_, 1, v_a_5225_);
if (v_isShared_5232_ == 0)
{
lean_ctor_set(v___x_5231_, 0, v___x_5233_);
v___x_5235_ = v___x_5231_;
goto v_reusejp_5234_;
}
else
{
lean_object* v_reuseFailAlloc_5236_; 
v_reuseFailAlloc_5236_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5236_, 0, v___x_5233_);
v___x_5235_ = v_reuseFailAlloc_5236_;
goto v_reusejp_5234_;
}
v_reusejp_5234_:
{
return v___x_5235_;
}
}
}
else
{
lean_object* v_a_5238_; lean_object* v___x_5240_; uint8_t v_isShared_5241_; uint8_t v_isSharedCheck_5245_; 
lean_dec_ref(v_a_5225_);
v_a_5238_ = lean_ctor_get(v___x_5228_, 0);
v_isSharedCheck_5245_ = !lean_is_exclusive(v___x_5228_);
if (v_isSharedCheck_5245_ == 0)
{
v___x_5240_ = v___x_5228_;
v_isShared_5241_ = v_isSharedCheck_5245_;
goto v_resetjp_5239_;
}
else
{
lean_inc(v_a_5238_);
lean_dec(v___x_5228_);
v___x_5240_ = lean_box(0);
v_isShared_5241_ = v_isSharedCheck_5245_;
goto v_resetjp_5239_;
}
v_resetjp_5239_:
{
lean_object* v___x_5243_; 
if (v_isShared_5241_ == 0)
{
v___x_5243_ = v___x_5240_;
goto v_reusejp_5242_;
}
else
{
lean_object* v_reuseFailAlloc_5244_; 
v_reuseFailAlloc_5244_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5244_, 0, v_a_5238_);
v___x_5243_ = v_reuseFailAlloc_5244_;
goto v_reusejp_5242_;
}
v_reusejp_5242_:
{
return v___x_5243_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata___redArg___boxed(lean_object* v_a_5246_, lean_object* v_a_5247_){
_start:
{
lean_object* v_res_5248_; 
v_res_5248_ = lp_proofEnvironment_dumpMetadata___redArg(v_a_5246_);
return v_res_5248_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata(lean_object* v_a_5249_, lean_object* v_a_5250_){
_start:
{
lean_object* v___x_5252_; 
v___x_5252_ = lp_proofEnvironment_dumpMetadata___redArg(v_a_5250_);
return v___x_5252_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_dumpMetadata___boxed(lean_object* v_a_5253_, lean_object* v_a_5254_, lean_object* v_a_5255_){
_start:
{
lean_object* v_res_5256_; 
v_res_5256_ = lp_proofEnvironment_dumpMetadata(v_a_5253_, v_a_5254_);
lean_dec_ref(v_a_5253_);
return v_res_5256_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Lean(uint8_t builtin);
lean_object* initialize_Std_Data_HashMap_Basic(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_Export(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std_Data_HashMap_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_proofEnvironment_exportMetadata = _init_lp_proofEnvironment_exportMetadata();
lean_mark_persistent(lp_proofEnvironment_exportMetadata);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
