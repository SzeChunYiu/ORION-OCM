// Lean compiler output
// Module: OCMEnvironment.Check
// Imports: public import Init public meta import Init public import OCMEnvironment.Prepare
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_result(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Array_append___redArg(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure(lean_object*, lean_object*, lean_object*);
lean_object* l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_axiomNames(lean_object*, lean_object*, lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_SMap_contains___at___00Lean_isClass_spec__0_spec__0___redArg(lean_object*, lean_object*);
lean_object* lean_elab_environment_to_kernel_env(lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* lean_add_decl(lean_object*, size_t, size_t, lean_object*, lean_object*);
extern lean_object* l_Lean_Options_empty;
lean_object* l_Lean_Kernel_Exception_toMessageData(lean_object*, lean_object*);
lean_object* l_Lean_MessageData_toString(lean_object*);
lean_object* lean_environment_find(lean_object*, lean_object*);
uint8_t lean_expr_equal(lean_object*, lean_object*);
uint8_t l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_Lean_SMap_fold___at___00Lean_getRevAliases_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t l_Array_isEqvAux___at___00Lean_Meta_instBEqAbstractMVarsResult_beq_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(lean_object*, size_t, size_t, lean_object*);
uint8_t l_Lean_Expr_hasLooseBVars(lean_object*);
uint8_t l_Lean_Expr_hasFVar(lean_object*);
uint8_t l_Lean_Expr_hasMVar(lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "POST_KERNEL_AXIOM_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "check"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "declarations_replayed"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "result.json"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__4_value;
static const lean_array_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 246}, .m_size = 1, .m_capacity = 1, .m_data = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__4_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "CHECKED_THEOREM_IDENTITY"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__6_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "MISSING_CHECKED_THEOREM"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__8_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__9_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "OPEN_CANDIDATE"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__10_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__11_value;
static const lean_closure_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__12_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "OCMEnvironment_checked_candidate"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__13_value),LEAN_SCALAR_PTR_LITERAL(121, 192, 168, 114, 44, 114, 227, 95)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__14_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__15 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__15_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "CANNOT_CHECK"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__16 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__16_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "kernel_resource"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__17 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__17_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "DETERMINISTIC_TIMEOUT"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__18 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__18_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "EXCESSIVE_MEMORY"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__19 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__19_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "DEEP_RECURSION"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__20 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__20_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "INTERRUPTED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__21 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__21_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "kernel_unclassified"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__22 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__22_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "REJECTED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__23 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__23_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "kernel"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__24 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__24_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_checkProof___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__25;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_checkProof___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__26;
static const lean_array_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 246}, .m_size = 1, .m_capacity = 1, .m_data = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__14_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__27 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__27_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "KERNEL_PASS"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__28 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__28_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "kernel_and_axioms"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__29 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__29_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__30 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__30_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "candidate_constants_touched"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__31 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__31_value;
static const lean_array_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 246}, .m_size = 1, .m_capacity = 1, .m_data = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__4_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__32 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__32_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "CHECKER_NAME_COLLISION"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__33 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__33_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_checkProof___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__33_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___closed__34 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkProof___closed__34_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_checkProof(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_checkProof___closed__25(void){
_start:
{
lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; 
v___x_36_ = lean_box(0);
v___x_37_ = lean_unsigned_to_nat(16u);
v___x_38_ = lean_mk_array(v___x_37_, v___x_36_);
return v___x_38_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_checkProof___closed__26(void){
_start:
{
lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; 
v___x_39_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_checkProof___closed__25, &lp_proofEnvironment_OCMEnvironment_checkProof___closed__25_once, _init_lp_proofEnvironment_OCMEnvironment_checkProof___closed__25);
v___x_40_ = lean_unsigned_to_nat(0u);
v___x_41_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_41_, 0, v___x_40_);
lean_ctor_set(v___x_41_, 1, v___x_39_);
return v___x_41_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_checkProof(lean_object* v_prepared_57_, lean_object* v_candidate_58_){
_start:
{
lean_object* v___y_64_; lean_object* v___y_65_; lean_object* v___y_66_; lean_object* v_fst_67_; lean_object* v_fst_68_; lean_object* v_snd_69_; lean_object* v___f_98_; lean_object* v___y_100_; lean_object* v___y_101_; lean_object* v___y_102_; lean_object* v___y_103_; lean_object* v___y_104_; lean_object* v___y_105_; lean_object* v___y_106_; lean_object* v___y_107_; lean_object* v___y_108_; lean_object* v___y_109_; lean_object* v___y_277_; lean_object* v___y_278_; lean_object* v___y_279_; lean_object* v___y_280_; uint8_t v___y_303_; uint8_t v___x_322_; 
v___f_98_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__12));
v___x_322_ = l_Lean_Expr_hasFVar(v_candidate_58_);
if (v___x_322_ == 0)
{
uint8_t v___x_323_; 
v___x_323_ = l_Lean_Expr_hasMVar(v_candidate_58_);
v___y_303_ = v___x_323_;
goto v___jp_302_;
}
else
{
v___y_303_ = v___x_322_;
goto v___jp_302_;
}
v___jp_60_:
{
lean_object* v___x_61_; lean_object* v___x_62_; 
v___x_61_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__1));
v___x_62_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_62_, 0, v___x_61_);
return v___x_62_;
}
v___jp_63_:
{
lean_object* v_size_70_; lean_object* v___x_72_; uint8_t v_isShared_73_; uint8_t v_isSharedCheck_87_; 
v_size_70_ = lean_ctor_get(v___y_64_, 0);
v_isSharedCheck_87_ = !lean_is_exclusive(v___y_64_);
if (v_isSharedCheck_87_ == 0)
{
lean_object* v_unused_88_; 
v_unused_88_ = lean_ctor_get(v___y_64_, 1);
lean_dec(v_unused_88_);
v___x_72_ = v___y_64_;
v_isShared_73_ = v_isSharedCheck_87_;
goto v_resetjp_71_;
}
else
{
lean_inc(v_size_70_);
lean_dec(v___y_64_);
v___x_72_ = lean_box(0);
v_isShared_73_ = v_isSharedCheck_87_;
goto v_resetjp_71_;
}
v_resetjp_71_:
{
lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_79_; 
v___x_74_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__2));
v___x_75_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__3));
v___x_76_ = l_Lean_JsonNumber_fromNat(v_size_70_);
v___x_77_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_77_, 0, v___x_76_);
if (v_isShared_73_ == 0)
{
lean_ctor_set(v___x_72_, 1, v___x_77_);
lean_ctor_set(v___x_72_, 0, v___x_75_);
v___x_79_ = v___x_72_;
goto v_reusejp_78_;
}
else
{
lean_object* v_reuseFailAlloc_86_; 
v_reuseFailAlloc_86_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_86_, 0, v___x_75_);
lean_ctor_set(v_reuseFailAlloc_86_, 1, v___x_77_);
v___x_79_ = v_reuseFailAlloc_86_;
goto v_reusejp_78_;
}
v_reusejp_78_:
{
lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; 
v___x_80_ = lean_box(0);
v___x_81_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_81_, 0, v___x_79_);
lean_ctor_set(v___x_81_, 1, v___x_80_);
v___x_82_ = l_Lean_Json_mkObj(v___x_81_);
lean_dec_ref_known(v___x_81_, 2);
v___x_83_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__5));
lean_inc_ref(v_fst_68_);
lean_inc_ref(v_fst_67_);
v___x_84_ = lp_proofEnvironment_OCMEnvironment_result(v___x_74_, v_fst_67_, v_fst_68_, v_snd_69_, v___x_82_, v___y_65_, v___y_66_, v___x_83_);
v___x_85_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_85_, 0, v___x_84_);
return v___x_85_;
}
}
}
v___jp_89_:
{
lean_object* v___x_90_; lean_object* v___x_91_; 
v___x_90_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__7));
v___x_91_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_91_, 0, v___x_90_);
return v___x_91_;
}
v___jp_92_:
{
lean_object* v___x_93_; lean_object* v___x_94_; 
v___x_93_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__9));
v___x_94_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_94_, 0, v___x_93_);
return v___x_94_;
}
v___jp_95_:
{
lean_object* v___x_96_; lean_object* v___x_97_; 
v___x_96_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__11));
v___x_97_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_97_, 0, v___x_96_);
return v___x_97_;
}
v___jp_99_:
{
lean_object* v_roots_110_; lean_object* v___x_111_; lean_object* v___x_112_; 
v_roots_110_ = l_Array_append___redArg(v___y_105_, v___y_109_);
lean_dec_ref(v___y_109_);
v___x_111_ = lp_proofEnvironment_OCMEnvironment_dependencyClosure(v___y_104_, v_roots_110_, v___y_107_);
v___x_112_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_111_);
if (lean_obj_tag(v___x_112_) == 0)
{
lean_object* v_a_113_; lean_object* v_names_114_; lean_object* v___x_116_; uint8_t v_isShared_117_; uint8_t v_isSharedCheck_266_; 
v_a_113_ = lean_ctor_get(v___x_112_, 0);
lean_inc(v_a_113_);
lean_dec_ref_known(v___x_112_, 1);
v_names_114_ = lean_ctor_get(v_a_113_, 0);
v_isSharedCheck_266_ = !lean_is_exclusive(v_a_113_);
if (v_isSharedCheck_266_ == 0)
{
lean_object* v_unused_267_; 
v_unused_267_ = lean_ctor_get(v_a_113_, 1);
lean_dec(v_unused_267_);
v___x_116_ = v_a_113_;
v_isShared_117_ = v_isSharedCheck_266_;
goto v_resetjp_115_;
}
else
{
lean_inc(v_names_114_);
lean_dec(v_a_113_);
v___x_116_ = lean_box(0);
v_isShared_117_ = v_isSharedCheck_266_;
goto v_resetjp_115_;
}
v_resetjp_115_:
{
lean_object* v___x_118_; lean_object* v___x_119_; 
v___x_118_ = lp_proofEnvironment_OCMEnvironment_axiomNames(v___y_104_, v_names_114_, v___y_101_);
v___x_119_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_118_);
if (lean_obj_tag(v___x_119_) == 0)
{
lean_object* v_a_120_; lean_object* v___x_122_; uint8_t v_isShared_123_; uint8_t v_isSharedCheck_257_; 
v_a_120_ = lean_ctor_get(v___x_119_, 0);
v_isSharedCheck_257_ = !lean_is_exclusive(v___x_119_);
if (v_isSharedCheck_257_ == 0)
{
v___x_122_ = v___x_119_;
v_isShared_123_ = v_isSharedCheck_257_;
goto v_resetjp_121_;
}
else
{
lean_inc(v_a_120_);
lean_dec(v___x_119_);
v___x_122_ = lean_box(0);
v_isShared_123_ = v_isSharedCheck_257_;
goto v_resetjp_121_;
}
v_resetjp_121_:
{
lean_object* v___x_124_; uint8_t v___x_125_; 
v___x_124_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__14));
v___x_125_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_SMap_contains___at___00Lean_isClass_spec__0_spec__0___redArg(v___y_104_, v___x_124_);
if (v___x_125_ == 0)
{
lean_object* v___x_126_; lean_object* v___x_127_; lean_object* v___x_128_; lean_object* v___x_129_; lean_object* v___x_130_; lean_object* v___x_131_; size_t v___x_132_; size_t v___x_133_; lean_object* v___x_134_; lean_object* v___x_135_; 
lean_del_object(v___x_122_);
lean_inc_ref(v___y_100_);
lean_inc(v___y_106_);
v___x_126_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_126_, 0, v___x_124_);
lean_ctor_set(v___x_126_, 1, v___y_106_);
lean_ctor_set(v___x_126_, 2, v___y_100_);
v___x_127_ = lean_box(0);
v___x_128_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__15));
lean_inc_ref(v_candidate_58_);
v___x_129_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_129_, 0, v___x_126_);
lean_ctor_set(v___x_129_, 1, v_candidate_58_);
lean_ctor_set(v___x_129_, 2, v___x_128_);
v___x_130_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_130_, 0, v___x_129_);
v___x_131_ = lean_elab_environment_to_kernel_env(v___y_108_);
v___x_132_ = lean_usize_of_nat(v___y_103_);
lean_dec(v___y_103_);
v___x_133_ = lean_usize_of_nat(v___y_102_);
lean_dec(v___y_102_);
v___x_134_ = lean_box(0);
v___x_135_ = lean_add_decl(v___x_131_, v___x_132_, v___x_133_, v___x_130_, v___x_134_);
lean_dec_ref_known(v___x_130_, 1);
if (lean_obj_tag(v___x_135_) == 0)
{
lean_object* v_a_136_; 
lean_del_object(v___x_116_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_candidate_58_);
v_a_136_ = lean_ctor_get(v___x_135_, 0);
lean_inc(v_a_136_);
lean_dec_ref_known(v___x_135_, 1);
switch(lean_obj_tag(v_a_136_))
{
case 13:
{
lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; 
v___x_137_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__16));
v___x_138_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__17));
v___x_139_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__18));
v___y_64_ = v___y_104_;
v___y_65_ = v_names_114_;
v___y_66_ = v_a_120_;
v_fst_67_ = v___x_137_;
v_fst_68_ = v___x_138_;
v_snd_69_ = v___x_139_;
goto v___jp_63_;
}
case 14:
{
lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; 
v___x_140_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__16));
v___x_141_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__17));
v___x_142_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__19));
v___y_64_ = v___y_104_;
v___y_65_ = v_names_114_;
v___y_66_ = v_a_120_;
v_fst_67_ = v___x_140_;
v_fst_68_ = v___x_141_;
v_snd_69_ = v___x_142_;
goto v___jp_63_;
}
case 15:
{
lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; 
v___x_143_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__16));
v___x_144_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__17));
v___x_145_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__20));
v___y_64_ = v___y_104_;
v___y_65_ = v_names_114_;
v___y_66_ = v_a_120_;
v_fst_67_ = v___x_143_;
v_fst_68_ = v___x_144_;
v_snd_69_ = v___x_145_;
goto v___jp_63_;
}
case 16:
{
lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; 
v___x_146_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__16));
v___x_147_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__17));
v___x_148_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__21));
v___y_64_ = v___y_104_;
v___y_65_ = v_names_114_;
v___y_66_ = v_a_120_;
v_fst_67_ = v___x_146_;
v_fst_68_ = v___x_147_;
v_snd_69_ = v___x_148_;
goto v___jp_63_;
}
case 12:
{
lean_object* v_msg_149_; lean_object* v___x_150_; lean_object* v___x_151_; 
v_msg_149_ = lean_ctor_get(v_a_136_, 0);
lean_inc_ref(v_msg_149_);
lean_dec_ref_known(v_a_136_, 1);
v___x_150_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__16));
v___x_151_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__22));
v___y_64_ = v___y_104_;
v___y_65_ = v_names_114_;
v___y_66_ = v_a_120_;
v_fst_67_ = v___x_150_;
v_fst_68_ = v___x_151_;
v_snd_69_ = v_msg_149_;
goto v___jp_63_;
}
default: 
{
lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; 
v___x_152_ = l_Lean_Options_empty;
v___x_153_ = l_Lean_Kernel_Exception_toMessageData(v_a_136_, v___x_152_);
v___x_154_ = l_Lean_MessageData_toString(v___x_153_);
v___x_155_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__23));
v___x_156_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__24));
v___y_64_ = v___y_104_;
v___y_65_ = v_names_114_;
v___y_66_ = v_a_120_;
v_fst_67_ = v___x_155_;
v_fst_68_ = v___x_156_;
v_snd_69_ = v___x_154_;
goto v___jp_63_;
}
}
}
else
{
lean_object* v_a_157_; lean_object* v___x_158_; 
v_a_157_ = lean_ctor_get(v___x_135_, 0);
lean_inc_n(v_a_157_, 2);
lean_dec_ref_known(v___x_135_, 1);
v___x_158_ = lean_environment_find(v_a_157_, v___x_124_);
if (lean_obj_tag(v___x_158_) == 1)
{
lean_object* v_val_159_; lean_object* v___x_161_; uint8_t v_isShared_162_; uint8_t v_isSharedCheck_252_; 
v_val_159_ = lean_ctor_get(v___x_158_, 0);
v_isSharedCheck_252_ = !lean_is_exclusive(v___x_158_);
if (v_isSharedCheck_252_ == 0)
{
v___x_161_ = v___x_158_;
v_isShared_162_ = v_isSharedCheck_252_;
goto v_resetjp_160_;
}
else
{
lean_inc(v_val_159_);
lean_dec(v___x_158_);
v___x_161_ = lean_box(0);
v_isShared_162_ = v_isSharedCheck_252_;
goto v_resetjp_160_;
}
v_resetjp_160_:
{
if (lean_obj_tag(v_val_159_) == 2)
{
lean_object* v_val_163_; lean_object* v___x_165_; uint8_t v_isShared_166_; uint8_t v_isSharedCheck_251_; 
v_val_163_ = lean_ctor_get(v_val_159_, 0);
v_isSharedCheck_251_ = !lean_is_exclusive(v_val_159_);
if (v_isSharedCheck_251_ == 0)
{
v___x_165_ = v_val_159_;
v_isShared_166_ = v_isSharedCheck_251_;
goto v_resetjp_164_;
}
else
{
lean_inc(v_val_163_);
lean_dec(v_val_159_);
v___x_165_ = lean_box(0);
v_isShared_166_ = v_isSharedCheck_251_;
goto v_resetjp_164_;
}
v_resetjp_164_:
{
lean_object* v_toConstantVal_167_; lean_object* v_value_168_; lean_object* v_levelParams_169_; lean_object* v_type_170_; uint8_t v___x_171_; 
v_toConstantVal_167_ = lean_ctor_get(v_val_163_, 0);
lean_inc_ref(v_toConstantVal_167_);
v_value_168_ = lean_ctor_get(v_val_163_, 1);
lean_inc_ref(v_value_168_);
lean_dec_ref(v_val_163_);
v_levelParams_169_ = lean_ctor_get(v_toConstantVal_167_, 1);
lean_inc(v_levelParams_169_);
v_type_170_ = lean_ctor_get(v_toConstantVal_167_, 2);
lean_inc_ref(v_type_170_);
lean_dec_ref(v_toConstantVal_167_);
v___x_171_ = lean_expr_equal(v_type_170_, v___y_100_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_type_170_);
if (v___x_171_ == 0)
{
lean_dec(v_levelParams_169_);
lean_dec_ref(v_value_168_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_157_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v_candidate_58_);
goto v___jp_89_;
}
else
{
if (v___x_125_ == 0)
{
uint8_t v___x_172_; 
v___x_172_ = l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(v_levelParams_169_, v___y_106_);
lean_dec(v___y_106_);
lean_dec(v_levelParams_169_);
if (v___x_172_ == 0)
{
lean_dec_ref(v_value_168_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_157_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_107_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v_candidate_58_);
goto v___jp_89_;
}
else
{
uint8_t v___x_173_; 
v___x_173_ = lean_expr_equal(v_value_168_, v_candidate_58_);
lean_dec_ref(v_candidate_58_);
lean_dec_ref(v_value_168_);
if (v___x_173_ == 0)
{
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_157_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_107_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
goto v___jp_89_;
}
else
{
lean_object* v_constants_174_; lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; lean_object* v___x_179_; 
v_constants_174_ = lean_ctor_get(v_a_157_, 0);
lean_inc_ref(v_constants_174_);
lean_dec(v_a_157_);
v___x_175_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_checkProof___closed__26, &lp_proofEnvironment_OCMEnvironment_checkProof___closed__26_once, _init_lp_proofEnvironment_OCMEnvironment_checkProof___closed__26);
v___x_176_ = l_Lean_SMap_fold___at___00Lean_getRevAliases_spec__0___redArg(v___f_98_, v___x_175_, v_constants_174_);
lean_dec_ref(v_constants_174_);
v___x_177_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__27));
v___x_178_ = lp_proofEnvironment_OCMEnvironment_dependencyClosure(v___x_176_, v___x_177_, v___y_107_);
lean_dec_ref(v___y_107_);
v___x_179_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_178_);
if (lean_obj_tag(v___x_179_) == 0)
{
lean_object* v_a_180_; lean_object* v_names_181_; lean_object* v___x_183_; uint8_t v_isShared_184_; uint8_t v_isSharedCheck_241_; 
v_a_180_ = lean_ctor_get(v___x_179_, 0);
lean_inc(v_a_180_);
lean_dec_ref_known(v___x_179_, 1);
v_names_181_ = lean_ctor_get(v_a_180_, 0);
v_isSharedCheck_241_ = !lean_is_exclusive(v_a_180_);
if (v_isSharedCheck_241_ == 0)
{
lean_object* v_unused_242_; 
v_unused_242_ = lean_ctor_get(v_a_180_, 1);
lean_dec(v_unused_242_);
v___x_183_ = v_a_180_;
v_isShared_184_ = v_isSharedCheck_241_;
goto v_resetjp_182_;
}
else
{
lean_inc(v_names_181_);
lean_dec(v_a_180_);
v___x_183_ = lean_box(0);
v_isShared_184_ = v_isSharedCheck_241_;
goto v_resetjp_182_;
}
v_resetjp_182_:
{
lean_object* v___x_185_; lean_object* v___x_186_; 
v___x_185_ = lp_proofEnvironment_OCMEnvironment_axiomNames(v___x_176_, v_names_181_, v___y_101_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v_names_181_);
lean_dec(v___x_176_);
v___x_186_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_185_);
if (lean_obj_tag(v___x_186_) == 0)
{
lean_object* v_a_187_; lean_object* v___x_189_; uint8_t v_isShared_190_; uint8_t v_isSharedCheck_232_; 
v_a_187_ = lean_ctor_get(v___x_186_, 0);
v_isSharedCheck_232_ = !lean_is_exclusive(v___x_186_);
if (v_isSharedCheck_232_ == 0)
{
v___x_189_ = v___x_186_;
v_isShared_190_ = v_isSharedCheck_232_;
goto v_resetjp_188_;
}
else
{
lean_inc(v_a_187_);
lean_dec(v___x_186_);
v___x_189_ = lean_box(0);
v_isShared_190_ = v_isSharedCheck_232_;
goto v_resetjp_188_;
}
v_resetjp_188_:
{
lean_object* v___x_191_; lean_object* v___x_192_; uint8_t v___x_193_; 
v___x_191_ = lean_array_get_size(v_a_187_);
v___x_192_ = lean_array_get_size(v_a_120_);
v___x_193_ = lean_nat_dec_eq(v___x_191_, v___x_192_);
if (v___x_193_ == 0)
{
lean_del_object(v___x_189_);
lean_dec(v_a_187_);
lean_del_object(v___x_183_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_104_);
goto v___jp_60_;
}
else
{
uint8_t v___x_194_; 
v___x_194_ = l_Array_isEqvAux___at___00Lean_Meta_instBEqAbstractMVarsResult_beq_spec__0___redArg(v_a_187_, v_a_120_, v___x_191_);
lean_dec(v_a_187_);
if (v___x_194_ == 0)
{
lean_del_object(v___x_189_);
lean_del_object(v___x_183_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_104_);
goto v___jp_60_;
}
else
{
lean_object* v_size_195_; lean_object* v___x_197_; uint8_t v_isShared_198_; uint8_t v_isSharedCheck_230_; 
v_size_195_ = lean_ctor_get(v___y_104_, 0);
v_isSharedCheck_230_ = !lean_is_exclusive(v___y_104_);
if (v_isSharedCheck_230_ == 0)
{
lean_object* v_unused_231_; 
v_unused_231_ = lean_ctor_get(v___y_104_, 1);
lean_dec(v_unused_231_);
v___x_197_ = v___y_104_;
v_isShared_198_ = v_isSharedCheck_230_;
goto v_resetjp_196_;
}
else
{
lean_inc(v_size_195_);
lean_dec(v___y_104_);
v___x_197_ = lean_box(0);
v_isShared_198_ = v_isSharedCheck_230_;
goto v_resetjp_196_;
}
v_resetjp_196_:
{
lean_object* v___x_199_; lean_object* v___x_200_; lean_object* v___x_201_; lean_object* v___x_202_; lean_object* v___x_203_; lean_object* v___x_204_; lean_object* v___x_206_; 
v___x_199_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__2));
v___x_200_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__28));
v___x_201_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__29));
v___x_202_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__30));
v___x_203_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__3));
v___x_204_ = l_Lean_JsonNumber_fromNat(v_size_195_);
if (v_isShared_166_ == 0)
{
lean_ctor_set(v___x_165_, 0, v___x_204_);
v___x_206_ = v___x_165_;
goto v_reusejp_205_;
}
else
{
lean_object* v_reuseFailAlloc_229_; 
v_reuseFailAlloc_229_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_229_, 0, v___x_204_);
v___x_206_ = v_reuseFailAlloc_229_;
goto v_reusejp_205_;
}
v_reusejp_205_:
{
lean_object* v___x_208_; 
if (v_isShared_198_ == 0)
{
lean_ctor_set(v___x_197_, 1, v___x_206_);
lean_ctor_set(v___x_197_, 0, v___x_203_);
v___x_208_ = v___x_197_;
goto v_reusejp_207_;
}
else
{
lean_object* v_reuseFailAlloc_228_; 
v_reuseFailAlloc_228_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_228_, 0, v___x_203_);
lean_ctor_set(v_reuseFailAlloc_228_, 1, v___x_206_);
v___x_208_ = v_reuseFailAlloc_228_;
goto v_reusejp_207_;
}
v_reusejp_207_:
{
lean_object* v___x_209_; lean_object* v___x_210_; lean_object* v___x_211_; lean_object* v___x_213_; 
v___x_209_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__31));
v___x_210_ = lean_array_get_size(v_names_114_);
v___x_211_ = l_Lean_JsonNumber_fromNat(v___x_210_);
if (v_isShared_162_ == 0)
{
lean_ctor_set_tag(v___x_161_, 2);
lean_ctor_set(v___x_161_, 0, v___x_211_);
v___x_213_ = v___x_161_;
goto v_reusejp_212_;
}
else
{
lean_object* v_reuseFailAlloc_227_; 
v_reuseFailAlloc_227_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_227_, 0, v___x_211_);
v___x_213_ = v_reuseFailAlloc_227_;
goto v_reusejp_212_;
}
v_reusejp_212_:
{
lean_object* v___x_215_; 
if (v_isShared_184_ == 0)
{
lean_ctor_set(v___x_183_, 1, v___x_213_);
lean_ctor_set(v___x_183_, 0, v___x_209_);
v___x_215_ = v___x_183_;
goto v_reusejp_214_;
}
else
{
lean_object* v_reuseFailAlloc_226_; 
v_reuseFailAlloc_226_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_226_, 0, v___x_209_);
lean_ctor_set(v_reuseFailAlloc_226_, 1, v___x_213_);
v___x_215_ = v_reuseFailAlloc_226_;
goto v_reusejp_214_;
}
v_reusejp_214_:
{
lean_object* v___x_217_; 
if (v_isShared_117_ == 0)
{
lean_ctor_set_tag(v___x_116_, 1);
lean_ctor_set(v___x_116_, 1, v___x_127_);
lean_ctor_set(v___x_116_, 0, v___x_215_);
v___x_217_ = v___x_116_;
goto v_reusejp_216_;
}
else
{
lean_object* v_reuseFailAlloc_225_; 
v_reuseFailAlloc_225_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_225_, 0, v___x_215_);
lean_ctor_set(v_reuseFailAlloc_225_, 1, v___x_127_);
v___x_217_ = v_reuseFailAlloc_225_;
goto v_reusejp_216_;
}
v_reusejp_216_:
{
lean_object* v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; lean_object* v___x_221_; lean_object* v___x_223_; 
v___x_218_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_218_, 0, v___x_208_);
lean_ctor_set(v___x_218_, 1, v___x_217_);
v___x_219_ = l_Lean_Json_mkObj(v___x_218_);
lean_dec_ref_known(v___x_218_, 2);
v___x_220_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__32));
v___x_221_ = lp_proofEnvironment_OCMEnvironment_result(v___x_199_, v___x_200_, v___x_201_, v___x_202_, v___x_219_, v_names_114_, v_a_120_, v___x_220_);
if (v_isShared_190_ == 0)
{
lean_ctor_set(v___x_189_, 0, v___x_221_);
v___x_223_ = v___x_189_;
goto v_reusejp_222_;
}
else
{
lean_object* v_reuseFailAlloc_224_; 
v_reuseFailAlloc_224_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_224_, 0, v___x_221_);
v___x_223_ = v_reuseFailAlloc_224_;
goto v_reusejp_222_;
}
v_reusejp_222_:
{
return v___x_223_;
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_233_; lean_object* v___x_235_; uint8_t v_isShared_236_; uint8_t v_isSharedCheck_240_; 
lean_del_object(v___x_183_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_104_);
v_a_233_ = lean_ctor_get(v___x_186_, 0);
v_isSharedCheck_240_ = !lean_is_exclusive(v___x_186_);
if (v_isSharedCheck_240_ == 0)
{
v___x_235_ = v___x_186_;
v_isShared_236_ = v_isSharedCheck_240_;
goto v_resetjp_234_;
}
else
{
lean_inc(v_a_233_);
lean_dec(v___x_186_);
v___x_235_ = lean_box(0);
v_isShared_236_ = v_isSharedCheck_240_;
goto v_resetjp_234_;
}
v_resetjp_234_:
{
lean_object* v___x_238_; 
if (v_isShared_236_ == 0)
{
v___x_238_ = v___x_235_;
goto v_reusejp_237_;
}
else
{
lean_object* v_reuseFailAlloc_239_; 
v_reuseFailAlloc_239_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_239_, 0, v_a_233_);
v___x_238_ = v_reuseFailAlloc_239_;
goto v_reusejp_237_;
}
v_reusejp_237_:
{
return v___x_238_;
}
}
}
}
}
else
{
lean_object* v_a_243_; lean_object* v___x_245_; uint8_t v_isShared_246_; uint8_t v_isSharedCheck_250_; 
lean_dec(v___x_176_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
v_a_243_ = lean_ctor_get(v___x_179_, 0);
v_isSharedCheck_250_ = !lean_is_exclusive(v___x_179_);
if (v_isSharedCheck_250_ == 0)
{
v___x_245_ = v___x_179_;
v_isShared_246_ = v_isSharedCheck_250_;
goto v_resetjp_244_;
}
else
{
lean_inc(v_a_243_);
lean_dec(v___x_179_);
v___x_245_ = lean_box(0);
v_isShared_246_ = v_isSharedCheck_250_;
goto v_resetjp_244_;
}
v_resetjp_244_:
{
lean_object* v___x_248_; 
if (v_isShared_246_ == 0)
{
v___x_248_ = v___x_245_;
goto v_reusejp_247_;
}
else
{
lean_object* v_reuseFailAlloc_249_; 
v_reuseFailAlloc_249_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_249_, 0, v_a_243_);
v___x_248_ = v_reuseFailAlloc_249_;
goto v_reusejp_247_;
}
v_reusejp_247_:
{
return v___x_248_;
}
}
}
}
}
}
else
{
lean_dec(v_levelParams_169_);
lean_dec_ref(v_value_168_);
lean_del_object(v___x_165_);
lean_del_object(v___x_161_);
lean_dec(v_a_157_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v_candidate_58_);
goto v___jp_89_;
}
}
}
}
else
{
lean_del_object(v___x_161_);
lean_dec(v_val_159_);
lean_dec(v_a_157_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_candidate_58_);
goto v___jp_92_;
}
}
}
else
{
lean_dec(v___x_158_);
lean_dec(v_a_157_);
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_candidate_58_);
goto v___jp_92_;
}
}
}
else
{
lean_object* v___x_253_; lean_object* v___x_255_; 
lean_dec(v_a_120_);
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_108_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec(v___y_103_);
lean_dec(v___y_102_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_candidate_58_);
v___x_253_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkProof___closed__34));
if (v_isShared_123_ == 0)
{
lean_ctor_set_tag(v___x_122_, 1);
lean_ctor_set(v___x_122_, 0, v___x_253_);
v___x_255_ = v___x_122_;
goto v_reusejp_254_;
}
else
{
lean_object* v_reuseFailAlloc_256_; 
v_reuseFailAlloc_256_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_256_, 0, v___x_253_);
v___x_255_ = v_reuseFailAlloc_256_;
goto v_reusejp_254_;
}
v_reusejp_254_:
{
return v___x_255_;
}
}
}
}
else
{
lean_object* v_a_258_; lean_object* v___x_260_; uint8_t v_isShared_261_; uint8_t v_isSharedCheck_265_; 
lean_del_object(v___x_116_);
lean_dec_ref(v_names_114_);
lean_dec_ref(v___y_108_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec(v___y_103_);
lean_dec(v___y_102_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_candidate_58_);
v_a_258_ = lean_ctor_get(v___x_119_, 0);
v_isSharedCheck_265_ = !lean_is_exclusive(v___x_119_);
if (v_isSharedCheck_265_ == 0)
{
v___x_260_ = v___x_119_;
v_isShared_261_ = v_isSharedCheck_265_;
goto v_resetjp_259_;
}
else
{
lean_inc(v_a_258_);
lean_dec(v___x_119_);
v___x_260_ = lean_box(0);
v_isShared_261_ = v_isSharedCheck_265_;
goto v_resetjp_259_;
}
v_resetjp_259_:
{
lean_object* v___x_263_; 
if (v_isShared_261_ == 0)
{
v___x_263_ = v___x_260_;
goto v_reusejp_262_;
}
else
{
lean_object* v_reuseFailAlloc_264_; 
v_reuseFailAlloc_264_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_264_, 0, v_a_258_);
v___x_263_ = v_reuseFailAlloc_264_;
goto v_reusejp_262_;
}
v_reusejp_262_:
{
return v___x_263_;
}
}
}
}
}
else
{
lean_object* v_a_268_; lean_object* v___x_270_; uint8_t v_isShared_271_; uint8_t v_isSharedCheck_275_; 
lean_dec_ref(v___y_108_);
lean_dec_ref(v___y_107_);
lean_dec(v___y_106_);
lean_dec_ref(v___y_104_);
lean_dec(v___y_103_);
lean_dec(v___y_102_);
lean_dec_ref(v___y_101_);
lean_dec_ref(v___y_100_);
lean_dec_ref(v_candidate_58_);
v_a_268_ = lean_ctor_get(v___x_112_, 0);
v_isSharedCheck_275_ = !lean_is_exclusive(v___x_112_);
if (v_isSharedCheck_275_ == 0)
{
v___x_270_ = v___x_112_;
v_isShared_271_ = v_isSharedCheck_275_;
goto v_resetjp_269_;
}
else
{
lean_inc(v_a_268_);
lean_dec(v___x_112_);
v___x_270_ = lean_box(0);
v_isShared_271_ = v_isSharedCheck_275_;
goto v_resetjp_269_;
}
v_resetjp_269_:
{
lean_object* v___x_273_; 
if (v_isShared_271_ == 0)
{
v___x_273_ = v___x_270_;
goto v_reusejp_272_;
}
else
{
lean_object* v_reuseFailAlloc_274_; 
v_reuseFailAlloc_274_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_274_, 0, v_a_268_);
v___x_273_ = v_reuseFailAlloc_274_;
goto v_reusejp_272_;
}
v_reusejp_272_:
{
return v___x_273_;
}
}
}
}
v___jp_276_:
{
lean_object* v_target_281_; lean_object* v_excluded_282_; lean_object* v_axioms_283_; lean_object* v_maxHeartbeats_284_; lean_object* v_maxRecDepth_285_; lean_object* v_levelParams_286_; lean_object* v_type_287_; lean_object* v___x_288_; lean_object* v_size_289_; lean_object* v_buckets_290_; lean_object* v___x_291_; lean_object* v___x_292_; lean_object* v___x_293_; uint8_t v___x_294_; 
v_target_281_ = lean_ctor_get(v___y_278_, 0);
lean_inc_ref(v_target_281_);
v_excluded_282_ = lean_ctor_get(v___y_278_, 2);
lean_inc_ref(v_excluded_282_);
v_axioms_283_ = lean_ctor_get(v___y_278_, 3);
lean_inc_ref(v_axioms_283_);
v_maxHeartbeats_284_ = lean_ctor_get(v___y_278_, 4);
lean_inc(v_maxHeartbeats_284_);
v_maxRecDepth_285_ = lean_ctor_get(v___y_278_, 5);
lean_inc(v_maxRecDepth_285_);
lean_dec_ref(v___y_278_);
v_levelParams_286_ = lean_ctor_get(v_target_281_, 1);
lean_inc(v_levelParams_286_);
v_type_287_ = lean_ctor_get(v_target_281_, 2);
lean_inc_ref_n(v_type_287_, 2);
lean_dec_ref(v_target_281_);
v___x_288_ = lp_proofEnvironment_OCMEnvironment_exprDependencies(v_type_287_);
v_size_289_ = lean_ctor_get(v___x_288_, 0);
lean_inc(v_size_289_);
v_buckets_290_ = lean_ctor_get(v___x_288_, 1);
lean_inc_ref(v_buckets_290_);
lean_dec_ref(v___x_288_);
v___x_291_ = lean_mk_empty_array_with_capacity(v_size_289_);
lean_dec(v_size_289_);
v___x_292_ = lean_unsigned_to_nat(0u);
v___x_293_ = lean_array_get_size(v_buckets_290_);
v___x_294_ = lean_nat_dec_lt(v___x_292_, v___x_293_);
if (v___x_294_ == 0)
{
lean_dec_ref(v_buckets_290_);
v___y_100_ = v_type_287_;
v___y_101_ = v_axioms_283_;
v___y_102_ = v_maxRecDepth_285_;
v___y_103_ = v_maxHeartbeats_284_;
v___y_104_ = v___y_277_;
v___y_105_ = v___y_280_;
v___y_106_ = v_levelParams_286_;
v___y_107_ = v_excluded_282_;
v___y_108_ = v___y_279_;
v___y_109_ = v___x_291_;
goto v___jp_99_;
}
else
{
uint8_t v___x_295_; 
v___x_295_ = lean_nat_dec_le(v___x_293_, v___x_293_);
if (v___x_295_ == 0)
{
if (v___x_294_ == 0)
{
lean_dec_ref(v_buckets_290_);
v___y_100_ = v_type_287_;
v___y_101_ = v_axioms_283_;
v___y_102_ = v_maxRecDepth_285_;
v___y_103_ = v_maxHeartbeats_284_;
v___y_104_ = v___y_277_;
v___y_105_ = v___y_280_;
v___y_106_ = v_levelParams_286_;
v___y_107_ = v_excluded_282_;
v___y_108_ = v___y_279_;
v___y_109_ = v___x_291_;
goto v___jp_99_;
}
else
{
size_t v___x_296_; size_t v___x_297_; lean_object* v___x_298_; 
v___x_296_ = ((size_t)0ULL);
v___x_297_ = lean_usize_of_nat(v___x_293_);
v___x_298_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_290_, v___x_296_, v___x_297_, v___x_291_);
lean_dec_ref(v_buckets_290_);
v___y_100_ = v_type_287_;
v___y_101_ = v_axioms_283_;
v___y_102_ = v_maxRecDepth_285_;
v___y_103_ = v_maxHeartbeats_284_;
v___y_104_ = v___y_277_;
v___y_105_ = v___y_280_;
v___y_106_ = v_levelParams_286_;
v___y_107_ = v_excluded_282_;
v___y_108_ = v___y_279_;
v___y_109_ = v___x_298_;
goto v___jp_99_;
}
}
else
{
size_t v___x_299_; size_t v___x_300_; lean_object* v___x_301_; 
v___x_299_ = ((size_t)0ULL);
v___x_300_ = lean_usize_of_nat(v___x_293_);
v___x_301_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_290_, v___x_299_, v___x_300_, v___x_291_);
lean_dec_ref(v_buckets_290_);
v___y_100_ = v_type_287_;
v___y_101_ = v_axioms_283_;
v___y_102_ = v_maxRecDepth_285_;
v___y_103_ = v_maxHeartbeats_284_;
v___y_104_ = v___y_277_;
v___y_105_ = v___y_280_;
v___y_106_ = v_levelParams_286_;
v___y_107_ = v_excluded_282_;
v___y_108_ = v___y_279_;
v___y_109_ = v___x_301_;
goto v___jp_99_;
}
}
}
v___jp_302_:
{
if (v___y_303_ == 0)
{
uint8_t v___x_304_; 
v___x_304_ = l_Lean_Expr_hasLooseBVars(v_candidate_58_);
if (v___x_304_ == 0)
{
lean_object* v_env_305_; lean_object* v_constants_306_; lean_object* v_policy_307_; lean_object* v___x_308_; lean_object* v_size_309_; lean_object* v_buckets_310_; lean_object* v___x_311_; lean_object* v___x_312_; lean_object* v___x_313_; uint8_t v___x_314_; 
v_env_305_ = lean_ctor_get(v_prepared_57_, 0);
lean_inc_ref(v_env_305_);
v_constants_306_ = lean_ctor_get(v_prepared_57_, 1);
lean_inc_ref(v_constants_306_);
v_policy_307_ = lean_ctor_get(v_prepared_57_, 2);
lean_inc_ref(v_policy_307_);
lean_dec_ref(v_prepared_57_);
lean_inc_ref(v_candidate_58_);
v___x_308_ = lp_proofEnvironment_OCMEnvironment_exprDependencies(v_candidate_58_);
v_size_309_ = lean_ctor_get(v___x_308_, 0);
lean_inc(v_size_309_);
v_buckets_310_ = lean_ctor_get(v___x_308_, 1);
lean_inc_ref(v_buckets_310_);
lean_dec_ref(v___x_308_);
v___x_311_ = lean_mk_empty_array_with_capacity(v_size_309_);
lean_dec(v_size_309_);
v___x_312_ = lean_unsigned_to_nat(0u);
v___x_313_ = lean_array_get_size(v_buckets_310_);
v___x_314_ = lean_nat_dec_lt(v___x_312_, v___x_313_);
if (v___x_314_ == 0)
{
lean_dec_ref(v_buckets_310_);
v___y_277_ = v_constants_306_;
v___y_278_ = v_policy_307_;
v___y_279_ = v_env_305_;
v___y_280_ = v___x_311_;
goto v___jp_276_;
}
else
{
uint8_t v___x_315_; 
v___x_315_ = lean_nat_dec_le(v___x_313_, v___x_313_);
if (v___x_315_ == 0)
{
if (v___x_314_ == 0)
{
lean_dec_ref(v_buckets_310_);
v___y_277_ = v_constants_306_;
v___y_278_ = v_policy_307_;
v___y_279_ = v_env_305_;
v___y_280_ = v___x_311_;
goto v___jp_276_;
}
else
{
size_t v___x_316_; size_t v___x_317_; lean_object* v___x_318_; 
v___x_316_ = ((size_t)0ULL);
v___x_317_ = lean_usize_of_nat(v___x_313_);
v___x_318_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_310_, v___x_316_, v___x_317_, v___x_311_);
lean_dec_ref(v_buckets_310_);
v___y_277_ = v_constants_306_;
v___y_278_ = v_policy_307_;
v___y_279_ = v_env_305_;
v___y_280_ = v___x_318_;
goto v___jp_276_;
}
}
else
{
size_t v___x_319_; size_t v___x_320_; lean_object* v___x_321_; 
v___x_319_ = ((size_t)0ULL);
v___x_320_ = lean_usize_of_nat(v___x_313_);
v___x_321_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_310_, v___x_319_, v___x_320_, v___x_311_);
lean_dec_ref(v_buckets_310_);
v___y_277_ = v_constants_306_;
v___y_278_ = v_policy_307_;
v___y_279_ = v_env_305_;
v___y_280_ = v___x_321_;
goto v___jp_276_;
}
}
}
else
{
lean_dec_ref(v_candidate_58_);
lean_dec_ref(v_prepared_57_);
goto v___jp_95_;
}
}
else
{
lean_dec_ref(v_candidate_58_);
lean_dec_ref(v_prepared_57_);
goto v___jp_95_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_checkProof___boxed(lean_object* v_prepared_324_, lean_object* v_candidate_325_, lean_object* v_a_326_){
_start:
{
lean_object* v_res_327_; 
v_res_327_ = lp_proofEnvironment_OCMEnvironment_checkProof(v_prepared_324_, v_candidate_325_);
return v_res_327_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Prepare(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Check(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Prepare(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
