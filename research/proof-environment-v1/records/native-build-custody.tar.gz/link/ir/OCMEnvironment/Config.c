// Lean compiler output
// Module: OCMEnvironment.Config
// Imports: public import Init public meta import Init public import OCMEnvironment.Packet public import OCMEnvironment.Prepare
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Json_getObjValAs_x3f___at___00Lean_Server_Test_Runner_Client_instFromJsonSubexprInfo_fromJson_spec__1(lean_object*, lean_object*);
lean_object* l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(lean_object*, size_t, size_t, lean_object*);
lean_object* l_Lean_Json_getObjVal_x3f(lean_object*, lean_object*);
lean_object* l_Lean_Json_getArr_x3f(lean_object*);
size_t lean_array_size(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_fromJson_x3f___at___00Lean_Json_getObjValAs_x3f___at___00Lean_Server_Test_Runner_Client_instFromJsonHyp_fromJson_spec__1_spec__2_spec__4(size_t, size_t, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lp_proofEnvironment_OCMEnvironment_natural(lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Do_Internal_VCGen_Frontend_0__Lean_Elab_Tactic_Do_Internal_elabRemainingInvariants_spec__4___redArg(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_keys(lean_object*, lean_object*);
uint8_t l_List_elem___at___00__private_Lean_Server_Completion_CompletionCollectors_0__Lean_Server_Completion_bestLabelForDecl_x3f_spec__0(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(lean_object*, lean_object*);
uint8_t l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(lean_object*, lean_object*);
uint8_t lean_expr_eqv(lean_object*, lean_object*);
lean_object* l_Lean_NameHashSet_insert(lean_object*, lean_object*);
lean_object* l_IO_FS_readFile(lean_object*);
lean_object* l_Lean_Json_parse(lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_readJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "\n"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_readJson___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_readJson___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_readJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "NONCANONICAL_JSON"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_readJson___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_readJson___closed__1_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_readJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_readJson___closed__1_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_readJson___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_readJson___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readJson(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readJson___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getString(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getString___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getNat(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getNat___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getStrings(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getStrings___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterMapTR_go___at___00OCMEnvironment_lookupName_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterMapTR_go___at___00OCMEnvironment_lookupName_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_lookupName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "UNKNOWN_OR_AMBIGUOUS_NAME "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_lookupName___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_lookupName___closed__0_value;
static const lean_array_object lp_proofEnvironment_OCMEnvironment_lookupName___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_lookupName___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_lookupName___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_lookupName(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_lookupName___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_packetName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "TARGET_NAME_INDEX "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_packetName___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_packetName___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetName(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetName___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_packetExpr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "EXPRESSION_ROOT_INDEX "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_packetExpr___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_packetExpr___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetExpr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetExpr___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_targetFrom_spec__1(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_targetFrom_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_targetFrom_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_targetFrom_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_targetFrom___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "TARGET_UNIVERSE_PARAMETERS"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_targetFrom___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_targetFrom___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "target_root"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_targetFrom___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___closed__3;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_targetFrom___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "target_level_params"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "max_heartbeats"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "max_rec_depth"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "KERNEL_LIMIT_RANGE"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__2_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__4;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "schema"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "target"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "roots"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "excluded"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "axioms"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__1_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__5_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__5_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__6_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__7_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__3_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__7_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__2_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__8_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__5_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__9_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__2_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__10_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__11_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__12_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__13_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "ocm.proof-environment.policy.v1"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__14_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "POLICY_SCHEMA"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__15 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__15_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__16 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__16_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "SOURCE_TARGET_NOT_THEOREM"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__17 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__17_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__17_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__18 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__18_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "INDEPENDENT_TARGET_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__19 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__19_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__19_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__20 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__20_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "target_name_index"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "allowed"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "normalization"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__2_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__3_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__4_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__5_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__5_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__6_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__7_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__5_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__7_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__2_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__8_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__9_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__10_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__11_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__12_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 38, .m_capacity = 38, .m_length = 37, .m_data = "ocm.proof-environment.registration.v1"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__13_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "REGISTRATION_SCHEMA"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__14_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__15 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__15_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 68, .m_capacity = 68, .m_length = 67, .m_data = "lean4export-3.1.0:metadata-erasure,let-nondep-false,alpha-interning"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__16 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__16_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "NORMALIZATION_VERSION"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__17 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__17_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__17_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__18 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__18_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "REGISTERED_NAME_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__19 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__19_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__19_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__20 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__20_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "REGISTERED_MEMBERSHIP_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__21 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__21_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__21_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__22 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__22_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readJson(lean_object* v_path_5_){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = l_IO_FS_readFile(v_path_5_);
if (lean_obj_tag(v___x_7_) == 0)
{
lean_object* v_a_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
v_a_8_ = lean_ctor_get(v___x_7_, 0);
lean_inc_n(v_a_8_, 2);
lean_dec_ref_known(v___x_7_, 1);
v___x_9_ = l_Lean_Json_parse(v_a_8_);
v___x_10_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_9_);
if (lean_obj_tag(v___x_10_) == 0)
{
lean_object* v_a_11_; lean_object* v___x_12_; uint8_t v___x_13_; 
v_a_11_ = lean_ctor_get(v___x_10_, 0);
lean_inc(v_a_11_);
v___x_12_ = l_Lean_Json_compress(v_a_11_);
v___x_13_ = lean_string_dec_eq(v_a_8_, v___x_12_);
if (v___x_13_ == 0)
{
lean_object* v___x_14_; lean_object* v___x_15_; uint8_t v___x_16_; 
v___x_14_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_readJson___closed__0));
v___x_15_ = lean_string_append(v___x_12_, v___x_14_);
v___x_16_ = lean_string_dec_eq(v_a_8_, v___x_15_);
lean_dec_ref(v___x_15_);
lean_dec(v_a_8_);
if (v___x_16_ == 0)
{
lean_object* v___x_18_; uint8_t v_isShared_19_; uint8_t v_isSharedCheck_24_; 
v_isSharedCheck_24_ = !lean_is_exclusive(v___x_10_);
if (v_isSharedCheck_24_ == 0)
{
lean_object* v_unused_25_; 
v_unused_25_ = lean_ctor_get(v___x_10_, 0);
lean_dec(v_unused_25_);
v___x_18_ = v___x_10_;
v_isShared_19_ = v_isSharedCheck_24_;
goto v_resetjp_17_;
}
else
{
lean_dec(v___x_10_);
v___x_18_ = lean_box(0);
v_isShared_19_ = v_isSharedCheck_24_;
goto v_resetjp_17_;
}
v_resetjp_17_:
{
lean_object* v___x_20_; lean_object* v___x_22_; 
v___x_20_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_readJson___closed__2));
if (v_isShared_19_ == 0)
{
lean_ctor_set_tag(v___x_18_, 1);
lean_ctor_set(v___x_18_, 0, v___x_20_);
v___x_22_ = v___x_18_;
goto v_reusejp_21_;
}
else
{
lean_object* v_reuseFailAlloc_23_; 
v_reuseFailAlloc_23_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_23_, 0, v___x_20_);
v___x_22_ = v_reuseFailAlloc_23_;
goto v_reusejp_21_;
}
v_reusejp_21_:
{
return v___x_22_;
}
}
}
else
{
return v___x_10_;
}
}
else
{
lean_dec_ref(v___x_12_);
lean_dec(v_a_8_);
return v___x_10_;
}
}
else
{
lean_dec(v_a_8_);
return v___x_10_;
}
}
else
{
lean_object* v_a_26_; lean_object* v___x_28_; uint8_t v_isShared_29_; uint8_t v_isSharedCheck_33_; 
v_a_26_ = lean_ctor_get(v___x_7_, 0);
v_isSharedCheck_33_ = !lean_is_exclusive(v___x_7_);
if (v_isSharedCheck_33_ == 0)
{
v___x_28_ = v___x_7_;
v_isShared_29_ = v_isSharedCheck_33_;
goto v_resetjp_27_;
}
else
{
lean_inc(v_a_26_);
lean_dec(v___x_7_);
v___x_28_ = lean_box(0);
v_isShared_29_ = v_isSharedCheck_33_;
goto v_resetjp_27_;
}
v_resetjp_27_:
{
lean_object* v___x_31_; 
if (v_isShared_29_ == 0)
{
v___x_31_ = v___x_28_;
goto v_reusejp_30_;
}
else
{
lean_object* v_reuseFailAlloc_32_; 
v_reuseFailAlloc_32_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_32_, 0, v_a_26_);
v___x_31_ = v_reuseFailAlloc_32_;
goto v_reusejp_30_;
}
v_reusejp_30_:
{
return v___x_31_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readJson___boxed(lean_object* v_path_34_, lean_object* v_a_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_proofEnvironment_OCMEnvironment_readJson(v_path_34_);
lean_dec_ref(v_path_34_);
return v_res_36_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getString(lean_object* v_j_37_, lean_object* v_k_38_){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; 
v___x_40_ = l_Lean_Json_getObjValAs_x3f___at___00Lean_Server_Test_Runner_Client_instFromJsonSubexprInfo_fromJson_spec__1(v_j_37_, v_k_38_);
v___x_41_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_40_);
return v___x_41_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getString___boxed(lean_object* v_j_42_, lean_object* v_k_43_, lean_object* v_a_44_){
_start:
{
lean_object* v_res_45_; 
v_res_45_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_42_, v_k_43_);
lean_dec_ref(v_k_43_);
return v_res_45_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getNat(lean_object* v_j_46_, lean_object* v_k_47_){
_start:
{
lean_object* v___x_49_; 
v___x_49_ = l_Lean_Json_getObjVal_x3f(v_j_46_, v_k_47_);
if (lean_obj_tag(v___x_49_) == 0)
{
lean_object* v_a_50_; lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_58_; 
v_a_50_ = lean_ctor_get(v___x_49_, 0);
v_isSharedCheck_58_ = !lean_is_exclusive(v___x_49_);
if (v_isSharedCheck_58_ == 0)
{
v___x_52_ = v___x_49_;
v_isShared_53_ = v_isSharedCheck_58_;
goto v_resetjp_51_;
}
else
{
lean_inc(v_a_50_);
lean_dec(v___x_49_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_58_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___x_55_; 
if (v_isShared_53_ == 0)
{
v___x_55_ = v___x_52_;
goto v_reusejp_54_;
}
else
{
lean_object* v_reuseFailAlloc_57_; 
v_reuseFailAlloc_57_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_57_, 0, v_a_50_);
v___x_55_ = v_reuseFailAlloc_57_;
goto v_reusejp_54_;
}
v_reusejp_54_:
{
lean_object* v___x_56_; 
v___x_56_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_55_);
return v___x_56_;
}
}
}
else
{
lean_object* v_a_59_; lean_object* v___x_60_; lean_object* v___x_61_; 
v_a_59_ = lean_ctor_get(v___x_49_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___x_49_, 1);
v___x_60_ = lp_proofEnvironment_OCMEnvironment_natural(v_a_59_);
v___x_61_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_60_);
return v___x_61_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getNat___boxed(lean_object* v_j_62_, lean_object* v_k_63_, lean_object* v_a_64_){
_start:
{
lean_object* v_res_65_; 
v_res_65_ = lp_proofEnvironment_OCMEnvironment_getNat(v_j_62_, v_k_63_);
lean_dec_ref(v_k_63_);
return v_res_65_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getStrings(lean_object* v_j_66_, lean_object* v_k_67_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = l_Lean_Json_getObjVal_x3f(v_j_66_, v_k_67_);
if (lean_obj_tag(v___x_69_) == 0)
{
lean_object* v_a_70_; lean_object* v___x_72_; uint8_t v_isShared_73_; uint8_t v_isSharedCheck_78_; 
v_a_70_ = lean_ctor_get(v___x_69_, 0);
v_isSharedCheck_78_ = !lean_is_exclusive(v___x_69_);
if (v_isSharedCheck_78_ == 0)
{
v___x_72_ = v___x_69_;
v_isShared_73_ = v_isSharedCheck_78_;
goto v_resetjp_71_;
}
else
{
lean_inc(v_a_70_);
lean_dec(v___x_69_);
v___x_72_ = lean_box(0);
v_isShared_73_ = v_isSharedCheck_78_;
goto v_resetjp_71_;
}
v_resetjp_71_:
{
lean_object* v___x_75_; 
if (v_isShared_73_ == 0)
{
v___x_75_ = v___x_72_;
goto v_reusejp_74_;
}
else
{
lean_object* v_reuseFailAlloc_77_; 
v_reuseFailAlloc_77_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_77_, 0, v_a_70_);
v___x_75_ = v_reuseFailAlloc_77_;
goto v_reusejp_74_;
}
v_reusejp_74_:
{
lean_object* v___x_76_; 
v___x_76_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_75_);
return v___x_76_;
}
}
}
else
{
lean_object* v_a_79_; lean_object* v___x_80_; 
v_a_79_ = lean_ctor_get(v___x_69_, 0);
lean_inc(v_a_79_);
lean_dec_ref_known(v___x_69_, 1);
v___x_80_ = l_Lean_Json_getArr_x3f(v_a_79_);
if (lean_obj_tag(v___x_80_) == 0)
{
lean_object* v_a_81_; lean_object* v___x_83_; uint8_t v_isShared_84_; uint8_t v_isSharedCheck_89_; 
v_a_81_ = lean_ctor_get(v___x_80_, 0);
v_isSharedCheck_89_ = !lean_is_exclusive(v___x_80_);
if (v_isSharedCheck_89_ == 0)
{
v___x_83_ = v___x_80_;
v_isShared_84_ = v_isSharedCheck_89_;
goto v_resetjp_82_;
}
else
{
lean_inc(v_a_81_);
lean_dec(v___x_80_);
v___x_83_ = lean_box(0);
v_isShared_84_ = v_isSharedCheck_89_;
goto v_resetjp_82_;
}
v_resetjp_82_:
{
lean_object* v___x_86_; 
if (v_isShared_84_ == 0)
{
v___x_86_ = v___x_83_;
goto v_reusejp_85_;
}
else
{
lean_object* v_reuseFailAlloc_88_; 
v_reuseFailAlloc_88_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_88_, 0, v_a_81_);
v___x_86_ = v_reuseFailAlloc_88_;
goto v_reusejp_85_;
}
v_reusejp_85_:
{
lean_object* v___x_87_; 
v___x_87_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_86_);
return v___x_87_;
}
}
}
else
{
lean_object* v_a_90_; size_t v_sz_91_; size_t v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; 
v_a_90_ = lean_ctor_get(v___x_80_, 0);
lean_inc(v_a_90_);
lean_dec_ref_known(v___x_80_, 1);
v_sz_91_ = lean_array_size(v_a_90_);
v___x_92_ = ((size_t)0ULL);
v___x_93_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_fromJson_x3f___at___00Lean_Json_getObjValAs_x3f___at___00Lean_Server_Test_Runner_Client_instFromJsonHyp_fromJson_spec__1_spec__2_spec__4(v_sz_91_, v___x_92_, v_a_90_);
v___x_94_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_93_);
return v___x_94_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_getStrings___boxed(lean_object* v_j_95_, lean_object* v_k_96_, lean_object* v_a_97_){
_start:
{
lean_object* v_res_98_; 
v_res_98_ = lp_proofEnvironment_OCMEnvironment_getStrings(v_j_95_, v_k_96_);
lean_dec_ref(v_k_96_);
return v_res_98_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterMapTR_go___at___00OCMEnvironment_lookupName_spec__0(lean_object* v_s_99_, lean_object* v_a_100_, lean_object* v_a_101_){
_start:
{
if (lean_obj_tag(v_a_100_) == 0)
{
lean_object* v___x_102_; 
v___x_102_ = lean_array_to_list(v_a_101_);
return v___x_102_;
}
else
{
lean_object* v_head_103_; lean_object* v_tail_104_; lean_object* v_fst_105_; uint8_t v___x_106_; lean_object* v___x_107_; uint8_t v___x_108_; 
v_head_103_ = lean_ctor_get(v_a_100_, 0);
lean_inc(v_head_103_);
v_tail_104_ = lean_ctor_get(v_a_100_, 1);
lean_inc(v_tail_104_);
lean_dec_ref_known(v_a_100_, 2);
v_fst_105_ = lean_ctor_get(v_head_103_, 0);
lean_inc_n(v_fst_105_, 2);
lean_dec(v_head_103_);
v___x_106_ = 1;
v___x_107_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_105_, v___x_106_);
v___x_108_ = lean_string_dec_eq(v___x_107_, v_s_99_);
lean_dec_ref(v___x_107_);
if (v___x_108_ == 0)
{
lean_dec(v_fst_105_);
v_a_100_ = v_tail_104_;
goto _start;
}
else
{
lean_object* v___x_110_; 
v___x_110_ = lean_array_push(v_a_101_, v_fst_105_);
v_a_100_ = v_tail_104_;
v_a_101_ = v___x_110_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterMapTR_go___at___00OCMEnvironment_lookupName_spec__0___boxed(lean_object* v_s_112_, lean_object* v_a_113_, lean_object* v_a_114_){
_start:
{
lean_object* v_res_115_; 
v_res_115_ = lp_proofEnvironment_List_filterMapTR_go___at___00OCMEnvironment_lookupName_spec__0(v_s_112_, v_a_113_, v_a_114_);
lean_dec_ref(v_s_112_);
return v_res_115_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_lookupName(lean_object* v_constants_119_, lean_object* v_s_120_){
_start:
{
lean_object* v___y_126_; lean_object* v_buckets_132_; lean_object* v___x_133_; lean_object* v___x_134_; lean_object* v___x_135_; uint8_t v___x_136_; 
v_buckets_132_ = lean_ctor_get(v_constants_119_, 1);
v___x_133_ = lean_box(0);
v___x_134_ = lean_array_get_size(v_buckets_132_);
v___x_135_ = lean_unsigned_to_nat(0u);
v___x_136_ = lean_nat_dec_lt(v___x_135_, v___x_134_);
if (v___x_136_ == 0)
{
v___y_126_ = v___x_133_;
goto v___jp_125_;
}
else
{
size_t v___x_137_; size_t v___x_138_; lean_object* v___x_139_; 
v___x_137_ = lean_usize_of_nat(v___x_134_);
v___x_138_ = ((size_t)0ULL);
v___x_139_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(v_buckets_132_, v___x_137_, v___x_138_, v___x_133_);
v___y_126_ = v___x_139_;
goto v___jp_125_;
}
v___jp_121_:
{
lean_object* v___x_122_; lean_object* v___x_123_; lean_object* v___x_124_; 
v___x_122_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_lookupName___closed__0));
v___x_123_ = lean_string_append(v___x_122_, v_s_120_);
v___x_124_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_124_, 0, v___x_123_);
return v___x_124_;
}
v___jp_125_:
{
lean_object* v___x_127_; lean_object* v_names_128_; 
v___x_127_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_lookupName___closed__1));
v_names_128_ = lp_proofEnvironment_List_filterMapTR_go___at___00OCMEnvironment_lookupName_spec__0(v_s_120_, v___y_126_, v___x_127_);
if (lean_obj_tag(v_names_128_) == 1)
{
lean_object* v_tail_129_; 
v_tail_129_ = lean_ctor_get(v_names_128_, 1);
lean_inc(v_tail_129_);
if (lean_obj_tag(v_tail_129_) == 0)
{
lean_object* v_head_130_; lean_object* v___x_131_; 
v_head_130_ = lean_ctor_get(v_names_128_, 0);
lean_inc(v_head_130_);
lean_dec_ref_known(v_names_128_, 2);
v___x_131_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_131_, 0, v_head_130_);
return v___x_131_;
}
else
{
lean_dec(v_tail_129_);
lean_dec_ref_known(v_names_128_, 2);
goto v___jp_121_;
}
}
else
{
lean_dec(v_names_128_);
goto v___jp_121_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_lookupName___boxed(lean_object* v_constants_140_, lean_object* v_s_141_){
_start:
{
lean_object* v_res_142_; 
v_res_142_ = lp_proofEnvironment_OCMEnvironment_lookupName(v_constants_140_, v_s_141_);
lean_dec_ref(v_s_141_);
lean_dec_ref(v_constants_140_);
return v_res_142_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetName(lean_object* v_p_144_, lean_object* v_id_145_){
_start:
{
lean_object* v_state_147_; lean_object* v_nameMap_148_; lean_object* v___x_149_; 
v_state_147_ = lean_ctor_get(v_p_144_, 0);
v_nameMap_148_ = lean_ctor_get(v_state_147_, 1);
v___x_149_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Do_Internal_VCGen_Frontend_0__Lean_Elab_Tactic_Do_Internal_elabRemainingInvariants_spec__4___redArg(v_nameMap_148_, v_id_145_);
if (lean_obj_tag(v___x_149_) == 1)
{
lean_object* v_val_150_; lean_object* v___x_152_; uint8_t v_isShared_153_; uint8_t v_isSharedCheck_157_; 
lean_dec(v_id_145_);
v_val_150_ = lean_ctor_get(v___x_149_, 0);
v_isSharedCheck_157_ = !lean_is_exclusive(v___x_149_);
if (v_isSharedCheck_157_ == 0)
{
v___x_152_ = v___x_149_;
v_isShared_153_ = v_isSharedCheck_157_;
goto v_resetjp_151_;
}
else
{
lean_inc(v_val_150_);
lean_dec(v___x_149_);
v___x_152_ = lean_box(0);
v_isShared_153_ = v_isSharedCheck_157_;
goto v_resetjp_151_;
}
v_resetjp_151_:
{
lean_object* v___x_155_; 
if (v_isShared_153_ == 0)
{
lean_ctor_set_tag(v___x_152_, 0);
v___x_155_ = v___x_152_;
goto v_reusejp_154_;
}
else
{
lean_object* v_reuseFailAlloc_156_; 
v_reuseFailAlloc_156_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_156_, 0, v_val_150_);
v___x_155_ = v_reuseFailAlloc_156_;
goto v_reusejp_154_;
}
v_reusejp_154_:
{
return v___x_155_;
}
}
}
else
{
lean_object* v___x_158_; lean_object* v___x_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; 
lean_dec(v___x_149_);
v___x_158_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_packetName___closed__0));
v___x_159_ = l_Nat_reprFast(v_id_145_);
v___x_160_ = lean_string_append(v___x_158_, v___x_159_);
lean_dec_ref(v___x_159_);
v___x_161_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_161_, 0, v___x_160_);
v___x_162_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_162_, 0, v___x_161_);
return v___x_162_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetName___boxed(lean_object* v_p_163_, lean_object* v_id_164_, lean_object* v_a_165_){
_start:
{
lean_object* v_res_166_; 
v_res_166_ = lp_proofEnvironment_OCMEnvironment_packetName(v_p_163_, v_id_164_);
lean_dec_ref(v_p_163_);
return v_res_166_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetExpr(lean_object* v_p_168_, lean_object* v_id_169_){
_start:
{
lean_object* v_state_171_; lean_object* v_exprMap_172_; lean_object* v___x_173_; 
v_state_171_ = lean_ctor_get(v_p_168_, 0);
v_exprMap_172_ = lean_ctor_get(v_state_171_, 3);
v___x_173_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Elab_Tactic_Do_Internal_VCGen_Frontend_0__Lean_Elab_Tactic_Do_Internal_elabRemainingInvariants_spec__4___redArg(v_exprMap_172_, v_id_169_);
if (lean_obj_tag(v___x_173_) == 1)
{
lean_object* v_val_174_; lean_object* v___x_176_; uint8_t v_isShared_177_; uint8_t v_isSharedCheck_181_; 
lean_dec(v_id_169_);
v_val_174_ = lean_ctor_get(v___x_173_, 0);
v_isSharedCheck_181_ = !lean_is_exclusive(v___x_173_);
if (v_isSharedCheck_181_ == 0)
{
v___x_176_ = v___x_173_;
v_isShared_177_ = v_isSharedCheck_181_;
goto v_resetjp_175_;
}
else
{
lean_inc(v_val_174_);
lean_dec(v___x_173_);
v___x_176_ = lean_box(0);
v_isShared_177_ = v_isSharedCheck_181_;
goto v_resetjp_175_;
}
v_resetjp_175_:
{
lean_object* v___x_179_; 
if (v_isShared_177_ == 0)
{
lean_ctor_set_tag(v___x_176_, 0);
v___x_179_ = v___x_176_;
goto v_reusejp_178_;
}
else
{
lean_object* v_reuseFailAlloc_180_; 
v_reuseFailAlloc_180_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_180_, 0, v_val_174_);
v___x_179_ = v_reuseFailAlloc_180_;
goto v_reusejp_178_;
}
v_reusejp_178_:
{
return v___x_179_;
}
}
}
else
{
lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; lean_object* v___x_185_; lean_object* v___x_186_; 
lean_dec(v___x_173_);
v___x_182_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_packetExpr___closed__0));
v___x_183_ = l_Nat_reprFast(v_id_169_);
v___x_184_ = lean_string_append(v___x_182_, v___x_183_);
lean_dec_ref(v___x_183_);
v___x_185_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_185_, 0, v___x_184_);
v___x_186_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_186_, 0, v___x_185_);
return v___x_186_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_packetExpr___boxed(lean_object* v_p_187_, lean_object* v_id_188_, lean_object* v_a_189_){
_start:
{
lean_object* v_res_190_; 
v_res_190_ = lp_proofEnvironment_OCMEnvironment_packetExpr(v_p_187_, v_id_188_);
lean_dec_ref(v_p_187_);
return v_res_190_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_targetFrom_spec__1(size_t v_sz_191_, size_t v_i_192_, lean_object* v_bs_193_){
_start:
{
uint8_t v___x_194_; 
v___x_194_ = lean_usize_dec_lt(v_i_192_, v_sz_191_);
if (v___x_194_ == 0)
{
lean_object* v___x_195_; 
v___x_195_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_195_, 0, v_bs_193_);
return v___x_195_;
}
else
{
lean_object* v_v_196_; lean_object* v___x_197_; 
v_v_196_ = lean_array_uget_borrowed(v_bs_193_, v_i_192_);
lean_inc(v_v_196_);
v___x_197_ = lp_proofEnvironment_OCMEnvironment_natural(v_v_196_);
if (lean_obj_tag(v___x_197_) == 0)
{
lean_object* v_a_198_; lean_object* v___x_200_; uint8_t v_isShared_201_; uint8_t v_isSharedCheck_205_; 
lean_dec_ref(v_bs_193_);
v_a_198_ = lean_ctor_get(v___x_197_, 0);
v_isSharedCheck_205_ = !lean_is_exclusive(v___x_197_);
if (v_isSharedCheck_205_ == 0)
{
v___x_200_ = v___x_197_;
v_isShared_201_ = v_isSharedCheck_205_;
goto v_resetjp_199_;
}
else
{
lean_inc(v_a_198_);
lean_dec(v___x_197_);
v___x_200_ = lean_box(0);
v_isShared_201_ = v_isSharedCheck_205_;
goto v_resetjp_199_;
}
v_resetjp_199_:
{
lean_object* v___x_203_; 
if (v_isShared_201_ == 0)
{
v___x_203_ = v___x_200_;
goto v_reusejp_202_;
}
else
{
lean_object* v_reuseFailAlloc_204_; 
v_reuseFailAlloc_204_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_204_, 0, v_a_198_);
v___x_203_ = v_reuseFailAlloc_204_;
goto v_reusejp_202_;
}
v_reusejp_202_:
{
return v___x_203_;
}
}
}
else
{
lean_object* v_a_206_; lean_object* v___x_207_; lean_object* v_bs_x27_208_; size_t v___x_209_; size_t v___x_210_; lean_object* v___x_211_; 
v_a_206_ = lean_ctor_get(v___x_197_, 0);
lean_inc(v_a_206_);
lean_dec_ref_known(v___x_197_, 1);
v___x_207_ = lean_unsigned_to_nat(0u);
v_bs_x27_208_ = lean_array_uset(v_bs_193_, v_i_192_, v___x_207_);
v___x_209_ = ((size_t)1ULL);
v___x_210_ = lean_usize_add(v_i_192_, v___x_209_);
v___x_211_ = lean_array_uset(v_bs_x27_208_, v_i_192_, v_a_206_);
v_i_192_ = v___x_210_;
v_bs_193_ = v___x_211_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_targetFrom_spec__1___boxed(lean_object* v_sz_213_, lean_object* v_i_214_, lean_object* v_bs_215_){
_start:
{
size_t v_sz_boxed_216_; size_t v_i_boxed_217_; lean_object* v_res_218_; 
v_sz_boxed_216_ = lean_unbox_usize(v_sz_213_);
lean_dec(v_sz_213_);
v_i_boxed_217_ = lean_unbox_usize(v_i_214_);
lean_dec(v_i_214_);
v_res_218_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_targetFrom_spec__1(v_sz_boxed_216_, v_i_boxed_217_, v_bs_215_);
return v_res_218_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_targetFrom_spec__0(lean_object* v_p_219_, lean_object* v_x_220_, lean_object* v_x_221_){
_start:
{
if (lean_obj_tag(v_x_220_) == 0)
{
lean_object* v___x_223_; lean_object* v___x_224_; 
v___x_223_ = l_List_reverse___redArg(v_x_221_);
v___x_224_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_224_, 0, v___x_223_);
return v___x_224_;
}
else
{
lean_object* v_head_225_; lean_object* v_tail_226_; lean_object* v___x_228_; uint8_t v_isShared_229_; uint8_t v_isSharedCheck_244_; 
v_head_225_ = lean_ctor_get(v_x_220_, 0);
v_tail_226_ = lean_ctor_get(v_x_220_, 1);
v_isSharedCheck_244_ = !lean_is_exclusive(v_x_220_);
if (v_isSharedCheck_244_ == 0)
{
v___x_228_ = v_x_220_;
v_isShared_229_ = v_isSharedCheck_244_;
goto v_resetjp_227_;
}
else
{
lean_inc(v_tail_226_);
lean_inc(v_head_225_);
lean_dec(v_x_220_);
v___x_228_ = lean_box(0);
v_isShared_229_ = v_isSharedCheck_244_;
goto v_resetjp_227_;
}
v_resetjp_227_:
{
lean_object* v___x_230_; 
v___x_230_ = lp_proofEnvironment_OCMEnvironment_packetName(v_p_219_, v_head_225_);
if (lean_obj_tag(v___x_230_) == 0)
{
lean_object* v_a_231_; lean_object* v___x_233_; 
v_a_231_ = lean_ctor_get(v___x_230_, 0);
lean_inc(v_a_231_);
lean_dec_ref_known(v___x_230_, 1);
if (v_isShared_229_ == 0)
{
lean_ctor_set(v___x_228_, 1, v_x_221_);
lean_ctor_set(v___x_228_, 0, v_a_231_);
v___x_233_ = v___x_228_;
goto v_reusejp_232_;
}
else
{
lean_object* v_reuseFailAlloc_235_; 
v_reuseFailAlloc_235_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_235_, 0, v_a_231_);
lean_ctor_set(v_reuseFailAlloc_235_, 1, v_x_221_);
v___x_233_ = v_reuseFailAlloc_235_;
goto v_reusejp_232_;
}
v_reusejp_232_:
{
v_x_220_ = v_tail_226_;
v_x_221_ = v___x_233_;
goto _start;
}
}
else
{
lean_object* v_a_236_; lean_object* v___x_238_; uint8_t v_isShared_239_; uint8_t v_isSharedCheck_243_; 
lean_del_object(v___x_228_);
lean_dec(v_tail_226_);
lean_dec(v_x_221_);
v_a_236_ = lean_ctor_get(v___x_230_, 0);
v_isSharedCheck_243_ = !lean_is_exclusive(v___x_230_);
if (v_isSharedCheck_243_ == 0)
{
v___x_238_ = v___x_230_;
v_isShared_239_ = v_isSharedCheck_243_;
goto v_resetjp_237_;
}
else
{
lean_inc(v_a_236_);
lean_dec(v___x_230_);
v___x_238_ = lean_box(0);
v_isShared_239_ = v_isSharedCheck_243_;
goto v_resetjp_237_;
}
v_resetjp_237_:
{
lean_object* v___x_241_; 
if (v_isShared_239_ == 0)
{
v___x_241_ = v___x_238_;
goto v_reusejp_240_;
}
else
{
lean_object* v_reuseFailAlloc_242_; 
v_reuseFailAlloc_242_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_242_, 0, v_a_236_);
v___x_241_ = v_reuseFailAlloc_242_;
goto v_reusejp_240_;
}
v_reusejp_240_:
{
return v___x_241_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_targetFrom_spec__0___boxed(lean_object* v_p_245_, lean_object* v_x_246_, lean_object* v_x_247_, lean_object* v___y_248_){
_start:
{
lean_object* v_res_249_; 
v_res_249_ = lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_targetFrom_spec__0(v_p_245_, v_x_246_, v_x_247_);
lean_dec_ref(v_p_245_);
return v_res_249_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_targetFrom___closed__3(void){
_start:
{
lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___x_256_; 
v___x_254_ = lean_box(0);
v___x_255_ = lean_unsigned_to_nat(16u);
v___x_256_ = lean_mk_array(v___x_255_, v___x_254_);
return v___x_256_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4(void){
_start:
{
lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; 
v___x_257_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__3, &lp_proofEnvironment_OCMEnvironment_targetFrom___closed__3_once, _init_lp_proofEnvironment_OCMEnvironment_targetFrom___closed__3);
v___x_258_ = lean_unsigned_to_nat(0u);
v___x_259_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_259_, 0, v___x_258_);
lean_ctor_set(v___x_259_, 1, v___x_257_);
return v___x_259_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom(lean_object* v_j_261_, lean_object* v_p_262_, lean_object* v_name_263_){
_start:
{
lean_object* v___x_268_; lean_object* v___x_269_; 
v___x_268_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_targetFrom___closed__2));
lean_inc(v_j_261_);
v___x_269_ = lp_proofEnvironment_OCMEnvironment_getNat(v_j_261_, v___x_268_);
if (lean_obj_tag(v___x_269_) == 0)
{
lean_object* v_a_270_; lean_object* v___x_271_; 
v_a_270_ = lean_ctor_get(v___x_269_, 0);
lean_inc(v_a_270_);
lean_dec_ref_known(v___x_269_, 1);
v___x_271_ = lp_proofEnvironment_OCMEnvironment_packetExpr(v_p_262_, v_a_270_);
if (lean_obj_tag(v___x_271_) == 0)
{
lean_object* v_a_272_; lean_object* v___x_274_; uint8_t v_isShared_275_; uint8_t v_isSharedCheck_338_; 
v_a_272_ = lean_ctor_get(v___x_271_, 0);
v_isSharedCheck_338_ = !lean_is_exclusive(v___x_271_);
if (v_isSharedCheck_338_ == 0)
{
v___x_274_ = v___x_271_;
v_isShared_275_ = v_isSharedCheck_338_;
goto v_resetjp_273_;
}
else
{
lean_inc(v_a_272_);
lean_dec(v___x_271_);
v___x_274_ = lean_box(0);
v_isShared_275_ = v_isSharedCheck_338_;
goto v_resetjp_273_;
}
v_resetjp_273_:
{
lean_object* v___y_277_; uint8_t v___y_278_; lean_object* v___y_284_; lean_object* v___x_314_; lean_object* v___x_315_; 
v___x_314_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_targetFrom___closed__5));
v___x_315_ = l_Lean_Json_getObjVal_x3f(v_j_261_, v___x_314_);
if (lean_obj_tag(v___x_315_) == 0)
{
lean_object* v_a_316_; lean_object* v___x_318_; uint8_t v_isShared_319_; uint8_t v_isSharedCheck_323_; 
v_a_316_ = lean_ctor_get(v___x_315_, 0);
v_isSharedCheck_323_ = !lean_is_exclusive(v___x_315_);
if (v_isSharedCheck_323_ == 0)
{
v___x_318_ = v___x_315_;
v_isShared_319_ = v_isSharedCheck_323_;
goto v_resetjp_317_;
}
else
{
lean_inc(v_a_316_);
lean_dec(v___x_315_);
v___x_318_ = lean_box(0);
v_isShared_319_ = v_isSharedCheck_323_;
goto v_resetjp_317_;
}
v_resetjp_317_:
{
lean_object* v___x_321_; 
if (v_isShared_319_ == 0)
{
v___x_321_ = v___x_318_;
goto v_reusejp_320_;
}
else
{
lean_object* v_reuseFailAlloc_322_; 
v_reuseFailAlloc_322_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_322_, 0, v_a_316_);
v___x_321_ = v_reuseFailAlloc_322_;
goto v_reusejp_320_;
}
v_reusejp_320_:
{
v___y_284_ = v___x_321_;
goto v___jp_283_;
}
}
}
else
{
lean_object* v_a_324_; lean_object* v___x_325_; 
v_a_324_ = lean_ctor_get(v___x_315_, 0);
lean_inc(v_a_324_);
lean_dec_ref_known(v___x_315_, 1);
v___x_325_ = l_Lean_Json_getArr_x3f(v_a_324_);
if (lean_obj_tag(v___x_325_) == 0)
{
lean_object* v_a_326_; lean_object* v___x_328_; uint8_t v_isShared_329_; uint8_t v_isSharedCheck_333_; 
v_a_326_ = lean_ctor_get(v___x_325_, 0);
v_isSharedCheck_333_ = !lean_is_exclusive(v___x_325_);
if (v_isSharedCheck_333_ == 0)
{
v___x_328_ = v___x_325_;
v_isShared_329_ = v_isSharedCheck_333_;
goto v_resetjp_327_;
}
else
{
lean_inc(v_a_326_);
lean_dec(v___x_325_);
v___x_328_ = lean_box(0);
v_isShared_329_ = v_isSharedCheck_333_;
goto v_resetjp_327_;
}
v_resetjp_327_:
{
lean_object* v___x_331_; 
if (v_isShared_329_ == 0)
{
v___x_331_ = v___x_328_;
goto v_reusejp_330_;
}
else
{
lean_object* v_reuseFailAlloc_332_; 
v_reuseFailAlloc_332_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_332_, 0, v_a_326_);
v___x_331_ = v_reuseFailAlloc_332_;
goto v_reusejp_330_;
}
v_reusejp_330_:
{
v___y_284_ = v___x_331_;
goto v___jp_283_;
}
}
}
else
{
lean_object* v_a_334_; size_t v_sz_335_; size_t v___x_336_; lean_object* v___x_337_; 
v_a_334_ = lean_ctor_get(v___x_325_, 0);
lean_inc(v_a_334_);
lean_dec_ref_known(v___x_325_, 1);
v_sz_335_ = lean_array_size(v_a_334_);
v___x_336_ = ((size_t)0ULL);
v___x_337_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_targetFrom_spec__1(v_sz_335_, v___x_336_, v_a_334_);
v___y_284_ = v___x_337_;
goto v___jp_283_;
}
}
v___jp_276_:
{
if (v___y_278_ == 0)
{
lean_object* v___x_279_; lean_object* v___x_281_; 
v___x_279_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_279_, 0, v_name_263_);
lean_ctor_set(v___x_279_, 1, v___y_277_);
lean_ctor_set(v___x_279_, 2, v_a_272_);
if (v_isShared_275_ == 0)
{
lean_ctor_set(v___x_274_, 0, v___x_279_);
v___x_281_ = v___x_274_;
goto v_reusejp_280_;
}
else
{
lean_object* v_reuseFailAlloc_282_; 
v_reuseFailAlloc_282_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_282_, 0, v___x_279_);
v___x_281_ = v_reuseFailAlloc_282_;
goto v_reusejp_280_;
}
v_reusejp_280_:
{
return v___x_281_;
}
}
else
{
lean_dec(v___y_277_);
lean_del_object(v___x_274_);
lean_dec(v_a_272_);
lean_dec(v_name_263_);
goto v___jp_265_;
}
}
v___jp_283_:
{
lean_object* v___x_285_; 
v___x_285_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___y_284_);
if (lean_obj_tag(v___x_285_) == 0)
{
lean_object* v_a_286_; lean_object* v___x_287_; lean_object* v___x_288_; lean_object* v___x_289_; 
v_a_286_ = lean_ctor_get(v___x_285_, 0);
lean_inc(v_a_286_);
lean_dec_ref_known(v___x_285_, 1);
v___x_287_ = lean_array_to_list(v_a_286_);
v___x_288_ = lean_box(0);
v___x_289_ = lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_targetFrom_spec__0(v_p_262_, v___x_287_, v___x_288_);
if (lean_obj_tag(v___x_289_) == 0)
{
lean_object* v_a_290_; lean_object* v___x_291_; uint8_t v___x_292_; 
v_a_290_ = lean_ctor_get(v___x_289_, 0);
lean_inc(v_a_290_);
lean_dec_ref_known(v___x_289_, 1);
v___x_291_ = lean_box(0);
v___x_292_ = l_List_elem___at___00__private_Lean_Server_Completion_CompletionCollectors_0__Lean_Server_Completion_bestLabelForDecl_x3f_spec__0(v___x_291_, v_a_290_);
if (v___x_292_ == 0)
{
lean_object* v___x_293_; lean_object* v___x_294_; lean_object* v_size_295_; lean_object* v___x_296_; uint8_t v___x_297_; 
v___x_293_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4, &lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4);
v___x_294_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_a_290_, v___x_293_);
v_size_295_ = lean_ctor_get(v___x_294_, 0);
lean_inc(v_size_295_);
lean_dec_ref(v___x_294_);
v___x_296_ = l_List_lengthTR___redArg(v_a_290_);
v___x_297_ = lean_nat_dec_eq(v___x_296_, v_size_295_);
lean_dec(v_size_295_);
lean_dec(v___x_296_);
if (v___x_297_ == 0)
{
lean_dec(v_a_290_);
lean_del_object(v___x_274_);
lean_dec(v_a_272_);
lean_dec(v_name_263_);
goto v___jp_265_;
}
else
{
v___y_277_ = v_a_290_;
v___y_278_ = v___x_292_;
goto v___jp_276_;
}
}
else
{
v___y_277_ = v_a_290_;
v___y_278_ = v___x_292_;
goto v___jp_276_;
}
}
else
{
lean_object* v_a_298_; lean_object* v___x_300_; uint8_t v_isShared_301_; uint8_t v_isSharedCheck_305_; 
lean_del_object(v___x_274_);
lean_dec(v_a_272_);
lean_dec(v_name_263_);
v_a_298_ = lean_ctor_get(v___x_289_, 0);
v_isSharedCheck_305_ = !lean_is_exclusive(v___x_289_);
if (v_isSharedCheck_305_ == 0)
{
v___x_300_ = v___x_289_;
v_isShared_301_ = v_isSharedCheck_305_;
goto v_resetjp_299_;
}
else
{
lean_inc(v_a_298_);
lean_dec(v___x_289_);
v___x_300_ = lean_box(0);
v_isShared_301_ = v_isSharedCheck_305_;
goto v_resetjp_299_;
}
v_resetjp_299_:
{
lean_object* v___x_303_; 
if (v_isShared_301_ == 0)
{
v___x_303_ = v___x_300_;
goto v_reusejp_302_;
}
else
{
lean_object* v_reuseFailAlloc_304_; 
v_reuseFailAlloc_304_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_304_, 0, v_a_298_);
v___x_303_ = v_reuseFailAlloc_304_;
goto v_reusejp_302_;
}
v_reusejp_302_:
{
return v___x_303_;
}
}
}
}
else
{
lean_object* v_a_306_; lean_object* v___x_308_; uint8_t v_isShared_309_; uint8_t v_isSharedCheck_313_; 
lean_del_object(v___x_274_);
lean_dec(v_a_272_);
lean_dec(v_name_263_);
v_a_306_ = lean_ctor_get(v___x_285_, 0);
v_isSharedCheck_313_ = !lean_is_exclusive(v___x_285_);
if (v_isSharedCheck_313_ == 0)
{
v___x_308_ = v___x_285_;
v_isShared_309_ = v_isSharedCheck_313_;
goto v_resetjp_307_;
}
else
{
lean_inc(v_a_306_);
lean_dec(v___x_285_);
v___x_308_ = lean_box(0);
v_isShared_309_ = v_isSharedCheck_313_;
goto v_resetjp_307_;
}
v_resetjp_307_:
{
lean_object* v___x_311_; 
if (v_isShared_309_ == 0)
{
v___x_311_ = v___x_308_;
goto v_reusejp_310_;
}
else
{
lean_object* v_reuseFailAlloc_312_; 
v_reuseFailAlloc_312_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_312_, 0, v_a_306_);
v___x_311_ = v_reuseFailAlloc_312_;
goto v_reusejp_310_;
}
v_reusejp_310_:
{
return v___x_311_;
}
}
}
}
}
}
else
{
lean_object* v_a_339_; lean_object* v___x_341_; uint8_t v_isShared_342_; uint8_t v_isSharedCheck_346_; 
lean_dec(v_name_263_);
lean_dec(v_j_261_);
v_a_339_ = lean_ctor_get(v___x_271_, 0);
v_isSharedCheck_346_ = !lean_is_exclusive(v___x_271_);
if (v_isSharedCheck_346_ == 0)
{
v___x_341_ = v___x_271_;
v_isShared_342_ = v_isSharedCheck_346_;
goto v_resetjp_340_;
}
else
{
lean_inc(v_a_339_);
lean_dec(v___x_271_);
v___x_341_ = lean_box(0);
v_isShared_342_ = v_isSharedCheck_346_;
goto v_resetjp_340_;
}
v_resetjp_340_:
{
lean_object* v___x_344_; 
if (v_isShared_342_ == 0)
{
v___x_344_ = v___x_341_;
goto v_reusejp_343_;
}
else
{
lean_object* v_reuseFailAlloc_345_; 
v_reuseFailAlloc_345_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_345_, 0, v_a_339_);
v___x_344_ = v_reuseFailAlloc_345_;
goto v_reusejp_343_;
}
v_reusejp_343_:
{
return v___x_344_;
}
}
}
}
else
{
lean_object* v_a_347_; lean_object* v___x_349_; uint8_t v_isShared_350_; uint8_t v_isSharedCheck_354_; 
lean_dec(v_name_263_);
lean_dec(v_j_261_);
v_a_347_ = lean_ctor_get(v___x_269_, 0);
v_isSharedCheck_354_ = !lean_is_exclusive(v___x_269_);
if (v_isSharedCheck_354_ == 0)
{
v___x_349_ = v___x_269_;
v_isShared_350_ = v_isSharedCheck_354_;
goto v_resetjp_348_;
}
else
{
lean_inc(v_a_347_);
lean_dec(v___x_269_);
v___x_349_ = lean_box(0);
v_isShared_350_ = v_isSharedCheck_354_;
goto v_resetjp_348_;
}
v_resetjp_348_:
{
lean_object* v___x_352_; 
if (v_isShared_350_ == 0)
{
v___x_352_ = v___x_349_;
goto v_reusejp_351_;
}
else
{
lean_object* v_reuseFailAlloc_353_; 
v_reuseFailAlloc_353_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_353_, 0, v_a_347_);
v___x_352_ = v_reuseFailAlloc_353_;
goto v_reusejp_351_;
}
v_reusejp_351_:
{
return v___x_352_;
}
}
}
v___jp_265_:
{
lean_object* v___x_266_; lean_object* v___x_267_; 
v___x_266_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_targetFrom___closed__1));
v___x_267_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_267_, 0, v___x_266_);
return v___x_267_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_targetFrom___boxed(lean_object* v_j_355_, lean_object* v_p_356_, lean_object* v_name_357_, lean_object* v_a_358_){
_start:
{
lean_object* v_res_359_; 
v_res_359_ = lp_proofEnvironment_OCMEnvironment_targetFrom(v_j_355_, v_p_356_, v_name_357_);
lean_dec_ref(v_p_356_);
return v_res_359_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__4(void){
_start:
{
lean_object* v___x_365_; 
v___x_365_ = lean_cstr_to_nat("18446744073709551615");
return v___x_365_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits(lean_object* v_j_366_){
_start:
{
lean_object* v___x_368_; lean_object* v___x_369_; 
v___x_368_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__0));
lean_inc(v_j_366_);
v___x_369_ = lp_proofEnvironment_OCMEnvironment_getNat(v_j_366_, v___x_368_);
if (lean_obj_tag(v___x_369_) == 0)
{
lean_object* v_a_370_; lean_object* v___x_372_; uint8_t v_isShared_373_; uint8_t v_isSharedCheck_406_; 
v_a_370_ = lean_ctor_get(v___x_369_, 0);
v_isSharedCheck_406_ = !lean_is_exclusive(v___x_369_);
if (v_isSharedCheck_406_ == 0)
{
v___x_372_ = v___x_369_;
v_isShared_373_ = v_isSharedCheck_406_;
goto v_resetjp_371_;
}
else
{
lean_inc(v_a_370_);
lean_dec(v___x_369_);
v___x_372_ = lean_box(0);
v_isShared_373_ = v_isSharedCheck_406_;
goto v_resetjp_371_;
}
v_resetjp_371_:
{
lean_object* v___x_374_; lean_object* v___x_375_; 
v___x_374_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__1));
v___x_375_ = lp_proofEnvironment_OCMEnvironment_getNat(v_j_366_, v___x_374_);
if (lean_obj_tag(v___x_375_) == 0)
{
lean_object* v_a_376_; lean_object* v___x_378_; uint8_t v_isShared_379_; uint8_t v_isSharedCheck_397_; 
v_a_376_ = lean_ctor_get(v___x_375_, 0);
v_isSharedCheck_397_ = !lean_is_exclusive(v___x_375_);
if (v_isSharedCheck_397_ == 0)
{
v___x_378_ = v___x_375_;
v_isShared_379_ = v_isSharedCheck_397_;
goto v_resetjp_377_;
}
else
{
lean_inc(v_a_376_);
lean_dec(v___x_375_);
v___x_378_ = lean_box(0);
v_isShared_379_ = v_isSharedCheck_397_;
goto v_resetjp_377_;
}
v_resetjp_377_:
{
uint8_t v___y_386_; lean_object* v___x_394_; uint8_t v___x_395_; 
v___x_394_ = lean_unsigned_to_nat(0u);
v___x_395_ = lean_nat_dec_eq(v_a_370_, v___x_394_);
if (v___x_395_ == 0)
{
uint8_t v___x_396_; 
v___x_396_ = lean_nat_dec_eq(v_a_376_, v___x_394_);
v___y_386_ = v___x_396_;
goto v___jp_385_;
}
else
{
v___y_386_ = v___x_395_;
goto v___jp_385_;
}
v___jp_380_:
{
lean_object* v___x_381_; lean_object* v___x_383_; 
v___x_381_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__3));
if (v_isShared_379_ == 0)
{
lean_ctor_set_tag(v___x_378_, 1);
lean_ctor_set(v___x_378_, 0, v___x_381_);
v___x_383_ = v___x_378_;
goto v_reusejp_382_;
}
else
{
lean_object* v_reuseFailAlloc_384_; 
v_reuseFailAlloc_384_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_384_, 0, v___x_381_);
v___x_383_ = v_reuseFailAlloc_384_;
goto v_reusejp_382_;
}
v_reusejp_382_:
{
return v___x_383_;
}
}
v___jp_385_:
{
if (v___y_386_ == 0)
{
lean_object* v___x_387_; uint8_t v___x_388_; 
v___x_387_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__4, &lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_kernelLimits___closed__4);
v___x_388_ = lean_nat_dec_lt(v___x_387_, v_a_370_);
if (v___x_388_ == 0)
{
uint8_t v___x_389_; 
v___x_389_ = lean_nat_dec_lt(v___x_387_, v_a_376_);
if (v___x_389_ == 0)
{
lean_object* v___x_390_; lean_object* v___x_392_; 
lean_del_object(v___x_378_);
v___x_390_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_390_, 0, v_a_370_);
lean_ctor_set(v___x_390_, 1, v_a_376_);
if (v_isShared_373_ == 0)
{
lean_ctor_set(v___x_372_, 0, v___x_390_);
v___x_392_ = v___x_372_;
goto v_reusejp_391_;
}
else
{
lean_object* v_reuseFailAlloc_393_; 
v_reuseFailAlloc_393_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_393_, 0, v___x_390_);
v___x_392_ = v_reuseFailAlloc_393_;
goto v_reusejp_391_;
}
v_reusejp_391_:
{
return v___x_392_;
}
}
else
{
lean_dec(v_a_376_);
lean_del_object(v___x_372_);
lean_dec(v_a_370_);
goto v___jp_380_;
}
}
else
{
lean_dec(v_a_376_);
lean_del_object(v___x_372_);
lean_dec(v_a_370_);
goto v___jp_380_;
}
}
else
{
lean_dec(v_a_376_);
lean_del_object(v___x_372_);
lean_dec(v_a_370_);
goto v___jp_380_;
}
}
}
}
else
{
lean_object* v_a_398_; lean_object* v___x_400_; uint8_t v_isShared_401_; uint8_t v_isSharedCheck_405_; 
lean_del_object(v___x_372_);
lean_dec(v_a_370_);
v_a_398_ = lean_ctor_get(v___x_375_, 0);
v_isSharedCheck_405_ = !lean_is_exclusive(v___x_375_);
if (v_isSharedCheck_405_ == 0)
{
v___x_400_ = v___x_375_;
v_isShared_401_ = v_isSharedCheck_405_;
goto v_resetjp_399_;
}
else
{
lean_inc(v_a_398_);
lean_dec(v___x_375_);
v___x_400_ = lean_box(0);
v_isShared_401_ = v_isSharedCheck_405_;
goto v_resetjp_399_;
}
v_resetjp_399_:
{
lean_object* v___x_403_; 
if (v_isShared_401_ == 0)
{
v___x_403_ = v___x_400_;
goto v_reusejp_402_;
}
else
{
lean_object* v_reuseFailAlloc_404_; 
v_reuseFailAlloc_404_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_404_, 0, v_a_398_);
v___x_403_ = v_reuseFailAlloc_404_;
goto v_reusejp_402_;
}
v_reusejp_402_:
{
return v___x_403_;
}
}
}
}
}
else
{
lean_object* v_a_407_; lean_object* v___x_409_; uint8_t v_isShared_410_; uint8_t v_isSharedCheck_414_; 
lean_dec(v_j_366_);
v_a_407_ = lean_ctor_get(v___x_369_, 0);
v_isSharedCheck_414_ = !lean_is_exclusive(v___x_369_);
if (v_isSharedCheck_414_ == 0)
{
v___x_409_ = v___x_369_;
v_isShared_410_ = v_isSharedCheck_414_;
goto v_resetjp_408_;
}
else
{
lean_inc(v_a_407_);
lean_dec(v___x_369_);
v___x_409_ = lean_box(0);
v_isShared_410_ = v_isSharedCheck_414_;
goto v_resetjp_408_;
}
v_resetjp_408_:
{
lean_object* v___x_412_; 
if (v_isShared_410_ == 0)
{
v___x_412_ = v___x_409_;
goto v_reusejp_411_;
}
else
{
lean_object* v_reuseFailAlloc_413_; 
v_reuseFailAlloc_413_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_413_, 0, v_a_407_);
v___x_412_ = v_reuseFailAlloc_413_;
goto v_reusejp_411_;
}
v_reusejp_411_:
{
return v___x_412_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_kernelLimits___boxed(lean_object* v_j_415_, lean_object* v_a_416_){
_start:
{
lean_object* v_res_417_; 
v_res_417_ = lp_proofEnvironment_OCMEnvironment_kernelLimits(v_j_415_);
return v_res_417_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(lean_object* v_source_418_, size_t v_sz_419_, size_t v_i_420_, lean_object* v_bs_421_){
_start:
{
uint8_t v___x_423_; 
v___x_423_ = lean_usize_dec_lt(v_i_420_, v_sz_419_);
if (v___x_423_ == 0)
{
lean_object* v___x_424_; 
v___x_424_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_424_, 0, v_bs_421_);
return v___x_424_;
}
else
{
lean_object* v_v_425_; lean_object* v___x_426_; lean_object* v___x_427_; 
v_v_425_ = lean_array_uget_borrowed(v_bs_421_, v_i_420_);
v___x_426_ = lp_proofEnvironment_OCMEnvironment_lookupName(v_source_418_, v_v_425_);
v___x_427_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_426_);
if (lean_obj_tag(v___x_427_) == 0)
{
lean_object* v_a_428_; lean_object* v___x_429_; lean_object* v_bs_x27_430_; size_t v___x_431_; size_t v___x_432_; lean_object* v___x_433_; 
v_a_428_ = lean_ctor_get(v___x_427_, 0);
lean_inc(v_a_428_);
lean_dec_ref_known(v___x_427_, 1);
v___x_429_ = lean_unsigned_to_nat(0u);
v_bs_x27_430_ = lean_array_uset(v_bs_421_, v_i_420_, v___x_429_);
v___x_431_ = ((size_t)1ULL);
v___x_432_ = lean_usize_add(v_i_420_, v___x_431_);
v___x_433_ = lean_array_uset(v_bs_x27_430_, v_i_420_, v_a_428_);
v_i_420_ = v___x_432_;
v_bs_421_ = v___x_433_;
goto _start;
}
else
{
lean_object* v_a_435_; lean_object* v___x_437_; uint8_t v_isShared_438_; uint8_t v_isSharedCheck_442_; 
lean_dec_ref(v_bs_421_);
v_a_435_ = lean_ctor_get(v___x_427_, 0);
v_isSharedCheck_442_ = !lean_is_exclusive(v___x_427_);
if (v_isSharedCheck_442_ == 0)
{
v___x_437_ = v___x_427_;
v_isShared_438_ = v_isSharedCheck_442_;
goto v_resetjp_436_;
}
else
{
lean_inc(v_a_435_);
lean_dec(v___x_427_);
v___x_437_ = lean_box(0);
v_isShared_438_ = v_isSharedCheck_442_;
goto v_resetjp_436_;
}
v_resetjp_436_:
{
lean_object* v___x_440_; 
if (v_isShared_438_ == 0)
{
v___x_440_ = v___x_437_;
goto v_reusejp_439_;
}
else
{
lean_object* v_reuseFailAlloc_441_; 
v_reuseFailAlloc_441_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_441_, 0, v_a_435_);
v___x_440_ = v_reuseFailAlloc_441_;
goto v_reusejp_439_;
}
v_reusejp_439_:
{
return v___x_440_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0___boxed(lean_object* v_source_443_, lean_object* v_sz_444_, lean_object* v_i_445_, lean_object* v_bs_446_, lean_object* v___y_447_){
_start:
{
size_t v_sz_boxed_448_; size_t v_i_boxed_449_; lean_object* v_res_450_; 
v_sz_boxed_448_ = lean_unbox_usize(v_sz_444_);
lean_dec(v_sz_444_);
v_i_boxed_449_ = lean_unbox_usize(v_i_445_);
lean_dec(v_i_445_);
v_res_450_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(v_source_443_, v_sz_boxed_448_, v_i_boxed_449_, v_bs_446_);
lean_dec_ref(v_source_443_);
return v_res_450_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy(lean_object* v_j_493_, lean_object* v_goal_494_, lean_object* v_source_495_){
_start:
{
lean_object* v___x_497_; lean_object* v___x_498_; lean_object* v___x_499_; lean_object* v___x_500_; lean_object* v___x_501_; lean_object* v___x_502_; lean_object* v___x_503_; lean_object* v___x_504_; 
v___x_497_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0));
v___x_498_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1));
v___x_499_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__2));
v___x_500_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__3));
v___x_501_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4));
v___x_502_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__13));
lean_inc(v_j_493_);
v___x_503_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_493_, v___x_502_);
v___x_504_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_503_);
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; 
lean_dec_ref_known(v___x_504_, 1);
lean_inc(v_j_493_);
v___x_505_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_493_, v___x_497_);
if (lean_obj_tag(v___x_505_) == 0)
{
lean_object* v_a_506_; lean_object* v___x_508_; uint8_t v_isShared_509_; uint8_t v_isSharedCheck_662_; 
v_a_506_ = lean_ctor_get(v___x_505_, 0);
v_isSharedCheck_662_ = !lean_is_exclusive(v___x_505_);
if (v_isSharedCheck_662_ == 0)
{
v___x_508_ = v___x_505_;
v_isShared_509_ = v_isSharedCheck_662_;
goto v_resetjp_507_;
}
else
{
lean_inc(v_a_506_);
lean_dec(v___x_505_);
v___x_508_ = lean_box(0);
v_isShared_509_ = v_isSharedCheck_662_;
goto v_resetjp_507_;
}
v_resetjp_507_:
{
lean_object* v___x_510_; uint8_t v___x_511_; 
v___x_510_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__14));
v___x_511_ = lean_string_dec_eq(v_a_506_, v___x_510_);
lean_dec(v_a_506_);
if (v___x_511_ == 0)
{
lean_object* v___x_512_; lean_object* v___x_514_; 
lean_dec(v_j_493_);
v___x_512_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__16));
if (v_isShared_509_ == 0)
{
lean_ctor_set_tag(v___x_508_, 1);
lean_ctor_set(v___x_508_, 0, v___x_512_);
v___x_514_ = v___x_508_;
goto v_reusejp_513_;
}
else
{
lean_object* v_reuseFailAlloc_515_; 
v_reuseFailAlloc_515_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_515_, 0, v___x_512_);
v___x_514_ = v_reuseFailAlloc_515_;
goto v_reusejp_513_;
}
v_reusejp_513_:
{
return v___x_514_;
}
}
else
{
lean_object* v___x_516_; 
lean_del_object(v___x_508_);
lean_inc(v_j_493_);
v___x_516_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_493_, v___x_498_);
if (lean_obj_tag(v___x_516_) == 0)
{
lean_object* v_a_517_; lean_object* v___x_518_; lean_object* v___x_519_; 
v_a_517_ = lean_ctor_get(v___x_516_, 0);
lean_inc(v_a_517_);
lean_dec_ref_known(v___x_516_, 1);
v___x_518_ = lp_proofEnvironment_OCMEnvironment_lookupName(v_source_495_, v_a_517_);
lean_dec(v_a_517_);
v___x_519_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_518_);
if (lean_obj_tag(v___x_519_) == 0)
{
lean_object* v_a_520_; lean_object* v___x_522_; uint8_t v_isShared_523_; uint8_t v_isSharedCheck_645_; 
v_a_520_ = lean_ctor_get(v___x_519_, 0);
v_isSharedCheck_645_ = !lean_is_exclusive(v___x_519_);
if (v_isSharedCheck_645_ == 0)
{
v___x_522_ = v___x_519_;
v_isShared_523_ = v_isSharedCheck_645_;
goto v_resetjp_521_;
}
else
{
lean_inc(v_a_520_);
lean_dec(v___x_519_);
v___x_522_ = lean_box(0);
v_isShared_523_ = v_isSharedCheck_645_;
goto v_resetjp_521_;
}
v_resetjp_521_:
{
lean_object* v___x_524_; 
lean_inc(v_a_520_);
lean_inc(v_j_493_);
v___x_524_ = lp_proofEnvironment_OCMEnvironment_targetFrom(v_j_493_, v_goal_494_, v_a_520_);
if (lean_obj_tag(v___x_524_) == 0)
{
lean_object* v_a_525_; lean_object* v___x_527_; uint8_t v_isShared_528_; uint8_t v_isSharedCheck_636_; 
v_a_525_ = lean_ctor_get(v___x_524_, 0);
v_isSharedCheck_636_ = !lean_is_exclusive(v___x_524_);
if (v_isSharedCheck_636_ == 0)
{
v___x_527_ = v___x_524_;
v_isShared_528_ = v_isSharedCheck_636_;
goto v_resetjp_526_;
}
else
{
lean_inc(v_a_525_);
lean_dec(v___x_524_);
v___x_527_ = lean_box(0);
v_isShared_528_ = v_isSharedCheck_636_;
goto v_resetjp_526_;
}
v_resetjp_526_:
{
lean_object* v___x_539_; 
v___x_539_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(v_source_495_, v_a_520_);
lean_dec(v_a_520_);
if (lean_obj_tag(v___x_539_) == 1)
{
lean_object* v_val_540_; 
v_val_540_ = lean_ctor_get(v___x_539_, 0);
lean_inc(v_val_540_);
lean_dec_ref_known(v___x_539_, 1);
if (lean_obj_tag(v_val_540_) == 2)
{
lean_object* v_val_541_; lean_object* v_toConstantVal_542_; lean_object* v_levelParams_543_; lean_object* v_type_544_; lean_object* v_levelParams_545_; lean_object* v_type_546_; uint8_t v___x_635_; 
lean_del_object(v___x_527_);
v_val_541_ = lean_ctor_get(v_val_540_, 0);
lean_inc_ref(v_val_541_);
lean_dec_ref_known(v_val_540_, 1);
v_toConstantVal_542_ = lean_ctor_get(v_val_541_, 0);
lean_inc_ref(v_toConstantVal_542_);
lean_dec_ref(v_val_541_);
v_levelParams_543_ = lean_ctor_get(v_toConstantVal_542_, 1);
lean_inc(v_levelParams_543_);
v_type_544_ = lean_ctor_get(v_toConstantVal_542_, 2);
lean_inc_ref(v_type_544_);
lean_dec_ref(v_toConstantVal_542_);
v_levelParams_545_ = lean_ctor_get(v_a_525_, 1);
v_type_546_ = lean_ctor_get(v_a_525_, 2);
v___x_635_ = lean_expr_eqv(v_type_544_, v_type_546_);
lean_dec_ref(v_type_544_);
if (v___x_635_ == 0)
{
if (v___x_511_ == 0)
{
goto v___jp_547_;
}
else
{
lean_dec(v_levelParams_543_);
lean_dec(v_a_525_);
lean_dec(v_j_493_);
goto v___jp_534_;
}
}
else
{
goto v___jp_547_;
}
v___jp_547_:
{
uint8_t v___x_548_; 
v___x_548_ = l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(v_levelParams_543_, v_levelParams_545_);
lean_dec(v_levelParams_543_);
if (v___x_548_ == 0)
{
lean_dec(v_a_525_);
lean_dec(v_j_493_);
goto v___jp_534_;
}
else
{
lean_object* v___x_549_; 
lean_del_object(v___x_522_);
lean_inc(v_j_493_);
v___x_549_ = lp_proofEnvironment_OCMEnvironment_getStrings(v_j_493_, v___x_499_);
if (lean_obj_tag(v___x_549_) == 0)
{
lean_object* v_a_550_; size_t v_sz_551_; size_t v___x_552_; lean_object* v___x_553_; 
v_a_550_ = lean_ctor_get(v___x_549_, 0);
lean_inc(v_a_550_);
lean_dec_ref_known(v___x_549_, 1);
v_sz_551_ = lean_array_size(v_a_550_);
v___x_552_ = ((size_t)0ULL);
v___x_553_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(v_source_495_, v_sz_551_, v___x_552_, v_a_550_);
if (lean_obj_tag(v___x_553_) == 0)
{
lean_object* v_a_554_; lean_object* v___x_555_; 
v_a_554_ = lean_ctor_get(v___x_553_, 0);
lean_inc(v_a_554_);
lean_dec_ref_known(v___x_553_, 1);
lean_inc(v_j_493_);
v___x_555_ = lp_proofEnvironment_OCMEnvironment_getStrings(v_j_493_, v___x_500_);
if (lean_obj_tag(v___x_555_) == 0)
{
lean_object* v_a_556_; size_t v_sz_557_; lean_object* v___x_558_; 
v_a_556_ = lean_ctor_get(v___x_555_, 0);
lean_inc(v_a_556_);
lean_dec_ref_known(v___x_555_, 1);
v_sz_557_ = lean_array_size(v_a_556_);
v___x_558_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(v_source_495_, v_sz_557_, v___x_552_, v_a_556_);
if (lean_obj_tag(v___x_558_) == 0)
{
lean_object* v_a_559_; lean_object* v___x_560_; 
v_a_559_ = lean_ctor_get(v___x_558_, 0);
lean_inc(v_a_559_);
lean_dec_ref_known(v___x_558_, 1);
lean_inc(v_j_493_);
v___x_560_ = lp_proofEnvironment_OCMEnvironment_getStrings(v_j_493_, v___x_501_);
if (lean_obj_tag(v___x_560_) == 0)
{
lean_object* v_a_561_; size_t v_sz_562_; lean_object* v___x_563_; 
v_a_561_ = lean_ctor_get(v___x_560_, 0);
lean_inc(v_a_561_);
lean_dec_ref_known(v___x_560_, 1);
v_sz_562_ = lean_array_size(v_a_561_);
v___x_563_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(v_source_495_, v_sz_562_, v___x_552_, v_a_561_);
if (lean_obj_tag(v___x_563_) == 0)
{
lean_object* v_a_564_; lean_object* v___x_565_; 
v_a_564_ = lean_ctor_get(v___x_563_, 0);
lean_inc(v_a_564_);
lean_dec_ref_known(v___x_563_, 1);
v___x_565_ = lp_proofEnvironment_OCMEnvironment_kernelLimits(v_j_493_);
if (lean_obj_tag(v___x_565_) == 0)
{
lean_object* v_a_566_; lean_object* v___x_568_; uint8_t v_isShared_569_; uint8_t v_isSharedCheck_578_; 
v_a_566_ = lean_ctor_get(v___x_565_, 0);
v_isSharedCheck_578_ = !lean_is_exclusive(v___x_565_);
if (v_isSharedCheck_578_ == 0)
{
v___x_568_ = v___x_565_;
v_isShared_569_ = v_isSharedCheck_578_;
goto v_resetjp_567_;
}
else
{
lean_inc(v_a_566_);
lean_dec(v___x_565_);
v___x_568_ = lean_box(0);
v_isShared_569_ = v_isSharedCheck_578_;
goto v_resetjp_567_;
}
v_resetjp_567_:
{
lean_object* v_fst_570_; lean_object* v_snd_571_; lean_object* v___x_572_; lean_object* v___x_573_; lean_object* v___x_574_; lean_object* v___x_576_; 
v_fst_570_ = lean_ctor_get(v_a_566_, 0);
lean_inc(v_fst_570_);
v_snd_571_ = lean_ctor_get(v_a_566_, 1);
lean_inc(v_snd_571_);
lean_dec(v_a_566_);
v___x_572_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4, &lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4);
v___x_573_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_572_, v_a_559_);
lean_dec(v_a_559_);
v___x_574_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_574_, 0, v_a_525_);
lean_ctor_set(v___x_574_, 1, v_a_554_);
lean_ctor_set(v___x_574_, 2, v___x_573_);
lean_ctor_set(v___x_574_, 3, v_a_564_);
lean_ctor_set(v___x_574_, 4, v_fst_570_);
lean_ctor_set(v___x_574_, 5, v_snd_571_);
if (v_isShared_569_ == 0)
{
lean_ctor_set(v___x_568_, 0, v___x_574_);
v___x_576_ = v___x_568_;
goto v_reusejp_575_;
}
else
{
lean_object* v_reuseFailAlloc_577_; 
v_reuseFailAlloc_577_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_577_, 0, v___x_574_);
v___x_576_ = v_reuseFailAlloc_577_;
goto v_reusejp_575_;
}
v_reusejp_575_:
{
return v___x_576_;
}
}
}
else
{
lean_object* v_a_579_; lean_object* v___x_581_; uint8_t v_isShared_582_; uint8_t v_isSharedCheck_586_; 
lean_dec(v_a_564_);
lean_dec(v_a_559_);
lean_dec(v_a_554_);
lean_dec(v_a_525_);
v_a_579_ = lean_ctor_get(v___x_565_, 0);
v_isSharedCheck_586_ = !lean_is_exclusive(v___x_565_);
if (v_isSharedCheck_586_ == 0)
{
v___x_581_ = v___x_565_;
v_isShared_582_ = v_isSharedCheck_586_;
goto v_resetjp_580_;
}
else
{
lean_inc(v_a_579_);
lean_dec(v___x_565_);
v___x_581_ = lean_box(0);
v_isShared_582_ = v_isSharedCheck_586_;
goto v_resetjp_580_;
}
v_resetjp_580_:
{
lean_object* v___x_584_; 
if (v_isShared_582_ == 0)
{
v___x_584_ = v___x_581_;
goto v_reusejp_583_;
}
else
{
lean_object* v_reuseFailAlloc_585_; 
v_reuseFailAlloc_585_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_585_, 0, v_a_579_);
v___x_584_ = v_reuseFailAlloc_585_;
goto v_reusejp_583_;
}
v_reusejp_583_:
{
return v___x_584_;
}
}
}
}
else
{
lean_object* v_a_587_; lean_object* v___x_589_; uint8_t v_isShared_590_; uint8_t v_isSharedCheck_594_; 
lean_dec(v_a_559_);
lean_dec(v_a_554_);
lean_dec(v_a_525_);
lean_dec(v_j_493_);
v_a_587_ = lean_ctor_get(v___x_563_, 0);
v_isSharedCheck_594_ = !lean_is_exclusive(v___x_563_);
if (v_isSharedCheck_594_ == 0)
{
v___x_589_ = v___x_563_;
v_isShared_590_ = v_isSharedCheck_594_;
goto v_resetjp_588_;
}
else
{
lean_inc(v_a_587_);
lean_dec(v___x_563_);
v___x_589_ = lean_box(0);
v_isShared_590_ = v_isSharedCheck_594_;
goto v_resetjp_588_;
}
v_resetjp_588_:
{
lean_object* v___x_592_; 
if (v_isShared_590_ == 0)
{
v___x_592_ = v___x_589_;
goto v_reusejp_591_;
}
else
{
lean_object* v_reuseFailAlloc_593_; 
v_reuseFailAlloc_593_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_593_, 0, v_a_587_);
v___x_592_ = v_reuseFailAlloc_593_;
goto v_reusejp_591_;
}
v_reusejp_591_:
{
return v___x_592_;
}
}
}
}
else
{
lean_object* v_a_595_; lean_object* v___x_597_; uint8_t v_isShared_598_; uint8_t v_isSharedCheck_602_; 
lean_dec(v_a_559_);
lean_dec(v_a_554_);
lean_dec(v_a_525_);
lean_dec(v_j_493_);
v_a_595_ = lean_ctor_get(v___x_560_, 0);
v_isSharedCheck_602_ = !lean_is_exclusive(v___x_560_);
if (v_isSharedCheck_602_ == 0)
{
v___x_597_ = v___x_560_;
v_isShared_598_ = v_isSharedCheck_602_;
goto v_resetjp_596_;
}
else
{
lean_inc(v_a_595_);
lean_dec(v___x_560_);
v___x_597_ = lean_box(0);
v_isShared_598_ = v_isSharedCheck_602_;
goto v_resetjp_596_;
}
v_resetjp_596_:
{
lean_object* v___x_600_; 
if (v_isShared_598_ == 0)
{
v___x_600_ = v___x_597_;
goto v_reusejp_599_;
}
else
{
lean_object* v_reuseFailAlloc_601_; 
v_reuseFailAlloc_601_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_601_, 0, v_a_595_);
v___x_600_ = v_reuseFailAlloc_601_;
goto v_reusejp_599_;
}
v_reusejp_599_:
{
return v___x_600_;
}
}
}
}
else
{
lean_object* v_a_603_; lean_object* v___x_605_; uint8_t v_isShared_606_; uint8_t v_isSharedCheck_610_; 
lean_dec(v_a_554_);
lean_dec(v_a_525_);
lean_dec(v_j_493_);
v_a_603_ = lean_ctor_get(v___x_558_, 0);
v_isSharedCheck_610_ = !lean_is_exclusive(v___x_558_);
if (v_isSharedCheck_610_ == 0)
{
v___x_605_ = v___x_558_;
v_isShared_606_ = v_isSharedCheck_610_;
goto v_resetjp_604_;
}
else
{
lean_inc(v_a_603_);
lean_dec(v___x_558_);
v___x_605_ = lean_box(0);
v_isShared_606_ = v_isSharedCheck_610_;
goto v_resetjp_604_;
}
v_resetjp_604_:
{
lean_object* v___x_608_; 
if (v_isShared_606_ == 0)
{
v___x_608_ = v___x_605_;
goto v_reusejp_607_;
}
else
{
lean_object* v_reuseFailAlloc_609_; 
v_reuseFailAlloc_609_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_609_, 0, v_a_603_);
v___x_608_ = v_reuseFailAlloc_609_;
goto v_reusejp_607_;
}
v_reusejp_607_:
{
return v___x_608_;
}
}
}
}
else
{
lean_object* v_a_611_; lean_object* v___x_613_; uint8_t v_isShared_614_; uint8_t v_isSharedCheck_618_; 
lean_dec(v_a_554_);
lean_dec(v_a_525_);
lean_dec(v_j_493_);
v_a_611_ = lean_ctor_get(v___x_555_, 0);
v_isSharedCheck_618_ = !lean_is_exclusive(v___x_555_);
if (v_isSharedCheck_618_ == 0)
{
v___x_613_ = v___x_555_;
v_isShared_614_ = v_isSharedCheck_618_;
goto v_resetjp_612_;
}
else
{
lean_inc(v_a_611_);
lean_dec(v___x_555_);
v___x_613_ = lean_box(0);
v_isShared_614_ = v_isSharedCheck_618_;
goto v_resetjp_612_;
}
v_resetjp_612_:
{
lean_object* v___x_616_; 
if (v_isShared_614_ == 0)
{
v___x_616_ = v___x_613_;
goto v_reusejp_615_;
}
else
{
lean_object* v_reuseFailAlloc_617_; 
v_reuseFailAlloc_617_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_617_, 0, v_a_611_);
v___x_616_ = v_reuseFailAlloc_617_;
goto v_reusejp_615_;
}
v_reusejp_615_:
{
return v___x_616_;
}
}
}
}
else
{
lean_object* v_a_619_; lean_object* v___x_621_; uint8_t v_isShared_622_; uint8_t v_isSharedCheck_626_; 
lean_dec(v_a_525_);
lean_dec(v_j_493_);
v_a_619_ = lean_ctor_get(v___x_553_, 0);
v_isSharedCheck_626_ = !lean_is_exclusive(v___x_553_);
if (v_isSharedCheck_626_ == 0)
{
v___x_621_ = v___x_553_;
v_isShared_622_ = v_isSharedCheck_626_;
goto v_resetjp_620_;
}
else
{
lean_inc(v_a_619_);
lean_dec(v___x_553_);
v___x_621_ = lean_box(0);
v_isShared_622_ = v_isSharedCheck_626_;
goto v_resetjp_620_;
}
v_resetjp_620_:
{
lean_object* v___x_624_; 
if (v_isShared_622_ == 0)
{
v___x_624_ = v___x_621_;
goto v_reusejp_623_;
}
else
{
lean_object* v_reuseFailAlloc_625_; 
v_reuseFailAlloc_625_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_625_, 0, v_a_619_);
v___x_624_ = v_reuseFailAlloc_625_;
goto v_reusejp_623_;
}
v_reusejp_623_:
{
return v___x_624_;
}
}
}
}
else
{
lean_object* v_a_627_; lean_object* v___x_629_; uint8_t v_isShared_630_; uint8_t v_isSharedCheck_634_; 
lean_dec(v_a_525_);
lean_dec(v_j_493_);
v_a_627_ = lean_ctor_get(v___x_549_, 0);
v_isSharedCheck_634_ = !lean_is_exclusive(v___x_549_);
if (v_isSharedCheck_634_ == 0)
{
v___x_629_ = v___x_549_;
v_isShared_630_ = v_isSharedCheck_634_;
goto v_resetjp_628_;
}
else
{
lean_inc(v_a_627_);
lean_dec(v___x_549_);
v___x_629_ = lean_box(0);
v_isShared_630_ = v_isSharedCheck_634_;
goto v_resetjp_628_;
}
v_resetjp_628_:
{
lean_object* v___x_632_; 
if (v_isShared_630_ == 0)
{
v___x_632_ = v___x_629_;
goto v_reusejp_631_;
}
else
{
lean_object* v_reuseFailAlloc_633_; 
v_reuseFailAlloc_633_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_633_, 0, v_a_627_);
v___x_632_ = v_reuseFailAlloc_633_;
goto v_reusejp_631_;
}
v_reusejp_631_:
{
return v___x_632_;
}
}
}
}
}
}
else
{
lean_dec(v_val_540_);
lean_dec(v_a_525_);
lean_del_object(v___x_522_);
lean_dec(v_j_493_);
goto v___jp_529_;
}
}
else
{
lean_dec(v___x_539_);
lean_dec(v_a_525_);
lean_del_object(v___x_522_);
lean_dec(v_j_493_);
goto v___jp_529_;
}
v___jp_529_:
{
lean_object* v___x_530_; lean_object* v___x_532_; 
v___x_530_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__18));
if (v_isShared_528_ == 0)
{
lean_ctor_set_tag(v___x_527_, 1);
lean_ctor_set(v___x_527_, 0, v___x_530_);
v___x_532_ = v___x_527_;
goto v_reusejp_531_;
}
else
{
lean_object* v_reuseFailAlloc_533_; 
v_reuseFailAlloc_533_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_533_, 0, v___x_530_);
v___x_532_ = v_reuseFailAlloc_533_;
goto v_reusejp_531_;
}
v_reusejp_531_:
{
return v___x_532_;
}
}
v___jp_534_:
{
lean_object* v___x_535_; lean_object* v___x_537_; 
v___x_535_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__20));
if (v_isShared_523_ == 0)
{
lean_ctor_set_tag(v___x_522_, 1);
lean_ctor_set(v___x_522_, 0, v___x_535_);
v___x_537_ = v___x_522_;
goto v_reusejp_536_;
}
else
{
lean_object* v_reuseFailAlloc_538_; 
v_reuseFailAlloc_538_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_538_, 0, v___x_535_);
v___x_537_ = v_reuseFailAlloc_538_;
goto v_reusejp_536_;
}
v_reusejp_536_:
{
return v___x_537_;
}
}
}
}
else
{
lean_object* v_a_637_; lean_object* v___x_639_; uint8_t v_isShared_640_; uint8_t v_isSharedCheck_644_; 
lean_del_object(v___x_522_);
lean_dec(v_a_520_);
lean_dec(v_j_493_);
v_a_637_ = lean_ctor_get(v___x_524_, 0);
v_isSharedCheck_644_ = !lean_is_exclusive(v___x_524_);
if (v_isSharedCheck_644_ == 0)
{
v___x_639_ = v___x_524_;
v_isShared_640_ = v_isSharedCheck_644_;
goto v_resetjp_638_;
}
else
{
lean_inc(v_a_637_);
lean_dec(v___x_524_);
v___x_639_ = lean_box(0);
v_isShared_640_ = v_isSharedCheck_644_;
goto v_resetjp_638_;
}
v_resetjp_638_:
{
lean_object* v___x_642_; 
if (v_isShared_640_ == 0)
{
v___x_642_ = v___x_639_;
goto v_reusejp_641_;
}
else
{
lean_object* v_reuseFailAlloc_643_; 
v_reuseFailAlloc_643_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_643_, 0, v_a_637_);
v___x_642_ = v_reuseFailAlloc_643_;
goto v_reusejp_641_;
}
v_reusejp_641_:
{
return v___x_642_;
}
}
}
}
}
else
{
lean_object* v_a_646_; lean_object* v___x_648_; uint8_t v_isShared_649_; uint8_t v_isSharedCheck_653_; 
lean_dec(v_j_493_);
v_a_646_ = lean_ctor_get(v___x_519_, 0);
v_isSharedCheck_653_ = !lean_is_exclusive(v___x_519_);
if (v_isSharedCheck_653_ == 0)
{
v___x_648_ = v___x_519_;
v_isShared_649_ = v_isSharedCheck_653_;
goto v_resetjp_647_;
}
else
{
lean_inc(v_a_646_);
lean_dec(v___x_519_);
v___x_648_ = lean_box(0);
v_isShared_649_ = v_isSharedCheck_653_;
goto v_resetjp_647_;
}
v_resetjp_647_:
{
lean_object* v___x_651_; 
if (v_isShared_649_ == 0)
{
v___x_651_ = v___x_648_;
goto v_reusejp_650_;
}
else
{
lean_object* v_reuseFailAlloc_652_; 
v_reuseFailAlloc_652_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_652_, 0, v_a_646_);
v___x_651_ = v_reuseFailAlloc_652_;
goto v_reusejp_650_;
}
v_reusejp_650_:
{
return v___x_651_;
}
}
}
}
else
{
lean_object* v_a_654_; lean_object* v___x_656_; uint8_t v_isShared_657_; uint8_t v_isSharedCheck_661_; 
lean_dec(v_j_493_);
v_a_654_ = lean_ctor_get(v___x_516_, 0);
v_isSharedCheck_661_ = !lean_is_exclusive(v___x_516_);
if (v_isSharedCheck_661_ == 0)
{
v___x_656_ = v___x_516_;
v_isShared_657_ = v_isSharedCheck_661_;
goto v_resetjp_655_;
}
else
{
lean_inc(v_a_654_);
lean_dec(v___x_516_);
v___x_656_ = lean_box(0);
v_isShared_657_ = v_isSharedCheck_661_;
goto v_resetjp_655_;
}
v_resetjp_655_:
{
lean_object* v___x_659_; 
if (v_isShared_657_ == 0)
{
v___x_659_ = v___x_656_;
goto v_reusejp_658_;
}
else
{
lean_object* v_reuseFailAlloc_660_; 
v_reuseFailAlloc_660_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_660_, 0, v_a_654_);
v___x_659_ = v_reuseFailAlloc_660_;
goto v_reusejp_658_;
}
v_reusejp_658_:
{
return v___x_659_;
}
}
}
}
}
}
else
{
lean_object* v_a_663_; lean_object* v___x_665_; uint8_t v_isShared_666_; uint8_t v_isSharedCheck_670_; 
lean_dec(v_j_493_);
v_a_663_ = lean_ctor_get(v___x_505_, 0);
v_isSharedCheck_670_ = !lean_is_exclusive(v___x_505_);
if (v_isSharedCheck_670_ == 0)
{
v___x_665_ = v___x_505_;
v_isShared_666_ = v_isSharedCheck_670_;
goto v_resetjp_664_;
}
else
{
lean_inc(v_a_663_);
lean_dec(v___x_505_);
v___x_665_ = lean_box(0);
v_isShared_666_ = v_isSharedCheck_670_;
goto v_resetjp_664_;
}
v_resetjp_664_:
{
lean_object* v___x_668_; 
if (v_isShared_666_ == 0)
{
v___x_668_ = v___x_665_;
goto v_reusejp_667_;
}
else
{
lean_object* v_reuseFailAlloc_669_; 
v_reuseFailAlloc_669_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_669_, 0, v_a_663_);
v___x_668_ = v_reuseFailAlloc_669_;
goto v_reusejp_667_;
}
v_reusejp_667_:
{
return v___x_668_;
}
}
}
}
else
{
lean_object* v_a_671_; lean_object* v___x_673_; uint8_t v_isShared_674_; uint8_t v_isSharedCheck_678_; 
lean_dec(v_j_493_);
v_a_671_ = lean_ctor_get(v___x_504_, 0);
v_isSharedCheck_678_ = !lean_is_exclusive(v___x_504_);
if (v_isSharedCheck_678_ == 0)
{
v___x_673_ = v___x_504_;
v_isShared_674_ = v_isSharedCheck_678_;
goto v_resetjp_672_;
}
else
{
lean_inc(v_a_671_);
lean_dec(v___x_504_);
v___x_673_ = lean_box(0);
v_isShared_674_ = v_isSharedCheck_678_;
goto v_resetjp_672_;
}
v_resetjp_672_:
{
lean_object* v___x_676_; 
if (v_isShared_674_ == 0)
{
v___x_676_ = v___x_673_;
goto v_reusejp_675_;
}
else
{
lean_object* v_reuseFailAlloc_677_; 
v_reuseFailAlloc_677_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_677_, 0, v_a_671_);
v___x_676_ = v_reuseFailAlloc_677_;
goto v_reusejp_675_;
}
v_reusejp_675_:
{
return v___x_676_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy___boxed(lean_object* v_j_679_, lean_object* v_goal_680_, lean_object* v_source_681_, lean_object* v_a_682_){
_start:
{
lean_object* v_res_683_; 
v_res_683_ = lp_proofEnvironment_OCMEnvironment_preparationPolicy(v_j_679_, v_goal_680_, v_source_681_);
lean_dec_ref(v_source_681_);
lean_dec_ref(v_goal_680_);
return v_res_683_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy(lean_object* v_j_731_, lean_object* v_goal_732_, lean_object* v_constants_733_){
_start:
{
lean_object* v___x_735_; lean_object* v___x_736_; lean_object* v___x_737_; lean_object* v___x_738_; lean_object* v___x_739_; lean_object* v___x_740_; lean_object* v___x_741_; lean_object* v___x_742_; lean_object* v___x_743_; 
v___x_735_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__0));
v___x_736_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__1));
v___x_737_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__0));
v___x_738_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__1));
v___x_739_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_preparationPolicy___closed__4));
v___x_740_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__2));
v___x_741_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__12));
lean_inc(v_j_731_);
v___x_742_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_731_, v___x_741_);
v___x_743_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_742_);
if (lean_obj_tag(v___x_743_) == 0)
{
lean_object* v___x_744_; 
lean_dec_ref_known(v___x_743_, 1);
lean_inc(v_j_731_);
v___x_744_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_731_, v___x_735_);
if (lean_obj_tag(v___x_744_) == 0)
{
lean_object* v_a_745_; lean_object* v___x_747_; uint8_t v_isShared_748_; uint8_t v_isSharedCheck_906_; 
v_a_745_ = lean_ctor_get(v___x_744_, 0);
v_isSharedCheck_906_ = !lean_is_exclusive(v___x_744_);
if (v_isSharedCheck_906_ == 0)
{
v___x_747_ = v___x_744_;
v_isShared_748_ = v_isSharedCheck_906_;
goto v_resetjp_746_;
}
else
{
lean_inc(v_a_745_);
lean_dec(v___x_744_);
v___x_747_ = lean_box(0);
v_isShared_748_ = v_isSharedCheck_906_;
goto v_resetjp_746_;
}
v_resetjp_746_:
{
lean_object* v___x_749_; uint8_t v___x_750_; 
v___x_749_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__13));
v___x_750_ = lean_string_dec_eq(v_a_745_, v___x_749_);
lean_dec(v_a_745_);
if (v___x_750_ == 0)
{
lean_object* v___x_751_; lean_object* v___x_753_; 
lean_dec(v_j_731_);
v___x_751_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__15));
if (v_isShared_748_ == 0)
{
lean_ctor_set_tag(v___x_747_, 1);
lean_ctor_set(v___x_747_, 0, v___x_751_);
v___x_753_ = v___x_747_;
goto v_reusejp_752_;
}
else
{
lean_object* v_reuseFailAlloc_754_; 
v_reuseFailAlloc_754_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_754_, 0, v___x_751_);
v___x_753_ = v_reuseFailAlloc_754_;
goto v_reusejp_752_;
}
v_reusejp_752_:
{
return v___x_753_;
}
}
else
{
lean_object* v___x_755_; 
lean_del_object(v___x_747_);
lean_inc(v_j_731_);
v___x_755_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_731_, v___x_740_);
if (lean_obj_tag(v___x_755_) == 0)
{
lean_object* v_a_756_; lean_object* v___x_758_; uint8_t v_isShared_759_; uint8_t v_isSharedCheck_897_; 
v_a_756_ = lean_ctor_get(v___x_755_, 0);
v_isSharedCheck_897_ = !lean_is_exclusive(v___x_755_);
if (v_isSharedCheck_897_ == 0)
{
v___x_758_ = v___x_755_;
v_isShared_759_ = v_isSharedCheck_897_;
goto v_resetjp_757_;
}
else
{
lean_inc(v_a_756_);
lean_dec(v___x_755_);
v___x_758_ = lean_box(0);
v_isShared_759_ = v_isSharedCheck_897_;
goto v_resetjp_757_;
}
v_resetjp_757_:
{
lean_object* v___x_760_; uint8_t v___x_761_; 
v___x_760_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__16));
v___x_761_ = lean_string_dec_eq(v_a_756_, v___x_760_);
lean_dec(v_a_756_);
if (v___x_761_ == 0)
{
lean_object* v___x_762_; lean_object* v___x_764_; 
lean_dec(v_j_731_);
v___x_762_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__18));
if (v_isShared_759_ == 0)
{
lean_ctor_set_tag(v___x_758_, 1);
lean_ctor_set(v___x_758_, 0, v___x_762_);
v___x_764_ = v___x_758_;
goto v_reusejp_763_;
}
else
{
lean_object* v_reuseFailAlloc_765_; 
v_reuseFailAlloc_765_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_765_, 0, v___x_762_);
v___x_764_ = v_reuseFailAlloc_765_;
goto v_reusejp_763_;
}
v_reusejp_763_:
{
return v___x_764_;
}
}
else
{
lean_object* v___x_766_; 
lean_del_object(v___x_758_);
lean_inc(v_j_731_);
v___x_766_ = lp_proofEnvironment_OCMEnvironment_getNat(v_j_731_, v___x_737_);
if (lean_obj_tag(v___x_766_) == 0)
{
lean_object* v_a_767_; lean_object* v___x_768_; 
v_a_767_ = lean_ctor_get(v___x_766_, 0);
lean_inc(v_a_767_);
lean_dec_ref_known(v___x_766_, 1);
v___x_768_ = lp_proofEnvironment_OCMEnvironment_packetName(v_goal_732_, v_a_767_);
if (lean_obj_tag(v___x_768_) == 0)
{
lean_object* v_a_769_; lean_object* v___x_770_; 
v_a_769_ = lean_ctor_get(v___x_768_, 0);
lean_inc(v_a_769_);
lean_dec_ref_known(v___x_768_, 1);
lean_inc(v_j_731_);
v___x_770_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_731_, v___x_736_);
if (lean_obj_tag(v___x_770_) == 0)
{
lean_object* v_a_771_; lean_object* v___x_773_; uint8_t v_isShared_774_; uint8_t v_isSharedCheck_872_; 
v_a_771_ = lean_ctor_get(v___x_770_, 0);
v_isSharedCheck_872_ = !lean_is_exclusive(v___x_770_);
if (v_isSharedCheck_872_ == 0)
{
v___x_773_ = v___x_770_;
v_isShared_774_ = v_isSharedCheck_872_;
goto v_resetjp_772_;
}
else
{
lean_inc(v_a_771_);
lean_dec(v___x_770_);
v___x_773_ = lean_box(0);
v_isShared_774_ = v_isSharedCheck_872_;
goto v_resetjp_772_;
}
v_resetjp_772_:
{
lean_object* v___x_775_; uint8_t v___x_776_; 
lean_inc(v_a_769_);
v___x_775_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_769_, v___x_761_);
v___x_776_ = lean_string_dec_eq(v___x_775_, v_a_771_);
lean_dec(v_a_771_);
lean_dec_ref(v___x_775_);
if (v___x_776_ == 0)
{
lean_object* v___x_777_; lean_object* v___x_779_; 
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v___x_777_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__20));
if (v_isShared_774_ == 0)
{
lean_ctor_set_tag(v___x_773_, 1);
lean_ctor_set(v___x_773_, 0, v___x_777_);
v___x_779_ = v___x_773_;
goto v_reusejp_778_;
}
else
{
lean_object* v_reuseFailAlloc_780_; 
v_reuseFailAlloc_780_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_780_, 0, v___x_777_);
v___x_779_ = v_reuseFailAlloc_780_;
goto v_reusejp_778_;
}
v_reusejp_778_:
{
return v___x_779_;
}
}
else
{
lean_object* v___x_781_; 
lean_del_object(v___x_773_);
lean_inc(v_a_769_);
lean_inc(v_j_731_);
v___x_781_ = lp_proofEnvironment_OCMEnvironment_targetFrom(v_j_731_, v_goal_732_, v_a_769_);
if (lean_obj_tag(v___x_781_) == 0)
{
lean_object* v_a_782_; lean_object* v___x_783_; 
v_a_782_ = lean_ctor_get(v___x_781_, 0);
lean_inc(v_a_782_);
lean_dec_ref_known(v___x_781_, 1);
lean_inc(v_j_731_);
v___x_783_ = lp_proofEnvironment_OCMEnvironment_getStrings(v_j_731_, v___x_738_);
if (lean_obj_tag(v___x_783_) == 0)
{
lean_object* v_a_784_; size_t v_sz_785_; size_t v___x_786_; lean_object* v___x_787_; 
v_a_784_ = lean_ctor_get(v___x_783_, 0);
lean_inc(v_a_784_);
lean_dec_ref_known(v___x_783_, 1);
v_sz_785_ = lean_array_size(v_a_784_);
v___x_786_ = ((size_t)0ULL);
v___x_787_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(v_constants_733_, v_sz_785_, v___x_786_, v_a_784_);
if (lean_obj_tag(v___x_787_) == 0)
{
lean_object* v_a_788_; lean_object* v___x_790_; uint8_t v_isShared_791_; uint8_t v_isSharedCheck_847_; 
v_a_788_ = lean_ctor_get(v___x_787_, 0);
v_isSharedCheck_847_ = !lean_is_exclusive(v___x_787_);
if (v_isSharedCheck_847_ == 0)
{
v___x_790_ = v___x_787_;
v_isShared_791_ = v_isSharedCheck_847_;
goto v_resetjp_789_;
}
else
{
lean_inc(v_a_788_);
lean_dec(v___x_787_);
v___x_790_ = lean_box(0);
v_isShared_791_ = v_isSharedCheck_847_;
goto v_resetjp_789_;
}
v_resetjp_789_:
{
lean_object* v_size_797_; lean_object* v___x_845_; uint8_t v___x_846_; 
v_size_797_ = lean_ctor_get(v_constants_733_, 0);
v___x_845_ = lean_array_get_size(v_a_788_);
v___x_846_ = lean_nat_dec_eq(v___x_845_, v_size_797_);
if (v___x_846_ == 0)
{
if (v___x_776_ == 0)
{
goto v___jp_798_;
}
else
{
lean_dec(v_a_788_);
lean_dec(v_a_782_);
lean_dec(v_a_769_);
lean_dec(v_j_731_);
goto v___jp_792_;
}
}
else
{
goto v___jp_798_;
}
v___jp_792_:
{
lean_object* v___x_793_; lean_object* v___x_795_; 
v___x_793_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_restorePolicy___closed__22));
if (v_isShared_791_ == 0)
{
lean_ctor_set_tag(v___x_790_, 1);
lean_ctor_set(v___x_790_, 0, v___x_793_);
v___x_795_ = v___x_790_;
goto v_reusejp_794_;
}
else
{
lean_object* v_reuseFailAlloc_796_; 
v_reuseFailAlloc_796_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_796_, 0, v___x_793_);
v___x_795_ = v_reuseFailAlloc_796_;
goto v_reusejp_794_;
}
v_reusejp_794_:
{
return v___x_795_;
}
}
v___jp_798_:
{
lean_object* v___x_799_; lean_object* v___x_800_; lean_object* v_size_801_; uint8_t v___x_802_; 
v___x_799_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4, &lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_targetFrom___closed__4);
v___x_800_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_799_, v_a_788_);
v_size_801_ = lean_ctor_get(v___x_800_, 0);
lean_inc(v_size_801_);
lean_dec_ref(v___x_800_);
v___x_802_ = lean_nat_dec_eq(v_size_801_, v_size_797_);
lean_dec(v_size_801_);
if (v___x_802_ == 0)
{
lean_dec(v_a_788_);
lean_dec(v_a_782_);
lean_dec(v_a_769_);
lean_dec(v_j_731_);
goto v___jp_792_;
}
else
{
lean_object* v___x_803_; 
lean_del_object(v___x_790_);
lean_inc(v_j_731_);
v___x_803_ = lp_proofEnvironment_OCMEnvironment_getStrings(v_j_731_, v___x_739_);
if (lean_obj_tag(v___x_803_) == 0)
{
lean_object* v_a_804_; size_t v_sz_805_; lean_object* v___x_806_; 
v_a_804_ = lean_ctor_get(v___x_803_, 0);
lean_inc(v_a_804_);
lean_dec_ref_known(v___x_803_, 1);
v_sz_805_ = lean_array_size(v_a_804_);
v___x_806_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_preparationPolicy_spec__0(v_constants_733_, v_sz_805_, v___x_786_, v_a_804_);
if (lean_obj_tag(v___x_806_) == 0)
{
lean_object* v_a_807_; lean_object* v___x_808_; 
v_a_807_ = lean_ctor_get(v___x_806_, 0);
lean_inc(v_a_807_);
lean_dec_ref_known(v___x_806_, 1);
v___x_808_ = lp_proofEnvironment_OCMEnvironment_kernelLimits(v_j_731_);
if (lean_obj_tag(v___x_808_) == 0)
{
lean_object* v_a_809_; lean_object* v___x_811_; uint8_t v_isShared_812_; uint8_t v_isSharedCheck_820_; 
v_a_809_ = lean_ctor_get(v___x_808_, 0);
v_isSharedCheck_820_ = !lean_is_exclusive(v___x_808_);
if (v_isSharedCheck_820_ == 0)
{
v___x_811_ = v___x_808_;
v_isShared_812_ = v_isSharedCheck_820_;
goto v_resetjp_810_;
}
else
{
lean_inc(v_a_809_);
lean_dec(v___x_808_);
v___x_811_ = lean_box(0);
v_isShared_812_ = v_isSharedCheck_820_;
goto v_resetjp_810_;
}
v_resetjp_810_:
{
lean_object* v_fst_813_; lean_object* v_snd_814_; lean_object* v___x_815_; lean_object* v___x_816_; lean_object* v___x_818_; 
v_fst_813_ = lean_ctor_get(v_a_809_, 0);
lean_inc(v_fst_813_);
v_snd_814_ = lean_ctor_get(v_a_809_, 1);
lean_inc(v_snd_814_);
lean_dec(v_a_809_);
v___x_815_ = l_Lean_NameHashSet_insert(v___x_799_, v_a_769_);
v___x_816_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_816_, 0, v_a_782_);
lean_ctor_set(v___x_816_, 1, v_a_788_);
lean_ctor_set(v___x_816_, 2, v___x_815_);
lean_ctor_set(v___x_816_, 3, v_a_807_);
lean_ctor_set(v___x_816_, 4, v_fst_813_);
lean_ctor_set(v___x_816_, 5, v_snd_814_);
if (v_isShared_812_ == 0)
{
lean_ctor_set(v___x_811_, 0, v___x_816_);
v___x_818_ = v___x_811_;
goto v_reusejp_817_;
}
else
{
lean_object* v_reuseFailAlloc_819_; 
v_reuseFailAlloc_819_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_819_, 0, v___x_816_);
v___x_818_ = v_reuseFailAlloc_819_;
goto v_reusejp_817_;
}
v_reusejp_817_:
{
return v___x_818_;
}
}
}
else
{
lean_object* v_a_821_; lean_object* v___x_823_; uint8_t v_isShared_824_; uint8_t v_isSharedCheck_828_; 
lean_dec(v_a_807_);
lean_dec(v_a_788_);
lean_dec(v_a_782_);
lean_dec(v_a_769_);
v_a_821_ = lean_ctor_get(v___x_808_, 0);
v_isSharedCheck_828_ = !lean_is_exclusive(v___x_808_);
if (v_isSharedCheck_828_ == 0)
{
v___x_823_ = v___x_808_;
v_isShared_824_ = v_isSharedCheck_828_;
goto v_resetjp_822_;
}
else
{
lean_inc(v_a_821_);
lean_dec(v___x_808_);
v___x_823_ = lean_box(0);
v_isShared_824_ = v_isSharedCheck_828_;
goto v_resetjp_822_;
}
v_resetjp_822_:
{
lean_object* v___x_826_; 
if (v_isShared_824_ == 0)
{
v___x_826_ = v___x_823_;
goto v_reusejp_825_;
}
else
{
lean_object* v_reuseFailAlloc_827_; 
v_reuseFailAlloc_827_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_827_, 0, v_a_821_);
v___x_826_ = v_reuseFailAlloc_827_;
goto v_reusejp_825_;
}
v_reusejp_825_:
{
return v___x_826_;
}
}
}
}
else
{
lean_object* v_a_829_; lean_object* v___x_831_; uint8_t v_isShared_832_; uint8_t v_isSharedCheck_836_; 
lean_dec(v_a_788_);
lean_dec(v_a_782_);
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v_a_829_ = lean_ctor_get(v___x_806_, 0);
v_isSharedCheck_836_ = !lean_is_exclusive(v___x_806_);
if (v_isSharedCheck_836_ == 0)
{
v___x_831_ = v___x_806_;
v_isShared_832_ = v_isSharedCheck_836_;
goto v_resetjp_830_;
}
else
{
lean_inc(v_a_829_);
lean_dec(v___x_806_);
v___x_831_ = lean_box(0);
v_isShared_832_ = v_isSharedCheck_836_;
goto v_resetjp_830_;
}
v_resetjp_830_:
{
lean_object* v___x_834_; 
if (v_isShared_832_ == 0)
{
v___x_834_ = v___x_831_;
goto v_reusejp_833_;
}
else
{
lean_object* v_reuseFailAlloc_835_; 
v_reuseFailAlloc_835_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_835_, 0, v_a_829_);
v___x_834_ = v_reuseFailAlloc_835_;
goto v_reusejp_833_;
}
v_reusejp_833_:
{
return v___x_834_;
}
}
}
}
else
{
lean_object* v_a_837_; lean_object* v___x_839_; uint8_t v_isShared_840_; uint8_t v_isSharedCheck_844_; 
lean_dec(v_a_788_);
lean_dec(v_a_782_);
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v_a_837_ = lean_ctor_get(v___x_803_, 0);
v_isSharedCheck_844_ = !lean_is_exclusive(v___x_803_);
if (v_isSharedCheck_844_ == 0)
{
v___x_839_ = v___x_803_;
v_isShared_840_ = v_isSharedCheck_844_;
goto v_resetjp_838_;
}
else
{
lean_inc(v_a_837_);
lean_dec(v___x_803_);
v___x_839_ = lean_box(0);
v_isShared_840_ = v_isSharedCheck_844_;
goto v_resetjp_838_;
}
v_resetjp_838_:
{
lean_object* v___x_842_; 
if (v_isShared_840_ == 0)
{
v___x_842_ = v___x_839_;
goto v_reusejp_841_;
}
else
{
lean_object* v_reuseFailAlloc_843_; 
v_reuseFailAlloc_843_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_843_, 0, v_a_837_);
v___x_842_ = v_reuseFailAlloc_843_;
goto v_reusejp_841_;
}
v_reusejp_841_:
{
return v___x_842_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_848_; lean_object* v___x_850_; uint8_t v_isShared_851_; uint8_t v_isSharedCheck_855_; 
lean_dec(v_a_782_);
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v_a_848_ = lean_ctor_get(v___x_787_, 0);
v_isSharedCheck_855_ = !lean_is_exclusive(v___x_787_);
if (v_isSharedCheck_855_ == 0)
{
v___x_850_ = v___x_787_;
v_isShared_851_ = v_isSharedCheck_855_;
goto v_resetjp_849_;
}
else
{
lean_inc(v_a_848_);
lean_dec(v___x_787_);
v___x_850_ = lean_box(0);
v_isShared_851_ = v_isSharedCheck_855_;
goto v_resetjp_849_;
}
v_resetjp_849_:
{
lean_object* v___x_853_; 
if (v_isShared_851_ == 0)
{
v___x_853_ = v___x_850_;
goto v_reusejp_852_;
}
else
{
lean_object* v_reuseFailAlloc_854_; 
v_reuseFailAlloc_854_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_854_, 0, v_a_848_);
v___x_853_ = v_reuseFailAlloc_854_;
goto v_reusejp_852_;
}
v_reusejp_852_:
{
return v___x_853_;
}
}
}
}
else
{
lean_object* v_a_856_; lean_object* v___x_858_; uint8_t v_isShared_859_; uint8_t v_isSharedCheck_863_; 
lean_dec(v_a_782_);
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v_a_856_ = lean_ctor_get(v___x_783_, 0);
v_isSharedCheck_863_ = !lean_is_exclusive(v___x_783_);
if (v_isSharedCheck_863_ == 0)
{
v___x_858_ = v___x_783_;
v_isShared_859_ = v_isSharedCheck_863_;
goto v_resetjp_857_;
}
else
{
lean_inc(v_a_856_);
lean_dec(v___x_783_);
v___x_858_ = lean_box(0);
v_isShared_859_ = v_isSharedCheck_863_;
goto v_resetjp_857_;
}
v_resetjp_857_:
{
lean_object* v___x_861_; 
if (v_isShared_859_ == 0)
{
v___x_861_ = v___x_858_;
goto v_reusejp_860_;
}
else
{
lean_object* v_reuseFailAlloc_862_; 
v_reuseFailAlloc_862_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_862_, 0, v_a_856_);
v___x_861_ = v_reuseFailAlloc_862_;
goto v_reusejp_860_;
}
v_reusejp_860_:
{
return v___x_861_;
}
}
}
}
else
{
lean_object* v_a_864_; lean_object* v___x_866_; uint8_t v_isShared_867_; uint8_t v_isSharedCheck_871_; 
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v_a_864_ = lean_ctor_get(v___x_781_, 0);
v_isSharedCheck_871_ = !lean_is_exclusive(v___x_781_);
if (v_isSharedCheck_871_ == 0)
{
v___x_866_ = v___x_781_;
v_isShared_867_ = v_isSharedCheck_871_;
goto v_resetjp_865_;
}
else
{
lean_inc(v_a_864_);
lean_dec(v___x_781_);
v___x_866_ = lean_box(0);
v_isShared_867_ = v_isSharedCheck_871_;
goto v_resetjp_865_;
}
v_resetjp_865_:
{
lean_object* v___x_869_; 
if (v_isShared_867_ == 0)
{
v___x_869_ = v___x_866_;
goto v_reusejp_868_;
}
else
{
lean_object* v_reuseFailAlloc_870_; 
v_reuseFailAlloc_870_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_870_, 0, v_a_864_);
v___x_869_ = v_reuseFailAlloc_870_;
goto v_reusejp_868_;
}
v_reusejp_868_:
{
return v___x_869_;
}
}
}
}
}
}
else
{
lean_object* v_a_873_; lean_object* v___x_875_; uint8_t v_isShared_876_; uint8_t v_isSharedCheck_880_; 
lean_dec(v_a_769_);
lean_dec(v_j_731_);
v_a_873_ = lean_ctor_get(v___x_770_, 0);
v_isSharedCheck_880_ = !lean_is_exclusive(v___x_770_);
if (v_isSharedCheck_880_ == 0)
{
v___x_875_ = v___x_770_;
v_isShared_876_ = v_isSharedCheck_880_;
goto v_resetjp_874_;
}
else
{
lean_inc(v_a_873_);
lean_dec(v___x_770_);
v___x_875_ = lean_box(0);
v_isShared_876_ = v_isSharedCheck_880_;
goto v_resetjp_874_;
}
v_resetjp_874_:
{
lean_object* v___x_878_; 
if (v_isShared_876_ == 0)
{
v___x_878_ = v___x_875_;
goto v_reusejp_877_;
}
else
{
lean_object* v_reuseFailAlloc_879_; 
v_reuseFailAlloc_879_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_879_, 0, v_a_873_);
v___x_878_ = v_reuseFailAlloc_879_;
goto v_reusejp_877_;
}
v_reusejp_877_:
{
return v___x_878_;
}
}
}
}
else
{
lean_object* v_a_881_; lean_object* v___x_883_; uint8_t v_isShared_884_; uint8_t v_isSharedCheck_888_; 
lean_dec(v_j_731_);
v_a_881_ = lean_ctor_get(v___x_768_, 0);
v_isSharedCheck_888_ = !lean_is_exclusive(v___x_768_);
if (v_isSharedCheck_888_ == 0)
{
v___x_883_ = v___x_768_;
v_isShared_884_ = v_isSharedCheck_888_;
goto v_resetjp_882_;
}
else
{
lean_inc(v_a_881_);
lean_dec(v___x_768_);
v___x_883_ = lean_box(0);
v_isShared_884_ = v_isSharedCheck_888_;
goto v_resetjp_882_;
}
v_resetjp_882_:
{
lean_object* v___x_886_; 
if (v_isShared_884_ == 0)
{
v___x_886_ = v___x_883_;
goto v_reusejp_885_;
}
else
{
lean_object* v_reuseFailAlloc_887_; 
v_reuseFailAlloc_887_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_887_, 0, v_a_881_);
v___x_886_ = v_reuseFailAlloc_887_;
goto v_reusejp_885_;
}
v_reusejp_885_:
{
return v___x_886_;
}
}
}
}
else
{
lean_object* v_a_889_; lean_object* v___x_891_; uint8_t v_isShared_892_; uint8_t v_isSharedCheck_896_; 
lean_dec(v_j_731_);
v_a_889_ = lean_ctor_get(v___x_766_, 0);
v_isSharedCheck_896_ = !lean_is_exclusive(v___x_766_);
if (v_isSharedCheck_896_ == 0)
{
v___x_891_ = v___x_766_;
v_isShared_892_ = v_isSharedCheck_896_;
goto v_resetjp_890_;
}
else
{
lean_inc(v_a_889_);
lean_dec(v___x_766_);
v___x_891_ = lean_box(0);
v_isShared_892_ = v_isSharedCheck_896_;
goto v_resetjp_890_;
}
v_resetjp_890_:
{
lean_object* v___x_894_; 
if (v_isShared_892_ == 0)
{
v___x_894_ = v___x_891_;
goto v_reusejp_893_;
}
else
{
lean_object* v_reuseFailAlloc_895_; 
v_reuseFailAlloc_895_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_895_, 0, v_a_889_);
v___x_894_ = v_reuseFailAlloc_895_;
goto v_reusejp_893_;
}
v_reusejp_893_:
{
return v___x_894_;
}
}
}
}
}
}
else
{
lean_object* v_a_898_; lean_object* v___x_900_; uint8_t v_isShared_901_; uint8_t v_isSharedCheck_905_; 
lean_dec(v_j_731_);
v_a_898_ = lean_ctor_get(v___x_755_, 0);
v_isSharedCheck_905_ = !lean_is_exclusive(v___x_755_);
if (v_isSharedCheck_905_ == 0)
{
v___x_900_ = v___x_755_;
v_isShared_901_ = v_isSharedCheck_905_;
goto v_resetjp_899_;
}
else
{
lean_inc(v_a_898_);
lean_dec(v___x_755_);
v___x_900_ = lean_box(0);
v_isShared_901_ = v_isSharedCheck_905_;
goto v_resetjp_899_;
}
v_resetjp_899_:
{
lean_object* v___x_903_; 
if (v_isShared_901_ == 0)
{
v___x_903_ = v___x_900_;
goto v_reusejp_902_;
}
else
{
lean_object* v_reuseFailAlloc_904_; 
v_reuseFailAlloc_904_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_904_, 0, v_a_898_);
v___x_903_ = v_reuseFailAlloc_904_;
goto v_reusejp_902_;
}
v_reusejp_902_:
{
return v___x_903_;
}
}
}
}
}
}
else
{
lean_object* v_a_907_; lean_object* v___x_909_; uint8_t v_isShared_910_; uint8_t v_isSharedCheck_914_; 
lean_dec(v_j_731_);
v_a_907_ = lean_ctor_get(v___x_744_, 0);
v_isSharedCheck_914_ = !lean_is_exclusive(v___x_744_);
if (v_isSharedCheck_914_ == 0)
{
v___x_909_ = v___x_744_;
v_isShared_910_ = v_isSharedCheck_914_;
goto v_resetjp_908_;
}
else
{
lean_inc(v_a_907_);
lean_dec(v___x_744_);
v___x_909_ = lean_box(0);
v_isShared_910_ = v_isSharedCheck_914_;
goto v_resetjp_908_;
}
v_resetjp_908_:
{
lean_object* v___x_912_; 
if (v_isShared_910_ == 0)
{
v___x_912_ = v___x_909_;
goto v_reusejp_911_;
}
else
{
lean_object* v_reuseFailAlloc_913_; 
v_reuseFailAlloc_913_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_913_, 0, v_a_907_);
v___x_912_ = v_reuseFailAlloc_913_;
goto v_reusejp_911_;
}
v_reusejp_911_:
{
return v___x_912_;
}
}
}
}
else
{
lean_object* v_a_915_; lean_object* v___x_917_; uint8_t v_isShared_918_; uint8_t v_isSharedCheck_922_; 
lean_dec(v_j_731_);
v_a_915_ = lean_ctor_get(v___x_743_, 0);
v_isSharedCheck_922_ = !lean_is_exclusive(v___x_743_);
if (v_isSharedCheck_922_ == 0)
{
v___x_917_ = v___x_743_;
v_isShared_918_ = v_isSharedCheck_922_;
goto v_resetjp_916_;
}
else
{
lean_inc(v_a_915_);
lean_dec(v___x_743_);
v___x_917_ = lean_box(0);
v_isShared_918_ = v_isSharedCheck_922_;
goto v_resetjp_916_;
}
v_resetjp_916_:
{
lean_object* v___x_920_; 
if (v_isShared_918_ == 0)
{
v___x_920_ = v___x_917_;
goto v_reusejp_919_;
}
else
{
lean_object* v_reuseFailAlloc_921_; 
v_reuseFailAlloc_921_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_921_, 0, v_a_915_);
v___x_920_ = v_reuseFailAlloc_921_;
goto v_reusejp_919_;
}
v_reusejp_919_:
{
return v___x_920_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy___boxed(lean_object* v_j_923_, lean_object* v_goal_924_, lean_object* v_constants_925_, lean_object* v_a_926_){
_start:
{
lean_object* v_res_927_; 
v_res_927_ = lp_proofEnvironment_OCMEnvironment_restorePolicy(v_j_923_, v_goal_924_, v_constants_925_);
lean_dec_ref(v_constants_925_);
lean_dec_ref(v_goal_924_);
return v_res_927_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Packet(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Prepare(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Config(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Packet(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Prepare(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
