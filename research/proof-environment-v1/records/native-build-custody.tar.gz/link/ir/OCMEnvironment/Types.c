// Lean compiler output
// Module: OCMEnvironment.Types
// Imports: public import Init public meta import Init public import Comparator.Compare public import Lean.Replay
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
size_t lean_usize_add(size_t, size_t);
uint8_t lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_OCMEnvironment_exactInfo(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_exactInfo___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_normalizationVersion___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 68, .m_capacity = 68, .m_length = 67, .m_data = "lean4export-3.1.0:metadata-erasure,let-nondep-false,alpha-interning"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_normalizationVersion___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_normalizationVersion___closed__0_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment_OCMEnvironment_normalizationVersion = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_normalizationVersion___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1_spec__1(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_namesJson_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_namesJson_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_namesJson(lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "schema"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "ocm.proof-environment.result.v1"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__1_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_result___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__1_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_result___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__2_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "operation"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__4_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "terminal"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "stage"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__6_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "reason"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "stats"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__8_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "dependencies"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__9_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "axioms"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__10_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_result___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "files"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_result___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_result___closed__11_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_result(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_OCMEnvironment_exactInfo(lean_object* v_a_1_, lean_object* v_b_2_){
_start:
{
uint8_t v___x_3_; 
v___x_3_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_a_1_, v_b_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_exactInfo___boxed(lean_object* v_a_4_, lean_object* v_b_5_){
_start:
{
uint8_t v_res_6_; lean_object* v_r_7_; 
v_res_6_ = lp_proofEnvironment_OCMEnvironment_exactInfo(v_a_4_, v_b_5_);
lean_dec_ref(v_b_5_);
lean_dec_ref(v_a_4_);
v_r_7_ = lean_box(v_res_6_);
return v_r_7_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1_spec__1(size_t v_sz_10_, size_t v_i_11_, lean_object* v_bs_12_){
_start:
{
uint8_t v___x_13_; 
v___x_13_ = lean_usize_dec_lt(v_i_11_, v_sz_10_);
if (v___x_13_ == 0)
{
return v_bs_12_;
}
else
{
lean_object* v_v_14_; lean_object* v___x_15_; lean_object* v_bs_x27_16_; lean_object* v___x_17_; size_t v___x_18_; size_t v___x_19_; lean_object* v___x_20_; 
v_v_14_ = lean_array_uget(v_bs_12_, v_i_11_);
v___x_15_ = lean_unsigned_to_nat(0u);
v_bs_x27_16_ = lean_array_uset(v_bs_12_, v_i_11_, v___x_15_);
v___x_17_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_17_, 0, v_v_14_);
v___x_18_ = ((size_t)1ULL);
v___x_19_ = lean_usize_add(v_i_11_, v___x_18_);
v___x_20_ = lean_array_uset(v_bs_x27_16_, v_i_11_, v___x_17_);
v_i_11_ = v___x_19_;
v_bs_12_ = v___x_20_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1_spec__1___boxed(lean_object* v_sz_22_, lean_object* v_i_23_, lean_object* v_bs_24_){
_start:
{
size_t v_sz_boxed_25_; size_t v_i_boxed_26_; lean_object* v_res_27_; 
v_sz_boxed_25_ = lean_unbox_usize(v_sz_22_);
lean_dec(v_sz_22_);
v_i_boxed_26_ = lean_unbox_usize(v_i_23_);
lean_dec(v_i_23_);
v_res_27_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1_spec__1(v_sz_boxed_25_, v_i_boxed_26_, v_bs_24_);
return v_res_27_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1(lean_object* v_a_28_){
_start:
{
size_t v_sz_29_; size_t v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v_sz_29_ = lean_array_size(v_a_28_);
v___x_30_ = ((size_t)0ULL);
v___x_31_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1_spec__1(v_sz_29_, v___x_30_, v_a_28_);
v___x_32_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_32_, 0, v___x_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_namesJson_spec__0(size_t v_sz_33_, size_t v_i_34_, lean_object* v_bs_35_){
_start:
{
uint8_t v___x_36_; 
v___x_36_ = lean_usize_dec_lt(v_i_34_, v_sz_33_);
if (v___x_36_ == 0)
{
return v_bs_35_;
}
else
{
lean_object* v_v_37_; lean_object* v___x_38_; lean_object* v_bs_x27_39_; lean_object* v___x_40_; size_t v___x_41_; size_t v___x_42_; lean_object* v___x_43_; 
v_v_37_ = lean_array_uget(v_bs_35_, v_i_34_);
v___x_38_ = lean_unsigned_to_nat(0u);
v_bs_x27_39_ = lean_array_uset(v_bs_35_, v_i_34_, v___x_38_);
v___x_40_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_v_37_, v___x_36_);
v___x_41_ = ((size_t)1ULL);
v___x_42_ = lean_usize_add(v_i_34_, v___x_41_);
v___x_43_ = lean_array_uset(v_bs_x27_39_, v_i_34_, v___x_40_);
v_i_34_ = v___x_42_;
v_bs_35_ = v___x_43_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_namesJson_spec__0___boxed(lean_object* v_sz_45_, lean_object* v_i_46_, lean_object* v_bs_47_){
_start:
{
size_t v_sz_boxed_48_; size_t v_i_boxed_49_; lean_object* v_res_50_; 
v_sz_boxed_48_ = lean_unbox_usize(v_sz_45_);
lean_dec(v_sz_45_);
v_i_boxed_49_ = lean_unbox_usize(v_i_46_);
lean_dec(v_i_46_);
v_res_50_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_namesJson_spec__0(v_sz_boxed_48_, v_i_boxed_49_, v_bs_47_);
return v_res_50_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_namesJson(lean_object* v_names_51_){
_start:
{
size_t v_sz_52_; size_t v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; 
v_sz_52_ = lean_array_size(v_names_51_);
v___x_53_ = ((size_t)0ULL);
v___x_54_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_namesJson_spec__0(v_sz_52_, v___x_53_, v_names_51_);
v___x_55_ = lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1(v___x_54_);
return v___x_55_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_result(lean_object* v_operation_71_, lean_object* v_terminal_72_, lean_object* v_stage_73_, lean_object* v_reason_74_, lean_object* v_stats_75_, lean_object* v_dependencies_76_, lean_object* v_axioms_77_, lean_object* v_files_78_){
_start:
{
lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_90_; lean_object* v___x_91_; lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v___x_104_; lean_object* v___x_105_; lean_object* v___x_106_; lean_object* v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; lean_object* v___x_111_; lean_object* v___x_112_; lean_object* v___x_113_; 
v___x_79_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__3));
v___x_80_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__4));
v___x_81_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_81_, 0, v_operation_71_);
v___x_82_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_82_, 0, v___x_80_);
lean_ctor_set(v___x_82_, 1, v___x_81_);
v___x_83_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__5));
v___x_84_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_84_, 0, v_terminal_72_);
v___x_85_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_85_, 0, v___x_83_);
lean_ctor_set(v___x_85_, 1, v___x_84_);
v___x_86_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__6));
v___x_87_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_87_, 0, v_stage_73_);
v___x_88_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_88_, 0, v___x_86_);
lean_ctor_set(v___x_88_, 1, v___x_87_);
v___x_89_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__7));
v___x_90_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_90_, 0, v_reason_74_);
v___x_91_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_91_, 0, v___x_89_);
lean_ctor_set(v___x_91_, 1, v___x_90_);
v___x_92_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__8));
v___x_93_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_93_, 0, v___x_92_);
lean_ctor_set(v___x_93_, 1, v_stats_75_);
v___x_94_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__9));
v___x_95_ = lp_proofEnvironment_OCMEnvironment_namesJson(v_dependencies_76_);
v___x_96_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_96_, 0, v___x_94_);
lean_ctor_set(v___x_96_, 1, v___x_95_);
v___x_97_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__10));
v___x_98_ = lp_proofEnvironment_OCMEnvironment_namesJson(v_axioms_77_);
v___x_99_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_99_, 0, v___x_97_);
lean_ctor_set(v___x_99_, 1, v___x_98_);
v___x_100_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_result___closed__11));
v___x_101_ = lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1(v_files_78_);
v___x_102_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_102_, 0, v___x_100_);
lean_ctor_set(v___x_102_, 1, v___x_101_);
v___x_103_ = lean_box(0);
v___x_104_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_104_, 0, v___x_102_);
lean_ctor_set(v___x_104_, 1, v___x_103_);
v___x_105_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_105_, 0, v___x_99_);
lean_ctor_set(v___x_105_, 1, v___x_104_);
v___x_106_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_106_, 0, v___x_96_);
lean_ctor_set(v___x_106_, 1, v___x_105_);
v___x_107_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_107_, 0, v___x_93_);
lean_ctor_set(v___x_107_, 1, v___x_106_);
v___x_108_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_108_, 0, v___x_91_);
lean_ctor_set(v___x_108_, 1, v___x_107_);
v___x_109_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_109_, 0, v___x_88_);
lean_ctor_set(v___x_109_, 1, v___x_108_);
v___x_110_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_110_, 0, v___x_85_);
lean_ctor_set(v___x_110_, 1, v___x_109_);
v___x_111_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_111_, 0, v___x_82_);
lean_ctor_set(v___x_111_, 1, v___x_110_);
v___x_112_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_112_, 0, v___x_79_);
lean_ctor_set(v___x_112_, 1, v___x_111_);
v___x_113_ = l_Lean_Json_mkObj(v___x_112_);
lean_dec_ref_known(v___x_112_, 2);
return v___x_113_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_Comparator_Compare(uint8_t builtin);
lean_object* initialize_Lean_Replay(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Types(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Comparator_Compare(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Replay(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
