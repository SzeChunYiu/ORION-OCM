// Lean compiler output
// Module: OCMEnvironment.Families
// Imports: public import Init public meta import Init public import OCMEnvironment.Dependencies
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_Lean_NameHashSet_insert(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_name_eq(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_name(lean_object*);
uint8_t l_List_elem___at___00__private_Lean_Class_0__Lean_initFn_00___x40_Lean_Class_1274053790____hygCtx___hyg_2__spec__1(lean_object*, lean_object*);
uint8_t l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_Lean_Name_append(lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t l_Lean_Expr_hasLooseBVars(lean_object*);
uint8_t l_Lean_Expr_hasFVar(lean_object*);
uint8_t l_Lean_Expr_hasMVar(lean_object*);
lean_object* l_List_get_x3fInternal___redArg(lean_object*, lean_object*);
uint8_t l_List_isEmpty___redArg(lean_object*);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
lean_object* l_Lean_ConstantInfo_value_x3f(lean_object*, uint8_t);
lean_object* l_Lean_ConstantInfo_levelParams(lean_object*);
uint8_t l_Lean_ConstantInfo_isUnsafe(lean_object*);
uint8_t l_Lean_ConstantInfo_isPartial(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__0;
static lean_once_cell_t lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__1;
LEAN_EXPORT uint8_t lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "INCONSISTENT_INDUCTIVE_FAMILY "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = " "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "MISSING_INDUCTIVE_MEMBER "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "CONSTRUCTOR_MEMBERSHIP "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "MISSING_CONSTRUCTOR "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "OPEN_RECURSOR_RULE "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "MISSING_RULE_CONSTRUCTOR "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "MISSING_RECURSOR_FAMILY "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "INCOMPLETE_QUOTIENT "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "MISSING_PRIMARY_RECURSOR "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "UNIVERSE_PARAMETERS "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "OPEN_DECLARATION_TYPE "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__2_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "RECURSOR_MEMBERSHIP "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__3_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "INDUCTIVE_MEMBERSHIP "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__4_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "OPEN_DECLARATION_VALUE "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__5 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__5_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "MISSING_CONSTRUCTOR_PARENT "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__6 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__6_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "NAME_RECORD_MISMATCH "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__7 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__7_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "rec"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__8 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__8_value),LEAN_SCALAR_PTR_LITERAL(18, 106, 38, 217, 182, 144, 186, 220)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__9 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__9_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "EXTRA_CONSTRUCTOR "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__10 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__10_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Quot"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__12 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__12_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "mk"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__13 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__14_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__14_value_aux_0),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__13_value),LEAN_SCALAR_PTR_LITERAL(255, 113, 137, 82, 82, 132, 58, 248)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__14 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__14_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__15 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__16_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__16_value_aux_0),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__15_value),LEAN_SCALAR_PTR_LITERAL(91, 125, 38, 34, 222, 200, 201, 80)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__16 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__16_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__17 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__17_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__18_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__11_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__18_value_aux_0),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__17_value),LEAN_SCALAR_PTR_LITERAL(150, 213, 121, 152, 109, 27, 137, 60)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__18 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__18_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__18_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__19 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__19_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__16_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__19_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__20 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__20_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__14_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__20_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__21 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__21_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__12_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__21_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__22 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__22_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "UNSAFE_OR_PARTIAL "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__23 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__23_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_validateFamilies___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateFamilies___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateFamilies___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateFamilies(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateFamilies___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0(lean_object* v_as_1_, size_t v_i_2_, size_t v_stop_3_, lean_object* v_b_4_){
_start:
{
uint8_t v___x_5_; 
v___x_5_ = lean_usize_dec_eq(v_i_2_, v_stop_3_);
if (v___x_5_ == 0)
{
lean_object* v___x_6_; lean_object* v___x_7_; size_t v___x_8_; size_t v___x_9_; 
v___x_6_ = lean_array_uget_borrowed(v_as_1_, v_i_2_);
lean_inc(v___x_6_);
v___x_7_ = l_Lean_NameHashSet_insert(v_b_4_, v___x_6_);
v___x_8_ = ((size_t)1ULL);
v___x_9_ = lean_usize_add(v_i_2_, v___x_8_);
v_i_2_ = v___x_9_;
v_b_4_ = v___x_7_;
goto _start;
}
else
{
return v_b_4_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0___boxed(lean_object* v_as_11_, lean_object* v_i_12_, lean_object* v_stop_13_, lean_object* v_b_14_){
_start:
{
size_t v_i_boxed_15_; size_t v_stop_boxed_16_; lean_object* v_res_17_; 
v_i_boxed_15_ = lean_unbox_usize(v_i_12_);
lean_dec(v_i_12_);
v_stop_boxed_16_ = lean_unbox_usize(v_stop_13_);
lean_dec(v_stop_13_);
v_res_17_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0(v_as_11_, v_i_boxed_15_, v_stop_boxed_16_, v_b_14_);
lean_dec_ref(v_as_11_);
return v_res_17_;
}
}
static lean_object* _init_lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__0(void){
_start:
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; 
v___x_18_ = lean_box(0);
v___x_19_ = lean_unsigned_to_nat(16u);
v___x_20_ = lean_mk_array(v___x_19_, v___x_18_);
return v___x_20_;
}
}
static lean_object* _init_lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__1(void){
_start:
{
lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; 
v___x_21_ = lean_obj_once(&lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__0, &lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__0_once, _init_lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__0);
v___x_22_ = lean_unsigned_to_nat(0u);
v___x_23_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_23_, 0, v___x_22_);
lean_ctor_set(v___x_23_, 1, v___x_21_);
return v___x_23_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(lean_object* v_xs_24_){
_start:
{
lean_object* v___x_25_; lean_object* v___y_27_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; uint8_t v___x_33_; 
v___x_25_ = l_List_lengthTR___redArg(v_xs_24_);
v___x_30_ = lean_unsigned_to_nat(0u);
v___x_31_ = lean_array_mk(v_xs_24_);
v___x_32_ = lean_array_get_size(v___x_31_);
v___x_33_ = lean_nat_dec_lt(v___x_30_, v___x_32_);
if (v___x_33_ == 0)
{
uint8_t v___x_34_; 
lean_dec_ref(v___x_31_);
v___x_34_ = lean_nat_dec_eq(v___x_25_, v___x_30_);
lean_dec(v___x_25_);
return v___x_34_;
}
else
{
lean_object* v___x_35_; uint8_t v___x_36_; 
v___x_35_ = lean_obj_once(&lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__1, &lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__1_once, _init_lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___closed__1);
v___x_36_ = lean_nat_dec_le(v___x_32_, v___x_32_);
if (v___x_36_ == 0)
{
if (v___x_33_ == 0)
{
uint8_t v___x_37_; 
lean_dec_ref(v___x_31_);
v___x_37_ = lean_nat_dec_eq(v___x_25_, v___x_30_);
lean_dec(v___x_25_);
return v___x_37_;
}
else
{
size_t v___x_38_; size_t v___x_39_; lean_object* v___x_40_; 
v___x_38_ = ((size_t)0ULL);
v___x_39_ = lean_usize_of_nat(v___x_32_);
v___x_40_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0(v___x_31_, v___x_38_, v___x_39_, v___x_35_);
lean_dec_ref(v___x_31_);
v___y_27_ = v___x_40_;
goto v___jp_26_;
}
}
else
{
size_t v___x_41_; size_t v___x_42_; lean_object* v___x_43_; 
v___x_41_ = ((size_t)0ULL);
v___x_42_ = lean_usize_of_nat(v___x_32_);
v___x_43_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_OCMEnvironment_Families_0__OCMEnvironment_unique_spec__0(v___x_31_, v___x_41_, v___x_42_, v___x_35_);
lean_dec_ref(v___x_31_);
v___y_27_ = v___x_43_;
goto v___jp_26_;
}
}
v___jp_26_:
{
lean_object* v_size_28_; uint8_t v___x_29_; 
v_size_28_ = lean_ctor_get(v___y_27_, 0);
lean_inc(v_size_28_);
lean_dec_ref(v___y_27_);
v___x_29_ = lean_nat_dec_eq(v___x_25_, v_size_28_);
lean_dec(v_size_28_);
lean_dec(v___x_25_);
return v___x_29_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique___boxed(lean_object* v_xs_44_){
_start:
{
uint8_t v_res_45_; lean_object* v_r_46_; 
v_res_45_ = lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(v_xs_44_);
v_r_46_ = lean_box(v_res_45_);
return v_r_46_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2(lean_object* v_x_47_, lean_object* v_x_48_){
_start:
{
if (lean_obj_tag(v_x_47_) == 0)
{
if (lean_obj_tag(v_x_48_) == 0)
{
uint8_t v___x_49_; 
v___x_49_ = 1;
return v___x_49_;
}
else
{
uint8_t v___x_50_; 
v___x_50_ = 0;
return v___x_50_;
}
}
else
{
if (lean_obj_tag(v_x_48_) == 0)
{
uint8_t v___x_51_; 
v___x_51_ = 0;
return v___x_51_;
}
else
{
lean_object* v_val_52_; lean_object* v_val_53_; uint8_t v___x_54_; 
v_val_52_ = lean_ctor_get(v_x_47_, 0);
v_val_53_ = lean_ctor_get(v_x_48_, 0);
v___x_54_ = lean_name_eq(v_val_52_, v_val_53_);
return v___x_54_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2___boxed(lean_object* v_x_55_, lean_object* v_x_56_){
_start:
{
uint8_t v_res_57_; lean_object* v_r_58_; 
v_res_57_ = lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2(v_x_55_, v_x_56_);
lean_dec(v_x_56_);
lean_dec(v_x_55_);
v_r_58_ = lean_box(v_res_57_);
return v_r_58_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg(lean_object* v_fst_62_, uint8_t v___x_63_, lean_object* v_constants_64_, lean_object* v_val_65_, lean_object* v___x_66_, lean_object* v_as_x27_67_, lean_object* v_b_68_){
_start:
{
if (lean_obj_tag(v_as_x27_67_) == 0)
{
lean_object* v___x_69_; 
lean_dec(v_fst_62_);
v___x_69_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_69_, 0, v_b_68_);
return v___x_69_;
}
else
{
lean_object* v_head_70_; lean_object* v_tail_71_; uint8_t v___y_73_; lean_object* v___x_91_; 
v_head_70_ = lean_ctor_get(v_as_x27_67_, 0);
v_tail_71_ = lean_ctor_get(v_as_x27_67_, 1);
v___x_91_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_64_, v_head_70_);
if (lean_obj_tag(v___x_91_) == 1)
{
lean_object* v_val_92_; 
v_val_92_ = lean_ctor_get(v___x_91_, 0);
lean_inc(v_val_92_);
lean_dec_ref_known(v___x_91_, 1);
if (lean_obj_tag(v_val_92_) == 5)
{
lean_object* v_val_93_; lean_object* v_toConstantVal_94_; lean_object* v_numParams_95_; lean_object* v_all_96_; lean_object* v___x_97_; uint8_t v___x_107_; 
v_val_93_ = lean_ctor_get(v_val_92_, 0);
lean_inc_ref(v_val_93_);
lean_dec_ref_known(v_val_92_, 1);
v_toConstantVal_94_ = lean_ctor_get(v_val_93_, 0);
lean_inc_ref(v_toConstantVal_94_);
v_numParams_95_ = lean_ctor_get(v_val_93_, 1);
lean_inc(v_numParams_95_);
v_all_96_ = lean_ctor_get(v_val_93_, 3);
lean_inc(v_all_96_);
lean_dec_ref(v_val_93_);
v___x_97_ = lean_box(0);
v___x_107_ = l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(v_all_96_, v___x_66_);
lean_dec(v_all_96_);
if (v___x_107_ == 0)
{
if (v___x_63_ == 0)
{
goto v___jp_102_;
}
else
{
lean_dec(v_numParams_95_);
lean_dec_ref(v_toConstantVal_94_);
v___y_73_ = v___x_63_;
goto v___jp_72_;
}
}
else
{
goto v___jp_102_;
}
v___jp_98_:
{
lean_object* v_numParams_99_; uint8_t v___x_100_; 
v_numParams_99_ = lean_ctor_get(v_val_65_, 1);
v___x_100_ = lean_nat_dec_eq(v_numParams_95_, v_numParams_99_);
lean_dec(v_numParams_95_);
if (v___x_100_ == 0)
{
v___y_73_ = v___x_63_;
goto v___jp_72_;
}
else
{
v_as_x27_67_ = v_tail_71_;
v_b_68_ = v___x_97_;
goto _start;
}
}
v___jp_102_:
{
lean_object* v_toConstantVal_103_; lean_object* v_levelParams_104_; lean_object* v_levelParams_105_; uint8_t v___x_106_; 
v_toConstantVal_103_ = lean_ctor_get(v_val_65_, 0);
v_levelParams_104_ = lean_ctor_get(v_toConstantVal_94_, 1);
lean_inc(v_levelParams_104_);
lean_dec_ref(v_toConstantVal_94_);
v_levelParams_105_ = lean_ctor_get(v_toConstantVal_103_, 1);
v___x_106_ = l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(v_levelParams_104_, v_levelParams_105_);
lean_dec(v_levelParams_104_);
if (v___x_106_ == 0)
{
if (v___x_63_ == 0)
{
goto v___jp_98_;
}
else
{
lean_dec(v_numParams_95_);
v___y_73_ = v___x_63_;
goto v___jp_72_;
}
}
else
{
goto v___jp_98_;
}
}
}
else
{
lean_dec(v_val_92_);
goto v___jp_82_;
}
}
else
{
lean_dec(v___x_91_);
goto v___jp_82_;
}
v___jp_72_:
{
lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; 
v___x_74_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__0));
v___x_75_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_62_, v___y_73_);
v___x_76_ = lean_string_append(v___x_74_, v___x_75_);
lean_dec_ref(v___x_75_);
v___x_77_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1));
v___x_78_ = lean_string_append(v___x_76_, v___x_77_);
lean_inc(v_head_70_);
v___x_79_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_70_, v___y_73_);
v___x_80_ = lean_string_append(v___x_78_, v___x_79_);
lean_dec_ref(v___x_79_);
v___x_81_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_81_, 0, v___x_80_);
return v___x_81_;
}
v___jp_82_:
{
lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_90_; 
v___x_83_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__2));
v___x_84_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_62_, v___x_63_);
v___x_85_ = lean_string_append(v___x_83_, v___x_84_);
lean_dec_ref(v___x_84_);
v___x_86_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1));
v___x_87_ = lean_string_append(v___x_85_, v___x_86_);
lean_inc(v_head_70_);
v___x_88_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_70_, v___x_63_);
v___x_89_ = lean_string_append(v___x_87_, v___x_88_);
lean_dec_ref(v___x_88_);
v___x_90_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_90_, 0, v___x_89_);
return v___x_90_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___boxed(lean_object* v_fst_108_, lean_object* v___x_109_, lean_object* v_constants_110_, lean_object* v_val_111_, lean_object* v___x_112_, lean_object* v_as_x27_113_, lean_object* v_b_114_){
_start:
{
uint8_t v___x_16475__boxed_115_; lean_object* v_res_116_; 
v___x_16475__boxed_115_ = lean_unbox(v___x_109_);
v_res_116_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg(v_fst_108_, v___x_16475__boxed_115_, v_constants_110_, v_val_111_, v___x_112_, v_as_x27_113_, v_b_114_);
lean_dec(v_as_x27_113_);
lean_dec(v___x_112_);
lean_dec_ref(v_val_111_);
lean_dec_ref(v_constants_110_);
return v_res_116_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg(lean_object* v___x_119_, lean_object* v_fst_120_, uint8_t v___x_121_, lean_object* v_constants_122_, lean_object* v_val_123_, lean_object* v_range_124_, lean_object* v_b_125_, lean_object* v_i_126_){
_start:
{
lean_object* v_stop_127_; lean_object* v_step_128_; uint8_t v___x_129_; 
v_stop_127_ = lean_ctor_get(v_range_124_, 1);
v_step_128_ = lean_ctor_get(v_range_124_, 2);
v___x_129_ = lean_nat_dec_lt(v_i_126_, v_stop_127_);
if (v___x_129_ == 0)
{
lean_object* v___x_130_; 
lean_dec(v_i_126_);
lean_dec(v_fst_120_);
v___x_130_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_130_, 0, v_b_125_);
return v___x_130_;
}
else
{
lean_object* v___x_131_; lean_object* v___x_132_; uint8_t v___y_134_; lean_object* v___x_148_; 
v___x_131_ = lean_box(0);
lean_inc(v_i_126_);
v___x_132_ = l_List_get_x21Internal___redArg(v___x_131_, v___x_119_, v_i_126_);
v___x_148_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_122_, v___x_132_);
if (lean_obj_tag(v___x_148_) == 1)
{
lean_object* v_val_149_; 
v_val_149_ = lean_ctor_get(v___x_148_, 0);
lean_inc(v_val_149_);
lean_dec_ref_known(v___x_148_, 1);
if (lean_obj_tag(v_val_149_) == 6)
{
lean_object* v_val_150_; lean_object* v_induct_151_; lean_object* v_cidx_152_; lean_object* v_numParams_153_; lean_object* v___x_154_; uint8_t v___x_162_; 
v_val_150_ = lean_ctor_get(v_val_149_, 0);
lean_inc_ref(v_val_150_);
lean_dec_ref_known(v_val_149_, 1);
v_induct_151_ = lean_ctor_get(v_val_150_, 1);
lean_inc(v_induct_151_);
v_cidx_152_ = lean_ctor_get(v_val_150_, 2);
lean_inc(v_cidx_152_);
v_numParams_153_ = lean_ctor_get(v_val_150_, 3);
lean_inc(v_numParams_153_);
lean_dec_ref(v_val_150_);
v___x_154_ = lean_box(0);
v___x_162_ = lean_name_eq(v_induct_151_, v_fst_120_);
lean_dec(v_induct_151_);
if (v___x_162_ == 0)
{
if (v___x_121_ == 0)
{
goto v___jp_160_;
}
else
{
lean_dec(v_numParams_153_);
lean_dec(v_cidx_152_);
lean_dec(v_i_126_);
lean_dec(v_fst_120_);
v___y_134_ = v___x_121_;
goto v___jp_133_;
}
}
else
{
goto v___jp_160_;
}
v___jp_155_:
{
lean_object* v_numParams_156_; uint8_t v___x_157_; 
v_numParams_156_ = lean_ctor_get(v_val_123_, 1);
v___x_157_ = lean_nat_dec_eq(v_numParams_153_, v_numParams_156_);
lean_dec(v_numParams_153_);
if (v___x_157_ == 0)
{
lean_dec(v_i_126_);
lean_dec(v_fst_120_);
v___y_134_ = v___x_121_;
goto v___jp_133_;
}
else
{
lean_object* v___x_158_; 
lean_dec(v___x_132_);
v___x_158_ = lean_nat_add(v_i_126_, v_step_128_);
lean_dec(v_i_126_);
v_b_125_ = v___x_154_;
v_i_126_ = v___x_158_;
goto _start;
}
}
v___jp_160_:
{
uint8_t v___x_161_; 
v___x_161_ = lean_nat_dec_eq(v_cidx_152_, v_i_126_);
lean_dec(v_cidx_152_);
if (v___x_161_ == 0)
{
if (v___x_121_ == 0)
{
goto v___jp_155_;
}
else
{
lean_dec(v_numParams_153_);
lean_dec(v_i_126_);
lean_dec(v_fst_120_);
v___y_134_ = v___x_121_;
goto v___jp_133_;
}
}
else
{
goto v___jp_155_;
}
}
}
else
{
lean_dec(v_val_149_);
lean_dec(v_i_126_);
goto v___jp_139_;
}
}
else
{
lean_dec(v___x_148_);
lean_dec(v_i_126_);
goto v___jp_139_;
}
v___jp_133_:
{
lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; 
v___x_135_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__0));
v___x_136_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_132_, v___y_134_);
v___x_137_ = lean_string_append(v___x_135_, v___x_136_);
lean_dec_ref(v___x_136_);
v___x_138_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_138_, 0, v___x_137_);
return v___x_138_;
}
v___jp_139_:
{
lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; 
v___x_140_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___closed__1));
v___x_141_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_120_, v___x_121_);
v___x_142_ = lean_string_append(v___x_140_, v___x_141_);
lean_dec_ref(v___x_141_);
v___x_143_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1));
v___x_144_ = lean_string_append(v___x_142_, v___x_143_);
v___x_145_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_132_, v___x_121_);
v___x_146_ = lean_string_append(v___x_144_, v___x_145_);
lean_dec_ref(v___x_145_);
v___x_147_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_147_, 0, v___x_146_);
return v___x_147_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg___boxed(lean_object* v___x_163_, lean_object* v_fst_164_, lean_object* v___x_165_, lean_object* v_constants_166_, lean_object* v_val_167_, lean_object* v_range_168_, lean_object* v_b_169_, lean_object* v_i_170_){
_start:
{
uint8_t v___x_16560__boxed_171_; lean_object* v_res_172_; 
v___x_16560__boxed_171_ = lean_unbox(v___x_165_);
v_res_172_ = lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg(v___x_163_, v_fst_164_, v___x_16560__boxed_171_, v_constants_166_, v_val_167_, v_range_168_, v_b_169_, v_i_170_);
lean_dec_ref(v_range_168_);
lean_dec_ref(v_val_167_);
lean_dec_ref(v_constants_166_);
lean_dec(v___x_163_);
return v_res_172_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg(lean_object* v_fst_175_, uint8_t v___x_176_, lean_object* v_constants_177_, lean_object* v_as_x27_178_, lean_object* v_b_179_){
_start:
{
uint8_t v___y_181_; 
if (lean_obj_tag(v_as_x27_178_) == 0)
{
lean_object* v___x_186_; 
lean_dec(v_fst_175_);
v___x_186_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_186_, 0, v_b_179_);
return v___x_186_;
}
else
{
lean_object* v_head_187_; lean_object* v_tail_188_; lean_object* v_ctor_189_; lean_object* v_rhs_190_; lean_object* v___x_200_; 
v_head_187_ = lean_ctor_get(v_as_x27_178_, 0);
v_tail_188_ = lean_ctor_get(v_as_x27_178_, 1);
v_ctor_189_ = lean_ctor_get(v_head_187_, 0);
v_rhs_190_ = lean_ctor_get(v_head_187_, 2);
v___x_200_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_177_, v_ctor_189_);
if (lean_obj_tag(v___x_200_) == 1)
{
lean_object* v_val_201_; 
v_val_201_ = lean_ctor_get(v___x_200_, 0);
lean_inc(v_val_201_);
lean_dec_ref_known(v___x_200_, 1);
if (lean_obj_tag(v_val_201_) == 6)
{
lean_object* v___x_202_; uint8_t v___y_204_; uint8_t v___x_207_; 
lean_dec_ref_known(v_val_201_, 1);
v___x_202_ = lean_box(0);
v___x_207_ = l_Lean_Expr_hasFVar(v_rhs_190_);
if (v___x_207_ == 0)
{
uint8_t v___x_208_; 
v___x_208_ = l_Lean_Expr_hasMVar(v_rhs_190_);
v___y_204_ = v___x_208_;
goto v___jp_203_;
}
else
{
v___y_204_ = v___x_207_;
goto v___jp_203_;
}
v___jp_203_:
{
if (v___y_204_ == 0)
{
uint8_t v___x_205_; 
v___x_205_ = l_Lean_Expr_hasLooseBVars(v_rhs_190_);
if (v___x_205_ == 0)
{
v_as_x27_178_ = v_tail_188_;
v_b_179_ = v___x_202_;
goto _start;
}
else
{
v___y_181_ = v___x_205_;
goto v___jp_180_;
}
}
else
{
v___y_181_ = v___y_204_;
goto v___jp_180_;
}
}
}
else
{
lean_dec(v_val_201_);
goto v___jp_191_;
}
}
else
{
lean_dec(v___x_200_);
goto v___jp_191_;
}
v___jp_191_:
{
lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; 
v___x_192_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__1));
v___x_193_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_175_, v___x_176_);
v___x_194_ = lean_string_append(v___x_192_, v___x_193_);
lean_dec_ref(v___x_193_);
v___x_195_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1));
v___x_196_ = lean_string_append(v___x_194_, v___x_195_);
lean_inc(v_ctor_189_);
v___x_197_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_ctor_189_, v___x_176_);
v___x_198_ = lean_string_append(v___x_196_, v___x_197_);
lean_dec_ref(v___x_197_);
v___x_199_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_199_, 0, v___x_198_);
return v___x_199_;
}
}
v___jp_180_:
{
lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; lean_object* v___x_185_; 
v___x_182_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___closed__0));
v___x_183_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_175_, v___y_181_);
v___x_184_ = lean_string_append(v___x_182_, v___x_183_);
lean_dec_ref(v___x_183_);
v___x_185_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_185_, 0, v___x_184_);
return v___x_185_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg___boxed(lean_object* v_fst_209_, lean_object* v___x_210_, lean_object* v_constants_211_, lean_object* v_as_x27_212_, lean_object* v_b_213_){
_start:
{
uint8_t v___x_16638__boxed_214_; lean_object* v_res_215_; 
v___x_16638__boxed_214_ = lean_unbox(v___x_210_);
v_res_215_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg(v_fst_209_, v___x_16638__boxed_214_, v_constants_211_, v_as_x27_212_, v_b_213_);
lean_dec(v_as_x27_212_);
lean_dec_ref(v_constants_211_);
return v_res_215_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg(lean_object* v_fst_217_, uint8_t v___x_218_, lean_object* v_constants_219_, lean_object* v_as_x27_220_, lean_object* v_b_221_){
_start:
{
if (lean_obj_tag(v_as_x27_220_) == 0)
{
lean_object* v___x_222_; 
lean_dec(v_fst_217_);
v___x_222_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_222_, 0, v_b_221_);
return v___x_222_;
}
else
{
lean_object* v_head_223_; lean_object* v_tail_224_; lean_object* v___x_234_; 
v_head_223_ = lean_ctor_get(v_as_x27_220_, 0);
v_tail_224_ = lean_ctor_get(v_as_x27_220_, 1);
v___x_234_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_219_, v_head_223_);
if (lean_obj_tag(v___x_234_) == 1)
{
lean_object* v_val_235_; 
v_val_235_ = lean_ctor_get(v___x_234_, 0);
lean_inc(v_val_235_);
lean_dec_ref_known(v___x_234_, 1);
if (lean_obj_tag(v_val_235_) == 5)
{
lean_object* v___x_236_; 
lean_dec_ref_known(v_val_235_, 1);
v___x_236_ = lean_box(0);
v_as_x27_220_ = v_tail_224_;
v_b_221_ = v___x_236_;
goto _start;
}
else
{
lean_dec(v_val_235_);
goto v___jp_225_;
}
}
else
{
lean_dec(v___x_234_);
goto v___jp_225_;
}
v___jp_225_:
{
lean_object* v___x_226_; lean_object* v___x_227_; lean_object* v___x_228_; lean_object* v___x_229_; lean_object* v___x_230_; lean_object* v___x_231_; lean_object* v___x_232_; lean_object* v___x_233_; 
v___x_226_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg___closed__0));
v___x_227_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_217_, v___x_218_);
v___x_228_ = lean_string_append(v___x_226_, v___x_227_);
lean_dec_ref(v___x_227_);
v___x_229_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg___closed__1));
v___x_230_ = lean_string_append(v___x_228_, v___x_229_);
lean_inc(v_head_223_);
v___x_231_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_223_, v___x_218_);
v___x_232_ = lean_string_append(v___x_230_, v___x_231_);
lean_dec_ref(v___x_231_);
v___x_233_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_233_, 0, v___x_232_);
return v___x_233_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg___boxed(lean_object* v_fst_238_, lean_object* v___x_239_, lean_object* v_constants_240_, lean_object* v_as_x27_241_, lean_object* v_b_242_){
_start:
{
uint8_t v___x_16704__boxed_243_; lean_object* v_res_244_; 
v___x_16704__boxed_243_ = lean_unbox(v___x_239_);
v_res_244_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg(v_fst_238_, v___x_16704__boxed_243_, v_constants_240_, v_as_x27_241_, v_b_242_);
lean_dec(v_as_x27_241_);
lean_dec_ref(v_constants_240_);
return v_res_244_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg(uint8_t v___x_246_, lean_object* v_constants_247_, lean_object* v_as_x27_248_, lean_object* v_b_249_){
_start:
{
if (lean_obj_tag(v_as_x27_248_) == 0)
{
lean_object* v___x_250_; 
v___x_250_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_250_, 0, v_b_249_);
return v___x_250_;
}
else
{
lean_object* v_head_251_; lean_object* v_tail_252_; lean_object* v___x_258_; 
v_head_251_ = lean_ctor_get(v_as_x27_248_, 0);
v_tail_252_ = lean_ctor_get(v_as_x27_248_, 1);
v___x_258_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_247_, v_head_251_);
if (lean_obj_tag(v___x_258_) == 1)
{
lean_object* v_val_259_; 
v_val_259_ = lean_ctor_get(v___x_258_, 0);
lean_inc(v_val_259_);
lean_dec_ref_known(v___x_258_, 1);
if (lean_obj_tag(v_val_259_) == 4)
{
lean_object* v___x_260_; 
lean_dec_ref_known(v_val_259_, 1);
v___x_260_ = lean_box(0);
v_as_x27_248_ = v_tail_252_;
v_b_249_ = v___x_260_;
goto _start;
}
else
{
lean_dec(v_val_259_);
goto v___jp_253_;
}
}
else
{
lean_dec(v___x_258_);
goto v___jp_253_;
}
v___jp_253_:
{
lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___x_256_; lean_object* v___x_257_; 
v___x_254_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg___closed__0));
lean_inc(v_head_251_);
v___x_255_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_251_, v___x_246_);
v___x_256_ = lean_string_append(v___x_254_, v___x_255_);
lean_dec_ref(v___x_255_);
v___x_257_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_257_, 0, v___x_256_);
return v___x_257_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg___boxed(lean_object* v___x_262_, lean_object* v_constants_263_, lean_object* v_as_x27_264_, lean_object* v_b_265_){
_start:
{
uint8_t v___x_16745__boxed_266_; lean_object* v_res_267_; 
v___x_16745__boxed_266_ = lean_unbox(v___x_262_);
v_res_267_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg(v___x_16745__boxed_266_, v_constants_263_, v_as_x27_264_, v_b_265_);
lean_dec(v_as_x27_264_);
lean_dec_ref(v_constants_263_);
return v_res_267_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg(lean_object* v_constants_308_, lean_object* v_as_x27_309_, lean_object* v_b_310_){
_start:
{
if (lean_obj_tag(v_as_x27_309_) == 0)
{
lean_object* v___x_311_; 
v___x_311_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_311_, 0, v_b_310_);
return v___x_311_;
}
else
{
lean_object* v_head_312_; lean_object* v_tail_313_; lean_object* v_fst_314_; lean_object* v_snd_315_; uint8_t v___y_317_; uint8_t v___y_323_; uint8_t v___y_329_; uint8_t v___y_335_; uint8_t v___y_341_; uint8_t v___y_347_; lean_object* v___x_352_; uint8_t v___x_353_; 
v_head_312_ = lean_ctor_get(v_as_x27_309_, 0);
v_tail_313_ = lean_ctor_get(v_as_x27_309_, 1);
v_fst_314_ = lean_ctor_get(v_head_312_, 0);
v_snd_315_ = lean_ctor_get(v_head_312_, 1);
v___x_352_ = l_Lean_ConstantInfo_name(v_snd_315_);
v___x_353_ = lean_name_eq(v_fst_314_, v___x_352_);
lean_dec(v___x_352_);
if (v___x_353_ == 0)
{
uint8_t v___x_359_; lean_object* v___x_360_; lean_object* v___x_361_; lean_object* v___x_362_; lean_object* v___x_363_; 
v___x_359_ = 1;
v___x_360_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__7));
lean_inc(v_fst_314_);
v___x_361_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___x_359_);
v___x_362_ = lean_string_append(v___x_360_, v___x_361_);
lean_dec_ref(v___x_361_);
v___x_363_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_363_, 0, v___x_362_);
return v___x_363_;
}
else
{
lean_object* v___x_364_; lean_object* v___y_366_; lean_object* v_all_367_; lean_object* v_ctors_368_; lean_object* v___y_382_; uint8_t v___y_383_; lean_object* v___y_388_; uint8_t v___y_389_; uint8_t v___y_396_; uint8_t v___y_436_; lean_object* v___y_437_; uint8_t v___y_438_; uint8_t v___y_441_; uint8_t v___y_456_; uint8_t v___x_463_; 
v___x_364_ = lean_box(0);
v___x_463_ = l_Lean_ConstantInfo_isUnsafe(v_snd_315_);
if (v___x_463_ == 0)
{
uint8_t v___x_464_; 
v___x_464_ = l_Lean_ConstantInfo_isPartial(v_snd_315_);
v___y_456_ = v___x_464_;
goto v___jp_455_;
}
else
{
v___y_456_ = v___x_463_;
goto v___jp_455_;
}
v___jp_365_:
{
uint8_t v___x_369_; 
v___x_369_ = l_List_elem___at___00__private_Lean_Class_0__Lean_initFn_00___x40_Lean_Class_1274053790____hygCtx___hyg_2__spec__1(v_fst_314_, v_all_367_);
if (v___x_369_ == 0)
{
lean_dec(v_ctors_368_);
lean_dec(v_all_367_);
lean_dec_ref(v___y_366_);
v___y_341_ = v___x_353_;
goto v___jp_340_;
}
else
{
lean_object* v___x_370_; 
lean_inc(v_fst_314_);
v___x_370_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg(v_fst_314_, v___x_369_, v_constants_308_, v___y_366_, v_all_367_, v_all_367_, v___x_364_);
lean_dec(v_all_367_);
if (lean_obj_tag(v___x_370_) == 0)
{
lean_dec(v_ctors_368_);
lean_dec_ref(v___y_366_);
return v___x_370_;
}
else
{
lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v___x_373_; lean_object* v___x_374_; lean_object* v___x_375_; 
lean_dec_ref_known(v___x_370_, 1);
v___x_371_ = lean_unsigned_to_nat(0u);
v___x_372_ = l_List_lengthTR___redArg(v_ctors_368_);
v___x_373_ = lean_unsigned_to_nat(1u);
v___x_374_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_374_, 0, v___x_371_);
lean_ctor_set(v___x_374_, 1, v___x_372_);
lean_ctor_set(v___x_374_, 2, v___x_373_);
lean_inc(v_fst_314_);
v___x_375_ = lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg(v_ctors_368_, v_fst_314_, v___x_369_, v_constants_308_, v___y_366_, v___x_374_, v___x_364_, v___x_371_);
lean_dec_ref_known(v___x_374_, 3);
lean_dec_ref(v___y_366_);
lean_dec(v_ctors_368_);
if (lean_obj_tag(v___x_375_) == 0)
{
return v___x_375_;
}
else
{
lean_object* v___x_376_; lean_object* v___x_377_; lean_object* v___x_378_; 
lean_dec_ref_known(v___x_375_, 1);
v___x_376_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__9));
lean_inc(v_fst_314_);
v___x_377_ = l_Lean_Name_append(v_fst_314_, v___x_376_);
v___x_378_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_308_, v___x_377_);
lean_dec(v___x_377_);
if (lean_obj_tag(v___x_378_) == 1)
{
lean_object* v_val_379_; 
v_val_379_ = lean_ctor_get(v___x_378_, 0);
lean_inc(v_val_379_);
lean_dec_ref_known(v___x_378_, 1);
if (lean_obj_tag(v_val_379_) == 7)
{
lean_dec_ref_known(v_val_379_, 1);
v_as_x27_309_ = v_tail_313_;
v_b_310_ = v___x_364_;
goto _start;
}
else
{
lean_dec(v_val_379_);
v___y_317_ = v___x_369_;
goto v___jp_316_;
}
}
else
{
lean_dec(v___x_378_);
v___y_317_ = v___x_369_;
goto v___jp_316_;
}
}
}
}
}
v___jp_381_:
{
if (v___y_383_ == 0)
{
lean_object* v_all_384_; lean_object* v_ctors_385_; uint8_t v___x_386_; 
v_all_384_ = lean_ctor_get(v___y_382_, 3);
lean_inc(v_all_384_);
v_ctors_385_ = lean_ctor_get(v___y_382_, 4);
lean_inc_n(v_ctors_385_, 2);
v___x_386_ = lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(v_ctors_385_);
if (v___x_386_ == 0)
{
if (v___x_353_ == 0)
{
v___y_366_ = v___y_382_;
v_all_367_ = v_all_384_;
v_ctors_368_ = v_ctors_385_;
goto v___jp_365_;
}
else
{
lean_dec(v_ctors_385_);
lean_dec(v_all_384_);
lean_dec_ref(v___y_382_);
v___y_341_ = v___x_353_;
goto v___jp_340_;
}
}
else
{
v___y_366_ = v___y_382_;
v_all_367_ = v_all_384_;
v_ctors_368_ = v_ctors_385_;
goto v___jp_365_;
}
}
else
{
lean_dec_ref(v___y_382_);
v___y_341_ = v___y_383_;
goto v___jp_340_;
}
}
v___jp_387_:
{
if (v___y_389_ == 0)
{
lean_object* v_all_390_; lean_object* v_rules_391_; lean_object* v___x_392_; 
v_all_390_ = lean_ctor_get(v___y_388_, 1);
lean_inc(v_all_390_);
v_rules_391_ = lean_ctor_get(v___y_388_, 6);
lean_inc(v_rules_391_);
lean_dec_ref(v___y_388_);
lean_inc(v_fst_314_);
v___x_392_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg(v_fst_314_, v___x_353_, v_constants_308_, v_all_390_, v___x_364_);
lean_dec(v_all_390_);
if (lean_obj_tag(v___x_392_) == 0)
{
lean_dec(v_rules_391_);
return v___x_392_;
}
else
{
lean_object* v___x_393_; 
lean_dec_ref_known(v___x_392_, 1);
lean_inc(v_fst_314_);
v___x_393_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg(v_fst_314_, v___x_353_, v_constants_308_, v_rules_391_, v___x_364_);
lean_dec(v_rules_391_);
if (lean_obj_tag(v___x_393_) == 0)
{
return v___x_393_;
}
else
{
lean_dec_ref_known(v___x_393_, 1);
v_as_x27_309_ = v_tail_313_;
v_b_310_ = v___x_364_;
goto _start;
}
}
}
else
{
lean_dec_ref(v___y_388_);
v___y_335_ = v___y_389_;
goto v___jp_334_;
}
}
v___jp_395_:
{
switch(lean_obj_tag(v_snd_315_))
{
case 5:
{
lean_object* v_val_397_; lean_object* v_all_398_; uint8_t v___x_399_; 
v_val_397_ = lean_ctor_get(v_snd_315_, 0);
v_all_398_ = lean_ctor_get(v_val_397_, 3);
lean_inc(v_all_398_);
v___x_399_ = lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(v_all_398_);
if (v___x_399_ == 0)
{
lean_inc_ref(v_val_397_);
v___y_382_ = v_val_397_;
v___y_383_ = v___x_353_;
goto v___jp_381_;
}
else
{
lean_inc_ref(v_val_397_);
v___y_382_ = v_val_397_;
v___y_383_ = v___y_396_;
goto v___jp_381_;
}
}
case 6:
{
lean_object* v_val_400_; lean_object* v_induct_401_; lean_object* v_cidx_402_; lean_object* v___x_403_; 
v_val_400_ = lean_ctor_get(v_snd_315_, 0);
v_induct_401_ = lean_ctor_get(v_val_400_, 1);
v_cidx_402_ = lean_ctor_get(v_val_400_, 2);
v___x_403_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_308_, v_induct_401_);
if (lean_obj_tag(v___x_403_) == 1)
{
lean_object* v_val_404_; lean_object* v___x_406_; uint8_t v_isShared_407_; uint8_t v_isSharedCheck_426_; 
v_val_404_ = lean_ctor_get(v___x_403_, 0);
v_isSharedCheck_426_ = !lean_is_exclusive(v___x_403_);
if (v_isSharedCheck_426_ == 0)
{
v___x_406_ = v___x_403_;
v_isShared_407_ = v_isSharedCheck_426_;
goto v_resetjp_405_;
}
else
{
lean_inc(v_val_404_);
lean_dec(v___x_403_);
v___x_406_ = lean_box(0);
v_isShared_407_ = v_isSharedCheck_426_;
goto v_resetjp_405_;
}
v_resetjp_405_:
{
if (lean_obj_tag(v_val_404_) == 5)
{
lean_object* v_val_408_; lean_object* v___x_410_; uint8_t v_isShared_411_; uint8_t v_isSharedCheck_425_; 
v_val_408_ = lean_ctor_get(v_val_404_, 0);
v_isSharedCheck_425_ = !lean_is_exclusive(v_val_404_);
if (v_isSharedCheck_425_ == 0)
{
v___x_410_ = v_val_404_;
v_isShared_411_ = v_isSharedCheck_425_;
goto v_resetjp_409_;
}
else
{
lean_inc(v_val_408_);
lean_dec(v_val_404_);
v___x_410_ = lean_box(0);
v_isShared_411_ = v_isSharedCheck_425_;
goto v_resetjp_409_;
}
v_resetjp_409_:
{
lean_object* v_ctors_412_; lean_object* v___x_413_; lean_object* v___x_415_; 
v_ctors_412_ = lean_ctor_get(v_val_408_, 4);
lean_inc(v_ctors_412_);
lean_dec_ref(v_val_408_);
lean_inc(v_cidx_402_);
v___x_413_ = l_List_get_x3fInternal___redArg(v_ctors_412_, v_cidx_402_);
lean_dec(v_ctors_412_);
lean_inc(v_fst_314_);
if (v_isShared_407_ == 0)
{
lean_ctor_set(v___x_406_, 0, v_fst_314_);
v___x_415_ = v___x_406_;
goto v_reusejp_414_;
}
else
{
lean_object* v_reuseFailAlloc_424_; 
v_reuseFailAlloc_424_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_424_, 0, v_fst_314_);
v___x_415_ = v_reuseFailAlloc_424_;
goto v_reusejp_414_;
}
v_reusejp_414_:
{
uint8_t v___x_416_; 
v___x_416_ = lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2(v___x_413_, v___x_415_);
lean_dec_ref(v___x_415_);
lean_dec(v___x_413_);
if (v___x_416_ == 0)
{
lean_object* v___x_417_; lean_object* v___x_418_; lean_object* v___x_419_; lean_object* v___x_421_; 
v___x_417_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__10));
lean_inc(v_fst_314_);
v___x_418_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___x_353_);
v___x_419_ = lean_string_append(v___x_417_, v___x_418_);
lean_dec_ref(v___x_418_);
if (v_isShared_411_ == 0)
{
lean_ctor_set_tag(v___x_410_, 0);
lean_ctor_set(v___x_410_, 0, v___x_419_);
v___x_421_ = v___x_410_;
goto v_reusejp_420_;
}
else
{
lean_object* v_reuseFailAlloc_422_; 
v_reuseFailAlloc_422_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_422_, 0, v___x_419_);
v___x_421_ = v_reuseFailAlloc_422_;
goto v_reusejp_420_;
}
v_reusejp_420_:
{
return v___x_421_;
}
}
else
{
lean_del_object(v___x_410_);
v_as_x27_309_ = v_tail_313_;
v_b_310_ = v___x_364_;
goto _start;
}
}
}
}
else
{
lean_del_object(v___x_406_);
lean_dec(v_val_404_);
goto v___jp_354_;
}
}
}
else
{
lean_dec(v___x_403_);
goto v___jp_354_;
}
}
case 7:
{
lean_object* v_val_427_; lean_object* v_all_428_; uint8_t v___x_429_; 
v_val_427_ = lean_ctor_get(v_snd_315_, 0);
v_all_428_ = lean_ctor_get(v_val_427_, 1);
v___x_429_ = l_List_isEmpty___redArg(v_all_428_);
if (v___x_429_ == 0)
{
uint8_t v___x_430_; 
lean_inc(v_all_428_);
v___x_430_ = lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(v_all_428_);
if (v___x_430_ == 0)
{
v___y_335_ = v___x_353_;
goto v___jp_334_;
}
else
{
lean_inc_ref(v_val_427_);
v___y_388_ = v_val_427_;
v___y_389_ = v___x_429_;
goto v___jp_387_;
}
}
else
{
lean_inc_ref(v_val_427_);
v___y_388_ = v_val_427_;
v___y_389_ = v___x_429_;
goto v___jp_387_;
}
}
case 4:
{
lean_object* v___x_431_; lean_object* v___x_432_; 
v___x_431_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__22));
v___x_432_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg(v___x_353_, v_constants_308_, v___x_431_, v___x_364_);
if (lean_obj_tag(v___x_432_) == 0)
{
return v___x_432_;
}
else
{
lean_dec_ref_known(v___x_432_, 1);
v_as_x27_309_ = v_tail_313_;
v_b_310_ = v___x_364_;
goto _start;
}
}
default: 
{
v_as_x27_309_ = v_tail_313_;
v_b_310_ = v___x_364_;
goto _start;
}
}
}
v___jp_435_:
{
if (v___y_438_ == 0)
{
uint8_t v___x_439_; 
v___x_439_ = l_Lean_Expr_hasLooseBVars(v___y_437_);
lean_dec_ref(v___y_437_);
if (v___x_439_ == 0)
{
v___y_396_ = v___y_436_;
goto v___jp_395_;
}
else
{
v___y_347_ = v___x_439_;
goto v___jp_346_;
}
}
else
{
lean_dec_ref(v___y_437_);
v___y_347_ = v___y_438_;
goto v___jp_346_;
}
}
v___jp_440_:
{
if (v___y_441_ == 0)
{
lean_object* v___x_442_; uint8_t v___x_443_; 
v___x_442_ = l_Lean_ConstantInfo_type(v_snd_315_);
v___x_443_ = l_Lean_Expr_hasLooseBVars(v___x_442_);
lean_dec_ref(v___x_442_);
if (v___x_443_ == 0)
{
lean_object* v___x_444_; 
lean_inc(v_snd_315_);
v___x_444_ = l_Lean_ConstantInfo_value_x3f(v_snd_315_, v___x_353_);
if (lean_obj_tag(v___x_444_) == 1)
{
lean_object* v_val_445_; uint8_t v___x_446_; 
v_val_445_ = lean_ctor_get(v___x_444_, 0);
lean_inc(v_val_445_);
lean_dec_ref_known(v___x_444_, 1);
v___x_446_ = l_Lean_Expr_hasFVar(v_val_445_);
if (v___x_446_ == 0)
{
uint8_t v___x_447_; 
v___x_447_ = l_Lean_Expr_hasMVar(v_val_445_);
v___y_436_ = v___x_443_;
v___y_437_ = v_val_445_;
v___y_438_ = v___x_447_;
goto v___jp_435_;
}
else
{
v___y_436_ = v___x_443_;
v___y_437_ = v_val_445_;
v___y_438_ = v___x_446_;
goto v___jp_435_;
}
}
else
{
lean_dec(v___x_444_);
v___y_396_ = v___x_443_;
goto v___jp_395_;
}
}
else
{
v___y_329_ = v___x_443_;
goto v___jp_328_;
}
}
else
{
v___y_329_ = v___y_441_;
goto v___jp_328_;
}
}
v___jp_448_:
{
lean_object* v___x_449_; lean_object* v___x_450_; uint8_t v___x_451_; 
v___x_449_ = l_Lean_ConstantInfo_levelParams(v_snd_315_);
v___x_450_ = lean_box(0);
v___x_451_ = l_List_elem___at___00__private_Lean_Class_0__Lean_initFn_00___x40_Lean_Class_1274053790____hygCtx___hyg_2__spec__1(v___x_450_, v___x_449_);
lean_dec(v___x_449_);
if (v___x_451_ == 0)
{
lean_object* v___x_452_; uint8_t v___x_453_; 
v___x_452_ = l_Lean_ConstantInfo_type(v_snd_315_);
v___x_453_ = l_Lean_Expr_hasFVar(v___x_452_);
if (v___x_453_ == 0)
{
uint8_t v___x_454_; 
v___x_454_ = l_Lean_Expr_hasMVar(v___x_452_);
lean_dec_ref(v___x_452_);
v___y_441_ = v___x_454_;
goto v___jp_440_;
}
else
{
lean_dec_ref(v___x_452_);
v___y_441_ = v___x_453_;
goto v___jp_440_;
}
}
else
{
v___y_323_ = v___x_451_;
goto v___jp_322_;
}
}
v___jp_455_:
{
if (v___y_456_ == 0)
{
lean_object* v___x_457_; uint8_t v___x_458_; 
v___x_457_ = l_Lean_ConstantInfo_levelParams(v_snd_315_);
v___x_458_ = lp_proofEnvironment___private_OCMEnvironment_Families_0__OCMEnvironment_unique(v___x_457_);
if (v___x_458_ == 0)
{
if (v___x_353_ == 0)
{
goto v___jp_448_;
}
else
{
v___y_323_ = v___x_353_;
goto v___jp_322_;
}
}
else
{
goto v___jp_448_;
}
}
else
{
lean_object* v___x_459_; lean_object* v___x_460_; lean_object* v___x_461_; lean_object* v___x_462_; 
v___x_459_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__23));
lean_inc(v_fst_314_);
v___x_460_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_456_);
v___x_461_ = lean_string_append(v___x_459_, v___x_460_);
lean_dec_ref(v___x_460_);
v___x_462_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_462_, 0, v___x_461_);
return v___x_462_;
}
}
}
v___jp_316_:
{
lean_object* v___x_318_; lean_object* v___x_319_; lean_object* v___x_320_; lean_object* v___x_321_; 
v___x_318_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__0));
lean_inc(v_fst_314_);
v___x_319_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_317_);
v___x_320_ = lean_string_append(v___x_318_, v___x_319_);
lean_dec_ref(v___x_319_);
v___x_321_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_321_, 0, v___x_320_);
return v___x_321_;
}
v___jp_322_:
{
lean_object* v___x_324_; lean_object* v___x_325_; lean_object* v___x_326_; lean_object* v___x_327_; 
v___x_324_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__1));
lean_inc(v_fst_314_);
v___x_325_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_323_);
v___x_326_ = lean_string_append(v___x_324_, v___x_325_);
lean_dec_ref(v___x_325_);
v___x_327_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_327_, 0, v___x_326_);
return v___x_327_;
}
v___jp_328_:
{
lean_object* v___x_330_; lean_object* v___x_331_; lean_object* v___x_332_; lean_object* v___x_333_; 
v___x_330_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__2));
lean_inc(v_fst_314_);
v___x_331_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_329_);
v___x_332_ = lean_string_append(v___x_330_, v___x_331_);
lean_dec_ref(v___x_331_);
v___x_333_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_333_, 0, v___x_332_);
return v___x_333_;
}
v___jp_334_:
{
lean_object* v___x_336_; lean_object* v___x_337_; lean_object* v___x_338_; lean_object* v___x_339_; 
v___x_336_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__3));
lean_inc(v_fst_314_);
v___x_337_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_335_);
v___x_338_ = lean_string_append(v___x_336_, v___x_337_);
lean_dec_ref(v___x_337_);
v___x_339_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_339_, 0, v___x_338_);
return v___x_339_;
}
v___jp_340_:
{
lean_object* v___x_342_; lean_object* v___x_343_; lean_object* v___x_344_; lean_object* v___x_345_; 
v___x_342_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__4));
lean_inc(v_fst_314_);
v___x_343_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_341_);
v___x_344_ = lean_string_append(v___x_342_, v___x_343_);
lean_dec_ref(v___x_343_);
v___x_345_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_345_, 0, v___x_344_);
return v___x_345_;
}
v___jp_346_:
{
lean_object* v___x_348_; lean_object* v___x_349_; lean_object* v___x_350_; lean_object* v___x_351_; 
v___x_348_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__5));
lean_inc(v_fst_314_);
v___x_349_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___y_347_);
v___x_350_ = lean_string_append(v___x_348_, v___x_349_);
lean_dec_ref(v___x_349_);
v___x_351_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_351_, 0, v___x_350_);
return v___x_351_;
}
v___jp_354_:
{
lean_object* v___x_355_; lean_object* v___x_356_; lean_object* v___x_357_; lean_object* v___x_358_; 
v___x_355_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___closed__6));
lean_inc(v_fst_314_);
v___x_356_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_314_, v___x_353_);
v___x_357_ = lean_string_append(v___x_355_, v___x_356_);
lean_dec_ref(v___x_356_);
v___x_358_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_358_, 0, v___x_357_);
return v___x_358_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg___boxed(lean_object* v_constants_465_, lean_object* v_as_x27_466_, lean_object* v_b_467_){
_start:
{
lean_object* v_res_468_; 
v_res_468_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg(v_constants_465_, v_as_x27_466_, v_b_467_);
lean_dec(v_as_x27_466_);
lean_dec_ref(v_constants_465_);
return v_res_468_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateFamilies(lean_object* v_constants_471_){
_start:
{
lean_object* v___y_473_; lean_object* v_buckets_477_; lean_object* v___x_478_; lean_object* v___x_479_; lean_object* v___x_480_; uint8_t v___x_481_; 
v_buckets_477_ = lean_ctor_get(v_constants_471_, 1);
v___x_478_ = lean_box(0);
v___x_479_ = lean_array_get_size(v_buckets_477_);
v___x_480_ = lean_unsigned_to_nat(0u);
v___x_481_ = lean_nat_dec_lt(v___x_480_, v___x_479_);
if (v___x_481_ == 0)
{
v___y_473_ = v___x_478_;
goto v___jp_472_;
}
else
{
size_t v___x_482_; size_t v___x_483_; lean_object* v___x_484_; 
v___x_482_ = lean_usize_of_nat(v___x_479_);
v___x_483_ = ((size_t)0ULL);
v___x_484_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(v_buckets_477_, v___x_482_, v___x_483_, v___x_478_);
v___y_473_ = v___x_484_;
goto v___jp_472_;
}
v___jp_472_:
{
lean_object* v___x_474_; lean_object* v___x_475_; 
v___x_474_ = lean_box(0);
v___x_475_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg(v_constants_471_, v___y_473_, v___x_474_);
lean_dec(v___y_473_);
if (lean_obj_tag(v___x_475_) == 0)
{
return v___x_475_;
}
else
{
lean_object* v___x_476_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateFamilies___closed__0));
return v___x_476_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateFamilies___boxed(lean_object* v_constants_485_){
_start:
{
lean_object* v_res_486_; 
v_res_486_ = lp_proofEnvironment_OCMEnvironment_validateFamilies(v_constants_485_);
lean_dec_ref(v_constants_485_);
return v_res_486_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0(lean_object* v_fst_487_, uint8_t v___x_488_, lean_object* v_constants_489_, lean_object* v_val_490_, lean_object* v___x_491_, lean_object* v_as_492_, lean_object* v_as_x27_493_, lean_object* v_b_494_, lean_object* v_a_495_){
_start:
{
lean_object* v___x_496_; 
v___x_496_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___redArg(v_fst_487_, v___x_488_, v_constants_489_, v_val_490_, v___x_491_, v_as_x27_493_, v_b_494_);
return v___x_496_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0___boxed(lean_object* v_fst_497_, lean_object* v___x_498_, lean_object* v_constants_499_, lean_object* v_val_500_, lean_object* v___x_501_, lean_object* v_as_502_, lean_object* v_as_x27_503_, lean_object* v_b_504_, lean_object* v_a_505_){
_start:
{
uint8_t v___x_17225__boxed_506_; lean_object* v_res_507_; 
v___x_17225__boxed_506_ = lean_unbox(v___x_498_);
v_res_507_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__0(v_fst_497_, v___x_17225__boxed_506_, v_constants_499_, v_val_500_, v___x_501_, v_as_502_, v_as_x27_503_, v_b_504_, v_a_505_);
lean_dec(v_as_x27_503_);
lean_dec(v_as_502_);
lean_dec(v___x_501_);
lean_dec_ref(v_val_500_);
lean_dec_ref(v_constants_499_);
return v_res_507_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1(lean_object* v___x_508_, lean_object* v_fst_509_, uint8_t v___x_510_, lean_object* v_constants_511_, lean_object* v_val_512_, lean_object* v_range_513_, lean_object* v_b_514_, lean_object* v_i_515_, lean_object* v_hs_516_, lean_object* v_hl_517_){
_start:
{
lean_object* v___x_518_; 
v___x_518_ = lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___redArg(v___x_508_, v_fst_509_, v___x_510_, v_constants_511_, v_val_512_, v_range_513_, v_b_514_, v_i_515_);
return v___x_518_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1___boxed(lean_object* v___x_519_, lean_object* v_fst_520_, lean_object* v___x_521_, lean_object* v_constants_522_, lean_object* v_val_523_, lean_object* v_range_524_, lean_object* v_b_525_, lean_object* v_i_526_, lean_object* v_hs_527_, lean_object* v_hl_528_){
_start:
{
uint8_t v___x_17243__boxed_529_; lean_object* v_res_530_; 
v___x_17243__boxed_529_ = lean_unbox(v___x_521_);
v_res_530_ = lp_proofEnvironment___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__1(v___x_519_, v_fst_520_, v___x_17243__boxed_529_, v_constants_522_, v_val_523_, v_range_524_, v_b_525_, v_i_526_, v_hs_527_, v_hl_528_);
lean_dec_ref(v_range_524_);
lean_dec_ref(v_val_523_);
lean_dec_ref(v_constants_522_);
lean_dec(v___x_519_);
return v_res_530_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3(lean_object* v_fst_531_, uint8_t v___x_532_, lean_object* v_constants_533_, lean_object* v_as_534_, lean_object* v_as_x27_535_, lean_object* v_b_536_, lean_object* v_a_537_){
_start:
{
lean_object* v___x_538_; 
v___x_538_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___redArg(v_fst_531_, v___x_532_, v_constants_533_, v_as_x27_535_, v_b_536_);
return v___x_538_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3___boxed(lean_object* v_fst_539_, lean_object* v___x_540_, lean_object* v_constants_541_, lean_object* v_as_542_, lean_object* v_as_x27_543_, lean_object* v_b_544_, lean_object* v_a_545_){
_start:
{
uint8_t v___x_17256__boxed_546_; lean_object* v_res_547_; 
v___x_17256__boxed_546_ = lean_unbox(v___x_540_);
v_res_547_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__3(v_fst_539_, v___x_17256__boxed_546_, v_constants_541_, v_as_542_, v_as_x27_543_, v_b_544_, v_a_545_);
lean_dec(v_as_x27_543_);
lean_dec(v_as_542_);
lean_dec_ref(v_constants_541_);
return v_res_547_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4(lean_object* v_fst_548_, uint8_t v___x_549_, lean_object* v_constants_550_, lean_object* v_as_551_, lean_object* v_as_x27_552_, lean_object* v_b_553_, lean_object* v_a_554_){
_start:
{
lean_object* v___x_555_; 
v___x_555_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___redArg(v_fst_548_, v___x_549_, v_constants_550_, v_as_x27_552_, v_b_553_);
return v___x_555_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4___boxed(lean_object* v_fst_556_, lean_object* v___x_557_, lean_object* v_constants_558_, lean_object* v_as_559_, lean_object* v_as_x27_560_, lean_object* v_b_561_, lean_object* v_a_562_){
_start:
{
uint8_t v___x_17267__boxed_563_; lean_object* v_res_564_; 
v___x_17267__boxed_563_ = lean_unbox(v___x_557_);
v_res_564_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__4(v_fst_556_, v___x_17267__boxed_563_, v_constants_558_, v_as_559_, v_as_x27_560_, v_b_561_, v_a_562_);
lean_dec(v_as_x27_560_);
lean_dec(v_as_559_);
lean_dec_ref(v_constants_558_);
return v_res_564_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5(uint8_t v___x_565_, lean_object* v_constants_566_, lean_object* v_as_567_, lean_object* v_as_x27_568_, lean_object* v_b_569_, lean_object* v_a_570_){
_start:
{
lean_object* v___x_571_; 
v___x_571_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___redArg(v___x_565_, v_constants_566_, v_as_x27_568_, v_b_569_);
return v___x_571_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5___boxed(lean_object* v___x_572_, lean_object* v_constants_573_, lean_object* v_as_574_, lean_object* v_as_x27_575_, lean_object* v_b_576_, lean_object* v_a_577_){
_start:
{
uint8_t v___x_17277__boxed_578_; lean_object* v_res_579_; 
v___x_17277__boxed_578_ = lean_unbox(v___x_572_);
v_res_579_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__5(v___x_17277__boxed_578_, v_constants_573_, v_as_574_, v_as_x27_575_, v_b_576_, v_a_577_);
lean_dec(v_as_x27_575_);
lean_dec(v_as_574_);
lean_dec_ref(v_constants_573_);
return v_res_579_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6(lean_object* v_constants_580_, lean_object* v_as_581_, lean_object* v_as_x27_582_, lean_object* v_b_583_, lean_object* v_a_584_){
_start:
{
lean_object* v___x_585_; 
v___x_585_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___redArg(v_constants_580_, v_as_x27_582_, v_b_583_);
return v___x_585_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6___boxed(lean_object* v_constants_586_, lean_object* v_as_587_, lean_object* v_as_x27_588_, lean_object* v_b_589_, lean_object* v_a_590_){
_start:
{
lean_object* v_res_591_; 
v_res_591_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateFamilies_spec__6(v_constants_586_, v_as_587_, v_as_x27_588_, v_b_589_, v_a_590_);
lean_dec(v_as_x27_588_);
lean_dec(v_as_587_);
lean_dec_ref(v_constants_586_);
return v_res_591_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Dependencies(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Families(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Dependencies(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
