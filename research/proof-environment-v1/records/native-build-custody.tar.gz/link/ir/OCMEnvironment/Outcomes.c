// Lean compiler output
// Module: OCMEnvironment.Outcomes
// Imports: public import Init public meta import Init
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_string_utf8_byte_size(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_string_memcmp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00OCMEnvironment_refusalTerminal_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00OCMEnvironment_refusalTerminal_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "EXCLUDED_DEPENDENCY"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "UNREGISTERED_AXIOM"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "INDEPENDENT_TARGET_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "PRIMITIVE_IDENTITY_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "REGISTERED_AXIOM_HEADER_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__4_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "REGISTERED_PRIMITIVE_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__5_value;
static const lean_array_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*6, .m_other = 0, .m_tag = 246}, .m_size = 6, .m_capacity = 6, .m_data = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__2_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__3_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__4_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__5_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__6_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__8;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "CANNOT_CHECK"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__9_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static size_t lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__10;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "REJECTED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__11_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00OCMEnvironment_refusalTerminal_spec__0(lean_object* v_reason_1_, lean_object* v_as_2_, size_t v_i_3_, size_t v_stop_4_){
_start:
{
uint8_t v___x_5_; 
v___x_5_ = lean_usize_dec_eq(v_i_3_, v_stop_4_);
if (v___x_5_ == 0)
{
uint8_t v___x_6_; uint8_t v___y_8_; lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; uint8_t v___x_15_; 
v___x_6_ = 1;
v___x_12_ = lean_array_uget_borrowed(v_as_2_, v_i_3_);
v___x_13_ = lean_string_utf8_byte_size(v_reason_1_);
v___x_14_ = lean_string_utf8_byte_size(v___x_12_);
v___x_15_ = lean_nat_dec_le(v___x_14_, v___x_13_);
if (v___x_15_ == 0)
{
v___y_8_ = v___x_5_;
goto v___jp_7_;
}
else
{
lean_object* v___x_16_; uint8_t v___x_17_; 
v___x_16_ = lean_unsigned_to_nat(0u);
v___x_17_ = lean_string_memcmp(v_reason_1_, v___x_12_, v___x_16_, v___x_16_, v___x_14_);
v___y_8_ = v___x_17_;
goto v___jp_7_;
}
v___jp_7_:
{
if (v___y_8_ == 0)
{
size_t v___x_9_; size_t v___x_10_; 
v___x_9_ = ((size_t)1ULL);
v___x_10_ = lean_usize_add(v_i_3_, v___x_9_);
v_i_3_ = v___x_10_;
goto _start;
}
else
{
return v___x_6_;
}
}
}
else
{
uint8_t v___x_18_; 
v___x_18_ = 0;
return v___x_18_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00OCMEnvironment_refusalTerminal_spec__0___boxed(lean_object* v_reason_19_, lean_object* v_as_20_, lean_object* v_i_21_, lean_object* v_stop_22_){
_start:
{
size_t v_i_boxed_23_; size_t v_stop_boxed_24_; uint8_t v_res_25_; lean_object* v_r_26_; 
v_i_boxed_23_ = lean_unbox_usize(v_i_21_);
lean_dec(v_i_21_);
v_stop_boxed_24_ = lean_unbox_usize(v_stop_22_);
lean_dec(v_stop_22_);
v_res_25_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00OCMEnvironment_refusalTerminal_spec__0(v_reason_19_, v_as_20_, v_i_boxed_23_, v_stop_boxed_24_);
lean_dec_ref(v_as_20_);
lean_dec_ref(v_reason_19_);
v_r_26_ = lean_box(v_res_25_);
return v_r_26_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7(void){
_start:
{
lean_object* v___x_47_; lean_object* v___x_48_; 
v___x_47_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__6));
v___x_48_ = lean_array_get_size(v___x_47_);
return v___x_48_;
}
}
static uint8_t _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__8(void){
_start:
{
lean_object* v___x_49_; lean_object* v___x_50_; uint8_t v___x_51_; 
v___x_49_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7, &lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7_once, _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7);
v___x_50_ = lean_unsigned_to_nat(0u);
v___x_51_ = lean_nat_dec_lt(v___x_50_, v___x_49_);
return v___x_51_;
}
}
static size_t _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__10(void){
_start:
{
lean_object* v___x_53_; size_t v___x_54_; 
v___x_53_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7, &lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7_once, _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__7);
v___x_54_ = lean_usize_of_nat(v___x_53_);
return v___x_54_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal(lean_object* v_reason_56_){
_start:
{
lean_object* v___x_57_; uint8_t v___x_58_; 
v___x_57_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__6));
v___x_58_ = lean_uint8_once(&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__8, &lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__8_once, _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__8);
if (v___x_58_ == 0)
{
lean_object* v___x_59_; 
v___x_59_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__9));
return v___x_59_;
}
else
{
if (v___x_58_ == 0)
{
lean_object* v___x_60_; 
v___x_60_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__9));
return v___x_60_;
}
else
{
size_t v___x_61_; size_t v___x_62_; uint8_t v___x_63_; 
v___x_61_ = ((size_t)0ULL);
v___x_62_ = lean_usize_once(&lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__10, &lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__10_once, _init_lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__10);
v___x_63_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00OCMEnvironment_refusalTerminal_spec__0(v_reason_56_, v___x_57_, v___x_61_, v___x_62_);
if (v___x_63_ == 0)
{
lean_object* v___x_64_; 
v___x_64_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__9));
return v___x_64_;
}
else
{
lean_object* v___x_65_; 
v___x_65_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_refusalTerminal___closed__11));
return v___x_65_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal___boxed(lean_object* v_reason_66_){
_start:
{
lean_object* v_res_67_; 
v_res_67_ = lp_proofEnvironment_OCMEnvironment_refusalTerminal(v_reason_66_);
lean_dec_ref(v_reason_66_);
return v_res_67_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Outcomes(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
