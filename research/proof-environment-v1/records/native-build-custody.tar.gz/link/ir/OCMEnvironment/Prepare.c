// Lean compiler output
// Module: OCMEnvironment.Prepare
// Imports: public import Init public meta import Init public import OCMEnvironment.Families
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
size_t lean_array_size(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(lean_object*, lean_object*);
uint8_t l_Array_contains___at___00Lean_findField_x3f_spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
uint8_t l_List_elem___at___00__private_Lean_Class_0__Lean_initFn_00___x40_Lean_Class_1274053790____hygCtx___hyg_2__spec__1(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collect_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_validateFamilies(lean_object*);
lean_object* l_Lean_mkEmptyEnvironment(uint32_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___00Lean_LocalContext_findFromUserNames_spec__1___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Environment_replay(lean_object*, lean_object*);
lean_object* lean_elab_environment_to_kernel_env(lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_Lean_SMap_fold___at___00Lean_getRevAliases_spec__0___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(lean_object*, size_t, size_t, lean_object*);
lean_object* lean_kernel_check(lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_Options_empty;
lean_object* l_Lean_Kernel_Exception_toMessageData(lean_object*, lean_object*);
lean_object* l_Lean_MessageData_toString(lean_object*);
lean_object* l_Lean_Expr_sort___override(lean_object*);
uint8_t lean_expr_eqv(lean_object*, lean_object*);
lean_object* l_Array_append___redArg(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure(lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__0(lean_object*, lean_object*);
uint8_t l_Lean_Expr_hasLooseBVars(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(lean_object*, size_t, size_t, lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(lean_object*, lean_object*);
uint8_t l_Lean_Expr_hasMVar(lean_object*);
uint8_t l_Lean_Expr_hasFVar(lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "UNREGISTERED_AXIOM "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "sorryAx"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__1_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__1_value),LEAN_SCALAR_PTR_LITERAL(196, 190, 164, 146, 38, 179, 69, 72)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Lean"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "ofReduceBool"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__4_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__5_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__3_value),LEAN_SCALAR_PTR_LITERAL(70, 193, 83, 126, 233, 67, 208, 165)}};
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__5_value_aux_0),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__4_value),LEAN_SCALAR_PTR_LITERAL(33, 77, 217, 63, 156, 187, 147, 213)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__5_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "trustCompiler"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__6 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__6_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__7_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__3_value),LEAN_SCALAR_PTR_LITERAL(70, 193, 83, 126, 233, 67, 208, 165)}};
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__7_value_aux_0),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__6_value),LEAN_SCALAR_PTR_LITERAL(121, 250, 167, 102, 228, 12, 150, 57)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__7 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__7_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__7_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__8 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__8_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__5_value),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__8_value)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__9 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__9_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__2_value),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__9_value)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__10 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__10_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "MISSING_AXIOM_AUDIT_DEPENDENCY "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__11 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__11_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_proofEnvironment_OCMEnvironment_axiomNames___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_axiomNames___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_axiomNames___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_axiomNames(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_axiomNames___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_OCMEnvironment_checkedMap___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_OCMEnvironment_checkedMap___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_checkedMap___closed__0_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_checkedMap___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_checkedMap___closed__2;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_checkedMap(lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "GENERATED_DECLARATION_MISMATCH "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "MISSING_GENERATED_DECLARATION "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Quot"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "mk"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__1_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__2_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__0_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__2_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__1_value),LEAN_SCALAR_PTR_LITERAL(255, 113, 137, 82, 82, 132, 58, 248)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__4_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__0_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__4_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__3_value),LEAN_SCALAR_PTR_LITERAL(91, 125, 38, 34, 222, 200, 201, 80)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__4_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__5_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__6_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__0_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__6_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__5_value),LEAN_SCALAR_PTR_LITERAL(150, 213, 121, 152, 109, 27, 137, 60)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__6_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "GENERATED_MEMBERSHIP_SIZE "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_replayMap___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = " "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_replayMap___closed__8_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_replayMap(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_prepareMap___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__0;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_prepareMap___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__1;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_prepareMap___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__2;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "INVALID_TARGET "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_prepareMap___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__4;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "TARGET_NOT_PROPOSITION"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__5_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__5_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__6_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "OPEN_REGISTERED_TARGET"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__7_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__7_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__8_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "TARGET_NOT_EXCLUDED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_prepareMap___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__9_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__10_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "PRIMITIVE_IDENTITY_MISMATCH "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_mergePrimitives(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_mergePrimitives___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "MISSING_SOURCE_AXIOM_HEADER "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "MISSING_REGISTERED_AXIOM_HEADER "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "REGISTERED_AXIOM_HEADER_MISMATCH "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0(lean_object* v_constants_24_, lean_object* v_allowed_25_, lean_object* v_as_26_, size_t v_sz_27_, size_t v_i_28_, lean_object* v_b_29_){
_start:
{
lean_object* v_a_31_; uint8_t v___x_35_; 
v___x_35_ = lean_usize_dec_lt(v_i_28_, v_sz_27_);
if (v___x_35_ == 0)
{
lean_object* v___x_36_; 
v___x_36_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_36_, 0, v_b_29_);
return v___x_36_;
}
else
{
lean_object* v_a_37_; uint8_t v___y_39_; lean_object* v___x_44_; 
v_a_37_ = lean_array_uget_borrowed(v_as_26_, v_i_28_);
v___x_44_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_24_, v_a_37_);
if (lean_obj_tag(v___x_44_) == 1)
{
lean_object* v_val_45_; 
v_val_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_val_45_);
lean_dec_ref_known(v___x_44_, 1);
if (lean_obj_tag(v_val_45_) == 0)
{
uint8_t v___x_46_; 
lean_dec_ref_known(v_val_45_, 1);
v___x_46_ = l_Array_contains___at___00Lean_findField_x3f_spec__0(v_allowed_25_, v_a_37_);
if (v___x_46_ == 0)
{
lean_dec_ref(v_b_29_);
v___y_39_ = v___x_35_;
goto v___jp_38_;
}
else
{
lean_object* v___x_47_; uint8_t v___x_48_; 
v___x_47_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__10));
v___x_48_ = l_List_elem___at___00__private_Lean_Class_0__Lean_initFn_00___x40_Lean_Class_1274053790____hygCtx___hyg_2__spec__1(v_a_37_, v___x_47_);
if (v___x_48_ == 0)
{
lean_object* v___x_49_; 
lean_inc(v_a_37_);
v___x_49_ = lean_array_push(v_b_29_, v_a_37_);
v_a_31_ = v___x_49_;
goto v___jp_30_;
}
else
{
lean_dec_ref(v_b_29_);
v___y_39_ = v___x_48_;
goto v___jp_38_;
}
}
}
else
{
lean_dec(v_val_45_);
v_a_31_ = v_b_29_;
goto v___jp_30_;
}
}
else
{
lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; 
lean_dec(v___x_44_);
lean_dec_ref(v_b_29_);
v___x_50_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__11));
lean_inc(v_a_37_);
v___x_51_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_37_, v___x_35_);
v___x_52_ = lean_string_append(v___x_50_, v___x_51_);
lean_dec_ref(v___x_51_);
v___x_53_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_53_, 0, v___x_52_);
return v___x_53_;
}
v___jp_38_:
{
lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; 
v___x_40_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___closed__0));
lean_inc(v_a_37_);
v___x_41_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_37_, v___y_39_);
v___x_42_ = lean_string_append(v___x_40_, v___x_41_);
lean_dec_ref(v___x_41_);
v___x_43_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_43_, 0, v___x_42_);
return v___x_43_;
}
}
v___jp_30_:
{
size_t v___x_32_; size_t v___x_33_; 
v___x_32_ = ((size_t)1ULL);
v___x_33_ = lean_usize_add(v_i_28_, v___x_32_);
v_i_28_ = v___x_33_;
v_b_29_ = v_a_31_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0___boxed(lean_object* v_constants_54_, lean_object* v_allowed_55_, lean_object* v_as_56_, lean_object* v_sz_57_, lean_object* v_i_58_, lean_object* v_b_59_){
_start:
{
size_t v_sz_boxed_60_; size_t v_i_boxed_61_; lean_object* v_res_62_; 
v_sz_boxed_60_ = lean_unbox_usize(v_sz_57_);
lean_dec(v_sz_57_);
v_i_boxed_61_ = lean_unbox_usize(v_i_58_);
lean_dec(v_i_58_);
v_res_62_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0(v_constants_54_, v_allowed_55_, v_as_56_, v_sz_boxed_60_, v_i_boxed_61_, v_b_59_);
lean_dec_ref(v_as_56_);
lean_dec_ref(v_allowed_55_);
lean_dec_ref(v_constants_54_);
return v_res_62_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_axiomNames(lean_object* v_constants_65_, lean_object* v_names_66_, lean_object* v_allowed_67_){
_start:
{
lean_object* v___x_68_; lean_object* v_axioms_69_; size_t v_sz_70_; size_t v___x_71_; lean_object* v___x_72_; 
v___x_68_ = lean_unsigned_to_nat(0u);
v_axioms_69_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_axiomNames___closed__0));
v_sz_70_ = lean_array_size(v_names_66_);
v___x_71_ = ((size_t)0ULL);
v___x_72_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_axiomNames_spec__0(v_constants_65_, v_allowed_67_, v_names_66_, v_sz_70_, v___x_71_, v_axioms_69_);
if (lean_obj_tag(v___x_72_) == 0)
{
return v___x_72_;
}
else
{
lean_object* v_a_73_; lean_object* v___x_74_; lean_object* v___y_76_; lean_object* v___y_77_; uint8_t v___x_80_; 
v_a_73_ = lean_ctor_get(v___x_72_, 0);
lean_inc(v_a_73_);
v___x_74_ = lean_array_get_size(v_a_73_);
v___x_80_ = lean_nat_dec_eq(v___x_74_, v___x_68_);
if (v___x_80_ == 0)
{
lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___y_84_; uint8_t v___x_86_; 
lean_dec_ref_known(v___x_72_, 1);
v___x_81_ = lean_unsigned_to_nat(1u);
v___x_82_ = lean_nat_sub(v___x_74_, v___x_81_);
v___x_86_ = lean_nat_dec_le(v___x_68_, v___x_82_);
if (v___x_86_ == 0)
{
lean_inc(v___x_82_);
v___y_84_ = v___x_82_;
goto v___jp_83_;
}
else
{
v___y_84_ = v___x_68_;
goto v___jp_83_;
}
v___jp_83_:
{
uint8_t v___x_85_; 
v___x_85_ = lean_nat_dec_le(v___y_84_, v___x_82_);
if (v___x_85_ == 0)
{
lean_dec(v___x_82_);
lean_inc(v___y_84_);
v___y_76_ = v___y_84_;
v___y_77_ = v___y_84_;
goto v___jp_75_;
}
else
{
v___y_76_ = v___y_84_;
v___y_77_ = v___x_82_;
goto v___jp_75_;
}
}
}
else
{
lean_dec(v_a_73_);
return v___x_72_;
}
v___jp_75_:
{
lean_object* v___x_78_; lean_object* v___x_79_; 
v___x_78_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collect_spec__2___redArg(v___x_74_, v_a_73_, v___y_76_, v___y_77_);
lean_dec(v___y_77_);
v___x_79_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_79_, 0, v___x_78_);
return v___x_79_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_axiomNames___boxed(lean_object* v_constants_87_, lean_object* v_names_88_, lean_object* v_allowed_89_){
_start:
{
lean_object* v_res_90_; 
v_res_90_ = lp_proofEnvironment_OCMEnvironment_axiomNames(v_constants_87_, v_names_88_, v_allowed_89_);
lean_dec_ref(v_allowed_89_);
lean_dec_ref(v_names_88_);
lean_dec_ref(v_constants_87_);
return v_res_90_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1(void){
_start:
{
lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; 
v___x_92_ = lean_box(0);
v___x_93_ = lean_unsigned_to_nat(16u);
v___x_94_ = lean_mk_array(v___x_93_, v___x_92_);
return v___x_94_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_checkedMap___closed__2(void){
_start:
{
lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; 
v___x_95_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1, &lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1_once, _init_lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1);
v___x_96_ = lean_unsigned_to_nat(0u);
v___x_97_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_97_, 0, v___x_96_);
lean_ctor_set(v___x_97_, 1, v___x_95_);
return v___x_97_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_checkedMap(lean_object* v_env_98_){
_start:
{
lean_object* v___x_99_; lean_object* v_constants_100_; lean_object* v___f_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v___x_99_ = lean_elab_environment_to_kernel_env(v_env_98_);
v_constants_100_ = lean_ctor_get(v___x_99_, 0);
lean_inc_ref(v_constants_100_);
lean_dec_ref(v___x_99_);
v___f_101_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_checkedMap___closed__0));
v___x_102_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_checkedMap___closed__2, &lp_proofEnvironment_OCMEnvironment_checkedMap___closed__2_once, _init_lp_proofEnvironment_OCMEnvironment_checkedMap___closed__2);
v___x_103_ = l_Lean_SMap_fold___at___00Lean_getRevAliases_spec__0___redArg(v___f_101_, v___x_102_, v_constants_100_);
lean_dec_ref(v_constants_100_);
return v___x_103_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg(lean_object* v___x_106_, lean_object* v___x_107_, lean_object* v___x_108_, lean_object* v_as_x27_109_, lean_object* v_b_110_){
_start:
{
if (lean_obj_tag(v_as_x27_109_) == 0)
{
lean_object* v___x_112_; 
v___x_112_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_112_, 0, v_b_110_);
return v___x_112_;
}
else
{
lean_object* v_head_113_; lean_object* v_tail_114_; lean_object* v_fst_115_; lean_object* v_snd_116_; uint8_t v___x_117_; lean_object* v___x_118_; 
v_head_113_ = lean_ctor_get(v_as_x27_109_, 0);
v_tail_114_ = lean_ctor_get(v_as_x27_109_, 1);
v_fst_115_ = lean_ctor_get(v_head_113_, 0);
v_snd_116_ = lean_ctor_get(v_head_113_, 1);
v___x_117_ = lean_nat_dec_eq(v___x_107_, v___x_108_);
v___x_118_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v___x_106_, v_fst_115_);
if (lean_obj_tag(v___x_118_) == 1)
{
lean_object* v_val_119_; lean_object* v___x_121_; uint8_t v_isShared_122_; uint8_t v_isSharedCheck_133_; 
v_val_119_ = lean_ctor_get(v___x_118_, 0);
v_isSharedCheck_133_ = !lean_is_exclusive(v___x_118_);
if (v_isSharedCheck_133_ == 0)
{
v___x_121_ = v___x_118_;
v_isShared_122_ = v_isSharedCheck_133_;
goto v_resetjp_120_;
}
else
{
lean_inc(v_val_119_);
lean_dec(v___x_118_);
v___x_121_ = lean_box(0);
v_isShared_122_ = v_isSharedCheck_133_;
goto v_resetjp_120_;
}
v_resetjp_120_:
{
uint8_t v___x_123_; 
v___x_123_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_snd_116_, v_val_119_);
lean_dec(v_val_119_);
if (v___x_123_ == 0)
{
lean_object* v___x_124_; lean_object* v___x_125_; lean_object* v___x_126_; lean_object* v___x_128_; 
v___x_124_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__0));
lean_inc(v_fst_115_);
v___x_125_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_115_, v___x_117_);
v___x_126_ = lean_string_append(v___x_124_, v___x_125_);
lean_dec_ref(v___x_125_);
if (v_isShared_122_ == 0)
{
lean_ctor_set_tag(v___x_121_, 18);
lean_ctor_set(v___x_121_, 0, v___x_126_);
v___x_128_ = v___x_121_;
goto v_reusejp_127_;
}
else
{
lean_object* v_reuseFailAlloc_130_; 
v_reuseFailAlloc_130_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_130_, 0, v___x_126_);
v___x_128_ = v_reuseFailAlloc_130_;
goto v_reusejp_127_;
}
v_reusejp_127_:
{
lean_object* v___x_129_; 
v___x_129_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_129_, 0, v___x_128_);
return v___x_129_;
}
}
else
{
lean_object* v___x_131_; 
lean_del_object(v___x_121_);
v___x_131_ = lean_box(0);
v_as_x27_109_ = v_tail_114_;
v_b_110_ = v___x_131_;
goto _start;
}
}
}
else
{
lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; 
lean_dec(v___x_118_);
v___x_134_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___closed__1));
lean_inc(v_fst_115_);
v___x_135_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_115_, v___x_117_);
v___x_136_ = lean_string_append(v___x_134_, v___x_135_);
lean_dec_ref(v___x_135_);
v___x_137_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_137_, 0, v___x_136_);
v___x_138_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_138_, 0, v___x_137_);
return v___x_138_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg___boxed(lean_object* v___x_139_, lean_object* v___x_140_, lean_object* v___x_141_, lean_object* v_as_x27_142_, lean_object* v_b_143_, lean_object* v___y_144_){
_start:
{
lean_object* v_res_145_; 
v_res_145_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg(v___x_139_, v___x_140_, v___x_141_, v_as_x27_142_, v_b_143_);
lean_dec(v_as_x27_142_);
lean_dec(v___x_141_);
lean_dec(v___x_140_);
lean_dec_ref(v___x_139_);
return v_res_145_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_replayMap(lean_object* v_constants_161_){
_start:
{
lean_object* v___x_163_; lean_object* v___x_164_; 
v___x_163_ = lp_proofEnvironment_OCMEnvironment_validateFamilies(v_constants_161_);
v___x_164_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_163_);
if (lean_obj_tag(v___x_164_) == 0)
{
lean_object* v___x_165_; uint32_t v___x_166_; lean_object* v___x_167_; 
lean_dec_ref_known(v___x_164_, 1);
v___x_165_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_replayMap___closed__2));
v___x_166_ = 0;
v___x_167_ = l_Lean_mkEmptyEnvironment(v___x_166_);
if (lean_obj_tag(v___x_167_) == 0)
{
lean_object* v_a_168_; lean_object* v___x_170_; uint8_t v_isShared_171_; uint8_t v_isSharedCheck_228_; 
v_a_168_ = lean_ctor_get(v___x_167_, 0);
v_isSharedCheck_228_ = !lean_is_exclusive(v___x_167_);
if (v_isSharedCheck_228_ == 0)
{
v___x_170_ = v___x_167_;
v_isShared_171_ = v_isSharedCheck_228_;
goto v_resetjp_169_;
}
else
{
lean_inc(v_a_168_);
lean_dec(v___x_167_);
v___x_170_ = lean_box(0);
v_isShared_171_ = v_isSharedCheck_228_;
goto v_resetjp_169_;
}
v_resetjp_169_:
{
lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v___x_177_; 
v___x_172_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_replayMap___closed__4));
lean_inc_ref(v_constants_161_);
v___x_173_ = l_Std_DHashMap_Internal_Raw_u2080_erase___at___00Lean_LocalContext_findFromUserNames_spec__1___redArg(v_constants_161_, v___x_165_);
v___x_174_ = l_Std_DHashMap_Internal_Raw_u2080_erase___at___00Lean_LocalContext_findFromUserNames_spec__1___redArg(v___x_173_, v___x_172_);
v___x_175_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_replayMap___closed__6));
v___x_176_ = l_Std_DHashMap_Internal_Raw_u2080_erase___at___00Lean_LocalContext_findFromUserNames_spec__1___redArg(v___x_174_, v___x_175_);
v___x_177_ = l_Lean_Environment_replay(v___x_176_, v_a_168_);
lean_dec_ref(v___x_176_);
if (lean_obj_tag(v___x_177_) == 0)
{
lean_object* v_a_178_; lean_object* v___x_180_; uint8_t v_isShared_181_; uint8_t v_isSharedCheck_227_; 
v_a_178_ = lean_ctor_get(v___x_177_, 0);
v_isSharedCheck_227_ = !lean_is_exclusive(v___x_177_);
if (v_isSharedCheck_227_ == 0)
{
v___x_180_ = v___x_177_;
v_isShared_181_ = v_isSharedCheck_227_;
goto v_resetjp_179_;
}
else
{
lean_inc(v_a_178_);
lean_dec(v___x_177_);
v___x_180_ = lean_box(0);
v_isShared_181_ = v_isSharedCheck_227_;
goto v_resetjp_179_;
}
v_resetjp_179_:
{
lean_object* v___x_182_; lean_object* v_size_183_; lean_object* v_size_184_; lean_object* v_buckets_185_; lean_object* v___y_187_; uint8_t v___x_206_; 
lean_inc(v_a_178_);
v___x_182_ = lp_proofEnvironment_OCMEnvironment_checkedMap(v_a_178_);
v_size_183_ = lean_ctor_get(v___x_182_, 0);
lean_inc(v_size_183_);
v_size_184_ = lean_ctor_get(v_constants_161_, 0);
lean_inc(v_size_184_);
v_buckets_185_ = lean_ctor_get(v_constants_161_, 1);
lean_inc_ref(v_buckets_185_);
lean_dec_ref(v_constants_161_);
v___x_206_ = lean_nat_dec_eq(v_size_183_, v_size_184_);
if (v___x_206_ == 0)
{
lean_object* v___x_207_; lean_object* v___x_208_; lean_object* v___x_209_; lean_object* v___x_210_; lean_object* v___x_211_; lean_object* v___x_212_; lean_object* v___x_213_; lean_object* v___x_215_; 
lean_dec_ref(v_buckets_185_);
lean_dec_ref(v___x_182_);
lean_dec(v_a_178_);
v___x_207_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_replayMap___closed__7));
v___x_208_ = l_Nat_reprFast(v_size_184_);
v___x_209_ = lean_string_append(v___x_207_, v___x_208_);
lean_dec_ref(v___x_208_);
v___x_210_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_replayMap___closed__8));
v___x_211_ = lean_string_append(v___x_209_, v___x_210_);
v___x_212_ = l_Nat_reprFast(v_size_183_);
v___x_213_ = lean_string_append(v___x_211_, v___x_212_);
lean_dec_ref(v___x_212_);
if (v_isShared_171_ == 0)
{
lean_ctor_set_tag(v___x_170_, 18);
lean_ctor_set(v___x_170_, 0, v___x_213_);
v___x_215_ = v___x_170_;
goto v_reusejp_214_;
}
else
{
lean_object* v_reuseFailAlloc_219_; 
v_reuseFailAlloc_219_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_219_, 0, v___x_213_);
v___x_215_ = v_reuseFailAlloc_219_;
goto v_reusejp_214_;
}
v_reusejp_214_:
{
lean_object* v___x_217_; 
if (v_isShared_181_ == 0)
{
lean_ctor_set_tag(v___x_180_, 1);
lean_ctor_set(v___x_180_, 0, v___x_215_);
v___x_217_ = v___x_180_;
goto v_reusejp_216_;
}
else
{
lean_object* v_reuseFailAlloc_218_; 
v_reuseFailAlloc_218_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_218_, 0, v___x_215_);
v___x_217_ = v_reuseFailAlloc_218_;
goto v_reusejp_216_;
}
v_reusejp_216_:
{
return v___x_217_;
}
}
}
else
{
lean_object* v___x_220_; lean_object* v___x_221_; lean_object* v___x_222_; uint8_t v___x_223_; 
lean_del_object(v___x_180_);
lean_del_object(v___x_170_);
v___x_220_ = lean_box(0);
v___x_221_ = lean_array_get_size(v_buckets_185_);
v___x_222_ = lean_unsigned_to_nat(0u);
v___x_223_ = lean_nat_dec_lt(v___x_222_, v___x_221_);
if (v___x_223_ == 0)
{
lean_dec_ref(v_buckets_185_);
v___y_187_ = v___x_220_;
goto v___jp_186_;
}
else
{
size_t v___x_224_; size_t v___x_225_; lean_object* v___x_226_; 
v___x_224_ = lean_usize_of_nat(v___x_221_);
v___x_225_ = ((size_t)0ULL);
v___x_226_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(v_buckets_185_, v___x_224_, v___x_225_, v___x_220_);
lean_dec_ref(v_buckets_185_);
v___y_187_ = v___x_226_;
goto v___jp_186_;
}
}
v___jp_186_:
{
lean_object* v___x_188_; lean_object* v___x_189_; 
v___x_188_ = lean_box(0);
v___x_189_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg(v___x_182_, v_size_183_, v_size_184_, v___y_187_, v___x_188_);
lean_dec(v___y_187_);
lean_dec(v_size_184_);
lean_dec(v_size_183_);
lean_dec_ref(v___x_182_);
if (lean_obj_tag(v___x_189_) == 0)
{
lean_object* v___x_191_; uint8_t v_isShared_192_; uint8_t v_isSharedCheck_196_; 
v_isSharedCheck_196_ = !lean_is_exclusive(v___x_189_);
if (v_isSharedCheck_196_ == 0)
{
lean_object* v_unused_197_; 
v_unused_197_ = lean_ctor_get(v___x_189_, 0);
lean_dec(v_unused_197_);
v___x_191_ = v___x_189_;
v_isShared_192_ = v_isSharedCheck_196_;
goto v_resetjp_190_;
}
else
{
lean_dec(v___x_189_);
v___x_191_ = lean_box(0);
v_isShared_192_ = v_isSharedCheck_196_;
goto v_resetjp_190_;
}
v_resetjp_190_:
{
lean_object* v___x_194_; 
if (v_isShared_192_ == 0)
{
lean_ctor_set(v___x_191_, 0, v_a_178_);
v___x_194_ = v___x_191_;
goto v_reusejp_193_;
}
else
{
lean_object* v_reuseFailAlloc_195_; 
v_reuseFailAlloc_195_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_195_, 0, v_a_178_);
v___x_194_ = v_reuseFailAlloc_195_;
goto v_reusejp_193_;
}
v_reusejp_193_:
{
return v___x_194_;
}
}
}
else
{
lean_object* v_a_198_; lean_object* v___x_200_; uint8_t v_isShared_201_; uint8_t v_isSharedCheck_205_; 
lean_dec(v_a_178_);
v_a_198_ = lean_ctor_get(v___x_189_, 0);
v_isSharedCheck_205_ = !lean_is_exclusive(v___x_189_);
if (v_isSharedCheck_205_ == 0)
{
v___x_200_ = v___x_189_;
v_isShared_201_ = v_isSharedCheck_205_;
goto v_resetjp_199_;
}
else
{
lean_inc(v_a_198_);
lean_dec(v___x_189_);
v___x_200_ = lean_box(0);
v_isShared_201_ = v_isSharedCheck_205_;
goto v_resetjp_199_;
}
v_resetjp_199_:
{
lean_object* v___x_203_; 
if (v_isShared_201_ == 0)
{
v___x_203_ = v___x_200_;
goto v_reusejp_202_;
}
else
{
lean_object* v_reuseFailAlloc_204_; 
v_reuseFailAlloc_204_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_204_, 0, v_a_198_);
v___x_203_ = v_reuseFailAlloc_204_;
goto v_reusejp_202_;
}
v_reusejp_202_:
{
return v___x_203_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_170_);
lean_dec_ref(v_constants_161_);
return v___x_177_;
}
}
}
else
{
lean_dec_ref(v_constants_161_);
return v___x_167_;
}
}
else
{
lean_object* v_a_229_; lean_object* v___x_231_; uint8_t v_isShared_232_; uint8_t v_isSharedCheck_236_; 
lean_dec_ref(v_constants_161_);
v_a_229_ = lean_ctor_get(v___x_164_, 0);
v_isSharedCheck_236_ = !lean_is_exclusive(v___x_164_);
if (v_isSharedCheck_236_ == 0)
{
v___x_231_ = v___x_164_;
v_isShared_232_ = v_isSharedCheck_236_;
goto v_resetjp_230_;
}
else
{
lean_inc(v_a_229_);
lean_dec(v___x_164_);
v___x_231_ = lean_box(0);
v_isShared_232_ = v_isSharedCheck_236_;
goto v_resetjp_230_;
}
v_resetjp_230_:
{
lean_object* v___x_234_; 
if (v_isShared_232_ == 0)
{
v___x_234_ = v___x_231_;
goto v_reusejp_233_;
}
else
{
lean_object* v_reuseFailAlloc_235_; 
v_reuseFailAlloc_235_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_235_, 0, v_a_229_);
v___x_234_ = v_reuseFailAlloc_235_;
goto v_reusejp_233_;
}
v_reusejp_233_:
{
return v___x_234_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_replayMap___boxed(lean_object* v_constants_237_, lean_object* v_a_238_){
_start:
{
lean_object* v_res_239_; 
v_res_239_ = lp_proofEnvironment_OCMEnvironment_replayMap(v_constants_237_);
return v_res_239_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0(lean_object* v___x_240_, lean_object* v___x_241_, lean_object* v___x_242_, lean_object* v_as_243_, lean_object* v_as_x27_244_, lean_object* v_b_245_, lean_object* v_a_246_){
_start:
{
lean_object* v___x_248_; 
v___x_248_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___redArg(v___x_240_, v___x_241_, v___x_242_, v_as_x27_244_, v_b_245_);
return v___x_248_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0___boxed(lean_object* v___x_249_, lean_object* v___x_250_, lean_object* v___x_251_, lean_object* v_as_252_, lean_object* v_as_x27_253_, lean_object* v_b_254_, lean_object* v_a_255_, lean_object* v___y_256_){
_start:
{
lean_object* v_res_257_; 
v_res_257_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_replayMap_spec__0(v___x_249_, v___x_250_, v___x_251_, v_as_252_, v_as_x27_253_, v_b_254_, v_a_255_);
lean_dec(v_as_x27_253_);
lean_dec(v_as_252_);
lean_dec(v___x_251_);
lean_dec(v___x_250_);
lean_dec_ref(v___x_249_);
return v_res_257_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0(lean_object* v_constants_258_, lean_object* v_as_259_, size_t v_i_260_, size_t v_stop_261_, lean_object* v_b_262_){
_start:
{
uint8_t v___x_263_; 
v___x_263_ = lean_usize_dec_eq(v_i_260_, v_stop_261_);
if (v___x_263_ == 0)
{
lean_object* v___x_264_; lean_object* v___x_265_; lean_object* v___x_266_; size_t v___x_267_; size_t v___x_268_; 
v___x_264_ = lean_array_uget_borrowed(v_as_259_, v_i_260_);
v___x_265_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__0(v_constants_258_, v___x_264_);
lean_inc(v___x_264_);
v___x_266_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg(v_b_262_, v___x_264_, v___x_265_);
v___x_267_ = ((size_t)1ULL);
v___x_268_ = lean_usize_add(v_i_260_, v___x_267_);
v_i_260_ = v___x_268_;
v_b_262_ = v___x_266_;
goto _start;
}
else
{
return v_b_262_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0___boxed(lean_object* v_constants_270_, lean_object* v_as_271_, lean_object* v_i_272_, lean_object* v_stop_273_, lean_object* v_b_274_){
_start:
{
size_t v_i_boxed_275_; size_t v_stop_boxed_276_; lean_object* v_res_277_; 
v_i_boxed_275_ = lean_unbox_usize(v_i_272_);
lean_dec(v_i_272_);
v_stop_boxed_276_ = lean_unbox_usize(v_stop_273_);
lean_dec(v_stop_273_);
v_res_277_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0(v_constants_270_, v_as_271_, v_i_boxed_275_, v_stop_boxed_276_, v_b_274_);
lean_dec_ref(v_as_271_);
lean_dec_ref(v_constants_270_);
return v_res_277_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__0(void){
_start:
{
lean_object* v___x_278_; 
v___x_278_ = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return v___x_278_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__1(void){
_start:
{
lean_object* v___x_279_; lean_object* v___x_280_; 
v___x_279_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__0, &lp_proofEnvironment_OCMEnvironment_prepareMap___closed__0_once, _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__0);
v___x_280_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_280_, 0, v___x_279_);
return v___x_280_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__2(void){
_start:
{
lean_object* v___x_281_; lean_object* v___x_282_; lean_object* v___x_283_; 
v___x_281_ = lean_unsigned_to_nat(32u);
v___x_282_ = lean_mk_empty_array_with_capacity(v___x_281_);
v___x_283_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_283_, 0, v___x_282_);
return v___x_283_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__4(void){
_start:
{
lean_object* v___x_285_; lean_object* v___x_286_; 
v___x_285_ = lean_box(0);
v___x_286_ = l_Lean_Expr_sort___override(v___x_285_);
return v___x_286_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap(lean_object* v_constants_296_, lean_object* v_policy_297_){
_start:
{
lean_object* v___y_300_; lean_object* v___y_301_; lean_object* v___y_302_; lean_object* v___y_303_; lean_object* v___y_304_; lean_object* v___y_305_; lean_object* v___y_306_; lean_object* v___y_307_; lean_object* v___y_308_; lean_object* v___y_309_; lean_object* v___y_310_; lean_object* v___y_374_; lean_object* v___y_375_; lean_object* v___y_376_; lean_object* v___y_377_; lean_object* v___y_378_; lean_object* v___y_379_; lean_object* v___y_380_; lean_object* v___y_381_; lean_object* v___y_382_; lean_object* v___y_408_; lean_object* v___y_409_; lean_object* v___y_410_; lean_object* v___y_411_; lean_object* v___y_412_; lean_object* v___y_413_; lean_object* v___y_414_; lean_object* v___y_415_; lean_object* v___y_416_; lean_object* v___y_417_; lean_object* v___y_418_; lean_object* v___y_419_; lean_object* v___y_422_; lean_object* v___y_423_; lean_object* v___y_424_; lean_object* v___y_425_; lean_object* v___y_426_; lean_object* v___y_427_; lean_object* v___y_428_; lean_object* v___y_429_; lean_object* v___y_430_; lean_object* v___y_431_; lean_object* v___y_432_; lean_object* v___y_433_; lean_object* v___y_436_; lean_object* v___y_437_; lean_object* v___y_438_; lean_object* v___y_439_; lean_object* v___y_440_; lean_object* v___y_441_; lean_object* v___y_442_; lean_object* v___y_443_; lean_object* v_target_453_; lean_object* v_roots_454_; lean_object* v_excluded_455_; lean_object* v_axioms_456_; lean_object* v_maxHeartbeats_457_; lean_object* v_maxRecDepth_458_; lean_object* v_name_459_; lean_object* v_type_460_; uint8_t v___y_462_; uint8_t v___x_478_; 
v_target_453_ = lean_ctor_get(v_policy_297_, 0);
lean_inc_ref(v_target_453_);
v_roots_454_ = lean_ctor_get(v_policy_297_, 1);
lean_inc_ref(v_roots_454_);
v_excluded_455_ = lean_ctor_get(v_policy_297_, 2);
lean_inc_ref(v_excluded_455_);
v_axioms_456_ = lean_ctor_get(v_policy_297_, 3);
lean_inc_ref(v_axioms_456_);
v_maxHeartbeats_457_ = lean_ctor_get(v_policy_297_, 4);
lean_inc(v_maxHeartbeats_457_);
v_maxRecDepth_458_ = lean_ctor_get(v_policy_297_, 5);
lean_inc(v_maxRecDepth_458_);
lean_dec_ref(v_policy_297_);
v_name_459_ = lean_ctor_get(v_target_453_, 0);
v_type_460_ = lean_ctor_get(v_target_453_, 2);
lean_inc_ref(v_type_460_);
v___x_478_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_excluded_455_, v_name_459_);
if (v___x_478_ == 0)
{
lean_object* v___x_479_; lean_object* v___x_480_; 
lean_dec_ref(v_type_460_);
lean_dec(v_maxRecDepth_458_);
lean_dec(v_maxHeartbeats_457_);
lean_dec_ref(v_axioms_456_);
lean_dec_ref(v_excluded_455_);
lean_dec_ref(v_roots_454_);
lean_dec_ref(v_target_453_);
v___x_479_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_prepareMap___closed__10));
v___x_480_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_480_, 0, v___x_479_);
return v___x_480_;
}
else
{
uint8_t v___x_481_; 
v___x_481_ = l_Lean_Expr_hasMVar(v_type_460_);
if (v___x_481_ == 0)
{
uint8_t v___x_482_; 
v___x_482_ = l_Lean_Expr_hasFVar(v_type_460_);
v___y_462_ = v___x_482_;
goto v___jp_461_;
}
else
{
v___y_462_ = v___x_481_;
goto v___jp_461_;
}
}
v___jp_299_:
{
lean_object* v___x_311_; lean_object* v___x_312_; 
v___x_311_ = lp_proofEnvironment_OCMEnvironment_axiomNames(v___y_310_, v___y_303_, v___y_304_);
lean_dec_ref(v___y_304_);
lean_dec_ref(v___y_303_);
v___x_312_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_311_);
if (lean_obj_tag(v___x_312_) == 0)
{
lean_object* v_a_313_; lean_object* v___x_314_; 
v_a_313_ = lean_ctor_get(v___x_312_, 0);
lean_inc(v_a_313_);
lean_dec_ref_known(v___x_312_, 1);
lean_inc_ref(v___y_310_);
v___x_314_ = lp_proofEnvironment_OCMEnvironment_replayMap(v___y_310_);
if (lean_obj_tag(v___x_314_) == 0)
{
lean_object* v_a_315_; lean_object* v___x_317_; uint8_t v_isShared_318_; uint8_t v_isSharedCheck_356_; 
v_a_315_ = lean_ctor_get(v___x_314_, 0);
v_isSharedCheck_356_ = !lean_is_exclusive(v___x_314_);
if (v_isSharedCheck_356_ == 0)
{
v___x_317_ = v___x_314_;
v_isShared_318_ = v_isSharedCheck_356_;
goto v_resetjp_316_;
}
else
{
lean_inc(v_a_315_);
lean_dec(v___x_314_);
v___x_317_ = lean_box(0);
v_isShared_318_ = v_isSharedCheck_356_;
goto v_resetjp_316_;
}
v_resetjp_316_:
{
lean_object* v___x_319_; lean_object* v___x_320_; lean_object* v___x_321_; lean_object* v___x_322_; size_t v___x_323_; lean_object* v___x_324_; lean_object* v___x_325_; lean_object* v___x_326_; lean_object* v___x_327_; 
v___x_319_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__1, &lp_proofEnvironment_OCMEnvironment_prepareMap___closed__1_once, _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__1);
v___x_320_ = lean_unsigned_to_nat(32u);
v___x_321_ = lean_mk_empty_array_with_capacity(v___x_320_);
v___x_322_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__2, &lp_proofEnvironment_OCMEnvironment_prepareMap___closed__2_once, _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__2);
v___x_323_ = ((size_t)5ULL);
lean_inc(v___y_309_);
v___x_324_ = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(v___x_324_, 0, v___x_322_);
lean_ctor_set(v___x_324_, 1, v___x_321_);
lean_ctor_set(v___x_324_, 2, v___y_309_);
lean_ctor_set(v___x_324_, 3, v___y_309_);
lean_ctor_set_usize(v___x_324_, 4, v___x_323_);
v___x_325_ = lean_box(1);
v___x_326_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_326_, 0, v___x_319_);
lean_ctor_set(v___x_326_, 1, v___x_324_);
lean_ctor_set(v___x_326_, 2, v___x_325_);
lean_inc(v_a_315_);
v___x_327_ = lean_kernel_check(v_a_315_, v___x_326_, v___y_300_);
if (lean_obj_tag(v___x_327_) == 0)
{
lean_object* v_a_328_; lean_object* v___x_330_; uint8_t v_isShared_331_; uint8_t v_isSharedCheck_343_; 
lean_dec(v_a_315_);
lean_dec(v_a_313_);
lean_dec_ref(v___y_310_);
lean_dec(v___y_308_);
lean_dec_ref(v___y_307_);
lean_dec(v___y_306_);
lean_dec_ref(v___y_305_);
lean_dec_ref(v___y_302_);
lean_dec_ref(v___y_301_);
v_a_328_ = lean_ctor_get(v___x_327_, 0);
v_isSharedCheck_343_ = !lean_is_exclusive(v___x_327_);
if (v_isSharedCheck_343_ == 0)
{
v___x_330_ = v___x_327_;
v_isShared_331_ = v_isSharedCheck_343_;
goto v_resetjp_329_;
}
else
{
lean_inc(v_a_328_);
lean_dec(v___x_327_);
v___x_330_ = lean_box(0);
v_isShared_331_ = v_isSharedCheck_343_;
goto v_resetjp_329_;
}
v_resetjp_329_:
{
lean_object* v___x_332_; lean_object* v___x_333_; lean_object* v___x_334_; lean_object* v___x_335_; lean_object* v___x_336_; lean_object* v___x_338_; 
v___x_332_ = l_Lean_Options_empty;
v___x_333_ = l_Lean_Kernel_Exception_toMessageData(v_a_328_, v___x_332_);
v___x_334_ = l_Lean_MessageData_toString(v___x_333_);
v___x_335_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_prepareMap___closed__3));
v___x_336_ = lean_string_append(v___x_335_, v___x_334_);
lean_dec_ref(v___x_334_);
if (v_isShared_331_ == 0)
{
lean_ctor_set_tag(v___x_330_, 18);
lean_ctor_set(v___x_330_, 0, v___x_336_);
v___x_338_ = v___x_330_;
goto v_reusejp_337_;
}
else
{
lean_object* v_reuseFailAlloc_342_; 
v_reuseFailAlloc_342_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_342_, 0, v___x_336_);
v___x_338_ = v_reuseFailAlloc_342_;
goto v_reusejp_337_;
}
v_reusejp_337_:
{
lean_object* v___x_340_; 
if (v_isShared_318_ == 0)
{
lean_ctor_set_tag(v___x_317_, 1);
lean_ctor_set(v___x_317_, 0, v___x_338_);
v___x_340_ = v___x_317_;
goto v_reusejp_339_;
}
else
{
lean_object* v_reuseFailAlloc_341_; 
v_reuseFailAlloc_341_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_341_, 0, v___x_338_);
v___x_340_ = v_reuseFailAlloc_341_;
goto v_reusejp_339_;
}
v_reusejp_339_:
{
return v___x_340_;
}
}
}
}
else
{
lean_object* v_a_344_; lean_object* v___x_345_; uint8_t v___x_346_; 
v_a_344_ = lean_ctor_get(v___x_327_, 0);
lean_inc(v_a_344_);
lean_dec_ref_known(v___x_327_, 1);
v___x_345_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_prepareMap___closed__4, &lp_proofEnvironment_OCMEnvironment_prepareMap___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_prepareMap___closed__4);
v___x_346_ = lean_expr_eqv(v_a_344_, v___x_345_);
lean_dec(v_a_344_);
if (v___x_346_ == 0)
{
lean_object* v___x_347_; lean_object* v___x_349_; 
lean_dec(v_a_315_);
lean_dec(v_a_313_);
lean_dec_ref(v___y_310_);
lean_dec(v___y_308_);
lean_dec_ref(v___y_307_);
lean_dec(v___y_306_);
lean_dec_ref(v___y_305_);
lean_dec_ref(v___y_302_);
lean_dec_ref(v___y_301_);
v___x_347_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_prepareMap___closed__6));
if (v_isShared_318_ == 0)
{
lean_ctor_set_tag(v___x_317_, 1);
lean_ctor_set(v___x_317_, 0, v___x_347_);
v___x_349_ = v___x_317_;
goto v_reusejp_348_;
}
else
{
lean_object* v_reuseFailAlloc_350_; 
v_reuseFailAlloc_350_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_350_, 0, v___x_347_);
v___x_349_ = v_reuseFailAlloc_350_;
goto v_reusejp_348_;
}
v_reusejp_348_:
{
return v___x_349_;
}
}
else
{
lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v___x_354_; 
v___x_351_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_351_, 0, v___y_305_);
lean_ctor_set(v___x_351_, 1, v___y_301_);
lean_ctor_set(v___x_351_, 2, v___y_302_);
lean_ctor_set(v___x_351_, 3, v_a_313_);
lean_ctor_set(v___x_351_, 4, v___y_308_);
lean_ctor_set(v___x_351_, 5, v___y_306_);
v___x_352_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_352_, 0, v_a_315_);
lean_ctor_set(v___x_352_, 1, v___y_310_);
lean_ctor_set(v___x_352_, 2, v___x_351_);
lean_ctor_set(v___x_352_, 3, v___y_307_);
if (v_isShared_318_ == 0)
{
lean_ctor_set(v___x_317_, 0, v___x_352_);
v___x_354_ = v___x_317_;
goto v_reusejp_353_;
}
else
{
lean_object* v_reuseFailAlloc_355_; 
v_reuseFailAlloc_355_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_355_, 0, v___x_352_);
v___x_354_ = v_reuseFailAlloc_355_;
goto v_reusejp_353_;
}
v_reusejp_353_:
{
return v___x_354_;
}
}
}
}
}
else
{
lean_object* v_a_357_; lean_object* v___x_359_; uint8_t v_isShared_360_; uint8_t v_isSharedCheck_364_; 
lean_dec(v_a_313_);
lean_dec_ref(v___y_310_);
lean_dec(v___y_309_);
lean_dec(v___y_308_);
lean_dec_ref(v___y_307_);
lean_dec(v___y_306_);
lean_dec_ref(v___y_305_);
lean_dec_ref(v___y_302_);
lean_dec_ref(v___y_301_);
lean_dec_ref(v___y_300_);
v_a_357_ = lean_ctor_get(v___x_314_, 0);
v_isSharedCheck_364_ = !lean_is_exclusive(v___x_314_);
if (v_isSharedCheck_364_ == 0)
{
v___x_359_ = v___x_314_;
v_isShared_360_ = v_isSharedCheck_364_;
goto v_resetjp_358_;
}
else
{
lean_inc(v_a_357_);
lean_dec(v___x_314_);
v___x_359_ = lean_box(0);
v_isShared_360_ = v_isSharedCheck_364_;
goto v_resetjp_358_;
}
v_resetjp_358_:
{
lean_object* v___x_362_; 
if (v_isShared_360_ == 0)
{
v___x_362_ = v___x_359_;
goto v_reusejp_361_;
}
else
{
lean_object* v_reuseFailAlloc_363_; 
v_reuseFailAlloc_363_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_363_, 0, v_a_357_);
v___x_362_ = v_reuseFailAlloc_363_;
goto v_reusejp_361_;
}
v_reusejp_361_:
{
return v___x_362_;
}
}
}
}
else
{
lean_object* v_a_365_; lean_object* v___x_367_; uint8_t v_isShared_368_; uint8_t v_isSharedCheck_372_; 
lean_dec_ref(v___y_310_);
lean_dec(v___y_309_);
lean_dec(v___y_308_);
lean_dec_ref(v___y_307_);
lean_dec(v___y_306_);
lean_dec_ref(v___y_305_);
lean_dec_ref(v___y_302_);
lean_dec_ref(v___y_301_);
lean_dec_ref(v___y_300_);
v_a_365_ = lean_ctor_get(v___x_312_, 0);
v_isSharedCheck_372_ = !lean_is_exclusive(v___x_312_);
if (v_isSharedCheck_372_ == 0)
{
v___x_367_ = v___x_312_;
v_isShared_368_ = v_isSharedCheck_372_;
goto v_resetjp_366_;
}
else
{
lean_inc(v_a_365_);
lean_dec(v___x_312_);
v___x_367_ = lean_box(0);
v_isShared_368_ = v_isSharedCheck_372_;
goto v_resetjp_366_;
}
v_resetjp_366_:
{
lean_object* v___x_370_; 
if (v_isShared_368_ == 0)
{
v___x_370_ = v___x_367_;
goto v_reusejp_369_;
}
else
{
lean_object* v_reuseFailAlloc_371_; 
v_reuseFailAlloc_371_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_371_, 0, v_a_365_);
v___x_370_ = v_reuseFailAlloc_371_;
goto v_reusejp_369_;
}
v_reusejp_369_:
{
return v___x_370_;
}
}
}
}
v___jp_373_:
{
lean_object* v_roots_383_; lean_object* v___x_384_; lean_object* v___x_385_; 
lean_inc_ref(v___y_375_);
v_roots_383_ = l_Array_append___redArg(v___y_375_, v___y_382_);
lean_dec_ref(v___y_382_);
v___x_384_ = lp_proofEnvironment_OCMEnvironment_dependencyClosure(v_constants_296_, v_roots_383_, v___y_376_);
v___x_385_ = l_IO_ofExcept___at___00Lean_mkAttributeImplOfEntry_spec__1___redArg(v___x_384_);
if (lean_obj_tag(v___x_385_) == 0)
{
lean_object* v_a_386_; lean_object* v_names_387_; lean_object* v___x_388_; lean_object* v___x_389_; lean_object* v___x_390_; uint8_t v___x_391_; 
v_a_386_ = lean_ctor_get(v___x_385_, 0);
lean_inc(v_a_386_);
lean_dec_ref_known(v___x_385_, 1);
v_names_387_ = lean_ctor_get(v_a_386_, 0);
lean_inc_ref(v_names_387_);
v___x_388_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1, &lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1_once, _init_lp_proofEnvironment_OCMEnvironment_checkedMap___closed__1);
lean_inc(v___y_381_);
v___x_389_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_389_, 0, v___y_381_);
lean_ctor_set(v___x_389_, 1, v___x_388_);
v___x_390_ = lean_array_get_size(v_names_387_);
v___x_391_ = lean_nat_dec_lt(v___y_381_, v___x_390_);
if (v___x_391_ == 0)
{
v___y_300_ = v___y_374_;
v___y_301_ = v___y_375_;
v___y_302_ = v___y_376_;
v___y_303_ = v_names_387_;
v___y_304_ = v___y_377_;
v___y_305_ = v___y_378_;
v___y_306_ = v___y_379_;
v___y_307_ = v_a_386_;
v___y_308_ = v___y_380_;
v___y_309_ = v___y_381_;
v___y_310_ = v___x_389_;
goto v___jp_299_;
}
else
{
uint8_t v___x_392_; 
v___x_392_ = lean_nat_dec_le(v___x_390_, v___x_390_);
if (v___x_392_ == 0)
{
if (v___x_391_ == 0)
{
v___y_300_ = v___y_374_;
v___y_301_ = v___y_375_;
v___y_302_ = v___y_376_;
v___y_303_ = v_names_387_;
v___y_304_ = v___y_377_;
v___y_305_ = v___y_378_;
v___y_306_ = v___y_379_;
v___y_307_ = v_a_386_;
v___y_308_ = v___y_380_;
v___y_309_ = v___y_381_;
v___y_310_ = v___x_389_;
goto v___jp_299_;
}
else
{
size_t v___x_393_; size_t v___x_394_; lean_object* v___x_395_; 
v___x_393_ = ((size_t)0ULL);
v___x_394_ = lean_usize_of_nat(v___x_390_);
v___x_395_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0(v_constants_296_, v_names_387_, v___x_393_, v___x_394_, v___x_389_);
v___y_300_ = v___y_374_;
v___y_301_ = v___y_375_;
v___y_302_ = v___y_376_;
v___y_303_ = v_names_387_;
v___y_304_ = v___y_377_;
v___y_305_ = v___y_378_;
v___y_306_ = v___y_379_;
v___y_307_ = v_a_386_;
v___y_308_ = v___y_380_;
v___y_309_ = v___y_381_;
v___y_310_ = v___x_395_;
goto v___jp_299_;
}
}
else
{
size_t v___x_396_; size_t v___x_397_; lean_object* v___x_398_; 
v___x_396_ = ((size_t)0ULL);
v___x_397_ = lean_usize_of_nat(v___x_390_);
v___x_398_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_prepareMap_spec__0(v_constants_296_, v_names_387_, v___x_396_, v___x_397_, v___x_389_);
v___y_300_ = v___y_374_;
v___y_301_ = v___y_375_;
v___y_302_ = v___y_376_;
v___y_303_ = v_names_387_;
v___y_304_ = v___y_377_;
v___y_305_ = v___y_378_;
v___y_306_ = v___y_379_;
v___y_307_ = v_a_386_;
v___y_308_ = v___y_380_;
v___y_309_ = v___y_381_;
v___y_310_ = v___x_398_;
goto v___jp_299_;
}
}
}
else
{
lean_object* v_a_399_; lean_object* v___x_401_; uint8_t v_isShared_402_; uint8_t v_isSharedCheck_406_; 
lean_dec(v___y_381_);
lean_dec(v___y_380_);
lean_dec(v___y_379_);
lean_dec_ref(v___y_378_);
lean_dec_ref(v___y_377_);
lean_dec_ref(v___y_376_);
lean_dec_ref(v___y_375_);
lean_dec_ref(v___y_374_);
v_a_399_ = lean_ctor_get(v___x_385_, 0);
v_isSharedCheck_406_ = !lean_is_exclusive(v___x_385_);
if (v_isSharedCheck_406_ == 0)
{
v___x_401_ = v___x_385_;
v_isShared_402_ = v_isSharedCheck_406_;
goto v_resetjp_400_;
}
else
{
lean_inc(v_a_399_);
lean_dec(v___x_385_);
v___x_401_ = lean_box(0);
v_isShared_402_ = v_isSharedCheck_406_;
goto v_resetjp_400_;
}
v_resetjp_400_:
{
lean_object* v___x_404_; 
if (v_isShared_402_ == 0)
{
v___x_404_ = v___x_401_;
goto v_reusejp_403_;
}
else
{
lean_object* v_reuseFailAlloc_405_; 
v_reuseFailAlloc_405_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_405_, 0, v_a_399_);
v___x_404_ = v_reuseFailAlloc_405_;
goto v_reusejp_403_;
}
v_reusejp_403_:
{
return v___x_404_;
}
}
}
}
v___jp_407_:
{
lean_object* v___x_420_; 
v___x_420_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collect_spec__2___redArg(v___y_411_, v___y_409_, v___y_416_, v___y_419_);
lean_dec(v___y_419_);
lean_dec(v___y_411_);
v___y_374_ = v___y_408_;
v___y_375_ = v___y_410_;
v___y_376_ = v___y_412_;
v___y_377_ = v___y_413_;
v___y_378_ = v___y_414_;
v___y_379_ = v___y_415_;
v___y_380_ = v___y_418_;
v___y_381_ = v___y_417_;
v___y_382_ = v___x_420_;
goto v___jp_373_;
}
v___jp_421_:
{
uint8_t v___x_434_; 
v___x_434_ = lean_nat_dec_le(v___y_433_, v___y_429_);
if (v___x_434_ == 0)
{
lean_dec(v___y_429_);
lean_inc(v___y_433_);
v___y_408_ = v___y_422_;
v___y_409_ = v___y_423_;
v___y_410_ = v___y_424_;
v___y_411_ = v___y_425_;
v___y_412_ = v___y_426_;
v___y_413_ = v___y_427_;
v___y_414_ = v___y_428_;
v___y_415_ = v___y_430_;
v___y_416_ = v___y_433_;
v___y_417_ = v___y_432_;
v___y_418_ = v___y_431_;
v___y_419_ = v___y_433_;
goto v___jp_407_;
}
else
{
v___y_408_ = v___y_422_;
v___y_409_ = v___y_423_;
v___y_410_ = v___y_424_;
v___y_411_ = v___y_425_;
v___y_412_ = v___y_426_;
v___y_413_ = v___y_427_;
v___y_414_ = v___y_428_;
v___y_415_ = v___y_430_;
v___y_416_ = v___y_433_;
v___y_417_ = v___y_432_;
v___y_418_ = v___y_431_;
v___y_419_ = v___y_429_;
goto v___jp_407_;
}
}
v___jp_435_:
{
lean_object* v___x_444_; lean_object* v___x_445_; uint8_t v___x_446_; 
v___x_444_ = lean_unsigned_to_nat(0u);
v___x_445_ = lean_array_get_size(v___y_443_);
v___x_446_ = lean_nat_dec_eq(v___x_445_, v___x_444_);
if (v___x_446_ == 0)
{
lean_object* v___x_447_; lean_object* v___x_448_; uint8_t v___x_449_; 
v___x_447_ = lean_unsigned_to_nat(1u);
v___x_448_ = lean_nat_sub(v___x_445_, v___x_447_);
v___x_449_ = lean_nat_dec_le(v___x_444_, v___x_448_);
if (v___x_449_ == 0)
{
lean_inc(v___x_448_);
v___y_422_ = v___y_436_;
v___y_423_ = v___y_443_;
v___y_424_ = v___y_437_;
v___y_425_ = v___x_445_;
v___y_426_ = v___y_438_;
v___y_427_ = v___y_439_;
v___y_428_ = v___y_440_;
v___y_429_ = v___x_448_;
v___y_430_ = v___y_441_;
v___y_431_ = v___y_442_;
v___y_432_ = v___x_444_;
v___y_433_ = v___x_448_;
goto v___jp_421_;
}
else
{
v___y_422_ = v___y_436_;
v___y_423_ = v___y_443_;
v___y_424_ = v___y_437_;
v___y_425_ = v___x_445_;
v___y_426_ = v___y_438_;
v___y_427_ = v___y_439_;
v___y_428_ = v___y_440_;
v___y_429_ = v___x_448_;
v___y_430_ = v___y_441_;
v___y_431_ = v___y_442_;
v___y_432_ = v___x_444_;
v___y_433_ = v___x_444_;
goto v___jp_421_;
}
}
else
{
v___y_374_ = v___y_436_;
v___y_375_ = v___y_437_;
v___y_376_ = v___y_438_;
v___y_377_ = v___y_439_;
v___y_378_ = v___y_440_;
v___y_379_ = v___y_441_;
v___y_380_ = v___y_442_;
v___y_381_ = v___x_444_;
v___y_382_ = v___y_443_;
goto v___jp_373_;
}
}
v___jp_450_:
{
lean_object* v___x_451_; lean_object* v___x_452_; 
v___x_451_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_prepareMap___closed__8));
v___x_452_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_452_, 0, v___x_451_);
return v___x_452_;
}
v___jp_461_:
{
if (v___y_462_ == 0)
{
uint8_t v___x_463_; 
v___x_463_ = l_Lean_Expr_hasLooseBVars(v_type_460_);
if (v___x_463_ == 0)
{
lean_object* v___x_464_; lean_object* v_size_465_; lean_object* v_buckets_466_; lean_object* v___x_467_; lean_object* v___x_468_; lean_object* v___x_469_; uint8_t v___x_470_; 
lean_inc_ref(v_type_460_);
v___x_464_ = lp_proofEnvironment_OCMEnvironment_exprDependencies(v_type_460_);
v_size_465_ = lean_ctor_get(v___x_464_, 0);
lean_inc(v_size_465_);
v_buckets_466_ = lean_ctor_get(v___x_464_, 1);
lean_inc_ref(v_buckets_466_);
lean_dec_ref(v___x_464_);
v___x_467_ = lean_mk_empty_array_with_capacity(v_size_465_);
lean_dec(v_size_465_);
v___x_468_ = lean_unsigned_to_nat(0u);
v___x_469_ = lean_array_get_size(v_buckets_466_);
v___x_470_ = lean_nat_dec_lt(v___x_468_, v___x_469_);
if (v___x_470_ == 0)
{
lean_dec_ref(v_buckets_466_);
v___y_436_ = v_type_460_;
v___y_437_ = v_roots_454_;
v___y_438_ = v_excluded_455_;
v___y_439_ = v_axioms_456_;
v___y_440_ = v_target_453_;
v___y_441_ = v_maxRecDepth_458_;
v___y_442_ = v_maxHeartbeats_457_;
v___y_443_ = v___x_467_;
goto v___jp_435_;
}
else
{
uint8_t v___x_471_; 
v___x_471_ = lean_nat_dec_le(v___x_469_, v___x_469_);
if (v___x_471_ == 0)
{
if (v___x_470_ == 0)
{
lean_dec_ref(v_buckets_466_);
v___y_436_ = v_type_460_;
v___y_437_ = v_roots_454_;
v___y_438_ = v_excluded_455_;
v___y_439_ = v_axioms_456_;
v___y_440_ = v_target_453_;
v___y_441_ = v_maxRecDepth_458_;
v___y_442_ = v_maxHeartbeats_457_;
v___y_443_ = v___x_467_;
goto v___jp_435_;
}
else
{
size_t v___x_472_; size_t v___x_473_; lean_object* v___x_474_; 
v___x_472_ = ((size_t)0ULL);
v___x_473_ = lean_usize_of_nat(v___x_469_);
v___x_474_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_466_, v___x_472_, v___x_473_, v___x_467_);
lean_dec_ref(v_buckets_466_);
v___y_436_ = v_type_460_;
v___y_437_ = v_roots_454_;
v___y_438_ = v_excluded_455_;
v___y_439_ = v_axioms_456_;
v___y_440_ = v_target_453_;
v___y_441_ = v_maxRecDepth_458_;
v___y_442_ = v_maxHeartbeats_457_;
v___y_443_ = v___x_474_;
goto v___jp_435_;
}
}
else
{
size_t v___x_475_; size_t v___x_476_; lean_object* v___x_477_; 
v___x_475_ = ((size_t)0ULL);
v___x_476_ = lean_usize_of_nat(v___x_469_);
v___x_477_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_466_, v___x_475_, v___x_476_, v___x_467_);
lean_dec_ref(v_buckets_466_);
v___y_436_ = v_type_460_;
v___y_437_ = v_roots_454_;
v___y_438_ = v_excluded_455_;
v___y_439_ = v_axioms_456_;
v___y_440_ = v_target_453_;
v___y_441_ = v_maxRecDepth_458_;
v___y_442_ = v_maxHeartbeats_457_;
v___y_443_ = v___x_477_;
goto v___jp_435_;
}
}
}
else
{
lean_dec_ref(v_type_460_);
lean_dec(v_maxRecDepth_458_);
lean_dec(v_maxHeartbeats_457_);
lean_dec_ref(v_axioms_456_);
lean_dec_ref(v_excluded_455_);
lean_dec_ref(v_roots_454_);
lean_dec_ref(v_target_453_);
goto v___jp_450_;
}
}
else
{
lean_dec_ref(v_type_460_);
lean_dec(v_maxRecDepth_458_);
lean_dec(v_maxHeartbeats_457_);
lean_dec_ref(v_axioms_456_);
lean_dec_ref(v_excluded_455_);
lean_dec_ref(v_roots_454_);
lean_dec_ref(v_target_453_);
goto v___jp_450_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap___boxed(lean_object* v_constants_483_, lean_object* v_policy_484_, lean_object* v_a_485_){
_start:
{
lean_object* v_res_486_; 
v_res_486_ = lp_proofEnvironment_OCMEnvironment_prepareMap(v_constants_483_, v_policy_484_);
lean_dec_ref(v_constants_483_);
return v_res_486_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg(lean_object* v_source_488_, lean_object* v_as_x27_489_, lean_object* v_b_490_){
_start:
{
if (lean_obj_tag(v_as_x27_489_) == 0)
{
lean_object* v___x_491_; 
v___x_491_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_491_, 0, v_b_490_);
return v___x_491_;
}
else
{
lean_object* v_head_492_; lean_object* v_tail_493_; lean_object* v_fst_494_; lean_object* v_snd_495_; lean_object* v___x_496_; 
v_head_492_ = lean_ctor_get(v_as_x27_489_, 0);
v_tail_493_ = lean_ctor_get(v_as_x27_489_, 1);
v_fst_494_ = lean_ctor_get(v_head_492_, 0);
v_snd_495_ = lean_ctor_get(v_head_492_, 1);
v___x_496_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_source_488_, v_fst_494_);
if (lean_obj_tag(v___x_496_) == 1)
{
lean_object* v_val_497_; lean_object* v___x_499_; uint8_t v_isShared_500_; uint8_t v_isSharedCheck_510_; 
v_val_497_ = lean_ctor_get(v___x_496_, 0);
v_isSharedCheck_510_ = !lean_is_exclusive(v___x_496_);
if (v_isSharedCheck_510_ == 0)
{
v___x_499_ = v___x_496_;
v_isShared_500_ = v_isSharedCheck_510_;
goto v_resetjp_498_;
}
else
{
lean_inc(v_val_497_);
lean_dec(v___x_496_);
v___x_499_ = lean_box(0);
v_isShared_500_ = v_isSharedCheck_510_;
goto v_resetjp_498_;
}
v_resetjp_498_:
{
uint8_t v___x_501_; 
v___x_501_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_val_497_, v_snd_495_);
lean_dec(v_val_497_);
if (v___x_501_ == 0)
{
uint8_t v___x_502_; lean_object* v___x_503_; lean_object* v___x_504_; lean_object* v___x_505_; lean_object* v___x_507_; 
lean_dec_ref(v_b_490_);
v___x_502_ = 1;
v___x_503_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg___closed__0));
lean_inc(v_fst_494_);
v___x_504_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_494_, v___x_502_);
v___x_505_ = lean_string_append(v___x_503_, v___x_504_);
lean_dec_ref(v___x_504_);
if (v_isShared_500_ == 0)
{
lean_ctor_set_tag(v___x_499_, 0);
lean_ctor_set(v___x_499_, 0, v___x_505_);
v___x_507_ = v___x_499_;
goto v_reusejp_506_;
}
else
{
lean_object* v_reuseFailAlloc_508_; 
v_reuseFailAlloc_508_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_508_, 0, v___x_505_);
v___x_507_ = v_reuseFailAlloc_508_;
goto v_reusejp_506_;
}
v_reusejp_506_:
{
return v___x_507_;
}
}
else
{
lean_del_object(v___x_499_);
v_as_x27_489_ = v_tail_493_;
goto _start;
}
}
}
else
{
lean_object* v___x_511_; 
lean_dec(v___x_496_);
lean_inc(v_snd_495_);
lean_inc(v_fst_494_);
v___x_511_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg(v_b_490_, v_fst_494_, v_snd_495_);
v_as_x27_489_ = v_tail_493_;
v_b_490_ = v___x_511_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg___boxed(lean_object* v_source_513_, lean_object* v_as_x27_514_, lean_object* v_b_515_){
_start:
{
lean_object* v_res_516_; 
v_res_516_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg(v_source_513_, v_as_x27_514_, v_b_515_);
lean_dec(v_as_x27_514_);
lean_dec_ref(v_source_513_);
return v_res_516_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_mergePrimitives(lean_object* v_source_517_, lean_object* v_primitives_518_){
_start:
{
lean_object* v_buckets_519_; lean_object* v___x_520_; lean_object* v___x_521_; lean_object* v___x_522_; uint8_t v___x_523_; 
v_buckets_519_ = lean_ctor_get(v_primitives_518_, 1);
v___x_520_ = lean_box(0);
v___x_521_ = lean_array_get_size(v_buckets_519_);
v___x_522_ = lean_unsigned_to_nat(0u);
v___x_523_ = lean_nat_dec_lt(v___x_522_, v___x_521_);
if (v___x_523_ == 0)
{
lean_object* v___x_524_; 
lean_inc_ref(v_source_517_);
v___x_524_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg(v_source_517_, v___x_520_, v_source_517_);
lean_dec_ref(v_source_517_);
return v___x_524_;
}
else
{
size_t v___x_525_; size_t v___x_526_; lean_object* v___x_527_; lean_object* v___x_528_; 
v___x_525_ = lean_usize_of_nat(v___x_521_);
v___x_526_ = ((size_t)0ULL);
v___x_527_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(v_buckets_519_, v___x_525_, v___x_526_, v___x_520_);
lean_inc_ref(v_source_517_);
v___x_528_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg(v_source_517_, v___x_527_, v_source_517_);
lean_dec(v___x_527_);
lean_dec_ref(v_source_517_);
return v___x_528_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_mergePrimitives___boxed(lean_object* v_source_529_, lean_object* v_primitives_530_){
_start:
{
lean_object* v_res_531_; 
v_res_531_ = lp_proofEnvironment_OCMEnvironment_mergePrimitives(v_source_529_, v_primitives_530_);
lean_dec_ref(v_primitives_530_);
return v_res_531_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0(lean_object* v_source_532_, lean_object* v_as_533_, lean_object* v_as_x27_534_, lean_object* v_b_535_, lean_object* v_a_536_){
_start:
{
lean_object* v___x_537_; 
v___x_537_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___redArg(v_source_532_, v_as_x27_534_, v_b_535_);
return v___x_537_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0___boxed(lean_object* v_source_538_, lean_object* v_as_539_, lean_object* v_as_x27_540_, lean_object* v_b_541_, lean_object* v_a_542_){
_start:
{
lean_object* v_res_543_; 
v_res_543_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_mergePrimitives_spec__0(v_source_538_, v_as_539_, v_as_x27_540_, v_b_541_, v_a_542_);
lean_dec(v_as_x27_540_);
lean_dec(v_as_539_);
lean_dec_ref(v_source_538_);
return v_res_543_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0(lean_object* v_registry_547_, lean_object* v_constants_548_, lean_object* v_as_549_, size_t v_sz_550_, size_t v_i_551_, lean_object* v_b_552_){
_start:
{
uint8_t v___x_553_; 
v___x_553_ = lean_usize_dec_lt(v_i_551_, v_sz_550_);
if (v___x_553_ == 0)
{
lean_object* v___x_554_; 
v___x_554_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_554_, 0, v_b_552_);
return v___x_554_;
}
else
{
lean_object* v_a_555_; lean_object* v___x_566_; 
v_a_555_ = lean_array_uget_borrowed(v_as_549_, v_i_551_);
v___x_566_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_registry_547_, v_a_555_);
if (lean_obj_tag(v___x_566_) == 1)
{
lean_object* v_val_567_; 
v_val_567_ = lean_ctor_get(v___x_566_, 0);
lean_inc(v_val_567_);
lean_dec_ref_known(v___x_566_, 1);
if (lean_obj_tag(v_val_567_) == 0)
{
lean_object* v___x_568_; 
v___x_568_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_548_, v_a_555_);
if (lean_obj_tag(v___x_568_) == 1)
{
lean_object* v_val_569_; 
v_val_569_ = lean_ctor_get(v___x_568_, 0);
lean_inc(v_val_569_);
lean_dec_ref_known(v___x_568_, 1);
if (lean_obj_tag(v_val_569_) == 0)
{
uint8_t v___x_570_; lean_object* v___x_572_; uint8_t v_isShared_573_; uint8_t v_isSharedCheck_584_; 
v___x_570_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_val_567_, v_val_569_);
lean_dec_ref_known(v_val_567_, 1);
v_isSharedCheck_584_ = !lean_is_exclusive(v_val_569_);
if (v_isSharedCheck_584_ == 0)
{
lean_object* v_unused_585_; 
v_unused_585_ = lean_ctor_get(v_val_569_, 0);
lean_dec(v_unused_585_);
v___x_572_ = v_val_569_;
v_isShared_573_ = v_isSharedCheck_584_;
goto v_resetjp_571_;
}
else
{
lean_dec(v_val_569_);
v___x_572_ = lean_box(0);
v_isShared_573_ = v_isSharedCheck_584_;
goto v_resetjp_571_;
}
v_resetjp_571_:
{
if (v___x_570_ == 0)
{
lean_object* v___x_574_; lean_object* v___x_575_; lean_object* v___x_576_; lean_object* v___x_578_; 
v___x_574_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__2));
lean_inc(v_a_555_);
v___x_575_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_555_, v___x_553_);
v___x_576_ = lean_string_append(v___x_574_, v___x_575_);
lean_dec_ref(v___x_575_);
if (v_isShared_573_ == 0)
{
lean_ctor_set(v___x_572_, 0, v___x_576_);
v___x_578_ = v___x_572_;
goto v_reusejp_577_;
}
else
{
lean_object* v_reuseFailAlloc_579_; 
v_reuseFailAlloc_579_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_579_, 0, v___x_576_);
v___x_578_ = v_reuseFailAlloc_579_;
goto v_reusejp_577_;
}
v_reusejp_577_:
{
return v___x_578_;
}
}
else
{
lean_object* v___x_580_; size_t v___x_581_; size_t v___x_582_; 
lean_del_object(v___x_572_);
v___x_580_ = lean_box(0);
v___x_581_ = ((size_t)1ULL);
v___x_582_ = lean_usize_add(v_i_551_, v___x_581_);
v_i_551_ = v___x_582_;
v_b_552_ = v___x_580_;
goto _start;
}
}
}
else
{
lean_dec(v_val_569_);
lean_dec_ref_known(v_val_567_, 1);
goto v___jp_556_;
}
}
else
{
lean_dec_ref_known(v_val_567_, 1);
lean_dec(v___x_568_);
goto v___jp_556_;
}
}
else
{
lean_dec(v_val_567_);
goto v___jp_561_;
}
}
else
{
lean_dec(v___x_566_);
goto v___jp_561_;
}
v___jp_556_:
{
lean_object* v___x_557_; lean_object* v___x_558_; lean_object* v___x_559_; lean_object* v___x_560_; 
v___x_557_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__0));
lean_inc(v_a_555_);
v___x_558_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_555_, v___x_553_);
v___x_559_ = lean_string_append(v___x_557_, v___x_558_);
lean_dec_ref(v___x_558_);
v___x_560_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_560_, 0, v___x_559_);
return v___x_560_;
}
v___jp_561_:
{
lean_object* v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; lean_object* v___x_565_; 
v___x_562_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___closed__1));
lean_inc(v_a_555_);
v___x_563_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_555_, v___x_553_);
v___x_564_ = lean_string_append(v___x_562_, v___x_563_);
lean_dec_ref(v___x_563_);
v___x_565_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_565_, 0, v___x_564_);
return v___x_565_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0___boxed(lean_object* v_registry_586_, lean_object* v_constants_587_, lean_object* v_as_588_, lean_object* v_sz_589_, lean_object* v_i_590_, lean_object* v_b_591_){
_start:
{
size_t v_sz_boxed_592_; size_t v_i_boxed_593_; lean_object* v_res_594_; 
v_sz_boxed_592_ = lean_unbox_usize(v_sz_589_);
lean_dec(v_sz_589_);
v_i_boxed_593_ = lean_unbox_usize(v_i_590_);
lean_dec(v_i_590_);
v_res_594_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0(v_registry_586_, v_constants_587_, v_as_588_, v_sz_boxed_592_, v_i_boxed_593_, v_b_591_);
lean_dec_ref(v_as_588_);
lean_dec_ref(v_constants_587_);
lean_dec_ref(v_registry_586_);
return v_res_594_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry(lean_object* v_constants_597_, lean_object* v_registry_598_, lean_object* v_allowed_599_){
_start:
{
lean_object* v___x_600_; size_t v_sz_601_; size_t v___x_602_; lean_object* v___x_603_; 
v___x_600_ = lean_box(0);
v_sz_601_ = lean_array_size(v_allowed_599_);
v___x_602_ = ((size_t)0ULL);
v___x_603_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireAxiomRegistry_spec__0(v_registry_598_, v_constants_597_, v_allowed_599_, v_sz_601_, v___x_602_, v___x_600_);
if (lean_obj_tag(v___x_603_) == 0)
{
return v___x_603_;
}
else
{
lean_object* v___x_604_; 
lean_dec_ref_known(v___x_603_, 1);
v___x_604_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry___closed__0));
return v___x_604_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry___boxed(lean_object* v_constants_605_, lean_object* v_registry_606_, lean_object* v_allowed_607_){
_start:
{
lean_object* v_res_608_; 
v_res_608_ = lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry(v_constants_605_, v_registry_606_, v_allowed_607_);
lean_dec_ref(v_allowed_607_);
lean_dec_ref(v_registry_606_);
lean_dec_ref(v_constants_605_);
return v_res_608_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Families(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Prepare(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Families(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
