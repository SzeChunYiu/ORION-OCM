// Lean compiler output
// Module: OCMEnvironment.Main
// Imports: public import Init public meta import Init public import OCMEnvironment.Config public import OCMEnvironment.Write public import OCMEnvironment.Check public import OCMEnvironment.Registry public import OCMEnvironment.Outcomes
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_IO_eprintln___at___00__private_Lean_Shell_0__Lean_shellMain_spec__1(lean_object*);
lean_object* l_System_FilePath_join(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_writeJson(lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(lean_object*);
uint8_t l_System_FilePath_pathExists(lean_object*);
lean_object* lean_io_create_dir(lean_object*);
lean_object* lean_st_mk_ref(lean_object*);
lean_object* lean_st_ref_get(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_refusalTerminal(lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_result(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_validateCat_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_io_read_dir(lean_object*);
size_t lean_array_size(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_readJson(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_getString(lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_keys(lean_object*, lean_object*);
lean_object* l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_readPacket(lean_object*, uint8_t);
lean_object* lp_proofEnvironment_OCMEnvironment_mergePrimitives(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_restorePolicy(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_prepareMap(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_getNat(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_packetExpr(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_checkProof(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_preparationPolicy(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_registration(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_inventory(lean_object*);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "schema"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "ocm.proof-environment.request.v1"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__1 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "REQUEST_SCHEMA"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__2 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__2_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__2_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__3 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "operation"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "inspect"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__5 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__5_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "prepare"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__6 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__6_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "check"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__7 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__7_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "UNKNOWN_OPERATION"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__8 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__8_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__8_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__9 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__9_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "permitted_packet"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__10 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__10_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "target_packet"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__11 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__11_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "registration"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__12 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__12_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "primitive_packet"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "candidate_packet"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__14 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__14_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "candidate_root"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__15 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__15_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__16 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__16_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__14_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__16_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__17 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__17_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__17_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__18 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__18_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__12_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__18_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__19 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__19_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__11_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__19_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__20 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__20_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__10_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__20_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__21 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__21_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__21_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__22 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__22_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__22_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__23 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__23_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "registered_target"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__24 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__24_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "primitive_identity"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__25 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__25_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "axiom_registry"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__26 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__26_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "closure_and_replay"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__27 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__27_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "primitive_coverage"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__28 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__28_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "candidate_dependencies_and_kernel"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__29 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__29_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "source_packet"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "policy"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__31 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__31_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "registered_target_packet"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__32 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__32_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__32_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__33 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__33_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__33_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__34 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__34_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__31_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__34_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__35 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__35_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__36_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__35_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__36 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__36_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__37_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__36_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__37 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__37_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__38_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__37_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__38 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__38_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__39_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "independent_target_and_policy"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__39 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__39_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__40_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "serialization"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__40 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__40_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__41_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "permitted.ndjson"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__41 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__41_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__42_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "target.ndjson"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__42 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__42_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__43_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "registration.json"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__43 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__43_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__44_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "inventory.json"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__44 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__44_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__45_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "PREPARED"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__45 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__45_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__46_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "replay_and_independent_target"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__46 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__46_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__47_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__47 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__47_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__48_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "source_declarations"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__48 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__48_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__49_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "declarations_replayed"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__49 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__49_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__50_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "dependency_edges"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__50 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__50_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "result.json"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51_value;
static const lean_array_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__52_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*5, .m_other = 0, .m_tag = 246}, .m_size = 5, .m_capacity = 5, .m_data = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__41_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__42_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__43_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__44_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__52 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__52_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__53_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__53 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__53_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__54_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__53_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__54 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__54_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__55_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__54_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__55 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__55_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__56_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "INSPECTED"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__56 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__56_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__57_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "parsed_inventory"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__57 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__57_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__58_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "NO_KERNEL_CHECK"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__58 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__58_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__59_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "declarations"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__59 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__59_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__60_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "expressions"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__60 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__60_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__61_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "rows"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__61 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__61_value;
static const lean_array_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__62_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__62 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__62_value;
static const lean_array_object lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__63_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 246}, .m_size = 1, .m_capacity = 1, .m_data = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__63 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__63_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 43, .m_capacity = 43, .m_length = 42, .m_data = "usage: ocm_environment REQUEST.json OUTDIR"};
static const lean_object* lp_proofEnvironment_main___closed__0 = (const lean_object*)&lp_proofEnvironment_main___closed__0_value;
static const lean_string_object lp_proofEnvironment_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "unknown"};
static const lean_object* lp_proofEnvironment_main___closed__1 = (const lean_object*)&lp_proofEnvironment_main___closed__1_value;
static const lean_string_object lp_proofEnvironment_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "request"};
static const lean_object* lp_proofEnvironment_main___closed__2 = (const lean_object*)&lp_proofEnvironment_main___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_main___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_main___closed__3;
static const lean_string_object lp_proofEnvironment_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "OUTPUT_EXISTS"};
static const lean_object* lp_proofEnvironment_main___closed__4 = (const lean_object*)&lp_proofEnvironment_main___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_main___boxed__const__1;
LEAN_EXPORT lean_object* lp_proofEnvironment_main___boxed__const__2;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(lean_object* v_j_1_, lean_object* v_k_2_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lp_proofEnvironment_OCMEnvironment_getString(v_j_1_, v_k_2_);
if (lean_obj_tag(v___x_4_) == 0)
{
lean_object* v_a_5_; lean_object* v___x_7_; uint8_t v_isShared_8_; uint8_t v_isSharedCheck_12_; 
v_a_5_ = lean_ctor_get(v___x_4_, 0);
v_isSharedCheck_12_ = !lean_is_exclusive(v___x_4_);
if (v_isSharedCheck_12_ == 0)
{
v___x_7_ = v___x_4_;
v_isShared_8_ = v_isSharedCheck_12_;
goto v_resetjp_6_;
}
else
{
lean_inc(v_a_5_);
lean_dec(v___x_4_);
v___x_7_ = lean_box(0);
v_isShared_8_ = v_isSharedCheck_12_;
goto v_resetjp_6_;
}
v_resetjp_6_:
{
lean_object* v___x_10_; 
if (v_isShared_8_ == 0)
{
v___x_10_ = v___x_7_;
goto v_reusejp_9_;
}
else
{
lean_object* v_reuseFailAlloc_11_; 
v_reuseFailAlloc_11_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_11_, 0, v_a_5_);
v___x_10_ = v_reuseFailAlloc_11_;
goto v_reusejp_9_;
}
v_reusejp_9_:
{
return v___x_10_;
}
}
}
else
{
lean_object* v_a_13_; lean_object* v___x_15_; uint8_t v_isShared_16_; uint8_t v_isSharedCheck_20_; 
v_a_13_ = lean_ctor_get(v___x_4_, 0);
v_isSharedCheck_20_ = !lean_is_exclusive(v___x_4_);
if (v_isSharedCheck_20_ == 0)
{
v___x_15_ = v___x_4_;
v_isShared_16_ = v_isSharedCheck_20_;
goto v_resetjp_14_;
}
else
{
lean_inc(v_a_13_);
lean_dec(v___x_4_);
v___x_15_ = lean_box(0);
v_isShared_16_ = v_isSharedCheck_20_;
goto v_resetjp_14_;
}
v_resetjp_14_:
{
lean_object* v___x_18_; 
if (v_isShared_16_ == 0)
{
v___x_18_ = v___x_15_;
goto v_reusejp_17_;
}
else
{
lean_object* v_reuseFailAlloc_19_; 
v_reuseFailAlloc_19_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_19_, 0, v_a_13_);
v___x_18_ = v_reuseFailAlloc_19_;
goto v_reusejp_17_;
}
v_reusejp_17_:
{
return v___x_18_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField___boxed(lean_object* v_j_21_, lean_object* v_k_22_, lean_object* v_a_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_j_21_, v_k_22_);
lean_dec_ref(v_k_22_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation(lean_object* v_request_140_, lean_object* v_out_141_, lean_object* v_phase_142_){
_start:
{
lean_object* v___x_144_; lean_object* v___x_145_; 
v___x_144_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__0));
lean_inc(v_request_140_);
v___x_145_ = lp_proofEnvironment_OCMEnvironment_getString(v_request_140_, v___x_144_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v_a_146_; lean_object* v___x_148_; uint8_t v_isShared_149_; uint8_t v_isSharedCheck_755_; 
v_a_146_ = lean_ctor_get(v___x_145_, 0);
v_isSharedCheck_755_ = !lean_is_exclusive(v___x_145_);
if (v_isSharedCheck_755_ == 0)
{
v___x_148_ = v___x_145_;
v_isShared_149_ = v_isSharedCheck_755_;
goto v_resetjp_147_;
}
else
{
lean_inc(v_a_146_);
lean_dec(v___x_145_);
v___x_148_ = lean_box(0);
v_isShared_149_ = v_isSharedCheck_755_;
goto v_resetjp_147_;
}
v_resetjp_147_:
{
lean_object* v___x_150_; uint8_t v___x_151_; 
v___x_150_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__1));
v___x_151_ = lean_string_dec_eq(v_a_146_, v___x_150_);
lean_dec(v_a_146_);
if (v___x_151_ == 0)
{
lean_object* v___x_152_; lean_object* v___x_154_; 
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v___x_152_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__3));
if (v_isShared_149_ == 0)
{
lean_ctor_set_tag(v___x_148_, 1);
lean_ctor_set(v___x_148_, 0, v___x_152_);
v___x_154_ = v___x_148_;
goto v_reusejp_153_;
}
else
{
lean_object* v_reuseFailAlloc_155_; 
v_reuseFailAlloc_155_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_155_, 0, v___x_152_);
v___x_154_ = v_reuseFailAlloc_155_;
goto v_reusejp_153_;
}
v_reusejp_153_:
{
return v___x_154_;
}
}
else
{
lean_object* v___x_156_; lean_object* v___x_157_; 
lean_del_object(v___x_148_);
v___x_156_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4));
lean_inc(v_request_140_);
v___x_157_ = lp_proofEnvironment_OCMEnvironment_getString(v_request_140_, v___x_156_);
if (lean_obj_tag(v___x_157_) == 0)
{
lean_object* v_a_158_; lean_object* v___x_160_; uint8_t v_isShared_161_; uint8_t v_isSharedCheck_746_; 
v_a_158_ = lean_ctor_get(v___x_157_, 0);
v_isSharedCheck_746_ = !lean_is_exclusive(v___x_157_);
if (v_isSharedCheck_746_ == 0)
{
v___x_160_ = v___x_157_;
v_isShared_161_ = v_isSharedCheck_746_;
goto v_resetjp_159_;
}
else
{
lean_inc(v_a_158_);
lean_dec(v___x_157_);
v___x_160_ = lean_box(0);
v_isShared_161_ = v_isSharedCheck_746_;
goto v_resetjp_159_;
}
v_resetjp_159_:
{
lean_object* v___x_162_; uint8_t v___x_163_; 
v___x_162_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__5));
v___x_163_ = lean_string_dec_eq(v_a_158_, v___x_162_);
if (v___x_163_ == 0)
{
lean_object* v___x_164_; uint8_t v___x_165_; 
v___x_164_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__6));
v___x_165_ = lean_string_dec_eq(v_a_158_, v___x_164_);
if (v___x_165_ == 0)
{
lean_object* v___x_166_; uint8_t v___x_167_; 
lean_dec_ref(v_out_141_);
v___x_166_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__7));
v___x_167_ = lean_string_dec_eq(v_a_158_, v___x_166_);
lean_dec(v_a_158_);
if (v___x_167_ == 0)
{
lean_object* v___x_168_; lean_object* v___x_170_; 
lean_dec(v_request_140_);
v___x_168_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__9));
if (v_isShared_161_ == 0)
{
lean_ctor_set_tag(v___x_160_, 1);
lean_ctor_set(v___x_160_, 0, v___x_168_);
v___x_170_ = v___x_160_;
goto v_reusejp_169_;
}
else
{
lean_object* v_reuseFailAlloc_171_; 
v_reuseFailAlloc_171_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_171_, 0, v___x_168_);
v___x_170_ = v_reuseFailAlloc_171_;
goto v_reusejp_169_;
}
v_reusejp_169_:
{
return v___x_170_;
}
}
else
{
lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; lean_object* v___x_179_; lean_object* v___x_180_; 
lean_del_object(v___x_160_);
v___x_172_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__10));
v___x_173_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__11));
v___x_174_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__12));
v___x_175_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13));
v___x_176_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__14));
v___x_177_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__15));
v___x_178_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__23));
lean_inc(v_request_140_);
v___x_179_ = lp_proofEnvironment_OCMEnvironment_keys(v_request_140_, v___x_178_);
v___x_180_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_179_);
if (lean_obj_tag(v___x_180_) == 0)
{
lean_object* v___x_181_; lean_object* v___x_182_; 
lean_dec_ref_known(v___x_180_, 1);
v___x_181_ = lean_st_ref_set(v_phase_142_, v___x_172_);
lean_inc(v_request_140_);
v___x_182_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_172_);
if (lean_obj_tag(v___x_182_) == 0)
{
lean_object* v_a_183_; lean_object* v___x_184_; 
v_a_183_ = lean_ctor_get(v___x_182_, 0);
lean_inc(v_a_183_);
lean_dec_ref_known(v___x_182_, 1);
v___x_184_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_183_, v___x_165_);
lean_dec(v_a_183_);
if (lean_obj_tag(v___x_184_) == 0)
{
lean_object* v_a_185_; lean_object* v___x_186_; lean_object* v___x_187_; lean_object* v___x_188_; 
v_a_185_ = lean_ctor_get(v___x_184_, 0);
lean_inc(v_a_185_);
lean_dec_ref_known(v___x_184_, 1);
v___x_186_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__24));
v___x_187_ = lean_st_ref_set(v_phase_142_, v___x_186_);
lean_inc(v_request_140_);
v___x_188_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_173_);
if (lean_obj_tag(v___x_188_) == 0)
{
lean_object* v_a_189_; lean_object* v___x_190_; 
v_a_189_ = lean_ctor_get(v___x_188_, 0);
lean_inc(v_a_189_);
lean_dec_ref_known(v___x_188_, 1);
v___x_190_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_189_, v___x_151_);
lean_dec(v_a_189_);
if (lean_obj_tag(v___x_190_) == 0)
{
lean_object* v_a_191_; lean_object* v___x_192_; lean_object* v___x_193_; 
v_a_191_ = lean_ctor_get(v___x_190_, 0);
lean_inc(v_a_191_);
lean_dec_ref_known(v___x_190_, 1);
v___x_192_ = lean_st_ref_set(v_phase_142_, v___x_175_);
lean_inc(v_request_140_);
v___x_193_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_175_);
if (lean_obj_tag(v___x_193_) == 0)
{
lean_object* v_a_194_; lean_object* v___x_195_; 
v_a_194_ = lean_ctor_get(v___x_193_, 0);
lean_inc(v_a_194_);
lean_dec_ref_known(v___x_193_, 1);
v___x_195_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_194_, v___x_165_);
lean_dec(v_a_194_);
if (lean_obj_tag(v___x_195_) == 0)
{
lean_object* v_a_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v_state_199_; lean_object* v_state_200_; lean_object* v_constMap_201_; lean_object* v_constMap_202_; lean_object* v___x_203_; lean_object* v___x_204_; 
v_a_196_ = lean_ctor_get(v___x_195_, 0);
lean_inc(v_a_196_);
lean_dec_ref_known(v___x_195_, 1);
v___x_197_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__25));
v___x_198_ = lean_st_ref_set(v_phase_142_, v___x_197_);
v_state_199_ = lean_ctor_get(v_a_185_, 0);
lean_inc_ref(v_state_199_);
lean_dec(v_a_185_);
v_state_200_ = lean_ctor_get(v_a_196_, 0);
lean_inc_ref(v_state_200_);
lean_dec(v_a_196_);
v_constMap_201_ = lean_ctor_get(v_state_199_, 5);
lean_inc_ref_n(v_constMap_201_, 2);
lean_dec_ref(v_state_199_);
v_constMap_202_ = lean_ctor_get(v_state_200_, 5);
lean_inc_ref(v_constMap_202_);
lean_dec_ref(v_state_200_);
v___x_203_ = lp_proofEnvironment_OCMEnvironment_mergePrimitives(v_constMap_201_, v_constMap_202_);
v___x_204_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_203_);
if (lean_obj_tag(v___x_204_) == 0)
{
lean_object* v___x_205_; lean_object* v___x_206_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = lean_st_ref_set(v_phase_142_, v___x_174_);
lean_inc(v_request_140_);
v___x_206_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_174_);
if (lean_obj_tag(v___x_206_) == 0)
{
lean_object* v_a_207_; lean_object* v___x_208_; 
v_a_207_ = lean_ctor_get(v___x_206_, 0);
lean_inc(v_a_207_);
lean_dec_ref_known(v___x_206_, 1);
v___x_208_ = lp_proofEnvironment_OCMEnvironment_readJson(v_a_207_);
lean_dec(v_a_207_);
if (lean_obj_tag(v___x_208_) == 0)
{
lean_object* v_a_209_; lean_object* v___x_210_; 
v_a_209_ = lean_ctor_get(v___x_208_, 0);
lean_inc(v_a_209_);
lean_dec_ref_known(v___x_208_, 1);
v___x_210_ = lp_proofEnvironment_OCMEnvironment_restorePolicy(v_a_209_, v_a_191_, v_constMap_201_);
lean_dec(v_a_191_);
if (lean_obj_tag(v___x_210_) == 0)
{
lean_object* v_a_211_; lean_object* v___x_212_; lean_object* v___x_213_; lean_object* v_axioms_214_; lean_object* v___x_215_; lean_object* v___x_216_; 
v_a_211_ = lean_ctor_get(v___x_210_, 0);
lean_inc(v_a_211_);
lean_dec_ref_known(v___x_210_, 1);
v___x_212_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__26));
v___x_213_ = lean_st_ref_set(v_phase_142_, v___x_212_);
v_axioms_214_ = lean_ctor_get(v_a_211_, 3);
v___x_215_ = lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry(v_constMap_201_, v_constMap_202_, v_axioms_214_);
v___x_216_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_215_);
if (lean_obj_tag(v___x_216_) == 0)
{
lean_object* v___x_217_; lean_object* v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__27));
v___x_218_ = lean_st_ref_set(v_phase_142_, v___x_217_);
v___x_219_ = lp_proofEnvironment_OCMEnvironment_prepareMap(v_constMap_201_, v_a_211_);
lean_dec_ref(v_constMap_201_);
if (lean_obj_tag(v___x_219_) == 0)
{
lean_object* v_a_220_; lean_object* v___x_221_; lean_object* v___x_222_; lean_object* v_constants_223_; lean_object* v___x_224_; lean_object* v___x_225_; 
v_a_220_ = lean_ctor_get(v___x_219_, 0);
lean_inc(v_a_220_);
lean_dec_ref_known(v___x_219_, 1);
v___x_221_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__28));
v___x_222_ = lean_st_ref_set(v_phase_142_, v___x_221_);
v_constants_223_ = lean_ctor_get(v_a_220_, 1);
v___x_224_ = lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives(v_constants_223_, v_constMap_202_);
lean_dec_ref(v_constMap_202_);
v___x_225_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_224_);
if (lean_obj_tag(v___x_225_) == 0)
{
lean_object* v___x_226_; lean_object* v___x_227_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = lean_st_ref_set(v_phase_142_, v___x_176_);
lean_inc(v_request_140_);
v___x_227_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_176_);
if (lean_obj_tag(v___x_227_) == 0)
{
lean_object* v_a_228_; lean_object* v___x_229_; 
v_a_228_ = lean_ctor_get(v___x_227_, 0);
lean_inc(v_a_228_);
lean_dec_ref_known(v___x_227_, 1);
v___x_229_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_228_, v___x_151_);
lean_dec(v_a_228_);
if (lean_obj_tag(v___x_229_) == 0)
{
lean_object* v_a_230_; lean_object* v___x_231_; 
v_a_230_ = lean_ctor_get(v___x_229_, 0);
lean_inc(v_a_230_);
lean_dec_ref_known(v___x_229_, 1);
v___x_231_ = lp_proofEnvironment_OCMEnvironment_getNat(v_request_140_, v___x_177_);
if (lean_obj_tag(v___x_231_) == 0)
{
lean_object* v_a_232_; lean_object* v___x_233_; 
v_a_232_ = lean_ctor_get(v___x_231_, 0);
lean_inc(v_a_232_);
lean_dec_ref_known(v___x_231_, 1);
v___x_233_ = lp_proofEnvironment_OCMEnvironment_packetExpr(v_a_230_, v_a_232_);
lean_dec(v_a_230_);
if (lean_obj_tag(v___x_233_) == 0)
{
lean_object* v_a_234_; lean_object* v___x_235_; lean_object* v___x_236_; lean_object* v___x_237_; 
v_a_234_ = lean_ctor_get(v___x_233_, 0);
lean_inc(v_a_234_);
lean_dec_ref_known(v___x_233_, 1);
v___x_235_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__29));
v___x_236_ = lean_st_ref_set(v_phase_142_, v___x_235_);
v___x_237_ = lp_proofEnvironment_OCMEnvironment_checkProof(v_a_220_, v_a_234_);
return v___x_237_;
}
else
{
lean_object* v_a_238_; lean_object* v___x_240_; uint8_t v_isShared_241_; uint8_t v_isSharedCheck_245_; 
lean_dec(v_a_220_);
v_a_238_ = lean_ctor_get(v___x_233_, 0);
v_isSharedCheck_245_ = !lean_is_exclusive(v___x_233_);
if (v_isSharedCheck_245_ == 0)
{
v___x_240_ = v___x_233_;
v_isShared_241_ = v_isSharedCheck_245_;
goto v_resetjp_239_;
}
else
{
lean_inc(v_a_238_);
lean_dec(v___x_233_);
v___x_240_ = lean_box(0);
v_isShared_241_ = v_isSharedCheck_245_;
goto v_resetjp_239_;
}
v_resetjp_239_:
{
lean_object* v___x_243_; 
if (v_isShared_241_ == 0)
{
v___x_243_ = v___x_240_;
goto v_reusejp_242_;
}
else
{
lean_object* v_reuseFailAlloc_244_; 
v_reuseFailAlloc_244_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_244_, 0, v_a_238_);
v___x_243_ = v_reuseFailAlloc_244_;
goto v_reusejp_242_;
}
v_reusejp_242_:
{
return v___x_243_;
}
}
}
}
else
{
lean_object* v_a_246_; lean_object* v___x_248_; uint8_t v_isShared_249_; uint8_t v_isSharedCheck_253_; 
lean_dec(v_a_230_);
lean_dec(v_a_220_);
v_a_246_ = lean_ctor_get(v___x_231_, 0);
v_isSharedCheck_253_ = !lean_is_exclusive(v___x_231_);
if (v_isSharedCheck_253_ == 0)
{
v___x_248_ = v___x_231_;
v_isShared_249_ = v_isSharedCheck_253_;
goto v_resetjp_247_;
}
else
{
lean_inc(v_a_246_);
lean_dec(v___x_231_);
v___x_248_ = lean_box(0);
v_isShared_249_ = v_isSharedCheck_253_;
goto v_resetjp_247_;
}
v_resetjp_247_:
{
lean_object* v___x_251_; 
if (v_isShared_249_ == 0)
{
v___x_251_ = v___x_248_;
goto v_reusejp_250_;
}
else
{
lean_object* v_reuseFailAlloc_252_; 
v_reuseFailAlloc_252_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_252_, 0, v_a_246_);
v___x_251_ = v_reuseFailAlloc_252_;
goto v_reusejp_250_;
}
v_reusejp_250_:
{
return v___x_251_;
}
}
}
}
else
{
lean_object* v_a_254_; lean_object* v___x_256_; uint8_t v_isShared_257_; uint8_t v_isSharedCheck_261_; 
lean_dec(v_a_220_);
lean_dec(v_request_140_);
v_a_254_ = lean_ctor_get(v___x_229_, 0);
v_isSharedCheck_261_ = !lean_is_exclusive(v___x_229_);
if (v_isSharedCheck_261_ == 0)
{
v___x_256_ = v___x_229_;
v_isShared_257_ = v_isSharedCheck_261_;
goto v_resetjp_255_;
}
else
{
lean_inc(v_a_254_);
lean_dec(v___x_229_);
v___x_256_ = lean_box(0);
v_isShared_257_ = v_isSharedCheck_261_;
goto v_resetjp_255_;
}
v_resetjp_255_:
{
lean_object* v___x_259_; 
if (v_isShared_257_ == 0)
{
v___x_259_ = v___x_256_;
goto v_reusejp_258_;
}
else
{
lean_object* v_reuseFailAlloc_260_; 
v_reuseFailAlloc_260_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_260_, 0, v_a_254_);
v___x_259_ = v_reuseFailAlloc_260_;
goto v_reusejp_258_;
}
v_reusejp_258_:
{
return v___x_259_;
}
}
}
}
else
{
lean_object* v_a_262_; lean_object* v___x_264_; uint8_t v_isShared_265_; uint8_t v_isSharedCheck_269_; 
lean_dec(v_a_220_);
lean_dec(v_request_140_);
v_a_262_ = lean_ctor_get(v___x_227_, 0);
v_isSharedCheck_269_ = !lean_is_exclusive(v___x_227_);
if (v_isSharedCheck_269_ == 0)
{
v___x_264_ = v___x_227_;
v_isShared_265_ = v_isSharedCheck_269_;
goto v_resetjp_263_;
}
else
{
lean_inc(v_a_262_);
lean_dec(v___x_227_);
v___x_264_ = lean_box(0);
v_isShared_265_ = v_isSharedCheck_269_;
goto v_resetjp_263_;
}
v_resetjp_263_:
{
lean_object* v___x_267_; 
if (v_isShared_265_ == 0)
{
v___x_267_ = v___x_264_;
goto v_reusejp_266_;
}
else
{
lean_object* v_reuseFailAlloc_268_; 
v_reuseFailAlloc_268_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_268_, 0, v_a_262_);
v___x_267_ = v_reuseFailAlloc_268_;
goto v_reusejp_266_;
}
v_reusejp_266_:
{
return v___x_267_;
}
}
}
}
else
{
lean_object* v_a_270_; lean_object* v___x_272_; uint8_t v_isShared_273_; uint8_t v_isSharedCheck_277_; 
lean_dec(v_a_220_);
lean_dec(v_request_140_);
v_a_270_ = lean_ctor_get(v___x_225_, 0);
v_isSharedCheck_277_ = !lean_is_exclusive(v___x_225_);
if (v_isSharedCheck_277_ == 0)
{
v___x_272_ = v___x_225_;
v_isShared_273_ = v_isSharedCheck_277_;
goto v_resetjp_271_;
}
else
{
lean_inc(v_a_270_);
lean_dec(v___x_225_);
v___x_272_ = lean_box(0);
v_isShared_273_ = v_isSharedCheck_277_;
goto v_resetjp_271_;
}
v_resetjp_271_:
{
lean_object* v___x_275_; 
if (v_isShared_273_ == 0)
{
v___x_275_ = v___x_272_;
goto v_reusejp_274_;
}
else
{
lean_object* v_reuseFailAlloc_276_; 
v_reuseFailAlloc_276_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_276_, 0, v_a_270_);
v___x_275_ = v_reuseFailAlloc_276_;
goto v_reusejp_274_;
}
v_reusejp_274_:
{
return v___x_275_;
}
}
}
}
else
{
lean_object* v_a_278_; lean_object* v___x_280_; uint8_t v_isShared_281_; uint8_t v_isSharedCheck_285_; 
lean_dec_ref(v_constMap_202_);
lean_dec(v_request_140_);
v_a_278_ = lean_ctor_get(v___x_219_, 0);
v_isSharedCheck_285_ = !lean_is_exclusive(v___x_219_);
if (v_isSharedCheck_285_ == 0)
{
v___x_280_ = v___x_219_;
v_isShared_281_ = v_isSharedCheck_285_;
goto v_resetjp_279_;
}
else
{
lean_inc(v_a_278_);
lean_dec(v___x_219_);
v___x_280_ = lean_box(0);
v_isShared_281_ = v_isSharedCheck_285_;
goto v_resetjp_279_;
}
v_resetjp_279_:
{
lean_object* v___x_283_; 
if (v_isShared_281_ == 0)
{
v___x_283_ = v___x_280_;
goto v_reusejp_282_;
}
else
{
lean_object* v_reuseFailAlloc_284_; 
v_reuseFailAlloc_284_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_284_, 0, v_a_278_);
v___x_283_ = v_reuseFailAlloc_284_;
goto v_reusejp_282_;
}
v_reusejp_282_:
{
return v___x_283_;
}
}
}
}
else
{
lean_object* v_a_286_; lean_object* v___x_288_; uint8_t v_isShared_289_; uint8_t v_isSharedCheck_293_; 
lean_dec(v_a_211_);
lean_dec_ref(v_constMap_202_);
lean_dec_ref(v_constMap_201_);
lean_dec(v_request_140_);
v_a_286_ = lean_ctor_get(v___x_216_, 0);
v_isSharedCheck_293_ = !lean_is_exclusive(v___x_216_);
if (v_isSharedCheck_293_ == 0)
{
v___x_288_ = v___x_216_;
v_isShared_289_ = v_isSharedCheck_293_;
goto v_resetjp_287_;
}
else
{
lean_inc(v_a_286_);
lean_dec(v___x_216_);
v___x_288_ = lean_box(0);
v_isShared_289_ = v_isSharedCheck_293_;
goto v_resetjp_287_;
}
v_resetjp_287_:
{
lean_object* v___x_291_; 
if (v_isShared_289_ == 0)
{
v___x_291_ = v___x_288_;
goto v_reusejp_290_;
}
else
{
lean_object* v_reuseFailAlloc_292_; 
v_reuseFailAlloc_292_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_292_, 0, v_a_286_);
v___x_291_ = v_reuseFailAlloc_292_;
goto v_reusejp_290_;
}
v_reusejp_290_:
{
return v___x_291_;
}
}
}
}
else
{
lean_object* v_a_294_; lean_object* v___x_296_; uint8_t v_isShared_297_; uint8_t v_isSharedCheck_301_; 
lean_dec_ref(v_constMap_202_);
lean_dec_ref(v_constMap_201_);
lean_dec(v_request_140_);
v_a_294_ = lean_ctor_get(v___x_210_, 0);
v_isSharedCheck_301_ = !lean_is_exclusive(v___x_210_);
if (v_isSharedCheck_301_ == 0)
{
v___x_296_ = v___x_210_;
v_isShared_297_ = v_isSharedCheck_301_;
goto v_resetjp_295_;
}
else
{
lean_inc(v_a_294_);
lean_dec(v___x_210_);
v___x_296_ = lean_box(0);
v_isShared_297_ = v_isSharedCheck_301_;
goto v_resetjp_295_;
}
v_resetjp_295_:
{
lean_object* v___x_299_; 
if (v_isShared_297_ == 0)
{
v___x_299_ = v___x_296_;
goto v_reusejp_298_;
}
else
{
lean_object* v_reuseFailAlloc_300_; 
v_reuseFailAlloc_300_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_300_, 0, v_a_294_);
v___x_299_ = v_reuseFailAlloc_300_;
goto v_reusejp_298_;
}
v_reusejp_298_:
{
return v___x_299_;
}
}
}
}
else
{
lean_dec_ref(v_constMap_202_);
lean_dec_ref(v_constMap_201_);
lean_dec(v_a_191_);
lean_dec(v_request_140_);
return v___x_208_;
}
}
else
{
lean_object* v_a_302_; lean_object* v___x_304_; uint8_t v_isShared_305_; uint8_t v_isSharedCheck_309_; 
lean_dec_ref(v_constMap_202_);
lean_dec_ref(v_constMap_201_);
lean_dec(v_a_191_);
lean_dec(v_request_140_);
v_a_302_ = lean_ctor_get(v___x_206_, 0);
v_isSharedCheck_309_ = !lean_is_exclusive(v___x_206_);
if (v_isSharedCheck_309_ == 0)
{
v___x_304_ = v___x_206_;
v_isShared_305_ = v_isSharedCheck_309_;
goto v_resetjp_303_;
}
else
{
lean_inc(v_a_302_);
lean_dec(v___x_206_);
v___x_304_ = lean_box(0);
v_isShared_305_ = v_isSharedCheck_309_;
goto v_resetjp_303_;
}
v_resetjp_303_:
{
lean_object* v___x_307_; 
if (v_isShared_305_ == 0)
{
v___x_307_ = v___x_304_;
goto v_reusejp_306_;
}
else
{
lean_object* v_reuseFailAlloc_308_; 
v_reuseFailAlloc_308_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_308_, 0, v_a_302_);
v___x_307_ = v_reuseFailAlloc_308_;
goto v_reusejp_306_;
}
v_reusejp_306_:
{
return v___x_307_;
}
}
}
}
else
{
lean_object* v_a_310_; lean_object* v___x_312_; uint8_t v_isShared_313_; uint8_t v_isSharedCheck_317_; 
lean_dec_ref(v_constMap_202_);
lean_dec_ref(v_constMap_201_);
lean_dec(v_a_191_);
lean_dec(v_request_140_);
v_a_310_ = lean_ctor_get(v___x_204_, 0);
v_isSharedCheck_317_ = !lean_is_exclusive(v___x_204_);
if (v_isSharedCheck_317_ == 0)
{
v___x_312_ = v___x_204_;
v_isShared_313_ = v_isSharedCheck_317_;
goto v_resetjp_311_;
}
else
{
lean_inc(v_a_310_);
lean_dec(v___x_204_);
v___x_312_ = lean_box(0);
v_isShared_313_ = v_isSharedCheck_317_;
goto v_resetjp_311_;
}
v_resetjp_311_:
{
lean_object* v___x_315_; 
if (v_isShared_313_ == 0)
{
v___x_315_ = v___x_312_;
goto v_reusejp_314_;
}
else
{
lean_object* v_reuseFailAlloc_316_; 
v_reuseFailAlloc_316_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_316_, 0, v_a_310_);
v___x_315_ = v_reuseFailAlloc_316_;
goto v_reusejp_314_;
}
v_reusejp_314_:
{
return v___x_315_;
}
}
}
}
else
{
lean_object* v_a_318_; lean_object* v___x_320_; uint8_t v_isShared_321_; uint8_t v_isSharedCheck_325_; 
lean_dec(v_a_191_);
lean_dec(v_a_185_);
lean_dec(v_request_140_);
v_a_318_ = lean_ctor_get(v___x_195_, 0);
v_isSharedCheck_325_ = !lean_is_exclusive(v___x_195_);
if (v_isSharedCheck_325_ == 0)
{
v___x_320_ = v___x_195_;
v_isShared_321_ = v_isSharedCheck_325_;
goto v_resetjp_319_;
}
else
{
lean_inc(v_a_318_);
lean_dec(v___x_195_);
v___x_320_ = lean_box(0);
v_isShared_321_ = v_isSharedCheck_325_;
goto v_resetjp_319_;
}
v_resetjp_319_:
{
lean_object* v___x_323_; 
if (v_isShared_321_ == 0)
{
v___x_323_ = v___x_320_;
goto v_reusejp_322_;
}
else
{
lean_object* v_reuseFailAlloc_324_; 
v_reuseFailAlloc_324_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_324_, 0, v_a_318_);
v___x_323_ = v_reuseFailAlloc_324_;
goto v_reusejp_322_;
}
v_reusejp_322_:
{
return v___x_323_;
}
}
}
}
else
{
lean_object* v_a_326_; lean_object* v___x_328_; uint8_t v_isShared_329_; uint8_t v_isSharedCheck_333_; 
lean_dec(v_a_191_);
lean_dec(v_a_185_);
lean_dec(v_request_140_);
v_a_326_ = lean_ctor_get(v___x_193_, 0);
v_isSharedCheck_333_ = !lean_is_exclusive(v___x_193_);
if (v_isSharedCheck_333_ == 0)
{
v___x_328_ = v___x_193_;
v_isShared_329_ = v_isSharedCheck_333_;
goto v_resetjp_327_;
}
else
{
lean_inc(v_a_326_);
lean_dec(v___x_193_);
v___x_328_ = lean_box(0);
v_isShared_329_ = v_isSharedCheck_333_;
goto v_resetjp_327_;
}
v_resetjp_327_:
{
lean_object* v___x_331_; 
if (v_isShared_329_ == 0)
{
v___x_331_ = v___x_328_;
goto v_reusejp_330_;
}
else
{
lean_object* v_reuseFailAlloc_332_; 
v_reuseFailAlloc_332_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_332_, 0, v_a_326_);
v___x_331_ = v_reuseFailAlloc_332_;
goto v_reusejp_330_;
}
v_reusejp_330_:
{
return v___x_331_;
}
}
}
}
else
{
lean_object* v_a_334_; lean_object* v___x_336_; uint8_t v_isShared_337_; uint8_t v_isSharedCheck_341_; 
lean_dec(v_a_185_);
lean_dec(v_request_140_);
v_a_334_ = lean_ctor_get(v___x_190_, 0);
v_isSharedCheck_341_ = !lean_is_exclusive(v___x_190_);
if (v_isSharedCheck_341_ == 0)
{
v___x_336_ = v___x_190_;
v_isShared_337_ = v_isSharedCheck_341_;
goto v_resetjp_335_;
}
else
{
lean_inc(v_a_334_);
lean_dec(v___x_190_);
v___x_336_ = lean_box(0);
v_isShared_337_ = v_isSharedCheck_341_;
goto v_resetjp_335_;
}
v_resetjp_335_:
{
lean_object* v___x_339_; 
if (v_isShared_337_ == 0)
{
v___x_339_ = v___x_336_;
goto v_reusejp_338_;
}
else
{
lean_object* v_reuseFailAlloc_340_; 
v_reuseFailAlloc_340_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_340_, 0, v_a_334_);
v___x_339_ = v_reuseFailAlloc_340_;
goto v_reusejp_338_;
}
v_reusejp_338_:
{
return v___x_339_;
}
}
}
}
else
{
lean_object* v_a_342_; lean_object* v___x_344_; uint8_t v_isShared_345_; uint8_t v_isSharedCheck_349_; 
lean_dec(v_a_185_);
lean_dec(v_request_140_);
v_a_342_ = lean_ctor_get(v___x_188_, 0);
v_isSharedCheck_349_ = !lean_is_exclusive(v___x_188_);
if (v_isSharedCheck_349_ == 0)
{
v___x_344_ = v___x_188_;
v_isShared_345_ = v_isSharedCheck_349_;
goto v_resetjp_343_;
}
else
{
lean_inc(v_a_342_);
lean_dec(v___x_188_);
v___x_344_ = lean_box(0);
v_isShared_345_ = v_isSharedCheck_349_;
goto v_resetjp_343_;
}
v_resetjp_343_:
{
lean_object* v___x_347_; 
if (v_isShared_345_ == 0)
{
v___x_347_ = v___x_344_;
goto v_reusejp_346_;
}
else
{
lean_object* v_reuseFailAlloc_348_; 
v_reuseFailAlloc_348_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_348_, 0, v_a_342_);
v___x_347_ = v_reuseFailAlloc_348_;
goto v_reusejp_346_;
}
v_reusejp_346_:
{
return v___x_347_;
}
}
}
}
else
{
lean_object* v_a_350_; lean_object* v___x_352_; uint8_t v_isShared_353_; uint8_t v_isSharedCheck_357_; 
lean_dec(v_request_140_);
v_a_350_ = lean_ctor_get(v___x_184_, 0);
v_isSharedCheck_357_ = !lean_is_exclusive(v___x_184_);
if (v_isSharedCheck_357_ == 0)
{
v___x_352_ = v___x_184_;
v_isShared_353_ = v_isSharedCheck_357_;
goto v_resetjp_351_;
}
else
{
lean_inc(v_a_350_);
lean_dec(v___x_184_);
v___x_352_ = lean_box(0);
v_isShared_353_ = v_isSharedCheck_357_;
goto v_resetjp_351_;
}
v_resetjp_351_:
{
lean_object* v___x_355_; 
if (v_isShared_353_ == 0)
{
v___x_355_ = v___x_352_;
goto v_reusejp_354_;
}
else
{
lean_object* v_reuseFailAlloc_356_; 
v_reuseFailAlloc_356_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_356_, 0, v_a_350_);
v___x_355_ = v_reuseFailAlloc_356_;
goto v_reusejp_354_;
}
v_reusejp_354_:
{
return v___x_355_;
}
}
}
}
else
{
lean_object* v_a_358_; lean_object* v___x_360_; uint8_t v_isShared_361_; uint8_t v_isSharedCheck_365_; 
lean_dec(v_request_140_);
v_a_358_ = lean_ctor_get(v___x_182_, 0);
v_isSharedCheck_365_ = !lean_is_exclusive(v___x_182_);
if (v_isSharedCheck_365_ == 0)
{
v___x_360_ = v___x_182_;
v_isShared_361_ = v_isSharedCheck_365_;
goto v_resetjp_359_;
}
else
{
lean_inc(v_a_358_);
lean_dec(v___x_182_);
v___x_360_ = lean_box(0);
v_isShared_361_ = v_isSharedCheck_365_;
goto v_resetjp_359_;
}
v_resetjp_359_:
{
lean_object* v___x_363_; 
if (v_isShared_361_ == 0)
{
v___x_363_ = v___x_360_;
goto v_reusejp_362_;
}
else
{
lean_object* v_reuseFailAlloc_364_; 
v_reuseFailAlloc_364_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_364_, 0, v_a_358_);
v___x_363_ = v_reuseFailAlloc_364_;
goto v_reusejp_362_;
}
v_reusejp_362_:
{
return v___x_363_;
}
}
}
}
else
{
lean_object* v_a_366_; lean_object* v___x_368_; uint8_t v_isShared_369_; uint8_t v_isSharedCheck_373_; 
lean_dec(v_request_140_);
v_a_366_ = lean_ctor_get(v___x_180_, 0);
v_isSharedCheck_373_ = !lean_is_exclusive(v___x_180_);
if (v_isSharedCheck_373_ == 0)
{
v___x_368_ = v___x_180_;
v_isShared_369_ = v_isSharedCheck_373_;
goto v_resetjp_367_;
}
else
{
lean_inc(v_a_366_);
lean_dec(v___x_180_);
v___x_368_ = lean_box(0);
v_isShared_369_ = v_isSharedCheck_373_;
goto v_resetjp_367_;
}
v_resetjp_367_:
{
lean_object* v___x_371_; 
if (v_isShared_369_ == 0)
{
v___x_371_ = v___x_368_;
goto v_reusejp_370_;
}
else
{
lean_object* v_reuseFailAlloc_372_; 
v_reuseFailAlloc_372_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_372_, 0, v_a_366_);
v___x_371_ = v_reuseFailAlloc_372_;
goto v_reusejp_370_;
}
v_reusejp_370_:
{
return v___x_371_;
}
}
}
}
}
else
{
lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v___x_376_; lean_object* v___x_377_; lean_object* v___x_378_; lean_object* v___x_379_; lean_object* v___x_380_; lean_object* v___x_381_; 
lean_del_object(v___x_160_);
v___x_374_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30));
v___x_375_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__31));
v___x_376_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__13));
v___x_377_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__32));
v___x_378_ = lean_box(0);
v___x_379_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__38));
lean_inc(v_request_140_);
v___x_380_ = lp_proofEnvironment_OCMEnvironment_keys(v_request_140_, v___x_379_);
v___x_381_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_380_);
if (lean_obj_tag(v___x_381_) == 0)
{
lean_object* v___x_382_; lean_object* v___x_383_; 
lean_dec_ref_known(v___x_381_, 1);
v___x_382_ = lean_st_ref_set(v_phase_142_, v___x_374_);
lean_inc(v_request_140_);
v___x_383_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_374_);
if (lean_obj_tag(v___x_383_) == 0)
{
lean_object* v_a_384_; lean_object* v___x_385_; 
v_a_384_ = lean_ctor_get(v___x_383_, 0);
lean_inc(v_a_384_);
lean_dec_ref_known(v___x_383_, 1);
v___x_385_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_384_, v___x_163_);
lean_dec(v_a_384_);
if (lean_obj_tag(v___x_385_) == 0)
{
lean_object* v_a_386_; lean_object* v___x_387_; lean_object* v___x_388_; 
v_a_386_ = lean_ctor_get(v___x_385_, 0);
lean_inc(v_a_386_);
lean_dec_ref_known(v___x_385_, 1);
v___x_387_ = lean_st_ref_set(v_phase_142_, v___x_376_);
lean_inc(v_request_140_);
v___x_388_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_376_);
if (lean_obj_tag(v___x_388_) == 0)
{
lean_object* v_a_389_; lean_object* v___x_390_; 
v_a_389_ = lean_ctor_get(v___x_388_, 0);
lean_inc(v_a_389_);
lean_dec_ref_known(v___x_388_, 1);
v___x_390_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_389_, v___x_163_);
lean_dec(v_a_389_);
if (lean_obj_tag(v___x_390_) == 0)
{
lean_object* v_a_391_; lean_object* v___x_392_; lean_object* v___x_393_; lean_object* v___x_394_; 
v_a_391_ = lean_ctor_get(v___x_390_, 0);
lean_inc(v_a_391_);
lean_dec_ref_known(v___x_390_, 1);
v___x_392_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__24));
v___x_393_ = lean_st_ref_set(v_phase_142_, v___x_392_);
lean_inc(v_request_140_);
v___x_394_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_377_);
if (lean_obj_tag(v___x_394_) == 0)
{
lean_object* v_a_395_; lean_object* v___x_396_; 
v_a_395_ = lean_ctor_get(v___x_394_, 0);
lean_inc(v_a_395_);
lean_dec_ref_known(v___x_394_, 1);
v___x_396_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_395_, v___x_151_);
lean_dec(v_a_395_);
if (lean_obj_tag(v___x_396_) == 0)
{
lean_object* v_a_397_; lean_object* v___x_398_; lean_object* v___x_399_; lean_object* v_state_400_; lean_object* v___x_402_; uint8_t v_isShared_403_; uint8_t v_isSharedCheck_604_; 
v_a_397_ = lean_ctor_get(v___x_396_, 0);
lean_inc(v_a_397_);
lean_dec_ref_known(v___x_396_, 1);
v___x_398_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__25));
v___x_399_ = lean_st_ref_set(v_phase_142_, v___x_398_);
v_state_400_ = lean_ctor_get(v_a_386_, 0);
v_isSharedCheck_604_ = !lean_is_exclusive(v_a_386_);
if (v_isSharedCheck_604_ == 0)
{
lean_object* v_unused_605_; 
v_unused_605_ = lean_ctor_get(v_a_386_, 1);
lean_dec(v_unused_605_);
v___x_402_ = v_a_386_;
v_isShared_403_ = v_isSharedCheck_604_;
goto v_resetjp_401_;
}
else
{
lean_inc(v_state_400_);
lean_dec(v_a_386_);
v___x_402_ = lean_box(0);
v_isShared_403_ = v_isSharedCheck_604_;
goto v_resetjp_401_;
}
v_resetjp_401_:
{
lean_object* v_state_404_; lean_object* v___x_406_; uint8_t v_isShared_407_; uint8_t v_isSharedCheck_602_; 
v_state_404_ = lean_ctor_get(v_a_391_, 0);
v_isSharedCheck_602_ = !lean_is_exclusive(v_a_391_);
if (v_isSharedCheck_602_ == 0)
{
lean_object* v_unused_603_; 
v_unused_603_ = lean_ctor_get(v_a_391_, 1);
lean_dec(v_unused_603_);
v___x_406_ = v_a_391_;
v_isShared_407_ = v_isSharedCheck_602_;
goto v_resetjp_405_;
}
else
{
lean_inc(v_state_404_);
lean_dec(v_a_391_);
v___x_406_ = lean_box(0);
v_isShared_407_ = v_isSharedCheck_602_;
goto v_resetjp_405_;
}
v_resetjp_405_:
{
lean_object* v_constMap_408_; lean_object* v_constMap_409_; lean_object* v___x_410_; lean_object* v___x_411_; 
v_constMap_408_ = lean_ctor_get(v_state_400_, 5);
lean_inc_ref_n(v_constMap_408_, 2);
lean_dec_ref(v_state_400_);
v_constMap_409_ = lean_ctor_get(v_state_404_, 5);
lean_inc_ref(v_constMap_409_);
lean_dec_ref(v_state_404_);
v___x_410_ = lp_proofEnvironment_OCMEnvironment_mergePrimitives(v_constMap_408_, v_constMap_409_);
v___x_411_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_410_);
if (lean_obj_tag(v___x_411_) == 0)
{
lean_object* v_a_412_; lean_object* v___x_413_; lean_object* v___x_414_; lean_object* v___x_415_; 
v_a_412_ = lean_ctor_get(v___x_411_, 0);
lean_inc(v_a_412_);
lean_dec_ref_known(v___x_411_, 1);
v___x_413_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__39));
v___x_414_ = lean_st_ref_set(v_phase_142_, v___x_413_);
v___x_415_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_375_);
if (lean_obj_tag(v___x_415_) == 0)
{
lean_object* v_a_416_; lean_object* v___x_417_; 
v_a_416_ = lean_ctor_get(v___x_415_, 0);
lean_inc(v_a_416_);
lean_dec_ref_known(v___x_415_, 1);
v___x_417_ = lp_proofEnvironment_OCMEnvironment_readJson(v_a_416_);
lean_dec(v_a_416_);
if (lean_obj_tag(v___x_417_) == 0)
{
lean_object* v_a_418_; lean_object* v___x_420_; uint8_t v_isShared_421_; uint8_t v_isSharedCheck_585_; 
v_a_418_ = lean_ctor_get(v___x_417_, 0);
v_isSharedCheck_585_ = !lean_is_exclusive(v___x_417_);
if (v_isSharedCheck_585_ == 0)
{
v___x_420_ = v___x_417_;
v_isShared_421_ = v_isSharedCheck_585_;
goto v_resetjp_419_;
}
else
{
lean_inc(v_a_418_);
lean_dec(v___x_417_);
v___x_420_ = lean_box(0);
v_isShared_421_ = v_isSharedCheck_585_;
goto v_resetjp_419_;
}
v_resetjp_419_:
{
lean_object* v___x_422_; 
v___x_422_ = lp_proofEnvironment_OCMEnvironment_preparationPolicy(v_a_418_, v_a_397_, v_a_412_);
lean_dec(v_a_397_);
if (lean_obj_tag(v___x_422_) == 0)
{
lean_object* v_a_423_; lean_object* v___x_424_; lean_object* v___x_425_; lean_object* v_target_426_; lean_object* v_axioms_427_; lean_object* v___x_428_; lean_object* v___x_429_; 
v_a_423_ = lean_ctor_get(v___x_422_, 0);
lean_inc(v_a_423_);
lean_dec_ref_known(v___x_422_, 1);
v___x_424_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__26));
v___x_425_ = lean_st_ref_set(v_phase_142_, v___x_424_);
v_target_426_ = lean_ctor_get(v_a_423_, 0);
lean_inc_ref(v_target_426_);
v_axioms_427_ = lean_ctor_get(v_a_423_, 3);
v___x_428_ = lp_proofEnvironment_OCMEnvironment_requireAxiomRegistry(v_a_412_, v_constMap_409_, v_axioms_427_);
v___x_429_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_428_);
if (lean_obj_tag(v___x_429_) == 0)
{
lean_object* v___x_430_; lean_object* v___x_431_; lean_object* v___x_432_; 
lean_dec_ref_known(v___x_429_, 1);
v___x_430_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__27));
v___x_431_ = lean_st_ref_set(v_phase_142_, v___x_430_);
v___x_432_ = lp_proofEnvironment_OCMEnvironment_prepareMap(v_a_412_, v_a_423_);
lean_dec(v_a_412_);
if (lean_obj_tag(v___x_432_) == 0)
{
lean_object* v_a_433_; lean_object* v___x_434_; lean_object* v___x_435_; lean_object* v_env_436_; lean_object* v_constants_437_; lean_object* v_policy_438_; lean_object* v_closure_439_; lean_object* v___x_440_; lean_object* v___x_441_; 
v_a_433_ = lean_ctor_get(v___x_432_, 0);
lean_inc(v_a_433_);
lean_dec_ref_known(v___x_432_, 1);
v___x_434_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__28));
v___x_435_ = lean_st_ref_set(v_phase_142_, v___x_434_);
v_env_436_ = lean_ctor_get(v_a_433_, 0);
v_constants_437_ = lean_ctor_get(v_a_433_, 1);
lean_inc_ref(v_constants_437_);
v_policy_438_ = lean_ctor_get(v_a_433_, 2);
lean_inc_ref(v_policy_438_);
v_closure_439_ = lean_ctor_get(v_a_433_, 3);
lean_inc_ref(v_closure_439_);
v___x_440_ = lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives(v_constants_437_, v_constMap_409_);
lean_dec_ref(v_constMap_409_);
v___x_441_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_440_);
if (lean_obj_tag(v___x_441_) == 0)
{
lean_object* v___x_442_; lean_object* v___x_443_; lean_object* v_names_444_; lean_object* v_edges_445_; lean_object* v___x_447_; uint8_t v_isShared_448_; uint8_t v_isSharedCheck_552_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__40));
v___x_443_ = lean_st_ref_set(v_phase_142_, v___x_442_);
v_names_444_ = lean_ctor_get(v_closure_439_, 0);
v_edges_445_ = lean_ctor_get(v_closure_439_, 1);
v_isSharedCheck_552_ = !lean_is_exclusive(v_closure_439_);
if (v_isSharedCheck_552_ == 0)
{
v___x_447_ = v_closure_439_;
v_isShared_448_ = v_isSharedCheck_552_;
goto v_resetjp_446_;
}
else
{
lean_inc(v_edges_445_);
lean_inc(v_names_444_);
lean_dec(v_closure_439_);
v___x_447_ = lean_box(0);
v_isShared_448_ = v_isSharedCheck_552_;
goto v_resetjp_446_;
}
v_resetjp_446_:
{
lean_object* v___x_449_; lean_object* v___x_450_; lean_object* v___x_451_; 
v___x_449_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__41));
lean_inc_ref(v_out_141_);
v___x_450_ = l_System_FilePath_join(v_out_141_, v___x_449_);
lean_inc_ref(v_names_444_);
lean_inc_ref(v_env_436_);
v___x_451_ = lp_proofEnvironment_OCMEnvironment_writeEnvironment(v___x_450_, v_env_436_, v_names_444_);
lean_dec_ref(v___x_450_);
if (lean_obj_tag(v___x_451_) == 0)
{
lean_object* v_name_452_; lean_object* v_levelParams_453_; lean_object* v_type_454_; lean_object* v___x_455_; lean_object* v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_451_, 1);
v_name_452_ = lean_ctor_get(v_target_426_, 0);
lean_inc(v_name_452_);
v_levelParams_453_ = lean_ctor_get(v_target_426_, 1);
lean_inc(v_levelParams_453_);
v_type_454_ = lean_ctor_get(v_target_426_, 2);
lean_inc_ref(v_type_454_);
lean_dec_ref(v_target_426_);
v___x_455_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__42));
lean_inc_ref(v_out_141_);
v___x_456_ = l_System_FilePath_join(v_out_141_, v___x_455_);
lean_inc_ref(v_env_436_);
v___x_457_ = lp_proofEnvironment_OCMEnvironment_writeExpression(v___x_456_, v_env_436_, v_name_452_, v_levelParams_453_, v_type_454_);
lean_dec_ref(v___x_456_);
if (lean_obj_tag(v___x_457_) == 0)
{
lean_object* v_a_458_; lean_object* v___x_460_; uint8_t v_isShared_461_; uint8_t v_isSharedCheck_543_; 
v_a_458_ = lean_ctor_get(v___x_457_, 0);
v_isSharedCheck_543_ = !lean_is_exclusive(v___x_457_);
if (v_isSharedCheck_543_ == 0)
{
v___x_460_ = v___x_457_;
v_isShared_461_ = v_isSharedCheck_543_;
goto v_resetjp_459_;
}
else
{
lean_inc(v_a_458_);
lean_dec(v___x_457_);
v___x_460_ = lean_box(0);
v_isShared_461_ = v_isSharedCheck_543_;
goto v_resetjp_459_;
}
v_resetjp_459_:
{
lean_object* v___x_462_; lean_object* v___x_463_; lean_object* v___x_464_; lean_object* v___x_465_; 
v___x_462_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__43));
lean_inc_ref(v_out_141_);
v___x_463_ = l_System_FilePath_join(v_out_141_, v___x_462_);
lean_inc(v_a_433_);
v___x_464_ = lp_proofEnvironment_OCMEnvironment_registration(v_a_433_, v_a_458_);
v___x_465_ = lp_proofEnvironment_OCMEnvironment_writeJson(v___x_463_, v___x_464_);
lean_dec_ref(v___x_463_);
if (lean_obj_tag(v___x_465_) == 0)
{
lean_object* v___x_466_; lean_object* v___x_467_; lean_object* v___x_468_; lean_object* v___x_469_; 
lean_dec_ref_known(v___x_465_, 1);
v___x_466_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__44));
v___x_467_ = l_System_FilePath_join(v_out_141_, v___x_466_);
v___x_468_ = lp_proofEnvironment_OCMEnvironment_inventory(v_a_433_);
v___x_469_ = lp_proofEnvironment_OCMEnvironment_writeJson(v___x_467_, v___x_468_);
lean_dec_ref(v___x_467_);
if (lean_obj_tag(v___x_469_) == 0)
{
lean_object* v___x_471_; uint8_t v_isShared_472_; uint8_t v_isSharedCheck_525_; 
v_isSharedCheck_525_ = !lean_is_exclusive(v___x_469_);
if (v_isSharedCheck_525_ == 0)
{
lean_object* v_unused_526_; 
v_unused_526_ = lean_ctor_get(v___x_469_, 0);
lean_dec(v_unused_526_);
v___x_471_ = v___x_469_;
v_isShared_472_ = v_isSharedCheck_525_;
goto v_resetjp_470_;
}
else
{
lean_dec(v___x_469_);
v___x_471_ = lean_box(0);
v_isShared_472_ = v_isSharedCheck_525_;
goto v_resetjp_470_;
}
v_resetjp_470_:
{
lean_object* v_size_473_; lean_object* v___x_475_; uint8_t v_isShared_476_; uint8_t v_isSharedCheck_523_; 
v_size_473_ = lean_ctor_get(v_constMap_408_, 0);
v_isSharedCheck_523_ = !lean_is_exclusive(v_constMap_408_);
if (v_isSharedCheck_523_ == 0)
{
lean_object* v_unused_524_; 
v_unused_524_ = lean_ctor_get(v_constMap_408_, 1);
lean_dec(v_unused_524_);
v___x_475_ = v_constMap_408_;
v_isShared_476_ = v_isSharedCheck_523_;
goto v_resetjp_474_;
}
else
{
lean_inc(v_size_473_);
lean_dec(v_constMap_408_);
v___x_475_ = lean_box(0);
v_isShared_476_ = v_isSharedCheck_523_;
goto v_resetjp_474_;
}
v_resetjp_474_:
{
lean_object* v_size_477_; lean_object* v___x_479_; uint8_t v_isShared_480_; uint8_t v_isSharedCheck_521_; 
v_size_477_ = lean_ctor_get(v_constants_437_, 0);
v_isSharedCheck_521_ = !lean_is_exclusive(v_constants_437_);
if (v_isSharedCheck_521_ == 0)
{
lean_object* v_unused_522_; 
v_unused_522_ = lean_ctor_get(v_constants_437_, 1);
lean_dec(v_unused_522_);
v___x_479_ = v_constants_437_;
v_isShared_480_ = v_isSharedCheck_521_;
goto v_resetjp_478_;
}
else
{
lean_inc(v_size_477_);
lean_dec(v_constants_437_);
v___x_479_ = lean_box(0);
v_isShared_480_ = v_isSharedCheck_521_;
goto v_resetjp_478_;
}
v_resetjp_478_:
{
lean_object* v_axioms_481_; lean_object* v___x_482_; lean_object* v___x_483_; lean_object* v___x_484_; lean_object* v___x_485_; lean_object* v___x_486_; lean_object* v___x_488_; 
v_axioms_481_ = lean_ctor_get(v_policy_438_, 3);
lean_inc_ref(v_axioms_481_);
lean_dec_ref(v_policy_438_);
v___x_482_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__45));
v___x_483_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__46));
v___x_484_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__47));
v___x_485_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__48));
v___x_486_ = l_Lean_JsonNumber_fromNat(v_size_473_);
if (v_isShared_461_ == 0)
{
lean_ctor_set_tag(v___x_460_, 2);
lean_ctor_set(v___x_460_, 0, v___x_486_);
v___x_488_ = v___x_460_;
goto v_reusejp_487_;
}
else
{
lean_object* v_reuseFailAlloc_520_; 
v_reuseFailAlloc_520_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_520_, 0, v___x_486_);
v___x_488_ = v_reuseFailAlloc_520_;
goto v_reusejp_487_;
}
v_reusejp_487_:
{
lean_object* v___x_490_; 
if (v_isShared_480_ == 0)
{
lean_ctor_set(v___x_479_, 1, v___x_488_);
lean_ctor_set(v___x_479_, 0, v___x_485_);
v___x_490_ = v___x_479_;
goto v_reusejp_489_;
}
else
{
lean_object* v_reuseFailAlloc_519_; 
v_reuseFailAlloc_519_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_519_, 0, v___x_485_);
lean_ctor_set(v_reuseFailAlloc_519_, 1, v___x_488_);
v___x_490_ = v_reuseFailAlloc_519_;
goto v_reusejp_489_;
}
v_reusejp_489_:
{
lean_object* v___x_491_; lean_object* v___x_492_; lean_object* v___x_494_; 
v___x_491_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__49));
v___x_492_ = l_Lean_JsonNumber_fromNat(v_size_477_);
if (v_isShared_421_ == 0)
{
lean_ctor_set_tag(v___x_420_, 2);
lean_ctor_set(v___x_420_, 0, v___x_492_);
v___x_494_ = v___x_420_;
goto v_reusejp_493_;
}
else
{
lean_object* v_reuseFailAlloc_518_; 
v_reuseFailAlloc_518_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_518_, 0, v___x_492_);
v___x_494_ = v_reuseFailAlloc_518_;
goto v_reusejp_493_;
}
v_reusejp_493_:
{
lean_object* v___x_496_; 
if (v_isShared_476_ == 0)
{
lean_ctor_set(v___x_475_, 1, v___x_494_);
lean_ctor_set(v___x_475_, 0, v___x_491_);
v___x_496_ = v___x_475_;
goto v_reusejp_495_;
}
else
{
lean_object* v_reuseFailAlloc_517_; 
v_reuseFailAlloc_517_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_517_, 0, v___x_491_);
lean_ctor_set(v_reuseFailAlloc_517_, 1, v___x_494_);
v___x_496_ = v_reuseFailAlloc_517_;
goto v_reusejp_495_;
}
v_reusejp_495_:
{
lean_object* v___x_497_; lean_object* v___x_498_; lean_object* v___x_499_; lean_object* v___x_500_; lean_object* v___x_502_; 
v___x_497_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__50));
v___x_498_ = lean_array_get_size(v_edges_445_);
lean_dec_ref(v_edges_445_);
v___x_499_ = l_Lean_JsonNumber_fromNat(v___x_498_);
v___x_500_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_500_, 0, v___x_499_);
if (v_isShared_448_ == 0)
{
lean_ctor_set(v___x_447_, 1, v___x_500_);
lean_ctor_set(v___x_447_, 0, v___x_497_);
v___x_502_ = v___x_447_;
goto v_reusejp_501_;
}
else
{
lean_object* v_reuseFailAlloc_516_; 
v_reuseFailAlloc_516_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_516_, 0, v___x_497_);
lean_ctor_set(v_reuseFailAlloc_516_, 1, v___x_500_);
v___x_502_ = v_reuseFailAlloc_516_;
goto v_reusejp_501_;
}
v_reusejp_501_:
{
lean_object* v___x_504_; 
if (v_isShared_407_ == 0)
{
lean_ctor_set_tag(v___x_406_, 1);
lean_ctor_set(v___x_406_, 1, v___x_378_);
lean_ctor_set(v___x_406_, 0, v___x_502_);
v___x_504_ = v___x_406_;
goto v_reusejp_503_;
}
else
{
lean_object* v_reuseFailAlloc_515_; 
v_reuseFailAlloc_515_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_515_, 0, v___x_502_);
lean_ctor_set(v_reuseFailAlloc_515_, 1, v___x_378_);
v___x_504_ = v_reuseFailAlloc_515_;
goto v_reusejp_503_;
}
v_reusejp_503_:
{
lean_object* v___x_506_; 
if (v_isShared_403_ == 0)
{
lean_ctor_set_tag(v___x_402_, 1);
lean_ctor_set(v___x_402_, 1, v___x_504_);
lean_ctor_set(v___x_402_, 0, v___x_496_);
v___x_506_ = v___x_402_;
goto v_reusejp_505_;
}
else
{
lean_object* v_reuseFailAlloc_514_; 
v_reuseFailAlloc_514_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_514_, 0, v___x_496_);
lean_ctor_set(v_reuseFailAlloc_514_, 1, v___x_504_);
v___x_506_ = v_reuseFailAlloc_514_;
goto v_reusejp_505_;
}
v_reusejp_505_:
{
lean_object* v___x_507_; lean_object* v___x_508_; lean_object* v___x_509_; lean_object* v___x_510_; lean_object* v___x_512_; 
v___x_507_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_507_, 0, v___x_490_);
lean_ctor_set(v___x_507_, 1, v___x_506_);
v___x_508_ = l_Lean_Json_mkObj(v___x_507_);
lean_dec_ref_known(v___x_507_, 2);
v___x_509_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__52));
v___x_510_ = lp_proofEnvironment_OCMEnvironment_result(v_a_158_, v___x_482_, v___x_483_, v___x_484_, v___x_508_, v_names_444_, v_axioms_481_, v___x_509_);
if (v_isShared_472_ == 0)
{
lean_ctor_set(v___x_471_, 0, v___x_510_);
v___x_512_ = v___x_471_;
goto v_reusejp_511_;
}
else
{
lean_object* v_reuseFailAlloc_513_; 
v_reuseFailAlloc_513_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_513_, 0, v___x_510_);
v___x_512_ = v_reuseFailAlloc_513_;
goto v_reusejp_511_;
}
v_reusejp_511_:
{
return v___x_512_;
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_527_; lean_object* v___x_529_; uint8_t v_isShared_530_; uint8_t v_isSharedCheck_534_; 
lean_del_object(v___x_460_);
lean_del_object(v___x_447_);
lean_dec_ref(v_edges_445_);
lean_dec_ref(v_names_444_);
lean_dec_ref(v_policy_438_);
lean_dec_ref(v_constants_437_);
lean_del_object(v___x_420_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
v_a_527_ = lean_ctor_get(v___x_469_, 0);
v_isSharedCheck_534_ = !lean_is_exclusive(v___x_469_);
if (v_isSharedCheck_534_ == 0)
{
v___x_529_ = v___x_469_;
v_isShared_530_ = v_isSharedCheck_534_;
goto v_resetjp_528_;
}
else
{
lean_inc(v_a_527_);
lean_dec(v___x_469_);
v___x_529_ = lean_box(0);
v_isShared_530_ = v_isSharedCheck_534_;
goto v_resetjp_528_;
}
v_resetjp_528_:
{
lean_object* v___x_532_; 
if (v_isShared_530_ == 0)
{
v___x_532_ = v___x_529_;
goto v_reusejp_531_;
}
else
{
lean_object* v_reuseFailAlloc_533_; 
v_reuseFailAlloc_533_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_533_, 0, v_a_527_);
v___x_532_ = v_reuseFailAlloc_533_;
goto v_reusejp_531_;
}
v_reusejp_531_:
{
return v___x_532_;
}
}
}
}
else
{
lean_object* v_a_535_; lean_object* v___x_537_; uint8_t v_isShared_538_; uint8_t v_isSharedCheck_542_; 
lean_del_object(v___x_460_);
lean_del_object(v___x_447_);
lean_dec_ref(v_edges_445_);
lean_dec_ref(v_names_444_);
lean_dec_ref(v_policy_438_);
lean_dec_ref(v_constants_437_);
lean_dec(v_a_433_);
lean_del_object(v___x_420_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_535_ = lean_ctor_get(v___x_465_, 0);
v_isSharedCheck_542_ = !lean_is_exclusive(v___x_465_);
if (v_isSharedCheck_542_ == 0)
{
v___x_537_ = v___x_465_;
v_isShared_538_ = v_isSharedCheck_542_;
goto v_resetjp_536_;
}
else
{
lean_inc(v_a_535_);
lean_dec(v___x_465_);
v___x_537_ = lean_box(0);
v_isShared_538_ = v_isSharedCheck_542_;
goto v_resetjp_536_;
}
v_resetjp_536_:
{
lean_object* v___x_540_; 
if (v_isShared_538_ == 0)
{
v___x_540_ = v___x_537_;
goto v_reusejp_539_;
}
else
{
lean_object* v_reuseFailAlloc_541_; 
v_reuseFailAlloc_541_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_541_, 0, v_a_535_);
v___x_540_ = v_reuseFailAlloc_541_;
goto v_reusejp_539_;
}
v_reusejp_539_:
{
return v___x_540_;
}
}
}
}
}
else
{
lean_del_object(v___x_447_);
lean_dec_ref(v_edges_445_);
lean_dec_ref(v_names_444_);
lean_dec_ref(v_policy_438_);
lean_dec_ref(v_constants_437_);
lean_dec(v_a_433_);
lean_del_object(v___x_420_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
return v___x_457_;
}
}
else
{
lean_object* v_a_544_; lean_object* v___x_546_; uint8_t v_isShared_547_; uint8_t v_isSharedCheck_551_; 
lean_del_object(v___x_447_);
lean_dec_ref(v_edges_445_);
lean_dec_ref(v_names_444_);
lean_dec_ref(v_policy_438_);
lean_dec_ref(v_constants_437_);
lean_dec(v_a_433_);
lean_dec_ref(v_target_426_);
lean_del_object(v___x_420_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_544_ = lean_ctor_get(v___x_451_, 0);
v_isSharedCheck_551_ = !lean_is_exclusive(v___x_451_);
if (v_isSharedCheck_551_ == 0)
{
v___x_546_ = v___x_451_;
v_isShared_547_ = v_isSharedCheck_551_;
goto v_resetjp_545_;
}
else
{
lean_inc(v_a_544_);
lean_dec(v___x_451_);
v___x_546_ = lean_box(0);
v_isShared_547_ = v_isSharedCheck_551_;
goto v_resetjp_545_;
}
v_resetjp_545_:
{
lean_object* v___x_549_; 
if (v_isShared_547_ == 0)
{
v___x_549_ = v___x_546_;
goto v_reusejp_548_;
}
else
{
lean_object* v_reuseFailAlloc_550_; 
v_reuseFailAlloc_550_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_550_, 0, v_a_544_);
v___x_549_ = v_reuseFailAlloc_550_;
goto v_reusejp_548_;
}
v_reusejp_548_:
{
return v___x_549_;
}
}
}
}
}
else
{
lean_object* v_a_553_; lean_object* v___x_555_; uint8_t v_isShared_556_; uint8_t v_isSharedCheck_560_; 
lean_dec_ref(v_closure_439_);
lean_dec_ref(v_policy_438_);
lean_dec_ref(v_constants_437_);
lean_dec(v_a_433_);
lean_dec_ref(v_target_426_);
lean_del_object(v___x_420_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_553_ = lean_ctor_get(v___x_441_, 0);
v_isSharedCheck_560_ = !lean_is_exclusive(v___x_441_);
if (v_isSharedCheck_560_ == 0)
{
v___x_555_ = v___x_441_;
v_isShared_556_ = v_isSharedCheck_560_;
goto v_resetjp_554_;
}
else
{
lean_inc(v_a_553_);
lean_dec(v___x_441_);
v___x_555_ = lean_box(0);
v_isShared_556_ = v_isSharedCheck_560_;
goto v_resetjp_554_;
}
v_resetjp_554_:
{
lean_object* v___x_558_; 
if (v_isShared_556_ == 0)
{
v___x_558_ = v___x_555_;
goto v_reusejp_557_;
}
else
{
lean_object* v_reuseFailAlloc_559_; 
v_reuseFailAlloc_559_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_559_, 0, v_a_553_);
v___x_558_ = v_reuseFailAlloc_559_;
goto v_reusejp_557_;
}
v_reusejp_557_:
{
return v___x_558_;
}
}
}
}
else
{
lean_object* v_a_561_; lean_object* v___x_563_; uint8_t v_isShared_564_; uint8_t v_isSharedCheck_568_; 
lean_dec_ref(v_target_426_);
lean_del_object(v___x_420_);
lean_dec_ref(v_constMap_409_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_561_ = lean_ctor_get(v___x_432_, 0);
v_isSharedCheck_568_ = !lean_is_exclusive(v___x_432_);
if (v_isSharedCheck_568_ == 0)
{
v___x_563_ = v___x_432_;
v_isShared_564_ = v_isSharedCheck_568_;
goto v_resetjp_562_;
}
else
{
lean_inc(v_a_561_);
lean_dec(v___x_432_);
v___x_563_ = lean_box(0);
v_isShared_564_ = v_isSharedCheck_568_;
goto v_resetjp_562_;
}
v_resetjp_562_:
{
lean_object* v___x_566_; 
if (v_isShared_564_ == 0)
{
v___x_566_ = v___x_563_;
goto v_reusejp_565_;
}
else
{
lean_object* v_reuseFailAlloc_567_; 
v_reuseFailAlloc_567_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_567_, 0, v_a_561_);
v___x_566_ = v_reuseFailAlloc_567_;
goto v_reusejp_565_;
}
v_reusejp_565_:
{
return v___x_566_;
}
}
}
}
else
{
lean_object* v_a_569_; lean_object* v___x_571_; uint8_t v_isShared_572_; uint8_t v_isSharedCheck_576_; 
lean_dec_ref(v_target_426_);
lean_dec(v_a_423_);
lean_del_object(v___x_420_);
lean_dec(v_a_412_);
lean_dec_ref(v_constMap_409_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_569_ = lean_ctor_get(v___x_429_, 0);
v_isSharedCheck_576_ = !lean_is_exclusive(v___x_429_);
if (v_isSharedCheck_576_ == 0)
{
v___x_571_ = v___x_429_;
v_isShared_572_ = v_isSharedCheck_576_;
goto v_resetjp_570_;
}
else
{
lean_inc(v_a_569_);
lean_dec(v___x_429_);
v___x_571_ = lean_box(0);
v_isShared_572_ = v_isSharedCheck_576_;
goto v_resetjp_570_;
}
v_resetjp_570_:
{
lean_object* v___x_574_; 
if (v_isShared_572_ == 0)
{
v___x_574_ = v___x_571_;
goto v_reusejp_573_;
}
else
{
lean_object* v_reuseFailAlloc_575_; 
v_reuseFailAlloc_575_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_575_, 0, v_a_569_);
v___x_574_ = v_reuseFailAlloc_575_;
goto v_reusejp_573_;
}
v_reusejp_573_:
{
return v___x_574_;
}
}
}
}
else
{
lean_object* v_a_577_; lean_object* v___x_579_; uint8_t v_isShared_580_; uint8_t v_isSharedCheck_584_; 
lean_del_object(v___x_420_);
lean_dec(v_a_412_);
lean_dec_ref(v_constMap_409_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_577_ = lean_ctor_get(v___x_422_, 0);
v_isSharedCheck_584_ = !lean_is_exclusive(v___x_422_);
if (v_isSharedCheck_584_ == 0)
{
v___x_579_ = v___x_422_;
v_isShared_580_ = v_isSharedCheck_584_;
goto v_resetjp_578_;
}
else
{
lean_inc(v_a_577_);
lean_dec(v___x_422_);
v___x_579_ = lean_box(0);
v_isShared_580_ = v_isSharedCheck_584_;
goto v_resetjp_578_;
}
v_resetjp_578_:
{
lean_object* v___x_582_; 
if (v_isShared_580_ == 0)
{
v___x_582_ = v___x_579_;
goto v_reusejp_581_;
}
else
{
lean_object* v_reuseFailAlloc_583_; 
v_reuseFailAlloc_583_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_583_, 0, v_a_577_);
v___x_582_ = v_reuseFailAlloc_583_;
goto v_reusejp_581_;
}
v_reusejp_581_:
{
return v___x_582_;
}
}
}
}
}
else
{
lean_dec(v_a_412_);
lean_dec_ref(v_constMap_409_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_397_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
return v___x_417_;
}
}
else
{
lean_object* v_a_586_; lean_object* v___x_588_; uint8_t v_isShared_589_; uint8_t v_isSharedCheck_593_; 
lean_dec(v_a_412_);
lean_dec_ref(v_constMap_409_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_397_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
v_a_586_ = lean_ctor_get(v___x_415_, 0);
v_isSharedCheck_593_ = !lean_is_exclusive(v___x_415_);
if (v_isSharedCheck_593_ == 0)
{
v___x_588_ = v___x_415_;
v_isShared_589_ = v_isSharedCheck_593_;
goto v_resetjp_587_;
}
else
{
lean_inc(v_a_586_);
lean_dec(v___x_415_);
v___x_588_ = lean_box(0);
v_isShared_589_ = v_isSharedCheck_593_;
goto v_resetjp_587_;
}
v_resetjp_587_:
{
lean_object* v___x_591_; 
if (v_isShared_589_ == 0)
{
v___x_591_ = v___x_588_;
goto v_reusejp_590_;
}
else
{
lean_object* v_reuseFailAlloc_592_; 
v_reuseFailAlloc_592_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_592_, 0, v_a_586_);
v___x_591_ = v_reuseFailAlloc_592_;
goto v_reusejp_590_;
}
v_reusejp_590_:
{
return v___x_591_;
}
}
}
}
else
{
lean_object* v_a_594_; lean_object* v___x_596_; uint8_t v_isShared_597_; uint8_t v_isSharedCheck_601_; 
lean_dec_ref(v_constMap_409_);
lean_dec_ref(v_constMap_408_);
lean_del_object(v___x_406_);
lean_del_object(v___x_402_);
lean_dec(v_a_397_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_594_ = lean_ctor_get(v___x_411_, 0);
v_isSharedCheck_601_ = !lean_is_exclusive(v___x_411_);
if (v_isSharedCheck_601_ == 0)
{
v___x_596_ = v___x_411_;
v_isShared_597_ = v_isSharedCheck_601_;
goto v_resetjp_595_;
}
else
{
lean_inc(v_a_594_);
lean_dec(v___x_411_);
v___x_596_ = lean_box(0);
v_isShared_597_ = v_isSharedCheck_601_;
goto v_resetjp_595_;
}
v_resetjp_595_:
{
lean_object* v___x_599_; 
if (v_isShared_597_ == 0)
{
v___x_599_ = v___x_596_;
goto v_reusejp_598_;
}
else
{
lean_object* v_reuseFailAlloc_600_; 
v_reuseFailAlloc_600_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_600_, 0, v_a_594_);
v___x_599_ = v_reuseFailAlloc_600_;
goto v_reusejp_598_;
}
v_reusejp_598_:
{
return v___x_599_;
}
}
}
}
}
}
else
{
lean_object* v_a_606_; lean_object* v___x_608_; uint8_t v_isShared_609_; uint8_t v_isSharedCheck_613_; 
lean_dec(v_a_391_);
lean_dec(v_a_386_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_606_ = lean_ctor_get(v___x_396_, 0);
v_isSharedCheck_613_ = !lean_is_exclusive(v___x_396_);
if (v_isSharedCheck_613_ == 0)
{
v___x_608_ = v___x_396_;
v_isShared_609_ = v_isSharedCheck_613_;
goto v_resetjp_607_;
}
else
{
lean_inc(v_a_606_);
lean_dec(v___x_396_);
v___x_608_ = lean_box(0);
v_isShared_609_ = v_isSharedCheck_613_;
goto v_resetjp_607_;
}
v_resetjp_607_:
{
lean_object* v___x_611_; 
if (v_isShared_609_ == 0)
{
v___x_611_ = v___x_608_;
goto v_reusejp_610_;
}
else
{
lean_object* v_reuseFailAlloc_612_; 
v_reuseFailAlloc_612_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_612_, 0, v_a_606_);
v___x_611_ = v_reuseFailAlloc_612_;
goto v_reusejp_610_;
}
v_reusejp_610_:
{
return v___x_611_;
}
}
}
}
else
{
lean_object* v_a_614_; lean_object* v___x_616_; uint8_t v_isShared_617_; uint8_t v_isSharedCheck_621_; 
lean_dec(v_a_391_);
lean_dec(v_a_386_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_614_ = lean_ctor_get(v___x_394_, 0);
v_isSharedCheck_621_ = !lean_is_exclusive(v___x_394_);
if (v_isSharedCheck_621_ == 0)
{
v___x_616_ = v___x_394_;
v_isShared_617_ = v_isSharedCheck_621_;
goto v_resetjp_615_;
}
else
{
lean_inc(v_a_614_);
lean_dec(v___x_394_);
v___x_616_ = lean_box(0);
v_isShared_617_ = v_isSharedCheck_621_;
goto v_resetjp_615_;
}
v_resetjp_615_:
{
lean_object* v___x_619_; 
if (v_isShared_617_ == 0)
{
v___x_619_ = v___x_616_;
goto v_reusejp_618_;
}
else
{
lean_object* v_reuseFailAlloc_620_; 
v_reuseFailAlloc_620_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_620_, 0, v_a_614_);
v___x_619_ = v_reuseFailAlloc_620_;
goto v_reusejp_618_;
}
v_reusejp_618_:
{
return v___x_619_;
}
}
}
}
else
{
lean_object* v_a_622_; lean_object* v___x_624_; uint8_t v_isShared_625_; uint8_t v_isSharedCheck_629_; 
lean_dec(v_a_386_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_622_ = lean_ctor_get(v___x_390_, 0);
v_isSharedCheck_629_ = !lean_is_exclusive(v___x_390_);
if (v_isSharedCheck_629_ == 0)
{
v___x_624_ = v___x_390_;
v_isShared_625_ = v_isSharedCheck_629_;
goto v_resetjp_623_;
}
else
{
lean_inc(v_a_622_);
lean_dec(v___x_390_);
v___x_624_ = lean_box(0);
v_isShared_625_ = v_isSharedCheck_629_;
goto v_resetjp_623_;
}
v_resetjp_623_:
{
lean_object* v___x_627_; 
if (v_isShared_625_ == 0)
{
v___x_627_ = v___x_624_;
goto v_reusejp_626_;
}
else
{
lean_object* v_reuseFailAlloc_628_; 
v_reuseFailAlloc_628_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_628_, 0, v_a_622_);
v___x_627_ = v_reuseFailAlloc_628_;
goto v_reusejp_626_;
}
v_reusejp_626_:
{
return v___x_627_;
}
}
}
}
else
{
lean_object* v_a_630_; lean_object* v___x_632_; uint8_t v_isShared_633_; uint8_t v_isSharedCheck_637_; 
lean_dec(v_a_386_);
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_630_ = lean_ctor_get(v___x_388_, 0);
v_isSharedCheck_637_ = !lean_is_exclusive(v___x_388_);
if (v_isSharedCheck_637_ == 0)
{
v___x_632_ = v___x_388_;
v_isShared_633_ = v_isSharedCheck_637_;
goto v_resetjp_631_;
}
else
{
lean_inc(v_a_630_);
lean_dec(v___x_388_);
v___x_632_ = lean_box(0);
v_isShared_633_ = v_isSharedCheck_637_;
goto v_resetjp_631_;
}
v_resetjp_631_:
{
lean_object* v___x_635_; 
if (v_isShared_633_ == 0)
{
v___x_635_ = v___x_632_;
goto v_reusejp_634_;
}
else
{
lean_object* v_reuseFailAlloc_636_; 
v_reuseFailAlloc_636_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_636_, 0, v_a_630_);
v___x_635_ = v_reuseFailAlloc_636_;
goto v_reusejp_634_;
}
v_reusejp_634_:
{
return v___x_635_;
}
}
}
}
else
{
lean_object* v_a_638_; lean_object* v___x_640_; uint8_t v_isShared_641_; uint8_t v_isSharedCheck_645_; 
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_638_ = lean_ctor_get(v___x_385_, 0);
v_isSharedCheck_645_ = !lean_is_exclusive(v___x_385_);
if (v_isSharedCheck_645_ == 0)
{
v___x_640_ = v___x_385_;
v_isShared_641_ = v_isSharedCheck_645_;
goto v_resetjp_639_;
}
else
{
lean_inc(v_a_638_);
lean_dec(v___x_385_);
v___x_640_ = lean_box(0);
v_isShared_641_ = v_isSharedCheck_645_;
goto v_resetjp_639_;
}
v_resetjp_639_:
{
lean_object* v___x_643_; 
if (v_isShared_641_ == 0)
{
v___x_643_ = v___x_640_;
goto v_reusejp_642_;
}
else
{
lean_object* v_reuseFailAlloc_644_; 
v_reuseFailAlloc_644_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_644_, 0, v_a_638_);
v___x_643_ = v_reuseFailAlloc_644_;
goto v_reusejp_642_;
}
v_reusejp_642_:
{
return v___x_643_;
}
}
}
}
else
{
lean_object* v_a_646_; lean_object* v___x_648_; uint8_t v_isShared_649_; uint8_t v_isSharedCheck_653_; 
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_646_ = lean_ctor_get(v___x_383_, 0);
v_isSharedCheck_653_ = !lean_is_exclusive(v___x_383_);
if (v_isSharedCheck_653_ == 0)
{
v___x_648_ = v___x_383_;
v_isShared_649_ = v_isSharedCheck_653_;
goto v_resetjp_647_;
}
else
{
lean_inc(v_a_646_);
lean_dec(v___x_383_);
v___x_648_ = lean_box(0);
v_isShared_649_ = v_isSharedCheck_653_;
goto v_resetjp_647_;
}
v_resetjp_647_:
{
lean_object* v___x_651_; 
if (v_isShared_649_ == 0)
{
v___x_651_ = v___x_648_;
goto v_reusejp_650_;
}
else
{
lean_object* v_reuseFailAlloc_652_; 
v_reuseFailAlloc_652_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_652_, 0, v_a_646_);
v___x_651_ = v_reuseFailAlloc_652_;
goto v_reusejp_650_;
}
v_reusejp_650_:
{
return v___x_651_;
}
}
}
}
else
{
lean_object* v_a_654_; lean_object* v___x_656_; uint8_t v_isShared_657_; uint8_t v_isSharedCheck_661_; 
lean_dec(v_a_158_);
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_654_ = lean_ctor_get(v___x_381_, 0);
v_isSharedCheck_661_ = !lean_is_exclusive(v___x_381_);
if (v_isSharedCheck_661_ == 0)
{
v___x_656_ = v___x_381_;
v_isShared_657_ = v_isSharedCheck_661_;
goto v_resetjp_655_;
}
else
{
lean_inc(v_a_654_);
lean_dec(v___x_381_);
v___x_656_ = lean_box(0);
v_isShared_657_ = v_isSharedCheck_661_;
goto v_resetjp_655_;
}
v_resetjp_655_:
{
lean_object* v___x_659_; 
if (v_isShared_657_ == 0)
{
v___x_659_ = v___x_656_;
goto v_reusejp_658_;
}
else
{
lean_object* v_reuseFailAlloc_660_; 
v_reuseFailAlloc_660_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_660_, 0, v_a_654_);
v___x_659_ = v_reuseFailAlloc_660_;
goto v_reusejp_658_;
}
v_reusejp_658_:
{
return v___x_659_;
}
}
}
}
}
else
{
lean_object* v___x_662_; lean_object* v___x_663_; lean_object* v___x_664_; lean_object* v___x_665_; lean_object* v___x_666_; 
lean_del_object(v___x_160_);
lean_dec_ref(v_out_141_);
v___x_662_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__30));
v___x_663_ = lean_box(0);
v___x_664_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__55));
lean_inc(v_request_140_);
v___x_665_ = lp_proofEnvironment_OCMEnvironment_keys(v_request_140_, v___x_664_);
v___x_666_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_665_);
if (lean_obj_tag(v___x_666_) == 0)
{
lean_object* v___x_667_; lean_object* v___x_668_; 
lean_dec_ref_known(v___x_666_, 1);
v___x_667_ = lean_st_ref_set(v_phase_142_, v___x_662_);
v___x_668_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_pathField(v_request_140_, v___x_662_);
if (lean_obj_tag(v___x_668_) == 0)
{
lean_object* v_a_669_; uint8_t v___x_670_; lean_object* v___x_671_; 
v_a_669_ = lean_ctor_get(v___x_668_, 0);
lean_inc(v_a_669_);
lean_dec_ref_known(v___x_668_, 1);
v___x_670_ = 0;
v___x_671_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_a_669_, v___x_670_);
lean_dec(v_a_669_);
if (lean_obj_tag(v___x_671_) == 0)
{
lean_object* v_a_672_; lean_object* v___x_674_; uint8_t v_isShared_675_; uint8_t v_isSharedCheck_721_; 
v_a_672_ = lean_ctor_get(v___x_671_, 0);
v_isSharedCheck_721_ = !lean_is_exclusive(v___x_671_);
if (v_isSharedCheck_721_ == 0)
{
v___x_674_ = v___x_671_;
v_isShared_675_ = v_isSharedCheck_721_;
goto v_resetjp_673_;
}
else
{
lean_inc(v_a_672_);
lean_dec(v___x_671_);
v___x_674_ = lean_box(0);
v_isShared_675_ = v_isSharedCheck_721_;
goto v_resetjp_673_;
}
v_resetjp_673_:
{
lean_object* v_state_676_; lean_object* v_exprMap_677_; lean_object* v_rows_678_; lean_object* v___x_680_; uint8_t v_isShared_681_; uint8_t v_isSharedCheck_719_; 
v_state_676_ = lean_ctor_get(v_a_672_, 0);
lean_inc_ref(v_state_676_);
v_exprMap_677_ = lean_ctor_get(v_state_676_, 3);
lean_inc_ref(v_exprMap_677_);
v_rows_678_ = lean_ctor_get(v_a_672_, 1);
v_isSharedCheck_719_ = !lean_is_exclusive(v_a_672_);
if (v_isSharedCheck_719_ == 0)
{
lean_object* v_unused_720_; 
v_unused_720_ = lean_ctor_get(v_a_672_, 0);
lean_dec(v_unused_720_);
v___x_680_ = v_a_672_;
v_isShared_681_ = v_isSharedCheck_719_;
goto v_resetjp_679_;
}
else
{
lean_inc(v_rows_678_);
lean_dec(v_a_672_);
v___x_680_ = lean_box(0);
v_isShared_681_ = v_isSharedCheck_719_;
goto v_resetjp_679_;
}
v_resetjp_679_:
{
lean_object* v_constOrder_682_; lean_object* v_size_683_; lean_object* v___x_685_; uint8_t v_isShared_686_; uint8_t v_isSharedCheck_717_; 
v_constOrder_682_ = lean_ctor_get(v_state_676_, 6);
lean_inc_ref(v_constOrder_682_);
lean_dec_ref(v_state_676_);
v_size_683_ = lean_ctor_get(v_exprMap_677_, 0);
v_isSharedCheck_717_ = !lean_is_exclusive(v_exprMap_677_);
if (v_isSharedCheck_717_ == 0)
{
lean_object* v_unused_718_; 
v_unused_718_ = lean_ctor_get(v_exprMap_677_, 1);
lean_dec(v_unused_718_);
v___x_685_ = v_exprMap_677_;
v_isShared_686_ = v_isSharedCheck_717_;
goto v_resetjp_684_;
}
else
{
lean_inc(v_size_683_);
lean_dec(v_exprMap_677_);
v___x_685_ = lean_box(0);
v_isShared_686_ = v_isSharedCheck_717_;
goto v_resetjp_684_;
}
v_resetjp_684_:
{
lean_object* v___x_687_; lean_object* v___x_688_; lean_object* v___x_689_; lean_object* v___x_690_; lean_object* v___x_691_; lean_object* v___x_692_; lean_object* v___x_693_; lean_object* v___x_695_; 
v___x_687_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__56));
v___x_688_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__57));
v___x_689_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__58));
v___x_690_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__59));
v___x_691_ = lean_array_get_size(v_constOrder_682_);
v___x_692_ = l_Lean_JsonNumber_fromNat(v___x_691_);
v___x_693_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_693_, 0, v___x_692_);
if (v_isShared_686_ == 0)
{
lean_ctor_set(v___x_685_, 1, v___x_693_);
lean_ctor_set(v___x_685_, 0, v___x_690_);
v___x_695_ = v___x_685_;
goto v_reusejp_694_;
}
else
{
lean_object* v_reuseFailAlloc_716_; 
v_reuseFailAlloc_716_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_716_, 0, v___x_690_);
lean_ctor_set(v_reuseFailAlloc_716_, 1, v___x_693_);
v___x_695_ = v_reuseFailAlloc_716_;
goto v_reusejp_694_;
}
v_reusejp_694_:
{
lean_object* v___x_696_; lean_object* v___x_697_; lean_object* v___x_698_; lean_object* v___x_700_; 
v___x_696_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__60));
v___x_697_ = l_Lean_JsonNumber_fromNat(v_size_683_);
v___x_698_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_698_, 0, v___x_697_);
if (v_isShared_681_ == 0)
{
lean_ctor_set(v___x_680_, 1, v___x_698_);
lean_ctor_set(v___x_680_, 0, v___x_696_);
v___x_700_ = v___x_680_;
goto v_reusejp_699_;
}
else
{
lean_object* v_reuseFailAlloc_715_; 
v_reuseFailAlloc_715_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_715_, 0, v___x_696_);
lean_ctor_set(v_reuseFailAlloc_715_, 1, v___x_698_);
v___x_700_ = v_reuseFailAlloc_715_;
goto v_reusejp_699_;
}
v_reusejp_699_:
{
lean_object* v___x_701_; lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; lean_object* v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_713_; 
v___x_701_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__61));
v___x_702_ = l_Lean_JsonNumber_fromNat(v_rows_678_);
v___x_703_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_703_, 0, v___x_702_);
v___x_704_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_704_, 0, v___x_701_);
lean_ctor_set(v___x_704_, 1, v___x_703_);
v___x_705_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_705_, 0, v___x_704_);
lean_ctor_set(v___x_705_, 1, v___x_663_);
v___x_706_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_706_, 0, v___x_700_);
lean_ctor_set(v___x_706_, 1, v___x_705_);
v___x_707_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_707_, 0, v___x_695_);
lean_ctor_set(v___x_707_, 1, v___x_706_);
v___x_708_ = l_Lean_Json_mkObj(v___x_707_);
lean_dec_ref_known(v___x_707_, 2);
v___x_709_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__62));
v___x_710_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__63));
v___x_711_ = lp_proofEnvironment_OCMEnvironment_result(v_a_158_, v___x_687_, v___x_688_, v___x_689_, v___x_708_, v_constOrder_682_, v___x_709_, v___x_710_);
if (v_isShared_675_ == 0)
{
lean_ctor_set(v___x_674_, 0, v___x_711_);
v___x_713_ = v___x_674_;
goto v_reusejp_712_;
}
else
{
lean_object* v_reuseFailAlloc_714_; 
v_reuseFailAlloc_714_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_714_, 0, v___x_711_);
v___x_713_ = v_reuseFailAlloc_714_;
goto v_reusejp_712_;
}
v_reusejp_712_:
{
return v___x_713_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_722_; lean_object* v___x_724_; uint8_t v_isShared_725_; uint8_t v_isSharedCheck_729_; 
lean_dec(v_a_158_);
v_a_722_ = lean_ctor_get(v___x_671_, 0);
v_isSharedCheck_729_ = !lean_is_exclusive(v___x_671_);
if (v_isSharedCheck_729_ == 0)
{
v___x_724_ = v___x_671_;
v_isShared_725_ = v_isSharedCheck_729_;
goto v_resetjp_723_;
}
else
{
lean_inc(v_a_722_);
lean_dec(v___x_671_);
v___x_724_ = lean_box(0);
v_isShared_725_ = v_isSharedCheck_729_;
goto v_resetjp_723_;
}
v_resetjp_723_:
{
lean_object* v___x_727_; 
if (v_isShared_725_ == 0)
{
v___x_727_ = v___x_724_;
goto v_reusejp_726_;
}
else
{
lean_object* v_reuseFailAlloc_728_; 
v_reuseFailAlloc_728_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_728_, 0, v_a_722_);
v___x_727_ = v_reuseFailAlloc_728_;
goto v_reusejp_726_;
}
v_reusejp_726_:
{
return v___x_727_;
}
}
}
}
else
{
lean_object* v_a_730_; lean_object* v___x_732_; uint8_t v_isShared_733_; uint8_t v_isSharedCheck_737_; 
lean_dec(v_a_158_);
v_a_730_ = lean_ctor_get(v___x_668_, 0);
v_isSharedCheck_737_ = !lean_is_exclusive(v___x_668_);
if (v_isSharedCheck_737_ == 0)
{
v___x_732_ = v___x_668_;
v_isShared_733_ = v_isSharedCheck_737_;
goto v_resetjp_731_;
}
else
{
lean_inc(v_a_730_);
lean_dec(v___x_668_);
v___x_732_ = lean_box(0);
v_isShared_733_ = v_isSharedCheck_737_;
goto v_resetjp_731_;
}
v_resetjp_731_:
{
lean_object* v___x_735_; 
if (v_isShared_733_ == 0)
{
v___x_735_ = v___x_732_;
goto v_reusejp_734_;
}
else
{
lean_object* v_reuseFailAlloc_736_; 
v_reuseFailAlloc_736_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_736_, 0, v_a_730_);
v___x_735_ = v_reuseFailAlloc_736_;
goto v_reusejp_734_;
}
v_reusejp_734_:
{
return v___x_735_;
}
}
}
}
else
{
lean_object* v_a_738_; lean_object* v___x_740_; uint8_t v_isShared_741_; uint8_t v_isSharedCheck_745_; 
lean_dec(v_a_158_);
lean_dec(v_request_140_);
v_a_738_ = lean_ctor_get(v___x_666_, 0);
v_isSharedCheck_745_ = !lean_is_exclusive(v___x_666_);
if (v_isSharedCheck_745_ == 0)
{
v___x_740_ = v___x_666_;
v_isShared_741_ = v_isSharedCheck_745_;
goto v_resetjp_739_;
}
else
{
lean_inc(v_a_738_);
lean_dec(v___x_666_);
v___x_740_ = lean_box(0);
v_isShared_741_ = v_isSharedCheck_745_;
goto v_resetjp_739_;
}
v_resetjp_739_:
{
lean_object* v___x_743_; 
if (v_isShared_741_ == 0)
{
v___x_743_ = v___x_740_;
goto v_reusejp_742_;
}
else
{
lean_object* v_reuseFailAlloc_744_; 
v_reuseFailAlloc_744_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_744_, 0, v_a_738_);
v___x_743_ = v_reuseFailAlloc_744_;
goto v_reusejp_742_;
}
v_reusejp_742_:
{
return v___x_743_;
}
}
}
}
}
}
else
{
lean_object* v_a_747_; lean_object* v___x_749_; uint8_t v_isShared_750_; uint8_t v_isSharedCheck_754_; 
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_747_ = lean_ctor_get(v___x_157_, 0);
v_isSharedCheck_754_ = !lean_is_exclusive(v___x_157_);
if (v_isSharedCheck_754_ == 0)
{
v___x_749_ = v___x_157_;
v_isShared_750_ = v_isSharedCheck_754_;
goto v_resetjp_748_;
}
else
{
lean_inc(v_a_747_);
lean_dec(v___x_157_);
v___x_749_ = lean_box(0);
v_isShared_750_ = v_isSharedCheck_754_;
goto v_resetjp_748_;
}
v_resetjp_748_:
{
lean_object* v___x_752_; 
if (v_isShared_750_ == 0)
{
v___x_752_ = v___x_749_;
goto v_reusejp_751_;
}
else
{
lean_object* v_reuseFailAlloc_753_; 
v_reuseFailAlloc_753_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_753_, 0, v_a_747_);
v___x_752_ = v_reuseFailAlloc_753_;
goto v_reusejp_751_;
}
v_reusejp_751_:
{
return v___x_752_;
}
}
}
}
}
}
else
{
lean_object* v_a_756_; lean_object* v___x_758_; uint8_t v_isShared_759_; uint8_t v_isSharedCheck_763_; 
lean_dec_ref(v_out_141_);
lean_dec(v_request_140_);
v_a_756_ = lean_ctor_get(v___x_145_, 0);
v_isSharedCheck_763_ = !lean_is_exclusive(v___x_145_);
if (v_isSharedCheck_763_ == 0)
{
v___x_758_ = v___x_145_;
v_isShared_759_ = v_isSharedCheck_763_;
goto v_resetjp_757_;
}
else
{
lean_inc(v_a_756_);
lean_dec(v___x_145_);
v___x_758_ = lean_box(0);
v_isShared_759_ = v_isSharedCheck_763_;
goto v_resetjp_757_;
}
v_resetjp_757_:
{
lean_object* v___x_761_; 
if (v_isShared_759_ == 0)
{
v___x_761_ = v___x_758_;
goto v_reusejp_760_;
}
else
{
lean_object* v_reuseFailAlloc_762_; 
v_reuseFailAlloc_762_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_762_, 0, v_a_756_);
v___x_761_ = v_reuseFailAlloc_762_;
goto v_reusejp_760_;
}
v_reusejp_760_:
{
return v___x_761_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___boxed(lean_object* v_request_764_, lean_object* v_out_765_, lean_object* v_phase_766_, lean_object* v_a_767_){
_start:
{
lean_object* v_res_768_; 
v_res_768_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation(v_request_764_, v_out_765_, v_phase_766_);
lean_dec(v_phase_766_);
return v_res_768_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__0(size_t v_sz_769_, size_t v_i_770_, lean_object* v_bs_771_){
_start:
{
uint8_t v___x_772_; 
v___x_772_ = lean_usize_dec_lt(v_i_770_, v_sz_769_);
if (v___x_772_ == 0)
{
return v_bs_771_;
}
else
{
lean_object* v_v_773_; lean_object* v_fileName_774_; lean_object* v___x_775_; lean_object* v_bs_x27_776_; size_t v___x_777_; size_t v___x_778_; lean_object* v___x_779_; 
v_v_773_ = lean_array_uget_borrowed(v_bs_771_, v_i_770_);
v_fileName_774_ = lean_ctor_get(v_v_773_, 1);
lean_inc_ref(v_fileName_774_);
v___x_775_ = lean_unsigned_to_nat(0u);
v_bs_x27_776_ = lean_array_uset(v_bs_771_, v_i_770_, v___x_775_);
v___x_777_ = ((size_t)1ULL);
v___x_778_ = lean_usize_add(v_i_770_, v___x_777_);
v___x_779_ = lean_array_uset(v_bs_x27_776_, v_i_770_, v_fileName_774_);
v_i_770_ = v___x_778_;
v_bs_771_ = v___x_779_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__0___boxed(lean_object* v_sz_781_, lean_object* v_i_782_, lean_object* v_bs_783_){
_start:
{
size_t v_sz_boxed_784_; size_t v_i_boxed_785_; lean_object* v_res_786_; 
v_sz_boxed_784_ = lean_unbox_usize(v_sz_781_);
lean_dec(v_sz_781_);
v_i_boxed_785_ = lean_unbox_usize(v_i_782_);
lean_dec(v_i_782_);
v_res_786_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__0(v_sz_boxed_784_, v_i_boxed_785_, v_bs_783_);
return v_res_786_;
}
}
static lean_object* _init_lp_proofEnvironment_main___closed__3(void){
_start:
{
lean_object* v___x_790_; lean_object* v___x_791_; 
v___x_790_ = lean_box(0);
v___x_791_ = l_Lean_Json_mkObj(v___x_790_);
return v___x_791_;
}
}
static lean_object* _init_lp_proofEnvironment_main___boxed__const__1(void){
_start:
{
uint32_t v___x_793_; lean_object* v___x_794_; 
v___x_793_ = 2;
v___x_794_ = lean_box_uint32(v___x_793_);
return v___x_794_;
}
}
static lean_object* _init_lp_proofEnvironment_main___boxed__const__2(void){
_start:
{
uint32_t v___x_795_; lean_object* v___x_796_; 
v___x_795_ = 0;
v___x_796_ = lean_box_uint32(v___x_795_);
return v___x_796_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_797_){
_start:
{
if (lean_obj_tag(v_args_797_) == 1)
{
lean_object* v_tail_819_; 
v_tail_819_ = lean_ctor_get(v_args_797_, 1);
lean_inc(v_tail_819_);
if (lean_obj_tag(v_tail_819_) == 1)
{
lean_object* v_head_820_; lean_object* v_head_821_; lean_object* v_tail_822_; lean_object* v_a_824_; 
v_head_820_ = lean_ctor_get(v_args_797_, 0);
lean_inc(v_head_820_);
lean_dec_ref_known(v_args_797_, 2);
v_head_821_ = lean_ctor_get(v_tail_819_, 0);
lean_inc(v_head_821_);
v_tail_822_ = lean_ctor_get(v_tail_819_, 1);
lean_inc(v_tail_822_);
lean_dec_ref_known(v_tail_819_, 2);
if (lean_obj_tag(v_tail_822_) == 0)
{
uint8_t v___x_855_; 
v___x_855_ = l_System_FilePath_pathExists(v_head_821_);
if (v___x_855_ == 0)
{
lean_object* v___x_856_; 
v___x_856_ = lean_io_create_dir(v_head_821_);
if (lean_obj_tag(v___x_856_) == 0)
{
lean_object* v___x_857_; lean_object* v___x_858_; lean_object* v___x_859_; lean_object* v___x_860_; lean_object* v___y_862_; lean_object* v___y_863_; lean_object* v___y_874_; lean_object* v___y_875_; lean_object* v___y_876_; lean_object* v___y_877_; lean_object* v___y_878_; lean_object* v___y_881_; lean_object* v___y_882_; lean_object* v___y_883_; lean_object* v___y_884_; lean_object* v___y_885_; lean_object* v_a_888_; lean_object* v___y_909_; lean_object* v___x_912_; 
lean_dec_ref_known(v___x_856_, 1);
v___x_857_ = ((lean_object*)(lp_proofEnvironment_main___closed__1));
v___x_858_ = lean_st_mk_ref(v___x_857_);
v___x_859_ = ((lean_object*)(lp_proofEnvironment_main___closed__2));
v___x_860_ = lean_st_mk_ref(v___x_859_);
v___x_912_ = lp_proofEnvironment_OCMEnvironment_readJson(v_head_820_);
lean_dec(v_head_820_);
if (lean_obj_tag(v___x_912_) == 0)
{
lean_object* v_a_913_; lean_object* v___x_914_; lean_object* v___x_915_; 
v_a_913_ = lean_ctor_get(v___x_912_, 0);
lean_inc_n(v_a_913_, 2);
lean_dec_ref_known(v___x_912_, 1);
v___x_914_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__4));
v___x_915_ = lp_proofEnvironment_OCMEnvironment_getString(v_a_913_, v___x_914_);
if (lean_obj_tag(v___x_915_) == 0)
{
lean_object* v_a_916_; lean_object* v___x_917_; lean_object* v___x_918_; 
v_a_916_ = lean_ctor_get(v___x_915_, 0);
lean_inc(v_a_916_);
lean_dec_ref_known(v___x_915_, 1);
v___x_917_ = lean_st_ref_set(v___x_858_, v_a_916_);
lean_inc(v_head_821_);
v___x_918_ = lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation(v_a_913_, v_head_821_, v___x_860_);
v___y_909_ = v___x_918_;
goto v___jp_908_;
}
else
{
lean_object* v_a_919_; 
lean_dec(v_a_913_);
v_a_919_ = lean_ctor_get(v___x_915_, 0);
lean_inc(v_a_919_);
lean_dec_ref_known(v___x_915_, 1);
v_a_888_ = v_a_919_;
goto v___jp_887_;
}
}
else
{
v___y_909_ = v___x_912_;
goto v___jp_908_;
}
v___jp_861_:
{
lean_object* v___x_864_; lean_object* v___x_865_; lean_object* v___x_866_; lean_object* v___x_867_; lean_object* v___x_868_; lean_object* v___x_869_; lean_object* v___x_870_; lean_object* v___x_871_; lean_object* v___x_872_; 
v___x_864_ = lean_st_ref_get(v___x_858_);
lean_dec(v___x_858_);
v___x_865_ = lean_st_ref_get(v___x_860_);
lean_dec(v___x_860_);
v___x_866_ = lean_io_error_to_string(v___y_862_);
v___x_867_ = lp_proofEnvironment_OCMEnvironment_refusalTerminal(v___x_866_);
v___x_868_ = lean_obj_once(&lp_proofEnvironment_main___closed__3, &lp_proofEnvironment_main___closed__3_once, _init_lp_proofEnvironment_main___closed__3);
v___x_869_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__62));
v___x_870_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51));
v___x_871_ = lean_array_push(v___y_863_, v___x_870_);
v___x_872_ = lp_proofEnvironment_OCMEnvironment_result(v___x_864_, v___x_867_, v___x_865_, v___x_866_, v___x_868_, v___x_869_, v___x_869_, v___x_871_);
v_a_824_ = v___x_872_;
goto v___jp_823_;
}
v___jp_873_:
{
lean_object* v___x_879_; 
v___x_879_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_validateCat_spec__3___redArg(v___y_877_, v___y_876_, v___y_874_, v___y_878_);
lean_dec(v___y_878_);
lean_dec(v___y_877_);
v___y_862_ = v___y_875_;
v___y_863_ = v___x_879_;
goto v___jp_861_;
}
v___jp_880_:
{
uint8_t v___x_886_; 
v___x_886_ = lean_nat_dec_le(v___y_885_, v___y_881_);
if (v___x_886_ == 0)
{
lean_dec(v___y_881_);
lean_inc(v___y_885_);
v___y_874_ = v___y_885_;
v___y_875_ = v___y_882_;
v___y_876_ = v___y_883_;
v___y_877_ = v___y_884_;
v___y_878_ = v___y_885_;
goto v___jp_873_;
}
else
{
v___y_874_ = v___y_885_;
v___y_875_ = v___y_882_;
v___y_876_ = v___y_883_;
v___y_877_ = v___y_884_;
v___y_878_ = v___y_881_;
goto v___jp_873_;
}
}
v___jp_887_:
{
lean_object* v___x_889_; 
v___x_889_ = lean_io_read_dir(v_head_821_);
if (lean_obj_tag(v___x_889_) == 0)
{
lean_object* v_a_890_; size_t v_sz_891_; size_t v___x_892_; lean_object* v___x_893_; lean_object* v___x_894_; lean_object* v___x_895_; uint8_t v___x_896_; 
v_a_890_ = lean_ctor_get(v___x_889_, 0);
lean_inc(v_a_890_);
lean_dec_ref_known(v___x_889_, 1);
v_sz_891_ = lean_array_size(v_a_890_);
v___x_892_ = ((size_t)0ULL);
v___x_893_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__0(v_sz_891_, v___x_892_, v_a_890_);
v___x_894_ = lean_array_get_size(v___x_893_);
v___x_895_ = lean_unsigned_to_nat(0u);
v___x_896_ = lean_nat_dec_eq(v___x_894_, v___x_895_);
if (v___x_896_ == 0)
{
lean_object* v___x_897_; lean_object* v___x_898_; uint8_t v___x_899_; 
v___x_897_ = lean_unsigned_to_nat(1u);
v___x_898_ = lean_nat_sub(v___x_894_, v___x_897_);
v___x_899_ = lean_nat_dec_le(v___x_895_, v___x_898_);
if (v___x_899_ == 0)
{
lean_inc(v___x_898_);
v___y_881_ = v___x_898_;
v___y_882_ = v_a_888_;
v___y_883_ = v___x_893_;
v___y_884_ = v___x_894_;
v___y_885_ = v___x_898_;
goto v___jp_880_;
}
else
{
v___y_881_ = v___x_898_;
v___y_882_ = v_a_888_;
v___y_883_ = v___x_893_;
v___y_884_ = v___x_894_;
v___y_885_ = v___x_895_;
goto v___jp_880_;
}
}
else
{
v___y_862_ = v_a_888_;
v___y_863_ = v___x_893_;
goto v___jp_861_;
}
}
else
{
lean_object* v_a_900_; lean_object* v___x_902_; uint8_t v_isShared_903_; uint8_t v_isSharedCheck_907_; 
lean_dec(v_a_888_);
lean_dec(v___x_860_);
lean_dec(v___x_858_);
lean_dec(v_head_821_);
v_a_900_ = lean_ctor_get(v___x_889_, 0);
v_isSharedCheck_907_ = !lean_is_exclusive(v___x_889_);
if (v_isSharedCheck_907_ == 0)
{
v___x_902_ = v___x_889_;
v_isShared_903_ = v_isSharedCheck_907_;
goto v_resetjp_901_;
}
else
{
lean_inc(v_a_900_);
lean_dec(v___x_889_);
v___x_902_ = lean_box(0);
v_isShared_903_ = v_isSharedCheck_907_;
goto v_resetjp_901_;
}
v_resetjp_901_:
{
lean_object* v___x_905_; 
if (v_isShared_903_ == 0)
{
v___x_905_ = v___x_902_;
goto v_reusejp_904_;
}
else
{
lean_object* v_reuseFailAlloc_906_; 
v_reuseFailAlloc_906_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_906_, 0, v_a_900_);
v___x_905_ = v_reuseFailAlloc_906_;
goto v_reusejp_904_;
}
v_reusejp_904_:
{
return v___x_905_;
}
}
}
}
v___jp_908_:
{
if (lean_obj_tag(v___y_909_) == 0)
{
lean_object* v_a_910_; 
lean_dec(v___x_860_);
lean_dec(v___x_858_);
v_a_910_ = lean_ctor_get(v___y_909_, 0);
lean_inc(v_a_910_);
lean_dec_ref_known(v___y_909_, 1);
v_a_824_ = v_a_910_;
goto v___jp_823_;
}
else
{
lean_object* v_a_911_; 
v_a_911_ = lean_ctor_get(v___y_909_, 0);
lean_inc(v_a_911_);
lean_dec_ref_known(v___y_909_, 1);
v_a_888_ = v_a_911_;
goto v___jp_887_;
}
}
}
else
{
lean_object* v_a_920_; lean_object* v___x_922_; uint8_t v_isShared_923_; uint8_t v_isSharedCheck_927_; 
lean_dec(v_head_821_);
lean_dec(v_head_820_);
v_a_920_ = lean_ctor_get(v___x_856_, 0);
v_isSharedCheck_927_ = !lean_is_exclusive(v___x_856_);
if (v_isSharedCheck_927_ == 0)
{
v___x_922_ = v___x_856_;
v_isShared_923_ = v_isSharedCheck_927_;
goto v_resetjp_921_;
}
else
{
lean_inc(v_a_920_);
lean_dec(v___x_856_);
v___x_922_ = lean_box(0);
v_isShared_923_ = v_isSharedCheck_927_;
goto v_resetjp_921_;
}
v_resetjp_921_:
{
lean_object* v___x_925_; 
if (v_isShared_923_ == 0)
{
v___x_925_ = v___x_922_;
goto v_reusejp_924_;
}
else
{
lean_object* v_reuseFailAlloc_926_; 
v_reuseFailAlloc_926_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_926_, 0, v_a_920_);
v___x_925_ = v_reuseFailAlloc_926_;
goto v_reusejp_924_;
}
v_reusejp_924_:
{
return v___x_925_;
}
}
}
}
else
{
lean_object* v___x_928_; lean_object* v___x_929_; 
lean_dec(v_head_821_);
lean_dec(v_head_820_);
v___x_928_ = ((lean_object*)(lp_proofEnvironment_main___closed__4));
v___x_929_ = l_IO_eprintln___at___00__private_Lean_Shell_0__Lean_shellMain_spec__1(v___x_928_);
if (lean_obj_tag(v___x_929_) == 0)
{
lean_object* v___x_931_; uint8_t v_isShared_932_; uint8_t v_isSharedCheck_937_; 
v_isSharedCheck_937_ = !lean_is_exclusive(v___x_929_);
if (v_isSharedCheck_937_ == 0)
{
lean_object* v_unused_938_; 
v_unused_938_ = lean_ctor_get(v___x_929_, 0);
lean_dec(v_unused_938_);
v___x_931_ = v___x_929_;
v_isShared_932_ = v_isSharedCheck_937_;
goto v_resetjp_930_;
}
else
{
lean_dec(v___x_929_);
v___x_931_ = lean_box(0);
v_isShared_932_ = v_isSharedCheck_937_;
goto v_resetjp_930_;
}
v_resetjp_930_:
{
lean_object* v___x_933_; lean_object* v___x_935_; 
v___x_933_ = lp_proofEnvironment_main___boxed__const__1;
if (v_isShared_932_ == 0)
{
lean_ctor_set(v___x_931_, 0, v___x_933_);
v___x_935_ = v___x_931_;
goto v_reusejp_934_;
}
else
{
lean_object* v_reuseFailAlloc_936_; 
v_reuseFailAlloc_936_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_936_, 0, v___x_933_);
v___x_935_ = v_reuseFailAlloc_936_;
goto v_reusejp_934_;
}
v_reusejp_934_:
{
return v___x_935_;
}
}
}
else
{
lean_object* v_a_939_; lean_object* v___x_941_; uint8_t v_isShared_942_; uint8_t v_isSharedCheck_946_; 
v_a_939_ = lean_ctor_get(v___x_929_, 0);
v_isSharedCheck_946_ = !lean_is_exclusive(v___x_929_);
if (v_isSharedCheck_946_ == 0)
{
v___x_941_ = v___x_929_;
v_isShared_942_ = v_isSharedCheck_946_;
goto v_resetjp_940_;
}
else
{
lean_inc(v_a_939_);
lean_dec(v___x_929_);
v___x_941_ = lean_box(0);
v_isShared_942_ = v_isSharedCheck_946_;
goto v_resetjp_940_;
}
v_resetjp_940_:
{
lean_object* v___x_944_; 
if (v_isShared_942_ == 0)
{
v___x_944_ = v___x_941_;
goto v_reusejp_943_;
}
else
{
lean_object* v_reuseFailAlloc_945_; 
v_reuseFailAlloc_945_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_945_, 0, v_a_939_);
v___x_944_ = v_reuseFailAlloc_945_;
goto v_reusejp_943_;
}
v_reusejp_943_:
{
return v___x_944_;
}
}
}
}
}
else
{
lean_dec(v_tail_822_);
lean_dec(v_head_821_);
lean_dec(v_head_820_);
goto v___jp_799_;
}
v___jp_823_:
{
lean_object* v___x_825_; lean_object* v___x_826_; lean_object* v___x_827_; 
v___x_825_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Main_0__OCMEnvironment_operation___closed__51));
v___x_826_ = l_System_FilePath_join(v_head_821_, v___x_825_);
lean_inc(v_a_824_);
v___x_827_ = lp_proofEnvironment_OCMEnvironment_writeJson(v___x_826_, v_a_824_);
lean_dec_ref(v___x_826_);
if (lean_obj_tag(v___x_827_) == 0)
{
lean_object* v___x_828_; lean_object* v___x_829_; 
lean_dec_ref_known(v___x_827_, 1);
v___x_828_ = l_Lean_Json_compress(v_a_824_);
v___x_829_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_828_);
if (lean_obj_tag(v___x_829_) == 0)
{
lean_object* v___x_831_; uint8_t v_isShared_832_; uint8_t v_isSharedCheck_837_; 
v_isSharedCheck_837_ = !lean_is_exclusive(v___x_829_);
if (v_isSharedCheck_837_ == 0)
{
lean_object* v_unused_838_; 
v_unused_838_ = lean_ctor_get(v___x_829_, 0);
lean_dec(v_unused_838_);
v___x_831_ = v___x_829_;
v_isShared_832_ = v_isSharedCheck_837_;
goto v_resetjp_830_;
}
else
{
lean_dec(v___x_829_);
v___x_831_ = lean_box(0);
v_isShared_832_ = v_isSharedCheck_837_;
goto v_resetjp_830_;
}
v_resetjp_830_:
{
lean_object* v___x_833_; lean_object* v___x_835_; 
v___x_833_ = lp_proofEnvironment_main___boxed__const__2;
if (v_isShared_832_ == 0)
{
lean_ctor_set(v___x_831_, 0, v___x_833_);
v___x_835_ = v___x_831_;
goto v_reusejp_834_;
}
else
{
lean_object* v_reuseFailAlloc_836_; 
v_reuseFailAlloc_836_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_836_, 0, v___x_833_);
v___x_835_ = v_reuseFailAlloc_836_;
goto v_reusejp_834_;
}
v_reusejp_834_:
{
return v___x_835_;
}
}
}
else
{
lean_object* v_a_839_; lean_object* v___x_841_; uint8_t v_isShared_842_; uint8_t v_isSharedCheck_846_; 
v_a_839_ = lean_ctor_get(v___x_829_, 0);
v_isSharedCheck_846_ = !lean_is_exclusive(v___x_829_);
if (v_isSharedCheck_846_ == 0)
{
v___x_841_ = v___x_829_;
v_isShared_842_ = v_isSharedCheck_846_;
goto v_resetjp_840_;
}
else
{
lean_inc(v_a_839_);
lean_dec(v___x_829_);
v___x_841_ = lean_box(0);
v_isShared_842_ = v_isSharedCheck_846_;
goto v_resetjp_840_;
}
v_resetjp_840_:
{
lean_object* v___x_844_; 
if (v_isShared_842_ == 0)
{
v___x_844_ = v___x_841_;
goto v_reusejp_843_;
}
else
{
lean_object* v_reuseFailAlloc_845_; 
v_reuseFailAlloc_845_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_845_, 0, v_a_839_);
v___x_844_ = v_reuseFailAlloc_845_;
goto v_reusejp_843_;
}
v_reusejp_843_:
{
return v___x_844_;
}
}
}
}
else
{
lean_object* v_a_847_; lean_object* v___x_849_; uint8_t v_isShared_850_; uint8_t v_isSharedCheck_854_; 
lean_dec(v_a_824_);
v_a_847_ = lean_ctor_get(v___x_827_, 0);
v_isSharedCheck_854_ = !lean_is_exclusive(v___x_827_);
if (v_isSharedCheck_854_ == 0)
{
v___x_849_ = v___x_827_;
v_isShared_850_ = v_isSharedCheck_854_;
goto v_resetjp_848_;
}
else
{
lean_inc(v_a_847_);
lean_dec(v___x_827_);
v___x_849_ = lean_box(0);
v_isShared_850_ = v_isSharedCheck_854_;
goto v_resetjp_848_;
}
v_resetjp_848_:
{
lean_object* v___x_852_; 
if (v_isShared_850_ == 0)
{
v___x_852_ = v___x_849_;
goto v_reusejp_851_;
}
else
{
lean_object* v_reuseFailAlloc_853_; 
v_reuseFailAlloc_853_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_853_, 0, v_a_847_);
v___x_852_ = v_reuseFailAlloc_853_;
goto v_reusejp_851_;
}
v_reusejp_851_:
{
return v___x_852_;
}
}
}
}
}
else
{
lean_dec(v_tail_819_);
lean_dec_ref_known(v_args_797_, 2);
goto v___jp_799_;
}
}
else
{
lean_dec(v_args_797_);
goto v___jp_799_;
}
v___jp_799_:
{
lean_object* v___x_800_; lean_object* v___x_801_; 
v___x_800_ = ((lean_object*)(lp_proofEnvironment_main___closed__0));
v___x_801_ = l_IO_eprintln___at___00__private_Lean_Shell_0__Lean_shellMain_spec__1(v___x_800_);
if (lean_obj_tag(v___x_801_) == 0)
{
lean_object* v___x_803_; uint8_t v_isShared_804_; uint8_t v_isSharedCheck_809_; 
v_isSharedCheck_809_ = !lean_is_exclusive(v___x_801_);
if (v_isSharedCheck_809_ == 0)
{
lean_object* v_unused_810_; 
v_unused_810_ = lean_ctor_get(v___x_801_, 0);
lean_dec(v_unused_810_);
v___x_803_ = v___x_801_;
v_isShared_804_ = v_isSharedCheck_809_;
goto v_resetjp_802_;
}
else
{
lean_dec(v___x_801_);
v___x_803_ = lean_box(0);
v_isShared_804_ = v_isSharedCheck_809_;
goto v_resetjp_802_;
}
v_resetjp_802_:
{
lean_object* v___x_805_; lean_object* v___x_807_; 
v___x_805_ = lp_proofEnvironment_main___boxed__const__1;
if (v_isShared_804_ == 0)
{
lean_ctor_set(v___x_803_, 0, v___x_805_);
v___x_807_ = v___x_803_;
goto v_reusejp_806_;
}
else
{
lean_object* v_reuseFailAlloc_808_; 
v_reuseFailAlloc_808_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_808_, 0, v___x_805_);
v___x_807_ = v_reuseFailAlloc_808_;
goto v_reusejp_806_;
}
v_reusejp_806_:
{
return v___x_807_;
}
}
}
else
{
lean_object* v_a_811_; lean_object* v___x_813_; uint8_t v_isShared_814_; uint8_t v_isSharedCheck_818_; 
v_a_811_ = lean_ctor_get(v___x_801_, 0);
v_isSharedCheck_818_ = !lean_is_exclusive(v___x_801_);
if (v_isSharedCheck_818_ == 0)
{
v___x_813_ = v___x_801_;
v_isShared_814_ = v_isSharedCheck_818_;
goto v_resetjp_812_;
}
else
{
lean_inc(v_a_811_);
lean_dec(v___x_801_);
v___x_813_ = lean_box(0);
v_isShared_814_ = v_isSharedCheck_818_;
goto v_resetjp_812_;
}
v_resetjp_812_:
{
lean_object* v___x_816_; 
if (v_isShared_814_ == 0)
{
v___x_816_ = v___x_813_;
goto v_reusejp_815_;
}
else
{
lean_object* v_reuseFailAlloc_817_; 
v_reuseFailAlloc_817_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_817_, 0, v_a_811_);
v___x_816_ = v_reuseFailAlloc_817_;
goto v_reusejp_815_;
}
v_reusejp_815_:
{
return v___x_816_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_main___boxed(lean_object* v_args_947_, lean_object* v_a_948_){
_start:
{
lean_object* v_res_949_; 
v_res_949_ = _lean_main(v_args_947_);
return v_res_949_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Config(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Write(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Check(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Registry(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Outcomes(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Config(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Write(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Check(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Registry(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Outcomes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_proofEnvironment_main___boxed__const__1 = _init_lp_proofEnvironment_main___boxed__const__1();
lean_mark_persistent(lp_proofEnvironment_main___boxed__const__1);
lp_proofEnvironment_main___boxed__const__2 = _init_lp_proofEnvironment_main___boxed__const__2();
lean_mark_persistent(lp_proofEnvironment_main___boxed__const__2);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
void lean_initialize();
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  lean_initialize();
  res = initialize_proofEnvironment_OCMEnvironment_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
