// Lean compiler output
// Module: OCMEnvironment.Packet
// Imports: public import Init public meta import Init public import OCMEnvironment.PacketSchema public import Export
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_String_splitOnAux(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_parse(lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
extern lean_object* lp_proofEnvironment_exportMetadata;
uint8_t l___private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27(lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t lean_string_memcmp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* lean_array_pop(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_references(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00Lean_Server_FileWorker_WorkerContext_modifyPartialHandler_spec__0___redArg(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_natural(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_IO_FS_readFile(lean_object*);
lean_object* l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(lean_object*);
lean_object* lean_io_prim_handle_mk(lean_object*, uint8_t);
lean_object* lp_proofEnvironment_Export_Parse_parseFile___boxed(lean_object*, lean_object*);
lean_object* lean_stream_of_handle(lean_object*);
lean_object* lp_proofEnvironment_Export_Parse_M_run___redArg(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* lean_array_get_size(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_metadata;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "METADATA_MISMATCH"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__0 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__0_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__0_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__1 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__1_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__2 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__2_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___boxed(lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "NONCANONICAL_JSON"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__0_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__1_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "in"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__2_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "NAME_INDEX_IDENTITY"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__3_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__4_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "il"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__5 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__5_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "LEVEL_INDEX_IDENTITY"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__6 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__6_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__7 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__7_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "ie"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__8 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__8_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "EXPR_INDEX_IDENTITY"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__9 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__9_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__10 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__10_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "CANDIDATE_DECLARATION"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__11 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__11_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__12 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__12_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "OBJECT_REQUIRED"};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__13 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__13_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__14 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__14_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_validateText___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "FINAL_NEWLINE_REQUIRED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_validateText___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_validateText___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "\n"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_validateText___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__3_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_validateText___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__4;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_validateText___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__5_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_validateText___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__5_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__6_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_validateText___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "EMPTY_PACKET"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__7_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_validateText___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__7_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_validateText___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_validateText___closed__8_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateText(lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateText___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_readPacket___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__11_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_readPacket___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_readPacket___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readPacket(lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readPacket___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_metadata(void){
_start:
{
lean_object* v___x_1_; 
v___x_1_ = lp_proofEnvironment_exportMetadata;
return v___x_1_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta(lean_object* v_j_7_){
_start:
{
lean_object* v___x_8_; uint8_t v___x_9_; 
v___x_8_ = lp_proofEnvironment_exportMetadata;
v___x_9_ = l___private_Lean_Data_Json_Basic_0__Lean_Json_beq_x27(v_j_7_, v___x_8_);
if (v___x_9_ == 0)
{
lean_object* v___x_10_; 
v___x_10_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__1));
return v___x_10_;
}
else
{
lean_object* v___x_11_; 
v___x_11_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__2));
return v___x_11_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___boxed(lean_object* v_j_12_){
_start:
{
lean_object* v_res_13_; 
v_res_13_ = lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta(v_j_12_);
lean_dec(v_j_12_);
return v_res_13_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg(uint8_t v_candidateOnly_35_, lean_object* v_as_x27_36_, lean_object* v_b_37_){
_start:
{
if (lean_obj_tag(v_as_x27_36_) == 0)
{
lean_object* v___x_38_; 
v___x_38_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_38_, 0, v_b_37_);
return v___x_38_;
}
else
{
lean_object* v_head_39_; lean_object* v_tail_40_; lean_object* v___x_41_; 
v_head_39_ = lean_ctor_get(v_as_x27_36_, 0);
v_tail_40_ = lean_ctor_get(v_as_x27_36_, 1);
lean_inc(v_head_39_);
v___x_41_ = l_Lean_Json_parse(v_head_39_);
if (lean_obj_tag(v___x_41_) == 0)
{
lean_object* v_a_42_; lean_object* v___x_44_; uint8_t v_isShared_45_; uint8_t v_isSharedCheck_49_; 
lean_dec_ref(v_b_37_);
v_a_42_ = lean_ctor_get(v___x_41_, 0);
v_isSharedCheck_49_ = !lean_is_exclusive(v___x_41_);
if (v_isSharedCheck_49_ == 0)
{
v___x_44_ = v___x_41_;
v_isShared_45_ = v_isSharedCheck_49_;
goto v_resetjp_43_;
}
else
{
lean_inc(v_a_42_);
lean_dec(v___x_41_);
v___x_44_ = lean_box(0);
v_isShared_45_ = v_isSharedCheck_49_;
goto v_resetjp_43_;
}
v_resetjp_43_:
{
lean_object* v___x_47_; 
if (v_isShared_45_ == 0)
{
v___x_47_ = v___x_44_;
goto v_reusejp_46_;
}
else
{
lean_object* v_reuseFailAlloc_48_; 
v_reuseFailAlloc_48_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_48_, 0, v_a_42_);
v___x_47_ = v_reuseFailAlloc_48_;
goto v_reusejp_46_;
}
v_reusejp_46_:
{
return v___x_47_;
}
}
}
else
{
lean_object* v_a_50_; lean_object* v___x_51_; uint8_t v___x_52_; 
v_a_50_ = lean_ctor_get(v___x_41_, 0);
lean_inc_n(v_a_50_, 2);
lean_dec_ref_known(v___x_41_, 1);
v___x_51_ = l_Lean_Json_compress(v_a_50_);
v___x_52_ = lean_string_dec_eq(v___x_51_, v_head_39_);
lean_dec_ref(v___x_51_);
if (v___x_52_ == 0)
{
lean_object* v___x_53_; 
lean_dec(v_a_50_);
lean_dec_ref(v_b_37_);
v___x_53_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__1));
return v___x_53_;
}
else
{
lean_object* v___x_54_; 
lean_inc(v_a_50_);
v___x_54_ = lp_proofEnvironment_OCMEnvironment_itemSchema(v_a_50_);
if (lean_obj_tag(v___x_54_) == 0)
{
lean_object* v_a_55_; lean_object* v___x_57_; uint8_t v_isShared_58_; uint8_t v_isSharedCheck_62_; 
lean_dec(v_a_50_);
lean_dec_ref(v_b_37_);
v_a_55_ = lean_ctor_get(v___x_54_, 0);
v_isSharedCheck_62_ = !lean_is_exclusive(v___x_54_);
if (v_isSharedCheck_62_ == 0)
{
v___x_57_ = v___x_54_;
v_isShared_58_ = v_isSharedCheck_62_;
goto v_resetjp_56_;
}
else
{
lean_inc(v_a_55_);
lean_dec(v___x_54_);
v___x_57_ = lean_box(0);
v_isShared_58_ = v_isSharedCheck_62_;
goto v_resetjp_56_;
}
v_resetjp_56_:
{
lean_object* v___x_60_; 
if (v_isShared_58_ == 0)
{
v___x_60_ = v___x_57_;
goto v_reusejp_59_;
}
else
{
lean_object* v_reuseFailAlloc_61_; 
v_reuseFailAlloc_61_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_61_, 0, v_a_55_);
v___x_60_ = v_reuseFailAlloc_61_;
goto v_reusejp_59_;
}
v_reusejp_59_:
{
return v___x_60_;
}
}
}
else
{
lean_object* v_snd_63_; lean_object* v_fst_64_; lean_object* v___x_66_; uint8_t v_isShared_67_; uint8_t v_isSharedCheck_163_; 
lean_dec_ref_known(v___x_54_, 1);
v_snd_63_ = lean_ctor_get(v_b_37_, 1);
v_fst_64_ = lean_ctor_get(v_b_37_, 0);
v_isSharedCheck_163_ = !lean_is_exclusive(v_b_37_);
if (v_isSharedCheck_163_ == 0)
{
v___x_66_ = v_b_37_;
v_isShared_67_ = v_isSharedCheck_163_;
goto v_resetjp_65_;
}
else
{
lean_inc(v_snd_63_);
lean_inc(v_fst_64_);
lean_dec(v_b_37_);
v___x_66_ = lean_box(0);
v_isShared_67_ = v_isSharedCheck_163_;
goto v_resetjp_65_;
}
v_resetjp_65_:
{
lean_object* v_fst_68_; lean_object* v_snd_69_; lean_object* v___x_71_; uint8_t v_isShared_72_; uint8_t v_isSharedCheck_162_; 
v_fst_68_ = lean_ctor_get(v_snd_63_, 0);
v_snd_69_ = lean_ctor_get(v_snd_63_, 1);
v_isSharedCheck_162_ = !lean_is_exclusive(v_snd_63_);
if (v_isSharedCheck_162_ == 0)
{
v___x_71_ = v_snd_63_;
v_isShared_72_ = v_isSharedCheck_162_;
goto v_resetjp_70_;
}
else
{
lean_inc(v_snd_69_);
lean_inc(v_fst_68_);
lean_dec(v_snd_63_);
v___x_71_ = lean_box(0);
v_isShared_72_ = v_isSharedCheck_162_;
goto v_resetjp_70_;
}
v_resetjp_70_:
{
lean_object* v___x_73_; 
lean_inc(v_a_50_);
v___x_73_ = lp_proofEnvironment_OCMEnvironment_references(v_a_50_, v_fst_64_, v_fst_68_, v_snd_69_);
if (lean_obj_tag(v___x_73_) == 0)
{
lean_object* v_a_74_; lean_object* v___x_76_; uint8_t v_isShared_77_; uint8_t v_isSharedCheck_81_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
lean_dec(v_a_50_);
v_a_74_ = lean_ctor_get(v___x_73_, 0);
v_isSharedCheck_81_ = !lean_is_exclusive(v___x_73_);
if (v_isSharedCheck_81_ == 0)
{
v___x_76_ = v___x_73_;
v_isShared_77_ = v_isSharedCheck_81_;
goto v_resetjp_75_;
}
else
{
lean_inc(v_a_74_);
lean_dec(v___x_73_);
v___x_76_ = lean_box(0);
v_isShared_77_ = v_isSharedCheck_81_;
goto v_resetjp_75_;
}
v_resetjp_75_:
{
lean_object* v___x_79_; 
if (v_isShared_77_ == 0)
{
v___x_79_ = v___x_76_;
goto v_reusejp_78_;
}
else
{
lean_object* v_reuseFailAlloc_80_; 
v_reuseFailAlloc_80_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_80_, 0, v_a_74_);
v___x_79_ = v_reuseFailAlloc_80_;
goto v_reusejp_78_;
}
v_reusejp_78_:
{
return v___x_79_;
}
}
}
else
{
lean_dec_ref_known(v___x_73_, 1);
if (lean_obj_tag(v_a_50_) == 5)
{
lean_object* v_kvPairs_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; 
v_kvPairs_82_ = lean_ctor_get(v_a_50_, 0);
lean_inc(v_kvPairs_82_);
lean_dec_ref_known(v_a_50_, 1);
v___x_83_ = lean_unsigned_to_nat(1u);
v___x_84_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__2));
v___x_85_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00Lean_Server_FileWorker_WorkerContext_modifyPartialHandler_spec__0___redArg(v_kvPairs_82_, v___x_84_);
if (lean_obj_tag(v___x_85_) == 1)
{
lean_object* v_val_86_; lean_object* v___x_87_; 
lean_dec(v_kvPairs_82_);
v_val_86_ = lean_ctor_get(v___x_85_, 0);
lean_inc(v_val_86_);
lean_dec_ref_known(v___x_85_, 1);
v___x_87_ = lp_proofEnvironment_OCMEnvironment_natural(v_val_86_);
if (lean_obj_tag(v___x_87_) == 0)
{
lean_object* v_a_88_; lean_object* v___x_90_; uint8_t v_isShared_91_; uint8_t v_isSharedCheck_95_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v_a_88_ = lean_ctor_get(v___x_87_, 0);
v_isSharedCheck_95_ = !lean_is_exclusive(v___x_87_);
if (v_isSharedCheck_95_ == 0)
{
v___x_90_ = v___x_87_;
v_isShared_91_ = v_isSharedCheck_95_;
goto v_resetjp_89_;
}
else
{
lean_inc(v_a_88_);
lean_dec(v___x_87_);
v___x_90_ = lean_box(0);
v_isShared_91_ = v_isSharedCheck_95_;
goto v_resetjp_89_;
}
v_resetjp_89_:
{
lean_object* v___x_93_; 
if (v_isShared_91_ == 0)
{
v___x_93_ = v___x_90_;
goto v_reusejp_92_;
}
else
{
lean_object* v_reuseFailAlloc_94_; 
v_reuseFailAlloc_94_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_94_, 0, v_a_88_);
v___x_93_ = v_reuseFailAlloc_94_;
goto v_reusejp_92_;
}
v_reusejp_92_:
{
return v___x_93_;
}
}
}
else
{
lean_object* v_a_96_; uint8_t v___x_97_; 
v_a_96_ = lean_ctor_get(v___x_87_, 0);
lean_inc(v_a_96_);
lean_dec_ref_known(v___x_87_, 1);
v___x_97_ = lean_nat_dec_eq(v_a_96_, v_fst_64_);
lean_dec(v_a_96_);
if (v___x_97_ == 0)
{
lean_object* v___x_98_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v___x_98_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__4));
return v___x_98_;
}
else
{
lean_object* v___x_99_; lean_object* v___x_101_; 
v___x_99_ = lean_nat_add(v_fst_64_, v___x_83_);
lean_dec(v_fst_64_);
if (v_isShared_72_ == 0)
{
v___x_101_ = v___x_71_;
goto v_reusejp_100_;
}
else
{
lean_object* v_reuseFailAlloc_106_; 
v_reuseFailAlloc_106_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_106_, 0, v_fst_68_);
lean_ctor_set(v_reuseFailAlloc_106_, 1, v_snd_69_);
v___x_101_ = v_reuseFailAlloc_106_;
goto v_reusejp_100_;
}
v_reusejp_100_:
{
lean_object* v___x_103_; 
if (v_isShared_67_ == 0)
{
lean_ctor_set(v___x_66_, 1, v___x_101_);
lean_ctor_set(v___x_66_, 0, v___x_99_);
v___x_103_ = v___x_66_;
goto v_reusejp_102_;
}
else
{
lean_object* v_reuseFailAlloc_105_; 
v_reuseFailAlloc_105_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_105_, 0, v___x_99_);
lean_ctor_set(v_reuseFailAlloc_105_, 1, v___x_101_);
v___x_103_ = v_reuseFailAlloc_105_;
goto v_reusejp_102_;
}
v_reusejp_102_:
{
v_as_x27_36_ = v_tail_40_;
v_b_37_ = v___x_103_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_107_; lean_object* v___x_108_; 
lean_dec(v___x_85_);
v___x_107_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__5));
v___x_108_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00Lean_Server_FileWorker_WorkerContext_modifyPartialHandler_spec__0___redArg(v_kvPairs_82_, v___x_107_);
if (lean_obj_tag(v___x_108_) == 1)
{
lean_object* v_val_109_; lean_object* v___x_110_; 
lean_dec(v_kvPairs_82_);
v_val_109_ = lean_ctor_get(v___x_108_, 0);
lean_inc(v_val_109_);
lean_dec_ref_known(v___x_108_, 1);
v___x_110_ = lp_proofEnvironment_OCMEnvironment_natural(v_val_109_);
if (lean_obj_tag(v___x_110_) == 0)
{
lean_object* v_a_111_; lean_object* v___x_113_; uint8_t v_isShared_114_; uint8_t v_isSharedCheck_118_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v_a_111_ = lean_ctor_get(v___x_110_, 0);
v_isSharedCheck_118_ = !lean_is_exclusive(v___x_110_);
if (v_isSharedCheck_118_ == 0)
{
v___x_113_ = v___x_110_;
v_isShared_114_ = v_isSharedCheck_118_;
goto v_resetjp_112_;
}
else
{
lean_inc(v_a_111_);
lean_dec(v___x_110_);
v___x_113_ = lean_box(0);
v_isShared_114_ = v_isSharedCheck_118_;
goto v_resetjp_112_;
}
v_resetjp_112_:
{
lean_object* v___x_116_; 
if (v_isShared_114_ == 0)
{
v___x_116_ = v___x_113_;
goto v_reusejp_115_;
}
else
{
lean_object* v_reuseFailAlloc_117_; 
v_reuseFailAlloc_117_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_117_, 0, v_a_111_);
v___x_116_ = v_reuseFailAlloc_117_;
goto v_reusejp_115_;
}
v_reusejp_115_:
{
return v___x_116_;
}
}
}
else
{
lean_object* v_a_119_; uint8_t v___x_120_; 
v_a_119_ = lean_ctor_get(v___x_110_, 0);
lean_inc(v_a_119_);
lean_dec_ref_known(v___x_110_, 1);
v___x_120_ = lean_nat_dec_eq(v_a_119_, v_fst_68_);
lean_dec(v_a_119_);
if (v___x_120_ == 0)
{
lean_object* v___x_121_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v___x_121_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__7));
return v___x_121_;
}
else
{
lean_object* v___x_122_; lean_object* v___x_124_; 
v___x_122_ = lean_nat_add(v_fst_68_, v___x_83_);
lean_dec(v_fst_68_);
if (v_isShared_72_ == 0)
{
lean_ctor_set(v___x_71_, 0, v___x_122_);
v___x_124_ = v___x_71_;
goto v_reusejp_123_;
}
else
{
lean_object* v_reuseFailAlloc_129_; 
v_reuseFailAlloc_129_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_129_, 0, v___x_122_);
lean_ctor_set(v_reuseFailAlloc_129_, 1, v_snd_69_);
v___x_124_ = v_reuseFailAlloc_129_;
goto v_reusejp_123_;
}
v_reusejp_123_:
{
lean_object* v___x_126_; 
if (v_isShared_67_ == 0)
{
lean_ctor_set(v___x_66_, 1, v___x_124_);
v___x_126_ = v___x_66_;
goto v_reusejp_125_;
}
else
{
lean_object* v_reuseFailAlloc_128_; 
v_reuseFailAlloc_128_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_128_, 0, v_fst_64_);
lean_ctor_set(v_reuseFailAlloc_128_, 1, v___x_124_);
v___x_126_ = v_reuseFailAlloc_128_;
goto v_reusejp_125_;
}
v_reusejp_125_:
{
v_as_x27_36_ = v_tail_40_;
v_b_37_ = v___x_126_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_130_; lean_object* v___x_131_; 
lean_dec(v___x_108_);
v___x_130_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__8));
v___x_131_ = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___00Lean_Server_FileWorker_WorkerContext_modifyPartialHandler_spec__0___redArg(v_kvPairs_82_, v___x_130_);
lean_dec(v_kvPairs_82_);
if (lean_obj_tag(v___x_131_) == 1)
{
lean_object* v_val_132_; lean_object* v___x_133_; 
v_val_132_ = lean_ctor_get(v___x_131_, 0);
lean_inc(v_val_132_);
lean_dec_ref_known(v___x_131_, 1);
v___x_133_ = lp_proofEnvironment_OCMEnvironment_natural(v_val_132_);
if (lean_obj_tag(v___x_133_) == 0)
{
lean_object* v_a_134_; lean_object* v___x_136_; uint8_t v_isShared_137_; uint8_t v_isSharedCheck_141_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v_a_134_ = lean_ctor_get(v___x_133_, 0);
v_isSharedCheck_141_ = !lean_is_exclusive(v___x_133_);
if (v_isSharedCheck_141_ == 0)
{
v___x_136_ = v___x_133_;
v_isShared_137_ = v_isSharedCheck_141_;
goto v_resetjp_135_;
}
else
{
lean_inc(v_a_134_);
lean_dec(v___x_133_);
v___x_136_ = lean_box(0);
v_isShared_137_ = v_isSharedCheck_141_;
goto v_resetjp_135_;
}
v_resetjp_135_:
{
lean_object* v___x_139_; 
if (v_isShared_137_ == 0)
{
v___x_139_ = v___x_136_;
goto v_reusejp_138_;
}
else
{
lean_object* v_reuseFailAlloc_140_; 
v_reuseFailAlloc_140_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_140_, 0, v_a_134_);
v___x_139_ = v_reuseFailAlloc_140_;
goto v_reusejp_138_;
}
v_reusejp_138_:
{
return v___x_139_;
}
}
}
else
{
lean_object* v_a_142_; uint8_t v___x_143_; 
v_a_142_ = lean_ctor_get(v___x_133_, 0);
lean_inc(v_a_142_);
lean_dec_ref_known(v___x_133_, 1);
v___x_143_ = lean_nat_dec_eq(v_a_142_, v_snd_69_);
lean_dec(v_a_142_);
if (v___x_143_ == 0)
{
lean_object* v___x_144_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v___x_144_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__10));
return v___x_144_;
}
else
{
lean_object* v___x_145_; lean_object* v___x_147_; 
v___x_145_ = lean_nat_add(v_snd_69_, v___x_83_);
lean_dec(v_snd_69_);
if (v_isShared_72_ == 0)
{
lean_ctor_set(v___x_71_, 1, v___x_145_);
v___x_147_ = v___x_71_;
goto v_reusejp_146_;
}
else
{
lean_object* v_reuseFailAlloc_152_; 
v_reuseFailAlloc_152_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_152_, 0, v_fst_68_);
lean_ctor_set(v_reuseFailAlloc_152_, 1, v___x_145_);
v___x_147_ = v_reuseFailAlloc_152_;
goto v_reusejp_146_;
}
v_reusejp_146_:
{
lean_object* v___x_149_; 
if (v_isShared_67_ == 0)
{
lean_ctor_set(v___x_66_, 1, v___x_147_);
v___x_149_ = v___x_66_;
goto v_reusejp_148_;
}
else
{
lean_object* v_reuseFailAlloc_151_; 
v_reuseFailAlloc_151_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_151_, 0, v_fst_64_);
lean_ctor_set(v_reuseFailAlloc_151_, 1, v___x_147_);
v___x_149_ = v_reuseFailAlloc_151_;
goto v_reusejp_148_;
}
v_reusejp_148_:
{
v_as_x27_36_ = v_tail_40_;
v_b_37_ = v___x_149_;
goto _start;
}
}
}
}
}
else
{
lean_dec(v___x_131_);
if (v_candidateOnly_35_ == 0)
{
lean_object* v___x_154_; 
if (v_isShared_72_ == 0)
{
v___x_154_ = v___x_71_;
goto v_reusejp_153_;
}
else
{
lean_object* v_reuseFailAlloc_159_; 
v_reuseFailAlloc_159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_159_, 0, v_fst_68_);
lean_ctor_set(v_reuseFailAlloc_159_, 1, v_snd_69_);
v___x_154_ = v_reuseFailAlloc_159_;
goto v_reusejp_153_;
}
v_reusejp_153_:
{
lean_object* v___x_156_; 
if (v_isShared_67_ == 0)
{
lean_ctor_set(v___x_66_, 1, v___x_154_);
v___x_156_ = v___x_66_;
goto v_reusejp_155_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v_fst_64_);
lean_ctor_set(v_reuseFailAlloc_158_, 1, v___x_154_);
v___x_156_ = v_reuseFailAlloc_158_;
goto v_reusejp_155_;
}
v_reusejp_155_:
{
v_as_x27_36_ = v_tail_40_;
v_b_37_ = v___x_156_;
goto _start;
}
}
}
else
{
lean_object* v___x_160_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
v___x_160_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__12));
return v___x_160_;
}
}
}
}
}
else
{
lean_object* v___x_161_; 
lean_del_object(v___x_71_);
lean_dec(v_snd_69_);
lean_dec(v_fst_68_);
lean_del_object(v___x_66_);
lean_dec(v_fst_64_);
lean_dec(v_a_50_);
v___x_161_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___closed__14));
return v___x_161_;
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg___boxed(lean_object* v_candidateOnly_164_, lean_object* v_as_x27_165_, lean_object* v_b_166_){
_start:
{
uint8_t v_candidateOnly_boxed_167_; lean_object* v_res_168_; 
v_candidateOnly_boxed_167_ = lean_unbox(v_candidateOnly_164_);
v_res_168_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg(v_candidateOnly_boxed_167_, v_as_x27_165_, v_b_166_);
lean_dec(v_as_x27_165_);
return v_res_168_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_validateText___closed__4(void){
_start:
{
lean_object* v___x_175_; lean_object* v___x_176_; 
v___x_175_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__2));
v___x_176_ = lean_string_utf8_byte_size(v___x_175_);
return v___x_176_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateText(lean_object* v_text_186_, uint8_t v_candidateOnly_187_){
_start:
{
lean_object* v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; 
v___x_190_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__2));
v___x_191_ = lean_unsigned_to_nat(0u);
v___x_192_ = lean_box(0);
v___x_193_ = l_String_splitOnAux(v_text_186_, v___x_190_, v___x_191_, v___x_191_, v___x_191_, v___x_192_);
if (lean_obj_tag(v___x_193_) == 1)
{
lean_object* v_head_194_; lean_object* v_tail_195_; lean_object* v___x_196_; 
v_head_194_ = lean_ctor_get(v___x_193_, 0);
lean_inc_n(v_head_194_, 2);
v_tail_195_ = lean_ctor_get(v___x_193_, 1);
lean_inc(v_tail_195_);
lean_dec_ref_known(v___x_193_, 2);
v___x_196_ = l_Lean_Json_parse(v_head_194_);
if (lean_obj_tag(v___x_196_) == 0)
{
lean_object* v_a_197_; lean_object* v___x_199_; uint8_t v_isShared_200_; uint8_t v_isSharedCheck_204_; 
lean_dec(v_tail_195_);
lean_dec(v_head_194_);
v_a_197_ = lean_ctor_get(v___x_196_, 0);
v_isSharedCheck_204_ = !lean_is_exclusive(v___x_196_);
if (v_isSharedCheck_204_ == 0)
{
v___x_199_ = v___x_196_;
v_isShared_200_ = v_isSharedCheck_204_;
goto v_resetjp_198_;
}
else
{
lean_inc(v_a_197_);
lean_dec(v___x_196_);
v___x_199_ = lean_box(0);
v_isShared_200_ = v_isSharedCheck_204_;
goto v_resetjp_198_;
}
v_resetjp_198_:
{
lean_object* v___x_202_; 
if (v_isShared_200_ == 0)
{
v___x_202_ = v___x_199_;
goto v_reusejp_201_;
}
else
{
lean_object* v_reuseFailAlloc_203_; 
v_reuseFailAlloc_203_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_203_, 0, v_a_197_);
v___x_202_ = v_reuseFailAlloc_203_;
goto v_reusejp_201_;
}
v_reusejp_201_:
{
return v___x_202_;
}
}
}
else
{
lean_object* v_a_205_; lean_object* v___x_206_; uint8_t v___x_207_; 
v_a_205_ = lean_ctor_get(v___x_196_, 0);
lean_inc_n(v_a_205_, 2);
lean_dec_ref_known(v___x_196_, 1);
v___x_206_ = l_Lean_Json_compress(v_a_205_);
v___x_207_ = lean_string_dec_eq(v___x_206_, v_head_194_);
lean_dec(v_head_194_);
lean_dec_ref(v___x_206_);
if (v___x_207_ == 0)
{
lean_object* v___x_208_; 
lean_dec(v_a_205_);
lean_dec(v_tail_195_);
v___x_208_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__3));
return v___x_208_;
}
else
{
lean_object* v___x_209_; 
v___x_209_ = lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta(v_a_205_);
lean_dec(v_a_205_);
if (lean_obj_tag(v___x_209_) == 0)
{
lean_dec(v_tail_195_);
return v___x_209_;
}
else
{
lean_object* v___x_210_; lean_object* v___x_211_; uint8_t v___x_212_; 
lean_dec_ref_known(v___x_209_, 1);
v___x_210_ = lean_string_utf8_byte_size(v_text_186_);
v___x_211_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_validateText___closed__4, &lp_proofEnvironment_OCMEnvironment_validateText___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_validateText___closed__4);
v___x_212_ = lean_nat_dec_le(v___x_211_, v___x_210_);
if (v___x_212_ == 0)
{
lean_dec(v_tail_195_);
goto v___jp_188_;
}
else
{
lean_object* v___x_213_; uint8_t v___x_214_; 
v___x_213_ = lean_nat_sub(v___x_210_, v___x_211_);
v___x_214_ = lean_string_memcmp(v_text_186_, v___x_190_, v___x_213_, v___x_191_, v___x_211_);
lean_dec(v___x_213_);
if (v___x_214_ == 0)
{
lean_dec(v_tail_195_);
goto v___jp_188_;
}
else
{
lean_object* v___x_215_; lean_object* v___x_216_; lean_object* v___x_217_; lean_object* v___x_218_; lean_object* v___x_219_; 
v___x_215_ = lean_array_mk(v_tail_195_);
v___x_216_ = lean_array_pop(v___x_215_);
v___x_217_ = lean_array_to_list(v___x_216_);
v___x_218_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__6));
v___x_219_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg(v_candidateOnly_187_, v___x_217_, v___x_218_);
lean_dec(v___x_217_);
if (lean_obj_tag(v___x_219_) == 0)
{
lean_object* v_a_220_; lean_object* v___x_222_; uint8_t v_isShared_223_; uint8_t v_isSharedCheck_227_; 
v_a_220_ = lean_ctor_get(v___x_219_, 0);
v_isSharedCheck_227_ = !lean_is_exclusive(v___x_219_);
if (v_isSharedCheck_227_ == 0)
{
v___x_222_ = v___x_219_;
v_isShared_223_ = v_isSharedCheck_227_;
goto v_resetjp_221_;
}
else
{
lean_inc(v_a_220_);
lean_dec(v___x_219_);
v___x_222_ = lean_box(0);
v_isShared_223_ = v_isSharedCheck_227_;
goto v_resetjp_221_;
}
v_resetjp_221_:
{
lean_object* v___x_225_; 
if (v_isShared_223_ == 0)
{
v___x_225_ = v___x_222_;
goto v_reusejp_224_;
}
else
{
lean_object* v_reuseFailAlloc_226_; 
v_reuseFailAlloc_226_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_226_, 0, v_a_220_);
v___x_225_ = v_reuseFailAlloc_226_;
goto v_reusejp_224_;
}
v_reusejp_224_:
{
return v___x_225_;
}
}
}
else
{
lean_object* v___x_228_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_228_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_Packet_0__OCMEnvironment_checkMeta___closed__2));
return v___x_228_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_229_; 
lean_dec(v___x_193_);
v___x_229_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__8));
return v___x_229_;
}
v___jp_188_:
{
lean_object* v___x_189_; 
v___x_189_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__1));
return v___x_189_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_validateText___boxed(lean_object* v_text_230_, lean_object* v_candidateOnly_231_){
_start:
{
uint8_t v_candidateOnly_boxed_232_; lean_object* v_res_233_; 
v_candidateOnly_boxed_232_ = lean_unbox(v_candidateOnly_231_);
v_res_233_ = lp_proofEnvironment_OCMEnvironment_validateText(v_text_230_, v_candidateOnly_boxed_232_);
lean_dec_ref(v_text_230_);
return v_res_233_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0(uint8_t v_candidateOnly_234_, lean_object* v_as_235_, lean_object* v_as_x27_236_, lean_object* v_b_237_, lean_object* v_a_238_){
_start:
{
lean_object* v___x_239_; 
v___x_239_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___redArg(v_candidateOnly_234_, v_as_x27_236_, v_b_237_);
return v___x_239_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0___boxed(lean_object* v_candidateOnly_240_, lean_object* v_as_241_, lean_object* v_as_x27_242_, lean_object* v_b_243_, lean_object* v_a_244_){
_start:
{
uint8_t v_candidateOnly_boxed_245_; lean_object* v_res_246_; 
v_candidateOnly_boxed_245_ = lean_unbox(v_candidateOnly_240_);
v_res_246_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_validateText_spec__0(v_candidateOnly_boxed_245_, v_as_241_, v_as_x27_242_, v_b_243_, v_a_244_);
lean_dec(v_as_x27_242_);
lean_dec(v_as_241_);
return v_res_246_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readPacket(lean_object* v_path_249_, uint8_t v_candidateOnly_250_){
_start:
{
lean_object* v___x_252_; 
v___x_252_ = l_IO_FS_readFile(v_path_249_);
if (lean_obj_tag(v___x_252_) == 0)
{
lean_object* v_a_253_; lean_object* v___x_254_; lean_object* v___x_255_; 
v_a_253_ = lean_ctor_get(v___x_252_, 0);
lean_inc(v_a_253_);
lean_dec_ref_known(v___x_252_, 1);
v___x_254_ = lp_proofEnvironment_OCMEnvironment_validateText(v_a_253_, v_candidateOnly_250_);
v___x_255_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_254_);
if (lean_obj_tag(v___x_255_) == 0)
{
uint8_t v___x_256_; lean_object* v___x_257_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = 0;
v___x_257_ = lean_io_prim_handle_mk(v_path_249_, v___x_256_);
if (lean_obj_tag(v___x_257_) == 0)
{
lean_object* v_a_258_; lean_object* v___x_260_; uint8_t v_isShared_261_; uint8_t v_isSharedCheck_310_; 
v_a_258_ = lean_ctor_get(v___x_257_, 0);
v_isSharedCheck_310_ = !lean_is_exclusive(v___x_257_);
if (v_isSharedCheck_310_ == 0)
{
v___x_260_ = v___x_257_;
v_isShared_261_ = v_isSharedCheck_310_;
goto v_resetjp_259_;
}
else
{
lean_inc(v_a_258_);
lean_dec(v___x_257_);
v___x_260_ = lean_box(0);
v_isShared_261_ = v_isSharedCheck_310_;
goto v_resetjp_259_;
}
v_resetjp_259_:
{
lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v___x_264_; 
v___x_262_ = lean_alloc_closure((void*)(lp_proofEnvironment_Export_Parse_parseFile___boxed), 2, 0);
v___x_263_ = lean_stream_of_handle(v_a_258_);
v___x_264_ = lp_proofEnvironment_Export_Parse_M_run___redArg(v___x_262_, v___x_263_);
if (lean_obj_tag(v___x_264_) == 0)
{
lean_object* v_a_265_; lean_object* v___x_267_; uint8_t v_isShared_268_; uint8_t v_isSharedCheck_301_; 
v_a_265_ = lean_ctor_get(v___x_264_, 0);
v_isSharedCheck_301_ = !lean_is_exclusive(v___x_264_);
if (v_isSharedCheck_301_ == 0)
{
v___x_267_ = v___x_264_;
v_isShared_268_ = v_isSharedCheck_301_;
goto v_resetjp_266_;
}
else
{
lean_inc(v_a_265_);
lean_dec(v___x_264_);
v___x_267_ = lean_box(0);
v_isShared_268_ = v_isSharedCheck_301_;
goto v_resetjp_266_;
}
v_resetjp_266_:
{
lean_object* v_snd_274_; lean_object* v___x_276_; uint8_t v_isShared_277_; uint8_t v_isSharedCheck_299_; 
v_snd_274_ = lean_ctor_get(v_a_265_, 1);
v_isSharedCheck_299_ = !lean_is_exclusive(v_a_265_);
if (v_isSharedCheck_299_ == 0)
{
lean_object* v_unused_300_; 
v_unused_300_ = lean_ctor_get(v_a_265_, 0);
lean_dec(v_unused_300_);
v___x_276_ = v_a_265_;
v_isShared_277_ = v_isSharedCheck_299_;
goto v_resetjp_275_;
}
else
{
lean_inc(v_snd_274_);
lean_dec(v_a_265_);
v___x_276_ = lean_box(0);
v_isShared_277_ = v_isSharedCheck_299_;
goto v_resetjp_275_;
}
v___jp_269_:
{
lean_object* v___x_270_; lean_object* v___x_272_; 
v___x_270_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_readPacket___closed__0));
if (v_isShared_268_ == 0)
{
lean_ctor_set_tag(v___x_267_, 1);
lean_ctor_set(v___x_267_, 0, v___x_270_);
v___x_272_ = v___x_267_;
goto v_reusejp_271_;
}
else
{
lean_object* v_reuseFailAlloc_273_; 
v_reuseFailAlloc_273_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_273_, 0, v___x_270_);
v___x_272_ = v_reuseFailAlloc_273_;
goto v_reusejp_271_;
}
v_reusejp_271_:
{
return v___x_272_;
}
}
v_resetjp_275_:
{
if (v_candidateOnly_250_ == 0)
{
lean_del_object(v___x_267_);
goto v___jp_278_;
}
else
{
lean_object* v_constMap_292_; lean_object* v_constOrder_293_; lean_object* v_size_294_; lean_object* v___x_295_; uint8_t v___x_296_; 
v_constMap_292_ = lean_ctor_get(v_snd_274_, 5);
v_constOrder_293_ = lean_ctor_get(v_snd_274_, 6);
v_size_294_ = lean_ctor_get(v_constMap_292_, 0);
v___x_295_ = lean_unsigned_to_nat(0u);
v___x_296_ = lean_nat_dec_eq(v_size_294_, v___x_295_);
if (v___x_296_ == 0)
{
lean_del_object(v___x_276_);
lean_dec(v_snd_274_);
lean_del_object(v___x_260_);
lean_dec(v_a_253_);
goto v___jp_269_;
}
else
{
lean_object* v___x_297_; uint8_t v___x_298_; 
v___x_297_ = lean_array_get_size(v_constOrder_293_);
v___x_298_ = lean_nat_dec_eq(v___x_297_, v___x_295_);
if (v___x_298_ == 0)
{
lean_del_object(v___x_276_);
lean_dec(v_snd_274_);
lean_del_object(v___x_260_);
lean_dec(v_a_253_);
goto v___jp_269_;
}
else
{
lean_del_object(v___x_267_);
goto v___jp_278_;
}
}
}
v___jp_278_:
{
lean_object* v___x_279_; lean_object* v___x_280_; lean_object* v___x_281_; lean_object* v___x_282_; lean_object* v___x_283_; lean_object* v___x_284_; lean_object* v___x_285_; lean_object* v___x_287_; 
v___x_279_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_validateText___closed__2));
v___x_280_ = lean_unsigned_to_nat(0u);
v___x_281_ = lean_box(0);
v___x_282_ = l_String_splitOnAux(v_a_253_, v___x_279_, v___x_280_, v___x_280_, v___x_280_, v___x_281_);
lean_dec(v_a_253_);
v___x_283_ = l_List_lengthTR___redArg(v___x_282_);
lean_dec(v___x_282_);
v___x_284_ = lean_unsigned_to_nat(1u);
v___x_285_ = lean_nat_sub(v___x_283_, v___x_284_);
lean_dec(v___x_283_);
if (v_isShared_277_ == 0)
{
lean_ctor_set(v___x_276_, 1, v___x_285_);
lean_ctor_set(v___x_276_, 0, v_snd_274_);
v___x_287_ = v___x_276_;
goto v_reusejp_286_;
}
else
{
lean_object* v_reuseFailAlloc_291_; 
v_reuseFailAlloc_291_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_291_, 0, v_snd_274_);
lean_ctor_set(v_reuseFailAlloc_291_, 1, v___x_285_);
v___x_287_ = v_reuseFailAlloc_291_;
goto v_reusejp_286_;
}
v_reusejp_286_:
{
lean_object* v___x_289_; 
if (v_isShared_261_ == 0)
{
lean_ctor_set(v___x_260_, 0, v___x_287_);
v___x_289_ = v___x_260_;
goto v_reusejp_288_;
}
else
{
lean_object* v_reuseFailAlloc_290_; 
v_reuseFailAlloc_290_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_290_, 0, v___x_287_);
v___x_289_ = v_reuseFailAlloc_290_;
goto v_reusejp_288_;
}
v_reusejp_288_:
{
return v___x_289_;
}
}
}
}
}
}
else
{
lean_object* v_a_302_; lean_object* v___x_304_; uint8_t v_isShared_305_; uint8_t v_isSharedCheck_309_; 
lean_del_object(v___x_260_);
lean_dec(v_a_253_);
v_a_302_ = lean_ctor_get(v___x_264_, 0);
v_isSharedCheck_309_ = !lean_is_exclusive(v___x_264_);
if (v_isSharedCheck_309_ == 0)
{
v___x_304_ = v___x_264_;
v_isShared_305_ = v_isSharedCheck_309_;
goto v_resetjp_303_;
}
else
{
lean_inc(v_a_302_);
lean_dec(v___x_264_);
v___x_304_ = lean_box(0);
v_isShared_305_ = v_isSharedCheck_309_;
goto v_resetjp_303_;
}
v_resetjp_303_:
{
lean_object* v___x_307_; 
if (v_isShared_305_ == 0)
{
v___x_307_ = v___x_304_;
goto v_reusejp_306_;
}
else
{
lean_object* v_reuseFailAlloc_308_; 
v_reuseFailAlloc_308_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_308_, 0, v_a_302_);
v___x_307_ = v_reuseFailAlloc_308_;
goto v_reusejp_306_;
}
v_reusejp_306_:
{
return v___x_307_;
}
}
}
}
}
else
{
lean_object* v_a_311_; lean_object* v___x_313_; uint8_t v_isShared_314_; uint8_t v_isSharedCheck_318_; 
lean_dec(v_a_253_);
v_a_311_ = lean_ctor_get(v___x_257_, 0);
v_isSharedCheck_318_ = !lean_is_exclusive(v___x_257_);
if (v_isSharedCheck_318_ == 0)
{
v___x_313_ = v___x_257_;
v_isShared_314_ = v_isSharedCheck_318_;
goto v_resetjp_312_;
}
else
{
lean_inc(v_a_311_);
lean_dec(v___x_257_);
v___x_313_ = lean_box(0);
v_isShared_314_ = v_isSharedCheck_318_;
goto v_resetjp_312_;
}
v_resetjp_312_:
{
lean_object* v___x_316_; 
if (v_isShared_314_ == 0)
{
v___x_316_ = v___x_313_;
goto v_reusejp_315_;
}
else
{
lean_object* v_reuseFailAlloc_317_; 
v_reuseFailAlloc_317_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_317_, 0, v_a_311_);
v___x_316_ = v_reuseFailAlloc_317_;
goto v_reusejp_315_;
}
v_reusejp_315_:
{
return v___x_316_;
}
}
}
}
else
{
lean_object* v_a_319_; lean_object* v___x_321_; uint8_t v_isShared_322_; uint8_t v_isSharedCheck_326_; 
lean_dec(v_a_253_);
v_a_319_ = lean_ctor_get(v___x_255_, 0);
v_isSharedCheck_326_ = !lean_is_exclusive(v___x_255_);
if (v_isSharedCheck_326_ == 0)
{
v___x_321_ = v___x_255_;
v_isShared_322_ = v_isSharedCheck_326_;
goto v_resetjp_320_;
}
else
{
lean_inc(v_a_319_);
lean_dec(v___x_255_);
v___x_321_ = lean_box(0);
v_isShared_322_ = v_isSharedCheck_326_;
goto v_resetjp_320_;
}
v_resetjp_320_:
{
lean_object* v___x_324_; 
if (v_isShared_322_ == 0)
{
v___x_324_ = v___x_321_;
goto v_reusejp_323_;
}
else
{
lean_object* v_reuseFailAlloc_325_; 
v_reuseFailAlloc_325_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_325_, 0, v_a_319_);
v___x_324_ = v_reuseFailAlloc_325_;
goto v_reusejp_323_;
}
v_reusejp_323_:
{
return v___x_324_;
}
}
}
}
else
{
lean_object* v_a_327_; lean_object* v___x_329_; uint8_t v_isShared_330_; uint8_t v_isSharedCheck_334_; 
v_a_327_ = lean_ctor_get(v___x_252_, 0);
v_isSharedCheck_334_ = !lean_is_exclusive(v___x_252_);
if (v_isSharedCheck_334_ == 0)
{
v___x_329_ = v___x_252_;
v_isShared_330_ = v_isSharedCheck_334_;
goto v_resetjp_328_;
}
else
{
lean_inc(v_a_327_);
lean_dec(v___x_252_);
v___x_329_ = lean_box(0);
v_isShared_330_ = v_isSharedCheck_334_;
goto v_resetjp_328_;
}
v_resetjp_328_:
{
lean_object* v___x_332_; 
if (v_isShared_330_ == 0)
{
v___x_332_ = v___x_329_;
goto v_reusejp_331_;
}
else
{
lean_object* v_reuseFailAlloc_333_; 
v_reuseFailAlloc_333_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_333_, 0, v_a_327_);
v___x_332_ = v_reuseFailAlloc_333_;
goto v_reusejp_331_;
}
v_reusejp_331_:
{
return v___x_332_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_readPacket___boxed(lean_object* v_path_335_, lean_object* v_candidateOnly_336_, lean_object* v_a_337_){
_start:
{
uint8_t v_candidateOnly_boxed_338_; lean_object* v_res_339_; 
v_candidateOnly_boxed_338_ = lean_unbox(v_candidateOnly_336_);
v_res_339_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_path_335_, v_candidateOnly_boxed_338_);
lean_dec_ref(v_path_335_);
return v_res_339_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_PacketSchema(uint8_t builtin);
lean_object* initialize_proofEnvironment_Export(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Packet(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_PacketSchema(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Export(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_proofEnvironment_OCMEnvironment_metadata = _init_lp_proofEnvironment_OCMEnvironment_metadata();
lean_mark_persistent(lp_proofEnvironment_OCMEnvironment_metadata);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
