// Lean compiler output
// Module: OCMEnvironment.Write
// Imports: public import Init public meta import Init public import CheckedExport public import OCMEnvironment.Packet public import OCMEnvironment.Prepare
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_mk_array(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1(lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_get_set_stdout(lean_object*);
lean_object* lp_proofEnvironment_CheckedExport_initState(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_CheckedExport_dumpMetadata___redArg(lean_object*);
size_t lean_array_size(lean_object*);
lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00Lean_mergeStructureResolutionOrders___at___00Lean_computeStructureResolutionOrder___at___00Lean_getStructureResolutionOrder___at___00Lean_getAllParentStructures___at___00__private_Lean_Server_Completion_CompletionUtils_0__Lean_Server_Completion_getDotCompletionTypeNames_visit_spec__0_spec__0_spec__1_spec__4_spec__16___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_CheckedExport_M_run___redArg(lean_object*, lean_object*);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_initState(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Environment_constants(lean_object*);
lean_object* l_Lean_SMap_fold___at___00Lean_SMap_toList___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_getQualified_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_dumpMetadata___redArg(lean_object*);
lean_object* lp_proofEnvironment_dumpName(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_dumpUparams(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_dumpExpr(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* l_Lean_NameHashSet_insert(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(lean_object*, lean_object*);
uint8_t lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lean_io_prim_handle_mk(lean_object*, uint8_t);
lean_object* lean_stream_of_handle(lean_object*);
lean_object* lean_elab_environment_to_kernel_env(lean_object*);
lean_object* lean_io_prim_handle_flush(lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_readPacket(lean_object*, uint8_t);
lean_object* lp_proofEnvironment_OCMEnvironment_checkedMap(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(lean_object*, size_t, size_t, lean_object*);
lean_object* lp_proofEnvironment_M_run___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Json_setObjVal_x21(lean_object*, lean_object*, lean_object*);
lean_object* lp_proofEnvironment_OCMEnvironment_namesJson(lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___00Lean_Server_FileWorker_instFromJsonAbsoluteLspSemanticToken_fromJson_spec__2(lean_object*, lean_object*);
lean_object* l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(lean_object*);
uint8_t lean_expr_eqv(lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___00Lean_Firefox_instFromJsonStackTable_fromJson_spec__0(lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
uint8_t l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(lean_object*, lean_object*);
uint8_t lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2(lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* l_IO_FS_writeFile(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_writeJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "\n"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeJson___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeJson___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeJson(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeJson___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "SERIALIZED_DECLARATION_MISMATCH "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "SERIALIZED_MISSING "};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "SERIALIZED_MEMBERSHIP_SIZE"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "SERIALIZED_UNIVERSE_INDEX"};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__0_value)}};
static const lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__0;
static lean_once_cell_t lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__1;
static const lean_string_object lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "target"};
static const lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__2 = (const lean_object*)&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__2_value;
static const lean_string_object lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "target_name_index"};
static const lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__3 = (const lean_object*)&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__3_value;
static const lean_string_object lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "target_level_params"};
static const lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__4 = (const lean_object*)&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__4_value;
static const lean_string_object lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "target_root"};
static const lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__5 = (const lean_object*)&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__0___boxed, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___closed__0 = (const lean_object*)&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___closed__0_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "SERIALIZED_TARGET_MISMATCH"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "SERIALIZED_UNIVERSES"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__2_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "SERIALIZED_TARGET_NAME"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__4_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "SERIALIZED_TARGET_ROOT"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_writeExpression___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__6_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_writeExpression___closed__7_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "schema"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 38, .m_capacity = 38, .m_length = 37, .m_data = "ocm.proof-environment.registration.v1"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__1_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_registration___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__1_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "allowed"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "axioms"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__4_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "max_heartbeats"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "max_rec_depth"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__6_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "normalization"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_registration___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 68, .m_capacity = 68, .m_length = 67, .m_data = "lean4export-3.1.0:metadata-erasure,let-nondep-false,alpha-interning"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_registration___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__8_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_registration___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__9_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_registration(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_inventory_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_inventory_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1_spec__1(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1(lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_inventory___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "ocm.proof-environment.inventory.v1"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_inventory___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_inventory___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_inventory___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__1_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_inventory___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_registration___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__1_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_inventory___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_inventory___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "names"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_inventory___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_inventory___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "edges"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_inventory___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_inventory___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_inventory(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeJson(lean_object* v_path_2_, lean_object* v_j_3_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; 
v___x_5_ = l_Lean_Json_compress(v_j_3_);
v___x_6_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_writeJson___closed__0));
v___x_7_ = lean_string_append(v___x_5_, v___x_6_);
v___x_8_ = l_IO_FS_writeFile(v_path_2_, v___x_7_);
lean_dec_ref(v___x_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeJson___boxed(lean_object* v_path_9_, lean_object* v_j_10_, lean_object* v_a_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_proofEnvironment_OCMEnvironment_writeJson(v_path_9_, v_j_10_);
lean_dec_ref(v_path_9_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg(lean_object* v_a_15_, lean_object* v___x_16_, lean_object* v___x_17_, lean_object* v_as_x27_18_, lean_object* v_b_19_){
_start:
{
if (lean_obj_tag(v_as_x27_18_) == 0)
{
lean_object* v___x_21_; 
v___x_21_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_21_, 0, v_b_19_);
return v___x_21_;
}
else
{
lean_object* v_head_22_; lean_object* v_state_23_; lean_object* v_tail_24_; lean_object* v_fst_25_; lean_object* v_snd_26_; lean_object* v_constMap_27_; uint8_t v___x_28_; lean_object* v___x_29_; 
v_head_22_ = lean_ctor_get(v_as_x27_18_, 0);
v_state_23_ = lean_ctor_get(v_a_15_, 0);
v_tail_24_ = lean_ctor_get(v_as_x27_18_, 1);
v_fst_25_ = lean_ctor_get(v_head_22_, 0);
v_snd_26_ = lean_ctor_get(v_head_22_, 1);
v_constMap_27_ = lean_ctor_get(v_state_23_, 5);
v___x_28_ = lean_nat_dec_eq(v___x_16_, v___x_17_);
v___x_29_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Compiler_LCNF_EmitC_0__Lean_Compiler_LCNF_Arg_toCString_spec__0___redArg(v_constMap_27_, v_fst_25_);
if (lean_obj_tag(v___x_29_) == 1)
{
lean_object* v_val_30_; lean_object* v___x_32_; uint8_t v_isShared_33_; uint8_t v_isSharedCheck_44_; 
v_val_30_ = lean_ctor_get(v___x_29_, 0);
v_isSharedCheck_44_ = !lean_is_exclusive(v___x_29_);
if (v_isSharedCheck_44_ == 0)
{
v___x_32_ = v___x_29_;
v_isShared_33_ = v_isSharedCheck_44_;
goto v_resetjp_31_;
}
else
{
lean_inc(v_val_30_);
lean_dec(v___x_29_);
v___x_32_ = lean_box(0);
v_isShared_33_ = v_isSharedCheck_44_;
goto v_resetjp_31_;
}
v_resetjp_31_:
{
uint8_t v___x_34_; 
v___x_34_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_snd_26_, v_val_30_);
lean_dec(v_val_30_);
if (v___x_34_ == 0)
{
lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_39_; 
v___x_35_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__0));
lean_inc(v_fst_25_);
v___x_36_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_25_, v___x_28_);
v___x_37_ = lean_string_append(v___x_35_, v___x_36_);
lean_dec_ref(v___x_36_);
if (v_isShared_33_ == 0)
{
lean_ctor_set_tag(v___x_32_, 18);
lean_ctor_set(v___x_32_, 0, v___x_37_);
v___x_39_ = v___x_32_;
goto v_reusejp_38_;
}
else
{
lean_object* v_reuseFailAlloc_41_; 
v_reuseFailAlloc_41_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_41_, 0, v___x_37_);
v___x_39_ = v_reuseFailAlloc_41_;
goto v_reusejp_38_;
}
v_reusejp_38_:
{
lean_object* v___x_40_; 
v___x_40_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_40_, 0, v___x_39_);
return v___x_40_;
}
}
else
{
lean_object* v___x_42_; 
lean_del_object(v___x_32_);
v___x_42_ = lean_box(0);
v_as_x27_18_ = v_tail_24_;
v_b_19_ = v___x_42_;
goto _start;
}
}
}
else
{
lean_object* v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; 
lean_dec(v___x_29_);
v___x_45_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___closed__1));
lean_inc(v_fst_25_);
v___x_46_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_25_, v___x_28_);
v___x_47_ = lean_string_append(v___x_45_, v___x_46_);
lean_dec_ref(v___x_46_);
v___x_48_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_48_, 0, v___x_47_);
v___x_49_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_49_, 0, v___x_48_);
return v___x_49_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg___boxed(lean_object* v_a_50_, lean_object* v___x_51_, lean_object* v___x_52_, lean_object* v_as_x27_53_, lean_object* v_b_54_, lean_object* v___y_55_){
_start:
{
lean_object* v_res_56_; 
v_res_56_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg(v_a_50_, v___x_51_, v___x_52_, v_as_x27_53_, v_b_54_);
lean_dec(v_as_x27_53_);
lean_dec(v___x_52_);
lean_dec(v___x_51_);
lean_dec_ref(v_a_50_);
return v_res_56_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0(lean_object* v_a_57_, lean_object* v___x_58_, lean_object* v___x_59_, lean_object* v_as_60_, lean_object* v_as_x27_61_, lean_object* v_b_62_, lean_object* v_a_63_){
_start:
{
lean_object* v___x_65_; 
v___x_65_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg(v_a_57_, v___x_58_, v___x_59_, v_as_x27_61_, v_b_62_);
return v___x_65_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___boxed(lean_object* v_a_66_, lean_object* v___x_67_, lean_object* v___x_68_, lean_object* v_as_69_, lean_object* v_as_x27_70_, lean_object* v_b_71_, lean_object* v_a_72_, lean_object* v___y_73_){
_start:
{
lean_object* v_res_74_; 
v_res_74_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0(v_a_66_, v___x_67_, v___x_68_, v_as_69_, v_as_x27_70_, v_b_71_, v_a_72_);
lean_dec(v_as_x27_70_);
lean_dec(v_as_69_);
lean_dec(v___x_68_);
lean_dec(v___x_67_);
lean_dec_ref(v_a_66_);
return v_res_74_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__0(lean_object* v___x_75_, lean_object* v___x_76_, lean_object* v_names_77_, lean_object* v___y_78_, lean_object* v___y_79_){
_start:
{
lean_object* v___x_81_; 
v___x_81_ = lp_proofEnvironment_CheckedExport_initState(v___x_75_, v___x_76_, v___y_78_, v___y_79_);
if (lean_obj_tag(v___x_81_) == 0)
{
lean_object* v_a_82_; lean_object* v_snd_83_; lean_object* v___x_84_; 
v_a_82_ = lean_ctor_get(v___x_81_, 0);
lean_inc(v_a_82_);
lean_dec_ref_known(v___x_81_, 1);
v_snd_83_ = lean_ctor_get(v_a_82_, 1);
lean_inc(v_snd_83_);
lean_dec(v_a_82_);
v___x_84_ = lp_proofEnvironment_CheckedExport_dumpMetadata___redArg(v_snd_83_);
if (lean_obj_tag(v___x_84_) == 0)
{
lean_object* v_a_85_; lean_object* v_snd_86_; lean_object* v___y_88_; lean_object* v___x_110_; lean_object* v___y_112_; lean_object* v___y_113_; lean_object* v___x_115_; uint8_t v___x_116_; 
v_a_85_ = lean_ctor_get(v___x_84_, 0);
lean_inc(v_a_85_);
lean_dec_ref_known(v___x_84_, 1);
v_snd_86_ = lean_ctor_get(v_a_85_, 1);
lean_inc(v_snd_86_);
lean_dec(v_a_85_);
v___x_110_ = lean_array_get_size(v_names_77_);
v___x_115_ = lean_unsigned_to_nat(0u);
v___x_116_ = lean_nat_dec_eq(v___x_110_, v___x_115_);
if (v___x_116_ == 0)
{
lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v___y_120_; uint8_t v___x_122_; 
v___x_117_ = lean_unsigned_to_nat(1u);
v___x_118_ = lean_nat_sub(v___x_110_, v___x_117_);
v___x_122_ = lean_nat_dec_le(v___x_115_, v___x_118_);
if (v___x_122_ == 0)
{
lean_inc(v___x_118_);
v___y_120_ = v___x_118_;
goto v___jp_119_;
}
else
{
v___y_120_ = v___x_115_;
goto v___jp_119_;
}
v___jp_119_:
{
uint8_t v___x_121_; 
v___x_121_ = lean_nat_dec_le(v___y_120_, v___x_118_);
if (v___x_121_ == 0)
{
lean_dec(v___x_118_);
lean_inc(v___y_120_);
v___y_112_ = v___y_120_;
v___y_113_ = v___y_120_;
goto v___jp_111_;
}
else
{
v___y_112_ = v___y_120_;
v___y_113_ = v___x_118_;
goto v___jp_111_;
}
}
}
else
{
v___y_88_ = v_names_77_;
goto v___jp_87_;
}
v___jp_87_:
{
lean_object* v___x_89_; size_t v_sz_90_; size_t v___x_91_; lean_object* v___x_92_; 
v___x_89_ = lean_box(0);
v_sz_90_ = lean_array_size(v___y_88_);
v___x_91_ = ((size_t)0ULL);
v___x_92_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00CheckedExport_dumpConstant_dumpDeps_spec__0(v___y_88_, v_sz_90_, v___x_91_, v___x_89_, v___y_78_, v_snd_86_);
lean_dec_ref(v___y_88_);
if (lean_obj_tag(v___x_92_) == 0)
{
lean_object* v_a_93_; lean_object* v___x_95_; uint8_t v_isShared_96_; uint8_t v_isSharedCheck_109_; 
v_a_93_ = lean_ctor_get(v___x_92_, 0);
v_isSharedCheck_109_ = !lean_is_exclusive(v___x_92_);
if (v_isSharedCheck_109_ == 0)
{
v___x_95_ = v___x_92_;
v_isShared_96_ = v_isSharedCheck_109_;
goto v_resetjp_94_;
}
else
{
lean_inc(v_a_93_);
lean_dec(v___x_92_);
v___x_95_ = lean_box(0);
v_isShared_96_ = v_isSharedCheck_109_;
goto v_resetjp_94_;
}
v_resetjp_94_:
{
lean_object* v_snd_97_; lean_object* v___x_99_; uint8_t v_isShared_100_; uint8_t v_isSharedCheck_107_; 
v_snd_97_ = lean_ctor_get(v_a_93_, 1);
v_isSharedCheck_107_ = !lean_is_exclusive(v_a_93_);
if (v_isSharedCheck_107_ == 0)
{
lean_object* v_unused_108_; 
v_unused_108_ = lean_ctor_get(v_a_93_, 0);
lean_dec(v_unused_108_);
v___x_99_ = v_a_93_;
v_isShared_100_ = v_isSharedCheck_107_;
goto v_resetjp_98_;
}
else
{
lean_inc(v_snd_97_);
lean_dec(v_a_93_);
v___x_99_ = lean_box(0);
v_isShared_100_ = v_isSharedCheck_107_;
goto v_resetjp_98_;
}
v_resetjp_98_:
{
lean_object* v___x_102_; 
if (v_isShared_100_ == 0)
{
lean_ctor_set(v___x_99_, 0, v___x_89_);
v___x_102_ = v___x_99_;
goto v_reusejp_101_;
}
else
{
lean_object* v_reuseFailAlloc_106_; 
v_reuseFailAlloc_106_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_106_, 0, v___x_89_);
lean_ctor_set(v_reuseFailAlloc_106_, 1, v_snd_97_);
v___x_102_ = v_reuseFailAlloc_106_;
goto v_reusejp_101_;
}
v_reusejp_101_:
{
lean_object* v___x_104_; 
if (v_isShared_96_ == 0)
{
lean_ctor_set(v___x_95_, 0, v___x_102_);
v___x_104_ = v___x_95_;
goto v_reusejp_103_;
}
else
{
lean_object* v_reuseFailAlloc_105_; 
v_reuseFailAlloc_105_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_105_, 0, v___x_102_);
v___x_104_ = v_reuseFailAlloc_105_;
goto v_reusejp_103_;
}
v_reusejp_103_:
{
return v___x_104_;
}
}
}
}
}
else
{
return v___x_92_;
}
}
v___jp_111_:
{
lean_object* v___x_114_; 
v___x_114_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00Lean_mergeStructureResolutionOrders___at___00Lean_computeStructureResolutionOrder___at___00Lean_getStructureResolutionOrder___at___00Lean_getAllParentStructures___at___00__private_Lean_Server_Completion_CompletionUtils_0__Lean_Server_Completion_getDotCompletionTypeNames_visit_spec__0_spec__0_spec__1_spec__4_spec__16___redArg(v___x_110_, v_names_77_, v___y_112_, v___y_113_);
lean_dec(v___y_113_);
v___y_88_ = v___x_114_;
goto v___jp_87_;
}
}
else
{
lean_dec_ref(v_names_77_);
return v___x_84_;
}
}
else
{
lean_dec_ref(v_names_77_);
return v___x_81_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__0___boxed(lean_object* v___x_123_, lean_object* v___x_124_, lean_object* v_names_125_, lean_object* v___y_126_, lean_object* v___y_127_, lean_object* v___y_128_){
_start:
{
lean_object* v_res_129_; 
v_res_129_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__0(v___x_123_, v___x_124_, v_names_125_, v___y_126_, v___y_127_);
lean_dec_ref(v___y_126_);
lean_dec(v___x_124_);
return v_res_129_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1(lean_object* v_val_130_, lean_object* v___x_131_, lean_object* v_x_132_){
_start:
{
lean_object* v___x_134_; lean_object* v___x_135_; 
v___x_134_ = lean_get_set_stdout(v_val_130_);
lean_dec_ref(v___x_134_);
v___x_135_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_135_, 0, v___x_131_);
return v___x_135_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1___boxed(lean_object* v_val_136_, lean_object* v___x_137_, lean_object* v_x_138_, lean_object* v___y_139_){
_start:
{
lean_object* v_res_140_; 
v_res_140_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1(v_val_136_, v___x_137_, v_x_138_);
lean_dec(v_x_138_);
return v_res_140_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1(lean_object* v___x_141_, lean_object* v_names_142_, lean_object* v_h_143_){
_start:
{
lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___f_147_; lean_object* v___x_148_; lean_object* v_r_149_; 
v___x_145_ = lean_get_set_stdout(v_h_143_);
v___x_146_ = lean_box(0);
lean_inc_ref(v___x_141_);
v___f_147_ = lean_alloc_closure((void*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__0___boxed), 6, 3);
lean_closure_set(v___f_147_, 0, v___x_141_);
lean_closure_set(v___f_147_, 1, v___x_146_);
lean_closure_set(v___f_147_, 2, v_names_142_);
v___x_148_ = lean_box(0);
v_r_149_ = lp_proofEnvironment_CheckedExport_M_run___redArg(v___x_141_, v___f_147_);
if (lean_obj_tag(v_r_149_) == 0)
{
lean_object* v_a_150_; lean_object* v___x_152_; uint8_t v_isShared_153_; uint8_t v_isSharedCheck_166_; 
v_a_150_ = lean_ctor_get(v_r_149_, 0);
v_isSharedCheck_166_ = !lean_is_exclusive(v_r_149_);
if (v_isSharedCheck_166_ == 0)
{
v___x_152_ = v_r_149_;
v_isShared_153_ = v_isSharedCheck_166_;
goto v_resetjp_151_;
}
else
{
lean_inc(v_a_150_);
lean_dec(v_r_149_);
v___x_152_ = lean_box(0);
v_isShared_153_ = v_isSharedCheck_166_;
goto v_resetjp_151_;
}
v_resetjp_151_:
{
lean_object* v___x_155_; 
lean_inc(v_a_150_);
if (v_isShared_153_ == 0)
{
lean_ctor_set_tag(v___x_152_, 1);
v___x_155_ = v___x_152_;
goto v_reusejp_154_;
}
else
{
lean_object* v_reuseFailAlloc_165_; 
v_reuseFailAlloc_165_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_165_, 0, v_a_150_);
v___x_155_ = v_reuseFailAlloc_165_;
goto v_reusejp_154_;
}
v_reusejp_154_:
{
lean_object* v___x_156_; lean_object* v___x_158_; uint8_t v_isShared_159_; uint8_t v_isSharedCheck_163_; 
v___x_156_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1(v___x_145_, v___x_148_, v___x_155_);
lean_dec_ref(v___x_155_);
v_isSharedCheck_163_ = !lean_is_exclusive(v___x_156_);
if (v_isSharedCheck_163_ == 0)
{
lean_object* v_unused_164_; 
v_unused_164_ = lean_ctor_get(v___x_156_, 0);
lean_dec(v_unused_164_);
v___x_158_ = v___x_156_;
v_isShared_159_ = v_isSharedCheck_163_;
goto v_resetjp_157_;
}
else
{
lean_dec(v___x_156_);
v___x_158_ = lean_box(0);
v_isShared_159_ = v_isSharedCheck_163_;
goto v_resetjp_157_;
}
v_resetjp_157_:
{
lean_object* v___x_161_; 
if (v_isShared_159_ == 0)
{
lean_ctor_set(v___x_158_, 0, v_a_150_);
v___x_161_ = v___x_158_;
goto v_reusejp_160_;
}
else
{
lean_object* v_reuseFailAlloc_162_; 
v_reuseFailAlloc_162_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_162_, 0, v_a_150_);
v___x_161_ = v_reuseFailAlloc_162_;
goto v_reusejp_160_;
}
v_reusejp_160_:
{
return v___x_161_;
}
}
}
}
}
else
{
lean_object* v_a_167_; lean_object* v___x_168_; lean_object* v___x_169_; lean_object* v___x_171_; uint8_t v_isShared_172_; uint8_t v_isSharedCheck_176_; 
v_a_167_ = lean_ctor_get(v_r_149_, 0);
lean_inc(v_a_167_);
lean_dec_ref_known(v_r_149_, 1);
v___x_168_ = lean_box(0);
v___x_169_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___lam__1(v___x_145_, v___x_148_, v___x_168_);
v_isSharedCheck_176_ = !lean_is_exclusive(v___x_169_);
if (v_isSharedCheck_176_ == 0)
{
lean_object* v_unused_177_; 
v_unused_177_ = lean_ctor_get(v___x_169_, 0);
lean_dec(v_unused_177_);
v___x_171_ = v___x_169_;
v_isShared_172_ = v_isSharedCheck_176_;
goto v_resetjp_170_;
}
else
{
lean_dec(v___x_169_);
v___x_171_ = lean_box(0);
v_isShared_172_ = v_isSharedCheck_176_;
goto v_resetjp_170_;
}
v_resetjp_170_:
{
lean_object* v___x_174_; 
if (v_isShared_172_ == 0)
{
lean_ctor_set_tag(v___x_171_, 1);
lean_ctor_set(v___x_171_, 0, v_a_167_);
v___x_174_ = v___x_171_;
goto v_reusejp_173_;
}
else
{
lean_object* v_reuseFailAlloc_175_; 
v_reuseFailAlloc_175_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_175_, 0, v_a_167_);
v___x_174_ = v_reuseFailAlloc_175_;
goto v_reusejp_173_;
}
v_reusejp_173_:
{
return v___x_174_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1___boxed(lean_object* v___x_178_, lean_object* v_names_179_, lean_object* v_h_180_, lean_object* v___y_181_){
_start:
{
lean_object* v_res_182_; 
v_res_182_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1(v___x_178_, v_names_179_, v_h_180_);
return v_res_182_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment(lean_object* v_path_186_, lean_object* v_env_187_, lean_object* v_names_188_){
_start:
{
uint8_t v___x_190_; lean_object* v___x_191_; 
v___x_190_ = 1;
v___x_191_ = lean_io_prim_handle_mk(v_path_186_, v___x_190_);
if (lean_obj_tag(v___x_191_) == 0)
{
lean_object* v_a_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; 
v_a_192_ = lean_ctor_get(v___x_191_, 0);
lean_inc_n(v_a_192_, 2);
lean_dec_ref_known(v___x_191_, 1);
v___x_193_ = lean_stream_of_handle(v_a_192_);
lean_inc_ref(v_env_187_);
v___x_194_ = lean_elab_environment_to_kernel_env(v_env_187_);
v___x_195_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeEnvironment_spec__1(v___x_194_, v_names_188_, v___x_193_);
if (lean_obj_tag(v___x_195_) == 0)
{
lean_object* v___x_196_; 
lean_dec_ref_known(v___x_195_, 1);
v___x_196_ = lean_io_prim_handle_flush(v_a_192_);
lean_dec(v_a_192_);
if (lean_obj_tag(v___x_196_) == 0)
{
uint8_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_196_, 1);
v___x_197_ = 0;
v___x_198_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_path_186_, v___x_197_);
if (lean_obj_tag(v___x_198_) == 0)
{
lean_object* v_a_199_; lean_object* v___x_201_; uint8_t v_isShared_202_; uint8_t v_isSharedCheck_233_; 
v_a_199_ = lean_ctor_get(v___x_198_, 0);
v_isSharedCheck_233_ = !lean_is_exclusive(v___x_198_);
if (v_isSharedCheck_233_ == 0)
{
v___x_201_ = v___x_198_;
v_isShared_202_ = v_isSharedCheck_233_;
goto v_resetjp_200_;
}
else
{
lean_inc(v_a_199_);
lean_dec(v___x_198_);
v___x_201_ = lean_box(0);
v_isShared_202_ = v_isSharedCheck_233_;
goto v_resetjp_200_;
}
v_resetjp_200_:
{
lean_object* v_state_203_; lean_object* v_constMap_204_; lean_object* v_size_205_; lean_object* v___x_206_; lean_object* v_size_207_; lean_object* v_buckets_208_; lean_object* v___y_210_; uint8_t v___x_221_; 
v_state_203_ = lean_ctor_get(v_a_199_, 0);
v_constMap_204_ = lean_ctor_get(v_state_203_, 5);
v_size_205_ = lean_ctor_get(v_constMap_204_, 0);
lean_inc(v_size_205_);
v___x_206_ = lp_proofEnvironment_OCMEnvironment_checkedMap(v_env_187_);
v_size_207_ = lean_ctor_get(v___x_206_, 0);
lean_inc(v_size_207_);
v_buckets_208_ = lean_ctor_get(v___x_206_, 1);
lean_inc_ref(v_buckets_208_);
lean_dec_ref(v___x_206_);
v___x_221_ = lean_nat_dec_eq(v_size_205_, v_size_207_);
if (v___x_221_ == 0)
{
lean_object* v___x_222_; lean_object* v___x_224_; 
lean_dec_ref(v_buckets_208_);
lean_dec(v_size_207_);
lean_dec(v_size_205_);
lean_dec(v_a_199_);
v___x_222_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_writeEnvironment___closed__1));
if (v_isShared_202_ == 0)
{
lean_ctor_set_tag(v___x_201_, 1);
lean_ctor_set(v___x_201_, 0, v___x_222_);
v___x_224_ = v___x_201_;
goto v_reusejp_223_;
}
else
{
lean_object* v_reuseFailAlloc_225_; 
v_reuseFailAlloc_225_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_225_, 0, v___x_222_);
v___x_224_ = v_reuseFailAlloc_225_;
goto v_reusejp_223_;
}
v_reusejp_223_:
{
return v___x_224_;
}
}
else
{
lean_object* v___x_226_; lean_object* v___x_227_; lean_object* v___x_228_; uint8_t v___x_229_; 
lean_del_object(v___x_201_);
v___x_226_ = lean_box(0);
v___x_227_ = lean_array_get_size(v_buckets_208_);
v___x_228_ = lean_unsigned_to_nat(0u);
v___x_229_ = lean_nat_dec_lt(v___x_228_, v___x_227_);
if (v___x_229_ == 0)
{
lean_dec_ref(v_buckets_208_);
v___y_210_ = v___x_226_;
goto v___jp_209_;
}
else
{
size_t v___x_230_; size_t v___x_231_; lean_object* v___x_232_; 
v___x_230_ = lean_usize_of_nat(v___x_227_);
v___x_231_ = ((size_t)0ULL);
v___x_232_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(v_buckets_208_, v___x_230_, v___x_231_, v___x_226_);
lean_dec_ref(v_buckets_208_);
v___y_210_ = v___x_232_;
goto v___jp_209_;
}
}
v___jp_209_:
{
lean_object* v___x_211_; lean_object* v___x_212_; 
v___x_211_ = lean_box(0);
v___x_212_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_writeEnvironment_spec__0___redArg(v_a_199_, v_size_205_, v_size_207_, v___y_210_, v___x_211_);
lean_dec(v___y_210_);
lean_dec(v_size_207_);
lean_dec(v_size_205_);
lean_dec(v_a_199_);
if (lean_obj_tag(v___x_212_) == 0)
{
lean_object* v___x_214_; uint8_t v_isShared_215_; uint8_t v_isSharedCheck_219_; 
v_isSharedCheck_219_ = !lean_is_exclusive(v___x_212_);
if (v_isSharedCheck_219_ == 0)
{
lean_object* v_unused_220_; 
v_unused_220_ = lean_ctor_get(v___x_212_, 0);
lean_dec(v_unused_220_);
v___x_214_ = v___x_212_;
v_isShared_215_ = v_isSharedCheck_219_;
goto v_resetjp_213_;
}
else
{
lean_dec(v___x_212_);
v___x_214_ = lean_box(0);
v_isShared_215_ = v_isSharedCheck_219_;
goto v_resetjp_213_;
}
v_resetjp_213_:
{
lean_object* v___x_217_; 
if (v_isShared_215_ == 0)
{
lean_ctor_set(v___x_214_, 0, v___x_211_);
v___x_217_ = v___x_214_;
goto v_reusejp_216_;
}
else
{
lean_object* v_reuseFailAlloc_218_; 
v_reuseFailAlloc_218_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_218_, 0, v___x_211_);
v___x_217_ = v_reuseFailAlloc_218_;
goto v_reusejp_216_;
}
v_reusejp_216_:
{
return v___x_217_;
}
}
}
else
{
return v___x_212_;
}
}
}
}
else
{
lean_object* v_a_234_; lean_object* v___x_236_; uint8_t v_isShared_237_; uint8_t v_isSharedCheck_241_; 
lean_dec_ref(v_env_187_);
v_a_234_ = lean_ctor_get(v___x_198_, 0);
v_isSharedCheck_241_ = !lean_is_exclusive(v___x_198_);
if (v_isSharedCheck_241_ == 0)
{
v___x_236_ = v___x_198_;
v_isShared_237_ = v_isSharedCheck_241_;
goto v_resetjp_235_;
}
else
{
lean_inc(v_a_234_);
lean_dec(v___x_198_);
v___x_236_ = lean_box(0);
v_isShared_237_ = v_isSharedCheck_241_;
goto v_resetjp_235_;
}
v_resetjp_235_:
{
lean_object* v___x_239_; 
if (v_isShared_237_ == 0)
{
v___x_239_ = v___x_236_;
goto v_reusejp_238_;
}
else
{
lean_object* v_reuseFailAlloc_240_; 
v_reuseFailAlloc_240_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_240_, 0, v_a_234_);
v___x_239_ = v_reuseFailAlloc_240_;
goto v_reusejp_238_;
}
v_reusejp_238_:
{
return v___x_239_;
}
}
}
}
else
{
lean_dec_ref(v_env_187_);
return v___x_196_;
}
}
else
{
lean_dec(v_a_192_);
lean_dec_ref(v_env_187_);
return v___x_195_;
}
}
else
{
lean_object* v_a_242_; lean_object* v___x_244_; uint8_t v_isShared_245_; uint8_t v_isSharedCheck_249_; 
lean_dec_ref(v_names_188_);
lean_dec_ref(v_env_187_);
v_a_242_ = lean_ctor_get(v___x_191_, 0);
v_isSharedCheck_249_ = !lean_is_exclusive(v___x_191_);
if (v_isSharedCheck_249_ == 0)
{
v___x_244_ = v___x_191_;
v_isShared_245_ = v_isSharedCheck_249_;
goto v_resetjp_243_;
}
else
{
lean_inc(v_a_242_);
lean_dec(v___x_191_);
v___x_244_ = lean_box(0);
v_isShared_245_ = v_isSharedCheck_249_;
goto v_resetjp_243_;
}
v_resetjp_243_:
{
lean_object* v___x_247_; 
if (v_isShared_245_ == 0)
{
v___x_247_ = v___x_244_;
goto v_reusejp_246_;
}
else
{
lean_object* v_reuseFailAlloc_248_; 
v_reuseFailAlloc_248_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_248_, 0, v_a_242_);
v___x_247_ = v_reuseFailAlloc_248_;
goto v_reusejp_246_;
}
v_reusejp_246_:
{
return v___x_247_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeEnvironment___boxed(lean_object* v_path_250_, lean_object* v_env_251_, lean_object* v_names_252_, lean_object* v_a_253_){
_start:
{
lean_object* v_res_254_; 
v_res_254_ = lp_proofEnvironment_OCMEnvironment_writeEnvironment(v_path_250_, v_env_251_, v_names_252_);
lean_dec_ref(v_path_250_);
return v_res_254_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0(lean_object* v_a_258_, lean_object* v_x_259_, lean_object* v_x_260_){
_start:
{
if (lean_obj_tag(v_x_259_) == 0)
{
lean_object* v___x_262_; lean_object* v___x_263_; 
v___x_262_ = l_List_reverse___redArg(v_x_260_);
v___x_263_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_263_, 0, v___x_262_);
return v___x_263_;
}
else
{
lean_object* v_state_264_; lean_object* v_head_265_; lean_object* v_tail_266_; lean_object* v___x_268_; uint8_t v_isShared_269_; uint8_t v_isSharedCheck_279_; 
v_state_264_ = lean_ctor_get(v_a_258_, 0);
v_head_265_ = lean_ctor_get(v_x_259_, 0);
v_tail_266_ = lean_ctor_get(v_x_259_, 1);
v_isSharedCheck_279_ = !lean_is_exclusive(v_x_259_);
if (v_isSharedCheck_279_ == 0)
{
v___x_268_ = v_x_259_;
v_isShared_269_ = v_isSharedCheck_279_;
goto v_resetjp_267_;
}
else
{
lean_inc(v_tail_266_);
lean_inc(v_head_265_);
lean_dec(v_x_259_);
v___x_268_ = lean_box(0);
v_isShared_269_ = v_isSharedCheck_279_;
goto v_resetjp_267_;
}
v_resetjp_267_:
{
lean_object* v_nameMap_270_; lean_object* v___x_271_; 
v_nameMap_270_ = lean_ctor_get(v_state_264_, 1);
v___x_271_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_270_, v_head_265_);
lean_dec(v_head_265_);
if (lean_obj_tag(v___x_271_) == 1)
{
lean_object* v_val_272_; lean_object* v___x_274_; 
v_val_272_ = lean_ctor_get(v___x_271_, 0);
lean_inc(v_val_272_);
lean_dec_ref_known(v___x_271_, 1);
if (v_isShared_269_ == 0)
{
lean_ctor_set(v___x_268_, 1, v_x_260_);
lean_ctor_set(v___x_268_, 0, v_val_272_);
v___x_274_ = v___x_268_;
goto v_reusejp_273_;
}
else
{
lean_object* v_reuseFailAlloc_276_; 
v_reuseFailAlloc_276_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_276_, 0, v_val_272_);
lean_ctor_set(v_reuseFailAlloc_276_, 1, v_x_260_);
v___x_274_ = v_reuseFailAlloc_276_;
goto v_reusejp_273_;
}
v_reusejp_273_:
{
v_x_259_ = v_tail_266_;
v_x_260_ = v___x_274_;
goto _start;
}
}
else
{
lean_object* v___x_277_; lean_object* v___x_278_; 
lean_dec(v___x_271_);
lean_del_object(v___x_268_);
lean_dec(v_tail_266_);
lean_dec(v_x_260_);
v___x_277_ = ((lean_object*)(lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___closed__1));
v___x_278_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_278_, 0, v___x_277_);
return v___x_278_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0___boxed(lean_object* v_a_280_, lean_object* v_x_281_, lean_object* v_x_282_, lean_object* v___y_283_){
_start:
{
lean_object* v_res_284_; 
v_res_284_ = lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0(v_a_280_, v_x_281_, v_x_282_);
lean_dec_ref(v_a_280_);
return v_res_284_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__0(lean_object* v_ns_285_, lean_object* v_n_286_, lean_object* v_x_287_){
_start:
{
lean_object* v___x_288_; 
v___x_288_ = l_Lean_NameHashSet_insert(v_ns_285_, v_n_286_);
return v___x_288_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__0___boxed(lean_object* v_ns_289_, lean_object* v_n_290_, lean_object* v_x_291_){
_start:
{
lean_object* v_res_292_; 
v_res_292_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__0(v_ns_289_, v_n_290_, v_x_291_);
lean_dec_ref(v_x_291_);
return v_res_292_;
}
}
static lean_object* _init_lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__0(void){
_start:
{
lean_object* v___x_293_; lean_object* v___x_294_; lean_object* v___x_295_; 
v___x_293_ = lean_box(0);
v___x_294_ = lean_unsigned_to_nat(16u);
v___x_295_ = lean_mk_array(v___x_294_, v___x_293_);
return v___x_295_;
}
}
static lean_object* _init_lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__1(void){
_start:
{
lean_object* v___x_296_; lean_object* v___x_297_; lean_object* v___x_298_; 
v___x_296_ = lean_obj_once(&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__0, &lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__0_once, _init_lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__0);
v___x_297_ = lean_unsigned_to_nat(0u);
v___x_298_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_298_, 0, v___x_297_);
lean_ctor_set(v___x_298_, 1, v___x_296_);
return v___x_298_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1(lean_object* v_env_303_, lean_object* v___x_304_, lean_object* v___f_305_, lean_object* v_name_306_, lean_object* v_params_307_, lean_object* v_expr_308_, lean_object* v___y_309_, lean_object* v___y_310_){
_start:
{
lean_object* v___x_312_; 
lean_inc_ref(v_env_303_);
v___x_312_ = lp_proofEnvironment_initState(v_env_303_, v___x_304_, v___y_309_, v___y_310_);
if (lean_obj_tag(v___x_312_) == 0)
{
lean_object* v_a_313_; lean_object* v_snd_314_; lean_object* v___x_316_; uint8_t v_isShared_317_; uint8_t v_isSharedCheck_438_; 
v_a_313_ = lean_ctor_get(v___x_312_, 0);
lean_inc(v_a_313_);
lean_dec_ref_known(v___x_312_, 1);
v_snd_314_ = lean_ctor_get(v_a_313_, 1);
v_isSharedCheck_438_ = !lean_is_exclusive(v_a_313_);
if (v_isSharedCheck_438_ == 0)
{
lean_object* v_unused_439_; 
v_unused_439_ = lean_ctor_get(v_a_313_, 0);
lean_dec(v_unused_439_);
v___x_316_ = v_a_313_;
v_isShared_317_ = v_isSharedCheck_438_;
goto v_resetjp_315_;
}
else
{
lean_inc(v_snd_314_);
lean_dec(v_a_313_);
v___x_316_ = lean_box(0);
v_isShared_317_ = v_isSharedCheck_438_;
goto v_resetjp_315_;
}
v_resetjp_315_:
{
lean_object* v_visitedNames_318_; lean_object* v_visitedLevels_319_; lean_object* v_visitedExprs_320_; lean_object* v_noMDataExprs_321_; uint8_t v_exportMData_322_; uint8_t v_exportUnsafe_323_; uint8_t v_ignoreMissing_324_; lean_object* v_recursorMap_325_; lean_object* v___x_327_; uint8_t v_isShared_328_; uint8_t v_isSharedCheck_436_; 
v_visitedNames_318_ = lean_ctor_get(v_snd_314_, 0);
v_visitedLevels_319_ = lean_ctor_get(v_snd_314_, 1);
v_visitedExprs_320_ = lean_ctor_get(v_snd_314_, 2);
v_noMDataExprs_321_ = lean_ctor_get(v_snd_314_, 4);
v_exportMData_322_ = lean_ctor_get_uint8(v_snd_314_, sizeof(void*)*6);
v_exportUnsafe_323_ = lean_ctor_get_uint8(v_snd_314_, sizeof(void*)*6 + 1);
v_ignoreMissing_324_ = lean_ctor_get_uint8(v_snd_314_, sizeof(void*)*6 + 2);
v_recursorMap_325_ = lean_ctor_get(v_snd_314_, 5);
v_isSharedCheck_436_ = !lean_is_exclusive(v_snd_314_);
if (v_isSharedCheck_436_ == 0)
{
lean_object* v_unused_437_; 
v_unused_437_ = lean_ctor_get(v_snd_314_, 3);
lean_dec(v_unused_437_);
v___x_327_ = v_snd_314_;
v_isShared_328_ = v_isSharedCheck_436_;
goto v_resetjp_326_;
}
else
{
lean_inc(v_recursorMap_325_);
lean_inc(v_noMDataExprs_321_);
lean_inc(v_visitedExprs_320_);
lean_inc(v_visitedLevels_319_);
lean_inc(v_visitedNames_318_);
lean_dec(v_snd_314_);
v___x_327_ = lean_box(0);
v_isShared_328_ = v_isSharedCheck_436_;
goto v_resetjp_326_;
}
v_resetjp_326_:
{
lean_object* v___x_329_; lean_object* v___x_330_; lean_object* v___x_331_; lean_object* v___x_333_; 
v___x_329_ = lean_obj_once(&lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__1, &lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__1_once, _init_lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__1);
v___x_330_ = l_Lean_Environment_constants(v_env_303_);
v___x_331_ = l_Lean_SMap_fold___at___00Lean_SMap_toList___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_getQualified_spec__1_spec__2___redArg(v___f_305_, v___x_329_, v___x_330_);
lean_dec_ref(v___x_330_);
if (v_isShared_328_ == 0)
{
lean_ctor_set(v___x_327_, 3, v___x_331_);
v___x_333_ = v___x_327_;
goto v_reusejp_332_;
}
else
{
lean_object* v_reuseFailAlloc_435_; 
v_reuseFailAlloc_435_ = lean_alloc_ctor(0, 6, 3);
lean_ctor_set(v_reuseFailAlloc_435_, 0, v_visitedNames_318_);
lean_ctor_set(v_reuseFailAlloc_435_, 1, v_visitedLevels_319_);
lean_ctor_set(v_reuseFailAlloc_435_, 2, v_visitedExprs_320_);
lean_ctor_set(v_reuseFailAlloc_435_, 3, v___x_331_);
lean_ctor_set(v_reuseFailAlloc_435_, 4, v_noMDataExprs_321_);
lean_ctor_set(v_reuseFailAlloc_435_, 5, v_recursorMap_325_);
lean_ctor_set_uint8(v_reuseFailAlloc_435_, sizeof(void*)*6, v_exportMData_322_);
lean_ctor_set_uint8(v_reuseFailAlloc_435_, sizeof(void*)*6 + 1, v_exportUnsafe_323_);
lean_ctor_set_uint8(v_reuseFailAlloc_435_, sizeof(void*)*6 + 2, v_ignoreMissing_324_);
v___x_333_ = v_reuseFailAlloc_435_;
goto v_reusejp_332_;
}
v_reusejp_332_:
{
lean_object* v___x_334_; 
v___x_334_ = lp_proofEnvironment_dumpMetadata___redArg(v___x_333_);
if (lean_obj_tag(v___x_334_) == 0)
{
lean_object* v_a_335_; lean_object* v_snd_336_; lean_object* v___x_338_; uint8_t v_isShared_339_; uint8_t v_isSharedCheck_425_; 
v_a_335_ = lean_ctor_get(v___x_334_, 0);
lean_inc(v_a_335_);
lean_dec_ref_known(v___x_334_, 1);
v_snd_336_ = lean_ctor_get(v_a_335_, 1);
v_isSharedCheck_425_ = !lean_is_exclusive(v_a_335_);
if (v_isSharedCheck_425_ == 0)
{
lean_object* v_unused_426_; 
v_unused_426_ = lean_ctor_get(v_a_335_, 0);
lean_dec(v_unused_426_);
v___x_338_ = v_a_335_;
v_isShared_339_ = v_isSharedCheck_425_;
goto v_resetjp_337_;
}
else
{
lean_inc(v_snd_336_);
lean_dec(v_a_335_);
v___x_338_ = lean_box(0);
v_isShared_339_ = v_isSharedCheck_425_;
goto v_resetjp_337_;
}
v_resetjp_337_:
{
lean_object* v___x_340_; 
lean_inc(v_name_306_);
v___x_340_ = lp_proofEnvironment_dumpName(v_name_306_, v___y_309_, v_snd_336_);
if (lean_obj_tag(v___x_340_) == 0)
{
lean_object* v_a_341_; lean_object* v_fst_342_; lean_object* v_snd_343_; lean_object* v___x_345_; uint8_t v_isShared_346_; uint8_t v_isSharedCheck_416_; 
v_a_341_ = lean_ctor_get(v___x_340_, 0);
lean_inc(v_a_341_);
lean_dec_ref_known(v___x_340_, 1);
v_fst_342_ = lean_ctor_get(v_a_341_, 0);
v_snd_343_ = lean_ctor_get(v_a_341_, 1);
v_isSharedCheck_416_ = !lean_is_exclusive(v_a_341_);
if (v_isSharedCheck_416_ == 0)
{
v___x_345_ = v_a_341_;
v_isShared_346_ = v_isSharedCheck_416_;
goto v_resetjp_344_;
}
else
{
lean_inc(v_snd_343_);
lean_inc(v_fst_342_);
lean_dec(v_a_341_);
v___x_345_ = lean_box(0);
v_isShared_346_ = v_isSharedCheck_416_;
goto v_resetjp_344_;
}
v_resetjp_344_:
{
lean_object* v___x_347_; 
v___x_347_ = lp_proofEnvironment_dumpUparams(v_params_307_, v___y_309_, v_snd_343_);
if (lean_obj_tag(v___x_347_) == 0)
{
lean_object* v_a_348_; lean_object* v___x_350_; uint8_t v_isShared_351_; uint8_t v_isSharedCheck_415_; 
v_a_348_ = lean_ctor_get(v___x_347_, 0);
v_isSharedCheck_415_ = !lean_is_exclusive(v___x_347_);
if (v_isSharedCheck_415_ == 0)
{
v___x_350_ = v___x_347_;
v_isShared_351_ = v_isSharedCheck_415_;
goto v_resetjp_349_;
}
else
{
lean_inc(v_a_348_);
lean_dec(v___x_347_);
v___x_350_ = lean_box(0);
v_isShared_351_ = v_isSharedCheck_415_;
goto v_resetjp_349_;
}
v_resetjp_349_:
{
lean_object* v_fst_352_; lean_object* v_snd_353_; lean_object* v___x_355_; uint8_t v_isShared_356_; uint8_t v_isSharedCheck_414_; 
v_fst_352_ = lean_ctor_get(v_a_348_, 0);
v_snd_353_ = lean_ctor_get(v_a_348_, 1);
v_isSharedCheck_414_ = !lean_is_exclusive(v_a_348_);
if (v_isSharedCheck_414_ == 0)
{
v___x_355_ = v_a_348_;
v_isShared_356_ = v_isSharedCheck_414_;
goto v_resetjp_354_;
}
else
{
lean_inc(v_snd_353_);
lean_inc(v_fst_352_);
lean_dec(v_a_348_);
v___x_355_ = lean_box(0);
v_isShared_356_ = v_isSharedCheck_414_;
goto v_resetjp_354_;
}
v_resetjp_354_:
{
lean_object* v___x_357_; 
v___x_357_ = lp_proofEnvironment_dumpExpr(v_expr_308_, v___y_309_, v_snd_353_);
if (lean_obj_tag(v___x_357_) == 0)
{
lean_object* v_a_358_; lean_object* v___x_360_; uint8_t v_isShared_361_; uint8_t v_isSharedCheck_405_; 
v_a_358_ = lean_ctor_get(v___x_357_, 0);
v_isSharedCheck_405_ = !lean_is_exclusive(v___x_357_);
if (v_isSharedCheck_405_ == 0)
{
v___x_360_ = v___x_357_;
v_isShared_361_ = v_isSharedCheck_405_;
goto v_resetjp_359_;
}
else
{
lean_inc(v_a_358_);
lean_dec(v___x_357_);
v___x_360_ = lean_box(0);
v_isShared_361_ = v_isSharedCheck_405_;
goto v_resetjp_359_;
}
v_resetjp_359_:
{
lean_object* v_fst_362_; lean_object* v_snd_363_; lean_object* v___x_365_; uint8_t v_isShared_366_; uint8_t v_isSharedCheck_404_; 
v_fst_362_ = lean_ctor_get(v_a_358_, 0);
v_snd_363_ = lean_ctor_get(v_a_358_, 1);
v_isSharedCheck_404_ = !lean_is_exclusive(v_a_358_);
if (v_isSharedCheck_404_ == 0)
{
v___x_365_ = v_a_358_;
v_isShared_366_ = v_isSharedCheck_404_;
goto v_resetjp_364_;
}
else
{
lean_inc(v_snd_363_);
lean_inc(v_fst_362_);
lean_dec(v_a_358_);
v___x_365_ = lean_box(0);
v_isShared_366_ = v_isSharedCheck_404_;
goto v_resetjp_364_;
}
v_resetjp_364_:
{
lean_object* v___x_367_; uint8_t v___x_368_; lean_object* v___x_369_; lean_object* v___x_371_; 
v___x_367_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__2));
v___x_368_ = 1;
v___x_369_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_306_, v___x_368_);
if (v_isShared_351_ == 0)
{
lean_ctor_set_tag(v___x_350_, 3);
lean_ctor_set(v___x_350_, 0, v___x_369_);
v___x_371_ = v___x_350_;
goto v_reusejp_370_;
}
else
{
lean_object* v_reuseFailAlloc_403_; 
v_reuseFailAlloc_403_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_403_, 0, v___x_369_);
v___x_371_ = v_reuseFailAlloc_403_;
goto v_reusejp_370_;
}
v_reusejp_370_:
{
lean_object* v___x_373_; 
if (v_isShared_366_ == 0)
{
lean_ctor_set(v___x_365_, 1, v___x_371_);
lean_ctor_set(v___x_365_, 0, v___x_367_);
v___x_373_ = v___x_365_;
goto v_reusejp_372_;
}
else
{
lean_object* v_reuseFailAlloc_402_; 
v_reuseFailAlloc_402_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_402_, 0, v___x_367_);
lean_ctor_set(v_reuseFailAlloc_402_, 1, v___x_371_);
v___x_373_ = v_reuseFailAlloc_402_;
goto v_reusejp_372_;
}
v_reusejp_372_:
{
lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v___x_376_; lean_object* v___x_378_; 
v___x_374_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__3));
v___x_375_ = l_Lean_JsonNumber_fromNat(v_fst_342_);
v___x_376_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_376_, 0, v___x_375_);
if (v_isShared_356_ == 0)
{
lean_ctor_set(v___x_355_, 1, v___x_376_);
lean_ctor_set(v___x_355_, 0, v___x_374_);
v___x_378_ = v___x_355_;
goto v_reusejp_377_;
}
else
{
lean_object* v_reuseFailAlloc_401_; 
v_reuseFailAlloc_401_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_401_, 0, v___x_374_);
lean_ctor_set(v_reuseFailAlloc_401_, 1, v___x_376_);
v___x_378_ = v_reuseFailAlloc_401_;
goto v_reusejp_377_;
}
v_reusejp_377_:
{
lean_object* v___x_379_; lean_object* v___x_381_; 
v___x_379_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__4));
if (v_isShared_346_ == 0)
{
lean_ctor_set(v___x_345_, 1, v_fst_352_);
lean_ctor_set(v___x_345_, 0, v___x_379_);
v___x_381_ = v___x_345_;
goto v_reusejp_380_;
}
else
{
lean_object* v_reuseFailAlloc_400_; 
v_reuseFailAlloc_400_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_400_, 0, v___x_379_);
lean_ctor_set(v_reuseFailAlloc_400_, 1, v_fst_352_);
v___x_381_ = v_reuseFailAlloc_400_;
goto v_reusejp_380_;
}
v_reusejp_380_:
{
lean_object* v___x_382_; lean_object* v___x_383_; lean_object* v___x_384_; lean_object* v___x_386_; 
v___x_382_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__5));
v___x_383_ = l_Lean_JsonNumber_fromNat(v_fst_362_);
v___x_384_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_384_, 0, v___x_383_);
if (v_isShared_339_ == 0)
{
lean_ctor_set(v___x_338_, 1, v___x_384_);
lean_ctor_set(v___x_338_, 0, v___x_382_);
v___x_386_ = v___x_338_;
goto v_reusejp_385_;
}
else
{
lean_object* v_reuseFailAlloc_399_; 
v_reuseFailAlloc_399_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_399_, 0, v___x_382_);
lean_ctor_set(v_reuseFailAlloc_399_, 1, v___x_384_);
v___x_386_ = v_reuseFailAlloc_399_;
goto v_reusejp_385_;
}
v_reusejp_385_:
{
lean_object* v___x_387_; lean_object* v___x_388_; lean_object* v___x_389_; lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_394_; 
v___x_387_ = lean_box(0);
v___x_388_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_388_, 0, v___x_386_);
lean_ctor_set(v___x_388_, 1, v___x_387_);
v___x_389_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_389_, 0, v___x_381_);
lean_ctor_set(v___x_389_, 1, v___x_388_);
v___x_390_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_390_, 0, v___x_378_);
lean_ctor_set(v___x_390_, 1, v___x_389_);
v___x_391_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_391_, 0, v___x_373_);
lean_ctor_set(v___x_391_, 1, v___x_390_);
v___x_392_ = l_Lean_Json_mkObj(v___x_391_);
lean_dec_ref_known(v___x_391_, 2);
if (v_isShared_317_ == 0)
{
lean_ctor_set(v___x_316_, 1, v_snd_363_);
lean_ctor_set(v___x_316_, 0, v___x_392_);
v___x_394_ = v___x_316_;
goto v_reusejp_393_;
}
else
{
lean_object* v_reuseFailAlloc_398_; 
v_reuseFailAlloc_398_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_398_, 0, v___x_392_);
lean_ctor_set(v_reuseFailAlloc_398_, 1, v_snd_363_);
v___x_394_ = v_reuseFailAlloc_398_;
goto v_reusejp_393_;
}
v_reusejp_393_:
{
lean_object* v___x_396_; 
if (v_isShared_361_ == 0)
{
lean_ctor_set(v___x_360_, 0, v___x_394_);
v___x_396_ = v___x_360_;
goto v_reusejp_395_;
}
else
{
lean_object* v_reuseFailAlloc_397_; 
v_reuseFailAlloc_397_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_397_, 0, v___x_394_);
v___x_396_ = v_reuseFailAlloc_397_;
goto v_reusejp_395_;
}
v_reusejp_395_:
{
return v___x_396_;
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_406_; lean_object* v___x_408_; uint8_t v_isShared_409_; uint8_t v_isSharedCheck_413_; 
lean_del_object(v___x_355_);
lean_dec(v_fst_352_);
lean_del_object(v___x_350_);
lean_del_object(v___x_345_);
lean_dec(v_fst_342_);
lean_del_object(v___x_338_);
lean_del_object(v___x_316_);
lean_dec(v_name_306_);
v_a_406_ = lean_ctor_get(v___x_357_, 0);
v_isSharedCheck_413_ = !lean_is_exclusive(v___x_357_);
if (v_isSharedCheck_413_ == 0)
{
v___x_408_ = v___x_357_;
v_isShared_409_ = v_isSharedCheck_413_;
goto v_resetjp_407_;
}
else
{
lean_inc(v_a_406_);
lean_dec(v___x_357_);
v___x_408_ = lean_box(0);
v_isShared_409_ = v_isSharedCheck_413_;
goto v_resetjp_407_;
}
v_resetjp_407_:
{
lean_object* v___x_411_; 
if (v_isShared_409_ == 0)
{
v___x_411_ = v___x_408_;
goto v_reusejp_410_;
}
else
{
lean_object* v_reuseFailAlloc_412_; 
v_reuseFailAlloc_412_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_412_, 0, v_a_406_);
v___x_411_ = v_reuseFailAlloc_412_;
goto v_reusejp_410_;
}
v_reusejp_410_:
{
return v___x_411_;
}
}
}
}
}
}
else
{
lean_del_object(v___x_345_);
lean_dec(v_fst_342_);
lean_del_object(v___x_338_);
lean_del_object(v___x_316_);
lean_dec_ref(v_expr_308_);
lean_dec(v_name_306_);
return v___x_347_;
}
}
}
else
{
lean_object* v_a_417_; lean_object* v___x_419_; uint8_t v_isShared_420_; uint8_t v_isSharedCheck_424_; 
lean_del_object(v___x_338_);
lean_del_object(v___x_316_);
lean_dec_ref(v_expr_308_);
lean_dec(v_params_307_);
lean_dec(v_name_306_);
v_a_417_ = lean_ctor_get(v___x_340_, 0);
v_isSharedCheck_424_ = !lean_is_exclusive(v___x_340_);
if (v_isSharedCheck_424_ == 0)
{
v___x_419_ = v___x_340_;
v_isShared_420_ = v_isSharedCheck_424_;
goto v_resetjp_418_;
}
else
{
lean_inc(v_a_417_);
lean_dec(v___x_340_);
v___x_419_ = lean_box(0);
v_isShared_420_ = v_isSharedCheck_424_;
goto v_resetjp_418_;
}
v_resetjp_418_:
{
lean_object* v___x_422_; 
if (v_isShared_420_ == 0)
{
v___x_422_ = v___x_419_;
goto v_reusejp_421_;
}
else
{
lean_object* v_reuseFailAlloc_423_; 
v_reuseFailAlloc_423_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_423_, 0, v_a_417_);
v___x_422_ = v_reuseFailAlloc_423_;
goto v_reusejp_421_;
}
v_reusejp_421_:
{
return v___x_422_;
}
}
}
}
}
else
{
lean_object* v_a_427_; lean_object* v___x_429_; uint8_t v_isShared_430_; uint8_t v_isSharedCheck_434_; 
lean_del_object(v___x_316_);
lean_dec_ref(v_expr_308_);
lean_dec(v_params_307_);
lean_dec(v_name_306_);
v_a_427_ = lean_ctor_get(v___x_334_, 0);
v_isSharedCheck_434_ = !lean_is_exclusive(v___x_334_);
if (v_isSharedCheck_434_ == 0)
{
v___x_429_ = v___x_334_;
v_isShared_430_ = v_isSharedCheck_434_;
goto v_resetjp_428_;
}
else
{
lean_inc(v_a_427_);
lean_dec(v___x_334_);
v___x_429_ = lean_box(0);
v_isShared_430_ = v_isSharedCheck_434_;
goto v_resetjp_428_;
}
v_resetjp_428_:
{
lean_object* v___x_432_; 
if (v_isShared_430_ == 0)
{
v___x_432_ = v___x_429_;
goto v_reusejp_431_;
}
else
{
lean_object* v_reuseFailAlloc_433_; 
v_reuseFailAlloc_433_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_433_, 0, v_a_427_);
v___x_432_ = v_reuseFailAlloc_433_;
goto v_reusejp_431_;
}
v_reusejp_431_:
{
return v___x_432_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_440_; lean_object* v___x_442_; uint8_t v_isShared_443_; uint8_t v_isSharedCheck_447_; 
lean_dec_ref(v_expr_308_);
lean_dec(v_params_307_);
lean_dec(v_name_306_);
lean_dec_ref(v___f_305_);
lean_dec_ref(v_env_303_);
v_a_440_ = lean_ctor_get(v___x_312_, 0);
v_isSharedCheck_447_ = !lean_is_exclusive(v___x_312_);
if (v_isSharedCheck_447_ == 0)
{
v___x_442_ = v___x_312_;
v_isShared_443_ = v_isSharedCheck_447_;
goto v_resetjp_441_;
}
else
{
lean_inc(v_a_440_);
lean_dec(v___x_312_);
v___x_442_ = lean_box(0);
v_isShared_443_ = v_isSharedCheck_447_;
goto v_resetjp_441_;
}
v_resetjp_441_:
{
lean_object* v___x_445_; 
if (v_isShared_443_ == 0)
{
v___x_445_ = v___x_442_;
goto v_reusejp_444_;
}
else
{
lean_object* v_reuseFailAlloc_446_; 
v_reuseFailAlloc_446_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_446_, 0, v_a_440_);
v___x_445_ = v_reuseFailAlloc_446_;
goto v_reusejp_444_;
}
v_reusejp_444_:
{
return v___x_445_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___boxed(lean_object* v_env_448_, lean_object* v___x_449_, lean_object* v___f_450_, lean_object* v_name_451_, lean_object* v_params_452_, lean_object* v_expr_453_, lean_object* v___y_454_, lean_object* v___y_455_, lean_object* v___y_456_){
_start:
{
lean_object* v_res_457_; 
v_res_457_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1(v_env_448_, v___x_449_, v___f_450_, v_name_451_, v_params_452_, v_expr_453_, v___y_454_, v___y_455_);
lean_dec_ref(v___y_454_);
lean_dec(v___x_449_);
return v_res_457_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2(lean_object* v_val_458_, lean_object* v___x_459_, lean_object* v_x_460_){
_start:
{
lean_object* v___x_462_; lean_object* v___x_463_; 
v___x_462_ = lean_get_set_stdout(v_val_458_);
lean_dec_ref(v___x_462_);
v___x_463_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_463_, 0, v___x_459_);
return v___x_463_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2___boxed(lean_object* v_val_464_, lean_object* v___x_465_, lean_object* v_x_466_, lean_object* v___y_467_){
_start:
{
lean_object* v_res_468_; 
v_res_468_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2(v_val_464_, v___x_465_, v_x_466_);
lean_dec(v_x_466_);
return v_res_468_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1(lean_object* v_env_470_, lean_object* v_name_471_, lean_object* v_params_472_, lean_object* v_expr_473_, lean_object* v_h_474_){
_start:
{
lean_object* v___x_476_; lean_object* v___f_477_; lean_object* v___x_478_; lean_object* v___f_479_; lean_object* v___x_480_; lean_object* v_r_481_; 
v___x_476_ = lean_get_set_stdout(v_h_474_);
v___f_477_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___closed__0));
v___x_478_ = lean_box(0);
lean_inc_ref(v_env_470_);
v___f_479_ = lean_alloc_closure((void*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___boxed), 9, 6);
lean_closure_set(v___f_479_, 0, v_env_470_);
lean_closure_set(v___f_479_, 1, v___x_478_);
lean_closure_set(v___f_479_, 2, v___f_477_);
lean_closure_set(v___f_479_, 3, v_name_471_);
lean_closure_set(v___f_479_, 4, v_params_472_);
lean_closure_set(v___f_479_, 5, v_expr_473_);
v___x_480_ = lean_box(0);
v_r_481_ = lp_proofEnvironment_M_run___redArg(v_env_470_, v___f_479_);
if (lean_obj_tag(v_r_481_) == 0)
{
lean_object* v_a_482_; lean_object* v___x_484_; uint8_t v_isShared_485_; uint8_t v_isSharedCheck_498_; 
v_a_482_ = lean_ctor_get(v_r_481_, 0);
v_isSharedCheck_498_ = !lean_is_exclusive(v_r_481_);
if (v_isSharedCheck_498_ == 0)
{
v___x_484_ = v_r_481_;
v_isShared_485_ = v_isSharedCheck_498_;
goto v_resetjp_483_;
}
else
{
lean_inc(v_a_482_);
lean_dec(v_r_481_);
v___x_484_ = lean_box(0);
v_isShared_485_ = v_isSharedCheck_498_;
goto v_resetjp_483_;
}
v_resetjp_483_:
{
lean_object* v___x_487_; 
lean_inc(v_a_482_);
if (v_isShared_485_ == 0)
{
lean_ctor_set_tag(v___x_484_, 1);
v___x_487_ = v___x_484_;
goto v_reusejp_486_;
}
else
{
lean_object* v_reuseFailAlloc_497_; 
v_reuseFailAlloc_497_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_497_, 0, v_a_482_);
v___x_487_ = v_reuseFailAlloc_497_;
goto v_reusejp_486_;
}
v_reusejp_486_:
{
lean_object* v___x_488_; lean_object* v___x_490_; uint8_t v_isShared_491_; uint8_t v_isSharedCheck_495_; 
v___x_488_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2(v___x_476_, v___x_480_, v___x_487_);
lean_dec_ref(v___x_487_);
v_isSharedCheck_495_ = !lean_is_exclusive(v___x_488_);
if (v_isSharedCheck_495_ == 0)
{
lean_object* v_unused_496_; 
v_unused_496_ = lean_ctor_get(v___x_488_, 0);
lean_dec(v_unused_496_);
v___x_490_ = v___x_488_;
v_isShared_491_ = v_isSharedCheck_495_;
goto v_resetjp_489_;
}
else
{
lean_dec(v___x_488_);
v___x_490_ = lean_box(0);
v_isShared_491_ = v_isSharedCheck_495_;
goto v_resetjp_489_;
}
v_resetjp_489_:
{
lean_object* v___x_493_; 
if (v_isShared_491_ == 0)
{
lean_ctor_set(v___x_490_, 0, v_a_482_);
v___x_493_ = v___x_490_;
goto v_reusejp_492_;
}
else
{
lean_object* v_reuseFailAlloc_494_; 
v_reuseFailAlloc_494_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_494_, 0, v_a_482_);
v___x_493_ = v_reuseFailAlloc_494_;
goto v_reusejp_492_;
}
v_reusejp_492_:
{
return v___x_493_;
}
}
}
}
}
else
{
lean_object* v_a_499_; lean_object* v___x_500_; lean_object* v___x_501_; lean_object* v___x_503_; uint8_t v_isShared_504_; uint8_t v_isSharedCheck_508_; 
v_a_499_ = lean_ctor_get(v_r_481_, 0);
lean_inc(v_a_499_);
lean_dec_ref_known(v_r_481_, 1);
v___x_500_ = lean_box(0);
v___x_501_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__2(v___x_476_, v___x_480_, v___x_500_);
v_isSharedCheck_508_ = !lean_is_exclusive(v___x_501_);
if (v_isSharedCheck_508_ == 0)
{
lean_object* v_unused_509_; 
v_unused_509_ = lean_ctor_get(v___x_501_, 0);
lean_dec(v_unused_509_);
v___x_503_ = v___x_501_;
v_isShared_504_ = v_isSharedCheck_508_;
goto v_resetjp_502_;
}
else
{
lean_dec(v___x_501_);
v___x_503_ = lean_box(0);
v_isShared_504_ = v_isSharedCheck_508_;
goto v_resetjp_502_;
}
v_resetjp_502_:
{
lean_object* v___x_506_; 
if (v_isShared_504_ == 0)
{
lean_ctor_set_tag(v___x_503_, 1);
lean_ctor_set(v___x_503_, 0, v_a_499_);
v___x_506_ = v___x_503_;
goto v_reusejp_505_;
}
else
{
lean_object* v_reuseFailAlloc_507_; 
v_reuseFailAlloc_507_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_507_, 0, v_a_499_);
v___x_506_ = v_reuseFailAlloc_507_;
goto v_reusejp_505_;
}
v_reusejp_505_:
{
return v___x_506_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___boxed(lean_object* v_env_510_, lean_object* v_name_511_, lean_object* v_params_512_, lean_object* v_expr_513_, lean_object* v_h_514_, lean_object* v___y_515_){
_start:
{
lean_object* v_res_516_; 
v_res_516_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1(v_env_510_, v_name_511_, v_params_512_, v_expr_513_, v_h_514_);
return v_res_516_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression(lean_object* v_path_529_, lean_object* v_env_530_, lean_object* v_name_531_, lean_object* v_params_532_, lean_object* v_expr_533_){
_start:
{
uint8_t v___x_535_; lean_object* v___x_536_; 
v___x_535_ = 1;
v___x_536_ = lean_io_prim_handle_mk(v_path_529_, v___x_535_);
if (lean_obj_tag(v___x_536_) == 0)
{
lean_object* v_a_537_; lean_object* v___x_538_; lean_object* v___x_539_; 
v_a_537_ = lean_ctor_get(v___x_536_, 0);
lean_inc_n(v_a_537_, 2);
lean_dec_ref_known(v___x_536_, 1);
v___x_538_ = lean_stream_of_handle(v_a_537_);
lean_inc_ref(v_expr_533_);
lean_inc(v_params_532_);
lean_inc(v_name_531_);
v___x_539_ = lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1(v_env_530_, v_name_531_, v_params_532_, v_expr_533_, v___x_538_);
if (lean_obj_tag(v___x_539_) == 0)
{
lean_object* v_a_540_; lean_object* v___x_541_; 
v_a_540_ = lean_ctor_get(v___x_539_, 0);
lean_inc(v_a_540_);
lean_dec_ref_known(v___x_539_, 1);
v___x_541_ = lean_io_prim_handle_flush(v_a_537_);
lean_dec(v_a_537_);
if (lean_obj_tag(v___x_541_) == 0)
{
uint8_t v___x_542_; lean_object* v___x_543_; 
lean_dec_ref_known(v___x_541_, 1);
v___x_542_ = 1;
v___x_543_ = lp_proofEnvironment_OCMEnvironment_readPacket(v_path_529_, v___x_542_);
if (lean_obj_tag(v___x_543_) == 0)
{
lean_object* v_a_544_; lean_object* v___x_545_; lean_object* v___x_546_; lean_object* v___x_547_; 
v_a_544_ = lean_ctor_get(v___x_543_, 0);
lean_inc(v_a_544_);
lean_dec_ref_known(v___x_543_, 1);
v___x_545_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__5));
lean_inc(v_a_540_);
v___x_546_ = l_Lean_Json_getObjValAs_x3f___at___00Lean_Server_FileWorker_instFromJsonAbsoluteLspSemanticToken_fromJson_spec__2(v_a_540_, v___x_545_);
v___x_547_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_546_);
if (lean_obj_tag(v___x_547_) == 0)
{
lean_object* v_state_548_; lean_object* v_a_549_; lean_object* v___x_551_; uint8_t v_isShared_552_; uint8_t v_isSharedCheck_631_; 
v_state_548_ = lean_ctor_get(v_a_544_, 0);
v_a_549_ = lean_ctor_get(v___x_547_, 0);
v_isSharedCheck_631_ = !lean_is_exclusive(v___x_547_);
if (v_isSharedCheck_631_ == 0)
{
v___x_551_ = v___x_547_;
v_isShared_552_ = v_isSharedCheck_631_;
goto v_resetjp_550_;
}
else
{
lean_inc(v_a_549_);
lean_dec(v___x_547_);
v___x_551_ = lean_box(0);
v_isShared_552_ = v_isSharedCheck_631_;
goto v_resetjp_550_;
}
v_resetjp_550_:
{
lean_object* v_nameMap_553_; lean_object* v_exprMap_554_; lean_object* v___x_555_; 
v_nameMap_553_ = lean_ctor_get(v_state_548_, 1);
lean_inc_ref(v_nameMap_553_);
v_exprMap_554_ = lean_ctor_get(v_state_548_, 3);
v___x_555_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_exprMap_554_, v_a_549_);
lean_dec(v_a_549_);
if (lean_obj_tag(v___x_555_) == 1)
{
lean_object* v_val_556_; lean_object* v___x_558_; uint8_t v_isShared_559_; uint8_t v_isSharedCheck_626_; 
v_val_556_ = lean_ctor_get(v___x_555_, 0);
v_isSharedCheck_626_ = !lean_is_exclusive(v___x_555_);
if (v_isSharedCheck_626_ == 0)
{
v___x_558_ = v___x_555_;
v_isShared_559_ = v_isSharedCheck_626_;
goto v_resetjp_557_;
}
else
{
lean_inc(v_val_556_);
lean_dec(v___x_555_);
v___x_558_ = lean_box(0);
v_isShared_559_ = v_isSharedCheck_626_;
goto v_resetjp_557_;
}
v_resetjp_557_:
{
uint8_t v___x_560_; 
v___x_560_ = lean_expr_eqv(v_val_556_, v_expr_533_);
lean_dec_ref(v_expr_533_);
lean_dec(v_val_556_);
if (v___x_560_ == 0)
{
lean_object* v___x_561_; lean_object* v___x_563_; 
lean_del_object(v___x_558_);
lean_dec_ref(v_nameMap_553_);
lean_dec(v_a_544_);
lean_dec(v_a_540_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v___x_561_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_writeExpression___closed__1));
if (v_isShared_552_ == 0)
{
lean_ctor_set_tag(v___x_551_, 1);
lean_ctor_set(v___x_551_, 0, v___x_561_);
v___x_563_ = v___x_551_;
goto v_reusejp_562_;
}
else
{
lean_object* v_reuseFailAlloc_564_; 
v_reuseFailAlloc_564_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_564_, 0, v___x_561_);
v___x_563_ = v_reuseFailAlloc_564_;
goto v_reusejp_562_;
}
v_reusejp_562_:
{
return v___x_563_;
}
}
else
{
lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; 
lean_del_object(v___x_551_);
v___x_565_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__4));
lean_inc(v_a_540_);
v___x_566_ = l_Lean_Json_getObjValAs_x3f___at___00Lean_Firefox_instFromJsonStackTable_fromJson_spec__0(v_a_540_, v___x_565_);
v___x_567_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_566_);
if (lean_obj_tag(v___x_567_) == 0)
{
lean_object* v_a_568_; lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; 
v_a_568_ = lean_ctor_get(v___x_567_, 0);
lean_inc(v_a_568_);
lean_dec_ref_known(v___x_567_, 1);
v___x_569_ = lean_array_to_list(v_a_568_);
v___x_570_ = lean_box(0);
v___x_571_ = lp_proofEnvironment_List_mapM_loop___at___00OCMEnvironment_writeExpression_spec__0(v_a_544_, v___x_569_, v___x_570_);
lean_dec(v_a_544_);
if (lean_obj_tag(v___x_571_) == 0)
{
lean_object* v_a_572_; lean_object* v___x_574_; uint8_t v_isShared_575_; uint8_t v_isSharedCheck_609_; 
v_a_572_ = lean_ctor_get(v___x_571_, 0);
v_isSharedCheck_609_ = !lean_is_exclusive(v___x_571_);
if (v_isSharedCheck_609_ == 0)
{
v___x_574_ = v___x_571_;
v_isShared_575_ = v_isSharedCheck_609_;
goto v_resetjp_573_;
}
else
{
lean_inc(v_a_572_);
lean_dec(v___x_571_);
v___x_574_ = lean_box(0);
v_isShared_575_ = v_isSharedCheck_609_;
goto v_resetjp_573_;
}
v_resetjp_573_:
{
uint8_t v___x_576_; 
v___x_576_ = l_List_beq___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__4(v_a_572_, v_params_532_);
lean_dec(v_params_532_);
lean_dec(v_a_572_);
if (v___x_576_ == 0)
{
lean_object* v___x_577_; lean_object* v___x_579_; 
lean_del_object(v___x_558_);
lean_dec_ref(v_nameMap_553_);
lean_dec(v_a_540_);
lean_dec(v_name_531_);
v___x_577_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_writeExpression___closed__3));
if (v_isShared_575_ == 0)
{
lean_ctor_set_tag(v___x_574_, 1);
lean_ctor_set(v___x_574_, 0, v___x_577_);
v___x_579_ = v___x_574_;
goto v_reusejp_578_;
}
else
{
lean_object* v_reuseFailAlloc_580_; 
v_reuseFailAlloc_580_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_580_, 0, v___x_577_);
v___x_579_ = v_reuseFailAlloc_580_;
goto v_reusejp_578_;
}
v_reusejp_578_:
{
return v___x_579_;
}
}
else
{
lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; 
lean_del_object(v___x_574_);
v___x_581_ = ((lean_object*)(lp_proofEnvironment_IO_withStdout___at___00IO_FS_withIsolatedStreams___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_lean_runCommand_spec__2_spec__4___at___00OCMEnvironment_writeExpression_spec__1___lam__1___closed__3));
lean_inc(v_a_540_);
v___x_582_ = l_Lean_Json_getObjValAs_x3f___at___00Lean_Server_FileWorker_instFromJsonAbsoluteLspSemanticToken_fromJson_spec__2(v_a_540_, v___x_581_);
v___x_583_ = l_IO_ofExcept___at___00__private_Lean_Elab_Idbg_0__Lean_Idbg_idbgClientLoopImpl_spec__2___redArg(v___x_582_);
if (lean_obj_tag(v___x_583_) == 0)
{
lean_object* v_a_584_; lean_object* v___x_586_; uint8_t v_isShared_587_; uint8_t v_isSharedCheck_600_; 
v_a_584_ = lean_ctor_get(v___x_583_, 0);
v_isSharedCheck_600_ = !lean_is_exclusive(v___x_583_);
if (v_isSharedCheck_600_ == 0)
{
v___x_586_ = v___x_583_;
v_isShared_587_ = v_isSharedCheck_600_;
goto v_resetjp_585_;
}
else
{
lean_inc(v_a_584_);
lean_dec(v___x_583_);
v___x_586_ = lean_box(0);
v_isShared_587_ = v_isSharedCheck_600_;
goto v_resetjp_585_;
}
v_resetjp_585_:
{
lean_object* v___x_588_; lean_object* v___x_590_; 
v___x_588_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Export_Parse_parseNameStr_spec__0___redArg(v_nameMap_553_, v_a_584_);
lean_dec(v_a_584_);
lean_dec_ref(v_nameMap_553_);
if (v_isShared_559_ == 0)
{
lean_ctor_set(v___x_558_, 0, v_name_531_);
v___x_590_ = v___x_558_;
goto v_reusejp_589_;
}
else
{
lean_object* v_reuseFailAlloc_599_; 
v_reuseFailAlloc_599_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_599_, 0, v_name_531_);
v___x_590_ = v_reuseFailAlloc_599_;
goto v_reusejp_589_;
}
v_reusejp_589_:
{
uint8_t v___x_591_; 
v___x_591_ = lp_proofEnvironment_Option_instBEq_beq___at___00OCMEnvironment_validateFamilies_spec__2(v___x_588_, v___x_590_);
lean_dec_ref(v___x_590_);
lean_dec(v___x_588_);
if (v___x_591_ == 0)
{
lean_object* v___x_592_; lean_object* v___x_594_; 
lean_dec(v_a_540_);
v___x_592_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_writeExpression___closed__5));
if (v_isShared_587_ == 0)
{
lean_ctor_set_tag(v___x_586_, 1);
lean_ctor_set(v___x_586_, 0, v___x_592_);
v___x_594_ = v___x_586_;
goto v_reusejp_593_;
}
else
{
lean_object* v_reuseFailAlloc_595_; 
v_reuseFailAlloc_595_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_595_, 0, v___x_592_);
v___x_594_ = v_reuseFailAlloc_595_;
goto v_reusejp_593_;
}
v_reusejp_593_:
{
return v___x_594_;
}
}
else
{
lean_object* v___x_597_; 
if (v_isShared_587_ == 0)
{
lean_ctor_set(v___x_586_, 0, v_a_540_);
v___x_597_ = v___x_586_;
goto v_reusejp_596_;
}
else
{
lean_object* v_reuseFailAlloc_598_; 
v_reuseFailAlloc_598_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_598_, 0, v_a_540_);
v___x_597_ = v_reuseFailAlloc_598_;
goto v_reusejp_596_;
}
v_reusejp_596_:
{
return v___x_597_;
}
}
}
}
}
else
{
lean_object* v_a_601_; lean_object* v___x_603_; uint8_t v_isShared_604_; uint8_t v_isSharedCheck_608_; 
lean_del_object(v___x_558_);
lean_dec_ref(v_nameMap_553_);
lean_dec(v_a_540_);
lean_dec(v_name_531_);
v_a_601_ = lean_ctor_get(v___x_583_, 0);
v_isSharedCheck_608_ = !lean_is_exclusive(v___x_583_);
if (v_isSharedCheck_608_ == 0)
{
v___x_603_ = v___x_583_;
v_isShared_604_ = v_isSharedCheck_608_;
goto v_resetjp_602_;
}
else
{
lean_inc(v_a_601_);
lean_dec(v___x_583_);
v___x_603_ = lean_box(0);
v_isShared_604_ = v_isSharedCheck_608_;
goto v_resetjp_602_;
}
v_resetjp_602_:
{
lean_object* v___x_606_; 
if (v_isShared_604_ == 0)
{
v___x_606_ = v___x_603_;
goto v_reusejp_605_;
}
else
{
lean_object* v_reuseFailAlloc_607_; 
v_reuseFailAlloc_607_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_607_, 0, v_a_601_);
v___x_606_ = v_reuseFailAlloc_607_;
goto v_reusejp_605_;
}
v_reusejp_605_:
{
return v___x_606_;
}
}
}
}
}
}
else
{
lean_object* v_a_610_; lean_object* v___x_612_; uint8_t v_isShared_613_; uint8_t v_isSharedCheck_617_; 
lean_del_object(v___x_558_);
lean_dec_ref(v_nameMap_553_);
lean_dec(v_a_540_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v_a_610_ = lean_ctor_get(v___x_571_, 0);
v_isSharedCheck_617_ = !lean_is_exclusive(v___x_571_);
if (v_isSharedCheck_617_ == 0)
{
v___x_612_ = v___x_571_;
v_isShared_613_ = v_isSharedCheck_617_;
goto v_resetjp_611_;
}
else
{
lean_inc(v_a_610_);
lean_dec(v___x_571_);
v___x_612_ = lean_box(0);
v_isShared_613_ = v_isSharedCheck_617_;
goto v_resetjp_611_;
}
v_resetjp_611_:
{
lean_object* v___x_615_; 
if (v_isShared_613_ == 0)
{
v___x_615_ = v___x_612_;
goto v_reusejp_614_;
}
else
{
lean_object* v_reuseFailAlloc_616_; 
v_reuseFailAlloc_616_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_616_, 0, v_a_610_);
v___x_615_ = v_reuseFailAlloc_616_;
goto v_reusejp_614_;
}
v_reusejp_614_:
{
return v___x_615_;
}
}
}
}
else
{
lean_object* v_a_618_; lean_object* v___x_620_; uint8_t v_isShared_621_; uint8_t v_isSharedCheck_625_; 
lean_del_object(v___x_558_);
lean_dec_ref(v_nameMap_553_);
lean_dec(v_a_544_);
lean_dec(v_a_540_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v_a_618_ = lean_ctor_get(v___x_567_, 0);
v_isSharedCheck_625_ = !lean_is_exclusive(v___x_567_);
if (v_isSharedCheck_625_ == 0)
{
v___x_620_ = v___x_567_;
v_isShared_621_ = v_isSharedCheck_625_;
goto v_resetjp_619_;
}
else
{
lean_inc(v_a_618_);
lean_dec(v___x_567_);
v___x_620_ = lean_box(0);
v_isShared_621_ = v_isSharedCheck_625_;
goto v_resetjp_619_;
}
v_resetjp_619_:
{
lean_object* v___x_623_; 
if (v_isShared_621_ == 0)
{
v___x_623_ = v___x_620_;
goto v_reusejp_622_;
}
else
{
lean_object* v_reuseFailAlloc_624_; 
v_reuseFailAlloc_624_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_624_, 0, v_a_618_);
v___x_623_ = v_reuseFailAlloc_624_;
goto v_reusejp_622_;
}
v_reusejp_622_:
{
return v___x_623_;
}
}
}
}
}
}
else
{
lean_object* v___x_627_; lean_object* v___x_629_; 
lean_dec(v___x_555_);
lean_dec_ref(v_nameMap_553_);
lean_dec(v_a_544_);
lean_dec(v_a_540_);
lean_dec_ref(v_expr_533_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v___x_627_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_writeExpression___closed__7));
if (v_isShared_552_ == 0)
{
lean_ctor_set_tag(v___x_551_, 1);
lean_ctor_set(v___x_551_, 0, v___x_627_);
v___x_629_ = v___x_551_;
goto v_reusejp_628_;
}
else
{
lean_object* v_reuseFailAlloc_630_; 
v_reuseFailAlloc_630_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_630_, 0, v___x_627_);
v___x_629_ = v_reuseFailAlloc_630_;
goto v_reusejp_628_;
}
v_reusejp_628_:
{
return v___x_629_;
}
}
}
}
else
{
lean_object* v_a_632_; lean_object* v___x_634_; uint8_t v_isShared_635_; uint8_t v_isSharedCheck_639_; 
lean_dec(v_a_544_);
lean_dec(v_a_540_);
lean_dec_ref(v_expr_533_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v_a_632_ = lean_ctor_get(v___x_547_, 0);
v_isSharedCheck_639_ = !lean_is_exclusive(v___x_547_);
if (v_isSharedCheck_639_ == 0)
{
v___x_634_ = v___x_547_;
v_isShared_635_ = v_isSharedCheck_639_;
goto v_resetjp_633_;
}
else
{
lean_inc(v_a_632_);
lean_dec(v___x_547_);
v___x_634_ = lean_box(0);
v_isShared_635_ = v_isSharedCheck_639_;
goto v_resetjp_633_;
}
v_resetjp_633_:
{
lean_object* v___x_637_; 
if (v_isShared_635_ == 0)
{
v___x_637_ = v___x_634_;
goto v_reusejp_636_;
}
else
{
lean_object* v_reuseFailAlloc_638_; 
v_reuseFailAlloc_638_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_638_, 0, v_a_632_);
v___x_637_ = v_reuseFailAlloc_638_;
goto v_reusejp_636_;
}
v_reusejp_636_:
{
return v___x_637_;
}
}
}
}
else
{
lean_object* v_a_640_; lean_object* v___x_642_; uint8_t v_isShared_643_; uint8_t v_isSharedCheck_647_; 
lean_dec(v_a_540_);
lean_dec_ref(v_expr_533_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v_a_640_ = lean_ctor_get(v___x_543_, 0);
v_isSharedCheck_647_ = !lean_is_exclusive(v___x_543_);
if (v_isSharedCheck_647_ == 0)
{
v___x_642_ = v___x_543_;
v_isShared_643_ = v_isSharedCheck_647_;
goto v_resetjp_641_;
}
else
{
lean_inc(v_a_640_);
lean_dec(v___x_543_);
v___x_642_ = lean_box(0);
v_isShared_643_ = v_isSharedCheck_647_;
goto v_resetjp_641_;
}
v_resetjp_641_:
{
lean_object* v___x_645_; 
if (v_isShared_643_ == 0)
{
v___x_645_ = v___x_642_;
goto v_reusejp_644_;
}
else
{
lean_object* v_reuseFailAlloc_646_; 
v_reuseFailAlloc_646_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_646_, 0, v_a_640_);
v___x_645_ = v_reuseFailAlloc_646_;
goto v_reusejp_644_;
}
v_reusejp_644_:
{
return v___x_645_;
}
}
}
}
else
{
lean_object* v_a_648_; lean_object* v___x_650_; uint8_t v_isShared_651_; uint8_t v_isSharedCheck_655_; 
lean_dec(v_a_540_);
lean_dec_ref(v_expr_533_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
v_a_648_ = lean_ctor_get(v___x_541_, 0);
v_isSharedCheck_655_ = !lean_is_exclusive(v___x_541_);
if (v_isSharedCheck_655_ == 0)
{
v___x_650_ = v___x_541_;
v_isShared_651_ = v_isSharedCheck_655_;
goto v_resetjp_649_;
}
else
{
lean_inc(v_a_648_);
lean_dec(v___x_541_);
v___x_650_ = lean_box(0);
v_isShared_651_ = v_isSharedCheck_655_;
goto v_resetjp_649_;
}
v_resetjp_649_:
{
lean_object* v___x_653_; 
if (v_isShared_651_ == 0)
{
v___x_653_ = v___x_650_;
goto v_reusejp_652_;
}
else
{
lean_object* v_reuseFailAlloc_654_; 
v_reuseFailAlloc_654_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_654_, 0, v_a_648_);
v___x_653_ = v_reuseFailAlloc_654_;
goto v_reusejp_652_;
}
v_reusejp_652_:
{
return v___x_653_;
}
}
}
}
else
{
lean_dec(v_a_537_);
lean_dec_ref(v_expr_533_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
return v___x_539_;
}
}
else
{
lean_object* v_a_656_; lean_object* v___x_658_; uint8_t v_isShared_659_; uint8_t v_isSharedCheck_663_; 
lean_dec_ref(v_expr_533_);
lean_dec(v_params_532_);
lean_dec(v_name_531_);
lean_dec_ref(v_env_530_);
v_a_656_ = lean_ctor_get(v___x_536_, 0);
v_isSharedCheck_663_ = !lean_is_exclusive(v___x_536_);
if (v_isSharedCheck_663_ == 0)
{
v___x_658_ = v___x_536_;
v_isShared_659_ = v_isSharedCheck_663_;
goto v_resetjp_657_;
}
else
{
lean_inc(v_a_656_);
lean_dec(v___x_536_);
v___x_658_ = lean_box(0);
v_isShared_659_ = v_isSharedCheck_663_;
goto v_resetjp_657_;
}
v_resetjp_657_:
{
lean_object* v___x_661_; 
if (v_isShared_659_ == 0)
{
v___x_661_ = v___x_658_;
goto v_reusejp_660_;
}
else
{
lean_object* v_reuseFailAlloc_662_; 
v_reuseFailAlloc_662_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_662_, 0, v_a_656_);
v___x_661_ = v_reuseFailAlloc_662_;
goto v_reusejp_660_;
}
v_reusejp_660_:
{
return v___x_661_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_writeExpression___boxed(lean_object* v_path_664_, lean_object* v_env_665_, lean_object* v_name_666_, lean_object* v_params_667_, lean_object* v_expr_668_, lean_object* v_a_669_){
_start:
{
lean_object* v_res_670_; 
v_res_670_ = lp_proofEnvironment_OCMEnvironment_writeExpression(v_path_664_, v_env_665_, v_name_666_, v_params_667_, v_expr_668_);
lean_dec_ref(v_path_664_);
return v_res_670_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_registration(lean_object* v_p_683_, lean_object* v_target_684_){
_start:
{
lean_object* v_closure_685_; lean_object* v_policy_686_; lean_object* v_names_687_; lean_object* v___x_688_; lean_object* v___x_689_; lean_object* v___x_690_; lean_object* v___x_691_; lean_object* v___y_693_; lean_object* v___x_713_; lean_object* v___y_715_; lean_object* v___y_716_; lean_object* v___x_718_; uint8_t v___x_719_; 
v_closure_685_ = lean_ctor_get(v_p_683_, 3);
lean_inc_ref(v_closure_685_);
v_policy_686_ = lean_ctor_get(v_p_683_, 2);
lean_inc_ref(v_policy_686_);
lean_dec_ref(v_p_683_);
v_names_687_ = lean_ctor_get(v_closure_685_, 0);
lean_inc_ref(v_names_687_);
lean_dec_ref(v_closure_685_);
v___x_688_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__0));
v___x_689_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__2));
v___x_690_ = l_Lean_Json_setObjVal_x21(v_target_684_, v___x_688_, v___x_689_);
v___x_691_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__3));
v___x_713_ = lean_array_get_size(v_names_687_);
v___x_718_ = lean_unsigned_to_nat(0u);
v___x_719_ = lean_nat_dec_eq(v___x_713_, v___x_718_);
if (v___x_719_ == 0)
{
lean_object* v___x_720_; lean_object* v___x_721_; lean_object* v___y_723_; uint8_t v___x_725_; 
v___x_720_ = lean_unsigned_to_nat(1u);
v___x_721_ = lean_nat_sub(v___x_713_, v___x_720_);
v___x_725_ = lean_nat_dec_le(v___x_718_, v___x_721_);
if (v___x_725_ == 0)
{
lean_inc(v___x_721_);
v___y_723_ = v___x_721_;
goto v___jp_722_;
}
else
{
v___y_723_ = v___x_718_;
goto v___jp_722_;
}
v___jp_722_:
{
uint8_t v___x_724_; 
v___x_724_ = lean_nat_dec_le(v___y_723_, v___x_721_);
if (v___x_724_ == 0)
{
lean_dec(v___x_721_);
lean_inc(v___y_723_);
v___y_715_ = v___y_723_;
v___y_716_ = v___y_723_;
goto v___jp_714_;
}
else
{
v___y_715_ = v___y_723_;
v___y_716_ = v___x_721_;
goto v___jp_714_;
}
}
}
else
{
v___y_693_ = v_names_687_;
goto v___jp_692_;
}
v___jp_692_:
{
lean_object* v_axioms_694_; lean_object* v_maxHeartbeats_695_; lean_object* v_maxRecDepth_696_; lean_object* v___x_697_; lean_object* v___x_698_; lean_object* v___x_699_; lean_object* v___x_700_; lean_object* v___x_701_; lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; lean_object* v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_712_; 
v_axioms_694_ = lean_ctor_get(v_policy_686_, 3);
lean_inc_ref(v_axioms_694_);
v_maxHeartbeats_695_ = lean_ctor_get(v_policy_686_, 4);
lean_inc(v_maxHeartbeats_695_);
v_maxRecDepth_696_ = lean_ctor_get(v_policy_686_, 5);
lean_inc(v_maxRecDepth_696_);
lean_dec_ref(v_policy_686_);
v___x_697_ = lp_proofEnvironment_OCMEnvironment_namesJson(v___y_693_);
v___x_698_ = l_Lean_Json_setObjVal_x21(v___x_690_, v___x_691_, v___x_697_);
v___x_699_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__4));
v___x_700_ = lp_proofEnvironment_OCMEnvironment_namesJson(v_axioms_694_);
v___x_701_ = l_Lean_Json_setObjVal_x21(v___x_698_, v___x_699_, v___x_700_);
v___x_702_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__5));
v___x_703_ = l_Lean_JsonNumber_fromNat(v_maxHeartbeats_695_);
v___x_704_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_704_, 0, v___x_703_);
v___x_705_ = l_Lean_Json_setObjVal_x21(v___x_701_, v___x_702_, v___x_704_);
v___x_706_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__6));
v___x_707_ = l_Lean_JsonNumber_fromNat(v_maxRecDepth_696_);
v___x_708_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_708_, 0, v___x_707_);
v___x_709_ = l_Lean_Json_setObjVal_x21(v___x_705_, v___x_706_, v___x_708_);
v___x_710_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__7));
v___x_711_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_registration___closed__9));
v___x_712_ = l_Lean_Json_setObjVal_x21(v___x_709_, v___x_710_, v___x_711_);
return v___x_712_;
}
v___jp_714_:
{
lean_object* v___x_717_; 
v___x_717_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00Lean_mergeStructureResolutionOrders___at___00Lean_computeStructureResolutionOrder___at___00Lean_getStructureResolutionOrder___at___00Lean_getAllParentStructures___at___00__private_Lean_Server_Completion_CompletionUtils_0__Lean_Server_Completion_getDotCompletionTypeNames_visit_spec__0_spec__0_spec__1_spec__4_spec__16___redArg(v___x_713_, v_names_687_, v___y_715_, v___y_716_);
lean_dec(v___y_716_);
v___y_693_ = v___x_717_;
goto v___jp_692_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_inventory_spec__0(size_t v_sz_726_, size_t v_i_727_, lean_object* v_bs_728_){
_start:
{
uint8_t v___x_729_; 
v___x_729_ = lean_usize_dec_lt(v_i_727_, v_sz_726_);
if (v___x_729_ == 0)
{
return v_bs_728_;
}
else
{
lean_object* v_v_730_; lean_object* v_fst_731_; lean_object* v_snd_732_; lean_object* v___x_733_; lean_object* v_bs_x27_734_; lean_object* v___x_735_; lean_object* v___x_736_; lean_object* v___x_737_; lean_object* v___x_738_; lean_object* v___x_739_; lean_object* v___x_740_; size_t v___x_741_; size_t v___x_742_; lean_object* v___x_743_; 
v_v_730_ = lean_array_uget_borrowed(v_bs_728_, v_i_727_);
v_fst_731_ = lean_ctor_get(v_v_730_, 0);
lean_inc(v_fst_731_);
v_snd_732_ = lean_ctor_get(v_v_730_, 1);
lean_inc(v_snd_732_);
v___x_733_ = lean_unsigned_to_nat(0u);
v_bs_x27_734_ = lean_array_uset(v_bs_728_, v_i_727_, v___x_733_);
v___x_735_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_731_, v___x_729_);
v___x_736_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_snd_732_, v___x_729_);
v___x_737_ = lean_unsigned_to_nat(2u);
v___x_738_ = lean_mk_empty_array_with_capacity(v___x_737_);
v___x_739_ = lean_array_push(v___x_738_, v___x_735_);
v___x_740_ = lean_array_push(v___x_739_, v___x_736_);
v___x_741_ = ((size_t)1ULL);
v___x_742_ = lean_usize_add(v_i_727_, v___x_741_);
v___x_743_ = lean_array_uset(v_bs_x27_734_, v_i_727_, v___x_740_);
v_i_727_ = v___x_742_;
v_bs_728_ = v___x_743_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_inventory_spec__0___boxed(lean_object* v_sz_745_, lean_object* v_i_746_, lean_object* v_bs_747_){
_start:
{
size_t v_sz_boxed_748_; size_t v_i_boxed_749_; lean_object* v_res_750_; 
v_sz_boxed_748_ = lean_unbox_usize(v_sz_745_);
lean_dec(v_sz_745_);
v_i_boxed_749_ = lean_unbox_usize(v_i_746_);
lean_dec(v_i_746_);
v_res_750_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_inventory_spec__0(v_sz_boxed_748_, v_i_boxed_749_, v_bs_747_);
return v_res_750_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1_spec__1(size_t v_sz_751_, size_t v_i_752_, lean_object* v_bs_753_){
_start:
{
uint8_t v___x_754_; 
v___x_754_ = lean_usize_dec_lt(v_i_752_, v_sz_751_);
if (v___x_754_ == 0)
{
return v_bs_753_;
}
else
{
lean_object* v_v_755_; lean_object* v___x_756_; lean_object* v_bs_x27_757_; lean_object* v___x_758_; size_t v___x_759_; size_t v___x_760_; lean_object* v___x_761_; 
v_v_755_ = lean_array_uget(v_bs_753_, v_i_752_);
v___x_756_ = lean_unsigned_to_nat(0u);
v_bs_x27_757_ = lean_array_uset(v_bs_753_, v_i_752_, v___x_756_);
v___x_758_ = lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_namesJson_spec__1(v_v_755_);
v___x_759_ = ((size_t)1ULL);
v___x_760_ = lean_usize_add(v_i_752_, v___x_759_);
v___x_761_ = lean_array_uset(v_bs_x27_757_, v_i_752_, v___x_758_);
v_i_752_ = v___x_760_;
v_bs_753_ = v___x_761_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1_spec__1___boxed(lean_object* v_sz_763_, lean_object* v_i_764_, lean_object* v_bs_765_){
_start:
{
size_t v_sz_boxed_766_; size_t v_i_boxed_767_; lean_object* v_res_768_; 
v_sz_boxed_766_ = lean_unbox_usize(v_sz_763_);
lean_dec(v_sz_763_);
v_i_boxed_767_ = lean_unbox_usize(v_i_764_);
lean_dec(v_i_764_);
v_res_768_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1_spec__1(v_sz_boxed_766_, v_i_boxed_767_, v_bs_765_);
return v_res_768_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1(lean_object* v_a_769_){
_start:
{
size_t v_sz_770_; size_t v___x_771_; lean_object* v___x_772_; lean_object* v___x_773_; 
v_sz_770_ = lean_array_size(v_a_769_);
v___x_771_ = ((size_t)0ULL);
v___x_772_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1_spec__1(v_sz_770_, v___x_771_, v_a_769_);
v___x_773_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_773_, 0, v___x_772_);
return v___x_773_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_inventory(lean_object* v_p_782_){
_start:
{
lean_object* v_closure_783_; lean_object* v_names_784_; lean_object* v_edges_785_; lean_object* v___x_787_; uint8_t v_isShared_788_; uint8_t v_isSharedCheck_821_; 
v_closure_783_ = lean_ctor_get(v_p_782_, 3);
lean_inc_ref(v_closure_783_);
lean_dec_ref(v_p_782_);
v_names_784_ = lean_ctor_get(v_closure_783_, 0);
v_edges_785_ = lean_ctor_get(v_closure_783_, 1);
v_isSharedCheck_821_ = !lean_is_exclusive(v_closure_783_);
if (v_isSharedCheck_821_ == 0)
{
v___x_787_ = v_closure_783_;
v_isShared_788_ = v_isSharedCheck_821_;
goto v_resetjp_786_;
}
else
{
lean_inc(v_edges_785_);
lean_inc(v_names_784_);
lean_dec(v_closure_783_);
v___x_787_ = lean_box(0);
v_isShared_788_ = v_isSharedCheck_821_;
goto v_resetjp_786_;
}
v_resetjp_786_:
{
lean_object* v___x_789_; lean_object* v___x_790_; lean_object* v___y_792_; lean_object* v___x_808_; lean_object* v___y_810_; lean_object* v___y_811_; lean_object* v___x_813_; uint8_t v___x_814_; 
v___x_789_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_inventory___closed__2));
v___x_790_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_inventory___closed__3));
v___x_808_ = lean_array_get_size(v_names_784_);
v___x_813_ = lean_unsigned_to_nat(0u);
v___x_814_ = lean_nat_dec_eq(v___x_808_, v___x_813_);
if (v___x_814_ == 0)
{
lean_object* v___x_815_; lean_object* v___x_816_; lean_object* v___y_818_; uint8_t v___x_820_; 
v___x_815_ = lean_unsigned_to_nat(1u);
v___x_816_ = lean_nat_sub(v___x_808_, v___x_815_);
v___x_820_ = lean_nat_dec_le(v___x_813_, v___x_816_);
if (v___x_820_ == 0)
{
lean_inc(v___x_816_);
v___y_818_ = v___x_816_;
goto v___jp_817_;
}
else
{
v___y_818_ = v___x_813_;
goto v___jp_817_;
}
v___jp_817_:
{
uint8_t v___x_819_; 
v___x_819_ = lean_nat_dec_le(v___y_818_, v___x_816_);
if (v___x_819_ == 0)
{
lean_dec(v___x_816_);
lean_inc(v___y_818_);
v___y_810_ = v___y_818_;
v___y_811_ = v___y_818_;
goto v___jp_809_;
}
else
{
v___y_810_ = v___y_818_;
v___y_811_ = v___x_816_;
goto v___jp_809_;
}
}
}
else
{
v___y_792_ = v_names_784_;
goto v___jp_791_;
}
v___jp_791_:
{
lean_object* v___x_793_; lean_object* v___x_795_; 
v___x_793_ = lp_proofEnvironment_OCMEnvironment_namesJson(v___y_792_);
if (v_isShared_788_ == 0)
{
lean_ctor_set(v___x_787_, 1, v___x_793_);
lean_ctor_set(v___x_787_, 0, v___x_790_);
v___x_795_ = v___x_787_;
goto v_reusejp_794_;
}
else
{
lean_object* v_reuseFailAlloc_807_; 
v_reuseFailAlloc_807_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_807_, 0, v___x_790_);
lean_ctor_set(v_reuseFailAlloc_807_, 1, v___x_793_);
v___x_795_ = v_reuseFailAlloc_807_;
goto v_reusejp_794_;
}
v_reusejp_794_:
{
lean_object* v___x_796_; size_t v_sz_797_; size_t v___x_798_; lean_object* v___x_799_; lean_object* v___x_800_; lean_object* v___x_801_; lean_object* v___x_802_; lean_object* v___x_803_; lean_object* v___x_804_; lean_object* v___x_805_; lean_object* v___x_806_; 
v___x_796_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_inventory___closed__4));
v_sz_797_ = lean_array_size(v_edges_785_);
v___x_798_ = ((size_t)0ULL);
v___x_799_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_inventory_spec__0(v_sz_797_, v___x_798_, v_edges_785_);
v___x_800_ = lp_proofEnvironment_Lean_Array_toJson___at___00OCMEnvironment_inventory_spec__1(v___x_799_);
v___x_801_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_801_, 0, v___x_796_);
lean_ctor_set(v___x_801_, 1, v___x_800_);
v___x_802_ = lean_box(0);
v___x_803_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_803_, 0, v___x_801_);
lean_ctor_set(v___x_803_, 1, v___x_802_);
v___x_804_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_804_, 0, v___x_795_);
lean_ctor_set(v___x_804_, 1, v___x_803_);
v___x_805_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_805_, 0, v___x_789_);
lean_ctor_set(v___x_805_, 1, v___x_804_);
v___x_806_ = l_Lean_Json_mkObj(v___x_805_);
lean_dec_ref_known(v___x_805_, 2);
return v___x_806_;
}
}
v___jp_809_:
{
lean_object* v___x_812_; 
v___x_812_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00Lean_mergeStructureResolutionOrders___at___00Lean_computeStructureResolutionOrder___at___00Lean_getStructureResolutionOrder___at___00Lean_getAllParentStructures___at___00__private_Lean_Server_Completion_CompletionUtils_0__Lean_Server_Completion_getDotCompletionTypeNames_visit_spec__0_spec__0_spec__1_spec__4_spec__16___redArg(v___x_808_, v_names_784_, v___y_810_, v___y_811_);
lean_dec(v___y_811_);
v___y_792_ = v___x_812_;
goto v___jp_791_;
}
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_CheckedExport(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Packet(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Prepare(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Write(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_CheckedExport(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Packet(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Prepare(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
