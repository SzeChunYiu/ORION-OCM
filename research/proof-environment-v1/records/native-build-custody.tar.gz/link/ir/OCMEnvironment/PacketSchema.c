// Lean compiler output
// Module: OCMEnvironment.PacketSchema
// Imports: public import Init public meta import Init public import Export.Parse
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_Int_toNat(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_String_decLE___boxed(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(lean_object*, lean_object*);
uint8_t l_List_beq___at___00Lean_Syntax_instBEqPreresolved_beq_spec__0(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_Lean_Json_getObjVal_x3f(lean_object*, lean_object*);
lean_object* l_Lean_Json_getArr_x3f(lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_string_compare(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_keys_spec__0(lean_object*, lean_object*);
static const lean_closure_object lp_proofEnvironment_OCMEnvironment_keys___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_String_decLE___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_proofEnvironment_OCMEnvironment_keys___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_keys___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "FIELDS "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_keys___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_keys___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = " expected "};
static const lean_object* lp_proofEnvironment_OCMEnvironment_keys___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_keys___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_keys___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_keys___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "OBJECT_REQUIRED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_keys___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_keys___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__4_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_keys___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_keys___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_keys(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_field(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_field___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_natural___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "EXACT_NAT_REQUIRED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_natural___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_natural___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_natural___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_natural___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_natural___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_natural___closed__1_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_natural___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_natural___closed__2;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_natural___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "NAT_REQUIRED"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_natural___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_natural___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_natural___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_natural___closed__3_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_natural___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_natural___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_natural(lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_index___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "REFERENCE_OUT_OF_RANGE"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_index___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_index___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_index___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_index___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_index___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_index___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_index(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_index___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "name"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "levelParams"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__1 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "type"};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__3 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__3_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__1_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__3_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__4 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__4_value;
static const lean_ctor_object lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value),((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__4_value)}};
static const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__5 = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__5_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields = (const lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__5_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "ctor"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "nfields"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "rhs"};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__2_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__2_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__3_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__1_value),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__3_value)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__4_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__0_value),((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__4_value)}};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__5_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "recInfo"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__0_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "rules"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "def"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__2_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "hints"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "regular"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__4_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "HINT_UINT32_OVERFLOW"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__6_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "axiom"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__8_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "thm"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__9_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "opaque"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__10_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "quot"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__11_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "typeInfo"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__12_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "ctorInfo"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__13_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "DECLARATION_TAG"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__14_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__15 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__15_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "all"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numParams"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__17 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__17_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numIndices"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__18 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__18_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "numMotives"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__19 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__19_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numMinors"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__20 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__20_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "k"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__21 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__21_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "isUnsafe"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__22 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__22_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__22_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__21_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__24 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__24_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__24_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__25 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__25_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__20_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__25_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__26 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__26_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__19_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__26_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__27 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__27_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__18_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__27_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__28 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__28_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__17_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__28_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__29 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__29_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__29_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__30 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__30_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "induct"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__31 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__31_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "cidx"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__32 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__32_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numFields"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__33 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__33_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__33_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__34 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__34_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__17_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__34_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__35 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__35_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__36_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__32_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__35_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__36 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__36_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__37_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__31_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__36_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__37 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__37_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ctors"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__39_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "numNested"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__39 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__39_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__40_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "isRec"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__40 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__40_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__41_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "isReflexive"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__41 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__41_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__42_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__41_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__42 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__42_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__43_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__22_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__42_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__43 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__43_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__44_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__40_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__43_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__44 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__44_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__45_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__39_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__44_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__45 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__45_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__46_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__45_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__46 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__46_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__47_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__46_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__47 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__47_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__48_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__18_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__47_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__48 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__48_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__49_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__17_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__48_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__49 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__49_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__50_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "kind"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__50 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__50_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__51_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__50_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__51 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__51_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "value"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__53_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__53 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__53_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__54_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__53_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__54 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__54_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__55_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__55 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__55_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__56_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__55_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__56 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__56_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__57_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "safety"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__57 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__57_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__58_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__57_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__55_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__58 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__58_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__59_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__3_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__58_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__59 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__59_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__60_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__59_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__60 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__60_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_itemSchema_spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_itemSchema_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "EXPR_TAG"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "LEVEL_TAG"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__2_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "in"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__4_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "il"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "ie"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__6_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inductive"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "types"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__8_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "recs"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__9_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__10_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__8_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__11_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__8_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__12_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__13_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__9_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__0_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__15 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__15_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__16 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__16_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__14_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__16_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__17 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__17_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__13_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__17_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__18 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__18_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "bvar"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__19 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__19_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "sort"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__20 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__20_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "const"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__21 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__21_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "app"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__22 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__22_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lam"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__23 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__23_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "forallE"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__24 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__24_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "letE"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__25 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__25_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "proj"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__26 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__26_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "natVal"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__27 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__27_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "strVal"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__28 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__28_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "mdata"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__29 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__29_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__29_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__30 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__30_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__28_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__30_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__31 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__31_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__27_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__31_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__32 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__32_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__26_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__32_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__33 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__33_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__25_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__33_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__34 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__34_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__24_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__34_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__35 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__35_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__36_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__23_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__35_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__36 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__36_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__37_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__22_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__36_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__37 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__37_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__38_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__21_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__37_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__38 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__38_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__39_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__20_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__38_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__39 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__39_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__40_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__19_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__39_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__40 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__40_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__41_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "body"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__41 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__41_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__42_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "binderInfo"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__42 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__42_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__43_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__42_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__43 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__43_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__44_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__41_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__43_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__44 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__44_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__45_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__44_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__45 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__45_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__46_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__45_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__46 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__46_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__47_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "expr"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__47 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__47_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__48_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "data"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__48 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__48_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__49_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__48_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__49 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__49_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__50_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__47_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__49_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__50 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__50_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__51_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "typeName"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__51 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__51_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__52_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "idx"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__52 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__52_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__53_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "struct"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__53 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__53_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__54_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__53_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__54 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__54_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__55_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__52_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__54_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__55 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__55_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__56_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__51_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__55_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__56 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__56_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__57_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "nondep"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__57 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__57_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__58_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__57_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__58 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__58_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__59_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__41_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__58_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__59 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__59_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__60_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__59_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__60 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__60_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__61_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__60_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__61 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__61_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__62_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__61_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__62 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__62_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__63_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "fn"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__63 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__63_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__64_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "arg"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__64 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__64_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__65_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__64_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__65 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__65_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__66_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__63_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__65_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__66 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__66_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__67_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "us"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__67 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__67_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__68_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__67_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__68 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__68_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__69_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__68_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__69 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__69_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__70_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "succ"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__70 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__70_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__71_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "max"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__71 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__71_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__72_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "imax"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__72 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__72_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__73_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "param"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__73 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__73_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__74_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__73_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__74 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__74_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__75_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__72_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__74_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__75 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__75_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__76_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__71_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__75_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__76 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__76_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__77_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__70_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__76_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__77 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__77_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__78_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "str"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__78 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__78_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__79_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "num"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__79 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__79_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__80_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__79_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__80 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__80_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__81_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__4_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__80_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__81 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__81_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__82_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "pre"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__82 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__82_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__83_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "i"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__83 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__83_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__84_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__83_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__84 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__84_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__85_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__82_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__84_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__85 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__85_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__86_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__78_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__86 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__86_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__87_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__4_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__86_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__87 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__87_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_itemSchema___closed__88_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__82_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__86_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema___closed__88 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__88_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema(lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__0_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__74_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__31_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__0_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__1_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__51_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__1_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__0_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__2_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__3_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__82_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__3_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__47_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__5 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__5_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__2_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__5_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__6 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__53_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__6_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__7 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__7_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__41_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__7_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__8 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__64_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__8_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__9 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_itemSchema___closed__63_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__9_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__10 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__52_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__10_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__11 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__2_value),((lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__11_value)}};
static const lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__12 = (const lean_object*)&lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__12_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_references(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_references___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_keys_spec__0(lean_object* v_a_1_, lean_object* v_a_2_){
_start:
{
if (lean_obj_tag(v_a_1_) == 0)
{
lean_object* v___x_3_; 
v___x_3_ = l_List_reverse___redArg(v_a_2_);
return v___x_3_;
}
else
{
lean_object* v_head_4_; lean_object* v_tail_5_; lean_object* v___x_7_; uint8_t v_isShared_8_; uint8_t v_isSharedCheck_14_; 
v_head_4_ = lean_ctor_get(v_a_1_, 0);
v_tail_5_ = lean_ctor_get(v_a_1_, 1);
v_isSharedCheck_14_ = !lean_is_exclusive(v_a_1_);
if (v_isSharedCheck_14_ == 0)
{
v___x_7_ = v_a_1_;
v_isShared_8_ = v_isSharedCheck_14_;
goto v_resetjp_6_;
}
else
{
lean_inc(v_tail_5_);
lean_inc(v_head_4_);
lean_dec(v_a_1_);
v___x_7_ = lean_box(0);
v_isShared_8_ = v_isSharedCheck_14_;
goto v_resetjp_6_;
}
v_resetjp_6_:
{
lean_object* v_fst_9_; lean_object* v___x_11_; 
v_fst_9_ = lean_ctor_get(v_head_4_, 0);
lean_inc(v_fst_9_);
lean_dec(v_head_4_);
if (v_isShared_8_ == 0)
{
lean_ctor_set(v___x_7_, 1, v_a_2_);
lean_ctor_set(v___x_7_, 0, v_fst_9_);
v___x_11_ = v___x_7_;
goto v_reusejp_10_;
}
else
{
lean_object* v_reuseFailAlloc_13_; 
v_reuseFailAlloc_13_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_13_, 0, v_fst_9_);
lean_ctor_set(v_reuseFailAlloc_13_, 1, v_a_2_);
v___x_11_ = v_reuseFailAlloc_13_;
goto v_reusejp_10_;
}
v_reusejp_10_:
{
v_a_1_ = v_tail_5_;
v_a_2_ = v___x_11_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_keys(lean_object* v_j_23_, lean_object* v_expected_24_){
_start:
{
if (lean_obj_tag(v_j_23_) == 5)
{
lean_object* v_kvPairs_25_; lean_object* v___x_27_; uint8_t v_isShared_28_; uint8_t v_isSharedCheck_47_; 
v_kvPairs_25_ = lean_ctor_get(v_j_23_, 0);
v_isSharedCheck_47_ = !lean_is_exclusive(v_j_23_);
if (v_isSharedCheck_47_ == 0)
{
v___x_27_ = v_j_23_;
v_isShared_28_ = v_isSharedCheck_47_;
goto v_resetjp_26_;
}
else
{
lean_inc(v_kvPairs_25_);
lean_dec(v_j_23_);
v___x_27_ = lean_box(0);
v_isShared_28_ = v_isSharedCheck_47_;
goto v_resetjp_26_;
}
v_resetjp_26_:
{
lean_object* v___f_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; uint8_t v___x_34_; 
v___f_29_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__0));
v___x_30_ = lean_box(0);
v___x_31_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(v___x_30_, v_kvPairs_25_);
v___x_32_ = lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_keys_spec__0(v___x_31_, v___x_30_);
lean_inc(v_expected_24_);
v___x_33_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v_expected_24_, v___f_29_);
v___x_34_ = l_List_beq___at___00Lean_Syntax_instBEqPreresolved_beq_spec__0(v___x_32_, v___x_33_);
lean_dec(v___x_33_);
lean_dec(v___x_32_);
if (v___x_34_ == 0)
{
lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_44_; 
v___x_35_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__1));
v___x_36_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__0(v___x_30_, v_kvPairs_25_);
lean_dec(v_kvPairs_25_);
v___x_37_ = lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(v___x_36_);
lean_dec(v___x_36_);
v___x_38_ = lean_string_append(v___x_35_, v___x_37_);
lean_dec_ref(v___x_37_);
v___x_39_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__2));
v___x_40_ = lean_string_append(v___x_38_, v___x_39_);
v___x_41_ = lp_proofEnvironment_List_toString___at___00Export_Parse_parseItem_spec__1(v_expected_24_);
lean_dec(v_expected_24_);
v___x_42_ = lean_string_append(v___x_40_, v___x_41_);
lean_dec_ref(v___x_41_);
if (v_isShared_28_ == 0)
{
lean_ctor_set_tag(v___x_27_, 0);
lean_ctor_set(v___x_27_, 0, v___x_42_);
v___x_44_ = v___x_27_;
goto v_reusejp_43_;
}
else
{
lean_object* v_reuseFailAlloc_45_; 
v_reuseFailAlloc_45_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_45_, 0, v___x_42_);
v___x_44_ = v_reuseFailAlloc_45_;
goto v_reusejp_43_;
}
v_reusejp_43_:
{
return v___x_44_;
}
}
else
{
lean_object* v___x_46_; 
lean_del_object(v___x_27_);
lean_dec(v_kvPairs_25_);
lean_dec(v_expected_24_);
v___x_46_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_46_;
}
}
}
else
{
lean_object* v___x_48_; 
lean_dec(v_expected_24_);
lean_dec(v_j_23_);
v___x_48_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__5));
return v___x_48_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_field(lean_object* v_j_49_, lean_object* v_k_50_){
_start:
{
lean_object* v___x_51_; 
v___x_51_ = l_Lean_Json_getObjVal_x3f(v_j_49_, v_k_50_);
return v___x_51_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_field___boxed(lean_object* v_j_52_, lean_object* v_k_53_){
_start:
{
lean_object* v_res_54_; 
v_res_54_ = lp_proofEnvironment_OCMEnvironment_field(v_j_52_, v_k_53_);
lean_dec_ref(v_k_53_);
return v_res_54_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_natural___closed__2(void){
_start:
{
lean_object* v___x_58_; lean_object* v___x_59_; 
v___x_58_ = lean_unsigned_to_nat(0u);
v___x_59_ = lean_nat_to_int(v___x_58_);
return v___x_59_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_natural(lean_object* v_j_63_){
_start:
{
if (lean_obj_tag(v_j_63_) == 2)
{
lean_object* v_n_66_; lean_object* v___x_68_; uint8_t v_isShared_69_; uint8_t v_isSharedCheck_80_; 
v_n_66_ = lean_ctor_get(v_j_63_, 0);
v_isSharedCheck_80_ = !lean_is_exclusive(v_j_63_);
if (v_isSharedCheck_80_ == 0)
{
v___x_68_ = v_j_63_;
v_isShared_69_ = v_isSharedCheck_80_;
goto v_resetjp_67_;
}
else
{
lean_inc(v_n_66_);
lean_dec(v_j_63_);
v___x_68_ = lean_box(0);
v_isShared_69_ = v_isSharedCheck_80_;
goto v_resetjp_67_;
}
v_resetjp_67_:
{
lean_object* v_mantissa_70_; lean_object* v_exponent_71_; lean_object* v___x_72_; uint8_t v___x_73_; 
v_mantissa_70_ = lean_ctor_get(v_n_66_, 0);
lean_inc(v_mantissa_70_);
v_exponent_71_ = lean_ctor_get(v_n_66_, 1);
lean_inc(v_exponent_71_);
lean_dec_ref(v_n_66_);
v___x_72_ = lean_unsigned_to_nat(0u);
v___x_73_ = lean_nat_dec_eq(v_exponent_71_, v___x_72_);
lean_dec(v_exponent_71_);
if (v___x_73_ == 0)
{
lean_dec(v_mantissa_70_);
lean_del_object(v___x_68_);
goto v___jp_64_;
}
else
{
lean_object* v___x_74_; uint8_t v___x_75_; 
v___x_74_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_natural___closed__2, &lp_proofEnvironment_OCMEnvironment_natural___closed__2_once, _init_lp_proofEnvironment_OCMEnvironment_natural___closed__2);
v___x_75_ = lean_int_dec_lt(v_mantissa_70_, v___x_74_);
if (v___x_75_ == 0)
{
lean_object* v___x_76_; lean_object* v___x_78_; 
v___x_76_ = l_Int_toNat(v_mantissa_70_);
lean_dec(v_mantissa_70_);
if (v_isShared_69_ == 0)
{
lean_ctor_set_tag(v___x_68_, 1);
lean_ctor_set(v___x_68_, 0, v___x_76_);
v___x_78_ = v___x_68_;
goto v_reusejp_77_;
}
else
{
lean_object* v_reuseFailAlloc_79_; 
v_reuseFailAlloc_79_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_79_, 0, v___x_76_);
v___x_78_ = v_reuseFailAlloc_79_;
goto v_reusejp_77_;
}
v_reusejp_77_:
{
return v___x_78_;
}
}
else
{
lean_dec(v_mantissa_70_);
lean_del_object(v___x_68_);
goto v___jp_64_;
}
}
}
}
else
{
lean_object* v___x_81_; 
lean_dec(v_j_63_);
v___x_81_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_natural___closed__4));
return v___x_81_;
}
v___jp_64_:
{
lean_object* v___x_65_; 
v___x_65_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_natural___closed__1));
return v___x_65_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_index(lean_object* v_j_85_, lean_object* v_bound_86_){
_start:
{
lean_object* v___x_87_; 
v___x_87_ = lp_proofEnvironment_OCMEnvironment_natural(v_j_85_);
if (lean_obj_tag(v___x_87_) == 0)
{
lean_object* v_a_88_; lean_object* v___x_90_; uint8_t v_isShared_91_; uint8_t v_isSharedCheck_95_; 
v_a_88_ = lean_ctor_get(v___x_87_, 0);
v_isSharedCheck_95_ = !lean_is_exclusive(v___x_87_);
if (v_isSharedCheck_95_ == 0)
{
v___x_90_ = v___x_87_;
v_isShared_91_ = v_isSharedCheck_95_;
goto v_resetjp_89_;
}
else
{
lean_inc(v_a_88_);
lean_dec(v___x_87_);
v___x_90_ = lean_box(0);
v_isShared_91_ = v_isSharedCheck_95_;
goto v_resetjp_89_;
}
v_resetjp_89_:
{
lean_object* v___x_93_; 
if (v_isShared_91_ == 0)
{
v___x_93_ = v___x_90_;
goto v_reusejp_92_;
}
else
{
lean_object* v_reuseFailAlloc_94_; 
v_reuseFailAlloc_94_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_94_, 0, v_a_88_);
v___x_93_ = v_reuseFailAlloc_94_;
goto v_reusejp_92_;
}
v_reusejp_92_:
{
return v___x_93_;
}
}
}
else
{
lean_object* v_a_96_; uint8_t v___x_97_; 
v_a_96_ = lean_ctor_get(v___x_87_, 0);
lean_inc(v_a_96_);
lean_dec_ref_known(v___x_87_, 1);
v___x_97_ = lean_nat_dec_le(v_bound_86_, v_a_96_);
lean_dec(v_a_96_);
if (v___x_97_ == 0)
{
lean_object* v___x_98_; 
v___x_98_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_98_;
}
else
{
lean_object* v___x_99_; 
v___x_99_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_index___closed__1));
return v___x_99_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_index___boxed(lean_object* v_j_100_, lean_object* v_bound_101_){
_start:
{
lean_object* v_res_102_; 
v_res_102_ = lp_proofEnvironment_OCMEnvironment_index(v_j_100_, v_bound_101_);
lean_dec(v_bound_101_);
return v_res_102_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0(lean_object* v_as_128_, size_t v_sz_129_, size_t v_i_130_, lean_object* v_b_131_){
_start:
{
uint8_t v___x_132_; 
v___x_132_ = lean_usize_dec_lt(v_i_130_, v_sz_129_);
if (v___x_132_ == 0)
{
lean_object* v___x_133_; 
v___x_133_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_133_, 0, v_b_131_);
return v___x_133_;
}
else
{
lean_object* v_a_134_; lean_object* v___x_135_; lean_object* v___x_136_; 
v_a_134_ = lean_array_uget_borrowed(v_as_128_, v_i_130_);
v___x_135_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___closed__5));
lean_inc(v_a_134_);
v___x_136_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_134_, v___x_135_);
if (lean_obj_tag(v___x_136_) == 0)
{
return v___x_136_;
}
else
{
lean_object* v___x_137_; size_t v___x_138_; size_t v___x_139_; 
lean_dec_ref_known(v___x_136_, 1);
v___x_137_ = lean_box(0);
v___x_138_ = ((size_t)1ULL);
v___x_139_ = lean_usize_add(v_i_130_, v___x_138_);
v_i_130_ = v___x_139_;
v_b_131_ = v___x_137_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0___boxed(lean_object* v_as_141_, lean_object* v_sz_142_, lean_object* v_i_143_, lean_object* v_b_144_){
_start:
{
size_t v_sz_boxed_145_; size_t v_i_boxed_146_; lean_object* v_res_147_; 
v_sz_boxed_145_ = lean_unbox_usize(v_sz_142_);
lean_dec(v_sz_142_);
v_i_boxed_146_ = lean_unbox_usize(v_i_143_);
lean_dec(v_i_143_);
v_res_147_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0(v_as_141_, v_sz_boxed_145_, v_i_boxed_146_, v_b_144_);
lean_dec_ref(v_as_141_);
return v_res_147_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema(lean_object* v_tag_269_, lean_object* v_j_270_){
_start:
{
lean_object* v_extra_302_; lean_object* v___x_345_; uint8_t v___x_346_; 
v___x_345_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__8));
v___x_346_ = lean_string_dec_eq(v_tag_269_, v___x_345_);
if (v___x_346_ == 0)
{
lean_object* v___x_347_; uint8_t v___x_348_; 
v___x_347_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__2));
v___x_348_ = lean_string_dec_eq(v_tag_269_, v___x_347_);
if (v___x_348_ == 0)
{
lean_object* v___x_349_; uint8_t v___x_350_; 
v___x_349_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__9));
v___x_350_ = lean_string_dec_eq(v_tag_269_, v___x_349_);
if (v___x_350_ == 0)
{
lean_object* v___x_351_; uint8_t v___x_352_; 
v___x_351_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__10));
v___x_352_ = lean_string_dec_eq(v_tag_269_, v___x_351_);
if (v___x_352_ == 0)
{
lean_object* v___x_353_; uint8_t v___x_354_; 
v___x_353_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__11));
v___x_354_ = lean_string_dec_eq(v_tag_269_, v___x_353_);
if (v___x_354_ == 0)
{
lean_object* v___x_355_; uint8_t v___x_356_; 
v___x_355_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__12));
v___x_356_ = lean_string_dec_eq(v_tag_269_, v___x_355_);
if (v___x_356_ == 0)
{
lean_object* v___x_357_; uint8_t v___x_358_; 
v___x_357_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__13));
v___x_358_ = lean_string_dec_eq(v_tag_269_, v___x_357_);
if (v___x_358_ == 0)
{
lean_object* v___x_359_; uint8_t v___x_360_; 
v___x_359_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__0));
v___x_360_ = lean_string_dec_eq(v_tag_269_, v___x_359_);
if (v___x_360_ == 0)
{
lean_object* v___x_361_; 
lean_dec(v_j_270_);
v___x_361_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__15));
return v___x_361_;
}
else
{
lean_object* v___x_362_; 
v___x_362_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__30));
v_extra_302_ = v___x_362_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_363_; 
v___x_363_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__37));
v_extra_302_ = v___x_363_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_364_; 
v___x_364_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__49));
v_extra_302_ = v___x_364_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_365_; 
v___x_365_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__51));
v_extra_302_ = v___x_365_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_366_; 
v___x_366_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__54));
v_extra_302_ = v___x_366_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_367_; 
v___x_367_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__56));
v_extra_302_ = v___x_367_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_368_; 
v___x_368_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__60));
v_extra_302_ = v___x_368_;
goto v___jp_301_;
}
}
else
{
lean_object* v___x_369_; 
v___x_369_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__23));
v_extra_302_ = v___x_369_;
goto v___jp_301_;
}
v___jp_271_:
{
lean_object* v___x_272_; uint8_t v___x_273_; 
v___x_272_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__0));
v___x_273_ = lean_string_dec_eq(v_tag_269_, v___x_272_);
if (v___x_273_ == 0)
{
lean_object* v___x_274_; 
lean_dec(v_j_270_);
v___x_274_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_274_;
}
else
{
lean_object* v___x_275_; lean_object* v___x_276_; 
v___x_275_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__1));
v___x_276_ = l_Lean_Json_getObjVal_x3f(v_j_270_, v___x_275_);
if (lean_obj_tag(v___x_276_) == 0)
{
lean_object* v_a_277_; lean_object* v___x_279_; uint8_t v_isShared_280_; uint8_t v_isSharedCheck_284_; 
v_a_277_ = lean_ctor_get(v___x_276_, 0);
v_isSharedCheck_284_ = !lean_is_exclusive(v___x_276_);
if (v_isSharedCheck_284_ == 0)
{
v___x_279_ = v___x_276_;
v_isShared_280_ = v_isSharedCheck_284_;
goto v_resetjp_278_;
}
else
{
lean_inc(v_a_277_);
lean_dec(v___x_276_);
v___x_279_ = lean_box(0);
v_isShared_280_ = v_isSharedCheck_284_;
goto v_resetjp_278_;
}
v_resetjp_278_:
{
lean_object* v___x_282_; 
if (v_isShared_280_ == 0)
{
v___x_282_ = v___x_279_;
goto v_reusejp_281_;
}
else
{
lean_object* v_reuseFailAlloc_283_; 
v_reuseFailAlloc_283_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_283_, 0, v_a_277_);
v___x_282_ = v_reuseFailAlloc_283_;
goto v_reusejp_281_;
}
v_reusejp_281_:
{
return v___x_282_;
}
}
}
else
{
lean_object* v_a_285_; lean_object* v___x_286_; 
v_a_285_ = lean_ctor_get(v___x_276_, 0);
lean_inc(v_a_285_);
lean_dec_ref_known(v___x_276_, 1);
v___x_286_ = l_Lean_Json_getArr_x3f(v_a_285_);
if (lean_obj_tag(v___x_286_) == 0)
{
lean_object* v_a_287_; lean_object* v___x_289_; uint8_t v_isShared_290_; uint8_t v_isSharedCheck_294_; 
v_a_287_ = lean_ctor_get(v___x_286_, 0);
v_isSharedCheck_294_ = !lean_is_exclusive(v___x_286_);
if (v_isSharedCheck_294_ == 0)
{
v___x_289_ = v___x_286_;
v_isShared_290_ = v_isSharedCheck_294_;
goto v_resetjp_288_;
}
else
{
lean_inc(v_a_287_);
lean_dec(v___x_286_);
v___x_289_ = lean_box(0);
v_isShared_290_ = v_isSharedCheck_294_;
goto v_resetjp_288_;
}
v_resetjp_288_:
{
lean_object* v___x_292_; 
if (v_isShared_290_ == 0)
{
v___x_292_ = v___x_289_;
goto v_reusejp_291_;
}
else
{
lean_object* v_reuseFailAlloc_293_; 
v_reuseFailAlloc_293_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_293_, 0, v_a_287_);
v___x_292_ = v_reuseFailAlloc_293_;
goto v_reusejp_291_;
}
v_reusejp_291_:
{
return v___x_292_;
}
}
}
else
{
lean_object* v_a_295_; lean_object* v___x_296_; size_t v_sz_297_; size_t v___x_298_; lean_object* v___x_299_; 
v_a_295_ = lean_ctor_get(v___x_286_, 0);
lean_inc(v_a_295_);
lean_dec_ref_known(v___x_286_, 1);
v___x_296_ = lean_box(0);
v_sz_297_ = lean_array_size(v_a_295_);
v___x_298_ = ((size_t)0ULL);
v___x_299_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_declarationSchema_spec__0(v_a_295_, v_sz_297_, v___x_298_, v___x_296_);
lean_dec(v_a_295_);
if (lean_obj_tag(v___x_299_) == 0)
{
return v___x_299_;
}
else
{
lean_object* v___x_300_; 
lean_dec_ref_known(v___x_299_, 1);
v___x_300_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_300_;
}
}
}
}
}
v___jp_301_:
{
lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; 
v___x_303_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields));
lean_inc(v_extra_302_);
v___x_304_ = l_List_appendTR___redArg(v___x_303_, v_extra_302_);
lean_inc(v_j_270_);
v___x_305_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_270_, v___x_304_);
if (lean_obj_tag(v___x_305_) == 0)
{
lean_dec(v_j_270_);
return v___x_305_;
}
else
{
lean_object* v___x_306_; uint8_t v___x_307_; 
lean_dec_ref_known(v___x_305_, 1);
v___x_306_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__2));
v___x_307_ = lean_string_dec_eq(v_tag_269_, v___x_306_);
if (v___x_307_ == 0)
{
goto v___jp_271_;
}
else
{
lean_object* v___x_308_; lean_object* v___x_309_; 
v___x_308_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__3));
lean_inc(v_j_270_);
v___x_309_ = l_Lean_Json_getObjVal_x3f(v_j_270_, v___x_308_);
if (lean_obj_tag(v___x_309_) == 0)
{
lean_object* v_a_310_; lean_object* v___x_312_; uint8_t v_isShared_313_; uint8_t v_isSharedCheck_317_; 
lean_dec(v_j_270_);
v_a_310_ = lean_ctor_get(v___x_309_, 0);
v_isSharedCheck_317_ = !lean_is_exclusive(v___x_309_);
if (v_isSharedCheck_317_ == 0)
{
v___x_312_ = v___x_309_;
v_isShared_313_ = v_isSharedCheck_317_;
goto v_resetjp_311_;
}
else
{
lean_inc(v_a_310_);
lean_dec(v___x_309_);
v___x_312_ = lean_box(0);
v_isShared_313_ = v_isSharedCheck_317_;
goto v_resetjp_311_;
}
v_resetjp_311_:
{
lean_object* v___x_315_; 
if (v_isShared_313_ == 0)
{
v___x_315_ = v___x_312_;
goto v_reusejp_314_;
}
else
{
lean_object* v_reuseFailAlloc_316_; 
v_reuseFailAlloc_316_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_316_, 0, v_a_310_);
v___x_315_ = v_reuseFailAlloc_316_;
goto v_reusejp_314_;
}
v_reusejp_314_:
{
return v___x_315_;
}
}
}
else
{
lean_object* v_a_318_; 
v_a_318_ = lean_ctor_get(v___x_309_, 0);
lean_inc(v_a_318_);
lean_dec_ref_known(v___x_309_, 1);
if (lean_obj_tag(v_a_318_) == 5)
{
lean_object* v___x_319_; lean_object* v___x_320_; lean_object* v___x_321_; 
v___x_319_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__4));
v___x_320_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__5));
lean_inc_ref(v_a_318_);
v___x_321_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_318_, v___x_320_);
if (lean_obj_tag(v___x_321_) == 0)
{
lean_dec_ref_known(v_a_318_, 1);
lean_dec(v_j_270_);
return v___x_321_;
}
else
{
lean_object* v___x_322_; 
lean_dec_ref_known(v___x_321_, 1);
v___x_322_ = l_Lean_Json_getObjVal_x3f(v_a_318_, v___x_319_);
if (lean_obj_tag(v___x_322_) == 0)
{
lean_object* v_a_323_; lean_object* v___x_325_; uint8_t v_isShared_326_; uint8_t v_isSharedCheck_330_; 
lean_dec(v_j_270_);
v_a_323_ = lean_ctor_get(v___x_322_, 0);
v_isSharedCheck_330_ = !lean_is_exclusive(v___x_322_);
if (v_isSharedCheck_330_ == 0)
{
v___x_325_ = v___x_322_;
v_isShared_326_ = v_isSharedCheck_330_;
goto v_resetjp_324_;
}
else
{
lean_inc(v_a_323_);
lean_dec(v___x_322_);
v___x_325_ = lean_box(0);
v_isShared_326_ = v_isSharedCheck_330_;
goto v_resetjp_324_;
}
v_resetjp_324_:
{
lean_object* v___x_328_; 
if (v_isShared_326_ == 0)
{
v___x_328_ = v___x_325_;
goto v_reusejp_327_;
}
else
{
lean_object* v_reuseFailAlloc_329_; 
v_reuseFailAlloc_329_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_329_, 0, v_a_323_);
v___x_328_ = v_reuseFailAlloc_329_;
goto v_reusejp_327_;
}
v_reusejp_327_:
{
return v___x_328_;
}
}
}
else
{
lean_object* v_a_331_; lean_object* v___x_332_; 
v_a_331_ = lean_ctor_get(v___x_322_, 0);
lean_inc(v_a_331_);
lean_dec_ref_known(v___x_322_, 1);
v___x_332_ = lp_proofEnvironment_OCMEnvironment_natural(v_a_331_);
if (lean_obj_tag(v___x_332_) == 0)
{
lean_object* v_a_333_; lean_object* v___x_335_; uint8_t v_isShared_336_; uint8_t v_isSharedCheck_340_; 
lean_dec(v_j_270_);
v_a_333_ = lean_ctor_get(v___x_332_, 0);
v_isSharedCheck_340_ = !lean_is_exclusive(v___x_332_);
if (v_isSharedCheck_340_ == 0)
{
v___x_335_ = v___x_332_;
v_isShared_336_ = v_isSharedCheck_340_;
goto v_resetjp_334_;
}
else
{
lean_inc(v_a_333_);
lean_dec(v___x_332_);
v___x_335_ = lean_box(0);
v_isShared_336_ = v_isSharedCheck_340_;
goto v_resetjp_334_;
}
v_resetjp_334_:
{
lean_object* v___x_338_; 
if (v_isShared_336_ == 0)
{
v___x_338_ = v___x_335_;
goto v_reusejp_337_;
}
else
{
lean_object* v_reuseFailAlloc_339_; 
v_reuseFailAlloc_339_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_339_, 0, v_a_333_);
v___x_338_ = v_reuseFailAlloc_339_;
goto v_reusejp_337_;
}
v_reusejp_337_:
{
return v___x_338_;
}
}
}
else
{
lean_object* v_a_341_; lean_object* v___x_342_; uint8_t v___x_343_; 
v_a_341_ = lean_ctor_get(v___x_332_, 0);
lean_inc(v_a_341_);
lean_dec_ref_known(v___x_332_, 1);
v___x_342_ = lean_unsigned_to_nat(4294967295u);
v___x_343_ = lean_nat_dec_lt(v___x_342_, v_a_341_);
lean_dec(v_a_341_);
if (v___x_343_ == 0)
{
goto v___jp_271_;
}
else
{
lean_object* v___x_344_; 
lean_dec(v_j_270_);
v___x_344_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__7));
return v___x_344_;
}
}
}
}
}
else
{
lean_dec(v_a_318_);
goto v___jp_271_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_declarationSchema___boxed(lean_object* v_tag_370_, lean_object* v_j_371_){
_start:
{
lean_object* v_res_372_; 
v_res_372_ = lp_proofEnvironment_OCMEnvironment_declarationSchema(v_tag_370_, v_j_371_);
lean_dec_ref(v_tag_370_);
return v_res_372_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(lean_object* v_k_373_, lean_object* v_t_374_){
_start:
{
if (lean_obj_tag(v_t_374_) == 0)
{
lean_object* v_k_375_; lean_object* v_l_376_; lean_object* v_r_377_; uint8_t v___x_378_; 
v_k_375_ = lean_ctor_get(v_t_374_, 1);
v_l_376_ = lean_ctor_get(v_t_374_, 3);
v_r_377_ = lean_ctor_get(v_t_374_, 4);
v___x_378_ = lean_string_compare(v_k_373_, v_k_375_);
switch(v___x_378_)
{
case 0:
{
v_t_374_ = v_l_376_;
goto _start;
}
case 1:
{
uint8_t v___x_380_; 
v___x_380_ = 1;
return v___x_380_;
}
default: 
{
v_t_374_ = v_r_377_;
goto _start;
}
}
}
else
{
uint8_t v___x_382_; 
v___x_382_ = 0;
return v___x_382_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg___boxed(lean_object* v_k_383_, lean_object* v_t_384_){
_start:
{
uint8_t v_res_385_; lean_object* v_r_386_; 
v_res_385_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v_k_383_, v_t_384_);
lean_dec(v_t_384_);
lean_dec_ref(v_k_383_);
v_r_386_ = lean_box(v_res_385_);
return v_r_386_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3(lean_object* v_kvPairs_387_, lean_object* v_a_388_, lean_object* v_a_389_){
_start:
{
if (lean_obj_tag(v_a_388_) == 0)
{
lean_object* v___x_390_; 
v___x_390_ = l_List_reverse___redArg(v_a_389_);
return v___x_390_;
}
else
{
lean_object* v_head_391_; lean_object* v_tail_392_; lean_object* v___x_394_; uint8_t v_isShared_395_; uint8_t v_isSharedCheck_402_; 
v_head_391_ = lean_ctor_get(v_a_388_, 0);
v_tail_392_ = lean_ctor_get(v_a_388_, 1);
v_isSharedCheck_402_ = !lean_is_exclusive(v_a_388_);
if (v_isSharedCheck_402_ == 0)
{
v___x_394_ = v_a_388_;
v_isShared_395_ = v_isSharedCheck_402_;
goto v_resetjp_393_;
}
else
{
lean_inc(v_tail_392_);
lean_inc(v_head_391_);
lean_dec(v_a_388_);
v___x_394_ = lean_box(0);
v_isShared_395_ = v_isSharedCheck_402_;
goto v_resetjp_393_;
}
v_resetjp_393_:
{
uint8_t v___x_396_; 
v___x_396_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v_head_391_, v_kvPairs_387_);
if (v___x_396_ == 0)
{
lean_del_object(v___x_394_);
lean_dec(v_head_391_);
v_a_388_ = v_tail_392_;
goto _start;
}
else
{
lean_object* v___x_399_; 
if (v_isShared_395_ == 0)
{
lean_ctor_set(v___x_394_, 1, v_a_389_);
v___x_399_ = v___x_394_;
goto v_reusejp_398_;
}
else
{
lean_object* v_reuseFailAlloc_401_; 
v_reuseFailAlloc_401_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_401_, 0, v_head_391_);
lean_ctor_set(v_reuseFailAlloc_401_, 1, v_a_389_);
v___x_399_ = v_reuseFailAlloc_401_;
goto v_reusejp_398_;
}
v_reusejp_398_:
{
v_a_388_ = v_tail_392_;
v_a_389_ = v___x_399_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3___boxed(lean_object* v_kvPairs_403_, lean_object* v_a_404_, lean_object* v_a_405_){
_start:
{
lean_object* v_res_406_; 
v_res_406_ = lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3(v_kvPairs_403_, v_a_404_, v_a_405_);
lean_dec(v_kvPairs_403_);
return v_res_406_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_itemSchema_spec__1(lean_object* v_snd_407_, lean_object* v_as_408_, size_t v_sz_409_, size_t v_i_410_, lean_object* v_b_411_){
_start:
{
uint8_t v___x_412_; 
v___x_412_ = lean_usize_dec_lt(v_i_410_, v_sz_409_);
if (v___x_412_ == 0)
{
lean_object* v___x_413_; 
v___x_413_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_413_, 0, v_b_411_);
return v___x_413_;
}
else
{
lean_object* v_a_414_; lean_object* v___x_415_; 
v_a_414_ = lean_array_uget_borrowed(v_as_408_, v_i_410_);
lean_inc(v_a_414_);
v___x_415_ = lp_proofEnvironment_OCMEnvironment_declarationSchema(v_snd_407_, v_a_414_);
if (lean_obj_tag(v___x_415_) == 0)
{
return v___x_415_;
}
else
{
lean_object* v___x_416_; size_t v___x_417_; size_t v___x_418_; 
lean_dec_ref_known(v___x_415_, 1);
v___x_416_ = lean_box(0);
v___x_417_ = ((size_t)1ULL);
v___x_418_ = lean_usize_add(v_i_410_, v___x_417_);
v_i_410_ = v___x_418_;
v_b_411_ = v___x_416_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_itemSchema_spec__1___boxed(lean_object* v_snd_420_, lean_object* v_as_421_, lean_object* v_sz_422_, lean_object* v_i_423_, lean_object* v_b_424_){
_start:
{
size_t v_sz_boxed_425_; size_t v_i_boxed_426_; lean_object* v_res_427_; 
v_sz_boxed_425_ = lean_unbox_usize(v_sz_422_);
lean_dec(v_sz_422_);
v_i_boxed_426_ = lean_unbox_usize(v_i_423_);
lean_dec(v_i_423_);
v_res_427_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_itemSchema_spec__1(v_snd_420_, v_as_421_, v_sz_boxed_425_, v_i_boxed_426_, v_b_424_);
lean_dec_ref(v_as_421_);
lean_dec_ref(v_snd_420_);
return v_res_427_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg(lean_object* v_snd_428_, lean_object* v_as_x27_429_, lean_object* v_b_430_){
_start:
{
if (lean_obj_tag(v_as_x27_429_) == 0)
{
lean_object* v___x_431_; 
lean_dec(v_snd_428_);
v___x_431_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_431_, 0, v_b_430_);
return v___x_431_;
}
else
{
lean_object* v_head_432_; lean_object* v_tail_433_; lean_object* v_fst_434_; lean_object* v_snd_435_; lean_object* v___x_436_; 
v_head_432_ = lean_ctor_get(v_as_x27_429_, 0);
v_tail_433_ = lean_ctor_get(v_as_x27_429_, 1);
v_fst_434_ = lean_ctor_get(v_head_432_, 0);
v_snd_435_ = lean_ctor_get(v_head_432_, 1);
lean_inc(v_snd_428_);
v___x_436_ = l_Lean_Json_getObjVal_x3f(v_snd_428_, v_fst_434_);
if (lean_obj_tag(v___x_436_) == 0)
{
lean_object* v_a_437_; lean_object* v___x_439_; uint8_t v_isShared_440_; uint8_t v_isSharedCheck_444_; 
lean_dec(v_snd_428_);
v_a_437_ = lean_ctor_get(v___x_436_, 0);
v_isSharedCheck_444_ = !lean_is_exclusive(v___x_436_);
if (v_isSharedCheck_444_ == 0)
{
v___x_439_ = v___x_436_;
v_isShared_440_ = v_isSharedCheck_444_;
goto v_resetjp_438_;
}
else
{
lean_inc(v_a_437_);
lean_dec(v___x_436_);
v___x_439_ = lean_box(0);
v_isShared_440_ = v_isSharedCheck_444_;
goto v_resetjp_438_;
}
v_resetjp_438_:
{
lean_object* v___x_442_; 
if (v_isShared_440_ == 0)
{
v___x_442_ = v___x_439_;
goto v_reusejp_441_;
}
else
{
lean_object* v_reuseFailAlloc_443_; 
v_reuseFailAlloc_443_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_443_, 0, v_a_437_);
v___x_442_ = v_reuseFailAlloc_443_;
goto v_reusejp_441_;
}
v_reusejp_441_:
{
return v___x_442_;
}
}
}
else
{
lean_object* v_a_445_; lean_object* v___x_446_; 
v_a_445_ = lean_ctor_get(v___x_436_, 0);
lean_inc(v_a_445_);
lean_dec_ref_known(v___x_436_, 1);
v___x_446_ = l_Lean_Json_getArr_x3f(v_a_445_);
if (lean_obj_tag(v___x_446_) == 0)
{
lean_object* v_a_447_; lean_object* v___x_449_; uint8_t v_isShared_450_; uint8_t v_isSharedCheck_454_; 
lean_dec(v_snd_428_);
v_a_447_ = lean_ctor_get(v___x_446_, 0);
v_isSharedCheck_454_ = !lean_is_exclusive(v___x_446_);
if (v_isSharedCheck_454_ == 0)
{
v___x_449_ = v___x_446_;
v_isShared_450_ = v_isSharedCheck_454_;
goto v_resetjp_448_;
}
else
{
lean_inc(v_a_447_);
lean_dec(v___x_446_);
v___x_449_ = lean_box(0);
v_isShared_450_ = v_isSharedCheck_454_;
goto v_resetjp_448_;
}
v_resetjp_448_:
{
lean_object* v___x_452_; 
if (v_isShared_450_ == 0)
{
v___x_452_ = v___x_449_;
goto v_reusejp_451_;
}
else
{
lean_object* v_reuseFailAlloc_453_; 
v_reuseFailAlloc_453_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_453_, 0, v_a_447_);
v___x_452_ = v_reuseFailAlloc_453_;
goto v_reusejp_451_;
}
v_reusejp_451_:
{
return v___x_452_;
}
}
}
else
{
lean_object* v_a_455_; lean_object* v___x_456_; size_t v_sz_457_; size_t v___x_458_; lean_object* v___x_459_; 
v_a_455_ = lean_ctor_get(v___x_446_, 0);
lean_inc(v_a_455_);
lean_dec_ref_known(v___x_446_, 1);
v___x_456_ = lean_box(0);
v_sz_457_ = lean_array_size(v_a_455_);
v___x_458_ = ((size_t)0ULL);
v___x_459_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_itemSchema_spec__1(v_snd_435_, v_a_455_, v_sz_457_, v___x_458_, v___x_456_);
lean_dec(v_a_455_);
if (lean_obj_tag(v___x_459_) == 0)
{
lean_dec(v_snd_428_);
return v___x_459_;
}
else
{
lean_dec_ref_known(v___x_459_, 1);
v_as_x27_429_ = v_tail_433_;
v_b_430_ = v___x_456_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg___boxed(lean_object* v_snd_461_, lean_object* v_as_x27_462_, lean_object* v_b_463_){
_start:
{
lean_object* v_res_464_; 
v_res_464_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg(v_snd_461_, v_as_x27_462_, v_b_463_);
lean_dec(v_as_x27_462_);
return v_res_464_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_itemSchema(lean_object* v_j_654_){
_start:
{
if (lean_obj_tag(v_j_654_) == 5)
{
lean_object* v_kvPairs_661_; lean_object* v___x_662_; uint8_t v___x_663_; 
v_kvPairs_661_ = lean_ctor_get(v_j_654_, 0);
v___x_662_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__4));
v___x_663_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v___x_662_, v_kvPairs_661_);
if (v___x_663_ == 0)
{
lean_object* v___x_664_; uint8_t v___x_665_; 
v___x_664_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__5));
v___x_665_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v___x_664_, v_kvPairs_661_);
if (v___x_665_ == 0)
{
lean_object* v___x_666_; uint8_t v___x_667_; 
v___x_666_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__6));
v___x_667_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v___x_666_, v_kvPairs_661_);
if (v___x_667_ == 0)
{
lean_object* v___x_668_; lean_object* v___x_669_; 
lean_inc(v_kvPairs_661_);
lean_dec_ref_known(v_j_654_, 1);
v___x_668_ = lean_box(0);
v___x_669_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(v___x_668_, v_kvPairs_661_);
lean_dec(v_kvPairs_661_);
if (lean_obj_tag(v___x_669_) == 1)
{
lean_object* v_head_670_; lean_object* v_tail_671_; 
v_head_670_ = lean_ctor_get(v___x_669_, 0);
lean_inc(v_head_670_);
v_tail_671_ = lean_ctor_get(v___x_669_, 1);
lean_inc(v_tail_671_);
lean_dec_ref_known(v___x_669_, 2);
if (lean_obj_tag(v_tail_671_) == 0)
{
lean_object* v_fst_672_; lean_object* v_snd_673_; lean_object* v___x_674_; uint8_t v___x_675_; 
v_fst_672_ = lean_ctor_get(v_head_670_, 0);
lean_inc(v_fst_672_);
v_snd_673_ = lean_ctor_get(v_head_670_, 1);
lean_inc(v_snd_673_);
lean_dec(v_head_670_);
v___x_674_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__7));
v___x_675_ = lean_string_dec_eq(v_fst_672_, v___x_674_);
if (v___x_675_ == 0)
{
lean_object* v___x_676_; 
v___x_676_ = lp_proofEnvironment_OCMEnvironment_declarationSchema(v_fst_672_, v_snd_673_);
lean_dec(v_fst_672_);
return v___x_676_;
}
else
{
lean_object* v___x_677_; lean_object* v___x_678_; 
lean_dec(v_fst_672_);
v___x_677_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__12));
lean_inc(v_snd_673_);
v___x_678_ = lp_proofEnvironment_OCMEnvironment_keys(v_snd_673_, v___x_677_);
if (lean_obj_tag(v___x_678_) == 0)
{
lean_dec(v_snd_673_);
return v___x_678_;
}
else
{
lean_object* v___x_679_; lean_object* v___x_680_; lean_object* v___x_681_; 
lean_dec_ref_known(v___x_678_, 1);
v___x_679_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__18));
v___x_680_ = lean_box(0);
v___x_681_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg(v_snd_673_, v___x_679_, v___x_680_);
if (lean_obj_tag(v___x_681_) == 0)
{
return v___x_681_;
}
else
{
lean_object* v___x_682_; 
lean_dec_ref_known(v___x_681_, 1);
v___x_682_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_682_;
}
}
}
}
else
{
lean_dec(v_tail_671_);
lean_dec(v_head_670_);
goto v___jp_657_;
}
}
else
{
lean_dec(v___x_669_);
goto v___jp_657_;
}
}
else
{
lean_object* v___x_683_; lean_object* v___x_684_; lean_object* v___x_685_; lean_object* v___x_686_; lean_object* v___x_687_; lean_object* v___x_688_; lean_object* v___x_689_; lean_object* v___x_690_; lean_object* v___x_691_; lean_object* v_tags_692_; 
v___x_683_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__21));
v___x_684_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__22));
v___x_685_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__23));
v___x_686_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__24));
v___x_687_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__25));
v___x_688_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__26));
v___x_689_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__29));
v___x_690_ = lean_box(0);
v___x_691_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__40));
v_tags_692_ = lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3(v_kvPairs_661_, v___x_691_, v___x_690_);
if (lean_obj_tag(v_tags_692_) == 1)
{
lean_object* v_tail_693_; 
v_tail_693_ = lean_ctor_get(v_tags_692_, 1);
lean_inc(v_tail_693_);
if (lean_obj_tag(v_tail_693_) == 0)
{
lean_object* v_head_694_; lean_object* v___x_696_; uint8_t v_isShared_697_; uint8_t v_isSharedCheck_734_; 
v_head_694_ = lean_ctor_get(v_tags_692_, 0);
v_isSharedCheck_734_ = !lean_is_exclusive(v_tags_692_);
if (v_isSharedCheck_734_ == 0)
{
lean_object* v_unused_735_; 
v_unused_735_ = lean_ctor_get(v_tags_692_, 1);
lean_dec(v_unused_735_);
v___x_696_ = v_tags_692_;
v_isShared_697_ = v_isSharedCheck_734_;
goto v_resetjp_695_;
}
else
{
lean_inc(v_head_694_);
lean_dec(v_tags_692_);
v___x_696_ = lean_box(0);
v_isShared_697_ = v_isSharedCheck_734_;
goto v_resetjp_695_;
}
v_resetjp_695_:
{
lean_object* v___x_699_; 
lean_inc(v_head_694_);
if (v_isShared_697_ == 0)
{
lean_ctor_set(v___x_696_, 1, v___x_690_);
v___x_699_ = v___x_696_;
goto v_reusejp_698_;
}
else
{
lean_object* v_reuseFailAlloc_733_; 
v_reuseFailAlloc_733_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_733_, 0, v_head_694_);
lean_ctor_set(v_reuseFailAlloc_733_, 1, v___x_690_);
v___x_699_ = v_reuseFailAlloc_733_;
goto v_reusejp_698_;
}
v_reusejp_698_:
{
lean_object* v___x_700_; lean_object* v___x_701_; 
v___x_700_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_700_, 0, v___x_666_);
lean_ctor_set(v___x_700_, 1, v___x_699_);
lean_inc_ref(v_j_654_);
v___x_701_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_654_, v___x_700_);
if (lean_obj_tag(v___x_701_) == 0)
{
lean_dec(v_head_694_);
lean_dec_ref_known(v_j_654_, 1);
return v___x_701_;
}
else
{
lean_object* v___x_702_; 
lean_dec_ref_known(v___x_701_, 1);
v___x_702_ = l_Lean_Json_getObjVal_x3f(v_j_654_, v_head_694_);
if (lean_obj_tag(v___x_702_) == 0)
{
lean_object* v_a_703_; lean_object* v___x_705_; uint8_t v_isShared_706_; uint8_t v_isSharedCheck_710_; 
lean_dec(v_head_694_);
v_a_703_ = lean_ctor_get(v___x_702_, 0);
v_isSharedCheck_710_ = !lean_is_exclusive(v___x_702_);
if (v_isSharedCheck_710_ == 0)
{
v___x_705_ = v___x_702_;
v_isShared_706_ = v_isSharedCheck_710_;
goto v_resetjp_704_;
}
else
{
lean_inc(v_a_703_);
lean_dec(v___x_702_);
v___x_705_ = lean_box(0);
v_isShared_706_ = v_isSharedCheck_710_;
goto v_resetjp_704_;
}
v_resetjp_704_:
{
lean_object* v___x_708_; 
if (v_isShared_706_ == 0)
{
v___x_708_ = v___x_705_;
goto v_reusejp_707_;
}
else
{
lean_object* v_reuseFailAlloc_709_; 
v_reuseFailAlloc_709_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_709_, 0, v_a_703_);
v___x_708_ = v_reuseFailAlloc_709_;
goto v_reusejp_707_;
}
v_reusejp_707_:
{
return v___x_708_;
}
}
}
else
{
lean_object* v_a_711_; uint8_t v___x_715_; 
v_a_711_ = lean_ctor_get(v___x_702_, 0);
lean_inc(v_a_711_);
lean_dec_ref_known(v___x_702_, 1);
v___x_715_ = lean_string_dec_eq(v_head_694_, v___x_683_);
if (v___x_715_ == 0)
{
uint8_t v___x_716_; 
v___x_716_ = lean_string_dec_eq(v_head_694_, v___x_684_);
if (v___x_716_ == 0)
{
uint8_t v___x_717_; 
v___x_717_ = lean_string_dec_eq(v_head_694_, v___x_685_);
if (v___x_717_ == 0)
{
uint8_t v___x_718_; 
v___x_718_ = lean_string_dec_eq(v_head_694_, v___x_686_);
if (v___x_718_ == 0)
{
uint8_t v___x_719_; 
v___x_719_ = lean_string_dec_eq(v_head_694_, v___x_687_);
if (v___x_719_ == 0)
{
uint8_t v___x_720_; 
v___x_720_ = lean_string_dec_eq(v_head_694_, v___x_688_);
if (v___x_720_ == 0)
{
uint8_t v___x_721_; 
v___x_721_ = lean_string_dec_eq(v_head_694_, v___x_689_);
lean_dec(v_head_694_);
if (v___x_721_ == 0)
{
lean_object* v___x_722_; 
lean_dec(v_a_711_);
v___x_722_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_722_;
}
else
{
lean_object* v___x_723_; lean_object* v___x_724_; 
v___x_723_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__50));
v___x_724_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_711_, v___x_723_);
return v___x_724_;
}
}
else
{
lean_object* v___x_725_; lean_object* v___x_726_; 
lean_dec(v_head_694_);
v___x_725_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__56));
v___x_726_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_711_, v___x_725_);
return v___x_726_;
}
}
else
{
lean_object* v___x_727_; lean_object* v___x_728_; 
lean_dec(v_head_694_);
v___x_727_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__62));
v___x_728_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_711_, v___x_727_);
return v___x_728_;
}
}
else
{
lean_dec(v_head_694_);
goto v___jp_712_;
}
}
else
{
lean_dec(v_head_694_);
goto v___jp_712_;
}
}
else
{
lean_object* v___x_729_; lean_object* v___x_730_; 
lean_dec(v_head_694_);
v___x_729_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__66));
v___x_730_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_711_, v___x_729_);
return v___x_730_;
}
}
else
{
lean_object* v___x_731_; lean_object* v___x_732_; 
lean_dec(v_head_694_);
v___x_731_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__69));
v___x_732_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_711_, v___x_731_);
return v___x_732_;
}
v___jp_712_:
{
lean_object* v___x_713_; lean_object* v___x_714_; 
v___x_713_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__46));
v___x_714_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_711_, v___x_713_);
return v___x_714_;
}
}
}
}
}
}
else
{
lean_dec_ref_known(v_tags_692_, 2);
lean_dec(v_tail_693_);
lean_dec_ref_known(v_j_654_, 1);
goto v___jp_655_;
}
}
else
{
lean_dec(v_tags_692_);
lean_dec_ref_known(v_j_654_, 1);
goto v___jp_655_;
}
}
}
else
{
lean_object* v___x_736_; lean_object* v___x_737_; lean_object* v_tags_738_; 
v___x_736_ = lean_box(0);
v___x_737_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__77));
v_tags_738_ = lp_proofEnvironment_List_filterTR_loop___at___00OCMEnvironment_itemSchema_spec__3(v_kvPairs_661_, v___x_737_, v___x_736_);
if (lean_obj_tag(v_tags_738_) == 1)
{
lean_object* v_tail_739_; 
v_tail_739_ = lean_ctor_get(v_tags_738_, 1);
lean_inc(v_tail_739_);
if (lean_obj_tag(v_tail_739_) == 0)
{
lean_object* v_head_740_; lean_object* v___x_742_; uint8_t v_isShared_743_; uint8_t v_isSharedCheck_749_; 
v_head_740_ = lean_ctor_get(v_tags_738_, 0);
v_isSharedCheck_749_ = !lean_is_exclusive(v_tags_738_);
if (v_isSharedCheck_749_ == 0)
{
lean_object* v_unused_750_; 
v_unused_750_ = lean_ctor_get(v_tags_738_, 1);
lean_dec(v_unused_750_);
v___x_742_ = v_tags_738_;
v_isShared_743_ = v_isSharedCheck_749_;
goto v_resetjp_741_;
}
else
{
lean_inc(v_head_740_);
lean_dec(v_tags_738_);
v___x_742_ = lean_box(0);
v_isShared_743_ = v_isSharedCheck_749_;
goto v_resetjp_741_;
}
v_resetjp_741_:
{
lean_object* v___x_745_; 
if (v_isShared_743_ == 0)
{
lean_ctor_set(v___x_742_, 1, v___x_736_);
v___x_745_ = v___x_742_;
goto v_reusejp_744_;
}
else
{
lean_object* v_reuseFailAlloc_748_; 
v_reuseFailAlloc_748_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_748_, 0, v_head_740_);
lean_ctor_set(v_reuseFailAlloc_748_, 1, v___x_736_);
v___x_745_ = v_reuseFailAlloc_748_;
goto v_reusejp_744_;
}
v_reusejp_744_:
{
lean_object* v___x_746_; lean_object* v___x_747_; 
v___x_746_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_746_, 0, v___x_664_);
lean_ctor_set(v___x_746_, 1, v___x_745_);
v___x_747_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_654_, v___x_746_);
return v___x_747_;
}
}
}
else
{
lean_dec_ref_known(v_tags_738_, 2);
lean_dec(v_tail_739_);
lean_dec_ref_known(v_j_654_, 1);
goto v___jp_659_;
}
}
else
{
lean_dec(v_tags_738_);
lean_dec_ref_known(v_j_654_, 1);
goto v___jp_659_;
}
}
}
else
{
lean_object* v___x_751_; uint8_t v___x_752_; 
v___x_751_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__78));
v___x_752_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v___x_751_, v_kvPairs_661_);
if (v___x_752_ == 0)
{
lean_object* v___x_753_; lean_object* v___x_754_; lean_object* v___x_755_; 
v___x_753_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__79));
v___x_754_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__81));
lean_inc_ref(v_j_654_);
v___x_755_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_654_, v___x_754_);
if (lean_obj_tag(v___x_755_) == 0)
{
lean_dec_ref_known(v_j_654_, 1);
return v___x_755_;
}
else
{
lean_object* v___x_756_; 
lean_dec_ref_known(v___x_755_, 1);
v___x_756_ = l_Lean_Json_getObjVal_x3f(v_j_654_, v___x_753_);
if (lean_obj_tag(v___x_756_) == 0)
{
lean_object* v_a_757_; lean_object* v___x_759_; uint8_t v_isShared_760_; uint8_t v_isSharedCheck_764_; 
v_a_757_ = lean_ctor_get(v___x_756_, 0);
v_isSharedCheck_764_ = !lean_is_exclusive(v___x_756_);
if (v_isSharedCheck_764_ == 0)
{
v___x_759_ = v___x_756_;
v_isShared_760_ = v_isSharedCheck_764_;
goto v_resetjp_758_;
}
else
{
lean_inc(v_a_757_);
lean_dec(v___x_756_);
v___x_759_ = lean_box(0);
v_isShared_760_ = v_isSharedCheck_764_;
goto v_resetjp_758_;
}
v_resetjp_758_:
{
lean_object* v___x_762_; 
if (v_isShared_760_ == 0)
{
v___x_762_ = v___x_759_;
goto v_reusejp_761_;
}
else
{
lean_object* v_reuseFailAlloc_763_; 
v_reuseFailAlloc_763_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_763_, 0, v_a_757_);
v___x_762_ = v_reuseFailAlloc_763_;
goto v_reusejp_761_;
}
v_reusejp_761_:
{
return v___x_762_;
}
}
}
else
{
lean_object* v_a_765_; lean_object* v___x_766_; lean_object* v___x_767_; 
v_a_765_ = lean_ctor_get(v___x_756_, 0);
lean_inc(v_a_765_);
lean_dec_ref_known(v___x_756_, 1);
v___x_766_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__85));
v___x_767_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_765_, v___x_766_);
return v___x_767_;
}
}
}
else
{
lean_object* v___x_768_; lean_object* v___x_769_; 
v___x_768_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__87));
lean_inc_ref(v_j_654_);
v___x_769_ = lp_proofEnvironment_OCMEnvironment_keys(v_j_654_, v___x_768_);
if (lean_obj_tag(v___x_769_) == 0)
{
lean_dec_ref_known(v_j_654_, 1);
return v___x_769_;
}
else
{
lean_object* v___x_770_; 
lean_dec_ref_known(v___x_769_, 1);
v___x_770_ = l_Lean_Json_getObjVal_x3f(v_j_654_, v___x_751_);
if (lean_obj_tag(v___x_770_) == 0)
{
lean_object* v_a_771_; lean_object* v___x_773_; uint8_t v_isShared_774_; uint8_t v_isSharedCheck_778_; 
v_a_771_ = lean_ctor_get(v___x_770_, 0);
v_isSharedCheck_778_ = !lean_is_exclusive(v___x_770_);
if (v_isSharedCheck_778_ == 0)
{
v___x_773_ = v___x_770_;
v_isShared_774_ = v_isSharedCheck_778_;
goto v_resetjp_772_;
}
else
{
lean_inc(v_a_771_);
lean_dec(v___x_770_);
v___x_773_ = lean_box(0);
v_isShared_774_ = v_isSharedCheck_778_;
goto v_resetjp_772_;
}
v_resetjp_772_:
{
lean_object* v___x_776_; 
if (v_isShared_774_ == 0)
{
v___x_776_ = v___x_773_;
goto v_reusejp_775_;
}
else
{
lean_object* v_reuseFailAlloc_777_; 
v_reuseFailAlloc_777_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_777_, 0, v_a_771_);
v___x_776_ = v_reuseFailAlloc_777_;
goto v_reusejp_775_;
}
v_reusejp_775_:
{
return v___x_776_;
}
}
}
else
{
lean_object* v_a_779_; lean_object* v___x_780_; lean_object* v___x_781_; 
v_a_779_ = lean_ctor_get(v___x_770_, 0);
lean_inc(v_a_779_);
lean_dec_ref_known(v___x_770_, 1);
v___x_780_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__88));
v___x_781_ = lp_proofEnvironment_OCMEnvironment_keys(v_a_779_, v___x_780_);
return v___x_781_;
}
}
}
}
}
else
{
lean_object* v___x_782_; 
lean_dec(v_j_654_);
v___x_782_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__5));
return v___x_782_;
}
v___jp_655_:
{
lean_object* v___x_656_; 
v___x_656_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__1));
return v___x_656_;
}
v___jp_657_:
{
lean_object* v___x_658_; 
v___x_658_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__15));
return v___x_658_;
}
v___jp_659_:
{
lean_object* v___x_660_; 
v___x_660_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__3));
return v___x_660_;
}
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0(lean_object* v_00_u03b2_783_, lean_object* v_k_784_, lean_object* v_t_785_){
_start:
{
uint8_t v___x_786_; 
v___x_786_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___redArg(v_k_784_, v_t_785_);
return v___x_786_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0___boxed(lean_object* v_00_u03b2_787_, lean_object* v_k_788_, lean_object* v_t_789_){
_start:
{
uint8_t v_res_790_; lean_object* v_r_791_; 
v_res_790_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_contains___at___00OCMEnvironment_itemSchema_spec__0(v_00_u03b2_787_, v_k_788_, v_t_789_);
lean_dec(v_t_789_);
lean_dec_ref(v_k_788_);
v_r_791_ = lean_box(v_res_790_);
return v_r_791_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2(lean_object* v_snd_792_, lean_object* v_as_793_, lean_object* v_as_x27_794_, lean_object* v_b_795_, lean_object* v_a_796_){
_start:
{
lean_object* v___x_797_; 
v___x_797_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___redArg(v_snd_792_, v_as_x27_794_, v_b_795_);
return v___x_797_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2___boxed(lean_object* v_snd_798_, lean_object* v_as_799_, lean_object* v_as_x27_800_, lean_object* v_b_801_, lean_object* v_a_802_){
_start:
{
lean_object* v_res_803_; 
v_res_803_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_itemSchema_spec__2(v_snd_798_, v_as_799_, v_as_x27_800_, v_b_801_, v_a_802_);
lean_dec(v_as_x27_800_);
lean_dec(v_as_799_);
return v_res_803_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0(lean_object* v_levels_804_, lean_object* v_as_805_, size_t v_sz_806_, size_t v_i_807_, lean_object* v_b_808_){
_start:
{
uint8_t v___x_809_; 
v___x_809_ = lean_usize_dec_lt(v_i_807_, v_sz_806_);
if (v___x_809_ == 0)
{
lean_object* v___x_810_; 
v___x_810_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_810_, 0, v_b_808_);
return v___x_810_;
}
else
{
lean_object* v_a_811_; lean_object* v___x_812_; 
v_a_811_ = lean_array_uget_borrowed(v_as_805_, v_i_807_);
lean_inc(v_a_811_);
v___x_812_ = lp_proofEnvironment_OCMEnvironment_index(v_a_811_, v_levels_804_);
if (lean_obj_tag(v___x_812_) == 0)
{
return v___x_812_;
}
else
{
lean_object* v___x_813_; size_t v___x_814_; size_t v___x_815_; 
lean_dec_ref_known(v___x_812_, 1);
v___x_813_ = lean_box(0);
v___x_814_ = ((size_t)1ULL);
v___x_815_ = lean_usize_add(v_i_807_, v___x_814_);
v_i_807_ = v___x_815_;
v_b_808_ = v___x_813_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0___boxed(lean_object* v_levels_817_, lean_object* v_as_818_, lean_object* v_sz_819_, lean_object* v_i_820_, lean_object* v_b_821_){
_start:
{
size_t v_sz_boxed_822_; size_t v_i_boxed_823_; lean_object* v_res_824_; 
v_sz_boxed_822_ = lean_unbox_usize(v_sz_819_);
lean_dec(v_sz_819_);
v_i_boxed_823_ = lean_unbox_usize(v_i_820_);
lean_dec(v_i_820_);
v_res_824_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0(v_levels_817_, v_as_818_, v_sz_boxed_822_, v_i_boxed_823_, v_b_821_);
lean_dec_ref(v_as_818_);
lean_dec(v_levels_817_);
return v_res_824_;
}
}
LEAN_EXPORT uint8_t lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2(lean_object* v_a_825_, lean_object* v_x_826_){
_start:
{
if (lean_obj_tag(v_x_826_) == 0)
{
uint8_t v___x_827_; 
v___x_827_ = 0;
return v___x_827_;
}
else
{
lean_object* v_head_828_; lean_object* v_tail_829_; uint8_t v___x_830_; 
v_head_828_ = lean_ctor_get(v_x_826_, 0);
v_tail_829_ = lean_ctor_get(v_x_826_, 1);
v___x_830_ = lean_string_dec_eq(v_a_825_, v_head_828_);
if (v___x_830_ == 0)
{
v_x_826_ = v_tail_829_;
goto _start;
}
else
{
return v___x_830_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2___boxed(lean_object* v_a_832_, lean_object* v_x_833_){
_start:
{
uint8_t v_res_834_; lean_object* v_r_835_; 
v_res_834_ = lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2(v_a_832_, v_x_833_);
lean_dec(v_x_833_);
lean_dec_ref(v_a_832_);
v_r_835_ = lean_box(v_res_834_);
return v_r_835_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__1(lean_object* v_names_836_, lean_object* v_levels_837_, lean_object* v_exprs_838_, lean_object* v_as_839_, size_t v_sz_840_, size_t v_i_841_, lean_object* v_b_842_){
_start:
{
lean_object* v_a_844_; uint8_t v___x_848_; 
v___x_848_ = lean_usize_dec_lt(v_i_841_, v_sz_840_);
if (v___x_848_ == 0)
{
lean_object* v___x_849_; 
v___x_849_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_849_, 0, v_b_842_);
return v___x_849_;
}
else
{
lean_object* v___x_850_; lean_object* v_a_851_; 
v___x_850_ = lean_box(0);
v_a_851_ = lean_array_uget_borrowed(v_as_839_, v_i_841_);
if (lean_obj_tag(v_a_851_) == 5)
{
lean_object* v___x_852_; 
lean_inc_ref(v_a_851_);
v___x_852_ = lp_proofEnvironment_OCMEnvironment_references(v_a_851_, v_names_836_, v_levels_837_, v_exprs_838_);
if (lean_obj_tag(v___x_852_) == 0)
{
return v___x_852_;
}
else
{
lean_dec_ref_known(v___x_852_, 1);
v_a_844_ = v___x_850_;
goto v___jp_843_;
}
}
else
{
lean_object* v___x_853_; 
lean_inc(v_a_851_);
v___x_853_ = lp_proofEnvironment_OCMEnvironment_index(v_a_851_, v_names_836_);
if (lean_obj_tag(v___x_853_) == 0)
{
return v___x_853_;
}
else
{
lean_dec_ref_known(v___x_853_, 1);
v_a_844_ = v___x_850_;
goto v___jp_843_;
}
}
}
v___jp_843_:
{
size_t v___x_845_; size_t v___x_846_; 
v___x_845_ = ((size_t)1ULL);
v___x_846_ = lean_usize_add(v_i_841_, v___x_845_);
v_i_841_ = v___x_846_;
v_b_842_ = v_a_844_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg(lean_object* v_levels_893_, lean_object* v_names_894_, lean_object* v_exprs_895_, lean_object* v_as_x27_896_, lean_object* v_b_897_){
_start:
{
if (lean_obj_tag(v_as_x27_896_) == 0)
{
lean_object* v___x_898_; 
v___x_898_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_898_, 0, v_b_897_);
return v___x_898_;
}
else
{
lean_object* v_head_899_; lean_object* v_tail_900_; lean_object* v_fst_901_; lean_object* v_snd_902_; lean_object* v___x_903_; uint8_t v___y_938_; lean_object* v___x_967_; uint8_t v___x_968_; 
v_head_899_ = lean_ctor_get(v_as_x27_896_, 0);
v_tail_900_ = lean_ctor_get(v_as_x27_896_, 1);
v_fst_901_ = lean_ctor_get(v_head_899_, 0);
v_snd_902_ = lean_ctor_get(v_head_899_, 1);
v___x_903_ = lean_box(0);
v___x_967_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__4));
v___x_968_ = lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2(v_fst_901_, v___x_967_);
if (v___x_968_ == 0)
{
lean_object* v___x_969_; uint8_t v___x_970_; 
v___x_969_ = ((lean_object*)(lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___closed__12));
v___x_970_ = lp_proofEnvironment_List_elem___at___00OCMEnvironment_references_spec__2(v_fst_901_, v___x_969_);
if (v___x_970_ == 0)
{
lean_object* v___x_971_; uint8_t v___x_972_; 
v___x_971_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__20));
v___x_972_ = lean_string_dec_eq(v_fst_901_, v___x_971_);
if (v___x_972_ == 0)
{
lean_object* v___x_973_; uint8_t v___x_974_; 
v___x_973_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__70));
v___x_974_ = lean_string_dec_eq(v_fst_901_, v___x_973_);
if (v___x_974_ == 0)
{
lean_object* v___x_975_; uint8_t v___x_976_; 
v___x_975_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__71));
v___x_976_ = lean_string_dec_eq(v_fst_901_, v___x_975_);
if (v___x_976_ == 0)
{
lean_object* v___x_977_; uint8_t v___x_978_; 
v___x_977_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__72));
v___x_978_ = lean_string_dec_eq(v_fst_901_, v___x_977_);
v___y_938_ = v___x_978_;
goto v___jp_937_;
}
else
{
v___y_938_ = v___x_976_;
goto v___jp_937_;
}
}
else
{
goto v___jp_964_;
}
}
else
{
goto v___jp_964_;
}
}
else
{
lean_object* v___x_979_; 
lean_inc(v_snd_902_);
v___x_979_ = lp_proofEnvironment_OCMEnvironment_index(v_snd_902_, v_exprs_895_);
if (lean_obj_tag(v___x_979_) == 0)
{
return v___x_979_;
}
else
{
lean_dec_ref_known(v___x_979_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
}
else
{
lean_object* v___x_981_; 
lean_inc(v_snd_902_);
v___x_981_ = lp_proofEnvironment_OCMEnvironment_index(v_snd_902_, v_names_894_);
if (lean_obj_tag(v___x_981_) == 0)
{
return v___x_981_;
}
else
{
lean_dec_ref_known(v___x_981_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
v___jp_904_:
{
lean_object* v___x_905_; 
lean_inc(v_snd_902_);
v___x_905_ = lp_proofEnvironment_OCMEnvironment_references(v_snd_902_, v_names_894_, v_levels_893_, v_exprs_895_);
if (lean_obj_tag(v___x_905_) == 0)
{
return v___x_905_;
}
else
{
lean_dec_ref_known(v___x_905_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
v___jp_907_:
{
lean_object* v___x_908_; 
lean_inc(v_snd_902_);
v___x_908_ = l_Lean_Json_getArr_x3f(v_snd_902_);
if (lean_obj_tag(v___x_908_) == 0)
{
lean_object* v_a_909_; lean_object* v___x_911_; uint8_t v_isShared_912_; uint8_t v_isSharedCheck_916_; 
v_a_909_ = lean_ctor_get(v___x_908_, 0);
v_isSharedCheck_916_ = !lean_is_exclusive(v___x_908_);
if (v_isSharedCheck_916_ == 0)
{
v___x_911_ = v___x_908_;
v_isShared_912_ = v_isSharedCheck_916_;
goto v_resetjp_910_;
}
else
{
lean_inc(v_a_909_);
lean_dec(v___x_908_);
v___x_911_ = lean_box(0);
v_isShared_912_ = v_isSharedCheck_916_;
goto v_resetjp_910_;
}
v_resetjp_910_:
{
lean_object* v___x_914_; 
if (v_isShared_912_ == 0)
{
v___x_914_ = v___x_911_;
goto v_reusejp_913_;
}
else
{
lean_object* v_reuseFailAlloc_915_; 
v_reuseFailAlloc_915_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_915_, 0, v_a_909_);
v___x_914_ = v_reuseFailAlloc_915_;
goto v_reusejp_913_;
}
v_reusejp_913_:
{
return v___x_914_;
}
}
}
else
{
lean_object* v_a_917_; size_t v_sz_918_; size_t v___x_919_; lean_object* v___x_920_; 
v_a_917_ = lean_ctor_get(v___x_908_, 0);
lean_inc(v_a_917_);
lean_dec_ref_known(v___x_908_, 1);
v_sz_918_ = lean_array_size(v_a_917_);
v___x_919_ = ((size_t)0ULL);
v___x_920_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0(v_names_894_, v_a_917_, v_sz_918_, v___x_919_, v___x_903_);
lean_dec(v_a_917_);
if (lean_obj_tag(v___x_920_) == 0)
{
return v___x_920_;
}
else
{
lean_dec_ref_known(v___x_920_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
}
v___jp_922_:
{
lean_object* v___x_923_; 
lean_inc(v_snd_902_);
v___x_923_ = l_Lean_Json_getArr_x3f(v_snd_902_);
if (lean_obj_tag(v___x_923_) == 0)
{
lean_object* v_a_924_; lean_object* v___x_926_; uint8_t v_isShared_927_; uint8_t v_isSharedCheck_931_; 
v_a_924_ = lean_ctor_get(v___x_923_, 0);
v_isSharedCheck_931_ = !lean_is_exclusive(v___x_923_);
if (v_isSharedCheck_931_ == 0)
{
v___x_926_ = v___x_923_;
v_isShared_927_ = v_isSharedCheck_931_;
goto v_resetjp_925_;
}
else
{
lean_inc(v_a_924_);
lean_dec(v___x_923_);
v___x_926_ = lean_box(0);
v_isShared_927_ = v_isSharedCheck_931_;
goto v_resetjp_925_;
}
v_resetjp_925_:
{
lean_object* v___x_929_; 
if (v_isShared_927_ == 0)
{
v___x_929_ = v___x_926_;
goto v_reusejp_928_;
}
else
{
lean_object* v_reuseFailAlloc_930_; 
v_reuseFailAlloc_930_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_930_, 0, v_a_924_);
v___x_929_ = v_reuseFailAlloc_930_;
goto v_reusejp_928_;
}
v_reusejp_928_:
{
return v___x_929_;
}
}
}
else
{
lean_object* v_a_932_; size_t v_sz_933_; size_t v___x_934_; lean_object* v___x_935_; 
v_a_932_ = lean_ctor_get(v___x_923_, 0);
lean_inc(v_a_932_);
lean_dec_ref_known(v___x_923_, 1);
v_sz_933_ = lean_array_size(v_a_932_);
v___x_934_ = ((size_t)0ULL);
v___x_935_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__0(v_levels_893_, v_a_932_, v_sz_933_, v___x_934_, v___x_903_);
lean_dec(v_a_932_);
if (lean_obj_tag(v___x_935_) == 0)
{
return v___x_935_;
}
else
{
lean_dec_ref_known(v___x_935_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
}
v___jp_937_:
{
if (v___y_938_ == 0)
{
lean_object* v___x_939_; uint8_t v___x_940_; 
v___x_939_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__67));
v___x_940_ = lean_string_dec_eq(v_fst_901_, v___x_939_);
if (v___x_940_ == 0)
{
lean_object* v___x_941_; uint8_t v___x_942_; 
v___x_941_ = ((lean_object*)(lp_proofEnvironment___private_OCMEnvironment_PacketSchema_0__OCMEnvironment_baseFields___closed__1));
v___x_942_ = lean_string_dec_eq(v_fst_901_, v___x_941_);
if (v___x_942_ == 0)
{
lean_object* v___x_943_; uint8_t v___x_944_; 
v___x_943_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__16));
v___x_944_ = lean_string_dec_eq(v_fst_901_, v___x_943_);
if (v___x_944_ == 0)
{
lean_object* v___x_945_; uint8_t v___x_946_; 
v___x_945_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_declarationSchema___closed__38));
v___x_946_ = lean_string_dec_eq(v_fst_901_, v___x_945_);
if (v___x_946_ == 0)
{
lean_object* v___x_947_; uint8_t v___x_948_; 
v___x_947_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_itemSchema___closed__48));
v___x_948_ = lean_string_dec_eq(v_fst_901_, v___x_947_);
if (v___x_948_ == 0)
{
goto v___jp_904_;
}
else
{
if (v___x_946_ == 0)
{
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
else
{
goto v___jp_904_;
}
}
}
else
{
lean_object* v___x_950_; 
lean_inc(v_snd_902_);
v___x_950_ = l_Lean_Json_getArr_x3f(v_snd_902_);
if (lean_obj_tag(v___x_950_) == 0)
{
lean_object* v_a_951_; lean_object* v___x_953_; uint8_t v_isShared_954_; uint8_t v_isSharedCheck_958_; 
v_a_951_ = lean_ctor_get(v___x_950_, 0);
v_isSharedCheck_958_ = !lean_is_exclusive(v___x_950_);
if (v_isSharedCheck_958_ == 0)
{
v___x_953_ = v___x_950_;
v_isShared_954_ = v_isSharedCheck_958_;
goto v_resetjp_952_;
}
else
{
lean_inc(v_a_951_);
lean_dec(v___x_950_);
v___x_953_ = lean_box(0);
v_isShared_954_ = v_isSharedCheck_958_;
goto v_resetjp_952_;
}
v_resetjp_952_:
{
lean_object* v___x_956_; 
if (v_isShared_954_ == 0)
{
v___x_956_ = v___x_953_;
goto v_reusejp_955_;
}
else
{
lean_object* v_reuseFailAlloc_957_; 
v_reuseFailAlloc_957_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_957_, 0, v_a_951_);
v___x_956_ = v_reuseFailAlloc_957_;
goto v_reusejp_955_;
}
v_reusejp_955_:
{
return v___x_956_;
}
}
}
else
{
lean_object* v_a_959_; size_t v_sz_960_; size_t v___x_961_; lean_object* v___x_962_; 
v_a_959_ = lean_ctor_get(v___x_950_, 0);
lean_inc(v_a_959_);
lean_dec_ref_known(v___x_950_, 1);
v_sz_960_ = lean_array_size(v_a_959_);
v___x_961_ = ((size_t)0ULL);
v___x_962_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__1(v_names_894_, v_levels_893_, v_exprs_895_, v_a_959_, v_sz_960_, v___x_961_, v___x_903_);
lean_dec(v_a_959_);
if (lean_obj_tag(v___x_962_) == 0)
{
return v___x_962_;
}
else
{
lean_dec_ref_known(v___x_962_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
}
}
else
{
goto v___jp_907_;
}
}
else
{
goto v___jp_907_;
}
}
else
{
goto v___jp_922_;
}
}
else
{
goto v___jp_922_;
}
}
v___jp_964_:
{
lean_object* v___x_965_; 
lean_inc(v_snd_902_);
v___x_965_ = lp_proofEnvironment_OCMEnvironment_index(v_snd_902_, v_levels_893_);
if (lean_obj_tag(v___x_965_) == 0)
{
return v___x_965_;
}
else
{
lean_dec_ref_known(v___x_965_, 1);
v_as_x27_896_ = v_tail_900_;
v_b_897_ = v___x_903_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_references(lean_object* v_j_983_, lean_object* v_names_984_, lean_object* v_levels_985_, lean_object* v_exprs_986_){
_start:
{
switch(lean_obj_tag(v_j_983_))
{
case 5:
{
lean_object* v_kvPairs_987_; lean_object* v___x_988_; lean_object* v___x_989_; lean_object* v___x_990_; lean_object* v___x_991_; 
v_kvPairs_987_ = lean_ctor_get(v_j_983_, 0);
lean_inc(v_kvPairs_987_);
lean_dec_ref_known(v_j_983_, 1);
v___x_988_ = lean_box(0);
v___x_989_ = lp_proofEnvironment_Std_DTreeMap_Internal_Impl_foldrM___at___00Export_Parse_parseItem_spec__2(v___x_988_, v_kvPairs_987_);
lean_dec(v_kvPairs_987_);
v___x_990_ = lean_box(0);
v___x_991_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg(v_levels_985_, v_names_984_, v_exprs_986_, v___x_989_, v___x_990_);
lean_dec(v___x_989_);
if (lean_obj_tag(v___x_991_) == 0)
{
return v___x_991_;
}
else
{
lean_object* v___x_992_; 
lean_dec_ref_known(v___x_991_, 1);
v___x_992_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_992_;
}
}
case 4:
{
lean_object* v_elems_993_; lean_object* v___x_994_; size_t v_sz_995_; size_t v___x_996_; lean_object* v___x_997_; 
v_elems_993_ = lean_ctor_get(v_j_983_, 0);
lean_inc_ref(v_elems_993_);
lean_dec_ref_known(v_j_983_, 1);
v___x_994_ = lean_box(0);
v_sz_995_ = lean_array_size(v_elems_993_);
v___x_996_ = ((size_t)0ULL);
v___x_997_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__4(v_names_984_, v_levels_985_, v_exprs_986_, v_elems_993_, v_sz_995_, v___x_996_, v___x_994_);
lean_dec_ref(v_elems_993_);
if (lean_obj_tag(v___x_997_) == 0)
{
return v___x_997_;
}
else
{
lean_object* v___x_998_; 
lean_dec_ref_known(v___x_997_, 1);
v___x_998_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_998_;
}
}
case 2:
{
lean_object* v___x_999_; 
v___x_999_ = lp_proofEnvironment_OCMEnvironment_natural(v_j_983_);
if (lean_obj_tag(v___x_999_) == 0)
{
lean_object* v_a_1000_; lean_object* v___x_1002_; uint8_t v_isShared_1003_; uint8_t v_isSharedCheck_1007_; 
v_a_1000_ = lean_ctor_get(v___x_999_, 0);
v_isSharedCheck_1007_ = !lean_is_exclusive(v___x_999_);
if (v_isSharedCheck_1007_ == 0)
{
v___x_1002_ = v___x_999_;
v_isShared_1003_ = v_isSharedCheck_1007_;
goto v_resetjp_1001_;
}
else
{
lean_inc(v_a_1000_);
lean_dec(v___x_999_);
v___x_1002_ = lean_box(0);
v_isShared_1003_ = v_isSharedCheck_1007_;
goto v_resetjp_1001_;
}
v_resetjp_1001_:
{
lean_object* v___x_1005_; 
if (v_isShared_1003_ == 0)
{
v___x_1005_ = v___x_1002_;
goto v_reusejp_1004_;
}
else
{
lean_object* v_reuseFailAlloc_1006_; 
v_reuseFailAlloc_1006_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1006_, 0, v_a_1000_);
v___x_1005_ = v_reuseFailAlloc_1006_;
goto v_reusejp_1004_;
}
v_reusejp_1004_:
{
return v___x_1005_;
}
}
}
else
{
lean_object* v___x_1008_; 
lean_dec_ref_known(v___x_999_, 1);
v___x_1008_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_1008_;
}
}
default: 
{
lean_object* v___x_1009_; 
lean_dec(v_j_983_);
v___x_1009_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_keys___closed__3));
return v___x_1009_;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__4(lean_object* v_names_1010_, lean_object* v_levels_1011_, lean_object* v_exprs_1012_, lean_object* v_as_1013_, size_t v_sz_1014_, size_t v_i_1015_, lean_object* v_b_1016_){
_start:
{
uint8_t v___x_1017_; 
v___x_1017_ = lean_usize_dec_lt(v_i_1015_, v_sz_1014_);
if (v___x_1017_ == 0)
{
lean_object* v___x_1018_; 
v___x_1018_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1018_, 0, v_b_1016_);
return v___x_1018_;
}
else
{
lean_object* v_a_1019_; lean_object* v___x_1020_; 
v_a_1019_ = lean_array_uget_borrowed(v_as_1013_, v_i_1015_);
lean_inc(v_a_1019_);
v___x_1020_ = lp_proofEnvironment_OCMEnvironment_references(v_a_1019_, v_names_1010_, v_levels_1011_, v_exprs_1012_);
if (lean_obj_tag(v___x_1020_) == 0)
{
return v___x_1020_;
}
else
{
lean_object* v___x_1021_; size_t v___x_1022_; size_t v___x_1023_; 
lean_dec_ref_known(v___x_1020_, 1);
v___x_1021_ = lean_box(0);
v___x_1022_ = ((size_t)1ULL);
v___x_1023_ = lean_usize_add(v_i_1015_, v___x_1022_);
v_i_1015_ = v___x_1023_;
v_b_1016_ = v___x_1021_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__4___boxed(lean_object* v_names_1025_, lean_object* v_levels_1026_, lean_object* v_exprs_1027_, lean_object* v_as_1028_, lean_object* v_sz_1029_, lean_object* v_i_1030_, lean_object* v_b_1031_){
_start:
{
size_t v_sz_boxed_1032_; size_t v_i_boxed_1033_; lean_object* v_res_1034_; 
v_sz_boxed_1032_ = lean_unbox_usize(v_sz_1029_);
lean_dec(v_sz_1029_);
v_i_boxed_1033_ = lean_unbox_usize(v_i_1030_);
lean_dec(v_i_1030_);
v_res_1034_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__4(v_names_1025_, v_levels_1026_, v_exprs_1027_, v_as_1028_, v_sz_boxed_1032_, v_i_boxed_1033_, v_b_1031_);
lean_dec_ref(v_as_1028_);
lean_dec(v_exprs_1027_);
lean_dec(v_levels_1026_);
lean_dec(v_names_1025_);
return v_res_1034_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__1___boxed(lean_object* v_names_1035_, lean_object* v_levels_1036_, lean_object* v_exprs_1037_, lean_object* v_as_1038_, lean_object* v_sz_1039_, lean_object* v_i_1040_, lean_object* v_b_1041_){
_start:
{
size_t v_sz_boxed_1042_; size_t v_i_boxed_1043_; lean_object* v_res_1044_; 
v_sz_boxed_1042_ = lean_unbox_usize(v_sz_1039_);
lean_dec(v_sz_1039_);
v_i_boxed_1043_ = lean_unbox_usize(v_i_1040_);
lean_dec(v_i_1040_);
v_res_1044_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_references_spec__1(v_names_1035_, v_levels_1036_, v_exprs_1037_, v_as_1038_, v_sz_boxed_1042_, v_i_boxed_1043_, v_b_1041_);
lean_dec_ref(v_as_1038_);
lean_dec(v_exprs_1037_);
lean_dec(v_levels_1036_);
lean_dec(v_names_1035_);
return v_res_1044_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_references___boxed(lean_object* v_j_1045_, lean_object* v_names_1046_, lean_object* v_levels_1047_, lean_object* v_exprs_1048_){
_start:
{
lean_object* v_res_1049_; 
v_res_1049_ = lp_proofEnvironment_OCMEnvironment_references(v_j_1045_, v_names_1046_, v_levels_1047_, v_exprs_1048_);
lean_dec(v_exprs_1048_);
lean_dec(v_levels_1047_);
lean_dec(v_names_1046_);
return v_res_1049_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg___boxed(lean_object* v_levels_1050_, lean_object* v_names_1051_, lean_object* v_exprs_1052_, lean_object* v_as_x27_1053_, lean_object* v_b_1054_){
_start:
{
lean_object* v_res_1055_; 
v_res_1055_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg(v_levels_1050_, v_names_1051_, v_exprs_1052_, v_as_x27_1053_, v_b_1054_);
lean_dec(v_as_x27_1053_);
lean_dec(v_exprs_1052_);
lean_dec(v_names_1051_);
lean_dec(v_levels_1050_);
return v_res_1055_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3(lean_object* v_levels_1056_, lean_object* v_names_1057_, lean_object* v_exprs_1058_, lean_object* v_as_1059_, lean_object* v_as_x27_1060_, lean_object* v_b_1061_, lean_object* v_a_1062_){
_start:
{
lean_object* v___x_1063_; 
v___x_1063_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___redArg(v_levels_1056_, v_names_1057_, v_exprs_1058_, v_as_x27_1060_, v_b_1061_);
return v___x_1063_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3___boxed(lean_object* v_levels_1064_, lean_object* v_names_1065_, lean_object* v_exprs_1066_, lean_object* v_as_1067_, lean_object* v_as_x27_1068_, lean_object* v_b_1069_, lean_object* v_a_1070_){
_start:
{
lean_object* v_res_1071_; 
v_res_1071_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_references_spec__3(v_levels_1064_, v_names_1065_, v_exprs_1066_, v_as_1067_, v_as_x27_1068_, v_b_1069_, v_a_1070_);
lean_dec(v_as_x27_1068_);
lean_dec(v_as_1067_);
lean_dec(v_exprs_1066_);
lean_dec(v_names_1065_);
lean_dec(v_levels_1064_);
return v_res_1071_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_Export_Parse(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_PacketSchema(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_Export_Parse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
