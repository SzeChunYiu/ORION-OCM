// Lean compiler output
// Module: OCMEnvironment.Dependencies
// Imports: public import Init public meta import Init public import OCMEnvironment.Types
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_registerTraceClass_spec__0___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedExpr;
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_pop(lean_object*);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_CollectLevelParams_visitExpr_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_CollectLevelParams_visitExpr_spec__1___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_NameHashSet_insert(lean_object*, lean_object*);
lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint8_t l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t l_Lean_ConstantInfo_isUnsafe(lean_object*);
uint8_t l_Lean_ConstantInfo_isPartial(lean_object*);
lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collect_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
lean_object* l_Lean_ConstantInfo_value_x3f(lean_object*, uint8_t);
lean_object* l_List_toString___at___00Lean_Parser_FirstTokens_toStr_spec__0(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Nat"};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__0_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__1_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "String"};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__2_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__2_value),LEAN_SCALAR_PTR_LITERAL(6, 130, 56, 8, 41, 104, 134, 43)}};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Char"};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__4_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ofNat"};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__5 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__5_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__6_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__4_value),LEAN_SCALAR_PTR_LITERAL(18, 67, 155, 167, 151, 71, 146, 196)}};
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__6_value_aux_0),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__5_value),LEAN_SCALAR_PTR_LITERAL(27, 51, 10, 169, 25, 67, 44, 251)}};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__6 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__6_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "ofList"};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__7 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__7_value;
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__8_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__2_value),LEAN_SCALAR_PTR_LITERAL(6, 130, 56, 8, 41, 104, 134, 43)}};
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__8_value_aux_0),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__7_value),LEAN_SCALAR_PTR_LITERAL(118, 246, 177, 142, 179, 9, 199, 233)}};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__8 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__8_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg(lean_object*);
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__0;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__1;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__2;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00OCMEnvironment_constantDependencies_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2___boxed(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "Eq"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__0_value),LEAN_SCALAR_PTR_LITERAL(143, 37, 101, 248, 9, 246, 191, 223)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Quot"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "mk"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__5_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__5_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__4_value),LEAN_SCALAR_PTR_LITERAL(255, 113, 137, 82, 82, 132, 58, 248)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__7_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__7_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__6_value),LEAN_SCALAR_PTR_LITERAL(91, 125, 38, 34, 222, 200, 201, 80)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__9_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__2_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__9_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__8_value),LEAN_SCALAR_PTR_LITERAL(150, 213, 121, 152, 109, 27, 137, 60)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__9_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__9_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__7_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__10_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__11_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__5_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__11_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__3_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__12_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__13_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__13_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__14_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies(lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__5(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__4(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_dependencyClosure_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_dependencyClosure_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = "UNSAFE_OR_PARTIAL "};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__1_value;
static const lean_array_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 20, .m_capacity = 20, .m_length = 19, .m_data = "MISSING_DEPENDENCY "};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__3 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__3_value;
static const lean_string_object lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 21, .m_capacity = 21, .m_length = 20, .m_data = "EXCLUDED_DEPENDENCY "};
static const lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__4 = (const lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__4_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_dependencyClosure_spec__2(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_dependencyClosure_spec__2___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__0;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2_value),((lean_object*)&lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__2_value;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__3;
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__4;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0(lean_object* v___x_1_, lean_object* v___x_2_, lean_object* v_snd_3_, lean_object* v_binderName_4_, lean_object* v_t_5_, lean_object* v_b_6_, uint8_t v_binderInfo_7_){
_start:
{
lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_12_; 
v___x_8_ = lean_array_push(v___x_1_, v_t_5_);
v___x_9_ = lean_array_push(v___x_8_, v_b_6_);
v___x_10_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_10_, 0, v___x_2_);
lean_ctor_set(v___x_10_, 1, v_snd_3_);
v___x_11_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_11_, 0, v___x_9_);
lean_ctor_set(v___x_11_, 1, v___x_10_);
v___x_12_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_12_, 0, v___x_11_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0___boxed(lean_object* v___x_13_, lean_object* v___x_14_, lean_object* v_snd_15_, lean_object* v_binderName_16_, lean_object* v_t_17_, lean_object* v_b_18_, lean_object* v_binderInfo_19_){
_start:
{
uint8_t v_binderInfo_2361__boxed_20_; lean_object* v_res_21_; 
v_binderInfo_2361__boxed_20_ = lean_unbox(v_binderInfo_19_);
v_res_21_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0(v___x_13_, v___x_14_, v_snd_15_, v_binderName_16_, v_t_17_, v_b_18_, v_binderInfo_2361__boxed_20_);
lean_dec(v_binderName_16_);
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg(lean_object* v_a_37_){
_start:
{
lean_object* v___y_39_; lean_object* v_snd_43_; lean_object* v_fst_44_; lean_object* v___x_46_; uint8_t v_isShared_47_; uint8_t v_isSharedCheck_171_; 
v_snd_43_ = lean_ctor_get(v_a_37_, 1);
v_fst_44_ = lean_ctor_get(v_a_37_, 0);
v_isSharedCheck_171_ = !lean_is_exclusive(v_a_37_);
if (v_isSharedCheck_171_ == 0)
{
v___x_46_ = v_a_37_;
v_isShared_47_ = v_isSharedCheck_171_;
goto v_resetjp_45_;
}
else
{
lean_inc(v_snd_43_);
lean_inc(v_fst_44_);
lean_dec(v_a_37_);
v___x_46_ = lean_box(0);
v_isShared_47_ = v_isSharedCheck_171_;
goto v_resetjp_45_;
}
v___jp_38_:
{
if (lean_obj_tag(v___y_39_) == 0)
{
lean_object* v_a_40_; 
v_a_40_ = lean_ctor_get(v___y_39_, 0);
lean_inc(v_a_40_);
lean_dec_ref_known(v___y_39_, 1);
return v_a_40_;
}
else
{
lean_object* v_a_41_; 
v_a_41_ = lean_ctor_get(v___y_39_, 0);
lean_inc(v_a_41_);
lean_dec_ref_known(v___y_39_, 1);
v_a_37_ = v_a_41_;
goto _start;
}
}
v_resetjp_45_:
{
lean_object* v_fst_48_; lean_object* v_snd_49_; lean_object* v___x_51_; uint8_t v_isShared_52_; uint8_t v_isSharedCheck_170_; 
v_fst_48_ = lean_ctor_get(v_snd_43_, 0);
v_snd_49_ = lean_ctor_get(v_snd_43_, 1);
v_isSharedCheck_170_ = !lean_is_exclusive(v_snd_43_);
if (v_isSharedCheck_170_ == 0)
{
v___x_51_ = v_snd_43_;
v_isShared_52_ = v_isSharedCheck_170_;
goto v_resetjp_50_;
}
else
{
lean_inc(v_snd_49_);
lean_inc(v_fst_48_);
lean_dec(v_snd_43_);
v___x_51_ = lean_box(0);
v_isShared_52_ = v_isSharedCheck_170_;
goto v_resetjp_50_;
}
v_resetjp_50_:
{
lean_object* v___x_53_; lean_object* v___x_54_; uint8_t v___x_55_; 
v___x_53_ = lean_array_get_size(v_fst_44_);
v___x_54_ = lean_unsigned_to_nat(0u);
v___x_55_ = lean_nat_dec_eq(v___x_53_, v___x_54_);
if (v___x_55_ == 0)
{
lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v___x_60_; uint8_t v___x_61_; 
v___x_56_ = l_Lean_instInhabitedExpr;
v___x_57_ = lean_unsigned_to_nat(1u);
v___x_58_ = lean_nat_sub(v___x_53_, v___x_57_);
v___x_59_ = lean_array_get(v___x_56_, v_fst_44_, v___x_58_);
lean_dec(v___x_58_);
v___x_60_ = lean_array_pop(v_fst_44_);
v___x_61_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_CollectLevelParams_visitExpr_spec__0___redArg(v_fst_48_, v___x_59_);
if (v___x_61_ == 0)
{
lean_object* v___x_62_; lean_object* v___x_63_; 
v___x_62_ = lean_box(0);
lean_inc(v___x_59_);
v___x_63_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_CollectLevelParams_visitExpr_spec__1___redArg(v_fst_48_, v___x_59_, v___x_62_);
switch(lean_obj_tag(v___x_59_))
{
case 4:
{
lean_object* v_declName_64_; lean_object* v___x_65_; lean_object* v___x_67_; 
v_declName_64_ = lean_ctor_get(v___x_59_, 0);
lean_inc(v_declName_64_);
lean_dec_ref_known(v___x_59_, 2);
v___x_65_ = l_Lean_NameHashSet_insert(v_snd_49_, v_declName_64_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 1, v___x_65_);
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_67_ = v___x_51_;
goto v_reusejp_66_;
}
else
{
lean_object* v_reuseFailAlloc_72_; 
v_reuseFailAlloc_72_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_72_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_72_, 1, v___x_65_);
v___x_67_ = v_reuseFailAlloc_72_;
goto v_reusejp_66_;
}
v_reusejp_66_:
{
lean_object* v___x_69_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_67_);
lean_ctor_set(v___x_46_, 0, v___x_60_);
v___x_69_ = v___x_46_;
goto v_reusejp_68_;
}
else
{
lean_object* v_reuseFailAlloc_71_; 
v_reuseFailAlloc_71_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_71_, 0, v___x_60_);
lean_ctor_set(v_reuseFailAlloc_71_, 1, v___x_67_);
v___x_69_ = v_reuseFailAlloc_71_;
goto v_reusejp_68_;
}
v_reusejp_68_:
{
v_a_37_ = v___x_69_;
goto _start;
}
}
}
case 5:
{
lean_object* v_fn_73_; lean_object* v_arg_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_78_; 
v_fn_73_ = lean_ctor_get(v___x_59_, 0);
lean_inc_ref(v_fn_73_);
v_arg_74_ = lean_ctor_get(v___x_59_, 1);
lean_inc_ref(v_arg_74_);
lean_dec_ref_known(v___x_59_, 2);
v___x_75_ = lean_array_push(v___x_60_, v_fn_73_);
v___x_76_ = lean_array_push(v___x_75_, v_arg_74_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_78_ = v___x_51_;
goto v_reusejp_77_;
}
else
{
lean_object* v_reuseFailAlloc_83_; 
v_reuseFailAlloc_83_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_83_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_83_, 1, v_snd_49_);
v___x_78_ = v_reuseFailAlloc_83_;
goto v_reusejp_77_;
}
v_reusejp_77_:
{
lean_object* v___x_80_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_78_);
lean_ctor_set(v___x_46_, 0, v___x_76_);
v___x_80_ = v___x_46_;
goto v_reusejp_79_;
}
else
{
lean_object* v_reuseFailAlloc_82_; 
v_reuseFailAlloc_82_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_82_, 0, v___x_76_);
lean_ctor_set(v_reuseFailAlloc_82_, 1, v___x_78_);
v___x_80_ = v_reuseFailAlloc_82_;
goto v_reusejp_79_;
}
v_reusejp_79_:
{
v_a_37_ = v___x_80_;
goto _start;
}
}
}
case 6:
{
lean_object* v_binderName_84_; lean_object* v_binderType_85_; lean_object* v_body_86_; uint8_t v_binderInfo_87_; lean_object* v___x_88_; 
lean_del_object(v___x_51_);
lean_del_object(v___x_46_);
v_binderName_84_ = lean_ctor_get(v___x_59_, 0);
lean_inc(v_binderName_84_);
v_binderType_85_ = lean_ctor_get(v___x_59_, 1);
lean_inc_ref(v_binderType_85_);
v_body_86_ = lean_ctor_get(v___x_59_, 2);
lean_inc_ref(v_body_86_);
v_binderInfo_87_ = lean_ctor_get_uint8(v___x_59_, sizeof(void*)*3 + 8);
lean_dec_ref_known(v___x_59_, 3);
v___x_88_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0(v___x_60_, v___x_63_, v_snd_49_, v_binderName_84_, v_binderType_85_, v_body_86_, v_binderInfo_87_);
lean_dec(v_binderName_84_);
v___y_39_ = v___x_88_;
goto v___jp_38_;
}
case 7:
{
lean_object* v_binderName_89_; lean_object* v_binderType_90_; lean_object* v_body_91_; uint8_t v_binderInfo_92_; lean_object* v___x_93_; 
lean_del_object(v___x_51_);
lean_del_object(v___x_46_);
v_binderName_89_ = lean_ctor_get(v___x_59_, 0);
lean_inc(v_binderName_89_);
v_binderType_90_ = lean_ctor_get(v___x_59_, 1);
lean_inc_ref(v_binderType_90_);
v_body_91_ = lean_ctor_get(v___x_59_, 2);
lean_inc_ref(v_body_91_);
v_binderInfo_92_ = lean_ctor_get_uint8(v___x_59_, sizeof(void*)*3 + 8);
lean_dec_ref_known(v___x_59_, 3);
v___x_93_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___lam__0(v___x_60_, v___x_63_, v_snd_49_, v_binderName_89_, v_binderType_90_, v_body_91_, v_binderInfo_92_);
lean_dec(v_binderName_89_);
v___y_39_ = v___x_93_;
goto v___jp_38_;
}
case 8:
{
lean_object* v_type_94_; lean_object* v_value_95_; lean_object* v_body_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_101_; 
v_type_94_ = lean_ctor_get(v___x_59_, 1);
lean_inc_ref(v_type_94_);
v_value_95_ = lean_ctor_get(v___x_59_, 2);
lean_inc_ref(v_value_95_);
v_body_96_ = lean_ctor_get(v___x_59_, 3);
lean_inc_ref(v_body_96_);
lean_dec_ref_known(v___x_59_, 4);
v___x_97_ = lean_array_push(v___x_60_, v_type_94_);
v___x_98_ = lean_array_push(v___x_97_, v_value_95_);
v___x_99_ = lean_array_push(v___x_98_, v_body_96_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_101_ = v___x_51_;
goto v_reusejp_100_;
}
else
{
lean_object* v_reuseFailAlloc_106_; 
v_reuseFailAlloc_106_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_106_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_106_, 1, v_snd_49_);
v___x_101_ = v_reuseFailAlloc_106_;
goto v_reusejp_100_;
}
v_reusejp_100_:
{
lean_object* v___x_103_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_101_);
lean_ctor_set(v___x_46_, 0, v___x_99_);
v___x_103_ = v___x_46_;
goto v_reusejp_102_;
}
else
{
lean_object* v_reuseFailAlloc_105_; 
v_reuseFailAlloc_105_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_105_, 0, v___x_99_);
lean_ctor_set(v_reuseFailAlloc_105_, 1, v___x_101_);
v___x_103_ = v_reuseFailAlloc_105_;
goto v_reusejp_102_;
}
v_reusejp_102_:
{
v_a_37_ = v___x_103_;
goto _start;
}
}
}
case 10:
{
lean_object* v_expr_107_; lean_object* v___x_108_; lean_object* v___x_110_; 
v_expr_107_ = lean_ctor_get(v___x_59_, 1);
lean_inc_ref(v_expr_107_);
lean_dec_ref_known(v___x_59_, 2);
v___x_108_ = lean_array_push(v___x_60_, v_expr_107_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_110_ = v___x_51_;
goto v_reusejp_109_;
}
else
{
lean_object* v_reuseFailAlloc_115_; 
v_reuseFailAlloc_115_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_115_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_115_, 1, v_snd_49_);
v___x_110_ = v_reuseFailAlloc_115_;
goto v_reusejp_109_;
}
v_reusejp_109_:
{
lean_object* v___x_112_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_110_);
lean_ctor_set(v___x_46_, 0, v___x_108_);
v___x_112_ = v___x_46_;
goto v_reusejp_111_;
}
else
{
lean_object* v_reuseFailAlloc_114_; 
v_reuseFailAlloc_114_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_114_, 0, v___x_108_);
lean_ctor_set(v_reuseFailAlloc_114_, 1, v___x_110_);
v___x_112_ = v_reuseFailAlloc_114_;
goto v_reusejp_111_;
}
v_reusejp_111_:
{
v_a_37_ = v___x_112_;
goto _start;
}
}
}
case 11:
{
lean_object* v_typeName_116_; lean_object* v_struct_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_121_; 
v_typeName_116_ = lean_ctor_get(v___x_59_, 0);
lean_inc(v_typeName_116_);
v_struct_117_ = lean_ctor_get(v___x_59_, 2);
lean_inc_ref(v_struct_117_);
lean_dec_ref_known(v___x_59_, 3);
v___x_118_ = l_Lean_NameHashSet_insert(v_snd_49_, v_typeName_116_);
v___x_119_ = lean_array_push(v___x_60_, v_struct_117_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 1, v___x_118_);
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_121_ = v___x_51_;
goto v_reusejp_120_;
}
else
{
lean_object* v_reuseFailAlloc_126_; 
v_reuseFailAlloc_126_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_126_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_126_, 1, v___x_118_);
v___x_121_ = v_reuseFailAlloc_126_;
goto v_reusejp_120_;
}
v_reusejp_120_:
{
lean_object* v___x_123_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_121_);
lean_ctor_set(v___x_46_, 0, v___x_119_);
v___x_123_ = v___x_46_;
goto v_reusejp_122_;
}
else
{
lean_object* v_reuseFailAlloc_125_; 
v_reuseFailAlloc_125_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_125_, 0, v___x_119_);
lean_ctor_set(v_reuseFailAlloc_125_, 1, v___x_121_);
v___x_123_ = v_reuseFailAlloc_125_;
goto v_reusejp_122_;
}
v_reusejp_122_:
{
v_a_37_ = v___x_123_;
goto _start;
}
}
}
case 9:
{
lean_object* v_a_127_; 
v_a_127_ = lean_ctor_get(v___x_59_, 0);
lean_inc_ref(v_a_127_);
lean_dec_ref_known(v___x_59_, 1);
if (lean_obj_tag(v_a_127_) == 0)
{
lean_object* v___x_128_; lean_object* v___x_129_; lean_object* v___x_131_; 
lean_dec_ref_known(v_a_127_, 1);
v___x_128_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__1));
v___x_129_ = l_Lean_NameHashSet_insert(v_snd_49_, v___x_128_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 1, v___x_129_);
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_131_ = v___x_51_;
goto v_reusejp_130_;
}
else
{
lean_object* v_reuseFailAlloc_136_; 
v_reuseFailAlloc_136_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_136_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_136_, 1, v___x_129_);
v___x_131_ = v_reuseFailAlloc_136_;
goto v_reusejp_130_;
}
v_reusejp_130_:
{
lean_object* v___x_133_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_131_);
lean_ctor_set(v___x_46_, 0, v___x_60_);
v___x_133_ = v___x_46_;
goto v_reusejp_132_;
}
else
{
lean_object* v_reuseFailAlloc_135_; 
v_reuseFailAlloc_135_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_135_, 0, v___x_60_);
lean_ctor_set(v_reuseFailAlloc_135_, 1, v___x_131_);
v___x_133_ = v_reuseFailAlloc_135_;
goto v_reusejp_132_;
}
v_reusejp_132_:
{
v_a_37_ = v___x_133_;
goto _start;
}
}
}
else
{
lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_144_; 
lean_dec_ref_known(v_a_127_, 1);
v___x_137_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__3));
v___x_138_ = l_Lean_NameHashSet_insert(v_snd_49_, v___x_137_);
v___x_139_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__6));
v___x_140_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_registerTraceClass_spec__0___redArg(v___x_138_, v___x_139_, v___x_62_);
v___x_141_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg___closed__8));
v___x_142_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_registerTraceClass_spec__0___redArg(v___x_140_, v___x_141_, v___x_62_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 1, v___x_142_);
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_144_ = v___x_51_;
goto v_reusejp_143_;
}
else
{
lean_object* v_reuseFailAlloc_149_; 
v_reuseFailAlloc_149_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_149_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_149_, 1, v___x_142_);
v___x_144_ = v_reuseFailAlloc_149_;
goto v_reusejp_143_;
}
v_reusejp_143_:
{
lean_object* v___x_146_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_144_);
lean_ctor_set(v___x_46_, 0, v___x_60_);
v___x_146_ = v___x_46_;
goto v_reusejp_145_;
}
else
{
lean_object* v_reuseFailAlloc_148_; 
v_reuseFailAlloc_148_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_148_, 0, v___x_60_);
lean_ctor_set(v_reuseFailAlloc_148_, 1, v___x_144_);
v___x_146_ = v_reuseFailAlloc_148_;
goto v_reusejp_145_;
}
v_reusejp_145_:
{
v_a_37_ = v___x_146_;
goto _start;
}
}
}
}
default: 
{
lean_object* v___x_151_; 
lean_dec(v___x_59_);
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 0, v___x_63_);
v___x_151_ = v___x_51_;
goto v_reusejp_150_;
}
else
{
lean_object* v_reuseFailAlloc_156_; 
v_reuseFailAlloc_156_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_156_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_156_, 1, v_snd_49_);
v___x_151_ = v_reuseFailAlloc_156_;
goto v_reusejp_150_;
}
v_reusejp_150_:
{
lean_object* v___x_153_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_151_);
lean_ctor_set(v___x_46_, 0, v___x_60_);
v___x_153_ = v___x_46_;
goto v_reusejp_152_;
}
else
{
lean_object* v_reuseFailAlloc_155_; 
v_reuseFailAlloc_155_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_155_, 0, v___x_60_);
lean_ctor_set(v_reuseFailAlloc_155_, 1, v___x_151_);
v___x_153_ = v_reuseFailAlloc_155_;
goto v_reusejp_152_;
}
v_reusejp_152_:
{
v_a_37_ = v___x_153_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_158_; 
lean_dec(v___x_59_);
if (v_isShared_52_ == 0)
{
v___x_158_ = v___x_51_;
goto v_reusejp_157_;
}
else
{
lean_object* v_reuseFailAlloc_163_; 
v_reuseFailAlloc_163_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_163_, 0, v_fst_48_);
lean_ctor_set(v_reuseFailAlloc_163_, 1, v_snd_49_);
v___x_158_ = v_reuseFailAlloc_163_;
goto v_reusejp_157_;
}
v_reusejp_157_:
{
lean_object* v___x_160_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_158_);
lean_ctor_set(v___x_46_, 0, v___x_60_);
v___x_160_ = v___x_46_;
goto v_reusejp_159_;
}
else
{
lean_object* v_reuseFailAlloc_162_; 
v_reuseFailAlloc_162_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_162_, 0, v___x_60_);
lean_ctor_set(v_reuseFailAlloc_162_, 1, v___x_158_);
v___x_160_ = v_reuseFailAlloc_162_;
goto v_reusejp_159_;
}
v_reusejp_159_:
{
v_a_37_ = v___x_160_;
goto _start;
}
}
}
}
else
{
lean_object* v___x_165_; 
if (v_isShared_52_ == 0)
{
v___x_165_ = v___x_51_;
goto v_reusejp_164_;
}
else
{
lean_object* v_reuseFailAlloc_169_; 
v_reuseFailAlloc_169_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_169_, 0, v_fst_48_);
lean_ctor_set(v_reuseFailAlloc_169_, 1, v_snd_49_);
v___x_165_ = v_reuseFailAlloc_169_;
goto v_reusejp_164_;
}
v_reusejp_164_:
{
lean_object* v___x_167_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set(v___x_46_, 1, v___x_165_);
v___x_167_ = v___x_46_;
goto v_reusejp_166_;
}
else
{
lean_object* v_reuseFailAlloc_168_; 
v_reuseFailAlloc_168_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_168_, 0, v_fst_44_);
lean_ctor_set(v_reuseFailAlloc_168_, 1, v___x_165_);
v___x_167_ = v_reuseFailAlloc_168_;
goto v_reusejp_166_;
}
v_reusejp_166_:
{
return v___x_167_;
}
}
}
}
}
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__0(void){
_start:
{
lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_174_; 
v___x_172_ = lean_box(0);
v___x_173_ = lean_unsigned_to_nat(16u);
v___x_174_ = lean_mk_array(v___x_173_, v___x_172_);
return v___x_174_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__1(void){
_start:
{
lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v_seen_177_; 
v___x_175_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__0, &lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__0_once, _init_lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__0);
v___x_176_ = lean_unsigned_to_nat(0u);
v_seen_177_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_seen_177_, 0, v___x_176_);
lean_ctor_set(v_seen_177_, 1, v___x_175_);
return v_seen_177_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__2(void){
_start:
{
lean_object* v_seen_178_; lean_object* v___x_179_; 
v_seen_178_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__1, &lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__1_once, _init_lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__1);
v___x_179_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_179_, 0, v_seen_178_);
lean_ctor_set(v___x_179_, 1, v_seen_178_);
return v___x_179_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_exprDependencies(lean_object* v_expr_180_){
_start:
{
lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v_todo_183_; lean_object* v___x_184_; lean_object* v___x_185_; lean_object* v___x_186_; lean_object* v_snd_187_; lean_object* v_snd_188_; 
v___x_181_ = lean_unsigned_to_nat(1u);
v___x_182_ = lean_mk_empty_array_with_capacity(v___x_181_);
v_todo_183_ = lean_array_push(v___x_182_, v_expr_180_);
v___x_184_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__2, &lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__2_once, _init_lp_proofEnvironment_OCMEnvironment_exprDependencies___closed__2);
v___x_185_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_185_, 0, v_todo_183_);
lean_ctor_set(v___x_185_, 1, v___x_184_);
v___x_186_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg(v___x_185_);
v_snd_187_ = lean_ctor_get(v___x_186_, 1);
lean_inc(v_snd_187_);
lean_dec_ref(v___x_186_);
v_snd_188_ = lean_ctor_get(v_snd_187_, 1);
lean_inc(v_snd_188_);
lean_dec(v_snd_187_);
return v_snd_188_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0(lean_object* v_inst_189_, lean_object* v_a_190_){
_start:
{
lean_object* v___x_191_; 
v___x_191_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_exprDependencies_spec__0___redArg(v_a_190_);
return v___x_191_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00OCMEnvironment_constantDependencies_spec__0(lean_object* v_x_192_, lean_object* v_x_193_){
_start:
{
if (lean_obj_tag(v_x_193_) == 0)
{
return v_x_192_;
}
else
{
lean_object* v_key_194_; lean_object* v_tail_195_; lean_object* v___x_196_; 
v_key_194_ = lean_ctor_get(v_x_193_, 0);
lean_inc(v_key_194_);
v_tail_195_ = lean_ctor_get(v_x_193_, 2);
lean_inc(v_tail_195_);
lean_dec_ref_known(v_x_193_, 3);
v___x_196_ = lean_array_push(v_x_192_, v_key_194_);
v_x_192_ = v___x_196_;
v_x_193_ = v_tail_195_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(lean_object* v_as_198_, size_t v_i_199_, size_t v_stop_200_, lean_object* v_b_201_){
_start:
{
uint8_t v___x_202_; 
v___x_202_ = lean_usize_dec_eq(v_i_199_, v_stop_200_);
if (v___x_202_ == 0)
{
lean_object* v___x_203_; lean_object* v___x_204_; size_t v___x_205_; size_t v___x_206_; 
v___x_203_ = lean_array_uget_borrowed(v_as_198_, v_i_199_);
lean_inc(v___x_203_);
v___x_204_ = lp_proofEnvironment_Std_DHashMap_Internal_AssocList_foldlM___at___00OCMEnvironment_constantDependencies_spec__0(v_b_201_, v___x_203_);
v___x_205_ = ((size_t)1ULL);
v___x_206_ = lean_usize_add(v_i_199_, v___x_205_);
v_i_199_ = v___x_206_;
v_b_201_ = v___x_204_;
goto _start;
}
else
{
return v_b_201_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1___boxed(lean_object* v_as_208_, lean_object* v_i_209_, lean_object* v_stop_210_, lean_object* v_b_211_){
_start:
{
size_t v_i_boxed_212_; size_t v_stop_boxed_213_; lean_object* v_res_214_; 
v_i_boxed_212_ = lean_unbox_usize(v_i_209_);
lean_dec(v_i_209_);
v_stop_boxed_213_ = lean_unbox_usize(v_stop_210_);
lean_dec(v_stop_210_);
v_res_214_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_as_208_, v_i_boxed_212_, v_stop_boxed_213_, v_b_211_);
lean_dec_ref(v_as_208_);
return v_res_214_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg(lean_object* v_as_x27_215_, lean_object* v_b_216_){
_start:
{
if (lean_obj_tag(v_as_x27_215_) == 0)
{
return v_b_216_;
}
else
{
lean_object* v_head_217_; lean_object* v_tail_218_; lean_object* v_ctor_219_; lean_object* v_rhs_220_; lean_object* v___x_221_; lean_object* v_size_222_; lean_object* v_buckets_223_; lean_object* v___x_224_; lean_object* v___y_226_; lean_object* v___x_229_; lean_object* v___x_230_; lean_object* v___x_231_; uint8_t v___x_232_; 
v_head_217_ = lean_ctor_get(v_as_x27_215_, 0);
v_tail_218_ = lean_ctor_get(v_as_x27_215_, 1);
v_ctor_219_ = lean_ctor_get(v_head_217_, 0);
v_rhs_220_ = lean_ctor_get(v_head_217_, 2);
lean_inc_ref(v_rhs_220_);
v___x_221_ = lp_proofEnvironment_OCMEnvironment_exprDependencies(v_rhs_220_);
v_size_222_ = lean_ctor_get(v___x_221_, 0);
lean_inc(v_size_222_);
v_buckets_223_ = lean_ctor_get(v___x_221_, 1);
lean_inc_ref(v_buckets_223_);
lean_dec_ref(v___x_221_);
lean_inc(v_ctor_219_);
v___x_224_ = l_Lean_NameHashSet_insert(v_b_216_, v_ctor_219_);
v___x_229_ = lean_mk_empty_array_with_capacity(v_size_222_);
lean_dec(v_size_222_);
v___x_230_ = lean_unsigned_to_nat(0u);
v___x_231_ = lean_array_get_size(v_buckets_223_);
v___x_232_ = lean_nat_dec_lt(v___x_230_, v___x_231_);
if (v___x_232_ == 0)
{
lean_dec_ref(v_buckets_223_);
v___y_226_ = v___x_229_;
goto v___jp_225_;
}
else
{
uint8_t v___x_233_; 
v___x_233_ = lean_nat_dec_le(v___x_231_, v___x_231_);
if (v___x_233_ == 0)
{
if (v___x_232_ == 0)
{
lean_dec_ref(v_buckets_223_);
v___y_226_ = v___x_229_;
goto v___jp_225_;
}
else
{
size_t v___x_234_; size_t v___x_235_; lean_object* v___x_236_; 
v___x_234_ = ((size_t)0ULL);
v___x_235_ = lean_usize_of_nat(v___x_231_);
v___x_236_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_223_, v___x_234_, v___x_235_, v___x_229_);
lean_dec_ref(v_buckets_223_);
v___y_226_ = v___x_236_;
goto v___jp_225_;
}
}
else
{
size_t v___x_237_; size_t v___x_238_; lean_object* v___x_239_; 
v___x_237_ = ((size_t)0ULL);
v___x_238_ = lean_usize_of_nat(v___x_231_);
v___x_239_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_223_, v___x_237_, v___x_238_, v___x_229_);
lean_dec_ref(v_buckets_223_);
v___y_226_ = v___x_239_;
goto v___jp_225_;
}
}
v___jp_225_:
{
lean_object* v___x_227_; 
v___x_227_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_224_, v___y_226_);
lean_dec_ref(v___y_226_);
v_as_x27_215_ = v_tail_218_;
v_b_216_ = v___x_227_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg___boxed(lean_object* v_as_x27_240_, lean_object* v_b_241_){
_start:
{
lean_object* v_res_242_; 
v_res_242_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg(v_as_x27_240_, v_b_241_);
lean_dec(v_as_x27_240_);
return v_res_242_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(lean_object* v_as_x27_243_, lean_object* v_b_244_){
_start:
{
if (lean_obj_tag(v_as_x27_243_) == 0)
{
return v_b_244_;
}
else
{
lean_object* v_head_245_; lean_object* v_tail_246_; lean_object* v___x_247_; lean_object* v_r_248_; 
v_head_245_ = lean_ctor_get(v_as_x27_243_, 0);
v_tail_246_ = lean_ctor_get(v_as_x27_243_, 1);
v___x_247_ = lean_box(0);
lean_inc(v_head_245_);
v_r_248_ = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___00Lean_registerTraceClass_spec__0___redArg(v_b_244_, v_head_245_, v___x_247_);
v_as_x27_243_ = v_tail_246_;
v_b_244_ = v_r_248_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg___boxed(lean_object* v_as_x27_250_, lean_object* v_b_251_){
_start:
{
lean_object* v_res_252_; 
v_res_252_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_as_x27_250_, v_b_251_);
lean_dec(v_as_x27_250_);
return v_res_252_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2(lean_object* v_m_253_, lean_object* v_l_254_){
_start:
{
lean_object* v___x_255_; 
v___x_255_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_l_254_, v_m_253_);
return v___x_255_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2___boxed(lean_object* v_m_256_, lean_object* v_l_257_){
_start:
{
lean_object* v_res_258_; 
v_res_258_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2(v_m_256_, v_l_257_);
lean_dec(v_l_257_);
return v_res_258_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_constantDependencies(lean_object* v_ci_292_){
_start:
{
lean_object* v_names_294_; lean_object* v___x_319_; lean_object* v_names_320_; lean_object* v___y_322_; uint8_t v___x_324_; lean_object* v___x_325_; 
v___x_319_ = l_Lean_ConstantInfo_type(v_ci_292_);
v_names_320_ = lp_proofEnvironment_OCMEnvironment_exprDependencies(v___x_319_);
v___x_324_ = 1;
lean_inc_ref(v_ci_292_);
v___x_325_ = l_Lean_ConstantInfo_value_x3f(v_ci_292_, v___x_324_);
if (lean_obj_tag(v___x_325_) == 1)
{
lean_object* v_val_326_; lean_object* v___x_327_; lean_object* v_size_328_; lean_object* v_buckets_329_; lean_object* v___x_330_; lean_object* v___x_331_; lean_object* v___x_332_; uint8_t v___x_333_; 
v_val_326_ = lean_ctor_get(v___x_325_, 0);
lean_inc(v_val_326_);
lean_dec_ref_known(v___x_325_, 1);
v___x_327_ = lp_proofEnvironment_OCMEnvironment_exprDependencies(v_val_326_);
v_size_328_ = lean_ctor_get(v___x_327_, 0);
lean_inc(v_size_328_);
v_buckets_329_ = lean_ctor_get(v___x_327_, 1);
lean_inc_ref(v_buckets_329_);
lean_dec_ref(v___x_327_);
v___x_330_ = lean_mk_empty_array_with_capacity(v_size_328_);
lean_dec(v_size_328_);
v___x_331_ = lean_unsigned_to_nat(0u);
v___x_332_ = lean_array_get_size(v_buckets_329_);
v___x_333_ = lean_nat_dec_lt(v___x_331_, v___x_332_);
if (v___x_333_ == 0)
{
lean_dec_ref(v_buckets_329_);
v___y_322_ = v___x_330_;
goto v___jp_321_;
}
else
{
uint8_t v___x_334_; 
v___x_334_ = lean_nat_dec_le(v___x_332_, v___x_332_);
if (v___x_334_ == 0)
{
if (v___x_333_ == 0)
{
lean_dec_ref(v_buckets_329_);
v___y_322_ = v___x_330_;
goto v___jp_321_;
}
else
{
size_t v___x_335_; size_t v___x_336_; lean_object* v___x_337_; 
v___x_335_ = ((size_t)0ULL);
v___x_336_ = lean_usize_of_nat(v___x_332_);
v___x_337_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_329_, v___x_335_, v___x_336_, v___x_330_);
lean_dec_ref(v_buckets_329_);
v___y_322_ = v___x_337_;
goto v___jp_321_;
}
}
else
{
size_t v___x_338_; size_t v___x_339_; lean_object* v___x_340_; 
v___x_338_ = ((size_t)0ULL);
v___x_339_ = lean_usize_of_nat(v___x_332_);
v___x_340_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_329_, v___x_338_, v___x_339_, v___x_330_);
lean_dec_ref(v_buckets_329_);
v___y_322_ = v___x_340_;
goto v___jp_321_;
}
}
}
else
{
lean_dec(v___x_325_);
v_names_294_ = v_names_320_;
goto v___jp_293_;
}
v___jp_293_:
{
switch(lean_obj_tag(v_ci_292_))
{
case 1:
{
lean_object* v_val_295_; lean_object* v_all_296_; lean_object* v___x_297_; 
v_val_295_ = lean_ctor_get(v_ci_292_, 0);
lean_inc_ref(v_val_295_);
lean_dec_ref_known(v_ci_292_, 1);
v_all_296_ = lean_ctor_get(v_val_295_, 3);
lean_inc(v_all_296_);
lean_dec_ref(v_val_295_);
v___x_297_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_all_296_, v_names_294_);
lean_dec(v_all_296_);
return v___x_297_;
}
case 2:
{
lean_object* v_val_298_; lean_object* v_all_299_; lean_object* v___x_300_; 
v_val_298_ = lean_ctor_get(v_ci_292_, 0);
lean_inc_ref(v_val_298_);
lean_dec_ref_known(v_ci_292_, 1);
v_all_299_ = lean_ctor_get(v_val_298_, 2);
lean_inc(v_all_299_);
lean_dec_ref(v_val_298_);
v___x_300_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_all_299_, v_names_294_);
lean_dec(v_all_299_);
return v___x_300_;
}
case 3:
{
lean_object* v_val_301_; lean_object* v_all_302_; lean_object* v___x_303_; 
v_val_301_ = lean_ctor_get(v_ci_292_, 0);
lean_inc_ref(v_val_301_);
lean_dec_ref_known(v_ci_292_, 1);
v_all_302_ = lean_ctor_get(v_val_301_, 2);
lean_inc(v_all_302_);
lean_dec_ref(v_val_301_);
v___x_303_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_all_302_, v_names_294_);
lean_dec(v_all_302_);
return v___x_303_;
}
case 5:
{
lean_object* v_val_304_; lean_object* v_all_305_; lean_object* v_ctors_306_; lean_object* v___x_307_; lean_object* v___x_308_; 
v_val_304_ = lean_ctor_get(v_ci_292_, 0);
lean_inc_ref(v_val_304_);
lean_dec_ref_known(v_ci_292_, 1);
v_all_305_ = lean_ctor_get(v_val_304_, 3);
lean_inc(v_all_305_);
v_ctors_306_ = lean_ctor_get(v_val_304_, 4);
lean_inc(v_ctors_306_);
lean_dec_ref(v_val_304_);
v___x_307_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_all_305_, v_names_294_);
lean_dec(v_all_305_);
v___x_308_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_ctors_306_, v___x_307_);
lean_dec(v_ctors_306_);
return v___x_308_;
}
case 6:
{
lean_object* v_val_309_; lean_object* v_induct_310_; lean_object* v_names_311_; 
v_val_309_ = lean_ctor_get(v_ci_292_, 0);
lean_inc_ref(v_val_309_);
lean_dec_ref_known(v_ci_292_, 1);
v_induct_310_ = lean_ctor_get(v_val_309_, 1);
lean_inc(v_induct_310_);
lean_dec_ref(v_val_309_);
v_names_311_ = l_Lean_NameHashSet_insert(v_names_294_, v_induct_310_);
return v_names_311_;
}
case 7:
{
lean_object* v_val_312_; lean_object* v_all_313_; lean_object* v_rules_314_; lean_object* v_names_315_; lean_object* v___x_316_; 
v_val_312_ = lean_ctor_get(v_ci_292_, 0);
lean_inc_ref(v_val_312_);
lean_dec_ref_known(v_ci_292_, 1);
v_all_313_ = lean_ctor_get(v_val_312_, 1);
lean_inc(v_all_313_);
v_rules_314_ = lean_ctor_get(v_val_312_, 6);
lean_inc(v_rules_314_);
lean_dec_ref(v_val_312_);
v_names_315_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_all_313_, v_names_294_);
lean_dec(v_all_313_);
v___x_316_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg(v_rules_314_, v_names_315_);
lean_dec(v_rules_314_);
return v___x_316_;
}
case 4:
{
lean_object* v___x_317_; lean_object* v___x_318_; 
lean_dec_ref_known(v_ci_292_, 1);
v___x_317_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_constantDependencies___closed__14));
v___x_318_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v___x_317_, v_names_294_);
return v___x_318_;
}
default: 
{
lean_dec_ref(v_ci_292_);
return v_names_294_;
}
}
}
v___jp_321_:
{
lean_object* v_names_323_; 
v_names_323_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v_names_320_, v___y_322_);
lean_dec_ref(v___y_322_);
v_names_294_ = v_names_323_;
goto v___jp_293_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3(lean_object* v_as_341_, lean_object* v_as_x27_342_, lean_object* v_b_343_, lean_object* v_a_344_){
_start:
{
lean_object* v___x_345_; 
v___x_345_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___redArg(v_as_x27_342_, v_b_343_);
return v___x_345_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3___boxed(lean_object* v_as_346_, lean_object* v_as_x27_347_, lean_object* v_b_348_, lean_object* v_a_349_){
_start:
{
lean_object* v_res_350_; 
v_res_350_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_constantDependencies_spec__3(v_as_346_, v_as_x27_347_, v_b_348_, v_a_349_);
lean_dec(v_as_x27_347_);
lean_dec(v_as_346_);
return v_res_350_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2(lean_object* v_as_351_, lean_object* v_as_x27_352_, lean_object* v_b_353_, lean_object* v_a_354_){
_start:
{
lean_object* v___x_355_; 
v___x_355_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___redArg(v_as_x27_352_, v_b_353_);
return v___x_355_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2___boxed(lean_object* v_as_356_, lean_object* v_as_x27_357_, lean_object* v_b_358_, lean_object* v_a_359_){
_start:
{
lean_object* v_res_360_; 
v_res_360_ = lp_proofEnvironment_List_forIn_x27_loop___at___00Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00OCMEnvironment_constantDependencies_spec__2_spec__2(v_as_356_, v_as_x27_357_, v_b_358_, v_a_359_);
lean_dec(v_as_x27_357_);
lean_dec(v_as_356_);
return v_res_360_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__5(uint8_t v___x_361_, lean_object* v_a_362_, lean_object* v_a_363_){
_start:
{
if (lean_obj_tag(v_a_362_) == 0)
{
lean_object* v___x_364_; 
v___x_364_ = l_List_reverse___redArg(v_a_363_);
return v___x_364_;
}
else
{
lean_object* v_head_365_; lean_object* v_tail_366_; lean_object* v___x_368_; uint8_t v_isShared_369_; uint8_t v_isSharedCheck_375_; 
v_head_365_ = lean_ctor_get(v_a_362_, 0);
v_tail_366_ = lean_ctor_get(v_a_362_, 1);
v_isSharedCheck_375_ = !lean_is_exclusive(v_a_362_);
if (v_isSharedCheck_375_ == 0)
{
v___x_368_ = v_a_362_;
v_isShared_369_ = v_isSharedCheck_375_;
goto v_resetjp_367_;
}
else
{
lean_inc(v_tail_366_);
lean_inc(v_head_365_);
lean_dec(v_a_362_);
v___x_368_ = lean_box(0);
v_isShared_369_ = v_isSharedCheck_375_;
goto v_resetjp_367_;
}
v_resetjp_367_:
{
lean_object* v___x_370_; lean_object* v___x_372_; 
v___x_370_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_365_, v___x_361_);
if (v_isShared_369_ == 0)
{
lean_ctor_set(v___x_368_, 1, v_a_363_);
lean_ctor_set(v___x_368_, 0, v___x_370_);
v___x_372_ = v___x_368_;
goto v_reusejp_371_;
}
else
{
lean_object* v_reuseFailAlloc_374_; 
v_reuseFailAlloc_374_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_374_, 0, v___x_370_);
lean_ctor_set(v_reuseFailAlloc_374_, 1, v_a_363_);
v___x_372_ = v_reuseFailAlloc_374_;
goto v_reusejp_371_;
}
v_reusejp_371_:
{
v_a_362_ = v_tail_366_;
v_a_363_ = v___x_372_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__5___boxed(lean_object* v___x_376_, lean_object* v_a_377_, lean_object* v_a_378_){
_start:
{
uint8_t v___x_5794__boxed_379_; lean_object* v_res_380_; 
v___x_5794__boxed_379_ = lean_unbox(v___x_376_);
v_res_380_ = lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__5(v___x_5794__boxed_379_, v_a_377_, v_a_378_);
return v_res_380_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__4(lean_object* v_a_381_, lean_object* v_a_382_){
_start:
{
if (lean_obj_tag(v_a_381_) == 0)
{
lean_object* v___x_383_; 
v___x_383_ = l_List_reverse___redArg(v_a_382_);
return v___x_383_;
}
else
{
lean_object* v_head_384_; lean_object* v_tail_385_; lean_object* v___x_387_; uint8_t v_isShared_388_; uint8_t v_isSharedCheck_395_; 
v_head_384_ = lean_ctor_get(v_a_381_, 0);
v_tail_385_ = lean_ctor_get(v_a_381_, 1);
v_isSharedCheck_395_ = !lean_is_exclusive(v_a_381_);
if (v_isSharedCheck_395_ == 0)
{
v___x_387_ = v_a_381_;
v_isShared_388_ = v_isSharedCheck_395_;
goto v_resetjp_386_;
}
else
{
lean_inc(v_tail_385_);
lean_inc(v_head_384_);
lean_dec(v_a_381_);
v___x_387_ = lean_box(0);
v_isShared_388_ = v_isSharedCheck_395_;
goto v_resetjp_386_;
}
v_resetjp_386_:
{
uint8_t v___x_389_; lean_object* v___x_390_; lean_object* v___x_392_; 
v___x_389_ = 1;
v___x_390_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_head_384_, v___x_389_);
if (v_isShared_388_ == 0)
{
lean_ctor_set(v___x_387_, 1, v_a_382_);
lean_ctor_set(v___x_387_, 0, v___x_390_);
v___x_392_ = v___x_387_;
goto v_reusejp_391_;
}
else
{
lean_object* v_reuseFailAlloc_394_; 
v_reuseFailAlloc_394_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_394_, 0, v___x_390_);
lean_ctor_set(v_reuseFailAlloc_394_, 1, v_a_382_);
v___x_392_ = v_reuseFailAlloc_394_;
goto v_reusejp_391_;
}
v_reusejp_391_:
{
v_a_381_ = v_tail_385_;
v_a_382_ = v___x_392_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_dependencyClosure_spec__3(lean_object* v_fst_396_, lean_object* v___x_397_, lean_object* v_snd_398_, lean_object* v_as_399_, size_t v_sz_400_, size_t v_i_401_, lean_object* v_b_402_){
_start:
{
lean_object* v_a_404_; uint8_t v___x_408_; 
v___x_408_ = lean_usize_dec_lt(v_i_401_, v_sz_400_);
if (v___x_408_ == 0)
{
lean_object* v___x_409_; 
lean_dec(v_snd_398_);
lean_dec(v_fst_396_);
v___x_409_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_409_, 0, v_b_402_);
return v___x_409_;
}
else
{
lean_object* v_snd_410_; lean_object* v_fst_411_; lean_object* v___x_413_; uint8_t v_isShared_414_; uint8_t v_isSharedCheck_435_; 
v_snd_410_ = lean_ctor_get(v_b_402_, 1);
v_fst_411_ = lean_ctor_get(v_b_402_, 0);
v_isSharedCheck_435_ = !lean_is_exclusive(v_b_402_);
if (v_isSharedCheck_435_ == 0)
{
v___x_413_ = v_b_402_;
v_isShared_414_ = v_isSharedCheck_435_;
goto v_resetjp_412_;
}
else
{
lean_inc(v_snd_410_);
lean_inc(v_fst_411_);
lean_dec(v_b_402_);
v___x_413_ = lean_box(0);
v_isShared_414_ = v_isSharedCheck_435_;
goto v_resetjp_412_;
}
v_resetjp_412_:
{
lean_object* v_names_415_; lean_object* v_edges_416_; lean_object* v___x_418_; uint8_t v_isShared_419_; uint8_t v_isSharedCheck_434_; 
v_names_415_ = lean_ctor_get(v_snd_410_, 0);
v_edges_416_ = lean_ctor_get(v_snd_410_, 1);
v_isSharedCheck_434_ = !lean_is_exclusive(v_snd_410_);
if (v_isSharedCheck_434_ == 0)
{
v___x_418_ = v_snd_410_;
v_isShared_419_ = v_isSharedCheck_434_;
goto v_resetjp_417_;
}
else
{
lean_inc(v_edges_416_);
lean_inc(v_names_415_);
lean_dec(v_snd_410_);
v___x_418_ = lean_box(0);
v_isShared_419_ = v_isSharedCheck_434_;
goto v_resetjp_417_;
}
v_resetjp_417_:
{
lean_object* v_a_420_; lean_object* v___x_422_; 
v_a_420_ = lean_array_uget_borrowed(v_as_399_, v_i_401_);
lean_inc(v_a_420_);
lean_inc(v_fst_396_);
if (v_isShared_414_ == 0)
{
lean_ctor_set(v___x_413_, 1, v_a_420_);
lean_ctor_set(v___x_413_, 0, v_fst_396_);
v___x_422_ = v___x_413_;
goto v_reusejp_421_;
}
else
{
lean_object* v_reuseFailAlloc_433_; 
v_reuseFailAlloc_433_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_433_, 0, v_fst_396_);
lean_ctor_set(v_reuseFailAlloc_433_, 1, v_a_420_);
v___x_422_ = v_reuseFailAlloc_433_;
goto v_reusejp_421_;
}
v_reusejp_421_:
{
lean_object* v___x_423_; lean_object* v___x_425_; 
v___x_423_ = lean_array_push(v_edges_416_, v___x_422_);
if (v_isShared_419_ == 0)
{
lean_ctor_set(v___x_418_, 1, v___x_423_);
v___x_425_ = v___x_418_;
goto v_reusejp_424_;
}
else
{
lean_object* v_reuseFailAlloc_432_; 
v_reuseFailAlloc_432_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_432_, 0, v_names_415_);
lean_ctor_set(v_reuseFailAlloc_432_, 1, v___x_423_);
v___x_425_ = v_reuseFailAlloc_432_;
goto v_reusejp_424_;
}
v_reusejp_424_:
{
uint8_t v___x_426_; 
v___x_426_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v___x_397_, v_a_420_);
if (v___x_426_ == 0)
{
lean_object* v___x_427_; lean_object* v___x_428_; lean_object* v___x_429_; lean_object* v___x_430_; 
lean_inc(v_snd_398_);
lean_inc_n(v_a_420_, 2);
v___x_427_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_427_, 0, v_a_420_);
lean_ctor_set(v___x_427_, 1, v_snd_398_);
v___x_428_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_428_, 0, v_a_420_);
lean_ctor_set(v___x_428_, 1, v___x_427_);
v___x_429_ = lean_array_push(v_fst_411_, v___x_428_);
v___x_430_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_430_, 0, v___x_429_);
lean_ctor_set(v___x_430_, 1, v___x_425_);
v_a_404_ = v___x_430_;
goto v___jp_403_;
}
else
{
lean_object* v___x_431_; 
v___x_431_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_431_, 0, v_fst_411_);
lean_ctor_set(v___x_431_, 1, v___x_425_);
v_a_404_ = v___x_431_;
goto v___jp_403_;
}
}
}
}
}
}
v___jp_403_:
{
size_t v___x_405_; size_t v___x_406_; 
v___x_405_ = ((size_t)1ULL);
v___x_406_ = lean_usize_add(v_i_401_, v___x_405_);
v_i_401_ = v___x_406_;
v_b_402_ = v_a_404_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_dependencyClosure_spec__3___boxed(lean_object* v_fst_436_, lean_object* v___x_437_, lean_object* v_snd_438_, lean_object* v_as_439_, lean_object* v_sz_440_, lean_object* v_i_441_, lean_object* v_b_442_){
_start:
{
size_t v_sz_boxed_443_; size_t v_i_boxed_444_; lean_object* v_res_445_; 
v_sz_boxed_443_ = lean_unbox_usize(v_sz_440_);
lean_dec(v_sz_440_);
v_i_boxed_444_ = lean_unbox_usize(v_i_441_);
lean_dec(v_i_441_);
v_res_445_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_dependencyClosure_spec__3(v_fst_436_, v___x_437_, v_snd_438_, v_as_439_, v_sz_boxed_443_, v_i_boxed_444_, v_b_442_);
lean_dec_ref(v_as_439_);
lean_dec_ref(v___x_437_);
return v_res_445_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg(lean_object* v_excluded_454_, lean_object* v_constants_455_, lean_object* v_a_456_, lean_object* v_a_457_){
_start:
{
lean_object* v_snd_458_; lean_object* v_snd_459_; lean_object* v_fst_460_; lean_object* v___x_462_; uint8_t v_isShared_463_; uint8_t v_isSharedCheck_618_; 
v_snd_458_ = lean_ctor_get(v_a_457_, 1);
lean_inc(v_snd_458_);
v_snd_459_ = lean_ctor_get(v_snd_458_, 1);
lean_inc(v_snd_459_);
v_fst_460_ = lean_ctor_get(v_a_457_, 0);
v_isSharedCheck_618_ = !lean_is_exclusive(v_a_457_);
if (v_isSharedCheck_618_ == 0)
{
lean_object* v_unused_619_; 
v_unused_619_ = lean_ctor_get(v_a_457_, 1);
lean_dec(v_unused_619_);
v___x_462_ = v_a_457_;
v_isShared_463_ = v_isSharedCheck_618_;
goto v_resetjp_461_;
}
else
{
lean_inc(v_fst_460_);
lean_dec(v_a_457_);
v___x_462_ = lean_box(0);
v_isShared_463_ = v_isSharedCheck_618_;
goto v_resetjp_461_;
}
v_resetjp_461_:
{
lean_object* v_fst_464_; lean_object* v___x_466_; uint8_t v_isShared_467_; uint8_t v_isSharedCheck_616_; 
v_fst_464_ = lean_ctor_get(v_snd_458_, 0);
v_isSharedCheck_616_ = !lean_is_exclusive(v_snd_458_);
if (v_isSharedCheck_616_ == 0)
{
lean_object* v_unused_617_; 
v_unused_617_ = lean_ctor_get(v_snd_458_, 1);
lean_dec(v_unused_617_);
v___x_466_ = v_snd_458_;
v_isShared_467_ = v_isSharedCheck_616_;
goto v_resetjp_465_;
}
else
{
lean_inc(v_fst_464_);
lean_dec(v_snd_458_);
v___x_466_ = lean_box(0);
v_isShared_467_ = v_isSharedCheck_616_;
goto v_resetjp_465_;
}
v_resetjp_465_:
{
lean_object* v_fst_468_; lean_object* v_snd_469_; lean_object* v___x_471_; uint8_t v_isShared_472_; uint8_t v_isSharedCheck_615_; 
v_fst_468_ = lean_ctor_get(v_snd_459_, 0);
v_snd_469_ = lean_ctor_get(v_snd_459_, 1);
v_isSharedCheck_615_ = !lean_is_exclusive(v_snd_459_);
if (v_isSharedCheck_615_ == 0)
{
v___x_471_ = v_snd_459_;
v_isShared_472_ = v_isSharedCheck_615_;
goto v_resetjp_470_;
}
else
{
lean_inc(v_snd_469_);
lean_inc(v_fst_468_);
lean_dec(v_snd_459_);
v___x_471_ = lean_box(0);
v_isShared_472_ = v_isSharedCheck_615_;
goto v_resetjp_470_;
}
v_resetjp_470_:
{
lean_object* v___x_473_; uint8_t v___x_474_; 
v___x_473_ = lean_array_get_size(v_fst_460_);
v___x_474_ = lean_nat_dec_lt(v_fst_464_, v___x_473_);
if (v___x_474_ == 0)
{
lean_object* v___x_476_; 
if (v_isShared_472_ == 0)
{
v___x_476_ = v___x_471_;
goto v_reusejp_475_;
}
else
{
lean_object* v_reuseFailAlloc_484_; 
v_reuseFailAlloc_484_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_484_, 0, v_fst_468_);
lean_ctor_set(v_reuseFailAlloc_484_, 1, v_snd_469_);
v___x_476_ = v_reuseFailAlloc_484_;
goto v_reusejp_475_;
}
v_reusejp_475_:
{
lean_object* v___x_478_; 
if (v_isShared_467_ == 0)
{
lean_ctor_set(v___x_466_, 1, v___x_476_);
v___x_478_ = v___x_466_;
goto v_reusejp_477_;
}
else
{
lean_object* v_reuseFailAlloc_483_; 
v_reuseFailAlloc_483_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_483_, 0, v_fst_464_);
lean_ctor_set(v_reuseFailAlloc_483_, 1, v___x_476_);
v___x_478_ = v_reuseFailAlloc_483_;
goto v_reusejp_477_;
}
v_reusejp_477_:
{
lean_object* v___x_480_; 
if (v_isShared_463_ == 0)
{
lean_ctor_set(v___x_462_, 1, v___x_478_);
v___x_480_ = v___x_462_;
goto v_reusejp_479_;
}
else
{
lean_object* v_reuseFailAlloc_482_; 
v_reuseFailAlloc_482_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_482_, 0, v_fst_460_);
lean_ctor_set(v_reuseFailAlloc_482_, 1, v___x_478_);
v___x_480_ = v_reuseFailAlloc_482_;
goto v_reusejp_479_;
}
v_reusejp_479_:
{
lean_object* v___x_481_; 
v___x_481_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_481_, 0, v___x_480_);
return v___x_481_;
}
}
}
}
else
{
lean_object* v___x_485_; lean_object* v___x_486_; lean_object* v___x_487_; lean_object* v_fst_488_; lean_object* v_snd_489_; lean_object* v___x_491_; uint8_t v_isShared_492_; uint8_t v_isSharedCheck_614_; 
lean_del_object(v___x_462_);
v___x_485_ = lean_box(0);
v___x_486_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__0));
v___x_487_ = lean_array_get(v___x_486_, v_fst_460_, v_fst_464_);
v_fst_488_ = lean_ctor_get(v___x_487_, 0);
v_snd_489_ = lean_ctor_get(v___x_487_, 1);
v_isSharedCheck_614_ = !lean_is_exclusive(v___x_487_);
if (v_isSharedCheck_614_ == 0)
{
v___x_491_ = v___x_487_;
v_isShared_492_ = v_isSharedCheck_614_;
goto v_resetjp_490_;
}
else
{
lean_inc(v_snd_489_);
lean_inc(v_fst_488_);
lean_dec(v___x_487_);
v___x_491_ = lean_box(0);
v_isShared_492_ = v_isSharedCheck_614_;
goto v_resetjp_490_;
}
v_resetjp_490_:
{
uint8_t v___y_494_; uint8_t v___x_499_; 
v___x_499_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_excluded_454_, v_fst_488_);
if (v___x_499_ == 0)
{
lean_object* v___x_500_; lean_object* v___x_501_; uint8_t v___x_502_; 
v___x_500_ = lean_unsigned_to_nat(1u);
v___x_501_ = lean_nat_add(v_fst_464_, v___x_500_);
lean_dec(v_fst_464_);
v___x_502_ = l_Std_DHashMap_Internal_Raw_u2080_contains___at___00Lean_NameHashSet_contains_spec__0___redArg(v_fst_468_, v_fst_488_);
if (v___x_502_ == 0)
{
lean_object* v___x_503_; 
v___x_503_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_455_, v_fst_488_);
if (lean_obj_tag(v___x_503_) == 1)
{
lean_object* v_val_504_; uint8_t v___x_505_; 
v_val_504_ = lean_ctor_get(v___x_503_, 0);
lean_inc(v_val_504_);
lean_dec_ref_known(v___x_503_, 1);
v___x_505_ = l_Lean_ConstantInfo_isUnsafe(v_val_504_);
if (v___x_505_ == 0)
{
uint8_t v___x_506_; 
v___x_506_ = l_Lean_ConstantInfo_isPartial(v_val_504_);
if (v___x_506_ == 0)
{
lean_object* v_names_507_; lean_object* v_edges_508_; lean_object* v___x_510_; uint8_t v_isShared_511_; uint8_t v_isSharedCheck_591_; 
v_names_507_ = lean_ctor_get(v_snd_469_, 0);
v_edges_508_ = lean_ctor_get(v_snd_469_, 1);
v_isSharedCheck_591_ = !lean_is_exclusive(v_snd_469_);
if (v_isSharedCheck_591_ == 0)
{
v___x_510_ = v_snd_469_;
v_isShared_511_ = v_isSharedCheck_591_;
goto v_resetjp_509_;
}
else
{
lean_inc(v_edges_508_);
lean_inc(v_names_507_);
lean_dec(v_snd_469_);
v___x_510_ = lean_box(0);
v_isShared_511_ = v_isSharedCheck_591_;
goto v_resetjp_509_;
}
v_resetjp_509_:
{
lean_object* v___x_512_; lean_object* v___x_513_; lean_object* v___x_514_; lean_object* v___x_516_; 
v___x_512_ = lean_unsigned_to_nat(0u);
lean_inc_n(v_fst_488_, 2);
v___x_513_ = l_Lean_NameHashSet_insert(v_fst_468_, v_fst_488_);
v___x_514_ = lean_array_push(v_names_507_, v_fst_488_);
if (v_isShared_511_ == 0)
{
lean_ctor_set(v___x_510_, 0, v___x_514_);
v___x_516_ = v___x_510_;
goto v_reusejp_515_;
}
else
{
lean_object* v_reuseFailAlloc_590_; 
v_reuseFailAlloc_590_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_590_, 0, v___x_514_);
lean_ctor_set(v_reuseFailAlloc_590_, 1, v_edges_508_);
v___x_516_ = v_reuseFailAlloc_590_;
goto v_reusejp_515_;
}
v_reusejp_515_:
{
lean_object* v___y_518_; lean_object* v___y_551_; lean_object* v___y_552_; lean_object* v___y_553_; lean_object* v___y_554_; lean_object* v___y_557_; lean_object* v___y_558_; lean_object* v___y_559_; lean_object* v___y_560_; lean_object* v___y_563_; lean_object* v___y_569_; 
if (lean_obj_tag(v_val_504_) == 5)
{
lean_object* v___x_582_; lean_object* v___y_584_; lean_object* v___x_586_; 
v___x_582_ = lp_proofEnvironment_OCMEnvironment_constantDependencies(v_val_504_);
v___x_586_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_a_456_, v_fst_488_);
if (lean_obj_tag(v___x_586_) == 0)
{
lean_object* v___x_587_; 
v___x_587_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2));
v___y_584_ = v___x_587_;
goto v___jp_583_;
}
else
{
lean_object* v_val_588_; 
v_val_588_ = lean_ctor_get(v___x_586_, 0);
lean_inc(v_val_588_);
lean_dec_ref_known(v___x_586_, 1);
v___y_584_ = v_val_588_;
goto v___jp_583_;
}
v___jp_583_:
{
lean_object* v___x_585_; 
v___x_585_ = lp_proofEnvironment_Std_DHashMap_Internal_Raw_u2080_Const_insertManyIfNewUnit___at___00Comparator_checkAxioms_spec__2(v___x_582_, v___y_584_);
lean_dec_ref(v___y_584_);
v___y_569_ = v___x_585_;
goto v___jp_568_;
}
}
else
{
lean_object* v___x_589_; 
v___x_589_ = lp_proofEnvironment_OCMEnvironment_constantDependencies(v_val_504_);
v___y_569_ = v___x_589_;
goto v___jp_568_;
}
v___jp_517_:
{
lean_object* v___x_520_; 
if (v_isShared_492_ == 0)
{
lean_ctor_set(v___x_491_, 1, v___x_516_);
lean_ctor_set(v___x_491_, 0, v_fst_460_);
v___x_520_ = v___x_491_;
goto v_reusejp_519_;
}
else
{
lean_object* v_reuseFailAlloc_549_; 
v_reuseFailAlloc_549_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_549_, 0, v_fst_460_);
lean_ctor_set(v_reuseFailAlloc_549_, 1, v___x_516_);
v___x_520_ = v_reuseFailAlloc_549_;
goto v_reusejp_519_;
}
v_reusejp_519_:
{
size_t v_sz_521_; size_t v___x_522_; lean_object* v___x_523_; 
v_sz_521_ = lean_array_size(v___y_518_);
v___x_522_ = ((size_t)0ULL);
v___x_523_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_dependencyClosure_spec__3(v_fst_488_, v___x_513_, v_snd_489_, v___y_518_, v_sz_521_, v___x_522_, v___x_520_);
lean_dec_ref(v___y_518_);
if (lean_obj_tag(v___x_523_) == 0)
{
lean_object* v_a_524_; lean_object* v___x_526_; uint8_t v_isShared_527_; uint8_t v_isSharedCheck_531_; 
lean_dec_ref(v___x_513_);
lean_dec(v___x_501_);
lean_del_object(v___x_471_);
lean_del_object(v___x_466_);
v_a_524_ = lean_ctor_get(v___x_523_, 0);
v_isSharedCheck_531_ = !lean_is_exclusive(v___x_523_);
if (v_isSharedCheck_531_ == 0)
{
v___x_526_ = v___x_523_;
v_isShared_527_ = v_isSharedCheck_531_;
goto v_resetjp_525_;
}
else
{
lean_inc(v_a_524_);
lean_dec(v___x_523_);
v___x_526_ = lean_box(0);
v_isShared_527_ = v_isSharedCheck_531_;
goto v_resetjp_525_;
}
v_resetjp_525_:
{
lean_object* v___x_529_; 
if (v_isShared_527_ == 0)
{
v___x_529_ = v___x_526_;
goto v_reusejp_528_;
}
else
{
lean_object* v_reuseFailAlloc_530_; 
v_reuseFailAlloc_530_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_530_, 0, v_a_524_);
v___x_529_ = v_reuseFailAlloc_530_;
goto v_reusejp_528_;
}
v_reusejp_528_:
{
return v___x_529_;
}
}
}
else
{
lean_object* v_a_532_; lean_object* v_fst_533_; lean_object* v_snd_534_; lean_object* v___x_536_; uint8_t v_isShared_537_; uint8_t v_isSharedCheck_548_; 
v_a_532_ = lean_ctor_get(v___x_523_, 0);
lean_inc(v_a_532_);
lean_dec_ref_known(v___x_523_, 1);
v_fst_533_ = lean_ctor_get(v_a_532_, 0);
v_snd_534_ = lean_ctor_get(v_a_532_, 1);
v_isSharedCheck_548_ = !lean_is_exclusive(v_a_532_);
if (v_isSharedCheck_548_ == 0)
{
v___x_536_ = v_a_532_;
v_isShared_537_ = v_isSharedCheck_548_;
goto v_resetjp_535_;
}
else
{
lean_inc(v_snd_534_);
lean_inc(v_fst_533_);
lean_dec(v_a_532_);
v___x_536_ = lean_box(0);
v_isShared_537_ = v_isSharedCheck_548_;
goto v_resetjp_535_;
}
v_resetjp_535_:
{
lean_object* v___x_539_; 
if (v_isShared_537_ == 0)
{
lean_ctor_set(v___x_536_, 0, v___x_513_);
v___x_539_ = v___x_536_;
goto v_reusejp_538_;
}
else
{
lean_object* v_reuseFailAlloc_547_; 
v_reuseFailAlloc_547_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_547_, 0, v___x_513_);
lean_ctor_set(v_reuseFailAlloc_547_, 1, v_snd_534_);
v___x_539_ = v_reuseFailAlloc_547_;
goto v_reusejp_538_;
}
v_reusejp_538_:
{
lean_object* v___x_541_; 
if (v_isShared_472_ == 0)
{
lean_ctor_set(v___x_471_, 1, v___x_539_);
lean_ctor_set(v___x_471_, 0, v___x_501_);
v___x_541_ = v___x_471_;
goto v_reusejp_540_;
}
else
{
lean_object* v_reuseFailAlloc_546_; 
v_reuseFailAlloc_546_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_546_, 0, v___x_501_);
lean_ctor_set(v_reuseFailAlloc_546_, 1, v___x_539_);
v___x_541_ = v_reuseFailAlloc_546_;
goto v_reusejp_540_;
}
v_reusejp_540_:
{
lean_object* v___x_543_; 
if (v_isShared_467_ == 0)
{
lean_ctor_set(v___x_466_, 1, v___x_541_);
lean_ctor_set(v___x_466_, 0, v_fst_533_);
v___x_543_ = v___x_466_;
goto v_reusejp_542_;
}
else
{
lean_object* v_reuseFailAlloc_545_; 
v_reuseFailAlloc_545_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_545_, 0, v_fst_533_);
lean_ctor_set(v_reuseFailAlloc_545_, 1, v___x_541_);
v___x_543_ = v_reuseFailAlloc_545_;
goto v_reusejp_542_;
}
v_reusejp_542_:
{
v_a_457_ = v___x_543_;
goto _start;
}
}
}
}
}
}
}
v___jp_550_:
{
lean_object* v___x_555_; 
v___x_555_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collect_spec__2___redArg(v___y_553_, v___y_551_, v___y_552_, v___y_554_);
lean_dec(v___y_554_);
lean_dec(v___y_553_);
v___y_518_ = v___x_555_;
goto v___jp_517_;
}
v___jp_556_:
{
uint8_t v___x_561_; 
v___x_561_ = lean_nat_dec_le(v___y_560_, v___y_558_);
if (v___x_561_ == 0)
{
lean_dec(v___y_558_);
lean_inc(v___y_560_);
v___y_551_ = v___y_557_;
v___y_552_ = v___y_560_;
v___y_553_ = v___y_559_;
v___y_554_ = v___y_560_;
goto v___jp_550_;
}
else
{
v___y_551_ = v___y_557_;
v___y_552_ = v___y_560_;
v___y_553_ = v___y_559_;
v___y_554_ = v___y_558_;
goto v___jp_550_;
}
}
v___jp_562_:
{
lean_object* v___x_564_; uint8_t v___x_565_; 
v___x_564_ = lean_array_get_size(v___y_563_);
v___x_565_ = lean_nat_dec_eq(v___x_564_, v___x_512_);
if (v___x_565_ == 0)
{
lean_object* v___x_566_; uint8_t v___x_567_; 
v___x_566_ = lean_nat_sub(v___x_564_, v___x_500_);
v___x_567_ = lean_nat_dec_le(v___x_512_, v___x_566_);
if (v___x_567_ == 0)
{
lean_inc(v___x_566_);
v___y_557_ = v___y_563_;
v___y_558_ = v___x_566_;
v___y_559_ = v___x_564_;
v___y_560_ = v___x_566_;
goto v___jp_556_;
}
else
{
v___y_557_ = v___y_563_;
v___y_558_ = v___x_566_;
v___y_559_ = v___x_564_;
v___y_560_ = v___x_512_;
goto v___jp_556_;
}
}
else
{
v___y_518_ = v___y_563_;
goto v___jp_517_;
}
}
v___jp_568_:
{
lean_object* v_size_570_; lean_object* v_buckets_571_; lean_object* v___x_572_; lean_object* v___x_573_; uint8_t v___x_574_; 
v_size_570_ = lean_ctor_get(v___y_569_, 0);
lean_inc(v_size_570_);
v_buckets_571_ = lean_ctor_get(v___y_569_, 1);
lean_inc_ref(v_buckets_571_);
lean_dec_ref(v___y_569_);
v___x_572_ = lean_mk_empty_array_with_capacity(v_size_570_);
lean_dec(v_size_570_);
v___x_573_ = lean_array_get_size(v_buckets_571_);
v___x_574_ = lean_nat_dec_lt(v___x_512_, v___x_573_);
if (v___x_574_ == 0)
{
lean_dec_ref(v_buckets_571_);
v___y_563_ = v___x_572_;
goto v___jp_562_;
}
else
{
uint8_t v___x_575_; 
v___x_575_ = lean_nat_dec_le(v___x_573_, v___x_573_);
if (v___x_575_ == 0)
{
if (v___x_574_ == 0)
{
lean_dec_ref(v_buckets_571_);
v___y_563_ = v___x_572_;
goto v___jp_562_;
}
else
{
size_t v___x_576_; size_t v___x_577_; lean_object* v___x_578_; 
v___x_576_ = ((size_t)0ULL);
v___x_577_ = lean_usize_of_nat(v___x_573_);
v___x_578_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_571_, v___x_576_, v___x_577_, v___x_572_);
lean_dec_ref(v_buckets_571_);
v___y_563_ = v___x_578_;
goto v___jp_562_;
}
}
else
{
size_t v___x_579_; size_t v___x_580_; lean_object* v___x_581_; 
v___x_579_ = ((size_t)0ULL);
v___x_580_ = lean_usize_of_nat(v___x_573_);
v___x_581_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00OCMEnvironment_constantDependencies_spec__1(v_buckets_571_, v___x_579_, v___x_580_, v___x_572_);
lean_dec_ref(v_buckets_571_);
v___y_563_ = v___x_581_;
goto v___jp_562_;
}
}
}
}
}
}
else
{
lean_dec(v_val_504_);
lean_dec(v___x_501_);
lean_del_object(v___x_491_);
lean_dec(v_snd_489_);
lean_del_object(v___x_471_);
lean_dec(v_snd_469_);
lean_dec(v_fst_468_);
lean_del_object(v___x_466_);
lean_dec(v_fst_460_);
v___y_494_ = v___x_506_;
goto v___jp_493_;
}
}
else
{
lean_dec(v_val_504_);
lean_dec(v___x_501_);
lean_del_object(v___x_491_);
lean_dec(v_snd_489_);
lean_del_object(v___x_471_);
lean_dec(v_snd_469_);
lean_dec(v_fst_468_);
lean_del_object(v___x_466_);
lean_dec(v_fst_460_);
v___y_494_ = v___x_474_;
goto v___jp_493_;
}
}
else
{
lean_object* v___x_592_; lean_object* v___x_593_; lean_object* v___x_594_; lean_object* v___x_595_; lean_object* v___x_596_; lean_object* v___x_597_; 
lean_dec(v___x_503_);
lean_dec(v___x_501_);
lean_del_object(v___x_491_);
lean_dec(v_fst_488_);
lean_del_object(v___x_471_);
lean_dec(v_snd_469_);
lean_dec(v_fst_468_);
lean_del_object(v___x_466_);
lean_dec(v_fst_460_);
v___x_592_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__3));
v___x_593_ = l_List_reverse___redArg(v_snd_489_);
v___x_594_ = lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__4(v___x_593_, v___x_485_);
v___x_595_ = l_List_toString___at___00Lean_Parser_FirstTokens_toStr_spec__0(v___x_594_);
lean_dec(v___x_594_);
v___x_596_ = lean_string_append(v___x_592_, v___x_595_);
lean_dec_ref(v___x_595_);
v___x_597_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_597_, 0, v___x_596_);
return v___x_597_;
}
}
else
{
lean_object* v___x_599_; 
lean_dec(v_snd_489_);
lean_dec(v_fst_488_);
if (v_isShared_492_ == 0)
{
lean_ctor_set(v___x_491_, 1, v_snd_469_);
lean_ctor_set(v___x_491_, 0, v_fst_468_);
v___x_599_ = v___x_491_;
goto v_reusejp_598_;
}
else
{
lean_object* v_reuseFailAlloc_607_; 
v_reuseFailAlloc_607_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_607_, 0, v_fst_468_);
lean_ctor_set(v_reuseFailAlloc_607_, 1, v_snd_469_);
v___x_599_ = v_reuseFailAlloc_607_;
goto v_reusejp_598_;
}
v_reusejp_598_:
{
lean_object* v___x_601_; 
if (v_isShared_472_ == 0)
{
lean_ctor_set(v___x_471_, 1, v___x_599_);
lean_ctor_set(v___x_471_, 0, v___x_501_);
v___x_601_ = v___x_471_;
goto v_reusejp_600_;
}
else
{
lean_object* v_reuseFailAlloc_606_; 
v_reuseFailAlloc_606_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_606_, 0, v___x_501_);
lean_ctor_set(v_reuseFailAlloc_606_, 1, v___x_599_);
v___x_601_ = v_reuseFailAlloc_606_;
goto v_reusejp_600_;
}
v_reusejp_600_:
{
lean_object* v___x_603_; 
if (v_isShared_467_ == 0)
{
lean_ctor_set(v___x_466_, 1, v___x_601_);
lean_ctor_set(v___x_466_, 0, v_fst_460_);
v___x_603_ = v___x_466_;
goto v_reusejp_602_;
}
else
{
lean_object* v_reuseFailAlloc_605_; 
v_reuseFailAlloc_605_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_605_, 0, v_fst_460_);
lean_ctor_set(v_reuseFailAlloc_605_, 1, v___x_601_);
v___x_603_ = v_reuseFailAlloc_605_;
goto v_reusejp_602_;
}
v_reusejp_602_:
{
v_a_457_ = v___x_603_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_608_; lean_object* v___x_609_; lean_object* v___x_610_; lean_object* v___x_611_; lean_object* v___x_612_; lean_object* v___x_613_; 
lean_del_object(v___x_491_);
lean_dec(v_fst_488_);
lean_del_object(v___x_471_);
lean_dec(v_snd_469_);
lean_dec(v_fst_468_);
lean_del_object(v___x_466_);
lean_dec(v_fst_464_);
lean_dec(v_fst_460_);
v___x_608_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__4));
v___x_609_ = l_List_reverse___redArg(v_snd_489_);
v___x_610_ = lp_proofEnvironment_List_mapTR_loop___at___00OCMEnvironment_dependencyClosure_spec__5(v___x_499_, v___x_609_, v___x_485_);
v___x_611_ = l_List_toString___at___00Lean_Parser_FirstTokens_toStr_spec__0(v___x_610_);
lean_dec(v___x_610_);
v___x_612_ = lean_string_append(v___x_608_, v___x_611_);
lean_dec_ref(v___x_611_);
v___x_613_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_613_, 0, v___x_612_);
return v___x_613_;
}
v___jp_493_:
{
lean_object* v___x_495_; lean_object* v___x_496_; lean_object* v___x_497_; lean_object* v___x_498_; 
v___x_495_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__1));
v___x_496_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_488_, v___y_494_);
v___x_497_ = lean_string_append(v___x_495_, v___x_496_);
lean_dec_ref(v___x_496_);
v___x_498_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_498_, 0, v___x_497_);
return v___x_498_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___boxed(lean_object* v_excluded_620_, lean_object* v_constants_621_, lean_object* v_a_622_, lean_object* v_a_623_){
_start:
{
lean_object* v_res_624_; 
v_res_624_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg(v_excluded_620_, v_constants_621_, v_a_622_, v_a_623_);
lean_dec_ref(v_a_622_);
lean_dec_ref(v_constants_621_);
lean_dec_ref(v_excluded_620_);
return v_res_624_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg(lean_object* v_fst_625_, lean_object* v_as_x27_626_, lean_object* v_b_627_){
_start:
{
if (lean_obj_tag(v_as_x27_626_) == 0)
{
lean_object* v___x_628_; 
lean_dec(v_fst_625_);
v___x_628_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_628_, 0, v_b_627_);
return v___x_628_;
}
else
{
lean_object* v_head_629_; lean_object* v_tail_630_; lean_object* v___y_632_; lean_object* v___x_636_; 
v_head_629_ = lean_ctor_get(v_as_x27_626_, 0);
v_tail_630_ = lean_ctor_get(v_as_x27_626_, 1);
v___x_636_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_b_627_, v_head_629_);
if (lean_obj_tag(v___x_636_) == 0)
{
lean_object* v___x_637_; 
v___x_637_ = ((lean_object*)(lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg___closed__2));
v___y_632_ = v___x_637_;
goto v___jp_631_;
}
else
{
lean_object* v_val_638_; 
v_val_638_ = lean_ctor_get(v___x_636_, 0);
lean_inc(v_val_638_);
lean_dec_ref_known(v___x_636_, 1);
v___y_632_ = v_val_638_;
goto v___jp_631_;
}
v___jp_631_:
{
lean_object* v___x_633_; lean_object* v___x_634_; 
lean_inc(v_fst_625_);
v___x_633_ = lean_array_push(v___y_632_, v_fst_625_);
lean_inc(v_head_629_);
v___x_634_ = l_Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_SMap_insert___at___00__private_Lean_ReducibilityAttrs_0__Lean_initFn_00___x40_Lean_ReducibilityAttrs_3557922905____hygCtx___hyg_2__spec__1_spec__2___redArg(v_b_627_, v_head_629_, v___x_633_);
v_as_x27_626_ = v_tail_630_;
v_b_627_ = v___x_634_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg___boxed(lean_object* v_fst_639_, lean_object* v_as_x27_640_, lean_object* v_b_641_){
_start:
{
lean_object* v_res_642_; 
v_res_642_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg(v_fst_639_, v_as_x27_640_, v_b_641_);
lean_dec(v_as_x27_640_);
return v_res_642_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg(lean_object* v_as_x27_643_, lean_object* v_b_644_){
_start:
{
if (lean_obj_tag(v_as_x27_643_) == 0)
{
lean_object* v___x_645_; 
v___x_645_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_645_, 0, v_b_644_);
return v___x_645_;
}
else
{
lean_object* v_head_646_; lean_object* v_snd_647_; 
v_head_646_ = lean_ctor_get(v_as_x27_643_, 0);
v_snd_647_ = lean_ctor_get(v_head_646_, 1);
if (lean_obj_tag(v_snd_647_) == 7)
{
lean_object* v_val_648_; lean_object* v_tail_649_; lean_object* v_fst_650_; lean_object* v_all_651_; lean_object* v___x_652_; lean_object* v_a_653_; 
v_val_648_ = lean_ctor_get(v_snd_647_, 0);
v_tail_649_ = lean_ctor_get(v_as_x27_643_, 1);
v_fst_650_ = lean_ctor_get(v_head_646_, 0);
v_all_651_ = lean_ctor_get(v_val_648_, 1);
lean_inc(v_fst_650_);
v___x_652_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg(v_fst_650_, v_all_651_, v_b_644_);
v_a_653_ = lean_ctor_get(v___x_652_, 0);
lean_inc(v_a_653_);
lean_dec_ref(v___x_652_);
v_as_x27_643_ = v_tail_649_;
v_b_644_ = v_a_653_;
goto _start;
}
else
{
lean_object* v_tail_655_; 
v_tail_655_ = lean_ctor_get(v_as_x27_643_, 1);
v_as_x27_643_ = v_tail_655_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg___boxed(lean_object* v_as_x27_657_, lean_object* v_b_658_){
_start:
{
lean_object* v_res_659_; 
v_res_659_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg(v_as_x27_657_, v_b_658_);
lean_dec(v_as_x27_657_);
return v_res_659_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_dependencyClosure_spec__2(size_t v_sz_660_, size_t v_i_661_, lean_object* v_bs_662_){
_start:
{
uint8_t v___x_663_; 
v___x_663_ = lean_usize_dec_lt(v_i_661_, v_sz_660_);
if (v___x_663_ == 0)
{
return v_bs_662_;
}
else
{
lean_object* v_v_664_; lean_object* v___x_665_; lean_object* v_bs_x27_666_; lean_object* v___x_667_; lean_object* v___x_668_; lean_object* v___x_669_; size_t v___x_670_; size_t v___x_671_; lean_object* v___x_672_; 
v_v_664_ = lean_array_uget(v_bs_662_, v_i_661_);
v___x_665_ = lean_unsigned_to_nat(0u);
v_bs_x27_666_ = lean_array_uset(v_bs_662_, v_i_661_, v___x_665_);
v___x_667_ = lean_box(0);
lean_inc(v_v_664_);
v___x_668_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_668_, 0, v_v_664_);
lean_ctor_set(v___x_668_, 1, v___x_667_);
v___x_669_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_669_, 0, v_v_664_);
lean_ctor_set(v___x_669_, 1, v___x_668_);
v___x_670_ = ((size_t)1ULL);
v___x_671_ = lean_usize_add(v_i_661_, v___x_670_);
v___x_672_ = lean_array_uset(v_bs_x27_666_, v_i_661_, v___x_669_);
v_i_661_ = v___x_671_;
v_bs_662_ = v___x_672_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_dependencyClosure_spec__2___boxed(lean_object* v_sz_674_, lean_object* v_i_675_, lean_object* v_bs_676_){
_start:
{
size_t v_sz_boxed_677_; size_t v_i_boxed_678_; lean_object* v_res_679_; 
v_sz_boxed_677_ = lean_unbox_usize(v_sz_674_);
lean_dec(v_sz_674_);
v_i_boxed_678_ = lean_unbox_usize(v_i_675_);
lean_dec(v_i_675_);
v_res_679_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_dependencyClosure_spec__2(v_sz_boxed_677_, v_i_boxed_678_, v_bs_676_);
return v_res_679_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__0(void){
_start:
{
lean_object* v___x_680_; lean_object* v___x_681_; lean_object* v___x_682_; 
v___x_680_ = lean_box(0);
v___x_681_ = lean_unsigned_to_nat(16u);
v___x_682_ = lean_mk_array(v___x_681_, v___x_680_);
return v___x_682_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1(void){
_start:
{
lean_object* v___x_683_; lean_object* v___x_684_; lean_object* v_recursors_685_; 
v___x_683_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__0, &lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__0_once, _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__0);
v___x_684_ = lean_unsigned_to_nat(0u);
v_recursors_685_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_recursors_685_, 0, v___x_684_);
lean_ctor_set(v_recursors_685_, 1, v___x_683_);
return v_recursors_685_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__3(void){
_start:
{
lean_object* v___x_688_; lean_object* v_recursors_689_; lean_object* v___x_690_; 
v___x_688_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__2));
v_recursors_689_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1, &lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1_once, _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1);
v___x_690_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_690_, 0, v_recursors_689_);
lean_ctor_set(v___x_690_, 1, v___x_688_);
return v___x_690_;
}
}
static lean_object* _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__4(void){
_start:
{
lean_object* v___x_691_; lean_object* v___x_692_; lean_object* v___x_693_; 
v___x_691_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__3, &lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__3_once, _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__3);
v___x_692_ = lean_unsigned_to_nat(0u);
v___x_693_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_693_, 0, v___x_692_);
lean_ctor_set(v___x_693_, 1, v___x_691_);
return v___x_693_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure(lean_object* v_constants_694_, lean_object* v_roots_695_, lean_object* v_excluded_696_){
_start:
{
lean_object* v_buckets_697_; lean_object* v___x_698_; lean_object* v_recursors_699_; lean_object* v___y_701_; lean_object* v___x_729_; lean_object* v___x_730_; uint8_t v___x_731_; 
v_buckets_697_ = lean_ctor_get(v_constants_694_, 1);
v___x_698_ = lean_unsigned_to_nat(0u);
v_recursors_699_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1, &lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1_once, _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__1);
v___x_729_ = lean_box(0);
v___x_730_ = lean_array_get_size(v_buckets_697_);
v___x_731_ = lean_nat_dec_lt(v___x_698_, v___x_730_);
if (v___x_731_ == 0)
{
v___y_701_ = v___x_729_;
goto v___jp_700_;
}
else
{
size_t v___x_732_; size_t v___x_733_; lean_object* v___x_734_; 
v___x_732_ = lean_usize_of_nat(v___x_730_);
v___x_733_ = ((size_t)0ULL);
v___x_734_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Lean_Environment_replay_spec__2(v_buckets_697_, v___x_732_, v___x_733_, v___x_729_);
v___y_701_ = v___x_734_;
goto v___jp_700_;
}
v___jp_700_:
{
lean_object* v___x_702_; lean_object* v_a_703_; size_t v_sz_704_; size_t v___x_705_; lean_object* v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; lean_object* v___x_709_; 
v___x_702_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg(v___y_701_, v_recursors_699_);
lean_dec(v___y_701_);
v_a_703_ = lean_ctor_get(v___x_702_, 0);
lean_inc(v_a_703_);
lean_dec_ref(v___x_702_);
v_sz_704_ = lean_array_size(v_roots_695_);
v___x_705_ = ((size_t)0ULL);
v___x_706_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00OCMEnvironment_dependencyClosure_spec__2(v_sz_704_, v___x_705_, v_roots_695_);
v___x_707_ = lean_obj_once(&lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__4, &lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__4_once, _init_lp_proofEnvironment_OCMEnvironment_dependencyClosure___closed__4);
v___x_708_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_708_, 0, v___x_706_);
lean_ctor_set(v___x_708_, 1, v___x_707_);
v___x_709_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg(v_excluded_696_, v_constants_694_, v_a_703_, v___x_708_);
lean_dec(v_a_703_);
if (lean_obj_tag(v___x_709_) == 0)
{
lean_object* v_a_710_; lean_object* v___x_712_; uint8_t v_isShared_713_; uint8_t v_isSharedCheck_717_; 
v_a_710_ = lean_ctor_get(v___x_709_, 0);
v_isSharedCheck_717_ = !lean_is_exclusive(v___x_709_);
if (v_isSharedCheck_717_ == 0)
{
v___x_712_ = v___x_709_;
v_isShared_713_ = v_isSharedCheck_717_;
goto v_resetjp_711_;
}
else
{
lean_inc(v_a_710_);
lean_dec(v___x_709_);
v___x_712_ = lean_box(0);
v_isShared_713_ = v_isSharedCheck_717_;
goto v_resetjp_711_;
}
v_resetjp_711_:
{
lean_object* v___x_715_; 
if (v_isShared_713_ == 0)
{
v___x_715_ = v___x_712_;
goto v_reusejp_714_;
}
else
{
lean_object* v_reuseFailAlloc_716_; 
v_reuseFailAlloc_716_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_716_, 0, v_a_710_);
v___x_715_ = v_reuseFailAlloc_716_;
goto v_reusejp_714_;
}
v_reusejp_714_:
{
return v___x_715_;
}
}
}
else
{
lean_object* v_a_718_; lean_object* v___x_720_; uint8_t v_isShared_721_; uint8_t v_isSharedCheck_728_; 
v_a_718_ = lean_ctor_get(v___x_709_, 0);
v_isSharedCheck_728_ = !lean_is_exclusive(v___x_709_);
if (v_isSharedCheck_728_ == 0)
{
v___x_720_ = v___x_709_;
v_isShared_721_ = v_isSharedCheck_728_;
goto v_resetjp_719_;
}
else
{
lean_inc(v_a_718_);
lean_dec(v___x_709_);
v___x_720_ = lean_box(0);
v_isShared_721_ = v_isSharedCheck_728_;
goto v_resetjp_719_;
}
v_resetjp_719_:
{
lean_object* v_snd_722_; lean_object* v_snd_723_; lean_object* v_snd_724_; lean_object* v___x_726_; 
v_snd_722_ = lean_ctor_get(v_a_718_, 1);
lean_inc(v_snd_722_);
lean_dec(v_a_718_);
v_snd_723_ = lean_ctor_get(v_snd_722_, 1);
lean_inc(v_snd_723_);
lean_dec(v_snd_722_);
v_snd_724_ = lean_ctor_get(v_snd_723_, 1);
lean_inc(v_snd_724_);
lean_dec(v_snd_723_);
if (v_isShared_721_ == 0)
{
lean_ctor_set(v___x_720_, 0, v_snd_724_);
v___x_726_ = v___x_720_;
goto v_reusejp_725_;
}
else
{
lean_object* v_reuseFailAlloc_727_; 
v_reuseFailAlloc_727_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_727_, 0, v_snd_724_);
v___x_726_ = v_reuseFailAlloc_727_;
goto v_reusejp_725_;
}
v_reusejp_725_:
{
return v___x_726_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_dependencyClosure___boxed(lean_object* v_constants_735_, lean_object* v_roots_736_, lean_object* v_excluded_737_){
_start:
{
lean_object* v_res_738_; 
v_res_738_ = lp_proofEnvironment_OCMEnvironment_dependencyClosure(v_constants_735_, v_roots_736_, v_excluded_737_);
lean_dec_ref(v_excluded_737_);
lean_dec_ref(v_constants_735_);
return v_res_738_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0(lean_object* v_fst_739_, lean_object* v_as_740_, lean_object* v_as_x27_741_, lean_object* v_b_742_, lean_object* v_a_743_){
_start:
{
lean_object* v___x_744_; 
v___x_744_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___redArg(v_fst_739_, v_as_x27_741_, v_b_742_);
return v___x_744_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0___boxed(lean_object* v_fst_745_, lean_object* v_as_746_, lean_object* v_as_x27_747_, lean_object* v_b_748_, lean_object* v_a_749_){
_start:
{
lean_object* v_res_750_; 
v_res_750_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__0(v_fst_745_, v_as_746_, v_as_x27_747_, v_b_748_, v_a_749_);
lean_dec(v_as_x27_747_);
lean_dec(v_as_746_);
return v_res_750_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1(lean_object* v_as_751_, lean_object* v_as_x27_752_, lean_object* v_b_753_, lean_object* v_a_754_){
_start:
{
lean_object* v___x_755_; 
v___x_755_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___redArg(v_as_x27_752_, v_b_753_);
return v___x_755_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1___boxed(lean_object* v_as_756_, lean_object* v_as_x27_757_, lean_object* v_b_758_, lean_object* v_a_759_){
_start:
{
lean_object* v_res_760_; 
v_res_760_ = lp_proofEnvironment_List_forIn_x27_loop___at___00OCMEnvironment_dependencyClosure_spec__1(v_as_756_, v_as_x27_757_, v_b_758_, v_a_759_);
lean_dec(v_as_x27_757_);
lean_dec(v_as_756_);
return v_res_760_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6(lean_object* v_excluded_761_, lean_object* v_constants_762_, lean_object* v_a_763_, lean_object* v_inst_764_, lean_object* v_a_765_){
_start:
{
lean_object* v___x_766_; 
v___x_766_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___redArg(v_excluded_761_, v_constants_762_, v_a_763_, v_a_765_);
return v___x_766_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6___boxed(lean_object* v_excluded_767_, lean_object* v_constants_768_, lean_object* v_a_769_, lean_object* v_inst_770_, lean_object* v_a_771_){
_start:
{
lean_object* v_res_772_; 
v_res_772_ = lp_proofEnvironment___private_Init_While_0__repeatM_erased___at___00OCMEnvironment_dependencyClosure_spec__6(v_excluded_767_, v_constants_768_, v_a_769_, v_inst_770_, v_a_771_);
lean_dec_ref(v_a_769_);
lean_dec_ref(v_constants_768_);
lean_dec_ref(v_excluded_767_);
return v_res_772_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Types(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Dependencies(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Types(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
