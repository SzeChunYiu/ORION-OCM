// Lean compiler output
// Module: OCMEnvironment.Registry
// Imports: public import Init public meta import Init public import OCMEnvironment.Prepare
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(lean_object*, lean_object*);
uint8_t lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* lean_string_append(lean_object*, lean_object*);
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Nat"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__1_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "zero"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__2 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__2_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__3_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__3_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__2_value),LEAN_SCALAR_PTR_LITERAL(51, 81, 163, 94, 71, 156, 90, 186)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__3 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__3_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "succ"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__4 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__4_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__5_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__5_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__4_value),LEAN_SCALAR_PTR_LITERAL(93, 165, 73, 246, 125, 40, 156, 223)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__5 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__5_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "add"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__6 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__6_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__7_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__7_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__6_value),LEAN_SCALAR_PTR_LITERAL(210, 189, 86, 121, 130, 22, 242, 236)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__7 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__7_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "sub"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__8 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__8_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__9_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__9_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__8_value),LEAN_SCALAR_PTR_LITERAL(9, 137, 41, 185, 216, 152, 145, 196)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__9 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__9_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "mul"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__10 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__10_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__11_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__11_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__10_value),LEAN_SCALAR_PTR_LITERAL(124, 230, 50, 167, 103, 237, 136, 198)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__11 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__11_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "pow"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__12 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__12_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__13_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__13_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__12_value),LEAN_SCALAR_PTR_LITERAL(155, 64, 52, 77, 166, 227, 131, 174)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__13 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__13_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "gcd"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__14 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__14_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__15_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__15_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__14_value),LEAN_SCALAR_PTR_LITERAL(57, 94, 240, 174, 21, 113, 54, 0)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__15 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__15_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "div"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__16 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__16_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__17_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__17_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__16_value),LEAN_SCALAR_PTR_LITERAL(67, 67, 214, 176, 223, 68, 36, 94)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__17 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__17_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "mod"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__18 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__18_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__19_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__19_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__18_value),LEAN_SCALAR_PTR_LITERAL(244, 133, 16, 0, 168, 19, 182, 179)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__19 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__19_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "beq"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__20 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__20_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__21_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__21_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__20_value),LEAN_SCALAR_PTR_LITERAL(58, 27, 161, 98, 177, 242, 252, 86)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__21 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__21_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ble"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__22 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__22_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__23_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__23_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__22_value),LEAN_SCALAR_PTR_LITERAL(18, 188, 15, 95, 29, 42, 30, 33)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__23 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__23_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "land"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__24 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__24_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__25_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__25_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__24_value),LEAN_SCALAR_PTR_LITERAL(188, 247, 118, 195, 143, 11, 83, 131)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__25 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__25_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lor"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__26 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__26_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__27_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__27_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__26_value),LEAN_SCALAR_PTR_LITERAL(189, 20, 242, 236, 1, 249, 227, 248)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__27 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__27_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "xor"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__28 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__28_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__29_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__29_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__28_value),LEAN_SCALAR_PTR_LITERAL(42, 157, 235, 85, 27, 16, 17, 168)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__29 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__29_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "shiftLeft"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__30 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__30_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__31_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__31_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__30_value),LEAN_SCALAR_PTR_LITERAL(85, 136, 172, 27, 109, 172, 80, 195)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__31 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__31_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "shiftRight"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__32 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__32_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__33_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__0_value),LEAN_SCALAR_PTR_LITERAL(155, 221, 223, 104, 58, 13, 204, 158)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__33_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__32_value),LEAN_SCALAR_PTR_LITERAL(119, 176, 216, 253, 49, 85, 187, 63)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__33 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__33_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "String"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__34 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__34_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__34_value),LEAN_SCALAR_PTR_LITERAL(6, 130, 56, 8, 41, 104, 134, 43)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__35 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__35_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__36_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "ofList"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__36 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__36_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__37_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__34_value),LEAN_SCALAR_PTR_LITERAL(6, 130, 56, 8, 41, 104, 134, 43)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__37_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__37_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__36_value),LEAN_SCALAR_PTR_LITERAL(118, 246, 177, 142, 179, 9, 199, 233)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__37 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__37_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__38_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Char"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__38 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__38_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__39_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__38_value),LEAN_SCALAR_PTR_LITERAL(18, 67, 155, 167, 151, 71, 146, 196)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__39 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__39_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__40_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "ofNat"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__40 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__40_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__41_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__38_value),LEAN_SCALAR_PTR_LITERAL(18, 67, 155, 167, 151, 71, 146, 196)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__41_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__41_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__40_value),LEAN_SCALAR_PTR_LITERAL(27, 51, 10, 169, 25, 67, 44, 251)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__41 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__41_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__42_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "List"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__42 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__42_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__43_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__42_value),LEAN_SCALAR_PTR_LITERAL(245, 188, 225, 225, 165, 5, 251, 132)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__43 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__43_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__44_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "eagerReduce"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__44 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__44_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__45_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__44_value),LEAN_SCALAR_PTR_LITERAL(238, 243, 67, 12, 220, 84, 120, 222)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__45 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__45_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__46_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "Eq"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__46 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__46_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__47_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__46_value),LEAN_SCALAR_PTR_LITERAL(143, 37, 101, 248, 9, 246, 191, 223)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__47 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__47_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Quot"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__49_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__49 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__49_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__50_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "mk"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__50 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__50_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__51_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__51_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__51_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__50_value),LEAN_SCALAR_PTR_LITERAL(255, 113, 137, 82, 82, 132, 58, 248)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__51 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__51_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__52_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lift"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__52 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__52_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__53_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__53_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__53_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__52_value),LEAN_SCALAR_PTR_LITERAL(91, 125, 38, 34, 222, 200, 201, 80)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__53 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__53_value;
static const lean_string_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__54_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "ind"};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__54 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__54_value;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__55_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__48_value),LEAN_SCALAR_PTR_LITERAL(91, 127, 250, 116, 111, 99, 160, 200)}};
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__55_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__55_value_aux_0),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__54_value),LEAN_SCALAR_PTR_LITERAL(150, 213, 121, 152, 109, 27, 137, 60)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__55 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__55_value;
static const lean_array_object lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__56_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*28, .m_other = 0, .m_tag = 246}, .m_size = 28, .m_capacity = 28, .m_data = {((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__1_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__3_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__5_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__7_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__9_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__11_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__13_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__15_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__17_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__19_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__21_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__23_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__25_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__27_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__29_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__31_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__33_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__35_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__37_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__39_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__41_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__43_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__45_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__47_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__49_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__51_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__53_value),((lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__55_value)}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__56 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__56_value;
LEAN_EXPORT const lean_object* lp_proofEnvironment_OCMEnvironment_knownPrimitives = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_knownPrimitives___closed__56_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "REGISTERED_PRIMITIVE_MISMATCH "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__0 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__0_value;
static const lean_string_object lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "MISSING_REGISTERED_PRIMITIVE "};
static const lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__1 = (const lean_object*)&lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static size_t lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__0;
static const lean_ctor_object lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__1 = (const lean_object*)&lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__1_value;
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0(lean_object* v_constants_167_, lean_object* v_registry_168_, lean_object* v_as_169_, size_t v_sz_170_, size_t v_i_171_, lean_object* v_b_172_){
_start:
{
lean_object* v_a_174_; uint8_t v___x_178_; 
v___x_178_ = lean_usize_dec_lt(v_i_171_, v_sz_170_);
if (v___x_178_ == 0)
{
lean_object* v___x_179_; 
v___x_179_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_179_, 0, v_b_172_);
return v___x_179_;
}
else
{
lean_object* v___x_180_; lean_object* v_a_181_; lean_object* v___x_182_; 
v___x_180_ = lean_box(0);
v_a_181_ = lean_array_uget_borrowed(v_as_169_, v_i_171_);
v___x_182_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_constants_167_, v_a_181_);
if (lean_obj_tag(v___x_182_) == 1)
{
lean_object* v_val_183_; lean_object* v___x_185_; uint8_t v_isShared_186_; uint8_t v_isSharedCheck_206_; 
v_val_183_ = lean_ctor_get(v___x_182_, 0);
v_isSharedCheck_206_ = !lean_is_exclusive(v___x_182_);
if (v_isSharedCheck_206_ == 0)
{
v___x_185_ = v___x_182_;
v_isShared_186_ = v_isSharedCheck_206_;
goto v_resetjp_184_;
}
else
{
lean_inc(v_val_183_);
lean_dec(v___x_182_);
v___x_185_ = lean_box(0);
v_isShared_186_ = v_isSharedCheck_206_;
goto v_resetjp_184_;
}
v_resetjp_184_:
{
lean_object* v___x_187_; 
v___x_187_ = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00__private_Lean_Replay_0__Lean_Environment_Replay_replayConstant_spec__3___redArg(v_registry_168_, v_a_181_);
if (lean_obj_tag(v___x_187_) == 1)
{
lean_object* v_val_188_; lean_object* v___x_190_; uint8_t v_isShared_191_; uint8_t v_isSharedCheck_199_; 
lean_del_object(v___x_185_);
v_val_188_ = lean_ctor_get(v___x_187_, 0);
v_isSharedCheck_199_ = !lean_is_exclusive(v___x_187_);
if (v_isSharedCheck_199_ == 0)
{
v___x_190_ = v___x_187_;
v_isShared_191_ = v_isSharedCheck_199_;
goto v_resetjp_189_;
}
else
{
lean_inc(v_val_188_);
lean_dec(v___x_187_);
v___x_190_ = lean_box(0);
v_isShared_191_ = v_isSharedCheck_199_;
goto v_resetjp_189_;
}
v_resetjp_189_:
{
uint8_t v___x_192_; 
v___x_192_ = lp_proofEnvironment_Comparator_Compare_instBEqConstantInfo__comparator_beq(v_val_188_, v_val_183_);
lean_dec(v_val_183_);
lean_dec(v_val_188_);
if (v___x_192_ == 0)
{
lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_197_; 
v___x_193_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__0));
lean_inc(v_a_181_);
v___x_194_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_181_, v___x_178_);
v___x_195_ = lean_string_append(v___x_193_, v___x_194_);
lean_dec_ref(v___x_194_);
if (v_isShared_191_ == 0)
{
lean_ctor_set_tag(v___x_190_, 0);
lean_ctor_set(v___x_190_, 0, v___x_195_);
v___x_197_ = v___x_190_;
goto v_reusejp_196_;
}
else
{
lean_object* v_reuseFailAlloc_198_; 
v_reuseFailAlloc_198_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_198_, 0, v___x_195_);
v___x_197_ = v_reuseFailAlloc_198_;
goto v_reusejp_196_;
}
v_reusejp_196_:
{
return v___x_197_;
}
}
else
{
lean_del_object(v___x_190_);
v_a_174_ = v___x_180_;
goto v___jp_173_;
}
}
}
else
{
lean_object* v___x_200_; lean_object* v___x_201_; lean_object* v___x_202_; lean_object* v___x_204_; 
lean_dec(v___x_187_);
lean_dec(v_val_183_);
v___x_200_ = ((lean_object*)(lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___closed__1));
lean_inc(v_a_181_);
v___x_201_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_a_181_, v___x_178_);
v___x_202_ = lean_string_append(v___x_200_, v___x_201_);
lean_dec_ref(v___x_201_);
if (v_isShared_186_ == 0)
{
lean_ctor_set_tag(v___x_185_, 0);
lean_ctor_set(v___x_185_, 0, v___x_202_);
v___x_204_ = v___x_185_;
goto v_reusejp_203_;
}
else
{
lean_object* v_reuseFailAlloc_205_; 
v_reuseFailAlloc_205_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_205_, 0, v___x_202_);
v___x_204_ = v_reuseFailAlloc_205_;
goto v_reusejp_203_;
}
v_reusejp_203_:
{
return v___x_204_;
}
}
}
}
else
{
lean_dec(v___x_182_);
v_a_174_ = v___x_180_;
goto v___jp_173_;
}
}
v___jp_173_:
{
size_t v___x_175_; size_t v___x_176_; 
v___x_175_ = ((size_t)1ULL);
v___x_176_ = lean_usize_add(v_i_171_, v___x_175_);
v_i_171_ = v___x_176_;
v_b_172_ = v_a_174_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0___boxed(lean_object* v_constants_207_, lean_object* v_registry_208_, lean_object* v_as_209_, lean_object* v_sz_210_, lean_object* v_i_211_, lean_object* v_b_212_){
_start:
{
size_t v_sz_boxed_213_; size_t v_i_boxed_214_; lean_object* v_res_215_; 
v_sz_boxed_213_ = lean_unbox_usize(v_sz_210_);
lean_dec(v_sz_210_);
v_i_boxed_214_ = lean_unbox_usize(v_i_211_);
lean_dec(v_i_211_);
v_res_215_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0(v_constants_207_, v_registry_208_, v_as_209_, v_sz_boxed_213_, v_i_boxed_214_, v_b_212_);
lean_dec_ref(v_as_209_);
lean_dec_ref(v_registry_208_);
lean_dec_ref(v_constants_207_);
return v_res_215_;
}
}
static size_t _init_lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__0(void){
_start:
{
lean_object* v___x_216_; size_t v_sz_217_; 
v___x_216_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_knownPrimitives));
v_sz_217_ = lean_array_size(v___x_216_);
return v_sz_217_;
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives(lean_object* v_constants_220_, lean_object* v_registry_221_){
_start:
{
lean_object* v___x_222_; lean_object* v___x_223_; size_t v_sz_224_; size_t v___x_225_; lean_object* v___x_226_; 
v___x_222_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_knownPrimitives));
v___x_223_ = lean_box(0);
v_sz_224_ = lean_usize_once(&lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__0, &lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__0_once, _init_lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__0);
v___x_225_ = ((size_t)0ULL);
v___x_226_ = lp_proofEnvironment___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00OCMEnvironment_requireKnownPrimitives_spec__0(v_constants_220_, v_registry_221_, v___x_222_, v_sz_224_, v___x_225_, v___x_223_);
if (lean_obj_tag(v___x_226_) == 0)
{
return v___x_226_;
}
else
{
lean_object* v___x_227_; 
lean_dec_ref_known(v___x_226_, 1);
v___x_227_ = ((lean_object*)(lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___closed__1));
return v___x_227_;
}
}
}
LEAN_EXPORT lean_object* lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives___boxed(lean_object* v_constants_228_, lean_object* v_registry_229_){
_start:
{
lean_object* v_res_230_; 
v_res_230_ = lp_proofEnvironment_OCMEnvironment_requireKnownPrimitives(v_constants_228_, v_registry_229_);
lean_dec_ref(v_registry_229_);
lean_dec_ref(v_constants_228_);
return v_res_230_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_proofEnvironment_OCMEnvironment_Prepare(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_proofEnvironment_OCMEnvironment_Registry(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_proofEnvironment_OCMEnvironment_Prepare(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
