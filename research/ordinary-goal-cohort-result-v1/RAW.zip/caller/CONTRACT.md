# Joined historical cohort native qualification caller

Status: source preparation only. No constructor, source index, native verifier, Library constructor or search was executed on the cohort. Root authorization is absent.

The sole proposed invocation uses the frozen historical 22-member cohort, the unchanged 1,806,915-byte base prefix and its prior exact 4,223-proof/100-axiom metadata. No heldout, goal evaluation, corpus selection, new candidate or newer 32-member cohort is an input.

`cohort_input.adapt` preserves every member's issued theorem label, original target, ordered essential statements, proof and physical variables. It verifies current floating declarations and orders them by source declaration span. All three must be mandatory in the target/essentials; the exact constructed native contract must agree. A/B/V members remain A/B/V. Unsupported frames refuse; the caller does not broaden the interface.

The unchanged `cohort_suffix.construct` checks source/member identities, transports only essential proof-label names to unique cohort-local names and verifies exact reconstructed source contracts. Independent claims are derived again from the original members and explicit renaming bindings. The original proposed suffix remains separately pinned and must reconstruct exactly; it is never overwritten or treated as a joined admission.

One unchanged `life_native.verify` call checks the complete base plus all 22 issued claims. Success requires the exact ordered list of 4,223 old proof labels followed by the 22 historical labels, the same complete 100-axiom contracts/raw identities and trust-label order, 22 current traces and the complete union of their current USED contracts. Original and transported source/proof/receipt identities remain distinct. No cohort theorem can occur in these admission proofs as a shortcut.

Only after current native success does the caller produce `LIBRARY-MANIFEST.json` in the existing `goal_library.Library` schema and instantiate that unchanged class for custody compatibility. The manifest includes the full ordered base/cohort proof identities, exact unchanged axiom inventory and stored native receipt hash. The artifact file records both canonical manifest and stored-file identities. A saved receipt supplies custody, not future proof authority.

Output is create-only at `qualification-01`. Intermediate member/transport/claim artifacts and the native wrapper's logs survive later failures. A wrapper invocation that fails to return leaves actual native-call count unresolved (`null`), never invented as zero. Failed or partial qualification returns `CANNOT_CHECK`; no retry or automatic interface repair is scheduled.

Use the existing GNU-time/timeout observation pattern described in `OBSERVATION-PLAN.json`. Main wall/CPU/RSS include main preflight through final custody, but exclude imports and final RESULT serialization; GNU time covers the complete Python process. Native and Library windows nest. RSS is cumulative process highwater. Caller/construction source-index counters describe completed stages; partial-stage internal work is not fully instrumented. Source hashing, serialization and all other work remain within the measured process windows, without an invented complete lifetime cost inventory or whole-standard-library byte freeze.

This proposed pass is current joined-library qualification only. It demonstrates neither method discovery, goal solving, causal learned-method consumption, search benefit, training-cost reduction nor lifetime benefit. The goal-only study is separate.
