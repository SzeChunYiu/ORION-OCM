# Joined-cohort caller — staged source

One proposed native pass will qualify the historical 22 ordinary lemma statements together with their 4,223-proof base and unchanged 100 axioms. It has not run.

- [Concrete contract](CONTRACT.md)
- [Request](RUN-REQUEST.json) and [existing observation plan](OBSERVATION-PLAN.json)
- [Source/input freeze](SOURCE-FREEZE.json), [reuse bindings](SOURCE-ORIGINS.json)

The source is ready for root/independent review. No execution gate is issued here. The original cohort and proposed suffix remain immutable; the accepted bridge constructor supplies explicit essential-label transport at execution. The resulting receipt is custody evidence, not automatic eligibility or future proof authority.
