# Minimal typed argument-hole adapter
## Existing seams to reuse
The exact paths/digests and function line ranges are in LOCAL-SOURCE-MAP.json.
- trace_context.validate binds a selected trace, source scope, contract spans and
  all used floating/essential contracts to the qualified native authority.
- typed_constructor.construct independently replays source stack/events and emits
  normal labels, within its three-parameter/no-DV/256-node scope.
- typed_emit.emit validates an admitted body and its exact typed recipe under an
  identity context. It does not support arbitrary composite substitution itself.
- trace_adapter supplies each node's output, ordered inputs and saved-reference
  producer. Use these native-observed witnesses; no expression parser is needed.
- life_native.verify already checks exact issued claims and actual proof bytes
  with the pinned native verifier. Its authority/count/context must be rebound
  for the actual library; its historical receipt cannot certify a new replacement.

dag.py:Node lacks outputs/contracts/source scopes. Its flattened steps and
label-only spine can remain diagnostics, but must not supply typed acceptance.
No new compressed-proof reader is needed: use the existing native trace transport.

## Prospective files and entry signatures
Two small modules, not a general framework:
1. hole_match.py: match(body, pattern_contracts, lemma_contract, target_trace,
   target_contracts, target_node, authority_context, work) -> disposition/bindings.
2. replacement.py: emit_one(target_trace, occurrence_path, binding, lemma_label,
   target_hypothesis_renaming, work) -> exact normal proof proposal.

Custody/source validation stays in the existing caller/trace layer. The adapter
takes validated immutable/detached objects and makes no global mutations.

## Matching procedure
1. Bind exact lemma label, six-field contract, admitted body/proof identity, library,
   native authority and parameter context. Require the body's external sequent to
   equal that contract. A saved accepted flag is insufficient.
2. Resolve saved-reference nodes through the source-checked producer identity.
   Match pattern apply nodes against target assertion nodes by exact assertion
   label and ordered arity. Match every floating and essential child port.
   Include logical $a and $p targets; do not silently restrict roots to $p.
3. A pattern float leaf binds its declared variable to target.output[1:] only when
   target.output[0] equals the declared type. Retain the target subtree as a syntax
   proof witness. Repeated appearances require equal type/token expressions,
   not identical target node IDs or identical proof derivations.
4. A pattern hole binds its slot to an entire target proof subtree. Keep ordered
   occurrences; do not descend through that argument or include its internal
   assertions in the pattern-label comparison.
5. After collecting all mandatory floating bindings, substitute exact token
   vectors into every pattern node output, each ordered essential premise and
   the conclusion. They must equal corresponding native target outputs exactly.
   A repeated essential slot must have the same instantiated statement; multiple
   valid proofs of that statement may witness it. Distinct equal-statement slots
   stay distinct. Choose first left-to-right witness per mandatory slot.
6. A supported mismatch returns NO_MATCH at this exact pattern/target node.
   Unsupported type/context, missing argument witness, malformed/unqualified
   graph, resource exhaustion or incomplete traversal returns UNKNOWN/CANNOT_CHECK,
   never a certified negative over all candidate patterns or target proofs.

## Initial explicit interface scope
Reuse three homogeneous wff or class pattern parameters and the existing
no-extra-floating/no-DV source boundary. Composite images and noninjective
ordinary substitutions are supported when existing target syntax subtrees witness
them. This deliberately differs from the older atomic-bijection recipe serving.
Do not force the recipe emitter to accept a composite renaming.

Require an explicit pattern float-leaf witness for every mandatory lemma float.
If a variable only appears inside an essential statement and no syntax witness
can be collected, return UNKNOWN_ARGUMENT_WITNESS_MISSING; do not invent a proof
or add a parser in this first adaptation.
Preserve the qualified 256 trace-node, 2–8 body-application and 4,096 normal-label
boundaries. A trace outside them is unsupported, not evidence of no use.
The current constructor rejects zero-premise assertion steps; do not silently
claim their transport is qualified by this adapter. That interface is separate.

Require lemma, target active context and all applied assertion DV sets empty in
the first qualification. With nonempty DV, return UNKNOWN_UNSUPPORTED_DV.
A later DV extension must use the exact native active variable set and all cross
pairs in substituted images, rejecting identical variables or missing active
pairs. The A/B/C-only or V0/V1/V2-only helper is not a general DV checker.

## Replacement and exact native boundary
Emit a functional copy of one chosen proof-tree occurrence, identified by ordered
child-port path. DAG sharing does not authorize replacing every occurrence of a
producer. Expand saved references with bounded ordinary postorder traversal.
At the selected path, emit each bound floating argument proof in the admitted
lemma's floating-hypothesis order, then each essential argument proof in its
essential order, then the admitted lemma label. Preserve repeated argument slots.
Other target occurrences and the original graph remain unchanged.

Recheck the replacement node's exact output before emitting the whole root.
Count distinct DAG nodes, emitted application occurrences and actual normal labels
separately; caching a node traversal cannot erase repeated proof costs.

The next native request must bind the original target sequent/context, exact new
normal proof bytes, renamed local hypotheses, current library and admitted lemma.
No invocation may trust the original proof's acceptance for the rewritten proof.
Prohibit original-target-label shortcuts and unissued labels. The admitted lemma
must be earlier, separately qualified training knowledge; no future-target graph
may select its acquisition.

The current life_native wrapper can be reused only for its exact three-parameter,
empty-DV, available floating-label envelope and a freshly bound extended prefix.
That prefix must include the admitted lemma with unchanged axioms and explicit
new theorem order. If the actual target cannot be issued in that envelope, stop
as an unsupported native interface; do not change its hypothesis/type/DV context.
A future wrapper adjustment needs source/native qualification of its own.

Proof refactoring establishes use in a supplied known proof after a fresh native
check. It does not establish autonomous search transfer, shorter cold search,
or useful acquisition. Record source-proof access explicitly and charge matching,
argument emission, whole-proof serialization and fresh verification.
