# Authored qualification plan — not executed
Use synthetic typed traces/contracts and independently written expected bindings
and normal proof token order. No retained or held-out theorem is a fixture here.
Run only after a separate implementation/qualification assignment on laptop Linux.

1. Composite argument: a float hole consumes a syntax proof with internal assertion
   steps, and an essential hole consumes a multi-step proof. Internal pattern
   assertions still match; expected replacement retains both whole arguments.
   This is the direct falsifier for flattened-label equality.
2. Repeated bindings: equal typed expressions with different proof trees match;
   a valid target with different expressions at one repeated pattern variable
   returns NO_MATCH_BINDING. Two different variables may share one legal image.
3. Exact essential obligation: a correct arity/label spine with an inconsistent
   instantiated essential statement does not match. Equal-statement distinct
   slots remain ordered; repeated use of a slot preserves argument occurrences.
4. Floating order: textual variable order differs from lemma floating order.
   Independently specified output must emit floating witnesses in contract order,
   then essential witnesses, then exactly one lemma label.
5. Kind/type boundary: valid logical $a and $p roots both match; a different
   assertion label or supported type mismatch is a local NO_MATCH. Unqualified
   trace/output metadata is CANNOT_CHECK, not a meaningful negative.
6. Native scope refusal: nonempty active/applied DV, extra floats or missing
   mandatory float witness returns explicit unsupported/UNKNOWN. No alphabet-only
   DV shortcut or negative type-membership conclusion is accepted.
7. Shared argument/path: one producer occurs at two tree paths; rewriting the
   selected path leaves the other intact. Expected emitted labels count repeated
   proof occurrences and every ordered argument.
8. Resource/custody: cycle/forward reference, changed contract/span/authority,
   stale admitted lemma, missing label, 256-node or 4,096-label overflow refuses.
   A clean already-in-scope case establishes the no-alarm branch.

A separately gated native phase would check one exact issued positive replacement
and wrong-hole/wrong-target/tampered-proof negatives at their issued claim labels,
with complete expected prefix verified. It would also check unchanged original
axiom inventory and declared earlier theorem order. Those native outcomes do not
exist yet, and this plan is not permission to run them.

Matcher status is local to one exact pattern/target occurrence. Enumerating all
supported occurrences, filtering proper subtrees or allowing multiple sequential
replacements requires a separately fixed scan/order/resource policy. No data-based
choice or post-result replacement policy is supplied here.
