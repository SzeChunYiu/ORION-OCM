# Argument-hole consumer design
Status: source/design only. No tests, proof data, matcher, native verifier,
corpus or learner were run.

Adopt REFACTOR's recursive argument-hole mechanism through a small independently
authored adapter over OCM's existing typed bodies and native trace nodes.
Do not import the donor module: it transitively imports torch, and inspected
metadata does not establish a clear license for transplanting its matcher.

The adapter compares internal assertion labels/ordered proof ports and binds
pattern floating/essential leaves to entire target proof subtrees. It then checks
one consistent typed substitution and every essential obligation before proposing
a replacement. Matching alone never establishes native acceptance or causal reuse.

[License/dependencies](DONOR-BOUNDARY.md) →
[concrete design](DESIGN.md) → [authored control plan](CONTROLS.md) →
[source identities](LOCAL-SOURCE-MAP.json).

The missing piece is a typed binding/replacement adapter, not another parser,
miner, theorem search engine or neural component. Existing syntax witnesses come
from the exact native target trace; unsupported witness/context cases stay UNKNOWN.
Current recipes' atomic-bijection restriction is not the ordinary theorem
instantiation rule: supported composite/repeated argument substitutions remain legal.

Implementation and native replacement qualification require separate assignments.
No claim follows about the other lane's 32 negatives or any unseen later proof.
The original flattened-match receipts and their scoped independent review remain
unchanged. This note establishes an implementation plan, not a new result.

Reference source downloads are internal reading copies only. Do not include the
references/ directory in a public source transplant before resolving its license.
