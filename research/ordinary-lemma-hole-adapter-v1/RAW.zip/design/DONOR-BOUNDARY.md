# REFACTOR source and dependency boundary
Pinned official repository: [jinpz/refactor at 7327ca7](https://github.com/jinpz/refactor/tree/7327ca79f59929d8f8e43b79daeade3a9a6d5aad).

## License evidence
The complete nontruncated recursive Git tree has 651 entries. Searching all blob
basenames for LICENSE, LICENCE, COPYING or NOTICE found none. This is a scoped
filename observation, not a claim about all possible permissions elsewhere.
The read README and theorem_refactor.py give no explicit license grant.

theorem_expansion.py lines 1–5 retain Raph Levien's 2002 mmverify copyright
and a GNU General Public License notice, without a version in that notice.
This is a concrete inherited file-level notice; it does not establish the terms
of every new REFACTOR file. Do not infer Apache/MIT terms from OCM or from a
different, newer mmverify release. Direct matcher copying/vendor approval remains
unresolved. No contact or permission request was sent.

Use the published matching mechanism as the design reference; write the narrow
adapter in OCM's existing representation and preserve attribution. Do not copy
the donor's source implementation or redistribute these reading copies pending
license resolution.

## Import boundary
theorem_refactor.py imports theorem_expansion with a wildcard and imports
export_single_new_theorem from theorem_verification. Those imports pull in:
- theorem_expansion: graphviz, numpy, sklearn, pandas, scipy plus standard library;
- theorem_verification: torch, data/model_names and the expansion module;
- utils, if used elsewhere: pytorch_lightning.

create_environment.sh requests Python 3.7, PyTorch 1.6.0, CUDA 10.1,
torch-geometric 1.7.0, graph packages and Lightning 0.10.0. It is a research
environment recipe, not a minimal lock for the recursive matcher.
No dependency was installed, imported or executed.

## Mechanism worth adapting
[match_theorem_current_node, lines 165–191](https://github.com/jinpz/refactor/blob/7327ca79f59929d8f8e43b79daeade3a9a6d5aad/theorem_refactor.py#L165)
recurses through assertion children and treats pattern floating/essential leaves
as holes accepting whole target subtrees. additional_check compares repeated
mandatory-variable expressions. refactor_proof_single rebuilds arguments in
mandatory floating then essential order. The donor later calls verify_custom;
its structural match itself is not a full type/essential/DV certificate.

The new adapter can retain that mechanism without the color-mutation fields,
wildcard imports, neural extraction, global sweep or broad environment.
All six downloaded source blobs match the official Git blob identities.
[Exact tree/source/import/read scope](UPSTREAM-SOURCE-MAP.json).
