# Argument-hole adapter: structural qualification
Status: eight authored controls passed once on laptop Linux. Independent source
review is pending. No retained proof, corpus, native verifier or learner ran.

Two independently authored modules bind whole target subtrees at pattern
floating/essential leaves and emit one selected occurrence with the lemma's
arguments in exact contract order. The matching code uses explicit typed outputs,
not a flattened assertion list. No REFACTOR code or neural dependency was copied.

[Interface](INTERFACE.md) → [controls/costs](QUALIFICATION.md) →
[source map](SOURCE-ORIGINS.json) → [raw process](qualification-01/PROCESS.json).

The reused constructor and recipe validator are exact source copies; the old
synthetic trace marker is not native authority. Every result explicitly says
native_acceptance=false. Caller-supplied identity descriptors detect invocation
mismatches; they are not checked native certificates or evidence-registry liveness.

A later caller must supply current qualified trace/library/admission bindings and
obtain an exact fresh native check of the emitted whole proof. This milestone
establishes authored structural behavior only, not actual later use, search
transfer, useful learning or absence of opportunities.
