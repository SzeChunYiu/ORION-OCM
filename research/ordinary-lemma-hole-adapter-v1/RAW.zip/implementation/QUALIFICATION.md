# Eight authored controls
All eight passed on the first run, with no old suite replay and no failing source
generation. The exact authored inputs are specified in authored_fixture.py and
the control statements; raw stdout/stderr, source snapshots and module/process
identities are retained under qualification-01. The receipt retains test outcomes;
it does not invent native receipts or claim a separate dump of every temporary
intermediate Python object.

1. Whole composite syntax/proof arguments defeat flattened-step equality while
   exact typed matching succeeds; a hand-written full replacement token list agrees.
2. Noninjective images and different syntax proofs of the same repeated variable
   match; inconsistent repeated-variable images return NO_MATCH.
3. Changed essential obligations and forged saved argument bindings refuse;
   distinct equal-statement essential slots remain separate and emit twice.
4. A lemma floating order different from textual order produces the independently
   specified normal proof order.
5. Logical $a and $p roots work; a different root is a local mismatch and a
   falsified typed trace is CANNOT_CHECK.
6. Active DV, extra floating context and missing mandatory syntax witnesses
   produce explicit UNKNOWN without pretending to check native validity.
7. One of two shared graph occurrences is replaced; the other stays expanded,
   the exact token list agrees and the original graph remains unchanged.
8. Stale lemma pins, graph errors, target-node bounds, expanded 4,096-label bounds
   and a wrong occurrence path refuse; a clean in-scope match still succeeds.

Actual child PID: 2446363; exit 0. Eight test methods passed.
Child wall: 0.0698490790 s; user CPU: 0.061700 s; system CPU: 0.007712 s.
Peak child RSS: 56,228 KiB. Measured qualifier window: 0.3747765160 s.
The child window is nested in the qualifier window and is not additive.
Qualifier timing includes source pinning/readback, excludes interpreter imports
and final receipt serialization. Authoring/review time is not measured as zero.

All 2,012 source/runtime pins match before/after; all 82 imported file modules
resolve to their pinned identities and declared source/standard-library paths.
No torch, REFACTOR, mmverify or native observer was imported. The exact copied
fixture carries its historical NATIVE_VERIFIED marker for structural replay;
no native invocation occurred and every adapter outcome retains native=false.
