# Distinct essential-slot control correction
The missing two-slot witness is now qualified by one new authored control.
Production modules and their typed validators are byte-identical to the original.
No original eight-control suite was replayed.

The original test checked repeated use of one slot; its summary overstated that
as coverage of two distinct equal-statement slots. Original files/receipts remain
unchanged. This successor adds two slots whose statements are equal but whose
proof arguments differ: one is the hypothesis itself, the other is a derived
argument proof. Independent node indices and the exact output token order agree;
swapping the saved argument binding is refused.

[New control](check_slots.py) → [actual inputs](qualification-01/INPUTS.json) →
[actual results](qualification-01/CONTROLS.json) →
[process/costs](qualification-01/PROCESS.json).

Current scope: eight original controls with that corrected interpretation plus
one added two-slot control. The new case passed once, without a native verifier,
retained proof or corpus call. Native acceptance remains false for every proposal.
The source and actual record still require independent closure of the review gap.
