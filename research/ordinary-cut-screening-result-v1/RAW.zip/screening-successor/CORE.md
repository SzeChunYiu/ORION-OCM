# Retained screening source: current entry

The separate screening interface is implemented and passes 14 authored controls.
It has not screened the 76 retained proposals or compiled their actual P1 grammar.

Read [CONTRACT.md](CONTRACT.md) for the unchanged population, parent, resources and
UNKNOWN boundary. [QUALIFICATION.json](QUALIFICATION.json) binds the synthetic results.
[SOURCE-ORIGINS.json](SOURCE-ORIGINS.json) distinguishes exact donors from the small glue.

[REQUEST-DRAFT.json](REQUEST-DRAFT.json) binds the original result, full 4,323-contract
P1 and original cost receipts. Gate, outer observer and final source review are absent.
A separate root decision is required for the once-only screening run.

No original parser, control or opportunity record was edited. Alias proof readiness
remains separate from native admission, acquisition, utility and novelty.
