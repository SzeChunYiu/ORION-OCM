# Input, output and remaining scope

goal_library.Library consumes exact base/joined bytes, an independently pinned
manifest, and independently pinned cohort-receipt bytes. It checks every ordered
proof record, contract/proof/raw identity, base preservation, exact cohort append
and identical axiom inventory. New floating declarations and private emitted-label
collisions refuse. Receipt bytes are custody, not interpreted proof authority.

goal_solve.solve takes exactly schema, query, ordered premises, typed context
and limits. Its separate mode is enabled, resident-disabled or restored.
There are three homogeneous class/wff parameters with empty DV. The accepted
typed_context functions normalize resident hint variables by indexed floating
order to the issued frame. Original contracts/proofs and grounding substitutions
are preserved. No historical labels or target outcomes choose the mapping.

The published bank policy remains goal syntax closure, all resident cohort
conclusions and issued premises. WFF_OPS selects subexpressions for this finite
bank; it is not a grammar admission whitelist. The accepted contract-derived
grammar/cache handles syntax membership and structurally replayed proof witnesses.
Unsupported syntax, construction, resource or materialization yields UNKNOWN.

Every arm constructs that same bank and grounds the same resident actions.
All grounded-action syntax images are materialized before cohort ablation.
The emission lookup is separate from the logical search bank, so these images
do not add search facts. No official-proof intermediates or label hits are inputs.

The complete source-bound ordinary inventory is retained. The current finite
action interface supports empty-DV, logical-essential contracts with class/wff
mandatory types. Other logical rows are reported explicitly; a failed search
with them returns UNKNOWN_PARENT_SCOPE. A complete supported failure means only
no proof in the registered finite bank and tree-decision bound, not global
underivability. The current enabled_cohort concept is nominal arm eligibility;
actual grounded actions and consumed proof labels are recorded separately.

goal_native prepares a fresh claim from the exact emitted-result pin and checks
issued goal/premises, labels and current joined prefix. It calls unchanged
life_native.verify, then binds archived request/result/suffix/database/log,
full ordered replay, unchanged trust and complete current USED contracts.
A saved native flag is insufficient. Rejection counts at the issued claim only
after the complete expected prefix. Cohort consumption is recomputed from exact
proof labels and current native USED labels, with disabled-arm refusal at both
preparation and acceptance.

The existing wrapper additionally checks that the three parameters exactly match
the native mandatory frame, no extra used floats/DV, and at most 256 trace nodes.
A generated proof may still fail that boundary: pending-native is not native
success. Existing syntax domains remain 512 tokens / 4096 proof labels.

cohort_suffix.construct takes a pinned ordered member packet and pinned base.
It deterministically replaces only each member's scoped essential labels with
cohort-e-INDEX-SLOT, including their normal-proof occurrences. Collisions refuse.
Statements, floating order/types, theorem labels and empty DV remain exact.
The original member/contract/proof/origin and transported contract/proof/source
identities are recorded. Inputs remain unchanged; no saved flag is promoted.
The constructor does not read the historical cohort or natively admit its output.

## Remaining integration

1. Independent source acceptance of this bridge and authored records.
2. Bind one exact versioned cohort/receipt and any scoped transport map; no union
   of historical 22 and a newer 32. No member rows were read here.
3. Freshly qualify every ordered P1+C proof under unchanged current axiom authority.
   Selected-claim or old 96-axiom receipts do not replace the joined authority.
4. Register a goal-only allocation and dependency/exposure exclusions before tasks.
5. Bind the concrete isolated caller, mode, exact resource limits, sources/runtime
   and create-only output paths to one reviewed invocation.

No actual experiment entry/request/gate is supplied by this source qualification.
The future caller should reuse existing ordinary process observation.

Library rows and manifest still decode the complete detached JSON snapshot.
Counts, bytes and decoding wall are explicit. A safe immutable view is a concrete
later serving optimization, not a claim made by this source result.
