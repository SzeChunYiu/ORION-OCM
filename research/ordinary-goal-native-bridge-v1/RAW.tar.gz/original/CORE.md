# Ordinary goal → native bridge

Status: authored interface controls passed; independent source review pending.
No native verifier, retained cohort, held-out task, corpus scan or scientific trial ran.

The solver receives an issued goal, ordered premises, three typed parameters and
resource limits. It receives no target proof, trace, label or expected proof stream.
It retains the existing finite-bank derivation, supplies qualified syntax witnesses
to the existing emitter, and prepares a fresh claim from the complete generated proof.

- [Contract and remaining boundary](CONTRACT.md)
- [Source reuse](SOURCE.md)
- [Authored qualification and costs](QUALIFICATION.md)
- [Prospective request](PROSPECTIVE-REQUEST.json)
- [Current source freeze](SOURCE-FREEZE.json)
- [Historical source generations](history/)
- [Accepted programme decision](inputs/ORDINARY_GOAL_SEARCH_NEXT.md)

All arms retain the same bank, resident grounding and syntax materialization.
Disabling the cohort removes executable actions while retaining preparation work.
The restored authored arm reproduces the enabled proof. This is engineering
qualification, not acquisition or scientific utility evidence.

The joined library binds all ordered base/cohort proofs and unchanged axioms.
A saved admission flag grants no authority. Actual cohort ingestion, fresh joined
native verification and goal-only allocation remain separately unqualified.

Resident syntax hints normalize each indexed formal frame to the issued frame;
the actual lemma contracts, proof bodies and finite-engine substitutions remain
unchanged. A separate scoped suffix constructor only renames essential proof
labels, preserving statements, types and DV with explicit original/new bindings.
The historical 22-member cohort has not been opened here.
