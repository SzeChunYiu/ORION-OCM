# Source reuse

SOURCE-ORIGINS.json binds original files and copied source.
SOURCE-FREEZE.json binds the current implementation and runtime.

- goal_library: ordered joined source/receipt custody and view-cost accounting.
- goal_solve: goal-only finite search, normalized hints and complete proof emission.
- goal_native: fresh claim and current native acceptance/consumption binding.
- cohort_suffix: scoped essential-label-only transport with original/new identities.
- finite_search: existing grounding/search/emitter; optional syntax callback
  and parameter floating-label classification are the only donor edits.
- native_match: optional callback at the existing type-check site; unchanged
  token partitioning and premise/substitution semantics.
- bank_policy: AST-identical published functions/constants. The donor parser
  monkeypatch, old allocation and summary-only result path are not imported.
- Seven accepted syntax/cache/work/context modules are unchanged. The existing
  pinned 46-file Lark runtime is reused; no parser extension or neural dependency.
- Native wrapper, source index, trace adapter and verifier are unchanged. Existing
  native result-binding functions retain their AST; only imports are redirected
  to equivalent identity/require helpers.
- qualify variants adapt the preceding caller's Popen/wait4 recorder: entry,
  expected count and complete import/runtime pins only. No observer framework.

The exact MIT verifier license is in vendor/mmverify.LICENSE.
Current source includes narrow preserved successors for finite-wall/consumption
checks, view accounting, private-label refusal and two typed/scoped transports.
Historical control suites were not replayed to qualify these changes.
