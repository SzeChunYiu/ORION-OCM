
$c wff |- ( ) /\ -> $.
$v ph ps ch $.
wph $f wff ph $.
wps $f wff ps $.
wch $f wff ch $.
wa $a wff ( ph /\ ps ) $.
wi $a wff ( ph -> ps ) $.
${
pair-h $e |- ph $.
ax-pair $a |- ( ph /\ ch ) $.
base-pair $p |- ( ph /\ ch ) $= wph wch pair-h ax-pair $.
$}
${
wrap-h $e |- ( ph /\ ch ) $.
ax-wrap $a |- ( ps -> ( ph /\ ch ) ) $.
$}


${
cut-h $e |- ph $.
learned-cut $p |- ( ps -> ( ph /\ ch ) ) $= wph wps wch wph wch cut-h ax-pair ax-wrap $.
$}
