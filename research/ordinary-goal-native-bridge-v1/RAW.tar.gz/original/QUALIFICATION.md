# Authored qualification

Every retained fresh process passed, with zero native calls and no retained data.

| Generation | Controls | PID | Child wall (s) |
|---|---:|---:|---:|
| qualification-01 | 8 | 2643702 | 0.144272769 |
| qualification-02 | 1 | 2648252 | 0.097884402 |
| qualification-03 | 1 | 2652593 | 0.023756702 |
| qualification-04 | 2 | 2667710 | 0.105339142 |

The first eight controls cover exact enabled/disabled/restored proofs, identical
bank/grounding/syntax materialization, composite/repeated substitutions, rejection
of target-proof/oracle fields, ordered library/receipt/axiom custody, bounded
failure versus UNKNOWN, issued proof/target/hole bindings and context isolation.

The next control checks finite wall values, proof-derived consumption, disabled
refusal, wrong issued premise and full-view accounting. The next checks private
proof-label namespace refusal with a clean baseline. The final two check an
indexed A/B/V hint frame used in an A/B/C goal across all three arms, and two
authored members sharing a local essential label with exact deterministic transport.
Every expected proof stream and essential-label mapping is specified in the
authored control source. Previous source and control generations remain intact.

Receipts bind actual argv/cwd/Python and parent PID, all source/runtime pre/post
pins, and actual imported paths including finite-engine dynamic helpers. Native
imports are guarded and no verifier call occurs. Namespace-only controls do not
import the verifier wrapper or execute search.

Child Popen→reap wall/CPU/RSS cover each authored process. Qualifier windows include
pinning/readback but exclude initial imports and final receipt serialization.
Parent/child intervals are nested, not additive. Different qualification processes
are disjoint. These are engineering costs, not scientific timing results.

Solver costs retain cold grammar/cache preparation, every syntax request, actual
parse/emission, grounding/search and full proof construction. Repeated complete
library-view decoding counts/bytes/wall are explicit. Fine per-cohort attempted
action counts are not instrumented; grounded/eligible counts and exact consumed
proof labels are distinct. Wrapper costs/failures will be retained if it runs.
Outer bridge file-I/O bytes are not complete separately; its measured wall includes
those operations. No native cost is represented as though a call occurred.

Exact records: [QUALIFICATION.json](QUALIFICATION.json), [first](qualification-01/),
[second](qualification-02/), [third](qualification-03/), [transport](qualification-04/).
