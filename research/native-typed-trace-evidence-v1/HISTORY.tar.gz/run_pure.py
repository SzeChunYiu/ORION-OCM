from pathlib import Path
import json,subprocess,resource,time,os,sys,hashlib
root=Path(__file__).resolve().parent
generation=sys.argv[1]
out=root/("pure-"+generation);out.mkdir(exist_ok=False)
module=root/"worktree/research/native-typed-trace-v1"
python="/home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11"
bootstrap="import sys;sys.path[:0]=["+repr(str(module))+",'/home/billy/orion-director-work/20260908/native-ocm-integration-v1/venv/lib/python3.11/site-packages'];import pytest;raise SystemExit(pytest.main(['-c','/dev/null','-q','-p','no:cacheprovider',"+repr(str(module))+",'--junitxml="+str(out/"tests.xml")+"']))"
argv=[python,"-I","-S","-B","-c",bootstrap]
env=dict(os.environ,TYPED_ENGINEERING_RECEIPT=str(out/"RECEIPT.json"))
start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (out/"stdout.log").open("w") as stdout,(out/"stderr.log").open("w") as stderr:
 child=subprocess.Popen(argv,cwd=root,env=env,stdout=stdout,stderr=stderr);pid=child.pid;code=child.wait()
after=resource.getrusage(resource.RUSAGE_CHILDREN)
record={"argv":argv,"pid":pid,"parent_pid":os.getpid(),"exit":code,"wall_s":time.monotonic()-start,
        "cpu_user_s":after.ru_utime-before.ru_utime,"cpu_system_s":after.ru_stime-before.ru_stime,
        "maxrss_kib":after.ru_maxrss,"python_sha256":hashlib.sha256(Path(python).read_bytes()).hexdigest()}
(out/"PROCESS.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record));print((out/"stdout.log").read_text());print((out/"stderr.log").read_text())
raise SystemExit(code)
