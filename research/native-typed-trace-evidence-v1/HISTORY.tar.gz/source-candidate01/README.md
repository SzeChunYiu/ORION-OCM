# Typed native trace research seam

This successor qualifies typed extraction and reconstruction interfaces. Read
[the contract](CONTRACT.md). It is separate from the class-only native serving module
and does not inherit its native outcomes. Current work is pure source/fixture
engineering; actual native acquisition and reconstruction remain gated on independent
source review. No protected corpus, wider bank or new grammar is included.
