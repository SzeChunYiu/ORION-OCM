"""Alias-domain syntax uses the existing class and Boolean parsers."""
from vendor import bridge_syntax as boolean
from vendor import legacy_class_terms as legacy
from typed_context import IDS, require


def checker(parameters):
    require(type(parameters) is list and len(parameters)==3, "typed grammar parameters")
    require([r.get("id") for r in parameters]==list(IDS) and
            len({r.get("type") for r in parameters})==1, "typed grammar identities")
    kind=parameters[0]["type"]
    require(kind in ("wff","class"), "typed grammar type")
    types={key:kind for key in IDS}
    def syntax(wanted,tokens):
        require(type(tokens) is list and 0<len(tokens)<=512 and
                all(type(t) is str for t in tokens), "typed ground vector")
        if kind=="class":
            legacy.syntax(wanted,[dict(zip(IDS,legacy.ATOMS)).get(t,t) for t in tokens])
        else:
            require(wanted=="wff", "no ground inhabitant of requested type")
            # A wrapper exposes exactly the unchanged parser's wff-expression grammar.
            boolean.parse(["|-","("]+tokens+["->",IDS[0],")"],types)
        return True
    return syntax
