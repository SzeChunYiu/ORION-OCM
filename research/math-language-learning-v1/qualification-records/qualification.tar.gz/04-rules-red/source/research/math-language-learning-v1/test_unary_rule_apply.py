"""Use a mined method on a larger Boolean context without re-solving its query."""
import pytest
from unary_contract import InputRefused
from unary_solver import RegionSolver
from unary_verify import verify_result
from learning_test_support import api, training, pred, s, task, rule

def test_mined_schema_substitution_constructs_verified_certificate(monkeypatch):
    rules=api("unary_rule_acquire").acquire([training("B"),training("C")])["rules"]
    left=["or",pred("X"),pred("W")]
    t=task([s("every",left,"Y"),s("no","Y","Z"),s("some","Y","Y")],s("some",left,"Z"))
    engine=RegionSolver(t["predicates"]);p=engine.prepare(t)
    def forbidden(*a,**k):raise AssertionError("query was solved")
    monkeypatch.setattr(engine,"solve",forbidden);monkeypatch.setattr(engine,"complete",forbidden)
    proposals=[api("unary_rule_apply").apply_rule(x["rule"],t,engine,p) for x in rules]
    hits=[x for x in proposals if x["terminal"]=="PROPOSED"]
    assert hits
    for hit in hits:
        assert hit["cover"]==[0,1] and verify_result(t,hit["result"])
        assert hit["result"]["status"]=="CONTRADICTED"
        assert hit["counters"]["recipes_applied"]==1
        assert hit["counters"]["matching_nodes"]>0 and hit["counters"]["key_nodes"]>0

def test_missing_used_support_does_not_apply_rule():
    t=task([s("every","A","B"),s("some","B","C")],s("no","A","C"))
    e=RegionSolver(t["predicates"]);p=e.prepare(t)
    r=api("unary_rule_apply").apply_rule(rule(),t,e,p)
    assert r["terminal"]=="NO_MATCH" and r["counters"]["recipes_applied"]==0

def test_inconsistent_base_is_not_explosive_method_use():
    t=task([s("some","A","B"),s("no","A","B")],s("no","A","C"))
    e=RegionSolver(t["predicates"]);p=e.prepare(t)
    r=api("unary_rule_apply").apply_rule(rule(),t,e,p)
    assert r["terminal"]=="INCONSISTENT_BASE" and r["counters"]["recipes_applied"]==0

def test_changed_task_cannot_reuse_prepared_binding():
    t=training()["task"];e=RegionSolver(t["predicates"]);p=e.prepare(t)
    t["premises"].pop()
    with pytest.raises(InputRefused):api("unary_rule_apply").apply_rule(rule(),t,e,p)
