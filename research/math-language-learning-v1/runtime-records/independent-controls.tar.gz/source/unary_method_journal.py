"""Use receipts bind actual core events; historical checking is not current liveness."""
from unary_contract import InputRefused,fields
from unary_method_check import check_packet
import unary_method_data as D

def validate_receipt(store,body):
    fields(body,("schema","sources_sha256","qid","request","receipt","core_events"))
    if body["schema"]!="ocm.unary-method.use.v1" or body["sources_sha256"]!=store.source_sha:
        raise InputRefused("USE_SOURCE")
    receipt=body["receipt"]
    fields(receipt,("terminal","qid","trace","check","packet","dispatches","checks","solve_wall_s","backend_failure"))
    if (receipt["backend_failure"] is not None or receipt["terminal"]!="CHECKED" or receipt["qid"]!=body["qid"] or
        type(receipt["dispatches"]) is not int or receipt["dispatches"]!=1 or
        type(receipt["checks"]) is not int or receipt["checks"]!=1):raise InputRefused("USE_EXECUTION")
    stages=receipt["trace"]["stages"]
    if not stages or stages[-1]["stage"]!="COMMITMENT" or stages[-1]["status"]!="PASS":
        raise InputRefused("USE_COMMITMENT")
    if receipt["check"]["status"]!="PASS":raise InputRefused("USE_CHECK")
    events=store.rt.events;refs=body["core_events"]
    if type(refs) is not list or len(refs)!=5:raise InputRefused("USE_CORE_EVENTS")
    selected=[]
    for ref in refs:
        fields(ref,("sequence","hash"))
        i=ref["sequence"]
        if type(i) is not int or not 1<=i<=len(events):raise InputRefused("USE_CORE_SEQUENCE")
        ev=events[i-1]
        if ev.sequence!=i or ev.event_hash!=ref["hash"]:raise InputRefused("USE_CORE_HASH")
        selected.append(ev)
    if [x.event_type.value for x in selected]!=["QUERY_OPENED","NAVIGATION","EXTRACTION","CANDIDATE_COMPOSED","CHECKER_RESULT"]:
        raise InputRefused("USE_CORE_KINDS")
    if [x.sequence for x in selected]!=list(range(selected[0].sequence,selected[0].sequence+5)):
        raise InputRefused("USE_CORE_INTERVAL")
    if selected[0].payload["task_id"]!=body["qid"] or selected[-1].status.value!="PASS":
        raise InputRefused("USE_CORE_QUERY")
    actual=[s for s in stages if s["stage"] in ("NAVIGATION","EXTRACTION","COMPOSITION","CHECK")]
    if len(actual)!=4:raise InputRefused("USE_TRACE")
    for ev,stage in zip(selected[1:],actual):
        if D.raw(dict(ev.payload))!=D.raw({**stage,"admitted":False}):raise InputRefused("USE_TRACE_BINDING")
    check_packet(store,body["qid"],body["request"],receipt["packet"],current=False,work=store.work)
    return body

def record_use(store,qid,request,receipt):
    events=store.rt.events[-5:]
    body={"schema":"ocm.unary-method.use.v1","sources_sha256":store.source_sha,"qid":qid,
          "request":request,"receipt":receipt,
          "core_events":[{"sequence":e.sequence,"hash":e.event_hash} for e in events]}
    body=D.parse(D.raw(body));validate_receipt(store,body)
    if any(old["qid"]==qid for old in store.uses):raise InputRefused("DUPLICATE_USE")
    store._append("USE",body);store.uses.append(body)
