from pathlib import Path
import sys,json,hashlib,time,resource
root=Path('/home/billy/orion-director-work/20260907/ocm-unary-runtime')
for p in [root/'src',root/'research/math-language-v1',root/'research/math-language-learning-v1']:sys.path.insert(0,str(p))
out=Path('/home/billy/orion-director-work/20260907/unary-runtime-independent-controls-v1')
out.mkdir(exist_ok=False)
files=sorted((root/'research/math-language-learning-v1').glob('unary_method_*.py'))
def snap():
 return {str(p.relative_to(root)):{'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
before=snap()
for p in files:
 q=out/'source'/p.name;q.parent.mkdir(exist_ok=True);q.write_bytes(p.read_bytes())
from ocm.runtime.ocm_runtime import OCMRuntime
from unary_method_store import MethodStore
from unary_method_runtime import MethodRuntime
from learning_test_support import training
from test_unary_method_runtime import fresh
results=[]
start=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_SELF)
for label,fail in [('clean',False),('use_append_failure',True)]:
 rt=OCMRuntime(out/'cases'/label/'store');store=MethodStore(rt,create=True)
 store.acquire([training('B'),training('C')]);bridge=MethodRuntime(store)
 old=store.journal.append
 def append(kind,payload,**kwargs):
  if kind=='USE':raise OSError('AUTHORED_USE_APPEND_FAILURE')
  return old(kind,payload,**kwargs)
 if fail:store.journal.append=append
 error=None;receipt=None
 try:receipt=bridge.solve(fresh())
 except Exception as e:error=type(e).__name__+': '+str(e)
 events=[{'type':e.event_type.value,'status':e.status.value,'sequence':e.sequence,'hash':e.event_hash,'payload':dict(e.payload)} for e in rt.events]
 restored_error=None;restored=None
 try:restored=MethodStore(OCMRuntime(rt.root))
 except Exception as e:restored_error=type(e).__name__+': '+str(e)
 row={'case':label,'solve_error':error,'receipt':receipt,'core_events':events,'core_last_checker':events[-1] if events else None,'live_use_count':len(store.uses),'cold_restore_error':restored_error,'cold_uses':None if restored is None else len(restored.uses),'cold_methods':None if restored is None else restored.method_ids}
 results.append(row)
 (out/(label+'.json')).write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
assert results[0]['receipt']['terminal']=='CHECKED'
assert results[0]['cold_uses']==1 and results[0]['cold_restore_error'] is None
bad=results[1]
assert bad['solve_error']=='OSError: AUTHORED_USE_APPEND_FAILURE'
assert bad['core_last_checker']['type']=='CHECKER_RESULT' and bad['core_last_checker']['status']=='PASS'
assert bad['cold_uses']==0 and bad['cold_restore_error'] is None and bad['cold_methods']
after=snap();assert before==after
report={'terminal':'CONFIRMED_COMMITTED_WORK_MISSING_FROM_COLD_USE_HISTORY','sources_before':before,'sources_after':after,'clean':{'checked':True,'cold_uses':1},'fault':{'core_last_checker':'PASS','actual_backend_dispatches':bridge.dispatches,'actual_checker_calls':bridge.checks,'use_append_exception':bad['solve_error'],'cold_restore':'SUCCESS_WITH_ZERO_USES'},'wall_s':time.monotonic()-start,'cpu_self_user_s':resource.getrusage(resource.RUSAGE_SELF).ru_utime-cpu.ru_utime,'cpu_self_system_s':resource.getrusage(resource.RUSAGE_SELF).ru_stime-cpu.ru_stime,'scope':'Two authored engineering fixture runs on billy; not registered data, performance or scientific study. Original source untouched.'}
(out/'RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'path':str(out/'RESULT.json'),'sha256':hashlib.sha256((out/'RESULT.json').read_bytes()).hexdigest(),'bytes':(out/'RESULT.json').stat().st_size,'result':report['terminal'],'clean_uses':1,'fault_uses':0,'wall_s':report['wall_s']},indent=2))
