from pathlib import Path
import hashlib,json,os,stat,xml.etree.ElementTree as ET
BASE=Path('/home/billy/orion-director-work/20260907')
RAW=BASE/'unary-runtime-profile-qualification-v1'
OLD=BASE/'unary-runtime-qualification-v1'
WT=BASE/'ocm-unary-runtime'
OUT=BASE/'unary-runtime-profile-independent-review-v1'
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(p.read_bytes())
def inventory(root):
 files={};links={}
 def bad(e):raise e
 for base,dirs,names in os.walk(str(root),followlinks=False,onerror=bad):
  for n in dirs+names:
   p=Path(base)/n;m=p.lstat().st_mode;r=str(p.relative_to(root))
   if stat.S_ISLNK(m):links[r]=os.readlink(str(p))
   elif stat.S_ISREG(m):files[r]=ident(p)
   elif not stat.S_ISDIR(m):raise ValueError(r)
 return files,links
sid=ident(RAW/'SUMMARY.json');assert sid['sha256']=='d4541e1046af6df87ece218eed00fe29ed39d8d7a5ac41b4d554dbe1307a48d6'
s=load(RAW/'SUMMARY.json');files,links=inventory(RAW);assert files.pop('SUMMARY.json')==sid
assert files==s['files'] and links==s['symlinks'] and len(files)==940 and len(links)==40
assert sum(x['bytes'] for x in files.values())==9974032
old=load(OLD/'SUMMARY.json');oldid=ident(OLD/'SUMMARY.json')
assert oldid['sha256']=='8473700e87b10f2c9e9fae9181c279940f10d7515ff653aeec59f8fff9e28415'
oldfiles,oldlinks=inventory(OLD);assert oldfiles==dict(old['files'],**{'SUMMARY.json':oldid})
final=RAW/'21-combined';freeze=load(final/'SOURCE-BEFORE.json')
assert ident(final/'SOURCE-BEFORE.json')==s['final_source_freeze'] and len(freeze)==213
assert freeze==load(final/'SOURCE-AFTER.json')
for n,r in freeze.items():assert ident(final/'source'/n)==ident(WT/n)==r,n
previous=load(OLD/'18-combined/SOURCE-BEFORE.json')
changed={n:r for n,r in freeze.items() if previous.get(n)!=r}
assert {Path(n).name for n in changed}=={'unary_method_profile.py','unary_method_process.py','unary_method_episode.py','test_unary_method_profile.py','test_unary_method_process.py','test_unary_method_restart.py'}
hist=[]
for h in s['history']:
 d=RAW/h['directory'];p=load(d/'PROCESS.json');q=load(d/'REQUEST.json')
 assert p==h['process'] and p['argv']==q['argv'] and p['source_unchanged'] is True and p['reaped'] is True
 assert q['environment_overrides']['PYTHONDONTWRITEBYTECODE']=='1'
 f=load(d/'SOURCE-BEFORE.json');assert f==load(d/'SOURCE-AFTER.json')
 for n,r in f.items():assert ident(d/'source'/n)==r
 for n in ('stdout','stderr'):assert ident(d/(n+'.log'))==p[n]
 t=ET.parse(str(d/'tests.xml'));suites=list(t.getroot().iter('testsuite'))
 counts={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
 assert counts=={k:h[k] for k in counts} and len(list(t.getroot().iter('testcase')))==counts['tests']
 hist.append({'directory':h['directory'],'counts':counts,'process':ident(d/'PROCESS.json'),'xml':ident(d/'tests.xml'),'returncode':p['returncode'],'outer_wall_s':p['outer_wall_s']})
assert hist[-1]['counts']==dict(tests=213,failures=0,errors=0,skipped=0)
assert sum(x['outer_wall_s'] for x in hist)==s['recorded_test_outer_wall_s']
relocation=load(RAW/'RELOCATION.json')
for row in relocation['records']:
 dest=Path(row['retained_directory']);m,_=inventory(dest)
 assert {k:v['sha256'] for k,v in m.items()}==row['regular_file_sha256']
 q=load(dest/'REQUEST.json');origin=row['original_execution_directory']
 assert '--basetemp='+origin+'/cases' in q['argv'] and '--junitxml='+origin+'/tests.xml' in q['argv']
 assert not Path(origin).exists()
abcroot=final/'cases/test_real_acquisition_exit_res0';abc={};results={};last=0
for label in 'ABC':
 d=abcroot/label;p=load(d/'PROCESS.json');r=load(d/'result.json');q=load(d/'request.json')
 assert p['profile']==r['profile'] and p['profile']['version']=='3.11.14'
 assert p['argv'][0]==p['profile']['executable'] and p['argv'][1:4]==['-I','-S','-B']
 assert json.loads(p['environment']['OCM_UNARY_PYTHON_PROFILE'])==p['profile']
 assert set(p['environment'])=={'LANG','PATH','OCM_UNARY_PYTHON_PROFILE'}
 assert p['python']==p['python_after']==r['python']
 for k in ('request','result','stdout','stderr','entry','python'):
  assert ident(Path(p[k]['path']))=={a:p[k][a] for a in ('bytes','sha256')}
 assert p['profile']['sha256']==p['python']['sha256']
 assert p['terminal']==r['terminal']=='COMPLETED' and p['returncode']==0
 assert p['error'] is None and p['postcheck_error'] is None and p['reaped'] is True and p['group_absent'] is True
 assert not Path('/proc',str(p['pid'])).exists() and p['pid']==r['pid']
 assert p['started_monotonic']>last;last=p['ended_monotonic']
 assert r['flags']==dict(dont_write_bytecode=1,isolated=1,no_site=1) and r['callbacks_on_restore']==0
 assert p['source_before']==p['source_after']==r['source_before']==r['source_after']
 for n,h in p['source_before'].items():assert freeze[n]['sha256']==h
 assert (d/'result.json').read_bytes()==(d/'stdout.bin').read_bytes() and (d/'stderr.bin').read_bytes()==b''
 assert r['input_sha256']==ident(d/'request.json')['sha256']
 for n,v in r['imports'].items():
  assert ident(Path(v['path']))=={k:v[k] for k in ('bytes','sha256')}
  assert 'site-packages' not in v['path'] and 'learning_test_support' not in n
 assert len(r['imports'])==126 and 'unary_method_profile' in r['imports']
 if label=='A':assert set(q)=={'store','training'} and len(q['training'])==2
 else:
  assert set(q)=={'store','task','invoke'} and q['invoke']==(label=='B')
  o=r['outcome'];assert o['terminal']=='CHECKED' and o['dispatches']==o['checks']==1
  assert o['packet']['use']['recipes_applied']==int(label=='B')
  assert o['execution_observation']['parent_completions']==int(label=='C')
 results[label]=r
 abc[label]={'process':ident(d/'PROCESS.json'),'result':ident(d/'result.json'),'profile':p['profile'],'pid':p['pid'],'imports':len(r['imports']),'prior_uses':r['prior_uses'],'outer_wall_s':p['outer_wall_s']}
assert results['B']['outcome']['packet']['use']['method_id'] in results['A']['outcome']['method_ids']
assert results['C']['prior_uses']==1 and len({v['pid'] for v in abc.values()})==3
parent=final/'cases/test_parent_wrong_hash_refuses0/parent'
child=final/'cases/test_actual_child_checks_profi0/child'
p=load(parent/'PROCESS.json');c=load(child/'PROCESS.json');r=load(child/'result.json')
assert p['terminal']=='PROCESS_REFUSED' and p['pid'] is None and 'PYTHON_HASH' in p['error']
assert c['terminal']=='PROCESS_REFUSED' and c['returncode']==2 and c['reaped'] is True and c['group_absent'] is True
assert 'PYTHON_HASH' in r['reason'] and r['profile']['sha256']=='0'*64
docs={n:ident(WT/'research/math-language-learning-v1'/n) for n in ('RUNTIME-CONTRACT.md','RUNTIME-QUALIFICATION.md')}
assert inventory(RAW)==(dict(files,**{'SUMMARY.json':sid}),links)
assert inventory(OLD)[0]==oldfiles
record={'schema':'ocm.unary-runtime-profile.independent-review.v1','terminal':'SCOPED_REVIEW_PASS','scope':'Read-only review of strict interpreter profile, launcher and fixed child entry plus three affected test modules; retained byte/source/process/XML audit. No tests or runtime/scientific dispatch by reviewer.','summary':{'path':str(RAW/'SUMMARY.json'),**sid},'source_freeze':{'path':str(final/'SOURCE-BEFORE.json'),**s['final_source_freeze'],'current_and_snapshot_sources':213,'all_equal':True},'reviewed_successor_sources':changed,'postrun_docs':docs,'raw_inventory':{'regular_members_excluding_summary':940,'bytes':9974032,'symlink_metadata':40,'links_not_followed':True},'histories':hist,'relocation':{'record':ident(RAW/'RELOCATION.json'),'original_absolute_paths_preserved':True,'both_recorded_regular_sets_match':True,'dangling_original_pytest_aliases_retained_as_metadata':True},'historical_preservation':{'summary':oldid,'regular_members_including_summary':len(oldfiles),'exact_prior_member_set_and_bytes_unchanged':True,'review_sha256':'718cd126ee93e700abc4ad883545212cf64d1e951165807a13374f1b1eb107ae'},'ABC':abc,'negative_controls':{'parent_prelaunch_refusal':ident(parent/'PROCESS.json'),'child_independent_refusal':ident(child/'PROCESS.json'),'child_result':ident(child/'result.json')},'source_review':['Profile is exact plain data before operations; schema/path/hash/version are constrained. Canonical resolved absolute executable disallows path aliases.','Old literal laptop path/hash remains the default; observe() is an explicit engineering input and grants no scientific authority.','Launch code fixes the entrypoint, isolation flags, import roots and environment keys; task and method data do not choose them.','Parent checks selected executable bytes before and after dispatch; child independently checks actual executable/hash/version/flags before task work and rechecks bytes afterward.','213-control current-interpreter restart retains actual mining, KSO admission, generic runtime dispatch, independent final checking and invocation-disabled fallback.','Both targeted and combined recorded runs disable bytecode generation; a clean hosted checkout is still necessary because cached project bytecode refuses.'],'findings':[],'limits':['No hosted CI execution was observed here; exact Python 3.11.14 is required in CI.','Observed path and file hashes are trusted-host engineering custody, not adversarial interpreter/runtime or full-host containment.','The unchanged method-learning and journal semantics inherit the separately bound historical source review; no registered scientific outcome or lifetime benefit is claimed.'],'cost_scope':{'three_recorded_pytest_outer_wall_s':s['recorded_test_outer_wall_s'],'final_pytest_outer_wall_s':hist[-1]['outer_wall_s'],'nested_child_costs_not_added':True}}
OUT.mkdir(exist_ok=False);out=OUT/'REVIEW.json';out.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(out),**ident(out),'source_count':213,'raw':940,'ABC_import_observations':378,'final_tests':213,'findings':[]}))
