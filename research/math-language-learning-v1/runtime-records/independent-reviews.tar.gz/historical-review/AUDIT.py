from pathlib import Path
import hashlib,json,os,stat,xml.etree.ElementTree as ET,subprocess
BASE=Path('/home/billy/orion-director-work/20260907')
RAW=BASE/'unary-runtime-qualification-v1'
WT=BASE/'ocm-unary-runtime'
OUT=BASE/'unary-runtime-independent-review-v1'
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(p.read_bytes())
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def inventory(root):
 files={};links={}
 for base,dirs,names in os.walk(str(root),followlinks=False,onerror=lambda e: (_ for _ in ()).throw(e)):
  for n in dirs+names:
   p=Path(base)/n;m=p.lstat().st_mode;r=str(p.relative_to(root))
   if stat.S_ISLNK(m):links[r]=os.readlink(str(p))
   elif stat.S_ISREG(m):files[r]=ident(p)
   elif not stat.S_ISDIR(m):raise ValueError('unsupported '+r)
 return files,links
summary_id=ident(RAW/'SUMMARY.json')
assert summary_id['sha256']=='8473700e87b10f2c9e9fae9181c279940f10d7515ff653aeec59f8fff9e28415'
s=load(RAW/'SUMMARY.json');files,links=inventory(RAW)
assert files.pop('SUMMARY.json')==summary_id
assert files==s['files'] and len(files)==4555
assert sum(x['bytes'] for x in files.values())==39801192
final=RAW/'18-combined';freeze=load(final/'SOURCE-BEFORE.json')
assert ident(final/'SOURCE-BEFORE.json')==s['final_source_freeze']
assert len(freeze)==211 and freeze==load(final/'SOURCE-AFTER.json')
current={};drift=[]
for name,rec in freeze.items():
 assert ident(final/'source'/name)==rec,name
 current[name]=ident(WT/name)
 if current[name]!=rec:drift.append(name)
hist=[]
for h in s['histories']:
 d=RAW/h['directory'];proc=load(d/'PROCESS.json');request=load(d/'REQUEST.json')
 assert proc==h['process'] and proc['argv']==request['argv']
 assert proc['source_unchanged'] is True and load(d/'SOURCE-BEFORE.json')==load(d/'SOURCE-AFTER.json')
 for n,r in load(d/'SOURCE-BEFORE.json').items():assert ident(d/'source'/n)==r
 for k in ('stdout','stderr'):assert ident(d/(k+'.log'))==proc[k]
 tree=ET.parse(str(d/'tests.xml'));suites=list(tree.getroot().iter('testsuite'))
 counts={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}
 assert counts=={k:h[k] for k in counts}
 assert len(list(tree.getroot().iter('testcase')))==counts['tests']
 assert proc['reaped'] is True
 hist.append(dict(directory=h['directory'],counts=counts,returncode=proc['returncode'],outer_wall_s=proc['outer_wall_s'],process=ident(d/'PROCESS.json'),xml=ident(d/'tests.xml')))
assert hist[-1]['counts']==dict(tests=206,failures=0,errors=0,skipped=0)
assert abs(sum(x['outer_wall_s'] for x in hist)-s['recorded_test_outer_wall_s'])<1e-10
abcroot=final/'cases/test_real_acquisition_exit_res0';abc={};results={};last_end=0
for label in 'ABC':
 d=abcroot/label;p=load(d/'PROCESS.json');r=load(d/'result.json');q=load(d/'request.json')
 for k in ('request','result','stdout','stderr','python','entry'):
  path=Path(p[k]['path']);assert ident(path)=={a:p[k][a] for a in ('bytes','sha256')},(label,k)
 assert p['returncode']==0 and p['terminal']=='COMPLETED' and p['error'] is None and p['postcheck_error'] is None
 assert p['reaped'] is True and p['group_absent'] is True and not Path('/proc',str(p['pid'])).exists()
 assert p['pid']==r['pid'] and p['argv'][1:4]==['-I','-S','-B'] and p['argv'][4:]==r['argv']
 assert r['flags']==dict(dont_write_bytecode=1,isolated=1,no_site=1) and r['callbacks_on_restore']==0
 assert r['terminal']=='COMPLETED' and r['input_sha256']==ident(d/'request.json')['sha256']
 assert (d/'result.json').read_bytes()==(d/'stdout.bin').read_bytes() and (d/'stderr.bin').read_bytes()==b''
 assert p['source_before']==p['source_after']==r['source_before']==r['source_after']
 for n,h in p['source_before'].items():assert freeze[n]['sha256']==h
 assert p['started_monotonic']>last_end;last_end=p['ended_monotonic']
 for n,rec in r['imports'].items():
  assert ident(Path(rec['path']))=={k:rec[k] for k in ('bytes','sha256')},n
  assert 'site-packages' not in rec['path'] and 'learning_test_support' not in n
 assert len(r['imports'])==125
 if label=='A':
  assert set(q)=={'store','training'} and len(q['training'])==2 and r['prior_uses']==0
 else:
  assert set(q)=={'store','task','invoke'} and q['invoke']==(label=='B')
  o=r['outcome'];assert o['terminal']=='CHECKED' and o['dispatches']==o['checks']==1
  assert o['check']['status']=='PASS' and o['packet']['result']['status']=='ENTAILED'
  assert any(x['stage']=='COMMITMENT' and x['status']=='PASS' for x in o['trace']['stages'])
  assert o['execution_observation']==o['packet']['execution']
  assert o['return_observation']['total_wall_s']>=o['solve_wall_s']+o['return_observation']['journal_wall_s']
 results[label]=r
 abc[label]={'process':ident(d/'PROCESS.json'),'result':ident(d/'result.json'),'pid':p['pid'],'imported_origins':125,'prior_uses':r['prior_uses'],'child_dispatch_wait_wall_s':p['outer_wall_s'],'outer_process_scope':p['scope']}
assert len({x['pid'] for x in abc.values()})==3
a=results['A']['outcome'];b=results['B']['outcome'];c=results['C']['outcome']
assert a['terminal']=='RULES_ACQUIRED' and len(a['method_ids'])==1
assert b['packet']['use']['method_id']==a['method_ids'][0] and b['packet']['use']['cover']==[0,1]
assert b['packet']['use']['recipes_applied']==1 and b['packet']['execution']['parent_completions']==0
assert c['packet']['use']['method_id'] is None and c['packet']['use']['recipes_applied']==0 and c['packet']['execution']['parent_completions']==1
assert results['C']['prior_uses']==1
ledgers={}
for rel in ('ledger.jsonl','unary-method-journal/ledger.jsonl'):
 p=abcroot/'stored'/rel;rows=[json.loads(z) for z in p.read_text().splitlines()];prev='0'*64
 for i,row in enumerate(rows):
  assert row['sequence']==i and row['prev_hash']==prev and digest({k:v for k,v in row.items() if k!='entry_hash'})==row['entry_hash']
  prev=row['entry_hash']
 ledgers[rel]={'file':ident(p),'rows':len(rows),'head':prev}
 if rel=='ledger.jsonl':events={x['payload']['sequence']:x['payload'] for x in rows if x['kind']=='OCM_EVENT'}
 else:issuer=rows
assert [x['kind'] for x in issuer]==['INIT','PREPARE','ISSUE','USE_PREPARE','USE','USE_PREPARE','USE']
for label,i in [('B',4),('C',6)]:
 use=issuer[i]['payload'];intent=issuer[i-1]['payload'];ret=results[label]['outcome'].copy();ret.pop('return_observation')
 assert use['receipt']==ret and use['intent_sha256']==digest(intent) and use['qid']==intent['qid']
 assert use['request']==intent['request']
 es=use['core_events'];assert es[0]['sequence']==intent['core_sequence']+1
 assert events[intent['core_sequence']]['event_hash']==intent['core_hash']
 for e in es:assert events[e['sequence']]['event_hash']==e['hash']
 assert [e['sequence'] for e in es]==list(range(es[0]['sequence'],es[-1]['sequence']+1))
for r in results.values():
 assert r['core_head'] in {e['event_hash'] for e in events.values()}
 assert r['issuer_head'] in {e['entry_hash'] for e in issuer}
runtime={n:r for n,r in freeze.items() if Path(n).name.startswith('unary_method_')}
docs={n:ident(WT/'research/math-language-learning-v1'/n) for n in ('RUNTIME-CONTRACT.md','RUNTIME-QUALIFICATION.md')}
assert ident(RAW/'SUMMARY.json')==summary_id
assert inventory(RAW)[0]==dict(files,**{'SUMMARY.json':summary_id})
record={'schema':'ocm.unary-runtime.independent-review.v1','terminal':'SCOPED_REVIEW_PASS','generation':'Historical 206-control runtime generation; prospective interpreter-profile portability successor requires separate review and qualification.','scope':'Read-only source review of eight runtime modules, six new test modules, scoped documentation, retained source/raw audit. No test or scientific run during this audit. Earlier authorized two-case orphan-use reproduction is separately retained.','summary':{'path':str(RAW/'SUMMARY.json'),**summary_id},'raw_inventory':{'files':4555,'bytes':39801192,'nonfollowed_pytest_symlink_aliases':len(links),'all_regular_bytes_rehashed':True},'source_freeze':{'path':str(final/'SOURCE-BEFORE.json'),**s['final_source_freeze'],'sources':211,'all_snapshots_rehashed':True,'current_source_drift_observed':drift},'reviewed_runtime_sources':runtime,'postrun_docs':docs,'histories':hist,'ABC':abc,'ABC_ledgers':ledgers,'observed_method':a['method_ids'][0],'checks':['Actual acquired data admitted to KSO and restored with no callbacks before generic dispatcher registration.','Independent schema correctness, discovery provenance, utility eligibility and final answer checking remain distinct.','Actual recipe is consumed in B; identical task with invocation disabled in C uses prepared exact fallback. This authored knockout is not an equally adaptive parent study.','USE_PREPARE precedes index/dispatch; paired core-commit/USE-append failure now refuses incomplete cold restoration.','Refused matcher retains known preparation/index/candidate work and marks unknown partial matcher work unavailable.','Post-child source observation failure preserves process return code, cleanup and raw records.','211 sources and eighteen historical test receipts are retained; raw labels do not replace their actual outcomes.'],'findings':[],'cost_scope':{'final_test_outer_wall_s':8.493122140993364,'all_recorded_test_outer_wall_s':s['recorded_test_outer_wall_s'],'do_not_sum_nested_spans':True,'limits':'Launcher child dispatch/wait excludes initial/final source hashing and receipt assembly. Runtime solve_wall_s is pre-journal; outside durable receipt return_observation spans journal return. No full host, aggregate RSS or complete development cost claim.'},'limitations':['Authored engineering behavior only; no registered training/evaluation study, broad generalization or measured lifetime advantage.','Finite rule language, authored utility policy and generic dispatcher; no new runtime code learned.','Source/import observations and trusted-host hash journals are not adversarial interpreter isolation or full-host neural exclusion.','Cold index construction, source checks, dense navigation, whole-ledger rewrite and full prepared-state binding remain visible costs.']}
OUT.mkdir(exist_ok=False)
(OUT/'REVIEW.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps({'record':str(OUT/'REVIEW.json'),**ident(OUT/'REVIEW.json'),'current_drift':drift,'final_counts':hist[-1]['counts'],'raw_count':len(files),'source_count':len(freeze),'aliases':len(links)}))
