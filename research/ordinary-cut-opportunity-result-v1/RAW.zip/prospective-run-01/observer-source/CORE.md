# Fixed opportunity observer

The concrete observer is [observe_opportunity.py](observe_opportunity.py).
It is ready for independent source review. No opportunity gate or audit was run.

[OBSERVER-CONTRACT.json](OBSERVER-CONTRACT.json) binds the unchanged request,
18 consumer sources, six input artifacts and two registry metadata dependencies.
[GATE-REQUIREMENTS.json](GATE-REQUIREMENTS.json) gives exact argv, runtime,
paths and the remaining root review bindings. A separate root gate is required.

The consumer keeps its original 60-second soft deadline and two million matcher
token states. The observer has a 180-second containment timeout, authorized by
root before this source was prepared. This does not change task selection,
candidate order, consumer algorithms or resource accounting.

[output_contract.py](output_contract.py) checks the emitted file inventory against
the retained RESULT. ENUMERATED, UNKNOWN_INTERFACE and TRACE_UNUSABLE rows require
their exact ROOT file. Resource-unreached and excluded rows do not emit ROOT files.
Every completed audit still records all 128 positions. A partial failure may have
a consistent inventory while remaining a failed audit. The complete P1 file is
hash-bound, without equating trace readiness or screening with native admission.

Nine authored controls passed and the exact isolated observer entry refused at
the absent gate. [Qualification](qualification-01/QUALIFICATION.json) binds the
retained child processes, logs and source identities. These controls opened no
native teaching data and invoked no extractor, alias screen, learner or audit.

The [donor map](DONOR-MAP.json) identifies the reviewed native-export observer.
Its process loop and cleanup block are copied exactly, including wait-error
cleanup, process-group kill, the exit/kill race and final reap. The three retained
donor process controls support that unchanged block; they are not relabelled as
new whole-observer tests. The changed output contract has its own authored tests.

The only substantive adaptations are the fixed opportunity pins/paths, additional
review/runtime bindings and status-based output validation. No general framework
or new mining algorithm was introduced. [SUCCESSOR.diff](SUCCESSOR.diff) preserves
the exact comparison to the copied donor source.

The observer imports its output helper after source checks. It starts the child
with the pinned isolated Python, a minimal environment and a fresh process session.
Prelaunch refusal occurs before START/PROCESS creation; the invoking root must
retain its outer stdout/stderr/exit, as the startup control does. After launch,
failures, partial files, exit/signal and cleanup costs remain in PROCESS.

The measured outer window begins at observer run entry and ends after output and
custody checks. Interpreter/import startup, preparation, review and final PROCESS
serialization are excluded explicitly. Child wall time is nested within that
window. No lifetime or performance benefit follows from this apparatus.
