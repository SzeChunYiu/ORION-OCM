# Opportunity observer source review

**Ready for a separate root gate. No concrete source blocker remains.**

[REVIEW.json](REVIEW.json) binds the exact source and retained qualification;
[BINDINGS.json](BINDINGS.json) records the byte readback.

The frozen observer matches the accepted consumer output contract: all 128
positions remain in a completed RESULT, only processed statuses require ROOT
files, and the complete P1 output is hash-bound. Partial failure cannot be
reported as completion. Native contract authority remains upstream.

The single-child wait/cleanup block is byte-identical to the previously reviewed
donor. Its three historical process controls are retained evidence, not new runs.
Nine retained authored checks comprise eight output controls and one source
comparison. The isolated missing-gate startup verifies refusal before helper
import or child launch. The accepted-gate whole observer has not executed.

All 60 observer capsule manifest entries, 18 consumer source identities and the
retained qualification/log bindings match. Required input/source pins reject
conflicts; runtime, reviews, gate and readable outputs receive custody records.
Root supplies the gate and accepted-review identities, and retains any prelaunch
stdout/stderr/exit. No gate was created by this review.

The original two-million token-state and 60-second soft bounds remain unchanged.
The outer process has 180-second containment. Recorded measurement excludes
startup, preparation/review and final receipt serialization; it is not lifetime
cost. No corpus/trace body was interpreted, no control was replayed, and no
native/export/extractor/cut/alias/learner or audit execution occurred here.
