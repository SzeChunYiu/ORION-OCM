# Prospective ordinary opportunity request

[REQUEST-PROSPECTIVE.json](REQUEST-PROSPECTIVE.json) now binds the exact exported
authority, full P1 and teaching packet. This is a prepared request, not permission
to execute. The native results still require independent review and root
acceptance. The legacy field name qualified_native_trace_authority does not
establish that acceptance.

[Input pins](INPUT-PINS.json) were checked by hashing bytes only. No native-export
JSON body, trace, proof, cut or alias result was decoded by this preparation.
Root reports 71 ready and 57 unusable traces across the same 128 source positions.
All 128 whole training theorems remain in the 4,323-contract P1 inventory:
4,095 P0 theorems, 128 released theorems and 100 prefix axiom declarations.
No ready subset replaces the registered population.

[Source requirements](SOURCE-REQUIREMENTS.json) retain the frozen v3 mechanism
and interface. The request keeps two million token states and the original
60-second soft deadline. No parameter, task, candidate order or bound was tuned
using native export outcomes. A three-node branch remains closed.

[Observer requirements](OBSERVER-REQUIREMENTS.json) specify exact argv, source
and input custody, create-only paths, failure retention and cost boundaries.
The observer source/review and separate root gate are not yet bound. The gate
file, observation directory and output directory have not been created.

The existing 18 authored transport controls are source qualification evidence.
They are not native packet interoperability or an opportunity result. Actual
constructor refusals and incomplete ordinary matching remain UNKNOWN; all
released whole theorems remain in the strongest ordinary P1 baseline.

This preparation changed only this new directory. Frozen consumer sources,
templates, release artifacts and the separate publication package remain intact.
