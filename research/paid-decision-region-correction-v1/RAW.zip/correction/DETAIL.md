# Bounded correction and evidence

The isolated source base is PR158 head 1f6a975b5921da4109dd2286ac030613a55e8261,
tree 21f8382bacfbb43b1fc3438f7ad5c861172ccd1a. Exact original files, source review
and the unresolved historical DEV6 reference are retained. Nothing is applied to
that branch. The existing donor workflow is unchanged and remains outside this
qualification; it would run simulations and a full sweep if separately invoked.

## Changes

`exact_numeric.py` extracts PR159's `_rational` and `_items` functions verbatim
from its qualified helper c0705b32.... `drd_model.py` snapshots/validates the
finite inputs. The DRD recursion uses Fraction costs and exact comparisons,
retaining its own worst-case min/max semantics. It does not substitute PR159's
expectation-based finite-allowance DP.

The accepted policy class is finite terminating decision trees. Nonnegative
probe costs are checked before uninformative probes are omitted; other branches
strictly shrink the surviving hypothesis set. STOP wins exact ties. Signed finite
action costs remain allowed. The [model contract](source/research/paid-decision-region-v1/EXACT_MODEL_CONTRACT.md)
states ID/input constraints, the verdict-oracle lower-bound condition, and numeric
serialization/runtime limits.

`run_guards.py` requires both maintenance counters to be built-in integer zero.
The donor source adapter/runner call the pinned inventory check before donor
imports, verify imported paths, and check the exact donor function source.
`DONOR_SOURCE_PINS.json` binds exactly dev6_arms.py, run_dev6.py and dev6.py.
The latter was newly read as source/metadata to resolve the sweep configuration;
it was not imported. Transitive world/commitment dependencies are not qualified.
The runner's v2 receipt wording exposes that limit instead of asserting complete
frozen-study identity. No v2 result has been produced.

## Focused qualification

The original helper failed the seven numeric controls: thirteen failure events
(including subtests) and one error. The expected small binary margin and large
integer margin were lost. The clean wide-margin/proper-zero controls were also
present. These RED records remain under records/RED-01.

Current child PID 2042304 ran fifteen pure controls: exact margins/large Fraction
and tie, clean decisions, invalid numeric domains, negative/uninformative probes,
maintenance pairs/types, source and manifest drift, a self-consistent replacement
against a stale trusted pin, module-path refusal, and AST-only import/guard wiring.
All passed; forbidden donor-import attempts were zero. Actual cwd/imported module
paths and equal pre/post source hashes are recorded. The child ran on pinned
Python 3.11.14. The complete outer observed test window was 0.054446221 s; this is
qualification-process cost, not DRD or OCM performance.

Source-custody no-alarm controls copied the three real pinned source files into
owned temporary fixtures and hashed them as inert bytes. No donor, runner,
world generator, native verifier or learner was imported or executed. Adapter
wiring was inspected by AST, not certified by executing the donor path.

The original RED observer inventoried Python files. Its one-line successor also
binds JSON and contract files; the old observer was reconstructed after the run
and matched exactly to the contemporaneous child hash. That timing is explicit
under history/01-red-runner. Source freeze 01 precedes documentation only;
source freeze 02 is the unchanged current qualification input.

## Limits and next boundary

These are engineering controls on a finite conventional parent, not research
outcomes. The source patch does not requalify donor aggregates or complete
lifetime costs. D0, zero-priced storage, source-check overhead and runtime costs
retain the boundaries identified by the independent PR158 review.
The separate controls/ directory is the current qualification apparatus; a later
repository integration must decide its portable test entry point explicitly.
Root/independent source review and a separate integration decision come next.
