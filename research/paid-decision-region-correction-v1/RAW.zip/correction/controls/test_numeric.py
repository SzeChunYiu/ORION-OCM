"""Focused numeric witnesses; imports no donor or experiment source."""
from decimal import Decimal
from fractions import Fraction as F
import unittest
import decision_region_core as D


class NumericControls(unittest.TestCase):
    def solve(self, stop=1, probe=1, outcomes=None):
        states = (0, 1)
        safe = {0: ("safe", "a0"), 1: ("safe", "a1")}
        costs = {(0, "safe"): stop, (1, "safe"): stop,
                 (0, "a0"): 0, (1, "a1"): 0}
        return D.solve_worst_case_drd(
            states, safe, costs, ("p",),
            outcomes or {("p", 0): 0, ("p", 1): 1}, {"p": probe})

    def test_exact_binary_margin_selects_probe(self):
        cost = 1 - 2 ** -42
        result = self.solve(probe=cost)
        self.assertEqual(result["first_decision"], ("probe", "p"))
        self.assertEqual(result["value"], F(cost))

    def test_integer_margin_above_binary64(self):
        result = self.solve(stop=2 ** 54 + 1, probe=2 ** 54)
        self.assertEqual(result["first_decision"], ("probe", "p"))
        self.assertEqual(result["value"], F(2 ** 54))

    def test_fraction_huge_value_and_exact_tie(self):
        value = F(10 ** 1000, 3)
        result = self.solve(stop=value, probe=value)
        self.assertEqual(result["first_decision"], ("stop", "safe"))
        self.assertEqual(result["value"], value)
        self.assertIsInstance(result["value"], F)

    def test_no_alarm_common_action_and_paid_probe(self):
        self.assertEqual(self.solve(stop=10, probe=1)["value"], 1)
        self.assertEqual(self.solve(stop=10, probe=20)["first_decision"], ("stop", "safe"))

    def test_invalid_numeric_types_and_nonfinite(self):
        for value in (True, "1", Decimal("1"), float("nan"), float("inf"), -float("inf")):
            for field in ("stop", "probe"):
                with self.subTest(value=repr(value), field=field):
                    with self.assertRaises((TypeError, ValueError)):
                        self.solve(**{field: value})

    def test_negative_probe_refused_even_if_uninformative(self):
        with self.assertRaises(ValueError):
            self.solve(probe=-1, outcomes={("p", 0): 0, ("p", 1): 0})

    def test_zero_uninformative_probe_uses_proper_stop(self):
        result = self.solve(stop=2, probe=0, outcomes={("p", 0): 0, ("p", 1): 0})
        self.assertEqual(result["first_decision"], ("stop", "safe"))
        self.assertEqual(result["value"], 2)
