"""Pure guard and source-byte controls; donor bytes are never imported."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace
import unittest

import donor_custody as C
from run_guards import require_zero_maintenance

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "source/research/paid-decision-region-v1"
TMP = ROOT / "records/control-tmp"
TMP.mkdir(exist_ok=True)


class GuardControls(unittest.TestCase):
    def test_all_maintenance_pairs_and_clean_case(self):
        require_zero_maintenance(0, 0)
        for pair in ((1, 1), (1, 0), (0, 1), (-1, 0)):
            with self.subTest(pair=pair), self.assertRaises(AssertionError):
                require_zero_maintenance(*pair)

    def test_maintenance_counters_require_integer_domain(self):
        for value in (False, 0.0, "0"):
            with self.subTest(value=repr(value)), self.assertRaises(TypeError):
                require_zero_maintenance(value, 0)


class CustodyControls(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=TMP)
        self.root = Path(self.tmp.name)
        self.manifest = json.loads((MODULE / "DONOR_SOURCE_PINS.json").read_text())
        for row in self.manifest["files"]:
            destination = self.root / row["path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / "donor-pins" / Path(row["path"]).name, destination)

    def tearDown(self):
        self.tmp.cleanup()

    def test_exact_registered_bytes_are_accepted_without_execution(self):
        result = C.verify_inventory(self.root)
        self.assertEqual(len(result["checked_files"]), 3)
        self.assertFalse(result["complete_study_requalification"])

    def test_source_drift_refuses(self):
        path = self.root / self.manifest["files"][0]["path"]
        path.write_bytes(path.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "DONOR_SOURCE_DRIFT"):
            C.verify_inventory(self.root)

    def test_manifest_byte_drift_refuses(self):
        path = self.root / "changed-manifest.json"
        path.write_bytes((MODULE / "DONOR_SOURCE_PINS.json").read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "SOURCE_INVENTORY_DRIFT"):
            C.verify_inventory(self.root, inventory=path)

    def test_self_consistent_source_and_manifest_replacement_refuses(self):
        row = self.manifest["files"][0]
        path = self.root / row["path"]
        raw = path.read_bytes() + b" "
        path.write_bytes(raw)
        row.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                   git_blob_sha1=hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest())
        replacement = self.root / "replacement-manifest.json"
        replacement.write_text(json.dumps(self.manifest, indent=2, sort_keys=True) + "\n")
        with self.assertRaisesRegex(ValueError, "SOURCE_INVENTORY_DRIFT"):
            C.verify_inventory(self.root, inventory=replacement)

    def test_actual_import_path_guard_clean_and_wrong_path(self):
        name = self.manifest["files"][0]["path"]
        C.require_module_path(SimpleNamespace(__file__=str(self.root / name)), self.root, name)
        wrong = self.root / "other.py"
        wrong.write_text("# data-only fixture\n")
        with self.assertRaisesRegex(ValueError, "DONOR_MODULE_PATH_DRIFT"):
            C.require_module_path(SimpleNamespace(__file__=str(wrong)), self.root, name)


class WiringControls(unittest.TestCase):
    def test_preimport_checks_and_guard_wiring_by_ast_only(self):
        for name in ("shortcircuit_parent.py", "run_shortcircuit.py"):
            tree = ast.parse((MODULE / name).read_text())
            check = next(node.lineno for node in tree.body if isinstance(node, ast.Expr)
                         and isinstance(node.value, ast.Call)
                         and isinstance(node.value.func, ast.Name)
                         and node.value.func.id == "verify_inventory")
            imported = next(node.lineno for node in tree.body if isinstance(node, ast.Import)
                            and any(alias.name == "dev6_arms" for alias in node.names))
            self.assertLess(check, imported)
        run_tree = ast.parse((MODULE / "run_shortcircuit.py").read_text())
        one_rep = next(node for node in run_tree.body if isinstance(node, ast.FunctionDef) and node.name == "one_rep")
        names = [node.func.id for node in ast.walk(one_rep) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)]
        self.assertEqual(names.count("require_zero_maintenance"), 1)
