"""Fresh pure-control child with explicit target import guard and identity receipt."""
import hashlib
import importlib.abc
import io
import json
import os
import pathlib
import platform
import sys
import unittest

source, controls, destination, pattern = map(pathlib.Path, sys.argv[1:5])
forbidden = {"dev6_arms", "run_dev6", "dev6", "dev4", "retain", "shortcircuit_parent", "run_shortcircuit"}
blocked = []
class Guard(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in forbidden:
            blocked.append(fullname)
            raise ImportError("FORBIDDEN_DONOR_IMPORT: " + fullname)
sys.meta_path.insert(0, Guard())
sys.path[:0] = [str(source), str(controls)]
def pins():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for directory in (source, controls) for p in sorted(directory.glob("*.py"))}
before = pins()
log = io.StringIO()
suite = unittest.defaultTestLoader.discover(str(controls), pattern=str(pattern))
result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
after = pins()
imports = {name: getattr(module, "__file__", None) for name, module in sys.modules.copy().items()
           if name in {"decision_region_core", "exact_numeric", "drd_model", "donor_custody", "run_guards"}}
receipt = {"schema": "paid-drd.pure-child.v1", "pid": os.getpid(), "ppid": os.getppid(),
           "cwd": os.getcwd(), "python": sys.version, "executable": sys.executable,
           "platform": platform.platform(), "argv": sys.argv,
           "imports": imports, "sources_before": before, "sources_after": after,
           "sources_unchanged": before == after, "tests_run": result.testsRun,
           "failures": len(result.failures), "errors": len(result.errors),
           "passed": result.wasSuccessful(), "forbidden_import_attempts": blocked,
           "scope": "Pure authored controls only; no donor, frozen sweep, native, learner or corpus execution."}
destination.mkdir(exist_ok=False)
(destination / "stdout.txt").write_text(log.getvalue())
(destination / "RECEIPT.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps({"pid": os.getpid(), "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "passed": result.wasSuccessful(), "forbidden_import_attempts": blocked}))
sys.exit(0 if result.wasSuccessful() and before == after and not blocked else 1)
