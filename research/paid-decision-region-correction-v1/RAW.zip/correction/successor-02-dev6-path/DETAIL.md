# Scope of the successor

The independent review found one omission inside the existing three-file custody scope: `dev6.py` was checked on disk, while only `dev6_arms` and `run_dev6` had their actual loaded module paths checked. The pinned `run_dev6` imports `DEV6_PLAN` from `dev6` and assigns its sweep to `SW`.

The successor adds `import dev6 as D6_CONFIG` and passes that module to the unchanged `require_module_path`. The check runs before the runner's sweep is consumed. No new source inventory or dependency closure is introduced.

The exact numeric helper, DRD min/max recurrence, maintenance guard, three-file inventory and remaining 13 source files are byte-identical to the predecessor. The original directory, patch, source freeze, independent finding and 15-control receipts remain intact. Selected exact predecessor copies and their original bindings are retained in [PREDECESSOR.json](PREDECESSOR.json); it is not a replacement qualification.

## Focused control

[The single regression](controls/test_dev6_path.py) parses the preserved/current runner and evaluates only its import/path-check AST nodes. It installs synthetic module objects into `sys.modules`; files in the synthetic repository contain inert comments. The real donor sources and the whole runner are never imported or evaluated.

All three expected on-disk files exist. A separate shadow `dev6.py` contains identical bytes, demonstrating why expected-file hashing alone does not establish the cached module's path. The control checks three cases within one test:

1. Preserved predecessor wiring permits the shadow sweep sentinel.
2. Successor wiring raises `DONOR_MODULE_PATH_DRIFT` and consumes no sweep sentinel.
3. Successor wiring accepts the declared module paths and consumes the clean sentinel.

It also requires exactly the three declared path-check calls. The unchanged custody helper is imported from this successor's exact source path. The import guard records zero attempts to load real donor modules. Child and outer receipts retain actual PID, cwd, interpreter/import paths and unchanged before/after source hashes.

## Boundaries

The prior 15 controls were not rerun: only this runner wiring changed. The new single test does not replace those receipts or qualify a complete transformed adapter or actual DEV6 run. Both patches passed read-only `/usr/bin/git apply --check` against their exact predecessor/original preimages; no patch was applied to a shared checkout or PR.

Path checks cover the three declared modules. They are not a full transitive runtime/commitment closure or proof of arbitrary in-memory object immutability. Fraction serialization, complete runtime/lifetime costs and portable CI integration remain separate work. No published aggregate, source fixture outcome, native evidence or novelty conclusion changes.
