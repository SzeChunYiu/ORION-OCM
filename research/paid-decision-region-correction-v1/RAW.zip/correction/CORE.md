# Paid decision-region correction — read first

**Ready for independent source review:** an isolated correction of PR158,
with 15 focused pure controls passing on billy-laptop. The PR158 branch is untouched.

- [Contract and reuse](DETAIL.md): exact rational DRD, proper stopping and bounded
  donor-source inventory; no new study or runtime adoption.
- [Qualification](QUALIFICATION.json): child identities, preserved RED and current
  focused controls. [Source freeze](SOURCE-FREEZE-02.json) binds their inputs.
- [Patch](integration.patch): read-only applicability checked against exact PR158
  preimages; [reuse record](REUSE.json) binds verbatim PR159 functions.
- [Review request](SOURCE-REVIEW-REQUEST.json) and [manifest](SHA256SUMS).

No donor fixture, DEV6 sweep, native corpus, learner or CI was run. The three-file
custody check is deliberately not a full transitive/study requalification.
No published aggregate result or performance claim is changed by this capsule.
