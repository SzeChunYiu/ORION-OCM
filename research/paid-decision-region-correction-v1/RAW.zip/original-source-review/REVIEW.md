# PR158 independent source review

**Adopt the conventional baseline correction after repairs; do not adopt the
published Bellman helper as an exact parent yet.** This is source-only review of
head `1f6a975b5921da4109dd2286ac030613a55e8261`, tree
`21f8382bacfbb43b1fc3438f7ad5c861172ccd1a`. All eight PR blobs were retrieved at
that immutable head and independently hash-bound before reading. Three precise
donor dependencies were additionally bound to resolve transformation and costs.

## Concrete findings

1. **Exactness claim fails for valid finite costs.**
   [decision_region_core.py](source/research/paid-decision-region-v1/decision_region_core.py)
   converts action/probe costs to float at lines 34 and 94 and uses a `1e-12`
   improvement threshold at line 97. With common stop cost 1, state-specific
   actions costing 0, and an identifying probe costing `1 - 2^-42`, exact
   improvement exists but the source retains STOP. All these numbers are exactly
   representable in binary. Separately, integer stop cost `2^54+1` versus probe
   cost `2^54` loses its one-unit margin during conversion. These are source-
   derived counterexamples, not executed experiments; full inputs are in
   [SOURCE-WITNESSES.json](SOURCE-WITNESSES.json). Tests use wide, small margins
   and do not cover either failure. The formal note's sections 4–5 and the helper
   docstring therefore overstate the implementation's numerical exactness.

2. **The maintenance refusal condition is wrong.**
   [run_shortcircuit.py](source/research/paid-decision-region-v1/run_shortcircuit.py):46
   uses `full != short != 0`. Python requires both inequalities, so `(1,1)` and
   `(1,0)` pass the guard. Require both values to be zero, not chained inequality.
   The pinned naive donor modes currently produce zero maintenance by source
   construction; this guard defect does not show contamination of an outcome.

3. **Declared source custody is not enforced by the adapter.**
   [shortcircuit_parent.py](source/research/paid-decision-region-v1/shortcircuit_parent.py)
   emits `DONOR_BLOB_SHA` without checking actual bytes (lines 23, 53–72). Its
   test compares that emitted constant to itself. A donor edit outside the one
   matched fragment can pass while still advertising the old blob identity.
   At this reviewed head, the actual donor does match `7952b995...` and its
   `_run` has exactly one matching fragment; this is a readiness defect, not an
   asserted current mismatch. Bind and validate the executable donor/sweep
   dependencies before claiming reuse of a fixed study. Also, the declared
   DEV6 commit `f676a34274a9dfc09ae8205a902037cbe27bdd42` was not resolvable via
   either GitHub commit or immutable-contents API. This is an unresolved published
   provenance link, not proof that the commit never existed elsewhere.
   [The custody record](DONOR-CUSTODY-CHECK.json) retains both responses and the
   successful current-source fragment check.

## What is mathematically sound, with its conditions

Common-action safety under realizability and zero in-class information from a
correct unanimous verdict follow directly from intersection/conditioning.
Safety sufficiency and economically optimal stopping are correctly distinguished.
None of those results establishes that the admitted class contains the true world;
section 7 explicitly preserves that authority boundary.

The min/max recurrence describes worst-case cost, not expected cost. The source
skips uninformative probes and recurses only on strictly smaller nonempty subsets.
Its relevant policy class is finite terminating decision trees, with nonnegative
probe costs. State that proper-policy convention explicitly: a zero-cost
uninformative self-loop makes the displayed unconstrained Bellman equation alone
insufficient to select a value. The current source does not validate its numeric
preconditions; reuse should make that domain explicit and checked.

The fixed-prefix lower bound is valid in the unstructured verdict-query model:
unseen values must admit the alternative completions used in the proof. It is
not a lower bound against algorithms that infer correlated verdicts from known
predicate structure or previously paid information. The note already excludes
global optimality against reordering/caching; that oracle-model assumption should
also be explicit when the lower bound is carried into an engineering contract.

## Parent strength and actual cost scope

The original donor already uses short-circuiting `all(...)`. The transformation
preserves that verdict logic and changes the charge from survivor count to actual
predicate-evaluation count. It is a useful accounting correction to a conventional
parent, with no new information, acquired method or demonstrated physical speedup.
Both versions still construct `survivors[1:]`, copying the remaining references
even when disagreement occurs early. Predicate evaluation count is not all CPU,
allocation or memory work.

The runner reports D1 derive/apply/lookup/induce/verify/compose tariffs.
`Phase.total_work(0.0)` gives storage bit-steps zero price; D0 return values are
discarded. Language construction, observation filtering, source inspection and
compilation, whole-tail copying and process wall/CPU/RSS costs are not a complete
measured lifetime ledger. Equal omitted costs may be legitimate for a narrowly
stated differential tariff comparison; they cannot support a complete-cost or
runtime-speed conclusion. Non-lookup Phase equality is an aggregate source-control
check, not an exact per-query trace witness. No donor outcome was revalidated here.

## Workflow and execution boundary

[The workflow](source/.github/workflows/paid-decision-region.yml) uses GitHub-hosted
Ubuntu, Python 3.11.14 and pytest 8.3.5. It runs donor simulations in two test
fixtures and then invokes the full DEV6 sweep through `run_shortcircuit.py` on
matching pull-request/push events. It is not a portable pure-helper-only job.
Reviewing or adopting that workflow must account for this study execution scope;
this review triggered no CI and grants no new experiment authorization.
No inspected path adds a native verifier or neural mechanism, but the full
transitive environment is outside this bounded source review.

## Concrete reuse decision

The isolated PR159 correction already solves the numerical class in finding 1:
validated represented-rational costs, exact comparison and explicit domain rules.
Reuse that qualified foundation in a bounded corrective integration. Preserve this
DRD solver's deterministic-partition worst-case min/max semantics; the PR159
metalevel helper uses expectation and a finite allowance, so it is not a drop-in
replacement. Add only the new DRD margin/guard controls needed for that adaptation.
Do not create a third independent cost implementation.

PR158 overlaps the prior common-action/paid-stopping programme and adds a concrete
short-circuit tariff parent. It neither replaces the PR159 math correction nor
establishes new OCM novelty. The Bellman helper is not called by the short-circuit
runner, so its numerical defect gives no basis to change any unexecuted aggregate
result. It strengthens a future routing baseline without changing the current
native-learning/release priority or authorizing a neural routing path.

The 403-line formal note should receive a compact entry point and smaller detail
files when integrated; that documentation issue is separate from the mathematics.
