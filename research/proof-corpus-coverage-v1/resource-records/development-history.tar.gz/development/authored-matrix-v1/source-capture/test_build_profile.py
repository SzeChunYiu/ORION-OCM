import importlib.util,json
from hashlib import sha256
from pathlib import Path
import pytest
from resource_contract import record,write_json,canonical
def subject():
 assert importlib.util.find_spec("build_profile") is not None,"registered offline dispatcher missing"
 return __import__("build_profile")
def fixture(tmp_path):
 exe=tmp_path/"fixture";exe.write_bytes(b"not executed")
 inv=tmp_path/"inventory.json";source=tmp_path/"source";source.mkdir();(source/"x").write_text("x")
 from build_profile_policy import inventory
 write_json(inv,inventory(source))
 p={"schema":"ocm.f1.build-profile.v1","bwrap":record(exe),"aa_exec":record(exe),
 "files":[{"source":record(exe),"guest":"/tools/fixture","access":"executable"}],
 "materials":[{"path":str(source),"guest":"/source","inventory":record(inv)}],
 "writable":[{"path":str(tmp_path/"artifacts"),"guest":"/work"}],
 "argv":["/tools/fixture"],"environment":{}}
 evidence=tmp_path/"audit.txt";evidence.write_text("Authored fixture; not a native or closure qualification.")
 a=tmp_path/"audit.json";write_json(a,{"schema":"ocm.f1.build-code-audit.v1",
 "profile_payload_sha256":sha256(canonical(p)).hexdigest(),"non_neural_code_reviewed":True,
 "dynamic_code_scope":"REGISTERED_EXEC_AND_FILE_MAPPING_ONLY","evidence":[record(evidence)],
 "limitations":"Caller audit; format checks do not independently prove this review."})
 p["code_audit"]=record(a);return p
def test_bound_manifest_and_directory_inventory(tmp_path):
 m=subject();p=fixture(tmp_path);assert m.validate(p)
 (tmp_path/"source/x").write_text("drift")
 with pytest.raises(ValueError,match="inventory drift"):m.validate(p)
def test_reject_unregistered_dispatch_before_execution(tmp_path):
 m=subject();p=fixture(tmp_path);p["argv"][0]="/bin/sh"
 with pytest.raises(ValueError):m.validate(p)
def test_reject_writable_overlap_and_caller_audit_drift(tmp_path):
 m=subject();p=fixture(tmp_path);p["writable"][0]["guest"]="/tools"
 with pytest.raises(ValueError):m.validate(p)
def test_no_implicit_host_mounts(tmp_path):
 m=subject();p=fixture(tmp_path);args=m.command(p,"test-012345")
 assert "--unshare-all" in args and "--setenv" not in args
 assert "/" not in args and "/home/billy" not in args
 assert args[-4:]==["-p","ocm-f1-test-012345","--","/tools/fixture"]
