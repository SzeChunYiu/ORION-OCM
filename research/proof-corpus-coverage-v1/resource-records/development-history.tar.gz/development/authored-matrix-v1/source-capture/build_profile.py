"""Explicit offline evaluator profile. Audit records are external authority, not inferred."""
from pathlib import Path
from hashlib import sha256
import json,os,re,time,uuid
from resource_contract import record,verify,canonical,write_json
from resource_cgroup import helper
from build_profile_policy import guest_path,verify_inventory,apparmor_policy
import resource_runner
KEYS={"schema","bwrap","aa_exec","files","materials","writable","argv","environment","code_audit"}
ENV={"PATH","HOME","TMPDIR","LEAN_SYSROOT","LEAN_PATH","LEAN_NUM_THREADS","LANG","LC_ALL","TZ"}
def payload(p):return {k:v for k,v in p.items() if k!="code_audit"}
def validate(p):
 if type(p) is not dict or set(p)!=KEYS or p["schema"]!="ocm.f1.build-profile.v1":raise ValueError("exact profile required")
 verify(p["bwrap"]);verify(p["aa_exec"])
 guests={"/proc","/dev","/tmp","/policy-aa-exec"};entries=[]
 if type(p["files"]) is not list or not p["files"]:raise ValueError("explicit file mounts required")
 for f in p["files"]:
  if set(f)!={"source","guest","access"} or f["access"] not in ("executable","library","read"):raise ValueError("file mount contract")
  verify(f["source"]);g=guest_path(f["guest"])
  if g in guests:raise ValueError("duplicate or reserved guest")
  guests.add(g);entries.append((g,"file",f["source"]["path"]))
 for d in p["materials"]:
  if set(d)!={"path","guest","inventory"}:raise ValueError("material contract")
  path=Path(d["path"])
  if str(path.resolve(strict=True))!=str(path) or not path.is_dir():raise ValueError("canonical material directory required")
  inv=verify(d["inventory"]);verify_inventory(path,json.loads(inv.read_bytes()))
  g=guest_path(d["guest"])
  if g in guests:raise ValueError("duplicate or reserved guest")
  guests.add(g);entries.append((g,"material",str(path)))
 for w in p["writable"]:
  if set(w)!={"path","guest"}:raise ValueError("writable contract")
  path=Path(w["path"])
  if not path.is_absolute() or str(path.resolve())!=str(path):raise ValueError("canonical writable path required")
  g=guest_path(w["guest"])
  if g in guests:raise ValueError("duplicate or reserved guest")
  guests.add(g);entries.append((g,"writable",str(path)))
 for i,(g,kind,host) in enumerate(entries):
  for reserved in ("/proc","/dev","/tmp","/policy-aa-exec"):
   if g.startswith(reserved+"/"):raise ValueError("reserved namespace overlap")
  for h,k,other in entries[i+1:]:
   if (h.startswith(g+"/") and kind=="file") or (g.startswith(h+"/") and k=="file"):raise ValueError("file mount overlap")
   if kind=="writable" and (h.startswith(g+"/") or g==h):raise ValueError("writable covers code/material")
   if k=="writable" and (g.startswith(h+"/") or g==h):raise ValueError("writable covers code/material")
   if kind=="writable" and (Path(host)==Path(other) or Path(other).is_relative_to(host)):raise ValueError("writable host overlaps input")
   if k=="writable" and (Path(host)==Path(other) or Path(host).is_relative_to(other)):raise ValueError("writable host overlaps input")
 if not p["writable"]:raise ValueError("owned writable work mount required")
 argv=p["argv"]
 if type(argv) is not list or not argv or any(type(x) is not str or "\0" in x for x in argv):raise ValueError("argv required")
 if argv[0] not in {f["guest"] for f in p["files"] if f["access"]=="executable"}:raise ValueError("unregistered executable")
 if type(p["environment"]) is not dict or set(p["environment"])-ENV:raise ValueError("unregistered environment")
 if any(type(v) is not str or "\0" in v for v in p["environment"].values()):raise ValueError("invalid environment")
 audit=json.loads(verify(p["code_audit"]).read_bytes())
 if set(audit)!={"schema","profile_payload_sha256","non_neural_code_reviewed","dynamic_code_scope","evidence","limitations"}:raise ValueError("audit contract")
 if audit["schema"]!="ocm.f1.build-code-audit.v1" or audit["profile_payload_sha256"]!=sha256(canonical(payload(p))).hexdigest():raise ValueError("audit binding drift")
 if audit["non_neural_code_reviewed"] is not True or audit["dynamic_code_scope"]!="REGISTERED_EXEC_AND_FILE_MAPPING_ONLY":raise ValueError("code audit not qualified")
 if not audit["evidence"] or not audit["limitations"]:raise ValueError("audit evidence and scope required")
 for item in audit["evidence"]:verify(item)
 return audit
def command(p,token):
 args=[p["bwrap"]["path"],"--unshare-all","--die-with-parent","--new-session","--cap-drop","ALL",
  "--proc","/proc","--dev","/dev","--tmpfs","/tmp"]
 for key,value in sorted(p["environment"].items()):args+=["--setenv",key,value]
 for d in sorted(p["materials"],key=lambda x:x["guest"].count("/")):args+=["--ro-bind",d["path"],d["guest"]]
 for f in p["files"]:args+=["--ro-bind",f["source"]["path"],f["guest"]]
 args+=["--ro-bind",p["aa_exec"]["path"],"/policy-aa-exec"]
 for w in p["writable"]:args+=["--bind",w["path"],w["guest"]]
 args+=["--chdir",p["writable"][0]["guest"],"--","/policy-aa-exec","-p","ocm-f1-"+token,"--",*p["argv"]]
 return args
def run(profile,limits,output):
 root=Path(output).resolve();root.mkdir();start=time.monotonic();token="build-"+uuid.uuid4().hex
 result={"schema":"ocm.f1.build-profile-receipt.v1","terminal":"PROFILE_REFUSED","token":token,
  "authority":"External source/code audit plus observed controls; not whole-host neural absence."}
 loaded=False
 try:
  audit=validate(profile);result["audit"]=audit;write_json(root/"profile.json",profile)
  for w in profile["writable"]:
   p=Path(w["path"]);p.mkdir(parents=False,exist_ok=True)
   if not p.is_dir() or p.is_symlink() or p.stat().st_uid!=os.getuid():raise ValueError("unowned writable output")
  files=[*profile["files"],{"guest":"/policy-aa-exec","access":"executable"}]
  policy=apparmor_policy(token,files,[d["guest"] for d in profile["materials"]],[w["guest"] for w in profile["writable"]])
  pp=root/"apparmor.profile";pp.write_text(policy);result["policy"]=record(pp)
  result["policy_setup"]=helper("policy-add",token,str(pp));loaded=True
  result["dispatch"]=resource_runner.run(command(profile,token),{},limits,root/"dispatch",
   [w["path"] for w in profile["writable"]],token=token)
  result["terminal"]=result["dispatch"]["terminal"]
  validate(profile);result["post_input_custody"]="UNCHANGED"
 except BaseException as exc:
  result["error"]={"class":type(exc).__name__,"message":str(exc)}
  result["terminal"]="PROFILE_REFUSED"
 finally:
  if loaded:
   try:result["policy_cleanup"]=helper("policy-remove",token,str(root/"apparmor.profile"))
   except BaseException as exc:result["terminal"]="CLEANUP_INCOMPLETE";result["policy_cleanup_error"]=str(exc)
  result["wall_through_cleanup_s"]=time.monotonic()-start
  write_json(root/"build-profile-receipt.json",result)
 return result
