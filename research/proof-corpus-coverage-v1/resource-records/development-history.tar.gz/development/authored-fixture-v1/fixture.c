#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <time.h>
static void show(const char *p){char b[4096];FILE*f=fopen(p,"r");if(f){size_t n=fread(b,1,sizeof(b)-1,f);b[n]=0;printf("%s: %s\n",p,b);fclose(f);}}
int main(int argc,char**argv){
 setbuf(stdout,NULL);if(argc<2)return 2;
 if(!strcmp(argv[1],"inspect")){show("/proc/self/cgroup");show("/proc/self/attr/current");return 0;}
 if(!strcmp(argv[1],"policy")){
  int f=open("/source/input",O_WRONLY);int e=errno;printf("source_write=%d errno=%d\n",f,e);if(f>=0)return 3;
  int s=socket(AF_INET,SOCK_STREAM,0);e=errno;printf("network=%d errno=%d\n",s,e);if(s>=0)return 4;
  f=open("/read/fixture",O_RDONLY);if(f<0)return 5;
  void*p=mmap(NULL,4096,PROT_READ|PROT_EXEC,MAP_PRIVATE,f,0);e=errno;printf("plugin_map=%s errno=%d\n",p==MAP_FAILED?"DENIED":"ALLOWED",e);if(p!=MAP_FAILED)return 6;close(f);
  execl("/read/fixture","fixture","inspect",NULL);e=errno;printf("unexpected_exec=DENIED errno=%d\n",e);return e==EACCES?0:7;
 }
 if(!strcmp(argv[1],"memory")){for(int i=0;i<2;i++)if(fork()==0){char*p=malloc(40*1024*1024);if(!p)_exit(9);for(int j=0;j<40*1024*1024;j+=4096)p[j]=1;printf("allocated40MiB child=%d\n",getpid());sleep(20);_exit(0);}sleep(20);return 0;}
 if(!strcmp(argv[1],"pids")){for(int i=0;i<256;i++){pid_t p=fork();if(p==0){sleep(20);_exit(0);}if(p<0){printf("fork_denied errno=%d after=%d\n",errno,i);sleep(20);return 0;}}return 8;}
 if(!strcmp(argv[1],"tree")){if(fork()==0){setsid();printf("detached-child=%d\n",getpid());sleep(20);_exit(0);}usleep(100000);return 0;}
 if(!strcmp(argv[1],"cpu")){for(int i=0;i<2;i++)if(fork()==0){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);double end=t.tv_sec+t.tv_nsec/1e9+.6;do{clock_gettime(CLOCK_MONOTONIC,&t);}while(t.tv_sec+t.tv_nsec/1e9<end);_exit(0);}while(wait(NULL)>0){}return 0;}
 if(!strcmp(argv[1],"spool")){char b[4096];memset(b,'x',sizeof(b));for(int i=0;i<1024;i++)write(1,b,sizeof(b));sleep(20);return 0;}
 if(!strcmp(argv[1],"sleep")){puts("before-sleep");sleep(20);return 0;}
 return 2;
}
