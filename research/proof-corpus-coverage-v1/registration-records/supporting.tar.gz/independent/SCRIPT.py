"""Read-only independent audit of the already executed, complete registration."""
from pathlib import Path
from hashlib import sha256
import json,stat,time
BASE=Path('/home/billy/orion-director-work/20260907')
ROOT=BASE/'proof-corpus-coverage-registration-20260907-v1'
ENV=BASE/'proof-corpus-coverage-registration-envelope-20260907-v1'
OUT=BASE/'coverage-registration-independent-audit-v1';OUT.mkdir(exist_ok=False)
started=time.monotonic()
def hashfile(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and stat.S_ISREG(p.lstat().st_mode)
    h=sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
    return {'sha256':h.hexdigest(),'bytes':n}
def check(record):
    assert set(record)=={'path','sha256','bytes'}
    assert type(record['bytes']) is int
    assert hashfile(record['path'])=={k:record[k] for k in ('sha256','bytes')}
def pairs(items):
    result={}
    for k,v in items:
        assert k not in result;result[k]=v
    return result
def read(path):return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n').encode()
try:
    sealrecord=hashfile(ROOT/'SEAL.json')
    assert sealrecord['sha256']=='9d02378c93369da33ccd8940509474422d898bee899c42ce28e7bc6958362a2e'
    seal=read(ROOT/'SEAL.json');assert seal['state']=='REGISTERED_NO_DISPATCH'
    actual={}
    for p in ROOT.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():actual[p.relative_to(ROOT).as_posix()]=hashfile(p)
        else:assert p.is_dir()
    assert {k:v for k,v in actual.items() if k!='SEAL.json'}==seal['files']
    frozen=read(ROOT/'SOURCE-FREEZE.json')
    assert len(frozen['loaded_sources'])==10 and len(frozen['snapshots'])==12
    for group in ('loaded_sources','snapshots','documents','inputs','input_snapshots'):
        for record in frozen[group].values():check(record)
    check(frozen['interpreter'])
    for name,record in frozen['loaded_sources'].items():
        assert {k:record[k] for k in ('sha256','bytes')}=={k:frozen['snapshots'][name][k] for k in ('sha256','bytes')}
    for name,record in frozen['inputs'].items():
        assert {k:record[k] for k in ('sha256','bytes')}=={k:frozen['input_snapshots'][name][k] for k in ('sha256','bytes')}
    source=read(ROOT/'inputs/CORPUS_SOURCE.json');graph=read(ROOT/'inputs/GRAPH.json');solutions=read(ROOT/'inputs/SOLUTIONS.json')
    assert source['commit']=='aa2d8b34692b16c70f699536de0d8e75b9a3e9ef' and source['tree']=='8bb1c43c8f26f1c127591dddeffdead2b5094eb7'
    assert len(source['files'])==60478 and len(graph['nodes'])==len(solutions)==29511
    assert set(graph['nodes'])==set(solutions)
    expected=[]
    for key,node in graph['nodes'].items():
        wrapper=source['files']['Theorems/Thm_'+key+'.lean'];solution=source['files']['P2M/Sol/S_'+key+'.lean']
        assert node['wrapper_sha256']==wrapper['sha256'] and node['solution_sha256']==solution['sha256']==solutions[key]['solution_sha256']
        digest=sha256(b'ocm.f1.semantic-coverage.v1\0'+source['commit'].encode('ascii')+b'\0'+key.encode('utf-8')).hexdigest()
        expected.append({'key':key,'wrapper':wrapper,'solution':solution,'assignment_digest':digest})
    expected.sort(key=lambda r:(bytes.fromhex(r['assignment_digest']),r['key'].encode('utf-8')))
    population=read(ROOT/'POPULATION.json');assert population['count']==29511
    assert population['commit']==source['commit'] and population['tree']==source['tree']
    assert canonical(population['rows'])==canonical(expected)
    stages=('RESOURCE_SETUP','ACQUISITION','BUILD','ASSOCIATION','EXPORT','PREPARE','CHECK')
    rows=[dict(r,assignment_rank=n,state='ASSIGNED_NO_DISPATCH',stages=[{'stage':s,'state':'NOT_DISPATCHED','cause':'REGISTRATION_ONLY','measured_cost':None} for s in stages]) for n,r in enumerate(expected[:4])]
    assignment=read(ROOT/'ASSIGNMENTS.json')
    assert assignment['denominator']==assignment['continuation_cursor']==4
    assert canonical(assignment['rows'])==canonical(rows);check(assignment['population'])
    assert assignment['population']['path']==str(ROOT/'POPULATION.json')
    registered=read(ROOT/'REGISTRATION.json');assert registered['state']=='PROVISIONAL_UNTIL_SEAL'
    assert registered['assignment_count']==registered['continuation_cursor']==4 and registered['population_count']==29511
    assert registered['semantic_checks_reached']==registered['git_proof_blob_bodies_read']==0 and registered['wrapper_source_parsed'] is False
    git=read(ROOT/'GIT.json');assert git['files']==git['unique_blobs']==60478 and git['tree_objects']==source['verified_tree_objects']
    assert git['metrics']['blob_bytes_read']==0
    for record in git['artifacts'].values():check(record)
    ids=sorted({r['oid'] for r in source['files'].values()});sizes={r['oid']:r['bytes'] for r in source['files'].values()}
    assert (ROOT/'git/git-objects.stdin').read_bytes()==('\n'.join(ids)+'\n').encode()
    assert (ROOT/'git/git-objects.stdout').read_bytes()==''.join(oid+' blob '+str(sizes[oid])+'\n' for oid in ids).encode()
    assert (ROOT/'git/git-objects.stderr').read_bytes()==b''
    pre=read(ENV/'PRELAUNCH.json');process=read(ENV/'PROCESS.json')
    assert hashfile(ENV/'PROCESS.json')['sha256']=='e72a732ac4b0e42bdecd6396b1ab269f674e973c68342828b70d5ecb9d5ed137'
    assert process['returncode']==0 and pre['environment']=={} and pre['argv'][1:3]==['-I','-S']
    for record in (pre['python'],pre['entry'],pre['recorder'],process['stdout'],process['stderr']):check(record)
    assert process['stderr']['bytes']==0
    assert pre['entry']==frozen['loaded_sources']['register'] and pre['python']==frozen['interpreter']
    started_record=read(ROOT/'STARTED.json');assert started_record['argv']==pre['argv'][3:]
    assert started_record['isolated'] is started_record['no_site'] is True
    stdout=read(ENV/'stdout');assert stdout['state']=='REGISTERED_NO_DISPATCH'
    assert stdout['seal']=={'path':str(ROOT/'SEAL.json'),**sealrecord}
    qualification=read(BASE/'coverage-registration-qualification.json');preflight=read(BASE/'coverage-registration-preflight-v1.json')
    assert preflight['state']=='SOURCE_QUALIFICATION_BINDINGS_MATCHED'
    assert hashfile(BASE/'coverage-registration-qualification.json')['sha256']==preflight['qualification_sha256']
    assert qualification['tests']==58
    package=Path(pre['entry']['path']).parent
    for name,record in qualification['files'].items():assert hashfile(package/name)=={k:record[k] for k in ('sha256','bytes')}
    result={'terminal':'INDEPENDENT_REGISTRATION_AUDIT_PASS','registration_root':str(ROOT),'seal':sealrecord,'file_count_including_seal':len(actual),'bytes_including_seal':sum(r['bytes'] for r in actual.values()),'population':29511,'assignments':4,'cursor':4,'assigned_keys':[r['key'] for r in rows],'declared_stages_per_row':list(stages),'all_stages':'NOT_DISPATCHED','loaded_source_bindings':10,'snapshots_including_documents':12,'input_snapshots':4,'wrapper_snapshot_scope':'Bytes rehashed only; source text not parsed or model-inspected.','order_audit':'Independently recomputed fixed SHA256 formula over complete already-registered population; no registrar rerun.','process':hashfile(ENV/'PROCESS.json'),'process_wall_seconds':process['wall_seconds'],'scope':'Metadata registration only; no corpus build, proof execution, masked reconstruction or learning.','audit_wall_s':time.monotonic()-started}
    (OUT/'AUDIT.json').write_bytes(canonical(result));(OUT/'FILES.json').write_bytes(canonical(actual))
    (OUT/'SCRIPT.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps(result,sort_keys=True));print('audit_sha256',hashfile(OUT/'AUDIT.json')['sha256'])
except BaseException as exc:
    (OUT/'FAILURE.json').write_bytes(canonical({'error':type(exc).__name__,'detail':str(exc)}));raise
