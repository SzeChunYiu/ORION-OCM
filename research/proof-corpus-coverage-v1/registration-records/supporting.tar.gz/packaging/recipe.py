"""Create-only archival of registration records; no registration/native dispatch."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile, time
BASE = Path('/home/billy/orion-director-work/20260907')
PKG = BASE / 'ocm-proof-corpus-coverage/research/proof-corpus-coverage-v1'
ROOT = BASE / 'proof-corpus-coverage-registration-20260907-v1'
OUT = PKG / 'registration-records'
PRIOR = BASE / 'proof-corpus-inventory-revival-20260907T010338Z.tar.gz'
INPUTS = {'CORPUS_SOURCE.json', 'GRAPH.json', 'SOLUTIONS.json', 'WRAPPERS.json'}
def identity(raw): return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
def canonical(v): return (json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n').encode()
def write(name, raw):
    with (OUT/name).open('xb') as f: f.write(raw)
def archive(name, paths):
    members = {}
    with (OUT/name).open('xb') as target, gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
            for rel, p in sorted(paths.items()):
                assert p.is_file() and not p.is_symlink()
                raw=p.read_bytes(); members[rel]=identity(raw)
                ti=tarfile.TarInfo(rel); ti.size=len(raw); ti.mode=0o644; ti.uid=ti.gid=ti.mtime=0
                tf.addfile(ti, io.BytesIO(raw))
    member_name=name.removesuffix('.tar.gz')+'.members.json'
    write(member_name,canonical(members))
    return {'archive': dict(identity((OUT/name).read_bytes()),name=name),
            'members':dict(identity((OUT/member_name).read_bytes()),name=member_name),
            'member_count':len(members),'raw_bytes':sum(v['bytes'] for v in members.values())}
started=time.monotonic()
assert identity(PRIOR.read_bytes()) == {'sha256':'c1177f5a3725b21d91f74a52faf6c98839800052ababa254cc173bff154d27fb','bytes':61338019}
seal_raw=(ROOT/'SEAL.json').read_bytes(); assert hashlib.sha256(seal_raw).hexdigest()=='9d02378c93369da33ccd8940509474422d898bee899c42ce28e7bc6958362a2e'
seal=json.loads(seal_raw); freeze=json.loads((ROOT/'SOURCE-FREEZE.json').read_bytes())
actual={str(p.relative_to(ROOT)):p for p in ROOT.rglob('*') if p.is_file()}
assert set(actual)==set(seal['files'])|{'SEAL.json'}
for rel,v in seal['files'].items(): assert identity(actual[rel].read_bytes())==v
prior_members={}
with tarfile.open(PRIOR,'r:gz') as tf:
    for m in tf:
        if Path(m.name).name in INPUTS:
            assert m.isfile() and Path(m.name).name not in prior_members
            prior_members[Path(m.name).name]=(m.name,identity(tf.extractfile(m).read()))
assert set(prior_members)==INPUTS
omitted={}
for n in sorted(INPUTS):
    record=seal['files']['inputs/'+n]
    assert identity(Path(freeze['inputs'][n]['path']).read_bytes())==record
    assert prior_members[n][1]==record
    omitted['inputs/'+n]=dict(record,original=freeze['inputs'][n]['path'],sealed_copy=freeze['input_snapshots'][n]['path'],prior_archive_member=prior_members[n][0])
OUT.mkdir()
write('OMITTED.json',canonical({'schema':'ocm.f1.registration-omissions.v1','original_root':str(ROOT),'files':omitted,
    'prior_archive':dict(identity(PRIOR.read_bytes()),path=str(PRIOR)),
    'scope':'Exact four raw inputs omitted from this Git package. Full originals and sealed copies remain external; portable guard does not revalidate their metadata.'}))
derived={k:p for k,p in actual.items() if k not in omitted}
support={}
for p in (BASE/'proof-corpus-coverage-registration-envelope-20260907-v1').iterdir():
    if p.is_file():support['envelope/'+p.name]=p
for p in sorted(BASE.glob('coverage-registration-*.log')):support['qualification/'+p.name]=p
for n in ['coverage-registration-final-tests.xml','coverage-registration-qualification.json','coverage-registration-preflight-v1.json']:
    support['qualification/'+n]=BASE/n
q=json.loads((BASE/'coverage-registration-qualification.json').read_bytes())
for n,v in q['files'].items():
    assert identity((PKG/n).read_bytes())=={k:v[k] for k in ('sha256','bytes')}
    support['qualification/source/'+n]=PKG/n
for p in (BASE/'coverage-registration-independent-audit-v1').iterdir():
    if p.is_file():support['independent/'+p.name]=p
support['envelope/registration_envelope.py']=PKG/'registration_envelope.py'
support['packaging/recipe.py']=Path(__file__)
manifest={'schema':'ocm.f1.registration-records.v1','original_root':str(ROOT),'original_seal':identity(seal_raw),
          'derived':archive('registration-derived.tar.gz',derived),'supporting':archive('supporting.tar.gz',support),
          'omissions':dict(identity((OUT/'OMITTED.json').read_bytes()),name='OMITTED.json')}
manifest['packaging']={'wall_s_before_manifest':time.monotonic()-started,'scope':'Hash verification, external prior archive reads and creation of two archives/member maps; no experiment rerun.'}
write('MANIFEST.json',canonical(manifest))
for rel,p in actual.items():
    assert identity(p.read_bytes())==(identity(seal_raw) if rel=='SEAL.json' else seal['files'][rel])
print(json.dumps(manifest,indent=2))
print('MANIFEST',identity((OUT/'MANIFEST.json').read_bytes()))
