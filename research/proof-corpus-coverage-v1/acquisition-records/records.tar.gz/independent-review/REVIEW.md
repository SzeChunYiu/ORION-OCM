# Actual source acquisition review

Verdict: **INDEPENDENT_MATERIAL_ACQUISITION_REVIEW_PASS**.
Reviewed the actual v2 episode and envelope on billy-laptop. No acquisition,
controller, build, proof or test was rerun.

- All nine registered Git revisions were acquired through nine exact fetches;
  all 55 retained commands have actual integer zero exits and complete raw bindings.
- Frozen `acquisition_git.revalidate(result, expected_root)` independently returned
  `MATERIAL_BYTES_REVALIDATED`, packages 9. Its loaded source/helper hashes were
  pinned; subprocess and network audit events were prohibited during revalidation.
- The same four original assignments and cursor 4 are preserved. Resource setup
  and acquisition completed; BUILD, ASSOCIATION, EXPORT, PREPARE and CHECK remain
  `NOT_RUN`. The recorded semantic-check count is zero.
- All 15 original/frozen source pairs and their loaded/helper identities match.
  The prior 25-worker/31-phase qualifications and actual helper smoke match these
  sources. The original 30-file failure seal is intact.
- Worker PID 2604744 has a zero exit, recorded reap and empty/removed controllers.
  At review its `/proc` entry and the owned controller directories were absent.
- Complete before/after inventories match: 491 episode files / 32,281,524 bytes;
  seven envelope files / 9,979 bytes. The nine bare stores account for 239 files /
  31,591,927 bytes; these remain external, fully inventoried material.

The v2 outer process took 27.477269 seconds, including phase receipts; v1 and v2
outer process times sum to 27.837379 seconds. V2 scheduling took 75.004947 seconds
separately. Nested worker/controller/phase timers overlap and are not added.
Recorded cgroup CPU was 2.482937 seconds and group peak memory 83,288,064 bytes;
these are not aggregate RSS. Network wire bytes remain unmeasured.

V2 is explicitly a new linked revival after the closed v1 setup failure. Its
start is 618.175474 seconds after v1; do not describe both as one unreset clock.
At review, v2 had elapsed 809.029919 seconds with 42,390.970081 seconds remaining.
Later v2 stages must retain deadline monotonic **390867.56895429**. The original
v1 failure and costs remain visible; neither its evidence nor its result changed.

This establishes exact source-material readiness only. There was no checkout,
corpus build, evaluator qualification, semantic coverage, learning, FLT or scaling
result. The disclosed upstream source/proof provenance is unchanged.

Raw review directory:
`/home/billy/orion-director-work/20260907/acquisition-real-review-v1/`.

| Record | SHA256 |
|---|---|
| AUDIT.json | `a95928e154fd533d37921122c02693ce094e298f484551454cccfa628ce9ed7f` |
| ORIGINALS.json | `23443f064bc9eb4582442f25bf436f22b0862ea87d359682a01016951c514cd4` |
| Actual v2 ACQUISITION.json | `ae12fc94b684efe07dbb0dc41bb2f5d451fbeafed86220947df2d2ffd2b3e636` |
| Preserved v1 failure seal | `863ff61af6e9dcb42b7d34bf66fd833c16b363c5973257c2f96e483e4ed49c84` |

An initial review-script mapping error for the smoke manifest is recorded in
ATTEMPT-1.json. The corrected audit completed; it was not a production failure.
