from pathlib import Path
from hashlib import sha256
import json, os, resource, subprocess, sys, time
import xml.etree.ElementTree as ET

BASE=Path('/home/billy/orion-director-work/20260907')
PACKAGE=BASE/'ocm-corpus-material/research/proof-corpus-coverage-v1'
OUT=BASE/'coverage-material-episode-v2'
ENV=BASE/'coverage-material-envelope-v2'
PYTHON='/home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11'

def record(path):
    path=Path(path);raw=path.read_bytes()
    return {'path':str(path),'sha256':sha256(raw).hexdigest(),'bytes':len(raw)}
def save(name,value):
    with (ENV/name).open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2)

ENV.mkdir()
qualified={};evidence=[]
for directory,name,count,before,after in [
    ('acquisition-git-controls-v1','final',25,'source_before','source_after'),
    ('acquisition-qualification-v1','phase.05.process',31,'sources_before','sources_after')]:
    path=BASE/directory/(name+'.json');q=json.loads(path.read_bytes())
    assert type(q['returncode']) is int and q['returncode']==0 and q[before]==q[after]
    xml=BASE/directory/('phase.05.xml' if count==31 else 'final.xml')
    suites=list(ET.parse(xml).getroot().iter('testsuite'))
    assert sum(int(s.attrib['tests']) for s in suites)==count
    assert all(int(s.attrib.get(k,0))==0 for s in suites for k in ('errors','failures','skipped'))
    for key,wanted in q[before].items():
        actual=record(PACKAGE/key)
        assert {k:actual[k] for k in ('sha256','bytes')}==wanted
        qualified[key]=actual
    evidence.extend([record(path),record(xml)])
argv=[PYTHON,'-I','-S',str(PACKAGE/'acquisition_run.py'),
      str(BASE/'proof-corpus-coverage-registration-20260907-v1'),
      str(BASE/'acquisition-lock-input-v1/lake-manifest.json'),str(OUT)]
prior=record(BASE/'coverage-material-v1-failure-seal.json')
assert prior['sha256']=='863ff61af6e9dcb42b7d34bf66fd833c16b363c5973257c2f96e483e4ed49c84'
smoke=json.loads((BASE/'acquisition-helper-smoke-v1/RESULT.json').read_bytes())
assert smoke['terminal']=='FROZEN_ACQUISITION_HELPER_SMOKE_PASS'
save('REVIVAL.json',{'prior_failure_seal':prior,'smoke':record(BASE/'acquisition-helper-smoke-v1/RESULT.json'),
     'change':'Add omitted resource_setup.py to immutable source closure; actual frozen-controller smoke and31 source-bound controls pass.',
     'assignment':'Same four assigned rows and original policy; v1 remains terminal failed. This is a new linked revival, not a within-run retry.'})
save('PRELAUNCH.json',{'argv':argv,'environment':{},'source':qualified,'qualification':evidence,
     'python':record(PYTHON),'launcher':record(__file__),'lock_preparation':record(BASE/'acquisition-lock-input-v1/RECEIPT.json'),
     'revival':record(ENV/'REVIVAL.json'),
     'scope':'One successor launch after registered headroom is available; scheduling wait is separately measured. Prior failed episode and costs retained.'})
wait_start=time.monotonic();eligible=False
with (ENV/'scheduling.jsonl').open('x') as stream:
    while time.monotonic()-wait_start<=300:
        memory=next(int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
        disk=os.statvfs(BASE);free=disk.f_bavail*disk.f_frsize
        eligible=memory>=24*2**30 and free>=224*2**30
        stream.write(json.dumps({'unix_seconds':time.time(),'elapsed_s':time.monotonic()-wait_start,
                                'memory_available_bytes':memory,'disk_free_bytes':free,'eligible':eligible})+'\n');stream.flush()
        if eligible:break
        time.sleep(5)
save('SCHEDULING.json',{'eligible':eligible,'wall_s':time.monotonic()-wait_start,'raw':record(ENV/'scheduling.jsonl')})
if not eligible:
    save('NO-LAUNCH.json',{'state':'NOT_DISPATCHED','cause':'REGISTERED_INITIAL_HEADROOM_UNAVAILABLE','episode_created':OUT.exists()})
    print('No episode launched: registered initial headroom unavailable.',flush=True)
    sys.exit(2)
for value in qualified.values():assert record(value['path'])==value
started=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
print('Launching one fixed corpus material episode.',flush=True)
with (ENV/'stdout.bin').open('xb') as stdout,(ENV/'stderr.bin').open('xb') as stderr:
    process=subprocess.run(argv,env={},stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,check=False)
after=resource.getrusage(resource.RUSAGE_CHILDREN)
save('PROCESS.json',{'returncode':process.returncode,'wall_including_phase_receipts_s':time.monotonic()-started,
     'child_user_s':after.ru_utime-before.ru_utime,'child_system_s':after.ru_stime-before.ru_stime,
     'nonaggregate_child_peak_rss_kib':after.ru_maxrss,'stdout':record(ENV/'stdout.bin'),'stderr':record(ENV/'stderr.bin'),
     'phase':record(OUT/'ACQUISITION.json') if (OUT/'ACQUISITION.json').is_file() else None})
print((ENV/'stdout.bin').read_text(),flush=True)
sys.exit(process.returncode)
