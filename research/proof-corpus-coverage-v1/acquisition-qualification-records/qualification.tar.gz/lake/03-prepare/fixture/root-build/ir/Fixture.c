// Lean compiler output
// Module: Fixture
// Imports: public import Init public meta import Init public import Authored
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_fixture_fixtureValue;
static lean_object* _init_lp_fixture_fixtureValue(void){
_start:
{
lean_object* v___x_1_; 
v___x_1_ = lean_unsigned_to_nat(7u);
return v___x_1_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_authored_Authored(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_fixture_Fixture(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_authored_Authored(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_fixture_fixtureValue = _init_lp_fixture_fixtureValue();
lean_mark_persistent(lp_fixture_fixtureValue);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
