def authoredValue : Nat := 7
theorem authoredIdentity (n : Nat) : n = n := rfl
