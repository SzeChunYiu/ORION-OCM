import Authored
theorem fixtureIdentity (n : Nat) : n = n := authoredIdentity n
def fixtureValue : Nat := authoredValue
