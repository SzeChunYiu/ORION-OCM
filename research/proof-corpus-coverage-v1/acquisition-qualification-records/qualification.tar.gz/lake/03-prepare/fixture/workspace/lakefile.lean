import Lake
open Lake DSL
package fixture
require authored from git "https://example.invalid/authored" @ "cac0ec9f332821dad548f1563ab889d8c73428ef"
lean_lib Fixture
