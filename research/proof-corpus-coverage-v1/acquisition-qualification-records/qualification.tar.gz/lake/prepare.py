from pathlib import Path
import sys,json,re,subprocess,time,hashlib
P=Path('/home/billy/orion-director-work/20260907/ocm-corpus-material/research/proof-corpus-coverage-v1')
sys.path.insert(0,str(P))
import resource_boot
modules=resource_boot.load()
from resource_contract import record,write_json,canonical,verify
from build_profile_policy import inventory
import lake_build_fixture as F
base=Path('/home/billy/orion-director-work/20260907/lake-build-qualification-v1')
out=base/'03-prepare';out.mkdir();start=time.monotonic()
manifest=Path('/home/billy/orion-director-work/20260906/f0-development-runtime-v4/runtime-manifest.json')
assert record(manifest)['sha256']=='93aa17a738a8511bbb8996eff91e81da0ec5868db50d0f81ab26809e38661894'
m=json.loads(manifest.read_bytes());R=Path(m['lean_root'])
old={guest:Path(source) for source,guest in m['shared_libraries']['mounts']}
data=F.create_fixture(out/'fixture')
inv={name:{'type' if k=='kind' else k:v for k,v in item.items()} for name,item in m['lean_files'].items()}
write_json(out/'runtime-inventory.json',inv)
files={};raw=[]
def add(source,guest,access):
 source=Path(source).resolve(strict=True)
 if guest in files:
  assert files[guest]['source']==record(source)
  return
 binding=record(source)
 if source.is_relative_to(R):
  expected=m['lean_files'][str(source.relative_to(R))]
  assert binding['sha256']==expected['sha256'] and binding['bytes']==expected['bytes']
 files[guest]={'source':binding,'guest':guest,'access':access}
 parts=[]
 for flag in ['-lW','-dW']:
  argv=['/usr/bin/readelf',flag,str(source)];t=time.monotonic()
  p=subprocess.run(argv,capture_output=True,timeout=10)
  assert p.returncode==0,(str(source),p.stderr)
  raw.append({'argv':argv,'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'wall_s':time.monotonic()-t})
  parts.append(p.stdout.decode())
 interp=re.search(r'Requesting program interpreter: ([^\]]+)',parts[0])
 if interp:
  g=interp[1];add(old.get(g,Path(g)),g,'library')
 for name in re.findall(r'\(NEEDED\).*?\[([^\]]+)\]',parts[1]):
  internal=next((d/name for d in (R/'lib',R/'lib/lean') if (d/name).exists()),None) if source.is_relative_to(R) else None
  if internal:
   s=internal.resolve();g='/lean/'+str(s.relative_to(R))
  else:
   g='/lib/x86_64-linux-gnu/'+name
   s=old.get(g,Path(g))
   if not s.exists():
    g='/lib64/'+name;s=old.get(g,Path(g))
  add(s,g,'library')
for name in ['lake','lean','leanir','clang','ld.lld','llvm-ar']:
 add(R/'bin'/name,'/lean/bin/'+name,'executable')
add('/usr/bin/git','/usr/bin/git','executable')
write_json(out/'elf-raw.json',raw);write_json(out/'files.json',list(files.values()))
reference=Path('/home/billy/orion-director-work/20260907/resource-exitcode-qualification-v1/cases/policy/profile.json')
prior=json.loads(reference.read_bytes())
profile=F.make_profile(data,list(files.values()),[{'path':str(R),'guest':'/lean','inventory':record(out/'runtime-inventory.json')}],prior['bwrap'],prior['aa_exec'])
(out/'REVIEW.md').write_text('Authored two-package source inspected: Nat value 7, reflexivity lemma and direct imported application; configuration imports Lake and declares one fixed Git dependency. No neural implementation, callbacks, network API, external script, custom tactic, initializer, or plugin in these authored sources. Lean/Lake/Git and standard runtime are trusted pinned tool implementations; this is not a corpus or arbitrary-code sandbox audit. Only registered executables/libraries have x/m. Writable outputs cannot acquire x/m. Prior resource policy/plugin controls are cited, not rerun or relabelled. Full imported Lean/Lake implementation is trusted compiler infrastructure, not newly re-proved or individually line-audited here.\n')
for n in ('lake_build_fixture.py','test_lake_build_fixture.py'):(out/n).write_bytes((P/n).read_bytes())
audit={'schema':'ocm.f1.build-code-audit.v1','profile_payload_sha256':hashlib.sha256(canonical(profile)).hexdigest(),
 'non_neural_code_reviewed':True,'dynamic_code_scope':'REGISTERED_EXEC_AND_FILE_MAPPING_ONLY',
 'evidence':[record(out/'REVIEW.md'),record(out/'lake_build_fixture.py'),record(manifest),record(out/'elf-raw.json')],
 'limitations':'Manually inspected authored fixture plus trusted pinned Lean/Lake/Git runtime. No corpus or whole-OCM qualification. Compiler source inheritance is not an independent full audit.'}
write_json(out/'audit.json',audit);profile['code_audit']=record(out/'audit.json');write_json(out/'profile.json',profile)
limits={'memory_bytes':2*1024**3,'memsw_bytes':2*1024**3,'cpu_quota_us':200000,'cpu_period_us':100000,'pids':64,
 'max_file_bytes':256*1024**2,'min_available_bytes':2*1024**3,'min_free_bytes':80*1024**3,'stop_free_bytes':80*1024**3,
 'max_owned_bytes':2*1024**3,'wall_s':90,'term_grace_s':0.2,'reap_s':2,'poll_s':0.05}
write_json(out/'limits.json',limits)
write_json(out/'PREPARATION.json',{'terminal':'PREPARED_NOT_DISPATCHED','wall_s':time.monotonic()-start,
 'runtime':record(manifest),'profile':record(out/'profile.json'),'limits':record(out/'limits.json'),
 'driver_sources':resource_boot.loaded_sources(modules['build_profile'].__dict__),'fixture':record(out/'fixture/fixture.json'),
 'files':len(files),'metadata_processes':len(raw),'historical_profile':record(reference)})
print(json.dumps({'terminal':'PREPARED_NOT_DISPATCHED','files':len(files),'out':str(out),'wall_s':time.monotonic()-start}))
