from pathlib import Path
import hashlib,json,subprocess,time,xml.etree.ElementTree as ET
b=Path('/home/billy/orion-director-work/20260907');src=b/'ocm-corpus-material/research/proof-corpus-coverage-v1'
out=b/'corpus-layout-read-record-qualification-v1/02-green';out.mkdir();(out/'source').mkdir()
def rec(p):
 v=p.read_bytes();return {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def save(n,d):
 with (out/n).open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
names=['corpus_layout.py','test_corpus_layout.py']
before={n:rec(src/n) for n in names}
for n in names:(out/'source'/n).write_bytes((src/n).read_bytes())
save('SOURCE.json',before)
py='/home/billy/orion-director-work/20260906/ocm-completion-runtime/.venv/bin/python'
argv=[py,'-m','pytest','test_corpus_layout.py','-k','read_record','-q','--basetemp='+str(out/'fixtures'),'--junitxml='+str(out/'tests.xml')]
t=time.monotonic()
with (out/'stdout.bin').open('xb') as stdout,(out/'stderr.bin').open('xb') as stderr:
 p=subprocess.run(argv,cwd=src,stdout=stdout,stderr=stderr,check=False,timeout=30)
s=time.monotonic()-t;after={n:rec(src/n) for n in names};save('SOURCE-AFTER.json',after)
counts={k:sum(int(x.get(k,0)) for x in ET.parse(out/'tests.xml').getroot().iter('testsuite')) for k in ('tests','failures','errors','skipped')}
save('PROCESS.json',{'argv':argv,'returncode':p.returncode,'wall_s':s,'counts':counts,'deselected':21,
 'stdout':rec(out/'stdout.bin'),'stderr':rec(out/'stderr.bin'),'source_unchanged':before==after,
 'scope':'Only three consumed-record boundary controls; no Git fixture, materialization, Lake, profile or corpus dispatch.'})
assert p.returncode==0 and before==after and counts=={'tests':3,'failures':0,'errors':0,'skipped':0}
save('RESULT.json',{'terminal':'CONSUMED_RECORD_CONTROLS_PASS','source':rec(out/'SOURCE.json'),'process':rec(out/'PROCESS.json')})
print(json.dumps({'counts':counts,'wall_s':s,'source':before,'result':rec(out/'RESULT.json')}))
