from pathlib import Path
import hashlib,json,subprocess,time,xml.etree.ElementTree as ET
b=Path('/home/billy/orion-director-work/20260907');src=b/'ocm-corpus-material/research/proof-corpus-coverage-v1'
out=b/'corpus-layout-preflight-qualification-v1/03-green';out.mkdir();(out/'source').mkdir()
def rec(p):
 v=p.read_bytes();return {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def save(n,d):
 with (out/n).open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
names=['corpus_layout.py','test_corpus_layout.py','acquisition_git.py','acquisition_git_custody.py',
       'build_profile_policy.py','resource_contract.py','materialize_git.py','materialize_objects.py','test_materialize_git.py']
before={n:rec(src/n) for n in names}
for n in names:(out/'source'/n).write_bytes((src/n).read_bytes())
save('SOURCE.json',before)
argv=['/home/billy/orion-director-work/20260906/ocm-completion-runtime/.venv/bin/python','-m','pytest','test_corpus_layout.py',
      '-k','read_record or preflight or input_receipt or deadline_and_post','-q',
      '--basetemp='+str(out/'fixtures'),'--junitxml='+str(out/'tests.xml')]
t=time.monotonic()
with (out/'stdout.bin').open('xb') as stdout,(out/'stderr.bin').open('xb') as stderr:
 p=subprocess.run(argv,cwd=src,stdout=stdout,stderr=stderr,check=False,timeout=30)
s=time.monotonic()-t;after={n:rec(src/n) for n in names};save('SOURCE-AFTER.json',after)
counts={k:sum(int(x.get(k,0)) for x in ET.parse(out/'tests.xml').getroot().iter('testsuite')) for k in ('tests','failures','errors','skipped')}
save('PROCESS.json',{'argv':argv,'returncode':p.returncode,'wall_s':s,'counts':counts,'deselected':19,
 'stdout':rec(out/'stdout.bin'),'stderr':rec(out/'stderr.bin'),'source_unchanged':before==after,
 'scope':'Seven focused receipt/preflight/deadline controls with authored local Git fixtures. No production materialization, layout, Lake, profile or corpus dispatch.'})
assert p.returncode==0 and before==after and counts=={'tests':7,'failures':0,'errors':0,'skipped':0}
save('RESULT.json',{'terminal':'BOUND_PREFLIGHT_CONTROLS_PASS','source':rec(out/'SOURCE.json'),'process':rec(out/'PROCESS.json')})
print(json.dumps({'counts':counts,'wall_s':s,'own_sources':{n:before[n] for n in names[:2]},'result':rec(out/'RESULT.json')}))
