theorem authored (n : Nat) : n = n := rfl
