retained data
