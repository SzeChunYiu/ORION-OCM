from pathlib import Path
import hashlib,json,subprocess,time,xml.etree.ElementTree as ET
base=Path('/home/billy/orion-director-work/20260907')
src=base/'ocm-corpus-material/research/proof-corpus-coverage-v1'
out=base/'corpus-layout-qualification-v1/05-final';out.mkdir()
names=['corpus_layout.py','test_corpus_layout.py','acquisition_git.py','acquisition_git_custody.py',
       'build_profile_policy.py','resource_contract.py','materialize_git.py','materialize_objects.py','test_materialize_git.py']
def record(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,d):
 with (out/name).open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
snapshot=out/'source';snapshot.mkdir()
before={n:record(src/n) for n in names}
for n in names:(snapshot/n).write_bytes((src/n).read_bytes())
save('SOURCE.json',before)
py=Path('/home/billy/orion-director-work/20260906/ocm-completion-runtime/.venv/bin/python')
argv=[str(py),'-m','pytest','test_corpus_layout.py','-q','--basetemp='+str(out/'authored-fixtures'),
      '--junitxml='+str(out/'tests.xml')]
t=time.monotonic()
with (out/'stdout.bin').open('xb') as stdout,(out/'stderr.bin').open('xb') as stderr:
 p=subprocess.run(argv,cwd=src,stdout=stdout,stderr=stderr,check=False,timeout=120)
elapsed=time.monotonic()-t
after={n:record(src/n) for n in names};save('SOURCE-AFTER.json',after)
tree=ET.parse(out/'tests.xml').getroot()
counts={k:sum(int(s.get(k,'0')) for s in tree.iter('testsuite')) for k in ('tests','errors','failures','skipped')}
r={'argv':argv,'cwd':str(src),'returncode':p.returncode,'wall_s':elapsed,
   'python':{'path':str(py),'resolved':str(py.resolve()),**record(py)},
   'source_unchanged':before==after,'counts':counts,'stdout':record(out/'stdout.bin'),'stderr':record(out/'stderr.bin'),
   'scope':'Authored local Git objects and independent layout copies only. No production corpus preparation, acquired code, Lean, profile, network or scientific run.'}
save('PROCESS.json',r)
assert p.returncode==0 and before==after and counts=={'tests':21,'errors':0,'failures':0,'skipped':0}
save('RESULT.json',{'terminal':'AUTHORED_LAYOUT_CONTROLS_PASS','counts':counts,'source':record(out/'SOURCE.json'),
                   'process':record(out/'PROCESS.json'),'scope':r['scope']})
print(json.dumps(r))
