# Offline corpus layout helper: authored qualification

The new helper prepares data for the existing offline build profile. It does not
execute Lake, a profile, source configuration, imported package code or any corpus row.

## API

`corpus_layout.prepare_layout(materials, lock_record, new_output,
deadline_monotonic=<original whole deadline>)`

`materials` is an ordered list of exactly ten trusted bindings: corpus first,
then the nine names returned by the original pinned lock validator. Each entry is:
`{name, commit, tree, receipt: {path, sha256, bytes}}`.
Each receipt is the existing materializer's create-only RESULT.json.
The caller must authenticate that receipt's execution/source/issuer provenance;
the helper verifies its bytes and successful materialization fields, not its issuer.

`lock_record` is the exact file record for the registered corpus lock.
The public API uses the existing acquisition validator and fixed corpus commit.
The private `_prepare` test seam accepts an explicitly labelled authored small-lock
validator; it is not the production entry or candidate-configurable policy.

All input paths must be canonical. The output parent must exist and the new output
must not overlap any receipt, lock or source workspace. Existing destinations and
overlap/path errors raise before output creation. Subsequent failures retain partial
data plus LAYOUT_REFUSED/RESULT.json; LAYOUT_READY is emitted only after final checks.

## Output and custody

- Ten independent copies at `materials/<name>/workspace`, without hardlinks.
- Original source bytes, executable modes, symlink targets and Git metadata preserved.
- Safe relative internal links only; dangling/escaping/metadata aliases refuse.
- Before/post source inventories and final output inventory are retained.
- Only declared empty layout directories are added; existing nonempty overlay
  subtrees and package overrides refuse. Ordinary tracked widget.js/lake.trace
  fixture data remains visible. No seeded-artifact policy is introduced.
- Root .lake/config, .lake/build, .lake/cache and .lake/packages receive empty
  directories; dependency names are empty nested mountpoints.
- Every dependency gets its default .lake/build mountpoint.
- Separate artifacts contain scratch/home, config, cache and one build directory
  for each of the ten packages. They are empty before dispatch.

`material_mounts` uses the existing build_profile material/inventory schema:
root at /workspace, nine packages at /workspace/.lake/packages/<name>.
`writable` supplies 13 artifact mounts with /work first.
Combine those fragments with the separately pinned executor/library/material inputs,
exact Lake argv and external code-audit record. No executable profile or
non-neural-code approval is returned by this helper.

The original registered boot/deadline authority and aggregate enforcement belong
to the outer caller. Per-block copying/hashing and final readiness check the supplied
monotonic deadline. Inner wall time excludes imports and final receipt persistence.
Logical disk bytes and before/after free space are recorded; no hard disk quota,
whole-lifetime cost or speedup is inferred. Acquisition is reused, not repeated.

## Executed authored evidence

All execution occurred on billy-laptop using registered CPython 3.11.14.
The fixtures contain a root and two dependencies with real tiny Git objects and
detached HEAD/index metadata. Their Lean-looking source is copied as data only.

- 01-red: 16 expected failures because the helper was absent.
- 02-green: all 16 initial controls passed.
- 03-red: three late-change controls failed; 18 passed. The old final readiness
  check allowed drift of a copied source, an inventory, or a newly injected cache.
- 04-green: exact final membership/content validation repaired all three cases.
- 05-final: 21 passed, zero skipped/errors/failures, with the nine consumed source
  files unchanged before/after and retained authored fixtures/raw process records.
- Final outer test process: 1.817804088 seconds; stdout/stderr and JUnit retained.

Current helper SHA256:
`6dd25a4f7b9a781f2d3bdc1e45797fd45a93648cffe3ab4951f848879120a964`.
Current tests SHA256:
`fb86f3f340f501c4734dc4ad86243a66358ec8fd4dae56398c08412f09d0f3f3`.
Final SOURCE.json SHA256:
`2c6d31518e5136a424901f9fe0f9f08e8000a4def77a6d20da77fe42d4620481`.
Final RESULT.json SHA256:
`935a0ed28163361e822d7558a6ac4097a9847c72add12f95429ea7ee018d5f80`.

Raw root:
`/home/billy/orion-director-work/20260907/corpus-layout-qualification-v1`.

The current corpus materializer/output/profile integration is still separate.
No real corpus body was inspected or laid out by this task. No corpus preparation,
build, semantic coverage, proof search, learning or scientific claim was executed.
