import OCMEnvironment.Write
namespace OCMCoverage
open Lean

def verifySource (_env : Environment) (names : Array Name)
    (restored : OCMEnvironment.ConstMap) : IO Unit := do
  if restored.size != names.size then throw <| IO.userError "SOURCE_MEMBERSHIP_SIZE"
  for n in names do
    if !restored.contains n then throw <| IO.userError s!"SOURCE_MEMBERSHIP_MISSING {n}"
end OCMCoverage
