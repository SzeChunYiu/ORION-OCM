import OCMCoverage.Transport
open Lean OCMCoverage

def rejected (label : String) (action : IO Unit) : IO Unit := do
  let result ← try action; pure false catch _ => pure true
  unless result do throw <| IO.userError s!"EXPECTED_TRANSPORT_REFUSAL {label}"
  IO.println s!"PASS {label}"

def main (args : List String) : IO UInt32 := do
  let [packetPath] := args | throw <| IO.userError "usage: transport_tests SOURCE_PACKET"
  let some sysroot ← IO.getEnv "LEAN_SYSROOT" | throw <| IO.userError "LEAN_SYSROOT_REQUIRED"
  initSearchPath sysroot
  let env ← importModules #[{module := `Theorems.Thm_authored}] {} (loadExts := false) (level := .private)
  let packet ← OCMEnvironment.readPacket packetPath
  let map := packet.state.constMap
  let names := map.toList.toArray.map (·.1)
  verifySource env names map
  IO.println "PASS exact-original-support"
  let support := `P2MW.S_authored.solution
  let some (.thmInfo ci) := map[support]? | throw <| IO.userError "FIXTURE_SUPPORT_MISSING"
  let altered := #[
    ("body", ConstantInfo.thmInfo {ci with value := mkSort .zero}),
    ("type", ConstantInfo.thmInfo {ci with type := mkSort .zero}),
    ("universe", ConstantInfo.thmInfo {ci with levelParams := [`changed]}),
    ("family-membership", ConstantInfo.thmInfo {ci with all := [`changed]})]
  for (label, bad) in altered do
    rejected label <| verifySource env names (map.insert support bad)
  rejected "missing-support" <| verifySource env names (map.erase support)
  rejected "extra-support" <| verifySource env names (map.insert `unknown (.thmInfo {ci with name := `unknown}))
  IO.println "TRANSPORT_CONTROLS_PASS 7"
  return 0
