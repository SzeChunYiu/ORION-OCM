"""Fixed authored profile commissioning. No corpus, Lean proof or row selection."""
from pathlib import Path
from hashlib import sha256
import os,json,subprocess,sys,time,signal
ROOT=Path(__file__).resolve().parent
SRC=ROOT/"source"
DEV=ROOT.parent/"proof-corpus-coverage-resource-dev-20260907"
FIX=DEV/"authored-fixture-v2"
PY=Path("/home/billy/.local/share/uv/python/cpython-3.11.14-linux-x86_64-gnu/bin/python3.11")
def canonical(v):return (json.dumps(v,sort_keys=True,separators=(",",":"))+"\n").encode()
def write(p,v):
 with p.open("xb") as f:f.write(canonical(v))
def record(p):
 p=Path(p).resolve();b=p.read_bytes();return {"path":str(p),"sha256":sha256(b).hexdigest(),"bytes":len(b)}
BASE={"memory_bytes":67108864,"memsw_bytes":67108864,"cpu_quota_us":25000,"cpu_period_us":100000,
 "pids":16,"wall_s":3,"term_grace_s":.2,"reap_s":2,"poll_s":.05,"max_file_bytes":8388608,
 "min_available_bytes":0,"min_free_bytes":0,"stop_free_bytes":0,"max_owned_bytes":16777216}
ENVELOPE={**BASE,"memory_bytes":20*1024**3,"memsw_bytes":20*1024**3,"cpu_quota_us":200000,"pids":128,
 "min_available_bytes":24*1024**3,"min_free_bytes":224*1024**3,"stop_free_bytes":80*1024**3,
 "max_owned_bytes":128*1024**3,"max_file_bytes":8*1024**3}
CASES=[("envelope","inspect",ENVELOPE),("policy","policy",BASE),("plugin-allowed","plugin-allowed",BASE),
 ("plugin-denied","plugin-denied",BASE),("cpu","cpu",BASE),("memory","memory",BASE),("pids","pids",BASE),
 ("tree","tree",BASE),("spool","spool",{**BASE,"max_owned_bytes":100000}),
 ("wall","sleep",{**BASE,"wall_s":.3}),("file-size","spool",{**BASE,"max_file_bytes":65536}),
 ("host-interruption","sleep",{**BASE,"wall_s":8})]
def inputs(case,mode):
 d=ROOT/"cases"/case;d.mkdir()
 source=DEV/"profile-initial-v1/source";inv=DEV/"profile-initial-v1/inventory.json"
 files=[{"source":record(FIX/"fixture"),"guest":"/tools/fixture","access":"executable"},
  {"source":record(FIX/"fixture"),"guest":"/read/fixture","access":"read"},
  {"source":record(FIX/"plugin.so"),"guest":"/lib/fixture-plugin.so","access":"library"},
  {"source":record(FIX/"plugin.so"),"guest":"/read/fixture-plugin.so","access":"read"}]
 for guest in ("/lib/x86_64-linux-gnu/libc.so.6","/lib/x86_64-linux-gnu/libpthread.so.0","/lib64/ld-linux-x86-64.so.2"):
  files.append({"source":record(guest),"guest":guest,"access":"library"})
 p={"schema":"ocm.f1.build-profile.v1","bwrap":record("/usr/bin/bwrap"),"aa_exec":record("/usr/bin/aa-exec"),
  "files":files,"materials":[{"path":str(source),"guest":"/source","inventory":record(inv)}],
  "writable":[{"path":str(d/"artifacts"),"guest":"/work"}],"argv":["/tools/fixture",mode],"environment":{}}
 evidence=[record(FIX/n) for n in ("fixture.c","plugin.c","compile.json","fixture-d.readelf","plugin-d.readelf")]
 evidence += [record(DEV/"authored-fixture-v1/aa-exec-d.readelf")]
 audit={"schema":"ocm.f1.build-code-audit.v1","profile_payload_sha256":sha256(canonical(p)).hexdigest(),
  "non_neural_code_reviewed":True,"dynamic_code_scope":"REGISTERED_EXEC_AND_FILE_MAPPING_ONLY",
  "evidence":evidence,"limitations":"Finite authored C fixture/plugin and measured loader/libc/pthread/aa-exec. Code review plus observed fixed profile; not whole-host neural absence, semantic closure, corpus coverage or general adversarial-code assurance."}
 write(d/"audit.json",audit);p["code_audit"]=record(d/"audit.json");write(d/"profile.json",p)
 return d
def assess(case,r,out):
 d=r.get("dispatch",{});cleanup=d.get("cleanup",{})
 common=(cleanup.get("reaped") and cleanup.get("members_empty") and cleanup.get("controllers_removed")
  and r.get("policy_cleanup",{}).get("removed") and r.get("post_input_custody")=="UNCHANGED")
 if not common:return False
 terminal=r["terminal"];stats=d.get("final_resources",{})
 if case=="envelope":
  return terminal=="COMPLETED" and "(enforce)" in out and stats["memory.limit_in_bytes"]==20*1024**3 and stats["memory.memsw.limit_in_bytes"]==20*1024**3 and stats["cpu.cfs_quota_us"]==200000 and stats["pids.max"]==128
 if case=="policy":return terminal=="COMPLETED" and all(s in out for s in ["source_write=-1 errno=30","network=-1 errno=13","plugin_map=DENIED errno=13","unexpected_exec=DENIED errno=13"])
 if case=="plugin-allowed":return terminal=="COMPLETED" and "dlopen=ALLOWED value=17" in out
 if case=="plugin-denied":return terminal=="COMPLETED" and "dlopen=DENIED" in out
 if case=="cpu":return terminal=="COMPLETED" and stats["cpu.stat"]["nr_throttled"]>0
 if case=="tree":return terminal=="COMPLETED" and "detached-child=" in out
 if case=="file-size":return terminal=="COMMAND_FAILED" and d["returncode"]==153 and d["raw"]["stdout.bin"]["bytes"]==65536
 if case=="host-interruption":return terminal=="INTERRUPTED" and "before-sleep" in out
 expected={"memory":"MEMORY_LIMIT","pids":"PID_LIMIT","spool":"OWNED_BYTES","wall":"WALL_DEADLINE"}[case]
 return terminal=="RESOURCE_STOP" and d["reason"]==expected
def main():
 begin=time.monotonic();(ROOT/"cases").mkdir()
 frozen=json.loads((ROOT/"SOURCE_FREEZE.json").read_bytes())
 for n,r in frozen["files"].items():assert record(SRC/n)["sha256"]==r["sha256"]
 write(ROOT/"REGISTRATION.json",{"cases":[{"id":c,"mode":m,"limits":l} for c,m,l in CASES],
  "driver":record(__file__),"freeze":record(ROOT/"SOURCE_FREEZE.json"),"python":record(PY),
  "fixed_denominator":12,"scope":"Authored profile/resource controls, no corpus/proof studies"})
 rows=[{"case":c,"status":"NOT_RUN"} for c,_,_ in CASES]
 for i,(case,mode,limits) in enumerate(CASES):
  d=inputs(case,mode);write(d/"limits.json",limits)
  argv=[str(PY),"-I","-S",str(SRC/"resource_boot.py"),"run","--profile",str(d/"profile.json"),
   "--limits",str(d/"limits.json"),"--output",str(d/"run")]
  start=time.monotonic();process={"argv":argv,"environment":{}};p=None
  try:
   with (d/"host.stdout").open("xb") as out,(d/"host.stderr").open("xb") as err:
    p=subprocess.Popen(argv,env={},stdout=out,stderr=err)
    if case=="host-interruption":
     until=time.monotonic()+5;stream=d/"run/dispatch/stdout.bin"
     while time.monotonic()<until and (not stream.exists() or b"before-sleep" not in stream.read_bytes()):
      if p.poll() is not None:break
      time.sleep(.02)
     assert stream.exists() and b"before-sleep" in stream.read_bytes(),"child readiness unavailable"
     # Use the already qualified pidfd ABI; never a bare-PID kill.
     import ctypes
     libc=ctypes.CDLL(None,use_errno=True);fd=libc.syscall(434,p.pid,0)
     assert fd>=0
     try:assert libc.syscall(424,fd,int(signal.SIGTERM),0,0)==0
     finally:os.close(fd)
    process["returncode"]=p.wait(timeout=limits["wall_s"]+limits["term_grace_s"]+limits["reap_s"]+10)
   r=json.loads((d/"run/build-profile-receipt.json").read_bytes())
   child=(d/"run/dispatch/stdout.bin").read_text(errors="replace")
   passed=assess(case,r,child)
   rows[i]={"case":case,"status":"PASS" if passed else "FAIL","terminal":r["terminal"],
    "reason":r.get("dispatch",{}).get("reason"),"resource_wall_s":r.get("dispatch",{}).get("wall_through_cleanup_s"),
    "profile_wall_s":r["wall_through_cleanup_s"],"receipt":record(d/"run/build-profile-receipt.json")}
  except Exception as exc:rows[i]={"case":case,"status":"FAIL","error":str(exc)}
  finally:
   if p is not None and p.poll() is None:
    import ctypes
    libc=ctypes.CDLL(None,use_errno=True);fd=libc.syscall(434,p.pid,0)
    if fd>=0:
     try:libc.syscall(424,fd,int(signal.SIGTERM),0,0);p.wait(timeout=12)
     finally:os.close(fd)
  process["wall_s"]=time.monotonic()-start;write(d/"host-process.json",process);write(d/"assessment.json",rows[i])
  print(json.dumps(rows[i]),flush=True)
 for n,r in frozen["files"].items():assert record(SRC/n)["sha256"]==r["sha256"]
 result={"terminal":"AUTHORED_RESOURCE_PROFILE_CONTROLS_PASSED" if all(r["status"]=="PASS" for r in rows) else "CONTROLS_FAILED",
  "assigned":12,"passed":sum(r["status"]=="PASS" for r in rows),"rows":rows,"wall_s":time.monotonic()-begin,
  "scope":"Current host, frozen source-only entry, authored control packet. Not corpus qualification or neural-absence proof."}
 write(ROOT/"RESULT.json",result);return 0 if result["passed"]==12 else 2
if __name__=="__main__":raise SystemExit(main())
