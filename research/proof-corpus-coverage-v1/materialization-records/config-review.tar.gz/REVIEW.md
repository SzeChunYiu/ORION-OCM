# Pinned build configuration review

7 September 2026. This is a partial source review, not authorization to execute
the acquired corpus or evidence of a proof result. The V2 episode's original
whole deadline remains in force.

## Observed source

Read all ten root/package Lake configurations from the registered corpus commit
and the nine acquired revisions. Thirty bounded local Git calls returned zero;
each output was checked against its Git blob identity. No package configuration,
proof body, tactic, external helper or compiler was executed by the reader.

Raw records on billy-laptop:
`/home/billy/orion-director-work/20260907/coverage-build-config-review-v1/`.
`RESULT.json` binds the acquisition/start bytes, exact configuration objects,
reader and Git identities, raw streams and nested command times. The read took
0.047407 seconds before its receipt, including 0.018039 seconds of child CPU.
This engineering inspection has no aggregate-controller qualification claim.

| Configuration | Observed mechanism | Consequence for the intended build |
|---|---|---|
| Corpus `flt_e2e` | Four exact Lean options, one pinned mathlib requirement, four library declarations | Preserve the options and use the assigned `Theorems` module target; `FinalCheck` remains outside dispatch |
| mathlib | Lake definitions for options, libraries, executables and a post-update hook | Preserve its linters/options; declared executables are not automatically invoked or admitted |
| mathlib post-update hook | May build/run the cache executable and access remote storage | The exact existing lock/HEAD route must avoid update; network remains denied regardless |
| proofwidgets | `ProofWidgets` libraries require `widgetJsAll`; that target checks a trace and may invoke npm | Preserve the supplied JavaScript and trace; never enable npm or network as an implicit fallback |
| aesop | `precompileModules = false` explicitly in the pinned TOML | Keep that exact setting; it does not establish all other modules' plugin requirements |
| Other six dependency TOMLs | Ordinary library/executable/test declarations; importGraph requires Cli | Resolve the existing lock revisions, not the branch labels in package declarations |

The corpus options are `autoImplicit=false`, `maxHeartbeats=4000000`,
`synthInstance.maxHeartbeats=400000`, and
`backward.isDefEq.respectTransparency.types=false`. They are registered upstream
inputs, not newly optimized OCM settings.

## ProofWidgets asset check

The exact pinned Git tree contains 23 JavaScript files and `widget/js/lake.trace`.
The metadata query also included the known `ProofWidgets/Component/Basic.lean`
file as a positive control. Therefore the presence of an npm build function in
the configuration does not establish that the assets are missing or that npm
will execute. Whether Lake accepts the supplied trace remains unexecuted.

Keep all supplied assets and their original identities. A stale trace or a
required undeclared helper is a build-policy finding to preserve, not permission
to change source, disable the target, download replacement artifacts or count
the row as a proof rejection.

## Remaining execution boundary

The ten configurations import Lake or use its TOML DSL. Their direct declarations
do not supply a neural model or neural-learning pipeline. This observation does
not classify the complete imported theorem/tactic/initializer closure.

Before actual corpus execution, bind the materialized workspace, exact assigned
module closure, effective setup/options and required interpreted/native code.
Keep generated native plugin admission separate and immutable. Review the
reachable proof tactics, external-process calls and FFI/initializer behavior;
the mere availability of a file or declaration is not evidence it executed.

Reuse the qualified authored offline profile and resource controller. Match the
production profile to its actual source audit, and preserve all four assigned
rows if any required mechanism remains unclassified. Full learned proof search,
method reuse, language transfer and whole-machine no-neural evidence remain open.
