"""One current portable integration on laptop billy; no actual corpus dispatch."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

BASE = Path('/home/billy/orion-director-work/20260907')
REPO = BASE / 'ocm-corpus-material'
PACKAGE = REPO / 'research/proof-corpus-coverage-v1'
OUT = BASE / 'materialization-portable-integration-v2'
PYTHON = str(BASE / 'proof-runtime-engineering-env/bin/python')
PREFIX = 'research/proof-corpus-coverage-v1/'

def digest(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def source_map():
    paths = {REPO / '.github/workflows/proof-corpus-coverage.yml'}
    for component in ('proof-corpus-coverage-v1', 'proof-corpus-v1',
                      'proof-environment-v1', 'proof-replay-v1'):
        root = REPO / 'research' / component
        paths.update(root.glob('*.py'))
        paths.update((root / 'tests').rglob('*.py'))
        paths.update(root.glob('*.lean'))
    return {str(p.relative_to(REPO)): digest(p) for p in sorted(paths)}

OUT.mkdir()
(OUT / 'SCRIPT.py').write_bytes(Path(__file__).read_bytes())
before = source_map()
save('SOURCE-BEFORE.json', before)
for name in before:
    destination = OUT / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((REPO / name).read_bytes())
tests = sorted(str(p.relative_to(REPO)) for p in PACKAGE.glob('test_*.py'))
commands = [
    ('tests', [PYTHON, '-B', '-m', 'pytest', *tests, PREFIX + 'tests/',
        '--deselect=' + PREFIX + 'tests/test_registration_cli.py::test_cli_failure_is_retained_with_no_assignments_and_no_reuse',
        '--deselect=' + PREFIX + 'tests/test_registration_cli.py::test_cli_ignores_harmless_matching_header_policy_cache',
        '--junitxml=' + str(OUT / 'tests.xml'), '--basetemp=' + str(OUT / 'cases'), '-q']),
    ('registration', [PYTHON, '-I', '-S', PREFIX + 'registration_evidence.py']),
    ('native', [PYTHON, '-I', '-S', PREFIX + 'native_evidence.py',
        '--seal-sha256', '523531c5bb7ca79b4f3ff5d5e6316960cef38dcddcd82dc335421341280ffe2e']),
    ('resource', [PYTHON, '-I', '-S', PREFIX + 'resource_exitcode_evidence.py']),
]
environment = dict(os.environ)
environment.update(OCM_RESOURCE_HOST_QUALIFICATION='0', PYTHONDONTWRITEBYTECODE='1')
save('PRELAUNCH.json', {'commands': commands, 'cwd': str(REPO),
    'environment_overrides': {'OCM_RESOURCE_HOST_QUALIFICATION': '0', 'PYTHONDONTWRITEBYTECODE': '1'},
    'python': {'path': str(Path(PYTHON).resolve()), **digest(Path(PYTHON).resolve())},
    'scope': 'Current portable engineering tests and retained evidence guards; no real corpus or privileged profile dispatch',
    'source_scope': 'Top-level Python/Lean and tests Python for four proof components, plus coverage workflow; archives and changing documentation excluded'})
records = []
for name, argv in commands:
    started = time.monotonic()
    result = subprocess.run(argv, cwd=REPO, env=environment, capture_output=True, timeout=600)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    record = {'name': name, 'returncode': result.returncode,
        'wall_s': time.monotonic() - started, 'stdout': digest(OUT / (name + '.stdout')),
        'stderr': digest(OUT / (name + '.stderr'))}
    records.append(record)
    save('PROCESSES.json', records)
    if result.returncode:
        save('FAILURE.json', record)
        save('SOURCE-AFTER.json', source_map())
        raise SystemExit('Integration failed: ' + name)
after = source_map()
save('SOURCE-AFTER.json', after)
if before != after:
    raise SystemExit('Source changed during integration')
suites = list(ET.parse(OUT / 'tests.xml').getroot().iter('testsuite'))
counts = {k: sum(int(s.attrib.get(k, 0)) for s in suites)
          for k in ['tests', 'failures', 'errors', 'skipped']}
assert counts['errors'] == counts['failures'] == 0
counts['passed'] = counts['tests'] - counts['skipped']
result = {'terminal': 'PORTABLE_INTEGRATION_PASS', 'counts': counts,
    'source_files': len(before), 'source_changed': False,
    'guards': {name: json.loads((OUT / (name + '.stdout')).read_bytes())
               for name in ['registration', 'native', 'resource']},
    'scope': 'Current engineering integration only; no new semantic coverage, search, learning or scaling result'}
save('RESULT.json', result)
save('FILES.json', {p.name: digest(p) for p in sorted(OUT.iterdir()) if p.is_file()})
print(json.dumps(result, sort_keys=True))
