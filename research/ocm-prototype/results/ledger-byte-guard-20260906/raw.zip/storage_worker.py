"""Exact recorded storage replay; no actor, solver, model, or clock substitution."""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time

START = time.perf_counter()
if sys.flags.optimize or "PYTHONOPTIMIZE" in os.environ:
    raise RuntimeError("assertion gates must be enabled")
plan = json.loads(Path(sys.argv[1]).read_text())
case = next(c for c in plan["cases"] if c["id"] == sys.argv[2])
root = Path(plan["sources"][case["arm"]]["root"])
sys.path.insert(0, str(root / "src"))
from ocm.store.ledger import LedgerStore

def sha(data):
    return hashlib.sha256(data).hexdigest()

output = Path(case["output"])
output.mkdir(exist_ok=False)
phases = {}
record = {"case": case["id"], "arm": case["arm"], "pid": os.getpid(),
          "schema": "ocm.recorded-storage-comparison.v1", "status": "CANNOT_CHECK",
          "plan_sha256": sha(Path(sys.argv[1]).read_bytes())}
os.sched_setaffinity(0, {plan["cpu"]})
resource.setrlimit(resource.RLIMIT_AS, (plan["address_bytes"], plan["address_bytes"]))

def measured(name, fn):
    before = resource.getrusage(resource.RUSAGE_SELF)
    start = time.perf_counter()
    try:
        return fn()
    finally:
        after = resource.getrusage(resource.RUSAGE_SELF)
        phases[name] = {"wall_s": time.perf_counter() - start,
                        "self_cpu_s": after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime,
                        "peak_rss_kib": after.ru_maxrss}

try:
    def inputs():
        assert sha(Path(plan["executable"]).read_bytes()) == plan["executable_sha256"]
        actual = {p: sha((root / p).read_bytes()) for p in plan["sources"][case["arm"]]["files"]}
        assert actual == plan["sources"][case["arm"]]["files"]
        data = {key: Path(plan[key]["path"]).read_bytes() for key in ("prefix", "stream", "expected_final")}
        assert all(sha(v) == plan[k]["sha256"] for k, v in data.items())
        return data
    data = measured("input_and_source_binding", inputs)
    stream = json.loads(data["stream"])
    assert set(stream) == {"binding_rows", "query_rows", "explicit_persist_rows"}
    assert [len(stream[k]) for k in ("binding_rows", "query_rows", "explicit_persist_rows")] == [4, 9, 2]
    assert len(plan["cases"]) == 14 and len({c["id"] for c in plan["cases"]}) == 14
    state = Path(case["state"])
    assert not Path(os.environ["PYTHONPYCACHEPREFIX"]).exists()
    def setup():
        state.mkdir(exist_ok=False)
        (state / "ledger.jsonl").write_bytes(data["prefix"])
    measured("fresh_prefix_setup", setup)
    complete_start = time.perf_counter()
    complete_cpu = time.process_time()
    store = None
    def load():
        global store
        store = LedgerStore(state)
        rows = store.entries()
        assert len(rows) == plan["initial_count"]
        assert rows[-1].entry_hash == plan["initial_head"]
    measured("initial_full_validation", load)
    returned = []
    def append_group(name):
        for row in stream[name]:
            entry = store.append(row["kind"], row["payload"], expected_head=row["prev_hash"])
            returned.append(entry)
    for name in ("binding_rows", "query_rows", "explicit_persist_rows"):
        measured(name, lambda name=name: append_group(name))
    def validate():
        rows = store.entries()
        assert len(rows) == plan["initial_count"] + 15
        assert rows[plan["initial_count"]:] == tuple(returned)
        assert rows[-1].entry_hash == plan["final_head"]
        actual = store.path.read_bytes()
        assert actual == data["expected_final"]
        return {"ledger_sha256": sha(actual), "bytes": len(actual),
                "count": len(rows), "head": rows[-1].entry_hash}
    final = measured("final_full_validation", validate)
    record["complete_stream_wall_s"] = time.perf_counter() - complete_start
    record["complete_stream_self_cpu_s"] = time.process_time() - complete_cpu
    snapshot = getattr(store, "_validated_snapshot", None)
    record["cache"] = {"retained_content_bytes": len(snapshot[0]) if snapshot is not None else 0,
                       "shallow_total_bytes": sum(sys.getsizeof(v) for v in snapshot) + sys.getsizeof(snapshot) if snapshot is not None else 0}
    actual = {p: sha((root / p).read_bytes()) for p in plan["sources"][case["arm"]]["files"]}
    assert actual == plan["sources"][case["arm"]]["files"]
    record.update(status="EXACT_RECORDED_LEDGER_REPRODUCED", source_unchanged=True, final=final)
except Exception as exc:
    record["error"] = type(exc).__name__ + ": " + str(exc)
record.update(assertions_enabled=__debug__, phases=phases, case_body_wall_s=time.perf_counter() - START,
              peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              resource_scope="single storage process; no spawned children; physical IO/energy UNKNOWN")
(output / "receipt.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
print(json.dumps({"case": case["id"], "status": record["status"], "receipt": str(output / "receipt.json")}))
raise SystemExit(0 if record["status"] == "EXACT_RECORDED_LEDGER_REPRODUCED" else 2)
