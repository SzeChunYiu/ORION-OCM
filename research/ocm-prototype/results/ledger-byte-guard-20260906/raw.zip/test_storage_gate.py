"""Synthetic receipt-reader controls only; never benchmark observations."""
import hashlib
import importlib.util
import json
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location("storage_gate", Path(__file__).with_name("grade_storage_pairs.py"))
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))
    return gate.sha(path)

@pytest.mark.parametrize("mode", ["clean", "no_gain", "missing", "nonfinite", "disk_changed"])
def test_synthetic_acceptance_and_refusal(tmp_path, mode):
    expected = b"SYNTHETIC CONTROL ONLY"
    cases = []
    for pair in range(1, 8):
        for arm in (["baseline", "candidate"] if pair % 2 else ["candidate", "baseline"]):
            key = f"pair{pair}-{arm}"
            cases.append({"id": key, "pair": pair, "arm": arm,
                          "state": str(tmp_path / key / "state"), "output": str(tmp_path / key / "out")})
    plan = {"cases": cases, "run_root": str(tmp_path), "tools": {},
            "decision": {"query_median_of_paired_ratios_max": .8,
                         "complete_median_of_paired_ratios_strict_max": 1.0},
            "expected_final": {"sha256": hashlib.sha256(expected).hexdigest()}, "final_head": "synthetic"}
    plan_path = tmp_path / "synthetic-plan.json"; digest = write(plan_path, plan)
    records = []
    for case in cases:
        state = Path(case["state"]); state.mkdir(parents=True)
        (state / "ledger.jsonl").write_bytes(expected)
        faster = case["arm"] == "candidate" and mode != "no_gain"
        q = 1.0 if faster else 2.0
        if mode == "nonfinite" and case == cases[0]: q = float("nan")
        row = {"case": case["id"], "arm": case["arm"], "plan_sha256": digest,
               "assertions_enabled": True, "source_unchanged": True,
               "status": "EXACT_RECORDED_LEDGER_REPRODUCED",
               "final": {"ledger_sha256": plan["expected_final"]["sha256"], "count": 517, "head": "synthetic"},
               "phases": {"query_rows": {"wall_s": q}}, "complete_stream_wall_s": q * 2}
        receipt_sha = write(Path(case["output"]) / "receipt.json", row)
        records.append({"case": case["id"], "receipt_sha256": receipt_sha,
                        "exit_code": 0, "timed_out": False, "actor_pid_absent": True})
    if mode == "missing": records.pop()
    if mode == "disk_changed":
        (Path(cases[0]["state"]) / "ledger.jsonl").write_bytes(b"CHANGED")
    write(tmp_path / "execution.json", {"plan_sha256": digest, "records": records,
                                      "source_unchanged": True, "original_capture_unchanged": True})
    if mode in {"missing", "nonfinite", "disk_changed"}:
        with pytest.raises(ValueError): gate.assess(plan_path)
    else:
        result = gate.assess(plan_path)
        assert result["status"] == ("VALIDATED_REUSE_ENGINEERING_GAIN" if mode == "clean" else "NO_PRACTICAL_GAIN")
        assert len(result["pairs"]) == 7
