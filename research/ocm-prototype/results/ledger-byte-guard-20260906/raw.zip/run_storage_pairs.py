"""Run exactly the preregistered fourteen storage cases once, preserving every result."""
import hashlib
import json
import os
from pathlib import Path
import sys

if sys.flags.optimize or "PYTHONOPTIMIZE" in os.environ:
    raise RuntimeError("assertion gates must be enabled")
plan_path = Path(sys.argv[1])
plan = json.loads(plan_path.read_text())
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def source_matches():
    return all({p: sha(Path(s["root"]) / p) for p in s["files"]} == s["files"]
               for s in plan["sources"].values())
assert len(plan["cases"]) == 14
assert source_matches()
assert all(sha(x["path"]) == x["sha256"] for x in plan["tools"].values())
sys.path.insert(0, str(Path(plan["sources"]["baseline"]["root"]) / "research/ocm-prototype"))
from clia_reuse_study_common import run_process, verify_capture_manifest

verify_capture_manifest(plan["original_capture_root"])
run_root = Path(plan["run_root"])
run_root.mkdir(exist_ok=False)
records = []
for case in plan["cases"]:
    env = os.environ.copy()
    for key in ("PYTHONPATH", "PYTHONOPTIMIZE"):
        env.pop(key, None)
    env.update(plan["environment"])
    env["PYTHONPYCACHEPREFIX"] = case["pycache_prefix"]
    assert not Path(case["pycache_prefix"]).exists()
    prefix = run_root / case["id"]
    argv = [plan["executable"], plan["tools"]["worker"]["path"], str(plan_path), case["id"]]
    record = {"case": case["id"], "argv": argv, "host_loadavg_before": os.getloadavg()}
    try:
        record.update(run_process(argv, prefix, seconds=plan["per_case_deadline_s"],
                      cwd=run_root, env=env, cpu=plan["cpu"], address_bytes=plan["address_bytes"]))
    except Exception as exc:
        record.update(exit_code=None, error=type(exc).__name__ + ": " + str(exc))
    receipt = Path(case["output"]) / "receipt.json"
    record["receipt_sha256"] = sha(receipt) if receipt.exists() else None
    record["actor_pid_absent"] = not Path("/proc/" + str(record.get("pid", "UNKNOWN"))).exists()
    (run_root / (case["id"] + ".outer.json")).write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    records.append(record)
    print(case["id"], record.get("exit_code"), flush=True)
verify_capture_manifest(plan["original_capture_root"])
assert source_matches()
assert all(sha(x["path"]) == x["sha256"] for x in plan["tools"].values())
index = {"plan_sha256": sha(plan_path), "records": records, "source_unchanged": True,
         "original_capture_unchanged": True, "assertions_enabled": __debug__}
(run_root / "execution.json").write_text(json.dumps(index, indent=2, sort_keys=True) + "\n")
