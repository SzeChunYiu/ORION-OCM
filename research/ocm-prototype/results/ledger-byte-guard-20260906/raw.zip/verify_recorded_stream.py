"""Deterministic real-ledger compatibility control; no performance measurements."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path("/home/billy/orion-director-work/20260906")
OUT = ROOT / "ledger-byte-guard-v1"
sys.path.insert(0, str(ROOT / "ocm-ledger-byte-guard/src"))
if sys.flags.optimize or "PYTHONOPTIMIZE" in __import__("os").environ:
    raise RuntimeError("assertion gates must be enabled")
data = OUT / "inputs"
prefix = (data / "prefix.jsonl").read_bytes()
expected = (data / "expected-final.jsonl").read_bytes()
groups = json.loads((data / "append-stream.json").read_text())
stream = [row for key in ("binding_rows", "query_rows", "explicit_persist_rows") for row in groups[key]]
assert len(stream) == 15
records = {}
for arm, source in (("baseline", "ocm-ledger-reference"), ("candidate", "ocm-ledger-byte-guard")):
    module_path = ROOT / source / "src/ocm/store/ledger.py"
    name = "ocm.store._qualified_" + arm
    spec = importlib.util.spec_from_file_location(name, module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    state = OUT / ("functional-" + arm)
    state.mkdir(exist_ok=False)
    (state / "ledger.jsonl").write_bytes(prefix)
    store = module.LedgerStore(state)
    old = store.entries()
    assert len(old) == 502
    heads = []
    for row in stream:
        result = store.append(row["kind"], row["payload"], expected_head=row["prev_hash"])
        assert result.sequence == row["sequence"]
        assert result.prev_hash == row["prev_hash"]
        assert result.entry_hash == row["entry_hash"]
        assert result.kind == row["kind"] and result.payload == row["payload"]
        heads.append(result.entry_hash)
    assert store.path.read_bytes() == expected
    assert store.verify() == ()
    assert store.head().entry_hash == stream[-1]["entry_hash"]
    assert len(store.entries()) == 517
    records[arm] = {"ledger_sha256": hashlib.sha256(expected).hexdigest(),
                    "head_sequence": heads, "source_sha256": hashlib.sha256(module_path.read_bytes()).hexdigest()}
assert records["baseline"]["head_sequence"] == records["candidate"]["head_sequence"]
(OUT / "real-ledger-equivalence.json").write_text(json.dumps({
    "status": "EXACT_RECORDED_LEDGER_REPRODUCED_IN_BOTH",
    "scope": "functional compatibility; no performance measurements or actor execution",
    "initial_rows": 502, "appends": 15, "final_rows": 517, "records": records,
}, indent=2, sort_keys=True) + "\n")
print("Both implementations reproduced all original recorded bytes, entries, heads and sequences.")
