"""Fixed paired engineering gate; preserve every pair, no statistical or runtime claim."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def assess(plan_path):
    plan_path = Path(plan_path); plan = json.loads(plan_path.read_text())
    if any(sha(x["path"]) != x["sha256"] for x in plan["tools"].values()):
        raise ValueError("qualification tool binding changed")
    if (plan["decision"]["query_median_of_paired_ratios_max"] != 0.80
            or plan["decision"]["complete_median_of_paired_ratios_strict_max"] != 1.0):
        raise ValueError("registered criterion differs")
    index = json.loads((Path(plan["run_root"]) / "execution.json").read_text())
    if index["plan_sha256"] != sha(plan_path): raise ValueError("plan binding changed")
    if not index.get("source_unchanged") or not index.get("original_capture_unchanged"):
        raise ValueError("source or original capture changed")
    cases = plan["cases"]
    if len(cases) != 14 or len(index["records"]) != 14: raise ValueError("all fourteen outcomes required")
    if [r["case"] for r in index["records"]] != [c["id"] for c in cases]:
        raise ValueError("execution order differs")
    receipts = {}
    for case, outer in zip(cases, index["records"]):
        if outer.get("exit_code") != 0 or outer.get("timed_out") or not outer.get("actor_pid_absent"):
            raise ValueError("failed, censored or incomplete case: " + case["id"])
        if sha(Path(case["state"]) / "ledger.jsonl") != plan["expected_final"]["sha256"]:
            raise ValueError("persisted ledger binding changed")
        path = Path(case["output"]) / "receipt.json"
        if sha(path) != outer["receipt_sha256"]: raise ValueError("raw receipt binding changed")
        row = json.loads(path.read_text())
        if (row["case"] != case["id"] or row["arm"] != case["arm"]
                or row["plan_sha256"] != sha(plan_path) or not row.get("assertions_enabled")
                or row["status"] != "EXACT_RECORDED_LEDGER_REPRODUCED" or not row["source_unchanged"]
                or row["final"]["ledger_sha256"] != plan["expected_final"]["sha256"]
                or row["final"]["count"] != 517 or row["final"]["head"] != plan["final_head"]):
            raise ValueError("invalid semantic/custody result: " + case["id"])
        values = [row["phases"]["query_rows"]["wall_s"], row["complete_stream_wall_s"]]
        if not all(type(t) in (int, float) and math.isfinite(t) and t > 0 for t in values):
            raise ValueError("invalid timing observation")
        if values[1] < values[0]: raise ValueError("complete stream shorter than its query component")
        receipts[(case["pair"], case["arm"])] = row
    pairs = []
    for pair in range(1, 8):
        a, b = receipts[(pair, "baseline")], receipts[(pair, "candidate")]
        query = b["phases"]["query_rows"]["wall_s"] / a["phases"]["query_rows"]["wall_s"]
        complete = b["complete_stream_wall_s"] / a["complete_stream_wall_s"]
        pairs.append({"pair": pair, "query_component_ratio": query, "complete_stream_ratio": complete})
    query_median = statistics.median(p["query_component_ratio"] for p in pairs)
    complete_median = statistics.median(p["complete_stream_ratio"] for p in pairs)
    passed = query_median <= 0.80 and complete_median < 1.0
    return {"status": "VALIDATED_REUSE_ENGINEERING_GAIN" if passed else "NO_PRACTICAL_GAIN",
            "plan_sha256": sha(plan_path), "pairs": pairs, "median_query_ratio": query_median,
            "median_complete_ratio": complete_median,
            "scope": "recorded storage component only; not runtime, asymptotic or scientific superiority"}

if __name__ == "__main__":
    if sys.flags.optimize or "PYTHONOPTIMIZE" in __import__("os").environ:
        raise RuntimeError("assertion gates must be enabled")
    try:
        result = assess(sys.argv[1])
    except Exception as exc:
        result = {"status": "CANNOT_CHECK", "reason": type(exc).__name__ + ": " + str(exc)}
    out = Path(sys.argv[2]); out.mkdir(exist_ok=False)
    (out / "receipt.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result))
    raise SystemExit(2 if result["status"] == "CANNOT_CHECK" else 0)
