import subprocess,sys,time
subprocess.Popen([sys.executable,'-c',"import os,signal,time;from pathlib import Path;signal.signal(signal.SIGTERM,signal.SIG_IGN);Path('/home/billy/orion-director-work/20260906/clia-reuse-study-controls/final-v2-unit/test_timeout_reaps_actor_and_t0/UNIT_CHILD_PID').write_text(str(os.getpid()));time.sleep(30)"])
time.sleep(30)
